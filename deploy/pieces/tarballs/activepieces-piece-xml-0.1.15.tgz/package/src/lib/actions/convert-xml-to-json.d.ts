export declare const convertXmlToJson: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    xml: import("@activepieces/pieces-framework").LongTextProperty<true>;
    ignoreAttributes: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
//# sourceMappingURL=convert-xml-to-json.d.ts.map