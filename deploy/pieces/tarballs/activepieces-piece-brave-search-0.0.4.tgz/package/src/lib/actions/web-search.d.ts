export declare const braveWebSearchAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    query: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    count: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=web-search.d.ts.map