export declare const braveSearchAuth: import("@activepieces/pieces-framework").SecretTextProperty<true>;
//# sourceMappingURL=auth.d.ts.map