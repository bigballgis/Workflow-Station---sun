"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.braveSearch = void 0;
const tslib_1 = require("tslib");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const web_search_1 = require("./lib/actions/web-search");
const pieces_common_1 = require("@activepieces/pieces-common");
const auth_1 = require("./lib/auth");
exports.braveSearch = (0, pieces_framework_1.createPiece)({
    displayName: 'Brave Search',
    description: 'Privacy-preserving search engine',
    auth: auth_1.braveSearchAuth,
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/brave-search.png',
    authors: ['ErisMorn', 'sanket-a11y'],
    actions: [
        web_search_1.braveWebSearchAction,
        (0, pieces_common_1.createCustomApiCallAction)({
            auth: auth_1.braveSearchAuth,
            baseUrl: () => 'https://api.search.brave.com/res/v1',
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
                return {
                    'X-Subscription-Token': auth.secret_text,
                };
            }),
        }),
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map