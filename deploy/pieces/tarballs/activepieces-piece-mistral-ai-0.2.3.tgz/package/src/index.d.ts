export declare const mistralAi: import("@activepieces/pieces-framework").Piece<(import("@activepieces/pieces-framework").SecretTextProperty<true> | import("@activepieces/pieces-framework").CustomAuthProperty<{
    accountId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayAuthToken: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    mistralApiKey: import("@activepieces/pieces-framework").SecretTextProperty<false>;
}>)[]>;
//# sourceMappingURL=index.d.ts.map