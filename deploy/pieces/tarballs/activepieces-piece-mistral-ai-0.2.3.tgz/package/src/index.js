"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mistralAi = void 0;
const tslib_1 = require("tslib");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const create_chat_completion_1 = require("./lib/actions/create-chat-completion");
const create_embeddings_1 = require("./lib/actions/create-embeddings");
const upload_file_1 = require("./lib/actions/upload-file");
const run_ocr_1 = require("./lib/actions/run-ocr");
const list_models_1 = require("./lib/actions/list-models");
const auth_1 = require("./lib/common/auth");
const request_1 = require("./lib/common/request");
const pieces_common_1 = require("@activepieces/pieces-common");
exports.mistralAi = (0, pieces_framework_1.createPiece)({
    displayName: "Mistral AI",
    description: "Mistral AI provides state-of-the-art open-weight and hosted language models for text generation, embeddings, and reasoning tasks.",
    auth: auth_1.mistralAuth,
    minimumSupportedRelease: "0.36.1",
    logoUrl: "https://cdn.activepieces.com/pieces/mistral-ai.png",
    authors: ["sparkybug"],
    categories: [shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE],
    actions: [
        create_chat_completion_1.createChatCompletion,
        create_embeddings_1.createEmbeddings,
        upload_file_1.uploadFile,
        run_ocr_1.runOcr,
        list_models_1.listModels,
        (0, pieces_common_1.createCustomApiCallAction)({
            auth: auth_1.mistralAuth,
            baseUrl: (auth) => (auth ? request_1.mistralRequest.getConfig(auth).baseUrl : 'https://api.mistral.ai/v1'),
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () { return request_1.mistralRequest.getConfig(auth).headers; }),
        }),
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map