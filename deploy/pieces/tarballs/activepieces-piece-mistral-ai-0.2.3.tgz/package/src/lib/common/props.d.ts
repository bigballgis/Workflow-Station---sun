export declare const modelDropdown: import("@activepieces/pieces-framework").DropdownProperty<string, true, (import("@activepieces/pieces-framework").SecretTextProperty<true> | import("@activepieces/pieces-framework").CustomAuthProperty<{
    accountId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayAuthToken: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    mistralApiKey: import("@activepieces/pieces-framework").SecretTextProperty<false>;
}>)[]>;
export declare function parseMistralError(e: any): string;
//# sourceMappingURL=props.d.ts.map