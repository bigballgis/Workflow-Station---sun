export declare const uploadFile: import("@activepieces/pieces-framework").IAction<(import("@activepieces/pieces-framework").SecretTextProperty<true> | import("@activepieces/pieces-framework").CustomAuthProperty<{
    accountId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayAuthToken: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    mistralApiKey: import("@activepieces/pieces-framework").SecretTextProperty<false>;
}>)[], {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    purpose: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=upload-file.d.ts.map