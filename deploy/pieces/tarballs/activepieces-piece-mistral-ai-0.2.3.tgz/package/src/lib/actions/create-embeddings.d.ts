export declare const createEmbeddings: import("@activepieces/pieces-framework").IAction<(import("@activepieces/pieces-framework").SecretTextProperty<true> | import("@activepieces/pieces-framework").CustomAuthProperty<{
    accountId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayAuthToken: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    mistralApiKey: import("@activepieces/pieces-framework").SecretTextProperty<false>;
}>)[], {
    input: import("@activepieces/pieces-framework").ArrayProperty<true>;
    timeout: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=create-embeddings.d.ts.map