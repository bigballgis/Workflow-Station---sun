export declare const createChatCompletion: import("@activepieces/pieces-framework").IAction<(import("@activepieces/pieces-framework").SecretTextProperty<true> | import("@activepieces/pieces-framework").CustomAuthProperty<{
    accountId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayAuthToken: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    mistralApiKey: import("@activepieces/pieces-framework").SecretTextProperty<false>;
}>)[], {
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, (import("@activepieces/pieces-framework").SecretTextProperty<true> | import("@activepieces/pieces-framework").CustomAuthProperty<{
        accountId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
        gatewayId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
        gatewayAuthToken: import("@activepieces/pieces-framework").SecretTextProperty<false>;
        mistralApiKey: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    }>)[]>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    temperature: import("@activepieces/pieces-framework").NumberProperty<false>;
    top_p: import("@activepieces/pieces-framework").NumberProperty<false>;
    max_tokens: import("@activepieces/pieces-framework").NumberProperty<false>;
    random_seed: import("@activepieces/pieces-framework").NumberProperty<false>;
    timeout: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=create-chat-completion.d.ts.map