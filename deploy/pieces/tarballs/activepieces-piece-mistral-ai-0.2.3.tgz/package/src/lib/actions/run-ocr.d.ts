export declare const runOcr: import("@activepieces/pieces-framework").IAction<(import("@activepieces/pieces-framework").SecretTextProperty<true> | import("@activepieces/pieces-framework").CustomAuthProperty<{
    accountId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    gatewayAuthToken: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    mistralApiKey: import("@activepieces/pieces-framework").SecretTextProperty<false>;
}>)[], {
    model: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    documentSource: import("@activepieces/pieces-framework").StaticDropdownProperty<DocumentSource, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<DocumentSource, true>;
    sourceFields: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
    pages: import("@activepieces/pieces-framework").ArrayProperty<false>;
    includeImageBase64: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    timeout: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
type DocumentSource = 'url' | 'fileId';
export {};
//# sourceMappingURL=run-ocr.d.ts.map