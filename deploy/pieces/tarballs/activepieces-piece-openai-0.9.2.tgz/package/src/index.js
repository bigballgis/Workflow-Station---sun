"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.openai = void 0;
const tslib_1 = require("tslib");
const pieces_common_1 = require("@activepieces/pieces-common");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const ask_assistant_1 = require("./lib/actions/ask-assistant");
const send_prompt_1 = require("./lib/actions/send-prompt");
const classify_text_1 = require("./lib/actions/classify-text");
const create_embedding_1 = require("./lib/actions/create-embedding");
const delete_file_1 = require("./lib/actions/delete-file");
const edit_image_1 = require("./lib/actions/edit-image");
const extract_structure_data_action_1 = require("./lib/actions/extract-structure-data.action");
const generate_image_1 = require("./lib/actions/generate-image");
const list_files_1 = require("./lib/actions/list-files");
const list_models_1 = require("./lib/actions/list-models");
const text_to_speech_1 = require("./lib/actions/text-to-speech");
const transcriptions_1 = require("./lib/actions/transcriptions");
const translation_1 = require("./lib/actions/translation");
const upload_file_1 = require("./lib/actions/upload-file");
const vision_prompt_1 = require("./lib/actions/vision-prompt");
const auth_1 = require("./lib/auth");
const common_1 = require("./lib/common/common");
exports.openai = (0, pieces_framework_1.createPiece)({
    displayName: 'OpenAI',
    description: 'Use the many tools ChatGPT has to offer.',
    minimumSupportedRelease: '0.63.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/openai.png',
    categories: [shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE],
    auth: auth_1.openaiAuth,
    actions: [
        send_prompt_1.askOpenAI,
        ask_assistant_1.askAssistant,
        vision_prompt_1.visionPrompt,
        extract_structure_data_action_1.extractStructuredDataAction,
        classify_text_1.classifyText,
        create_embedding_1.createEmbedding,
        generate_image_1.generateImage,
        edit_image_1.editImage,
        text_to_speech_1.textToSpeech,
        transcriptions_1.transcribeAction,
        translation_1.translateAction,
        upload_file_1.uploadFile,
        list_files_1.listFiles,
        delete_file_1.deleteFile,
        list_models_1.listModels,
        (0, pieces_common_1.createCustomApiCallAction)({
            auth: auth_1.openaiAuth,
            baseUrl: () => common_1.baseUrl,
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
                return {
                    Authorization: `Bearer ${auth.secret_text}`,
                };
            }),
        }),
    ],
    authors: [
        'aboudzein',
        'astorozhevsky',
        'Willianwg',
        'Nilesh',
        'Salem-Alaa',
        'kishanprmr',
        'MoShizzle',
        'khaledmashaly',
        'abuaboud',
        'amrdb',
        'onyedikachi-david'
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map