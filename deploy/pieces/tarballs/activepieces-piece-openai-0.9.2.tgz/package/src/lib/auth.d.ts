export declare const openaiAuth: import("@activepieces/pieces-framework").SecretTextProperty<true>;
//# sourceMappingURL=auth.d.ts.map