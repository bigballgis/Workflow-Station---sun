export declare const generateImage: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    resolution: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    quality: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
}>;
//# sourceMappingURL=generate-image.d.ts.map