export declare const deleteFile: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    fileId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=delete-file.d.ts.map