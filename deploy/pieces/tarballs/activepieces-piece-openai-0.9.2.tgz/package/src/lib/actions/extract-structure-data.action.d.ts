export declare const extractStructuredDataAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    text: import("@activepieces/pieces-framework").LongTextProperty<true>;
    params: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=extract-structure-data.action.d.ts.map