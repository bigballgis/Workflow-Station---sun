export declare const uploadFile: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    purpose: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    fileName: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=upload-file.d.ts.map