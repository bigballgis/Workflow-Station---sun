export declare const createEmbedding: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    model: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    input: import("@activepieces/pieces-framework").LongTextProperty<true>;
    dimensions: import("@activepieces/pieces-framework").NumberProperty<false>;
    user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=create-embedding.d.ts.map