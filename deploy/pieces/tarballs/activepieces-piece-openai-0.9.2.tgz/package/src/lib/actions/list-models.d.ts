export declare const listModels: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    contains: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=list-models.d.ts.map