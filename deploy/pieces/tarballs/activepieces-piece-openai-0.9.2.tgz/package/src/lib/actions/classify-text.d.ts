export declare const classifyText: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    model: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    input: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=classify-text.d.ts.map