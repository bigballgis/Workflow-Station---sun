export declare const listFiles: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    purpose: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    limit: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=list-files.d.ts.map