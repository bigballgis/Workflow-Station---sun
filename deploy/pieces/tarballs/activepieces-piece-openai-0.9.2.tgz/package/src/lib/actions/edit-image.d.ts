export declare const editImage: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    image: import("@activepieces/pieces-framework").FileProperty<true>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    mask: import("@activepieces/pieces-framework").FileProperty<false>;
    size: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    quality: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
}>;
//# sourceMappingURL=edit-image.d.ts.map