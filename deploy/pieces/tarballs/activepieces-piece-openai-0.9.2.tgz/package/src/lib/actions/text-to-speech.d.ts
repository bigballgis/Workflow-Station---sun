export declare const textToSpeech: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    text: import("@activepieces/pieces-framework").LongTextProperty<true>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    speed: import("@activepieces/pieces-framework").NumberProperty<false>;
    voice: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    format: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    fileName: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=text-to-speech.d.ts.map