/** 支持的摘要算法(与 node:crypto 名称一致)。 */
export type HashAlgorithm = 'sha256' | 'sha512' | 'sha1' | 'md5';
/** 输出编码。 */
export type HashEncoding = 'hex' | 'base64';
/** 计算文本摘要,纯本地、零外网。 */
export declare function hashText(text: string, algorithm: HashAlgorithm, encoding?: HashEncoding): string;
/** UTF-8 文本 → Base64。 */
export declare function base64Encode(text: string): string;
/** Base64 → UTF-8 文本。非法输入抛错(Buffer 会静默容错,这里显式校验)。 */
export declare function base64Decode(encoded: string): string;
//# sourceMappingURL=hashing.d.ts.map