export declare const base64DecodeAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    encoded: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=base64-decode.d.ts.map