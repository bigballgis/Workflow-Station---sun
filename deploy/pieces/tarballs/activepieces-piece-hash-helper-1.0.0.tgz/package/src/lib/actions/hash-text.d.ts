export declare const hashTextAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    text: import("@activepieces/pieces-framework").LongTextProperty<true>;
    algorithm: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    encoding: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
}>;
//# sourceMappingURL=hash-text.d.ts.map