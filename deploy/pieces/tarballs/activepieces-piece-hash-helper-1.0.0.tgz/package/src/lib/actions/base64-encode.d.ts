export declare const base64EncodeAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    text: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=base64-encode.d.ts.map