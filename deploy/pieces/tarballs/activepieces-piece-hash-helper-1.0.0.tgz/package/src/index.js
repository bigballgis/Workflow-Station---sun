"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hashHelper = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const base64_decode_1 = require("./lib/actions/base64-decode");
const base64_encode_1 = require("./lib/actions/base64-encode");
const hash_text_1 = require("./lib/actions/hash-text");
exports.hashHelper = (0, pieces_framework_1.createPiece)({
    displayName: 'Hash Helper',
    description: '文本摘要与 Base64 编解码(纯本地,无外网)。',
    auth: pieces_framework_1.PieceAuth.None(), // 纯计算件无需鉴权
    minimumSupportedRelease: '0.36.1', // 必须 ≤ 我们的 0.84.0
    logoUrl: 'https://cdn.activepieces.com/pieces/hash-helper.png', // 气隙里图标会裂,纯外观
    authors: ['workflow-station'],
    categories: [shared_1.PieceCategory.CORE],
    actions: [hash_text_1.hashTextAction, base64_encode_1.base64EncodeAction, base64_decode_1.base64DecodeAction],
    triggers: [],
});
//# sourceMappingURL=index.js.map