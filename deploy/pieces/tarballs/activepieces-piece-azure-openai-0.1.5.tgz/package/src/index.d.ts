export declare const azureOpenai: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").CustomAuthProperty<{
    endpoint: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    apiKey: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>>;
//# sourceMappingURL=index.d.ts.map