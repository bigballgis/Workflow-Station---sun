"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.azureOpenai = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const ask_gpt_1 = require("./lib/actions/ask-gpt");
const auth_1 = require("./lib/auth");
exports.azureOpenai = (0, pieces_framework_1.createPiece)({
    displayName: 'Azure OpenAI',
    description: 'Powerful AI tools from Microsoft',
    auth: auth_1.azureOpenaiAuth,
    minimumSupportedRelease: '0.36.1',
    logoUrl: 'https://cdn.activepieces.com/pieces/azure-openai.png',
    authors: ["MoShizzle", "abuaboud"],
    actions: [ask_gpt_1.askGpt],
    triggers: [],
});
//# sourceMappingURL=index.js.map