export declare const azureOpenaiAuth: import("@activepieces/pieces-framework").CustomAuthProperty<{
    endpoint: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    apiKey: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>;
//# sourceMappingURL=auth.d.ts.map