"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.todos = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const create_todo_1 = require("./lib/actions/create-todo");
const shared_1 = require("@activepieces/shared");
const wait_for_approval_1 = require("./lib/actions/wait-for-approval");
const create_todo_and_wait_1 = require("./lib/actions/create-todo-and-wait");
exports.todos = (0, pieces_framework_1.createPiece)({
    displayName: 'Todos',
    description: 'Create tasks for project members to take actions, useful for approvals, reviews, and manual actions performed by humans',
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.49.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/todos.svg',
    authors: ['hazemadelkhalel'],
    categories: [shared_1.PieceCategory.CORE, shared_1.PieceCategory.FLOW_CONTROL],
    actions: [create_todo_1.createTodo, wait_for_approval_1.waitForApproval, create_todo_and_wait_1.createTodoAndWait],
    triggers: [],
});
//# sourceMappingURL=index.js.map