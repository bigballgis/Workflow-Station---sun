import { AppConnectionValueForAuthProperty } from "@activepieces/pieces-framework";
import { SeekPage, STATUS_VARIANT, UserWithMetaInformation } from "@activepieces/shared";
export declare const createTodoProps: {
    title: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    description: import("@activepieces/pieces-framework").LongTextProperty<false>;
    assigneeId: import("@activepieces/pieces-framework").DropdownProperty<string, false, undefined>;
    statusOptions: import("@activepieces/pieces-framework").ArrayProperty<true>;
};
export declare function constructTodoUrl(publicUrl: string, todoId: string, status: string, isTest: boolean): string;
type ApprovalParms = {
    auth?: AppConnectionValueForAuthProperty<undefined>;
    propsValue: {
        title: string;
        description?: string;
        statusOptions: unknown[];
        assigneeId?: string;
    };
    flows: {
        current: {
            id: string;
        };
    };
    run: {
        id: string;
    };
    server: {
        publicUrl: string;
        token: string;
    };
    generateResumeUrl: (options: {
        queryParams: Record<string, any>;
    }) => string;
};
export declare function sendTodoApproval(context: ApprovalParms, isTest: boolean): Promise<import("@activepieces/pieces-common").HttpResponse<{
    assigneeId?: string | null | undefined;
    resolveUrl?: string | null | undefined;
    createdByUserId?: string | null | undefined;
    flow?: {
        metadata?: {
            [x: string]: unknown;
        } | null | undefined;
        ownerId?: string | null | undefined;
        folderId?: string | null | undefined;
        publishedVersionId?: string | null | undefined;
        timeSavedPerRun?: number | null | undefined;
        templateId?: string | null | undefined;
        triggerSource?: {
            schedule?: {
                type: import("dist/packages/shared/src/lib/trigger").TriggerSourceScheduleType.CRON_EXPRESSION;
                cronExpression: string;
                timezone: string;
            } | null | undefined;
        } | undefined;
        projectId: string;
        version: {
            updatedBy?: string | null | undefined;
            schemaVersion?: string | null | undefined;
            backupFiles?: {
                [x: string]: string;
            } | null | undefined;
            flowId: string;
            id: string;
            created: string;
            updated: string;
            displayName: string;
            valid: boolean;
            trigger: {
                nextAction?: any;
                type: import("@activepieces/shared").FlowTriggerType.EMPTY;
                name: string;
                displayName: string;
                settings: any;
                valid: boolean;
            } | {
                nextAction?: any;
                type: import("@activepieces/shared").FlowTriggerType.PIECE;
                name: string;
                displayName: string;
                settings: {
                    triggerName?: string | undefined;
                    sampleData?: {
                        sampleDataFileId?: string | undefined;
                        sampleDataInputFileId?: string | undefined;
                        lastTestDate?: string | undefined;
                    } | undefined;
                    customLogoUrl?: string | undefined;
                    pieceName: string;
                    pieceVersion: string;
                    input: {
                        [x: string]: any;
                    };
                    propertySettings: {
                        [x: string]: {
                            schema?: any;
                            type: import("dist/packages/shared/src/lib/flows").PropertyExecutionType;
                        };
                    };
                };
                valid: boolean;
            };
            agentIds: string[];
            state: import("@activepieces/shared").FlowVersionState;
            connectionIds: string[];
            notes: {
                ownerId?: string | null | undefined;
                size: {
                    width: number;
                    height: number;
                };
                id: string;
                content: string;
                color: import("dist/packages/shared/src/lib/flows").NoteColorVariant;
                position: {
                    x: number;
                    y: number;
                };
                createdAt: string;
                updatedAt: string;
            }[];
        };
        id: string;
        created: string;
        updated: string;
        status: import("@activepieces/shared").FlowStatus;
        externalId: string;
        operationStatus: import("@activepieces/shared").FlowOperationStatus;
    } | null | undefined;
    assignee?: {
        platformId?: string | null | undefined;
        externalId?: string | null | undefined;
        lastActiveDate?: string | null | undefined;
        imageUrl?: string | null | undefined;
        id: string;
        created: string;
        updated: string;
        email: string;
        status: import("@activepieces/shared").UserStatus;
        platformRole: import("@activepieces/shared").PlatformRole;
        firstName: string;
        lastName: string;
    } | null | undefined;
    createdByUser?: {
        platformId?: string | null | undefined;
        externalId?: string | null | undefined;
        lastActiveDate?: string | null | undefined;
        imageUrl?: string | null | undefined;
        id: string;
        created: string;
        updated: string;
        email: string;
        status: import("@activepieces/shared").UserStatus;
        platformRole: import("@activepieces/shared").PlatformRole;
        firstName: string;
        lastName: string;
    } | null | undefined;
    description: string;
    id: string;
    status: {
        description?: string | null | undefined;
        name: string;
        variant: STATUS_VARIANT;
        continueFlow: boolean;
    };
    platformId: string;
    created: string;
    updated: string;
    title: string;
    statusOptions: {
        description?: string | null | undefined;
        name: string;
        variant: STATUS_VARIANT;
        continueFlow: boolean;
    }[];
    flowId: string;
    runId: string;
    environment: import("@activepieces/shared").TodoEnvironment;
    projectId: string;
    locked: boolean;
}>>;
export declare function listAssignee(publicUrl: string, token: string): Promise<SeekPage<UserWithMetaInformation>>;
export {};
