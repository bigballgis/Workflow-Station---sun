export declare const createTodo: import("@activepieces/pieces-framework").IAction<undefined, {
    title: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    description: import("@activepieces/pieces-framework").LongTextProperty<false>;
    assigneeId: import("@activepieces/pieces-framework").DropdownProperty<string, false, undefined>;
    statusOptions: import("@activepieces/pieces-framework").ArrayProperty<true>;
}>;
