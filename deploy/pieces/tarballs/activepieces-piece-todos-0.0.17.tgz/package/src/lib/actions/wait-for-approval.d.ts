export declare const waitForApproval: import("@activepieces/pieces-framework").IAction<undefined, {
    taskId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
