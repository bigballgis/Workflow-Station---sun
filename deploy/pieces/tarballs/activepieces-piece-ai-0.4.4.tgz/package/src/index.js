"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ai = void 0;
const tslib_1 = require("tslib");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const ask_ai_1 = require("./lib/actions/text/ask-ai");
const summarize_text_1 = require("./lib/actions/text/summarize-text");
const generate_image_1 = require("./lib/actions/image/generate-image");
const classify_text_1 = require("./lib/actions/utility/classify-text");
const extract_structured_data_1 = require("./lib/actions/utility/extract-structured-data");
const run_agent_1 = require("./lib/actions/agents/run-agent");
exports.ai = (0, pieces_framework_1.createPiece)({
    displayName: "AI",
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.78.2',
    categories: [
        shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE,
        shared_1.PieceCategory.UNIVERSAL_AI,
    ],
    logoUrl: "https://cdn.activepieces.com/pieces/new-core/text-ai.svg",
    authors: ['anasbarg', 'amrdb', 'Louai-Zokerburg'],
    actions: [ask_ai_1.askAI, summarize_text_1.summarizeText, generate_image_1.generateImageAction, classify_text_1.classifyText, extract_structured_data_1.extractStructuredData, run_agent_1.runAgent],
    triggers: [],
});
tslib_1.__exportStar(require("./lib/common/props"), exports);
tslib_1.__exportStar(require("./lib/common/ai-sdk"), exports);
//# sourceMappingURL=index.js.map