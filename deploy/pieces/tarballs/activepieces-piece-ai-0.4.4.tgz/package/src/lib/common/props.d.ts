import { AIProviderName } from '@activepieces/shared';
type AIModelType = 'text' | 'image';
type AIPropsParams<T extends AIModelType> = {
    modelType: T;
    allowedProviders?: AIProviderName[];
};
export declare const aiProps: <T extends AIModelType>({ modelType, allowedProviders, }: AIPropsParams<T>) => {
    provider: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
};
export {};
//# sourceMappingURL=props.d.ts.map