import { AgentOutputField, SeekPage, PopulatedFlow, AgentFlowTool } from '@activepieces/shared';
import { ZodObject } from 'zod';
import { Tool } from 'ai';
export declare const agentUtils: {
    isTaskCompletionToolCall: (toolName: string) => toolName is "updateTaskStatus";
    structuredOutputSchema(outputFields: AgentOutputField[]): ZodObject | undefined;
    getPrompts(userPrompt: string, options?: {
        hasKnowledgeBaseTools?: boolean;
    }): {
        prompt: string;
        system: string;
    };
    constructFlowsTools(params: ConstructFlowsToolsParams): Promise<Record<string, Tool>>;
};
type ConstructFlowsToolsParams = {
    tools: AgentFlowTool[];
    fetchFlows: (params: {
        externalIds: string[];
    }) => Promise<SeekPage<PopulatedFlow>>;
    publicUrl: string;
    token: string;
};
export {};
//# sourceMappingURL=utils.d.ts.map