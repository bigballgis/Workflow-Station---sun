export declare const askAI: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    provider: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    conversationKey: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    creativity: import("@activepieces/pieces-framework").NumberProperty<false>;
    maxOutputTokens: import("@activepieces/pieces-framework").NumberProperty<false>;
    webSearch: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    webSearchOptions: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}>;
//# sourceMappingURL=ask-ai.d.ts.map