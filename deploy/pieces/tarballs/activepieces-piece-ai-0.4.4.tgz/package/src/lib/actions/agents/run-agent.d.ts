export declare const runAgent: import("@activepieces/pieces-framework").IAction<undefined, {
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    aiProviderModel: import("@activepieces/pieces-framework").ObjectProperty<true>;
    agentTools: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
    structuredOutput: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
    maxSteps: import("@activepieces/pieces-framework").NumberProperty<true>;
    webSearch: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    webSearchOptions: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}>;
//# sourceMappingURL=run-agent.d.ts.map