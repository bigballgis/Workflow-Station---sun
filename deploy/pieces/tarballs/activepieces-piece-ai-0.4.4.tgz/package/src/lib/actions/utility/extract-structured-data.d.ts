export declare const extractStructuredData: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    provider: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    text: import("@activepieces/pieces-framework").LongTextProperty<false>;
    files: import("@activepieces/pieces-framework").ArrayProperty<false>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<false>;
    mode: import("@activepieces/pieces-framework").StaticDropdownProperty<"simple" | "advanced", false> | import("@activepieces/pieces-framework").StaticDropdownProperty<"simple" | "advanced", true>;
    schema: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
    maxOutputTokens: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=extract-structured-data.d.ts.map