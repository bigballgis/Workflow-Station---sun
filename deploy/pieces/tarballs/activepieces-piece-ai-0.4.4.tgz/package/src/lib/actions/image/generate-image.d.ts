export declare const generateImageAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    provider: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    inputImages: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
    advancedOptions: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}>;
//# sourceMappingURL=generate-image.d.ts.map