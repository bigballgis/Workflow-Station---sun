export declare const summarizeText: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    provider: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    text: import("@activepieces/pieces-framework").LongTextProperty<true>;
    prompt: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    maxOutputTokens: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=summarize-text.d.ts.map