export declare const classifyText: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    provider: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, undefined>;
    text: import("@activepieces/pieces-framework").LongTextProperty<true>;
    categories: import("@activepieces/pieces-framework").ArrayProperty<true>;
}>;
//# sourceMappingURL=classify-text.d.ts.map