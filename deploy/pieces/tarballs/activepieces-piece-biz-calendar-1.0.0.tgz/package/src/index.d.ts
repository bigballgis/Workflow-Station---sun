export declare const bizCalendar: import("@activepieces/pieces-framework").Piece<undefined>;
//# sourceMappingURL=index.d.ts.map