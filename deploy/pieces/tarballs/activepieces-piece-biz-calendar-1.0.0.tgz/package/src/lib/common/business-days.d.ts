/** 业务日历纯函数：全部按 UTC 的「年月日」计算，规避时区把日期算偏。 */
/** 是否工作日：非周末且不在节假日清单里。holidays 传 ['2026-10-01', ...]。 */
export declare function isBusinessDay(input: string | Date, holidays?: string[]): boolean;
/** 从 start 起加 N 个工作日（N 可为负，向前推）。返回 YYYY-MM-DD。 */
export declare function addBusinessDays(start: string | Date, days: number, holidays?: string[]): string;
/**
 * start 与 end 之间的工作日数（含 end、不含 start；end 早于 start 返回负数）。
 */
export declare function businessDaysBetween(start: string | Date, end: string | Date, holidays?: string[]): number;
//# sourceMappingURL=business-days.d.ts.map