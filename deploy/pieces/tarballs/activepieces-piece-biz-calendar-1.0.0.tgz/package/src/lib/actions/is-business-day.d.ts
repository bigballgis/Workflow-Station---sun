export declare const isBusinessDayAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    date: import("@activepieces/pieces-framework").DateTimeProperty<true>;
    holidays: import("@activepieces/pieces-framework").ArrayProperty<false>;
    onFalse: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
}>;
//# sourceMappingURL=is-business-day.d.ts.map