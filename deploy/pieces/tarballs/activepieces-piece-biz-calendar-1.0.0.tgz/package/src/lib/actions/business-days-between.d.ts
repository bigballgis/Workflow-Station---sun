export declare const businessDaysBetweenAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    startDate: import("@activepieces/pieces-framework").DateTimeProperty<true>;
    endDate: import("@activepieces/pieces-framework").DateTimeProperty<true>;
    holidays: import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=business-days-between.d.ts.map