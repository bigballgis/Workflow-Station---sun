export declare const addBusinessDaysAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    startDate: import("@activepieces/pieces-framework").DateTimeProperty<true>;
    days: import("@activepieces/pieces-framework").NumberProperty<true>;
    holidays: import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=add-business-days.d.ts.map