import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const slaDueSoonTrigger: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    apiBaseUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    withinHours: import("@activepieces/pieces-framework").NumberProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    apiBaseUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    withinHours: import("@activepieces/pieces-framework").NumberProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    apiBaseUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    withinHours: import("@activepieces/pieces-framework").NumberProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    apiBaseUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    withinHours: import("@activepieces/pieces-framework").NumberProperty<true>;
}>;
//# sourceMappingURL=sla-due-soon.d.ts.map