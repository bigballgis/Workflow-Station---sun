"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.bizCalendar = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const add_business_days_1 = require("./lib/actions/add-business-days");
const business_days_between_1 = require("./lib/actions/business-days-between");
const is_business_day_1 = require("./lib/actions/is-business-day");
const sla_due_soon_1 = require("./lib/triggers/sla-due-soon");
exports.bizCalendar = (0, pieces_framework_1.createPiece)({
    displayName: 'Business Calendar',
    description: '工作日 / SLA 到期日计算（纯本地，无外网）。',
    auth: pieces_framework_1.PieceAuth.None(), // 纯计算件无需鉴权
    minimumSupportedRelease: '0.36.1', // 必须 ≤ 我们的 0.84.0
    logoUrl: 'https://cdn.activepieces.com/pieces/calendar.svg', // 气隙里图标会裂，纯外观
    authors: ['workflow-station'],
    categories: [shared_1.PieceCategory.CORE],
    actions: [add_business_days_1.addBusinessDaysAction, business_days_between_1.businessDaysBetweenAction, is_business_day_1.isBusinessDayAction],
    triggers: [sla_due_soon_1.slaDueSoonTrigger], // 若不做触发器，这里给 []
});
//# sourceMappingURL=index.js.map