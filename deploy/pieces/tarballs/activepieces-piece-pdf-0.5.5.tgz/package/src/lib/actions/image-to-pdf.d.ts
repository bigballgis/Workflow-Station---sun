export declare const imageToPdf: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    image: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=image-to-pdf.d.ts.map