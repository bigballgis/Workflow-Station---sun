export declare const pdfPageCount: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=pdf-page-count.d.ts.map