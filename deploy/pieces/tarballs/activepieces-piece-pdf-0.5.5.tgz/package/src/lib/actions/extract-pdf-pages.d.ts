export declare function pageRangeToIndexes(startPage: number, endPage: number, totalPages: number): number[];
export declare const extractPdfPages: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    markdown: import("@activepieces/pieces-framework/dist/src/lib/property/input/markdown-property").MarkDownProperty;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    pageRanges: import("@activepieces/pieces-framework").ArrayProperty<true>;
}>;
//# sourceMappingURL=extract-pdf-pages.d.ts.map