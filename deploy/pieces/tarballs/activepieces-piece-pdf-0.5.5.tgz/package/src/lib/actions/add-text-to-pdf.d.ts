export declare const addTextToPdf: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    textItems: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=add-text-to-pdf.d.ts.map