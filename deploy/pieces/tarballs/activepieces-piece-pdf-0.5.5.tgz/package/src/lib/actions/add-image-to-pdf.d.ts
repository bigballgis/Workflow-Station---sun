export declare const addImageToPdf: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    imageItems: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=add-image-to-pdf.d.ts.map