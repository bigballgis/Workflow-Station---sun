export declare const textToPdf: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    text: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=text-to-pdf.d.ts.map