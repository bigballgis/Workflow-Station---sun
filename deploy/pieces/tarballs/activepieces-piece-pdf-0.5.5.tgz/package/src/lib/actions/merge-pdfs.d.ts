export declare const mergePdfs: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    pdfFiles: import("@activepieces/pieces-framework").ArrayProperty<true>;
    outputFileName: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=merge-pdfs.d.ts.map