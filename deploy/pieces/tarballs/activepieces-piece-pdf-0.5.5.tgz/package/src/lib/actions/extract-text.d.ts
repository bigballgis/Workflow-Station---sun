export declare const extractText: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=extract-text.d.ts.map