"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PDF = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const extract_text_1 = require("./lib/actions/extract-text");
const convert_to_image_1 = require("./lib/actions/convert-to-image");
const text_to_pdf_1 = require("./lib/actions/text-to-pdf");
const image_to_pdf_1 = require("./lib/actions/image-to-pdf");
const pdf_page_count_1 = require("./lib/actions/pdf-page-count");
const extract_pdf_pages_1 = require("./lib/actions/extract-pdf-pages");
const merge_pdfs_1 = require("./lib/actions/merge-pdfs");
const add_text_to_pdf_1 = require("./lib/actions/add-text-to-pdf");
const add_image_to_pdf_1 = require("./lib/actions/add-image-to-pdf");
exports.PDF = (0, pieces_framework_1.createPiece)({
    displayName: 'PDF',
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.34.2',
    logoUrl: 'https://cdn.activepieces.com/pieces/pdf.svg',
    authors: [
        'nyamkamunhjin',
        'abuaboud',
        'AbdulTheActivepiecer',
        'jmgb27',
        'danielpoonwj',
        'bertrandong',
    ],
    categories: [shared_1.PieceCategory.CORE],
    actions: [
        extract_text_1.extractText,
        convert_to_image_1.convertToImage,
        text_to_pdf_1.textToPdf,
        image_to_pdf_1.imageToPdf,
        pdf_page_count_1.pdfPageCount,
        extract_pdf_pages_1.extractPdfPages,
        merge_pdfs_1.mergePdfs,
        add_text_to_pdf_1.addTextToPdf,
        add_image_to_pdf_1.addImageToPdf
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map