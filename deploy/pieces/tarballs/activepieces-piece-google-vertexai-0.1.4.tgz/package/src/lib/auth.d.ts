import { AppConnectionValueForAuthProperty } from '@activepieces/pieces-framework';
export declare const vertexAiAuth: import("@activepieces/pieces-framework").CustomAuthProperty<{
    serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
export type GoogleVertexAIAuthValue = AppConnectionValueForAuthProperty<typeof vertexAiAuth>;
//# sourceMappingURL=auth.d.ts.map