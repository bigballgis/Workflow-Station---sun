import { ThinkingLevel } from '@google/genai';
export declare const generateContent: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>, {
    location: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").CustomAuthProperty<{
        serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
    }>>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").CustomAuthProperty<{
        serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
    }>>;
    systemMessage: import("@activepieces/pieces-framework").LongTextProperty<false>;
    userMessage: import("@activepieces/pieces-framework").LongTextProperty<true>;
    files: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
    youtubeUrl: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    imageUrls: import("@activepieces/pieces-framework").ArrayProperty<false>;
    temperature: import("@activepieces/pieces-framework").NumberProperty<false>;
    maxOutputTokens: import("@activepieces/pieces-framework").NumberProperty<false>;
    thinkingLevel: import("@activepieces/pieces-framework").StaticDropdownProperty<ThinkingLevel, false>;
    thinkingBudget: import("@activepieces/pieces-framework").NumberProperty<false>;
    includeThoughts: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
//# sourceMappingURL=generate-content.d.ts.map