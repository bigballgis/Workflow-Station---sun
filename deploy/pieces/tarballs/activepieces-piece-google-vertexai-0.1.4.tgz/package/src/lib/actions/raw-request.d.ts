export declare const customApiCall: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>, {
    url: import("@activepieces/pieces-framework").DynamicProperties<true, import("@activepieces/pieces-framework").CustomAuthProperty<{
        serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
    }> | undefined>;
    method: import("@activepieces/pieces-framework").StaticDropdownProperty<import("@activepieces/pieces-common").HttpMethod, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<import("@activepieces/pieces-common").HttpMethod, true>;
    headers: import("@activepieces/pieces-framework").ObjectProperty<false> | import("@activepieces/pieces-framework").ObjectProperty<true>;
    queryParams: import("@activepieces/pieces-framework").ObjectProperty<false> | import("@activepieces/pieces-framework").ObjectProperty<true>;
    body_type: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    body: import("@activepieces/pieces-framework").DynamicProperties<false, import("@activepieces/pieces-framework").CustomAuthProperty<{
        serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
    }> | undefined>;
    response_is_binary: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    failsafe: import("@activepieces/pieces-framework").CheckboxProperty<false> | import("@activepieces/pieces-framework").CheckboxProperty<true>;
    timeout: import("@activepieces/pieces-framework").NumberProperty<false> | import("@activepieces/pieces-framework").NumberProperty<true>;
    followRedirects: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
//# sourceMappingURL=raw-request.d.ts.map