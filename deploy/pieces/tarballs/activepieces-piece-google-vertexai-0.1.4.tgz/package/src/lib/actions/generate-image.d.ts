export declare const generateImage: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>, {
    location: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").CustomAuthProperty<{
        serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
    }>>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").CustomAuthProperty<{
        serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
    }>>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    modelOptions: import("@activepieces/pieces-framework").DynamicProperties<true, import("@activepieces/pieces-framework").CustomAuthProperty<{
        serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
    }>>;
}>;
//# sourceMappingURL=generate-image.d.ts.map