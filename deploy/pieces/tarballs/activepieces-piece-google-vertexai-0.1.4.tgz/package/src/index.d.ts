export declare const googleVertexai: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").CustomAuthProperty<{
    serviceAccountJson: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>>;
export { vertexAiAuth, GoogleVertexAIAuthValue } from "./lib/auth";
//# sourceMappingURL=index.d.ts.map