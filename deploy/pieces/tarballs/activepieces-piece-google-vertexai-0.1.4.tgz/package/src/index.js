"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.vertexAiAuth = exports.googleVertexai = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const auth_1 = require("./lib/auth");
const actions_1 = require("./lib/actions");
exports.googleVertexai = (0, pieces_framework_1.createPiece)({
    displayName: "Google Vertex AI",
    description: "Generate content and images using Gemini and Imagen models on Google Vertex AI.",
    auth: auth_1.vertexAiAuth,
    minimumSupportedRelease: "0.71.4",
    logoUrl: "https://cdn.activepieces.com/pieces/google-vertexai.png",
    categories: [shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE],
    authors: ["alinperghel", "onyedikachi-david", "bertrandong"],
    actions: [actions_1.generateContent, actions_1.generateImage, actions_1.customApiCall],
    triggers: [],
});
var auth_2 = require("./lib/auth");
Object.defineProperty(exports, "vertexAiAuth", { enumerable: true, get: function () { return auth_2.vertexAiAuth; } });
//# sourceMappingURL=index.js.map