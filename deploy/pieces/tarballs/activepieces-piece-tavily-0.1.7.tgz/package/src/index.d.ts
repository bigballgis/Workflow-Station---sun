export declare const tavily: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").SecretTextProperty<true>>;
//# sourceMappingURL=index.d.ts.map