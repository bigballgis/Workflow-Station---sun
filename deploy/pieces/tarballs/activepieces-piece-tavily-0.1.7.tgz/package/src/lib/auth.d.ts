export declare const tavilyAuth: import("@activepieces/pieces-framework").SecretTextProperty<true>;
//# sourceMappingURL=auth.d.ts.map