export declare const searchAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    query: import("@activepieces/pieces-framework").LongTextProperty<true>;
    search_depth: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    topic: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    days: import("@activepieces/pieces-framework").NumberProperty<false>;
    time_range: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    max_results: import("@activepieces/pieces-framework").NumberProperty<false>;
    include_images: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    include_image_descriptions: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    include_answer: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    include_raw_content: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    include_domains: import("@activepieces/pieces-framework").ArrayProperty<false>;
    exclude_domains: import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=search.d.ts.map