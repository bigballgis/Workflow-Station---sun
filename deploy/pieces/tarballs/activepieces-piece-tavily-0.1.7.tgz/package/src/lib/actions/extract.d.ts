export declare const extractAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    urls: import("@activepieces/pieces-framework").ArrayProperty<true>;
    include_images: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
//# sourceMappingURL=extract.d.ts.map