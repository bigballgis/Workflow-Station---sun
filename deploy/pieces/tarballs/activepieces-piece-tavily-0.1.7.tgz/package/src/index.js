"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tavily = void 0;
const tslib_1 = require("tslib");
const pieces_common_1 = require("@activepieces/pieces-common");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const search_1 = require("./lib/actions/search");
const extract_1 = require("./lib/actions/extract");
const auth_1 = require("./lib/auth");
exports.tavily = (0, pieces_framework_1.createPiece)({
    displayName: 'Tavily',
    description: 'Search engine tailored for AI agents.',
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/tavily.jpg',
    categories: [shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE],
    authors: ['OsamaHaikal'],
    auth: auth_1.tavilyAuth,
    actions: [search_1.searchAction, extract_1.extractAction,
        (0, pieces_common_1.createCustomApiCallAction)({
            baseUrl: () => 'https://api.tavily.com',
            auth: auth_1.tavilyAuth,
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () { return ({ Authorization: `Bearer ${auth.secret_text}` }); }),
        })
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map