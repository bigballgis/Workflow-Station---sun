export declare const createChatCompletionAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    model: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    temperature: import("@activepieces/pieces-framework").NumberProperty<false>;
    max_tokens: import("@activepieces/pieces-framework").NumberProperty<false>;
    top_p: import("@activepieces/pieces-framework").NumberProperty<false>;
    presence_penalty: import("@activepieces/pieces-framework").NumberProperty<false>;
    frequency_penalty: import("@activepieces/pieces-framework").NumberProperty<false>;
    roles: import("@activepieces/pieces-framework").JsonProperty<false>;
}>;
//# sourceMappingURL=create-chat-completion.action.d.ts.map