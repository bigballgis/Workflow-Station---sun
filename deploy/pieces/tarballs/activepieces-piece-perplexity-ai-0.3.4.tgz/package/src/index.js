"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.perplexityAi = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const create_chat_completion_action_1 = require("./lib/actions/create-chat-completion.action");
const auth_1 = require("./lib/auth");
exports.perplexityAi = (0, pieces_framework_1.createPiece)({
    displayName: 'Perplexity AI',
    auth: auth_1.perplexityAiAuth,
    minimumSupportedRelease: '0.36.1',
    logoUrl: 'https://cdn.activepieces.com/pieces/perplexity-ai.png',
    categories: [shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE],
    description: 'AI powered search engine',
    authors: ['kishanprmr', 'AbdulTheActivePiecer'],
    actions: [create_chat_completion_action_1.createChatCompletionAction],
    triggers: [],
});
//# sourceMappingURL=index.js.map