"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.blandAi = void 0;
const tslib_1 = require("tslib");
const pieces_common_1 = require("@activepieces/pieces-common");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const auth_1 = require("./lib/auth");
const send_call_1 = require("./lib/actions/send-call");
const get_call_details_1 = require("./lib/actions/get-call-details");
const list_calls_1 = require("./lib/actions/list-calls");
exports.blandAi = (0, pieces_framework_1.createPiece)({
    displayName: 'Bland AI',
    description: 'AI phone calling platform for outbound and conversational voice workflows.',
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/bland-ai.png',
    categories: [shared_1.PieceCategory.COMMUNICATION],
    auth: auth_1.blandAiAuth,
    authors: ['Harmatta'],
    actions: [
        send_call_1.sendCall,
        get_call_details_1.getCallDetails,
        list_calls_1.listCalls,
        (0, pieces_common_1.createCustomApiCallAction)({
            auth: auth_1.blandAiAuth,
            baseUrl: () => auth_1.BLAND_AI_BASE_URL,
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
                return ({
                    authorization: auth.secret_text,
                });
            }),
        }),
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map