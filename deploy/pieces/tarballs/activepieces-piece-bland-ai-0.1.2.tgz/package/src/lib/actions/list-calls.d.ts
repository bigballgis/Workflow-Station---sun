export declare const listCalls: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    limit: import("@activepieces/pieces-framework").NumberProperty<false>;
    fromNumber: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    toNumber: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=list-calls.d.ts.map