export declare const sendCall: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    phoneNumber: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    task: import("@activepieces/pieces-framework").LongTextProperty<false>;
    pathwayId: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    firstSentence: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    voice: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    model: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    language: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    maxDuration: import("@activepieces/pieces-framework").NumberProperty<false>;
    waitForGreeting: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    record: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    transferPhoneNumber: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    webhook: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    summaryPrompt: import("@activepieces/pieces-framework").LongTextProperty<false>;
}>;
//# sourceMappingURL=send-call.d.ts.map