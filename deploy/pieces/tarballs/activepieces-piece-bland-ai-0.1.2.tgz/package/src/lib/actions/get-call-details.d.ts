export declare const getCallDetails: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    callId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=get-call-details.d.ts.map