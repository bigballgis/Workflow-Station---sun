export declare const BLAND_AI_BASE_URL = "https://api.bland.ai/v1";
export declare const blandAiAuth: import("@activepieces/pieces-framework").SecretTextProperty<true>;
//# sourceMappingURL=auth.d.ts.map