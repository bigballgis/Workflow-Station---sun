"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.approval = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const create_approval_link_1 = require("./lib/actions/create-approval-link");
const wait_for_approval_1 = require("./lib/actions/wait-for-approval");
exports.approval = (0, pieces_framework_1.createPiece)({
    displayName: 'Approval (Legacy)',
    description: 'Build approval process in your workflows',
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.82.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/approvals.svg',
    authors: ["kishanprmr", "MoShizzle", "khaledmashaly", "abuaboud"],
    categories: [shared_1.PieceCategory.CORE, shared_1.PieceCategory.FLOW_CONTROL],
    actions: [wait_for_approval_1.waitForApprovalLink, create_approval_link_1.createApprovalLink],
    triggers: [],
});
//# sourceMappingURL=index.js.map