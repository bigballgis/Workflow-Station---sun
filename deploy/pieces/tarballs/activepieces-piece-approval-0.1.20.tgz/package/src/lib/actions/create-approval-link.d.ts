export declare const createApprovalLink: import("@activepieces/pieces-framework").IAction<undefined, {
    markdown: import("@activepieces/pieces-framework/dist/src/lib/property/input/markdown-property").MarkDownProperty;
}>;
//# sourceMappingURL=create-approval-link.d.ts.map