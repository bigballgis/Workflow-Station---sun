export declare const waitForApprovalLink: import("@activepieces/pieces-framework").IAction<undefined, {
    markdown: import("@activepieces/pieces-framework/dist/src/lib/property/input/markdown-property").MarkDownProperty;
}>;
//# sourceMappingURL=wait-for-approval.d.ts.map