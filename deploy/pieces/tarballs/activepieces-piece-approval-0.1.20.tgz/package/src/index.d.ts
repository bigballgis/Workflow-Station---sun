export declare const approval: import("@activepieces/pieces-framework").Piece<undefined>;
//# sourceMappingURL=index.d.ts.map