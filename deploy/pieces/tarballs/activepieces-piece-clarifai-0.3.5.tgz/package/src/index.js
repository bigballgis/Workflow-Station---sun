"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clarifai = void 0;
const tslib_1 = require("tslib");
const pieces_common_1 = require("@activepieces/pieces-common");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const ask_llm_1 = require("./lib/actions/ask-llm");
const call_audio_model_1 = require("./lib/actions/call-audio-model");
const call_image_model_1 = require("./lib/actions/call-image-model");
const call_post_inputs_1 = require("./lib/actions/call-post-inputs");
const call_text_model_1 = require("./lib/actions/call-text-model");
const call_workflow_1 = require("./lib/actions/call-workflow");
const generate_igm_1 = require("./lib/actions/generate-igm");
const auth_1 = require("./lib/auth");
const markdownDescription = `
Follow these instructions to get your Clarifai (Personal Access Token) PAT Key:
1. Go to the [security tab](https://clarifai.com/settings/security) in your Clarifai account and generate a new PAT token.
2. Copy the PAT token and paste it in the PAT Key field.
`;
exports.clarifai = (0, pieces_framework_1.createPiece)({
    displayName: 'Clarifai',
    description: 'AI-powered visual recognition',
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/clarifai.png',
    categories: [shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE],
    authors: ["akatechis", "zeiler", "Salem-Alaa", "kishanprmr", "MoShizzle", "abuaboud"],
    auth: auth_1.clarifaiAuth,
    actions: [
        ask_llm_1.clarifaiAskLLM,
        generate_igm_1.clarifaiGenerateIGM,
        call_image_model_1.visualClassifierModelPredictAction,
        call_text_model_1.textClassifierModelPredictAction,
        call_image_model_1.imageToTextModelPredictAction,
        call_text_model_1.textToTextModelPredictAction,
        call_audio_model_1.audioToTextModelPredictAction,
        call_post_inputs_1.postInputsAction,
        call_workflow_1.workflowPredictAction,
        (0, pieces_common_1.createCustomApiCallAction)({
            baseUrl: () => 'https://api.clarifai.com/v2', // Replace with the actual base URL
            auth: auth_1.clarifaiAuth,
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
                return ({
                    Authorization: `Key ${auth.secret_text}`,
                });
            }),
        }),
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map