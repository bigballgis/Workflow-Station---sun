export declare const clarifaiAuth: import("@activepieces/pieces-framework").SecretTextProperty<true>;
//# sourceMappingURL=auth.d.ts.map