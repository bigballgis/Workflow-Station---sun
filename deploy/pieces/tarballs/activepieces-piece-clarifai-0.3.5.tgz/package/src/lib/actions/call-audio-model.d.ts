export declare const audioToTextModelPredictAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    modelUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=call-audio-model.d.ts.map