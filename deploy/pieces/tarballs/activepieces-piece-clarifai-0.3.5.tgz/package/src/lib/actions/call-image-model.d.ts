export declare const visualClassifierModelPredictAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    modelUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
export declare const imageToTextModelPredictAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    modelUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=call-image-model.d.ts.map