export declare const workflowPredictAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    workflowUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=call-workflow.d.ts.map