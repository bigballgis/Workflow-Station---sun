export declare const postInputsAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    userId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    appId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=call-post-inputs.d.ts.map