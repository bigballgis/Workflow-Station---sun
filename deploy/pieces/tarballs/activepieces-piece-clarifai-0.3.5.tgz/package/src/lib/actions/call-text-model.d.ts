export declare const textClassifierModelPredictAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    modelUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    txt: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
export declare const textToTextModelPredictAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    modelUrl: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    txt: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=call-text-model.d.ts.map