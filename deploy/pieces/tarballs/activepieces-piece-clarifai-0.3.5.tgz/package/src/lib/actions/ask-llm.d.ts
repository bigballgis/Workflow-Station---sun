export declare const clarifaiAskLLM: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    models: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=ask-llm.d.ts.map