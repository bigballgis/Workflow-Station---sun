export declare const clarifai: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").SecretTextProperty<true>>;
//# sourceMappingURL=index.d.ts.map