export declare const schedule: import("@activepieces/pieces-framework").Piece<undefined>;
