"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.schedule = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const cron_expression_trigger_1 = require("./lib/triggers/cron-expression.trigger");
const every_day_trigger_1 = require("./lib/triggers/every-day.trigger");
const every_hour_trigger_1 = require("./lib/triggers/every-hour.trigger");
const every_month_trigger_1 = require("./lib/triggers/every-month.trigger");
const every_week_trigger_1 = require("./lib/triggers/every-week.trigger");
const every_x_minutes_trigger_1 = require("./lib/triggers/every-x-minutes.trigger");
exports.schedule = (0, pieces_framework_1.createPiece)({
    displayName: 'Schedule',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/schedule.svg',
    description: 'Trigger flow with fixed schedule',
    categories: [shared_1.PieceCategory.CORE],
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.30.0',
    authors: ["kishanprmr", "AbdulTheActivePiecer", "khaledmashaly", "abuaboud"],
    actions: [],
    triggers: [
        every_x_minutes_trigger_1.everyXMinutesTrigger,
        every_hour_trigger_1.everyHourTrigger,
        every_day_trigger_1.everyDayTrigger,
        every_week_trigger_1.everyWeekTrigger,
        every_month_trigger_1.everyMonthTrigger,
        cron_expression_trigger_1.cronExpressionTrigger,
    ],
});
//# sourceMappingURL=index.js.map