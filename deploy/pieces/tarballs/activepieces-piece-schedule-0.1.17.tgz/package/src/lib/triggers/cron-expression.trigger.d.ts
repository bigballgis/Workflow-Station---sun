import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const cronExpressionTrigger: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    cronExpression: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    cronExpression: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    cronExpression: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    cronExpression: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
