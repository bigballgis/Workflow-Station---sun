import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const everyWeekTrigger: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    day_of_the_week: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    hour_of_the_day: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    day_of_the_week: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    hour_of_the_day: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    day_of_the_week: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    hour_of_the_day: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    day_of_the_week: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    hour_of_the_day: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    timezone: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
