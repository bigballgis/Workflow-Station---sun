import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const everyXMinutesTrigger: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    minutes: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    minutes: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    minutes: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    minutes: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
}>;
