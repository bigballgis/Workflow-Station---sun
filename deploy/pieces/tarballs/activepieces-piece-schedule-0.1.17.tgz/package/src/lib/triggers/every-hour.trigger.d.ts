import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const everyHourTrigger: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    run_on_weekends: import("@activepieces/pieces-framework").CheckboxProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    run_on_weekends: import("@activepieces/pieces-framework").CheckboxProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    run_on_weekends: import("@activepieces/pieces-framework").CheckboxProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    run_on_weekends: import("@activepieces/pieces-framework").CheckboxProperty<true>;
}>;
