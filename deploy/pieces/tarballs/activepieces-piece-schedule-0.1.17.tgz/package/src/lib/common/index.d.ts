export declare const WEEK_DAYS: string[];
export declare const MONTH_DAYS: number[];
export declare const DAY_HOURS: string[];
export declare function validateHours(hours: number): number;
export declare function validateWeekDays(days: number): number;
export declare function validateMonthDays(days: number): number;
export declare const timezoneOptions: {
    label: string;
    value: string;
}[];
