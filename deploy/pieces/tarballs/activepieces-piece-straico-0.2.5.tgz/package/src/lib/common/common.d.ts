export declare const baseUrlv0 = "https://api.straico.com/v0";
export declare const baseUrlv1 = "https://api.straico.com/v1";
//# sourceMappingURL=common.d.ts.map