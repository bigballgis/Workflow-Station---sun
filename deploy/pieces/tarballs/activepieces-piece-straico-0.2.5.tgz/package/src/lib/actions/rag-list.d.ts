export declare const listRags: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {}>;
//# sourceMappingURL=rag-list.d.ts.map