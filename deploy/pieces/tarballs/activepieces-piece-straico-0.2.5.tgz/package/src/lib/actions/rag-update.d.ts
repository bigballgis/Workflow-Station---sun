export declare const updateRag: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    ragId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=rag-update.d.ts.map