export declare const agentList: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {}>;
//# sourceMappingURL=agent-list.d.ts.map