export declare const agentGet: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    agentId: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
}>;
//# sourceMappingURL=agent-get.d.ts.map