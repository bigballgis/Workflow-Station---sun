export declare const fileUpload: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=file-upload.d.ts.map