export declare const ragPromptCompletion: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    ragId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    searchType: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    k: import("@activepieces/pieces-framework").NumberProperty<false>;
    fetchK: import("@activepieces/pieces-framework").NumberProperty<false>;
    lambdaMult: import("@activepieces/pieces-framework").NumberProperty<false>;
    scoreThreshold: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=rag-prompt-completion.d.ts.map