export declare const promptCompletion: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    fileUrls: import("@activepieces/pieces-framework").ArrayProperty<false>;
    youtubeUrls: import("@activepieces/pieces-framework").ArrayProperty<false>;
    imageUrls: import("@activepieces/pieces-framework").ArrayProperty<false>;
    displayTranscripts: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    temperature: import("@activepieces/pieces-framework").NumberProperty<false>;
    maxTokens: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=prompt-completion.d.ts.map