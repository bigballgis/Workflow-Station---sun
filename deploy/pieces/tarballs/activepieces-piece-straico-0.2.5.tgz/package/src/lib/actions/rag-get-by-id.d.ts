export declare const getRagById: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    ragId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=rag-get-by-id.d.ts.map