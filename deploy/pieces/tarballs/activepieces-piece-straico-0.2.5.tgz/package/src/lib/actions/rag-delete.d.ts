export declare const deleteRag: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    ragId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=rag-delete.d.ts.map