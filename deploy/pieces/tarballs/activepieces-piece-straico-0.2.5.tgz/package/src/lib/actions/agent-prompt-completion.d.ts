export declare const agentPromptCompletion: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    agentId: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    searchType: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    k: import("@activepieces/pieces-framework").NumberProperty<false>;
    fetchK: import("@activepieces/pieces-framework").NumberProperty<false>;
    lambdaMult: import("@activepieces/pieces-framework").NumberProperty<false>;
    scoreThreshold: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=agent-prompt-completion.d.ts.map