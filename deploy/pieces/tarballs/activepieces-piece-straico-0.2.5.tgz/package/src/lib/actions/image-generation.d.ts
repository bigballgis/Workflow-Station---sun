export declare const imageGeneration: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    variations: import("@activepieces/pieces-framework").StaticDropdownProperty<number, true>;
    model: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    size: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    description: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=image-generation.d.ts.map