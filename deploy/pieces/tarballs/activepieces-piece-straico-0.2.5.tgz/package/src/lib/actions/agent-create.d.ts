export declare const agentCreate: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    name: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    description: import("@activepieces/pieces-framework").LongTextProperty<true>;
    custom_prompt: import("@activepieces/pieces-framework").LongTextProperty<true>;
    default_llm: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    tags: import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=agent-create.d.ts.map