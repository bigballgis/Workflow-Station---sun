export declare const agentUpdate: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    agentId: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    name: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    description: import("@activepieces/pieces-framework").LongTextProperty<false>;
    customPrompt: import("@activepieces/pieces-framework").LongTextProperty<false>;
    defaultLlm: import("@activepieces/pieces-framework").DropdownProperty<string, false, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    status: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    visibility: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
}>;
//# sourceMappingURL=agent-update.d.ts.map