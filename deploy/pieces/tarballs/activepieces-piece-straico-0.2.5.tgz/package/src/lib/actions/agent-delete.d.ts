export declare const agentDelete: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    agentId: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
}>;
//# sourceMappingURL=agent-delete.d.ts.map