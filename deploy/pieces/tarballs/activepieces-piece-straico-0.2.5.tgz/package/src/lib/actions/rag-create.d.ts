export declare const createRag: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    name: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    description: import("@activepieces/pieces-framework").LongTextProperty<true>;
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    chunkingMethod: import("@activepieces/pieces-framework").DropdownProperty<string, false, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    chunkSize: import("@activepieces/pieces-framework").NumberProperty<false>;
    chunkOverlap: import("@activepieces/pieces-framework").NumberProperty<false>;
    separator: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    separators: import("@activepieces/pieces-framework").ArrayProperty<false>;
    breakpointThresholdType: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    bufferSize: import("@activepieces/pieces-framework").NumberProperty<false>;
}>;
//# sourceMappingURL=rag-create.d.ts.map