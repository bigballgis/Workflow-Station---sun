"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.straico = void 0;
const tslib_1 = require("tslib");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const pieces_common_1 = require("@activepieces/pieces-common");
const common_1 = require("./lib/common/common");
const prompt_completion_1 = require("./lib/actions/prompt-completion");
const image_generation_1 = require("./lib/actions/image-generation");
const file_upload_1 = require("./lib/actions/file-upload");
const rag_create_1 = require("./lib/actions/rag-create");
const rag_list_1 = require("./lib/actions/rag-list");
const rag_get_by_id_1 = require("./lib/actions/rag-get-by-id");
const rag_update_1 = require("./lib/actions/rag-update");
const rag_delete_1 = require("./lib/actions/rag-delete");
const rag_prompt_completion_1 = require("./lib/actions/rag-prompt-completion");
const agent_create_1 = require("./lib/actions/agent-create");
const agent_add_rag_1 = require("./lib/actions/agent-add-rag");
const agent_list_1 = require("./lib/actions/agent-list");
const agent_delete_1 = require("./lib/actions/agent-delete");
const agent_update_1 = require("./lib/actions/agent-update");
const agent_get_1 = require("./lib/actions/agent-get");
const agent_prompt_completion_1 = require("./lib/actions/agent-prompt-completion");
const shared_1 = require("@activepieces/shared");
const auth_1 = require("./lib/auth");
const markdownDescription = `
Follow these instructions to get your Straico API Key:

1. Visit the following website: https://platform.straico.com/user-settings.
2. Once on the website, locate "Connect with Straico API" and click on the copy API Key.
`;
exports.straico = (0, pieces_framework_1.createPiece)({
    displayName: 'Straico',
    auth: auth_1.straicoAuth,
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/straico.png',
    categories: [shared_1.PieceCategory.ARTIFICIAL_INTELLIGENCE],
    description: 'All-in-one generative AI platform',
    authors: ['dennisrongo'],
    actions: [
        prompt_completion_1.promptCompletion,
        image_generation_1.imageGeneration,
        file_upload_1.fileUpload,
        rag_create_1.createRag,
        rag_list_1.listRags,
        rag_get_by_id_1.getRagById,
        rag_update_1.updateRag,
        rag_delete_1.deleteRag,
        rag_prompt_completion_1.ragPromptCompletion,
        agent_create_1.agentCreate,
        agent_add_rag_1.agentAddRag,
        agent_list_1.agentList,
        agent_delete_1.agentDelete,
        agent_update_1.agentUpdate,
        agent_get_1.agentGet,
        agent_prompt_completion_1.agentPromptCompletion,
        (0, pieces_common_1.createCustomApiCallAction)({
            auth: auth_1.straicoAuth,
            baseUrl: () => common_1.baseUrlv1,
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
                return {
                    Authorization: `Bearer ${auth.secret_text}`,
                };
            }),
        }),
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map