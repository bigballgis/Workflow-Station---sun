import { g as d, ae as ee, iO as K, j7 as ne, b6 as le, aJ as re, a6 as t, bL as de, c0 as me, j8 as pe, a_ as se, j as e, bs as he, b_ as ue, bt as xe, bu as ge, bv as je, bw as fe, c2 as Ce, c3 as M, aQ as H, fy as _, c8 as V, eU as A, Y as B, by as Q, gO as Ne, i as P, c6 as ye, cd as ae, h as te, j9 as ve, a7 as J, cO as we, at as be, eq as Re, ao as Pe, d5 as Se, d6 as Y, cQ as Te, a9 as Ie, cq as U, ak as Ae, D as G, a3 as De, a4 as Ee, a5 as ke, cp as I, et as Oe, dI as Fe, dJ as Le, cY as We, aa as ze, cS as Me, ja as He, ev as _e, cb as Ve, b7 as Ue, es as Ke, fz as $, cj as X, ck as Be, co as qe } from "./mount-builder-CqIEWsZv.mjs";
import { R as Qe, N as Je } from "./reconnect-button-dialog-J6RLSNjF.mjs";
import { P as q } from "./piece-icon-from-name-CkNp4shA.mjs";
import { C as Ye } from "./copy-text-tooltip-CjpUgg8T.mjs";
import { o as Z } from "./owner-column-hooks-B1fZKL15.mjs";
const ie = ({
  onConnectionMerged: j,
  children: h,
  projectId: x
}) => {
  const [p, v] = d.useState(!1), [f, l] = d.useState(
    "SELECT"
    /* SELECT */
  ), [g, w] = d.useState([]), { pieces: m, isLoading: b } = ee.usePieces({}), { data: C, isLoading: R } = K.useAppConnections({
    request: {
      projectId: x,
      limit: 1e3
    },
    extraKeys: [x, p],
    enabled: p
  }), { mutate: N, isPending: D } = ne.useReplaceConnections({
    setDialogOpen: v,
    refetch: j
  }), { mutate: E, isPending: k } = le({
    mutationFn: async (s) => await de.list({
      projectId: x,
      connectionExternalIds: [s],
      cursor: void 0,
      limit: 1e3
    }),
    onSuccess: (s) => {
      w(s.data), l(
        "CONFIRM"
        /* CONFIRM */
      );
    },
    onError: () => {
      re.error(t("Error"), {
        description: t("Failed to get affected flows")
      });
    }
  }), c = me({
    defaultValues: {
      pieceName: "",
      sourceConnections: { id: "", externalId: "" },
      replacedWithConnection: { id: "", externalId: "" }
    },
    mode: "onSubmit",
    resolver: (s) => {
      var n, a;
      const i = {};
      return s.pieceName || (i.pieceName = {
        type: "required",
        message: t("Please select a piece")
      }), (n = s.sourceConnections) != null && n.id || (i.sourceConnections = {
        type: "required",
        message: t("Please select a connection to replace")
      }), (a = s.replacedWithConnection) != null && a.id || (i.replacedWithConnection = {
        type: "required",
        message: t("Please select a connection to replace with")
      }), {
        values: Object.keys(i).length === 0 ? s : {},
        errors: i
      };
    }
  }), S = c.watch("pieceName"), u = new Set(
    C == null ? void 0 : C.data.map((s) => s.pieceName)
  ), O = (m == null ? void 0 : m.filter(
    (s) => s.name !== "@activepieces/piece-mcp" && s.name !== "@activepieces/piece-webhook" && u.has(s.name)
  ).map((s) => ({
    label: s.displayName,
    value: s.name
  }))) ?? [], r = (C == null ? void 0 : C.data.filter((s) => s.pieceName === S)) ?? [], T = pe({
    control: c.control,
    name: "sourceConnections.id"
  }), F = d.useMemo(() => r.filter((s) => s.id !== T).map((s) => ({
    label: s.displayName,
    value: s.id
  })), [r, T]), y = () => {
    l(
      "SELECT"
      /* SELECT */
    ), w([]);
  }, L = async (s) => {
    if (!await c.trigger()) {
      c.trigger([
        "pieceName",
        "sourceConnections",
        "replacedWithConnection"
      ]);
      return;
    }
    N({
      sourceAppConnectionId: s.sourceConnections.id,
      targetAppConnectionId: s.replacedWithConnection.id,
      projectId: x
    });
  }, W = (s) => {
    v(s), c.reset(), l(
      "SELECT"
      /* SELECT */
    ), w([]);
  }, z = se();
  return /* @__PURE__ */ e.jsxs(he, { open: p, onOpenChange: W, children: [
    /* @__PURE__ */ e.jsx(ue, { asChild: !0, children: h }),
    /* @__PURE__ */ e.jsxs(xe, { className: "flex flex-col", children: [
      /* @__PURE__ */ e.jsxs(ge, { children: [
        /* @__PURE__ */ e.jsx(je, { children: f === "SELECT" ? t("Replace Connections") : t("Confirm Replacement") }),
        /* @__PURE__ */ e.jsx(fe, { children: f === "SELECT" ? t(
          "This will replace one connection with another connection, existing flows will be changed to use the new connection, and the old connection will be deleted."
        ) : /* @__PURE__ */ e.jsx(e.Fragment, { children: t(
          "Existing MCP servers will not be changed automatically, you have to reconnect them manually."
        ) }) })
      ] }),
      f === "SELECT" ? /* @__PURE__ */ e.jsx(Ce, { ...c, children: /* @__PURE__ */ e.jsxs(
        "form",
        {
          onSubmit: c.handleSubmit(
            (s) => E(s.sourceConnections.externalId)
          ),
          className: "flex flex-col gap-4",
          children: [
            /* @__PURE__ */ e.jsx(
              M,
              {
                control: c.control,
                name: "pieceName",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
                  /* @__PURE__ */ e.jsx(H, { children: t("Piece") }),
                  /* @__PURE__ */ e.jsx(
                    _,
                    {
                      value: s.value,
                      onChange: (i) => {
                        s.onChange(i), c.setValue("sourceConnections", {
                          id: "",
                          externalId: ""
                        }), c.setValue("replacedWithConnection", {
                          id: "",
                          externalId: ""
                        });
                      },
                      options: O,
                      placeholder: t("Select a piece"),
                      loading: b,
                      valuesRendering: (i) => {
                        const n = m == null ? void 0 : m.find((a) => a.name === i);
                        return /* @__PURE__ */ e.jsxs("div", { className: "flex gap-2 items-center", children: [
                          /* @__PURE__ */ e.jsx(
                            "img",
                            {
                              src: n.logoUrl,
                              alt: n.displayName,
                              className: "w-4 h-4 object-contain"
                            }
                          ),
                          /* @__PURE__ */ e.jsx("span", { children: n.displayName })
                        ] });
                      }
                    }
                  ),
                  /* @__PURE__ */ e.jsx(V, {})
                ] })
              }
            ),
            S && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
              /* @__PURE__ */ e.jsx(
                M,
                {
                  control: c.control,
                  name: "sourceConnections",
                  render: ({ field: s }) => {
                    var i;
                    return /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
                      /* @__PURE__ */ e.jsx(H, { children: t("Connection to replace") }),
                      /* @__PURE__ */ e.jsx(
                        _,
                        {
                          value: (i = s.value) == null ? void 0 : i.id,
                          loading: R,
                          onChange: (n) => {
                            const a = r.find(
                              (o) => o.id === n
                            );
                            s.onChange({
                              id: (a == null ? void 0 : a.id) || "",
                              externalId: (a == null ? void 0 : a.externalId) || ""
                            }), c.setValue("replacedWithConnection", {
                              id: "",
                              externalId: ""
                            });
                          },
                          options: r.filter(
                            (n) => n.scope === A.PROJECT
                          ).map((n) => ({
                            label: n.displayName,
                            value: n.id
                          })),
                          placeholder: t("Choose connection to replace"),
                          valuesRendering: (n) => {
                            const a = r.find(
                              (o) => o.id === n
                            );
                            return /* @__PURE__ */ e.jsxs("div", { className: "flex gap-2 items-center", children: [
                              /* @__PURE__ */ e.jsx(
                                q,
                                {
                                  pieceName: a.pieceName,
                                  size: "xs",
                                  border: !1
                                }
                              ),
                              /* @__PURE__ */ e.jsx("span", { children: a.displayName })
                            ] });
                          }
                        }
                      ),
                      /* @__PURE__ */ e.jsx(V, {})
                    ] });
                  }
                }
              ),
              S && /* @__PURE__ */ e.jsx(
                M,
                {
                  control: c.control,
                  name: "replacedWithConnection",
                  render: ({ field: s }) => {
                    var i;
                    return /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
                      /* @__PURE__ */ e.jsx(H, { children: t("Replaced With") }),
                      /* @__PURE__ */ e.jsx(
                        _,
                        {
                          value: (i = s.value) == null ? void 0 : i.id,
                          loading: R,
                          onChange: (n) => {
                            const a = r.find((o) => o.id === n);
                            s.onChange({
                              id: (a == null ? void 0 : a.id) || "",
                              externalId: (a == null ? void 0 : a.externalId) || ""
                            });
                          },
                          options: F,
                          placeholder: t("Choose connection to replace with"),
                          valuesRendering: (n) => {
                            const a = r.find(
                              (o) => o.id === n
                            );
                            return /* @__PURE__ */ e.jsxs("div", { className: "flex gap-2 items-center", children: [
                              /* @__PURE__ */ e.jsx(
                                q,
                                {
                                  pieceName: a.pieceName,
                                  size: "xs",
                                  border: !1
                                }
                              ),
                              (a == null ? void 0 : a.scope) === A.PLATFORM && /* @__PURE__ */ e.jsx(B, { className: "w-4 h-4" }),
                              /* @__PURE__ */ e.jsx("span", { children: a.displayName })
                            ] });
                          }
                        }
                      ),
                      /* @__PURE__ */ e.jsx(V, {})
                    ] });
                  }
                }
              )
            ] }),
            /* @__PURE__ */ e.jsxs(Q, { children: [
              /* @__PURE__ */ e.jsx(Ne, { asChild: !0, children: /* @__PURE__ */ e.jsx(P, { type: "button", variant: "ghost", children: t("Cancel") }) }),
              /* @__PURE__ */ e.jsx(P, { type: "submit", loading: k, children: t("Next") })
            ] })
          ]
        }
      ) }) : /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-4", children: [
        /* @__PURE__ */ e.jsx(
          ye,
          {
            className: te(
              "h-[275px]",
              g.length === 0 && "h-[80px]"
            ),
            children: /* @__PURE__ */ e.jsx("div", { className: "flex flex-col gap-2", children: g.length === 0 ? /* @__PURE__ */ e.jsx("span", { className: "text-center text-muted-foreground p-4", children: t("No flows will be affected by this change") }) : g.map((s) => /* @__PURE__ */ e.jsx(
              "div",
              {
                className: "flex items-center justify-between",
                children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ e.jsx(ae, { className: "w-5 h-5" }),
                  /* @__PURE__ */ e.jsx(
                    P,
                    {
                      variant: "link",
                      className: "p-0 h-auto font-medium text-foreground truncate text-base",
                      onClick: () => {
                        z(
                          `/projects/${s.projectId}/flows/${s.id}`
                        );
                      },
                      children: s.version.displayName
                    }
                  )
                ] })
              },
              s.id
            )) })
          }
        ),
        /* @__PURE__ */ e.jsxs(Q, { children: [
          /* @__PURE__ */ e.jsx(P, { type: "button", variant: "accent", onClick: y, children: t("Back") }),
          /* @__PURE__ */ e.jsx(
            P,
            {
              type: "button",
              onClick: () => L(c.getValues()),
              loading: D,
              children: t("Replace")
            }
          )
        ] })
      ] })
    ] })
  ] });
};
ie.displayName = "ReplaceConnectionsDialog";
const Ge = {
  normal: {
    opacity: 1,
    pathLength: 1
  },
  animate: {
    opacity: [0, 1],
    pathLength: [0, 1],
    transition: {
      duration: 0.4,
      opacity: { duration: 0.1 }
    }
  }
}, $e = {
  normal: {
    opacity: 1,
    pathLength: 1
  },
  animate: {
    opacity: [0, 1],
    pathLength: [0, 1],
    transition: {
      delay: 0.2,
      duration: 0.3,
      opacity: { duration: 0.1, delay: 0.2 }
    }
  }
}, oe = d.forwardRef(
  ({ onMouseEnter: j, onMouseLeave: h, className: x, size: p = 28, ...v }, f) => {
    const l = ve(), g = d.useRef(!1);
    d.useImperativeHandle(f, () => (g.current = !0, {
      startAnimation: () => l.start("animate"),
      stopAnimation: () => l.start("normal")
    }));
    const w = d.useCallback(
      (b) => {
        g.current ? j == null || j(b) : l.start("animate");
      },
      [l, j]
    ), m = d.useCallback(
      (b) => {
        g.current ? h == null || h(b) : l.start("normal");
      },
      [l, h]
    );
    return /* @__PURE__ */ e.jsx(
      "div",
      {
        className: te(x),
        onMouseEnter: w,
        onMouseLeave: m,
        ...v,
        children: /* @__PURE__ */ e.jsxs(
          "svg",
          {
            fill: "none",
            height: p,
            stroke: "currentColor",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: "2",
            viewBox: "0 0 24 24",
            width: p,
            xmlns: "http://www.w3.org/2000/svg",
            children: [
              /* @__PURE__ */ e.jsx("path", { d: "M14 4c0-1.1.9-2 2-2" }),
              /* @__PURE__ */ e.jsx("path", { d: "M20 2c1.1 0 2 .9 2 2" }),
              /* @__PURE__ */ e.jsx("path", { d: "M22 8c0 1.1-.9 2-2 2" }),
              /* @__PURE__ */ e.jsx("path", { d: "M16 10c-1.1 0-2-.9-2-2" }),
              /* @__PURE__ */ e.jsx(
                J.path,
                {
                  animate: l,
                  d: "m3 7 3 3 3-3",
                  initial: "normal",
                  variants: $e
                }
              ),
              /* @__PURE__ */ e.jsx(
                J.path,
                {
                  animate: l,
                  d: "M6 10V5c0-1.7 1.3-3 3-3h1",
                  initial: "normal",
                  variants: Ge
                }
              ),
              /* @__PURE__ */ e.jsx("rect", { width: "8", height: "8", x: "2", y: "14", rx: "2" })
            ]
          }
        )
      }
    );
  }
);
oe.displayName = "ReplaceIcon";
function an() {
  const j = se(), [h, x] = d.useState(0), [p, v] = d.useState([]), [f, l] = d.useState(!1), { checkAccess: g } = we(), w = be.getCurrentUserPlatformRole(), m = Re(), { pieces: b } = ee.usePieces({}), C = (b ?? []).map((n) => ({
    label: n.displayName,
    value: n.name
  })), R = Pe.getProjectId(), N = new URLSearchParams(m.search), D = N.get(Se) ?? void 0, E = N.get(Y) ? parseInt(N.get(Y)) : 10, k = N.getAll("status") ?? [], c = N.get("pieceName") ?? void 0, S = N.get("displayName") ?? void 0, {
    data: u,
    isLoading: O,
    refetch: r
  } = K.useAppConnections({
    request: {
      projectId: R,
      cursor: D,
      limit: E,
      status: k,
      pieceName: c,
      displayName: S
    },
    extraKeys: [m.search, R],
    showErrorDialog: !0
  }), { mutateAsync: T } = ne.useBulkDeleteAppConnections(r), F = d.useMemo(() => {
    if (!(u != null && u.data)) return;
    const a = new URLSearchParams(m.search).getAll("owner");
    return a.length === 0 ? u : {
      data: u.data.filter(
        (o) => o.owner && a.includes(o.owner.email)
      ),
      next: u.next,
      previous: u.previous
    };
  }, [u, m.search]), y = g(
    Te.WRITE_APP_CONNECTION
  ), { data: L } = K.useConnectionsOwners(), W = Z.useOwnerColumnFilter(
    [
      {
        type: "select",
        title: t("Status"),
        accessorKey: "status",
        options: Object.values(Ae).map((n) => ({
          label: G.convertEnumToHumanReadable(n),
          value: n
        })),
        icon: Ie
      },
      {
        type: "select",
        title: t("Pieces"),
        accessorKey: "pieceName",
        icon: U,
        options: C
      },
      {
        type: "input",
        title: t("Name"),
        accessorKey: "displayName",
        icon: U
      }
    ],
    4,
    L
  ), z = Z.useOwnerColumn(
    [
      {
        accessorKey: "displayName",
        size: 280,
        header: ({ column: n }) => /* @__PURE__ */ e.jsx(
          I,
          {
            column: n,
            title: t("Name"),
            icon: U
          }
        ),
        cell: ({ row: n }) => {
          const a = n.original.scope === "PLATFORM";
          return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ e.jsx(
              Ye,
              {
                title: t("External ID"),
                text: n.original.externalId || "",
                children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 w-fit", children: [
                  /* @__PURE__ */ e.jsx(
                    q,
                    {
                      pieceName: n.original.pieceName,
                      showTooltip: !1,
                      size: "sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx("span", { className: "truncate max-w-[120px] 2xl:max-w-[250px]", children: n.original.displayName })
                ] })
              }
            ),
            a && /* @__PURE__ */ e.jsxs(De, { children: [
              /* @__PURE__ */ e.jsx(Ee, { asChild: !0, children: /* @__PURE__ */ e.jsx(B, { className: "w-4 h-4 shrink-0" }) }),
              /* @__PURE__ */ e.jsx(ke, { children: /* @__PURE__ */ e.jsx("p", { children: t(
                "This connection is global and can be managed in the platform admin"
              ) }) })
            ] })
          ] });
        }
      },
      {
        accessorKey: "status",
        size: 120,
        header: ({ column: n }) => /* @__PURE__ */ e.jsx(
          I,
          {
            column: n,
            title: t("Status"),
            icon: Le
          }
        ),
        cell: ({ row: n }) => {
          const a = n.original.status, { variant: o, icon: ce } = Oe.getStatusIcon(a);
          return /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(
            Fe,
            {
              icon: ce,
              text: G.convertEnumToHumanReadable(a),
              variant: o
            }
          ) });
        }
      },
      {
        accessorKey: "updated",
        size: 150,
        header: ({ column: n }) => /* @__PURE__ */ e.jsx(
          I,
          {
            column: n,
            title: t("Connected At"),
            icon: ze
          }
        ),
        cell: ({ row: n }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(We, { date: new Date(n.original.updated) }) })
      },
      {
        accessorKey: "flowCount",
        size: 80,
        header: ({ column: n }) => /* @__PURE__ */ e.jsx(
          I,
          {
            column: n,
            title: t("Flows"),
            icon: ae
          }
        ),
        cell: ({ row: n }) => {
          var a;
          return /* @__PURE__ */ e.jsx(
            "div",
            {
              className: "text-left underline cursor-pointer",
              onClick: () => {
                j(
                  `/flows?connectionExternalId=${n.original.externalId}`
                );
              },
              children: (a = n.original.flowIds) == null ? void 0 : a.length
            }
          );
        }
      },
      {
        id: "actions",
        size: 100,
        cell: ({ row: n }) => {
          const o = n.original.scope === A.PLATFORM ? w === Me.ADMIN : y;
          return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 justify-end", children: [
            n.original.scope === A.PROJECT ? /* @__PURE__ */ e.jsx(
              He,
              {
                connectionId: n.original.id,
                currentName: n.original.displayName,
                onRename: () => {
                  r();
                },
                userHasPermissionToRename: o
              }
            ) : /* @__PURE__ */ e.jsx(
              _e,
              {
                connectionId: n.original.id,
                currentName: n.original.displayName,
                projectIds: n.original.projectIds,
                userHasPermissionToEdit: o,
                onEdit: () => {
                  r();
                },
                preSelectForNewProjects: n.original.preSelectForNewProjects ?? !1
              }
            ),
            /* @__PURE__ */ e.jsx(
              Qe,
              {
                hasPermission: o,
                connection: n.original,
                onConnectionCreated: () => {
                  r();
                }
              }
            )
          ] });
        }
      }
    ],
    4
  ), s = d.useMemo(
    () => [
      {
        render: (n, a) => /* @__PURE__ */ e.jsx(e.Fragment, { children: p.length > 0 && /* @__PURE__ */ e.jsx(
          Ve,
          {
            title: t("Delete Connections"),
            message: t(
              "The selected connections will be permanently deleted."
            ),
            warning: /* @__PURE__ */ e.jsx(Ke, {}),
            mutationFn: async () => {
              await T(p.map((o) => o.id)), r(), a(), v([]);
            },
            entityName: t("connection"),
            buttonText: t("Delete"),
            open: f,
            onOpenChange: l,
            showToast: !0,
            children: /* @__PURE__ */ e.jsxs(
              P,
              {
                variant: "ghost",
                size: "sm",
                className: "text-destructive hover:text-destructive",
                onClick: () => l(!0),
                children: [
                  /* @__PURE__ */ e.jsx(Ue, { className: "h-4 w-4 mr-1" }),
                  t("Delete"),
                  " (",
                  p.length,
                  ")"
                ]
              }
            )
          }
        ) })
      }
    ],
    [p, f]
  ), i = d.useMemo(
    () => [
      /* @__PURE__ */ e.jsx(
        $,
        {
          hasPermission: y,
          children: /* @__PURE__ */ e.jsx(
            ie,
            {
              projectId: R,
              onConnectionMerged: () => {
                x(h + 1), r();
              },
              children: /* @__PURE__ */ e.jsx(
                X,
                {
                  icon: oe,
                  iconSize: 16,
                  variant: "outline",
                  disabled: !y,
                  children: t("Replace")
                }
              )
            }
          )
        },
        "replace"
      ),
      /* @__PURE__ */ e.jsx(
        $,
        {
          hasPermission: y,
          children: /* @__PURE__ */ e.jsx(
            Je,
            {
              isGlobalConnection: !1,
              onConnectionCreated: () => {
                x(h + 1), r();
              },
              children: /* @__PURE__ */ e.jsx(
                X,
                {
                  icon: Be,
                  iconSize: 16,
                  size: "sm",
                  disabled: !y,
                  children: t("New Connection")
                }
              )
            }
          )
        },
        "new"
      )
    ],
    [y, h]
  );
  return /* @__PURE__ */ e.jsx("div", { className: "flex-col w-full", children: /* @__PURE__ */ e.jsx(
    qe,
    {
      emptyStateTextTitle: t("No connections found"),
      emptyStateTextDescription: t(
        "Come back later when you create a automation to manage your connections"
      ),
      emptyStateIcon: /* @__PURE__ */ e.jsx(B, { className: "size-14" }),
      columns: z,
      page: F,
      isLoading: O,
      filters: W,
      selectColumn: !0,
      onSelectedRowsChange: v,
      bulkActions: s,
      toolbarButtons: i
    }
  ) });
}
export {
  an as AppConnectionsPage
};
