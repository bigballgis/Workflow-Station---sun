import { o as r, s as a, N as G, a as d, fL as V, fM as ce, fN as re, fO as Y, m as R, l, d as ie, dh as le, c as oe, e as A, H as z, b6 as $, cP as ne, ao as H, a1 as de, j as e, c7 as I, al as U, aW as K, cc as Z, c0 as me, c1 as xe, bs as he, bt as je, bu as ue, bv as ge, a6 as o, g as p, bF as Ee, aQ as S, aX as Ne, aI as fe, c6 as B, by as ye, i as J, fs as Ce, bi as Q, fP as pe } from "./mount-builder-CqIEWsZv.mjs";
var P = /* @__PURE__ */ ((t) => (t.UPDATE_FLOW = "UPDATE_FLOW", t.CREATE_FLOW = "CREATE_FLOW", t.DELETE_FLOW = "DELETE_FLOW", t))(P || {}), q = /* @__PURE__ */ ((t) => (t.UPDATE_CONNECTION = "UPDATE_CONNECTION", t.CREATE_CONNECTION = "CREATE_CONNECTION", t))(q || {}), D = /* @__PURE__ */ ((t) => (t.UPDATE_TABLE = "UPDATE_TABLE", t.CREATE_TABLE = "CREATE_TABLE", t.DELETE_TABLE = "DELETE_TABLE", t))(D || {});
const b = Y, F = r({
  externalId: a(),
  pieceName: a(),
  displayName: a()
}), Te = r({
  name: a(),
  type: a(),
  data: G(r({
    options: d(r({
      value: a()
    }))
  })),
  externalId: a()
}), L = r({
  id: a(),
  name: a(),
  externalId: a(),
  fields: d(Te),
  status: V(re),
  trigger: V(ce)
});
r({
  flows: d(Y),
  // NOTE: This is optional because in old releases, the connections, tables, agents and mcp state is not present
  connections: d(F).optional(),
  tables: d(L).optional()
});
const we = R([
  r({
    type: l(
      "UPDATE_FLOW"
      /* UPDATE_FLOW */
    ),
    newFlowState: b,
    flowState: b
  }),
  r({
    type: l(
      "CREATE_FLOW"
      /* CREATE_FLOW */
    ),
    flowState: b
  }),
  r({
    type: l(
      "DELETE_FLOW"
      /* DELETE_FLOW */
    ),
    flowState: b
  })
]), ee = R([
  r({
    type: l(
      "UPDATE_CONNECTION"
      /* UPDATE_CONNECTION */
    ),
    newConnectionState: F,
    connectionState: F
  }),
  r({
    type: l(
      "CREATE_CONNECTION"
      /* CREATE_CONNECTION */
    ),
    connectionState: F
  })
]), se = R([
  r({
    type: l(
      "UPDATE_TABLE"
      /* UPDATE_TABLE */
    ),
    newTableState: L,
    tableState: L
  }),
  r({
    type: l(
      "CREATE_TABLE"
      /* CREATE_TABLE */
    ),
    tableState: L
  }),
  r({
    type: l(
      "DELETE_TABLE"
      /* DELETE_TABLE */
    ),
    tableState: L
  })
]);
r({
  flows: d(we),
  connections: d(ee),
  tables: d(se)
});
const ve = r({
  flowId: a(),
  message: a()
}), Ae = R([
  r({
    type: l(
      "CREATE_FLOW"
      /* CREATE_FLOW */
    ),
    flow: r({
      id: a(),
      displayName: a()
    })
  }),
  r({
    type: l(
      "UPDATE_FLOW"
      /* UPDATE_FLOW */
    ),
    flow: r({
      id: a(),
      displayName: a()
    }),
    targetFlow: r({
      id: a(),
      displayName: a()
    })
  }),
  r({
    type: l(
      "DELETE_FLOW"
      /* DELETE_FLOW */
    ),
    flow: r({
      id: a(),
      displayName: a()
    })
  })
]);
r({
  flows: d(Ae),
  connections: d(ee),
  tables: d(se),
  errors: d(ve)
});
var y = /* @__PURE__ */ ((t) => (t.GIT = "GIT", t.PROJECT = "PROJECT", t.ROLLBACK = "ROLLBACK", t))(y || {});
const M = {
  name: a(),
  description: G(a()),
  selectedFlowsIds: G(d(a())),
  projectId: a()
}, Se = r({
  type: l(
    "GIT"
    /* GIT */
  ),
  ...M
}), Le = r({
  type: l(
    "ROLLBACK"
    /* ROLLBACK */
  ),
  ...M,
  projectReleaseId: a()
}), Re = r({
  type: l(
    "PROJECT"
    /* PROJECT */
  ),
  ...M,
  targetProjectId: a()
});
ie("type", [
  Le,
  Re,
  Se
]);
R([
  r({
    projectId: a(),
    type: l(
      "PROJECT"
      /* PROJECT */
    ),
    targetProjectId: a()
  }),
  r({
    projectId: a(),
    type: l(
      "ROLLBACK"
      /* ROLLBACK */
    ),
    projectReleaseId: a()
  }),
  r({
    projectId: a(),
    type: l(
      "GIT"
      /* GIT */
    )
  })
]);
r({
  projectId: a(),
  cursor: a().optional(),
  limit: le().default(10).optional()
});
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Oe = [
  [
    "path",
    {
      d: "m6 14 1.45-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5c0-1.1.9-2 2-2h3.93a2 2 0 0 1 1.66.9l.82 1.2a2 2 0 0 0 1.66.9H18a2 2 0 0 1 2 2v2",
      key: "1nmvlm"
    }
  ],
  ["circle", { cx: "14", cy: "15", r: "1", key: "1gm4qj" }]
], Fe = oe("folder-open-dot", Oe), _ = {
  async get(t) {
    return await A.get(`/v1/project-releases/${t}`);
  },
  async list(t) {
    return await A.get(
      "/v1/project-releases",
      t
    );
  },
  async create(t) {
    return await A.post("/v1/project-releases", t);
  },
  async delete(t) {
    return await A.delete(`/v1/project-releases/${t}`);
  },
  async diff(t) {
    return await A.post(
      "/v1/project-releases/diff",
      t
    );
  }
}, X = {
  all: ["project-releases"],
  detail: (t) => ["release", t]
}, _e = {
  useProjectReleases: () => z({
    queryKey: X.all,
    queryFn: () => _.list({
      projectId: H.getProjectId()
    }),
    meta: { showErrorDialog: !0, loadSubsetOptions: {} }
  }),
  useProjectRelease: (t, i) => z({
    queryKey: X.detail(t),
    queryFn: () => _.get(t),
    enabled: i
  })
}, te = {
  useDiffRelease: ({
    onSuccess: t,
    onError: i
  }) => $({
    mutationFn: (s) => _.diff(s),
    onSuccess: t,
    onError: () => {
      i(), ne();
    }
  }),
  useApplyRelease: ({ onSuccess: t }) => $({
    mutationFn: (i) => _.create(i),
    onSuccess: t
  })
}, W = (t, i) => /* @__PURE__ */ e.jsx("div", { className: "flex items-center justify-between text-sm hover:bg-accent/20 rounded-md py-1", children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
  i,
  t
] }) }), ae = de.memo(
  ({ change: t, selected: i, onSelect: s }) => /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    t.type === P.CREATE_FLOW && /* @__PURE__ */ e.jsxs("div", { className: "flex gap-2 text-success items-center", children: [
      /* @__PURE__ */ e.jsx(I, { checked: i, onCheckedChange: s }),
      W(
        t.flow.displayName,
        /* @__PURE__ */ e.jsx(U, { className: "w-4 h-4 shrink-0" })
      )
    ] }),
    t.type === P.UPDATE_FLOW && /* @__PURE__ */ e.jsxs("div", { className: "flex gap-2 items-center", children: [
      /* @__PURE__ */ e.jsx(I, { checked: i, onCheckedChange: s }),
      W(
        t.targetFlow.displayName,
        /* @__PURE__ */ e.jsx(K, { className: "w-4 h-4 shrink-0" })
      )
    ] }),
    t.type === P.DELETE_FLOW && /* @__PURE__ */ e.jsxs("div", { className: "flex gap-2 text-destructive items-center", children: [
      /* @__PURE__ */ e.jsx(I, { checked: i, onCheckedChange: s }),
      W(
        t.flow.displayName,
        /* @__PURE__ */ e.jsx(Z, { className: "w-4 h-4 shrink-0" })
      )
    ] })
  ] })
);
ae.displayName = "OperationChange";
const be = r({
  name: a().min(1, o("Name is required")),
  description: a().optional()
}), Ie = ({
  loading: t,
  diffRequest: i,
  plan: s,
  form: n,
  setOpen: E,
  refetch: N
}) => {
  var T, w;
  const h = (s == null ? void 0 : s.flows) && (s == null ? void 0 : s.flows.length) > 0 || (s == null ? void 0 : s.tables) && (s == null ? void 0 : s.tables.length) > 0, { mutate: m, isPending: j } = te.useApplyRelease({
    onSuccess: () => {
      N(), E(!1);
    }
  }), [u, C] = p.useState(
    new Set((s == null ? void 0 : s.flows.map((c) => c.flow.id)) || [])
  ), [O, f] = p.useState(""), k = (c) => {
    s && C(
      new Set(c ? s.flows.map((x) => x.flow.id) : [])
    );
  };
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    t && /* @__PURE__ */ e.jsx("div", { className: "flex items-center justify-center h-24", children: /* @__PURE__ */ e.jsx(Ee, {}) }),
    !t && h && /* @__PURE__ */ e.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ e.jsx(S, { className: "text-sm", htmlFor: "name", children: o("Name") }),
        /* @__PURE__ */ e.jsx(
          Ne,
          {
            id: "name",
            ...n.register("name"),
            onChange: (c) => {
              c.target.value && n.setError("name", { message: "" });
            },
            placeholder: o("Meeting Summary Flow")
          }
        ),
        n.formState.errors.name && /* @__PURE__ */ e.jsx("p", { className: "text-sm text-destructive", children: n.formState.errors.name.message })
      ] }),
      /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ e.jsx(S, { className: "text-sm", htmlFor: "description", children: o("Description") }),
        /* @__PURE__ */ e.jsx(
          fe,
          {
            id: "description",
            ...n.register("description"),
            placeholder: o("Added new features and fixed bugs")
          }
        ),
        n.formState.errors.description && /* @__PURE__ */ e.jsx("p", { className: "text-sm text-destructive", children: n.formState.errors.description.message })
      ] }),
      (s == null ? void 0 : s.flows) && (s == null ? void 0 : s.flows.length) > 0 && /* @__PURE__ */ e.jsxs("div", { className: "space-y-2 ", children: [
        /* @__PURE__ */ e.jsx("div", { className: "flex flex-col gap-2", children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 py-2 border-b", children: [
          /* @__PURE__ */ e.jsx(
            I,
            {
              checked: u.size === (s == null ? void 0 : s.flows.length),
              onCheckedChange: k
            }
          ),
          /* @__PURE__ */ e.jsxs(S, { className: "text-sm font-medium", children: [
            o("Flows Changes"),
            " (",
            u.size,
            "/",
            (s == null ? void 0 : s.flows.length) || 0,
            ")"
          ] })
        ] }) }),
        /* @__PURE__ */ e.jsx(B, { viewPortClassName: "max-h-[15vh]", children: s == null ? void 0 : s.flows.map((c) => /* @__PURE__ */ e.jsx(
          ae,
          {
            change: c,
            selected: u.has(c.flow.id),
            onSelect: (x) => {
              const v = new Set(u);
              x ? v.add(c.flow.id) : v.delete(c.flow.id), f(""), C(v);
            }
          },
          c.flow.id
        )) })
      ] }),
      (s == null ? void 0 : s.connections) && (s == null ? void 0 : s.connections.length) > 0 && /* @__PURE__ */ e.jsx("div", { className: "space-y-2", children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col justify -center gap-1 py-2 border-b", children: [
          /* @__PURE__ */ e.jsxs(S, { className: "text-sm font-medium", children: [
            o("Connections Changes"),
            " (",
            ((T = s == null ? void 0 : s.connections) == null ? void 0 : T.length) || 0,
            ")"
          ] }),
          /* @__PURE__ */ e.jsx("div", { className: "flex items-center text-sm text-muted-foreground", children: /* @__PURE__ */ e.jsx("span", { className: "flex items-center gap-2", children: o(
            "New connections are placeholders and need to be reconnected again"
          ) }) })
        ] }),
        /* @__PURE__ */ e.jsx(B, { viewPortClassName: "max-h-[10vh]", children: s == null ? void 0 : s.connections.map((c) => /* @__PURE__ */ e.jsxs(
          "div",
          {
            className: "flex items-center gap-2 text-sm py-1",
            children: [
              c.type === q.UPDATE_CONNECTION && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e.jsx(K, { className: "w-4 h-4 shrink-0" }),
                /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ e.jsx("span", { children: c.connectionState.displayName }),
                  /* @__PURE__ */ e.jsxs("span", { children: [
                    " ",
                    o("renamed to"),
                    " "
                  ] }),
                  /* @__PURE__ */ e.jsx("span", { children: c.newConnectionState.displayName })
                ] })
              ] }),
              c.type === q.CREATE_CONNECTION && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e.jsx(U, { className: "w-4 h-4 shrink-0 text-success" }),
                /* @__PURE__ */ e.jsx("span", { className: "text-success", children: c.connectionState.displayName })
              ] })
            ]
          },
          c.connectionState.externalId
        )) })
      ] }) }),
      (s == null ? void 0 : s.tables) && (s == null ? void 0 : s.tables.length) > 0 && /* @__PURE__ */ e.jsx("div", { className: "space-y-2", children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ e.jsx("div", { className: "flex flex-col justify -center gap-1 py-2 border-b", children: /* @__PURE__ */ e.jsxs(S, { className: "text-sm font-medium", children: [
          o("Tables Changes"),
          " (",
          ((w = s == null ? void 0 : s.tables) == null ? void 0 : w.length) || 0,
          ")"
        ] }) }),
        /* @__PURE__ */ e.jsx(B, { viewPortClassName: "max-h-[10vh]", children: s == null ? void 0 : s.tables.map((c) => /* @__PURE__ */ e.jsxs(
          "div",
          {
            className: "flex items-center gap-2 text-sm py-1",
            children: [
              c.type === D.UPDATE_TABLE && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e.jsx(K, { className: "w-4 h-4 shrink-0" }),
                /* @__PURE__ */ e.jsx("div", { className: "flex items-center gap-1", children: /* @__PURE__ */ e.jsx("span", { children: c.tableState.name }) })
              ] }),
              c.type === D.CREATE_TABLE && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e.jsx(U, { className: "w-4 h-4 shrink-0 text-success" }),
                /* @__PURE__ */ e.jsx("span", { className: "text-success", children: c.tableState.name })
              ] }),
              c.type === D.DELETE_TABLE && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e.jsx(Z, { className: "w-4 h-4 shrink-0 text-destructive" }),
                /* @__PURE__ */ e.jsx("span", { className: "text-destructive", children: c.tableState.name })
              ] })
            ]
          },
          c.tableState.externalId
        )) })
      ] }) }),
      O && /* @__PURE__ */ e.jsx("p", { className: "text-sm text-destructive", children: O })
    ] }),
    t || !t && !h && /* @__PURE__ */ e.jsx("div", { className: "text-sm py-2", children: o("No changes to apply") }),
    !t && h && /* @__PURE__ */ e.jsxs(ye, { className: " items-end gap-1 ", children: [
      /* @__PURE__ */ e.jsx(
        J,
        {
          size: "sm",
          variant: "outline",
          onClick: () => E(!1),
          children: o("Cancel")
        }
      ),
      /* @__PURE__ */ e.jsx(
        J,
        {
          size: "sm",
          loading: j,
          disabled: j,
          onClick: () => {
            let c = !1;
            if (n.getValues("name").trim() === "" && (n.setError("name", { message: "Release name is required" }), c = !0), u.size === 0 && s.tables.length === 0 && (f(
              "Please select at least one change to include in the release"
            ), c = !0), c)
              return;
            const x = {
              name: n.getValues("name"),
              description: n.getValues("description"),
              selectedFlowsIds: Array.from(u),
              projectId: H.getProjectId()
            };
            switch (i.type) {
              case y.GIT:
                m({ ...x, type: i.type });
                break;
              case y.PROJECT:
                m({
                  ...x,
                  targetProjectId: i.targetProjectId,
                  type: i.type
                });
                break;
              case y.ROLLBACK:
                m({
                  ...x,
                  projectReleaseId: i.projectReleaseId,
                  type: i.type
                });
                break;
            }
          },
          children: o("Apply Changes")
        }
      )
    ] })
  ] });
}, Pe = ({
  open: t,
  setOpen: i,
  refetch: s,
  plan: n,
  loading: E,
  defaultName: N = "",
  diffRequest: h
}) => {
  const m = me({
    resolver: xe(be),
    defaultValues: {
      name: N,
      description: ""
    }
  });
  return /* @__PURE__ */ e.jsx(
    he,
    {
      modal: !0,
      open: t,
      onOpenChange: (j) => {
        j && m.reset({
          name: N,
          description: ""
        }), i(j);
      },
      children: /* @__PURE__ */ e.jsxs(je, { className: "min-h-[100px] max-h-[850px] flex flex-col", children: [
        /* @__PURE__ */ e.jsx(ue, { className: "shrink-0", children: /* @__PURE__ */ e.jsx(ge, { children: h.type === y.GIT ? o("Create Git Release") : h.type === y.PROJECT ? o("Create Project Release") : `${o("Create Rollback to")} ${m.getValues("name")}` }) }),
        /* @__PURE__ */ e.jsx(
          Ie,
          {
            loading: E,
            diffRequest: h,
            plan: n,
            form: m,
            setOpen: i,
            refetch: s
          },
          `${E}`
        )
      ] })
    }
  );
}, ke = ({
  request: t,
  children: i,
  onSuccess: s,
  defaultName: n,
  ...E
}) => {
  const N = H.getProjectId(), { gitSync: h } = Ce.useGitSync(N, !Q(N)), [m, j] = p.useState(!1), [u, C] = p.useState(null), [O, f] = p.useState(null), { mutate: k } = te.useDiffRelease({
    onSuccess: (g) => {
      if ((!g.flows || g.flows.length === 0) && (!g.tables || g.tables.length === 0)) {
        C(null), f(null);
        return;
      }
      C(g), f(null);
    },
    onError: () => {
      C(null), f(null);
    }
  }), [T, w] = p.useState(!1), c = Q(h) && t.type === y.GIT, x = JSON.stringify(t), v = O === x;
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(
      J,
      {
        ...E,
        onClick: (g) => {
          g.stopPropagation(), g.preventDefault(), c ? w(!0) : (f(x), j(!0), k(t));
        },
        children: i
      }
    ),
    T ? /* @__PURE__ */ e.jsx(
      pe,
      {
        open: T,
        setOpen: w,
        showButton: !1
      }
    ) : m && /* @__PURE__ */ e.jsx(
      Pe,
      {
        open: m,
        loading: v,
        setOpen: j,
        refetch: s,
        plan: u,
        defaultName: n,
        diffRequest: t
      }
    )
  ] });
};
export {
  ke as A,
  Pe as C,
  Fe as F,
  y as P,
  _e as a,
  _ as p
};
