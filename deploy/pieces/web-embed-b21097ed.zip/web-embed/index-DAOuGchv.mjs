import { o as l, dh as K, dg as x, b as d, ak as y, s as o, eU as N, au as z, eV as E, a as R, w as M, e as A, H as P, d1 as U, d5 as _, d6 as L, as as F, ae as q, eW as h, a9 as H, cq as Q, d8 as w, c_ as I, a6 as a, D as C, av as f, j as t, co as W, ce as g, cp as r, et as k, dI as B, dJ as Y, dv as G, cY as J, aa as V, b4 as X, a3 as $, a4 as Z, a5 as ee, bB as T, Y as te } from "./mount-builder-CqIEWsZv.mjs";
import { D as se } from "./dashboard-page-header-BfLKPs1b.mjs";
import { C as ae } from "./copy-text-tooltip-CjpUgg8T.mjs";
import { P as oe } from "./piece-icon-from-name-CkNp4shA.mjs";
const ne = l({
  cursor: o().optional(),
  projectId: o(),
  scope: d(N).optional(),
  pieceName: o().optional(),
  displayName: o().optional(),
  status: x(d(y)),
  limit: K().optional()
});
l({
  externalId: o()
});
ne.omit({ projectId: !0 });
l({
  projectId: o()
});
l({
  cursor: o().optional(),
  limit: K().optional(),
  displayName: o().optional(),
  pieceName: o().optional(),
  scope: d(N).optional(),
  status: x(d(y)),
  projectIds: x(o()),
  ownerIds: x(o())
});
const ie = l({
  id: o(),
  displayName: o(),
  type: d(z)
});
E.extend({
  projects: R(ie)
});
const ce = l({
  id: o(),
  firstName: o(),
  lastName: o(),
  email: o()
});
l({
  data: R(ce),
  truncated: M()
});
const le = 1e3, b = {
  list(s) {
    return A.get(
      "/v1/platform-app-connections",
      s
    );
  },
  listOwners() {
    return A.get(
      "/v1/platform-app-connections/owners"
    );
  }
}, S = {
  list: (s) => ["platform-app-connections", s],
  owners: () => ["platform-app-connections", "owners"]
}, O = {
  useList: () => {
    const [s] = U();
    return P({
      queryKey: S.list(s.toString()),
      staleTime: 0,
      gcTime: 0,
      meta: { showErrorDialog: !0, loadSubsetOptions: {} },
      queryFn: () => {
        const p = s.get(_), n = s.get(L), c = s.getAll("status"), m = s.getAll("projectIds"), u = s.getAll("ownerIds");
        return b.list({
          cursor: p ?? void 0,
          limit: n ? parseInt(n) : void 0,
          displayName: s.get("displayName") ?? void 0,
          pieceName: s.get("pieceName") ?? void 0,
          status: c.length > 0 ? c : void 0,
          projectIds: m.length > 0 ? m : void 0,
          ownerIds: u.length > 0 ? u : void 0
        });
      }
    });
  },
  useOwners: () => P({
    queryKey: S.owners(),
    queryFn: () => b.listOwners()
  })
};
function je() {
  const { data: s, isLoading: p } = O.useList(), { data: n } = O.useOwners(), { data: c } = F.useAllPlatformProjects(), { pieces: m } = q.usePieces({}), u = [
    {
      type: "input",
      title: a("Name"),
      accessorKey: "displayName",
      icon: h
    },
    {
      type: "select",
      title: a("Status"),
      accessorKey: "status",
      icon: H,
      options: Object.values(y).map((e) => ({
        label: C.convertEnumToHumanReadable(e),
        value: e
      }))
    },
    {
      type: "select",
      title: a("Piece"),
      accessorKey: "pieceName",
      icon: Q,
      options: (m ?? []).map((e) => ({
        label: e.displayName,
        value: e.name
      }))
    },
    {
      type: "select",
      title: a("Project"),
      accessorKey: "projectIds",
      icon: w,
      options: (c ?? []).map((e) => ({
        label: f(e),
        value: e.id
      }))
    },
    {
      type: "select",
      title: a("Owner"),
      accessorKey: "ownerIds",
      icon: I,
      options: ((n == null ? void 0 : n.data) ?? []).map((e) => ({
        label: e.email,
        value: e.id
      }))
    }
  ], D = [
    {
      accessorKey: "displayName",
      size: 280,
      header: ({ column: e }) => /* @__PURE__ */ t.jsx(
        r,
        {
          column: e,
          title: a("Name"),
          icon: h
        }
      ),
      cell: ({ row: e }) => /* @__PURE__ */ t.jsx(
        ae,
        {
          title: a("External ID"),
          text: e.original.externalId || "",
          children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2 w-fit min-w-0", children: [
            /* @__PURE__ */ t.jsx(
              oe,
              {
                pieceName: e.original.pieceName,
                showTooltip: !1,
                size: "sm"
              }
            ),
            /* @__PURE__ */ t.jsx(g, { tooltipMessage: e.original.displayName, children: /* @__PURE__ */ t.jsx("span", { className: "truncate max-w-[160px] 2xl:max-w-[260px]", children: e.original.displayName }) })
          ] })
        }
      )
    },
    {
      accessorKey: "status",
      size: 130,
      header: ({ column: e }) => /* @__PURE__ */ t.jsx(
        r,
        {
          column: e,
          title: a("Status"),
          icon: Y
        }
      ),
      cell: ({ row: e }) => {
        const i = e.original.status, { variant: v, icon: j } = k.getStatusIcon(i);
        return /* @__PURE__ */ t.jsx(
          B,
          {
            icon: j,
            text: C.convertEnumToHumanReadable(i),
            variant: v
          }
        );
      }
    },
    {
      accessorKey: "projects",
      size: 220,
      header: ({ column: e }) => /* @__PURE__ */ t.jsx(
        r,
        {
          column: e,
          title: a("Project"),
          icon: w
        }
      ),
      cell: ({ row: e }) => /* @__PURE__ */ t.jsx(pe, { projects: e.original.projects })
    },
    {
      accessorKey: "scope",
      size: 120,
      header: ({ column: e }) => /* @__PURE__ */ t.jsx(
        r,
        {
          column: e,
          title: a("Scope"),
          icon: G
        }
      ),
      cell: ({ row: e }) => /* @__PURE__ */ t.jsx(re, { scope: e.original.scope })
    },
    {
      accessorKey: "owner",
      size: 200,
      header: ({ column: e }) => /* @__PURE__ */ t.jsx(r, { column: e, title: a("Owner"), icon: I }),
      cell: ({ row: e }) => {
        const i = e.original.owner;
        if (!i)
          return /* @__PURE__ */ t.jsx("span", { className: "text-muted-foreground", children: a("N/A") });
        const j = [i.firstName, i.lastName].filter(Boolean).join(" ") || i.email;
        return /* @__PURE__ */ t.jsx(g, { tooltipMessage: i.email, children: /* @__PURE__ */ t.jsx("span", { className: "truncate max-w-[180px]", children: j }) });
      }
    },
    {
      accessorKey: "updated",
      size: 150,
      header: ({ column: e }) => /* @__PURE__ */ t.jsx(
        r,
        {
          column: e,
          title: a("Connected At"),
          icon: V
        }
      ),
      cell: ({ row: e }) => /* @__PURE__ */ t.jsx(J, { date: new Date(e.original.updated) })
    }
  ];
  return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col w-full", children: [
    /* @__PURE__ */ t.jsx(
      se,
      {
        title: a("Connections"),
        description: a(
          "All app connections across every project on this platform"
        )
      }
    ),
    (n == null ? void 0 : n.truncated) && /* @__PURE__ */ t.jsx("div", { className: "px-6 pb-2 text-xs text-muted-foreground", children: a("Owner filter is limited to the first {count} owners", {
      count: le
    }) }),
    /* @__PURE__ */ t.jsx(
      W,
      {
        emptyStateTextTitle: a("No connections found"),
        emptyStateTextDescription: a(
          "Connections created in any project on this platform will appear here."
        ),
        emptyStateIcon: /* @__PURE__ */ t.jsx(h, { className: "size-14" }),
        columns: D,
        page: s,
        isLoading: p,
        filters: u
      }
    )
  ] });
}
const re = ({ scope: s }) => s === N.PLATFORM ? /* @__PURE__ */ t.jsxs(T, { variant: "accent", children: [
  /* @__PURE__ */ t.jsx(te, {}),
  a("Global")
] }) : /* @__PURE__ */ t.jsx(T, { variant: "outline", children: a("Project") }), pe = ({
  projects: s
}) => {
  if (s.length === 0)
    return /* @__PURE__ */ t.jsx("span", { className: "text-muted-foreground", children: a("N/A") });
  if (s.length === 1) {
    const n = s[0], c = f(n);
    return /* @__PURE__ */ t.jsx(X, { to: `/projects/${n.id}`, children: /* @__PURE__ */ t.jsx(g, { tooltipMessage: c, children: /* @__PURE__ */ t.jsx("span", { className: "truncate max-w-[200px] text-primary hover:underline", children: c }) }) });
  }
  const p = a("{count, plural, =1 {1 project} other {# projects}}", {
    count: s.length
  });
  return /* @__PURE__ */ t.jsxs($, { children: [
    /* @__PURE__ */ t.jsx(Z, { asChild: !0, children: /* @__PURE__ */ t.jsx("span", { className: "cursor-default underline decoration-dashed underline-offset-2", children: p }) }),
    /* @__PURE__ */ t.jsx(ee, { children: /* @__PURE__ */ t.jsx("ul", { className: "flex flex-col gap-1 max-w-[260px]", children: s.map((n) => /* @__PURE__ */ t.jsx("li", { className: "truncate", children: f(n) }, n.id)) }) })
  ] });
};
export {
  je as default
};
