import { e as h, H as p, j as e, bj as m, bk as u, bF as x, bl as f, bm as g, cf as j, bp as v, bq as k, cl as C, a6 as s, ac as b, be as l, bf as d, a1 as A, cm as w, cn as S } from "./mount-builder-CqIEWsZv.mjs";
import { C as I } from "./centered-page-C5JGBrkC.mjs";
import { H as N, M as R, C as P } from "./memory-stick-ZV4hBPBO.mjs";
const U = {
  getSystemHealthChecks() {
    return h.get("/v1/health/system");
  }
}, M = {
  all: ["system-health"]
}, q = {
  useSystemHealth: () => p({
    queryKey: M.all,
    queryFn: () => U.getSystemHealthChecks()
  })
}, T = ({
  id: a,
  title: n,
  icon: i,
  isChecked: r,
  message: o,
  loading: c,
  link: t
}) => /* @__PURE__ */ e.jsxs(m, { variant: "outline", children: [
  /* @__PURE__ */ e.jsx(u, { variant: "icon", children: c ? /* @__PURE__ */ e.jsx(x, {}) : i }),
  /* @__PURE__ */ e.jsxs(f, { children: [
    /* @__PURE__ */ e.jsxs(g, { children: [
      n,
      t && /* @__PURE__ */ e.jsx("a", { href: t, target: "_blank", rel: "noreferrer", children: /* @__PURE__ */ e.jsx(j, { size: 18 }) })
    ] }),
    /* @__PURE__ */ e.jsx(v, { className: "text-xs text-muted-foreground", children: c ? "..." : o })
  ] }),
  !c && /* @__PURE__ */ e.jsx(k, { children: r ? /* @__PURE__ */ e.jsxs("div", { className: "text-success-700 flex items-center gap-2", children: [
    /* @__PURE__ */ e.jsx(C, { size: 18 }),
    s("Passed")
  ] }) : /* @__PURE__ */ e.jsxs("div", { className: "text-destructive-700 flex items-center gap-2", children: [
    /* @__PURE__ */ e.jsx(b, { size: 18 }),
    s("Needs Attention")
  ] }) })
] }, a);
function F() {
  const { data: a } = l.useFlag(
    d.CURRENT_VERSION
  ), { data: n } = l.useFlag(
    d.LATEST_VERSION
  ), { data: i, isPending: r } = q.useSystemHealth(), o = A.useMemo(() => !a || !n ? !1 : w.gte(a, n), [a, n]), c = [
    {
      id: "version",
      title: s("Version Check"),
      icon: /* @__PURE__ */ e.jsx(S, {}),
      isChecked: o,
      message: /* @__PURE__ */ e.jsxs("div", { children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row gap-4 items-center", children: [
          /* @__PURE__ */ e.jsxs("span", { children: [
            /* @__PURE__ */ e.jsx("b", { children: s("Current Version") }),
            ": ",
            a || s("Unknown")
          ] }),
          /* @__PURE__ */ e.jsxs("span", { children: [
            /* @__PURE__ */ e.jsx("b", { children: s("Latest Version") }),
            ": ",
            n || s("Unknown")
          ] })
        ] }),
        /* @__PURE__ */ e.jsx("div", { className: "mt-2 flex flex-col gap-1", children: o ? null : /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
          /* @__PURE__ */ e.jsx("span", { children: s(
            "A new version is available. Upgrade now to enjoy the latest features, improvements, and bug fixes."
          ) }),
          /* @__PURE__ */ e.jsxs("span", { children: [
            s("See the"),
            " ",
            /* @__PURE__ */ e.jsx(
              "a",
              {
                className: "font-medium text-blue-600 dark:text-blue-500 hover:underline",
                href: "https://github.com/activepieces/activepieces/releases",
                target: "_blank",
                rel: "noopener noreferrer",
                children: s("release changelog")
              }
            ),
            "."
          ] })
        ] }) })
      ] }),
      link: "https://github.com/activepieces/activepieces/releases"
    },
    {
      id: "disk-size",
      title: s("Disk Size"),
      icon: /* @__PURE__ */ e.jsx(N, {}),
      isChecked: i == null ? void 0 : i.disk,
      message: /* @__PURE__ */ e.jsx("span", { children: i != null && i.disk ? s(
        "The server has sufficient disk space. At least 30GB of disk space is required for optimal operation."
      ) : s(
        "Insufficient disk space. A minimum of 30GB is required for Activepieces to function properly."
      ) }),
      loading: r,
      link: "https://www.activepieces.com/docs/install/configuration/hardware#technical-specifications"
    },
    {
      id: "ram",
      title: s("RAM"),
      icon: /* @__PURE__ */ e.jsx(R, {}),
      isChecked: i == null ? void 0 : i.ram,
      message: /* @__PURE__ */ e.jsx("span", { children: i != null && i.ram ? s(
        "The server meets the minimum RAM requirement. At least 4GB RAM is needed for stable performance."
      ) : s(
        "Insufficient RAM. A minimum of 4GB RAM is required for optimal operation."
      ) }),
      link: "https://www.activepieces.com/docs/install/configuration/hardware#technical-specifications",
      loading: r
    },
    {
      id: "cpu",
      title: s("CPU Cores"),
      icon: /* @__PURE__ */ e.jsx(P, {}),
      isChecked: i == null ? void 0 : i.cpu,
      message: /* @__PURE__ */ e.jsx("span", { children: i != null && i.cpu ? s(
        "The server has enough CPU resources. At least 1 CPU core is required to run Activepieces."
      ) : s(
        "Not enough CPU resources. At least 1 CPU core is necessary to operate Activepieces."
      ) }),
      link: "https://www.activepieces.com/docs/install/configuration/hardware#technical-specifications",
      loading: r
    }
  ];
  return /* @__PURE__ */ e.jsx(
    I,
    {
      title: s("System Health Status"),
      description: s("Check the status of your platform and its components"),
      children: /* @__PURE__ */ e.jsx("div", { className: "flex flex-col gap-4", children: c.map((t) => /* @__PURE__ */ e.jsx(
        T,
        {
          id: t.id,
          title: t.title,
          isChecked: t.isChecked ?? !1,
          message: t.message,
          loading: t.loading ?? !1,
          link: t.link,
          icon: t.icon
        },
        t.id
      )) })
    }
  );
}
export {
  F as default
};
