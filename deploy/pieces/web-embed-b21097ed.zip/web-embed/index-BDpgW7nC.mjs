import { s as d, o as g, dL as se, dM as I, a as E, dg as _, dN as je, b as be, dO as Ne, dP as M, df as ye, n as Ee, dQ as ve, _ as H, B as we, e as y, I as B, be as U, bf as W, H as te, bg as ne, aj as Se, b6 as q, g as w, c0 as A, c1 as D, j as e, bs as Ie, b_ as Ce, bt as Ae, bu as De, bv as ke, a6 as t, d4 as V, c2 as k, c3 as O, c4 as T, aQ as z, aX as Q, c8 as S, by as Oe, i as j, h as K, cP as ae, aJ as X, dR as Te, c5 as $, c9 as Le, dS as Fe, bB as Pe, ab as L, ac as Re, cl as _e, cb as ie, ch as re, ci as Me, bj as Ke, bk as He, bl as Ve, bm as ze, bp as Ge, D as Be, bq as Ue, b9 as We, ba as qe, az as Qe, bb as Xe, bc as $e, cc as Ye, Y as Je, bC as Ze, cf as es, aU as ss } from "./mount-builder-CqIEWsZv.mjs";
import { K as G } from "./key-m_VycdsK.mjs";
import { S as ts } from "./shield-check-DaZf4pFn.mjs";
import { L as ns } from "./list-checks-nm3lcqnf.mjs";
const as = 300, is = /* @__PURE__ */ new Set(["http:", "https:"]), rs = /^https?:\/\/\*\.[^*\s/?#]+$/, Y = d().max(as, "invalidEmbedOrigin").refine((s) => {
  const a = rs.test(s) ? s.replace("://*.", "://wildcard.") : s;
  try {
    const n = new URL(a);
    return is.has(n.protocol) && n.origin === a;
  } catch {
    return !1;
  }
}, "invalidEmbedOrigin");
g({
  base64: d(),
  mimetype: d()
});
g({
  name: d().regex(new RegExp(se)).min(1).max(100)
});
g({
  name: d().regex(new RegExp(se)).optional(),
  primaryColor: d().optional(),
  logoIcon: M.optional(),
  fullLogo: M.optional(),
  favIcon: M.optional(),
  filteredPieceNames: _(d()),
  filteredPieceBehavior: be(Ne).optional(),
  federatedAuthProviders: je.optional(),
  cloudAuthEnabled: I,
  googleAuthEnabled: I,
  emailAuthEnabled: I,
  allowedAuthDomains: _(d()),
  enforceAllowedAuthDomains: I,
  pinnedPieces: _(d()),
  allowedEmbedOrigins: E(Y).optional()
});
g({
  runIds: E(ye).optional(),
  createdAfter: d(),
  createdBefore: d()
});
g({
  email: d(),
  licenseKey: d()
});
g({
  platformId: d(),
  amountInUsd: Ee()
});
g({
  allowedEmbedOrigins: E(Y).min(1, "invalidEmbedOrigin")
});
g({
  allowedEmbedOrigins: E(d())
});
const os = g({
  displayName: d()
}), ls = 253;
var N = /* @__PURE__ */ ((s) => (s.PENDING_VERIFICATION = "PENDING_VERIFICATION", s.ACTIVE = "ACTIVE", s.FAILED = "FAILED", s))(N || {}), C = /* @__PURE__ */ ((s) => (s.HOSTNAME = "HOSTNAME", s.OWNERSHIP = "OWNERSHIP", s.SSL = "SSL", s))(C || {});
const ds = g({
  type: H([
    "CNAME",
    "TXT"
    /* TXT */
  ]),
  name: d(),
  value: d(),
  purpose: H([
    "HOSTNAME",
    "OWNERSHIP",
    "SSL"
    /* SSL */
  ])
});
g({
  ...we,
  platformId: d(),
  hostname: d(),
  status: H([
    "PENDING_VERIFICATION",
    "ACTIVE",
    "FAILED"
    /* FAILED */
  ]),
  cloudflareId: d(),
  verificationRecords: E(ds)
});
const oe = g({
  hostname: ve("invalidEmbedHostname").min(4, "invalidEmbedHostname").max(ls, "invalidEmbedHostname").refine((s) => s.includes("."), "invalidEmbedHostname").refine((s) => s === s.toLowerCase(), "invalidEmbedHostname")
}), le = {
  get() {
    return y.get("/v1/embed-subdomain");
  },
  upsert(s) {
    return y.post("/v1/embed-subdomain", s);
  }
}, J = {
  list() {
    return y.get("/v1/signing-keys");
  },
  delete(s) {
    return y.delete(`/v1/signing-keys/${s}`);
  },
  create(s) {
    return y.post("/v1/signing-keys/", s);
  }
}, de = {
  current: ["embed-subdomain"]
}, ce = {
  useEmbedSubdomain: () => {
    const { platform: s } = B.useCurrentPlatform(), { data: i } = U.useFlag(W.EDITION);
    return te({
      queryKey: de.current,
      queryFn: () => le.get(),
      enabled: s.plan.embeddingEnabled && i === ne.CLOUD,
      meta: { showErrorDialog: !0, loadSubsetOptions: {} },
      refetchInterval: (a) => {
        const n = a.state.data;
        return (n == null ? void 0 : n.status) === N.PENDING_VERIFICATION ? 1e4 : !1;
      }
    });
  },
  useCurrentEmbedSubdomain: () => {
    const { data: s, isLoading: i } = ce.useEmbedSubdomain();
    return { subdomain: s ?? void 0, isLoading: i };
  }
}, me = {
  useUpsert: () => {
    const s = Se();
    return q({
      mutationFn: (i) => le.upsert(i),
      onSuccess: () => {
        s.invalidateQueries({
          queryKey: de.current
        });
      }
    });
  }
}, cs = ({
  children: s,
  onCreate: i
}) => {
  var x, p, u;
  const [a, n] = w.useState(!1), [o, c] = w.useState(void 0), r = A({
    resolver: D(os)
  }), { mutate: l, isPending: m } = q({
    mutationFn: () => J.create(r.getValues()),
    onSuccess: (f) => {
      c(f), i();
    }
  });
  return /* @__PURE__ */ e.jsxs(
    Ie,
    {
      open: a,
      onOpenChange: (f) => {
        n(f), r.reset();
      },
      children: [
        /* @__PURE__ */ e.jsx(Ce, { asChild: !0, children: s }),
        /* @__PURE__ */ e.jsxs(Ae, { children: [
          /* @__PURE__ */ e.jsx(De, { children: /* @__PURE__ */ e.jsx(ke, { children: o ? t("Signing Key Created") : t("Create Signing Key") }) }),
          o && /* @__PURE__ */ e.jsx("div", { className: "p-4", children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-start gap-2", children: [
            /* @__PURE__ */ e.jsxs("span", { className: "text-md", children: [
              t(
                "Please save this secret key somewhere safe and accessible. For security reasons,"
              ),
              " ",
              /* @__PURE__ */ e.jsx("span", { className: "font-semibold", children: t(
                "you won't be able to view it again after closing this dialog."
              ) })
            ] }),
            /* @__PURE__ */ e.jsx(
              V,
              {
                useInput: !1,
                fileName: o.displayName,
                textToCopy: o.privateKey
              }
            )
          ] }) }),
          !o && /* @__PURE__ */ e.jsx(k, { ...r, children: /* @__PURE__ */ e.jsxs(
            "form",
            {
              className: "grid space-y-4",
              onSubmit: r.handleSubmit(() => l()),
              children: [
                /* @__PURE__ */ e.jsx(
                  O,
                  {
                    name: "displayName",
                    render: ({ field: f }) => /* @__PURE__ */ e.jsxs(T, { className: "grid space-y-4", children: [
                      /* @__PURE__ */ e.jsx(z, { htmlFor: "displayName", children: t("Name") }),
                      /* @__PURE__ */ e.jsx(
                        Q,
                        {
                          ...f,
                          required: !0,
                          id: "displayName",
                          className: "rounded-sm"
                        }
                      ),
                      /* @__PURE__ */ e.jsx(S, {})
                    ] })
                  }
                ),
                ((u = (p = (x = r == null ? void 0 : r.formState) == null ? void 0 : x.errors) == null ? void 0 : p.root) == null ? void 0 : u.serverError) && /* @__PURE__ */ e.jsx(S, { children: r.formState.errors.root.serverError.message })
              ]
            }
          ) }),
          /* @__PURE__ */ e.jsx(Oe, { children: o ? /* @__PURE__ */ e.jsx(
            j,
            {
              variant: "accent",
              onClick: () => {
                c(void 0), n(!1);
              },
              children: t("Done")
            }
          ) : /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
            /* @__PURE__ */ e.jsx(j, { variant: "outline", onClick: () => n(!1), children: t("Cancel") }),
            /* @__PURE__ */ e.jsx(
              j,
              {
                disabled: m || !r.formState.isValid,
                loading: m,
                onClick: () => l(),
                children: t("Save")
              }
            )
          ] }) })
        ] })
      ]
    }
  );
}, ms = {
  all: ["signing-keys"]
}, us = {
  useSigningKeys: () => te({
    queryKey: ms.all,
    gcTime: 0,
    staleTime: 0,
    queryFn: () => J.list()
  })
}, F = ({
  title: s,
  description: i,
  actions: a,
  children: n
}) => /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-8", children: [
  /* @__PURE__ */ e.jsxs("div", { className: "flex items-start justify-between gap-4", children: [
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1", children: [
      /* @__PURE__ */ e.jsx("h2", { className: "text-base font-medium", children: s }),
      /* @__PURE__ */ e.jsx("p", { className: "text-sm text-muted-foreground", children: i })
    ] }),
    a && /* @__PURE__ */ e.jsx("div", { className: "shrink-0", children: a })
  ] }),
  n
] }), xs = ({
  steps: s,
  completion: i,
  activeStepIndex: a,
  displayedIndex: n,
  onStepClick: o
}) => /* @__PURE__ */ e.jsx("ol", { className: "flex flex-col", children: s.map((c, r) => {
  const l = i[r], m = r === n, x = r > a, p = r === s.length - 1, u = c.icon;
  return /* @__PURE__ */ e.jsxs("li", { className: "flex gap-3", children: [
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center", children: [
      /* @__PURE__ */ e.jsx(
        "button",
        {
          type: "button",
          onClick: () => o(r),
          disabled: x,
          "aria-current": m ? "step" : void 0,
          className: K(
            "flex size-8 items-center justify-center transition-colors",
            l && "text-success-600",
            !l && m && "text-primary",
            !l && !m && !x && "text-muted-foreground hover:text-primary",
            x && "text-muted-foreground cursor-not-allowed opacity-60"
          ),
          children: /* @__PURE__ */ e.jsx(u, { className: "size-5" })
        }
      ),
      !p && /* @__PURE__ */ e.jsx(
        "div",
        {
          className: K(
            "w-px flex-1 my-2",
            l ? "bg-success-600" : "bg-border"
          )
        }
      )
    ] }),
    /* @__PURE__ */ e.jsxs(
      "button",
      {
        type: "button",
        onClick: () => o(r),
        disabled: x,
        className: K(
          "flex-1 text-left pt-1.5 pb-12 text-sm transition-colors",
          m && "font-medium text-foreground",
          !m && !x && "text-muted-foreground hover:text-foreground",
          x && "text-muted-foreground cursor-not-allowed opacity-60"
        ),
        children: [
          /* @__PURE__ */ e.jsxs("span", { className: "mr-1", children: [
            r + 1,
            "."
          ] }),
          c.title
        ]
      }
    )
  ] }, c.kind);
}) }), ue = (s) => Y.safeParse(s).success, gs = g({
  origins: E(d()).refine((s) => s.every(ue), "invalidEmbedOrigin")
}), hs = ({
  allowedEmbedOrigins: s
}) => {
  const { platform: i, refetch: a } = B.useCurrentPlatform(), { data: n } = U.useFlag(
    W.ALLOWED_EMBED_ORIGINS
  ), o = A({
    resolver: D(gs),
    defaultValues: { origins: s },
    mode: "onChange"
  }), { mutate: c, isPending: r } = q({
    mutationFn: async (l) => {
      await Te.update(
        { allowedEmbedOrigins: l.origins },
        i.id
      ), await a();
    },
    onSuccess: () => {
      X.success(t("Allowed domains updated"));
    },
    onError: () => ae()
  });
  return /* @__PURE__ */ e.jsx(
    F,
    {
      title: t("Add allowed domains"),
      description: t(
        "List the websites that can load your embed in an iframe. All other origins are blocked."
      ),
      children: /* @__PURE__ */ e.jsx(k, { ...o, children: /* @__PURE__ */ e.jsxs(
        "form",
        {
          onSubmit: o.handleSubmit((l) => c(l)),
          className: "flex flex-col gap-2",
          children: [
            /* @__PURE__ */ e.jsx(
              O,
              {
                name: "origins",
                render: ({ field: l }) => /* @__PURE__ */ e.jsxs(T, { children: [
                  /* @__PURE__ */ e.jsx($, { children: t("Allowed websites") }),
                  /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground", children: t(
                    "Press Enter or use a comma to add another, e.g. https://app.acme.com"
                  ) }),
                  /* @__PURE__ */ e.jsx(Le, { children: /* @__PURE__ */ e.jsx(
                    Fe,
                    {
                      value: l.value,
                      onChange: (m) => l.onChange([...m]),
                      validateItem: ue,
                      placeholder: "https://app.acme.com"
                    }
                  ) }),
                  /* @__PURE__ */ e.jsx(S, {})
                ] })
              }
            ),
            n && n.length > 0 && /* @__PURE__ */ e.jsxs("div", { className: "mt-2 flex flex-col gap-1.5", children: [
              /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground", children: t(
                "These origins are also allowed automatically (configured via AP_ALLOWED_EMBED_ORIGINS):"
              ) }),
              /* @__PURE__ */ e.jsx("div", { className: "flex flex-wrap gap-1.5", children: n.map((l) => /* @__PURE__ */ e.jsx(
                Pe,
                {
                  variant: "outline",
                  className: "font-mono text-xs",
                  children: l
                },
                l
              )) })
            ] }),
            /* @__PURE__ */ e.jsx("div", { className: "flex justify-end mt-6", children: /* @__PURE__ */ e.jsxs(j, { size: "sm", type: "submit", disabled: r, children: [
              r && /* @__PURE__ */ e.jsx(L, { className: "size-4 animate-spin mr-2" }),
              t("Save")
            ] }) })
          ]
        }
      ) })
    }
  );
}, ps = ({
  subdomain: s
}) => /* @__PURE__ */ e.jsx(
  F,
  {
    title: t("Verify the DNS records"),
    description: t(
      "Add these records at your DNS provider. We'll detect them automatically — this usually takes a few minutes."
    ),
    children: s && /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-4", children: [
      /* @__PURE__ */ e.jsx(fs, { status: s.status }),
      s.status === N.PENDING_VERIFICATION && /* @__PURE__ */ e.jsx(js, { records: s.verificationRecords })
    ] })
  }
), fs = ({ status: s }) => {
  switch (s) {
    case N.ACTIVE:
      return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 text-sm text-success-600", children: [
        /* @__PURE__ */ e.jsx(_e, { className: "size-4" }),
        t("DNS verified — your domain is ready")
      ] });
    case N.PENDING_VERIFICATION:
      return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 text-sm text-warning", children: [
        /* @__PURE__ */ e.jsx(L, { className: "size-4 animate-spin" }),
        t("Waiting for DNS")
      ] });
    case N.FAILED:
      return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 text-sm text-destructive", children: [
        /* @__PURE__ */ e.jsx(Re, { className: "size-4" }),
        t("Verification failed. Contact support to retry.")
      ] });
  }
}, js = ({
  records: s
}) => /* @__PURE__ */ e.jsx("div", { className: "flex flex-col gap-6 rounded-md border p-4", children: s.map((i, a) => /* @__PURE__ */ e.jsx(
  bs,
  {
    record: i
  },
  `${i.type}-${i.name}-${a}`
)) }), bs = ({ record: s }) => /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2", children: [
  /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ e.jsx("span", { className: "text-xs font-mono px-1.5 py-0.5 rounded bg-muted", children: s.type }),
    /* @__PURE__ */ e.jsx("span", { className: "text-xs text-muted-foreground", children: t(Ns[s.purpose]) })
  ] }),
  /* @__PURE__ */ e.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1.5 min-w-0", children: [
      /* @__PURE__ */ e.jsx(z, { className: "text-xs text-muted-foreground", children: t("Name") }),
      /* @__PURE__ */ e.jsx(V, { textToCopy: s.name, useInput: !0 })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1.5 min-w-0", children: [
      /* @__PURE__ */ e.jsx(z, { className: "text-xs text-muted-foreground", children: t("Value") }),
      /* @__PURE__ */ e.jsx(V, { textToCopy: s.value, useInput: !0 })
    ] })
  ] })
] }), Ns = {
  [C.HOSTNAME]: "embedPurposeHostname",
  [C.OWNERSHIP]: "embedPurposeOwnership",
  [C.SSL]: "embedPurposeSsl"
}, ys = ({
  subdomain: s
}) => /* @__PURE__ */ e.jsx(
  F,
  {
    title: t("Enter the embed URL"),
    description: t(
      "Pick the domain you'll embed in your website. It will be visible inside workflows."
    ),
    children: s ? /* @__PURE__ */ e.jsx(vs, { subdomain: s }) : /* @__PURE__ */ e.jsx(Es, {})
  }
), Es = () => {
  var o;
  const { mutate: s, isPending: i } = me.useUpsert(), a = A({
    resolver: D(oe),
    defaultValues: { hostname: "" },
    mode: "onChange"
  }), n = (c) => {
    a.clearErrors("root.serverError"), s(c, {
      onSuccess: () => {
        X.success(t("Domain saved"));
      },
      onError: (r) => {
        a.setError("root.serverError", {
          type: "manual",
          message: xe(r, t("Couldn't save domain"))
        });
      }
    });
  };
  return /* @__PURE__ */ e.jsx(k, { ...a, children: /* @__PURE__ */ e.jsxs(
    "form",
    {
      onSubmit: a.handleSubmit(n),
      className: "flex flex-col gap-3",
      children: [
        /* @__PURE__ */ e.jsx(
          O,
          {
            name: "hostname",
            render: ({ field: c }) => /* @__PURE__ */ e.jsxs(T, { children: [
              /* @__PURE__ */ e.jsx($, { children: t("Domain") }),
              /* @__PURE__ */ e.jsx(Q, { ...c, placeholder: "flows.acme.com" }),
              /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground", children: t("Use a subdomain you control, like flows.acme.com") }),
              /* @__PURE__ */ e.jsx(S, {})
            ] })
          }
        ),
        ((o = a.formState.errors.root) == null ? void 0 : o.serverError) && /* @__PURE__ */ e.jsx("p", { className: "text-sm text-destructive", children: a.formState.errors.root.serverError.message }),
        /* @__PURE__ */ e.jsx("div", { className: "flex justify-end mt-6", children: /* @__PURE__ */ e.jsxs(j, { type: "submit", size: "sm", disabled: i, children: [
          i && /* @__PURE__ */ e.jsx(L, { className: "size-4 animate-spin mr-2" }),
          t("Save domain")
        ] }) })
      ]
    }
  ) });
}, vs = ({ subdomain: s }) => {
  const [i, a] = w.useState(!1), [n, o] = w.useState(null), { mutateAsync: c, isPending: r } = me.useUpsert(), l = A({
    resolver: D(oe),
    defaultValues: { hostname: s.hostname },
    mode: "onChange"
  }), m = l.watch("hostname"), x = m.trim() !== s.hostname, p = async () => {
    o(null);
    try {
      await c({ hostname: m.trim() }), X.success(t("Domain updated"));
    } catch (u) {
      throw o(
        xe(u, t("Couldn't update domain"))
      ), u;
    }
  };
  return /* @__PURE__ */ e.jsx(k, { ...l, children: /* @__PURE__ */ e.jsxs(
    "form",
    {
      onSubmit: l.handleSubmit(() => a(!0)),
      className: "flex flex-col gap-3",
      children: [
        /* @__PURE__ */ e.jsx(
          O,
          {
            name: "hostname",
            render: ({ field: u }) => /* @__PURE__ */ e.jsxs(T, { children: [
              /* @__PURE__ */ e.jsx($, { children: t("Domain") }),
              /* @__PURE__ */ e.jsx(Q, { ...u, placeholder: "flows.acme.com" }),
              /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground", children: t("Use a subdomain you control, like flows.acme.com") }),
              /* @__PURE__ */ e.jsx(S, {})
            ] })
          }
        ),
        n && /* @__PURE__ */ e.jsx("p", { className: "text-sm text-destructive", children: n }),
        /* @__PURE__ */ e.jsx("div", { className: "flex justify-end mt-6", children: /* @__PURE__ */ e.jsxs(j, { type: "submit", size: "sm", disabled: !x || r, children: [
          r && /* @__PURE__ */ e.jsx(L, { className: "size-4 animate-spin mr-2" }),
          t("Update")
        ] }) }),
        /* @__PURE__ */ e.jsx(
          ie,
          {
            open: i,
            onOpenChange: a,
            title: t("Change embed domain?"),
            message: t(
              "Your current domain will stop working and you'll need to add new DNS records to verify the new one. Allowed websites and signing keys will be kept."
            ),
            warning: t("This action cannot be undone."),
            buttonText: t("Update domain"),
            entityName: t("domain"),
            mutationFn: p
          }
        )
      ]
    }
  ) });
};
function xe(s, i) {
  var a;
  if (y.isError(s)) {
    const n = (a = s.response) == null ? void 0 : a.data, o = n != null && n.params && "message" in n.params ? n.params.message : void 0;
    if (typeof o == "string" && o.length > 0)
      return o;
  }
  return s instanceof Error && s.message.length > 0 ? s.message : i;
}
const ws = ({
  signingKeys: s,
  isLoading: i,
  refetch: a
}) => /* @__PURE__ */ e.jsx(
  F,
  {
    title: t("Add signing keys"),
    description: t(
      "Generate a key to sign each embed session. We'll use the public half to verify your users at runtime."
    ),
    actions: /* @__PURE__ */ e.jsx(cs, { onCreate: a, children: /* @__PURE__ */ e.jsx(j, { size: "sm", children: t("New Signing Key") }) }),
    children: /* @__PURE__ */ e.jsx(
      Ss,
      {
        signingKeys: s,
        isLoading: i,
        refetch: a
      }
    )
  }
), Ss = ({
  signingKeys: s,
  isLoading: i,
  refetch: a
}) => i ? /* @__PURE__ */ e.jsx(re, { numberOfItems: 3, className: "w-full h-[72px]" }) : s.length === 0 ? /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center gap-3 py-12 text-muted-foreground", children: [
  /* @__PURE__ */ e.jsx(G, { className: "size-10" }),
  /* @__PURE__ */ e.jsx("p", { className: "text-sm", children: t("No signing keys yet") })
] }) : /* @__PURE__ */ e.jsx(Me, { className: "gap-2", children: s.map((n) => /* @__PURE__ */ e.jsxs(
  Ke,
  {
    variant: "outline",
    size: "sm",
    className: "items-center",
    children: [
      /* @__PURE__ */ e.jsx(He, { variant: "icon", children: /* @__PURE__ */ e.jsx(G, {}) }),
      /* @__PURE__ */ e.jsxs(Ve, { className: "gap-0", children: [
        /* @__PURE__ */ e.jsx(ze, { className: "flex items-center gap-2", children: n.displayName }),
        /* @__PURE__ */ e.jsxs(Ge, { className: "text-xs", children: [
          " " + t("Created"),
          " ",
          Be.formatDateToAgo(new Date(n.created)),
          /* @__PURE__ */ e.jsx("br", {}),
          /* @__PURE__ */ e.jsxs("span", { className: "text-xs text-muted-foreground", children: [
            "kid: ",
            n.id
          ] })
        ] })
      ] }),
      /* @__PURE__ */ e.jsx(Ue, { children: /* @__PURE__ */ e.jsxs(We, { modal: !0, children: [
        /* @__PURE__ */ e.jsx(qe, { asChild: !0, children: /* @__PURE__ */ e.jsx(j, { variant: "ghost", size: "sm", className: "size-8 p-0", children: /* @__PURE__ */ e.jsx(Qe, { className: "size-4" }) }) }),
        /* @__PURE__ */ e.jsx(Xe, { align: "end", children: /* @__PURE__ */ e.jsx(
          ie,
          {
            title: t("Delete Signing Key"),
            message: t(
              "Deleting this signing key will invalidate any tokens signed with it."
            ),
            entityName: t("Signing Key"),
            buttonText: t("Delete"),
            mutationFn: async () => {
              await J.delete(n.id), a();
            },
            onError: () => ae(),
            children: /* @__PURE__ */ e.jsxs(
              $e,
              {
                className: "text-destructive focus:text-destructive",
                onSelect: (o) => o.preventDefault(),
                children: [
                  /* @__PURE__ */ e.jsx(Ye, { className: "size-4 mr-2 text-destructive" }),
                  t("Delete Signing Key")
                ]
              }
            )
          }
        ) })
      ] }) })
    ]
  },
  n.id
)) }), Is = () => {
  const { platform: s } = B.useCurrentPlatform(), { data: i } = U.useFlag(W.EDITION), a = i === ne.CLOUD, { subdomain: n, isLoading: o } = ce.useCurrentEmbedSubdomain(), {
    data: c,
    isLoading: r,
    refetch: l
  } = us.useSigningKeys(), m = (c == null ? void 0 : c.data) ?? [], x = a && o || r, p = s.allowedEmbedOrigins ?? [], u = {
    hostname: {
      kind: "hostname",
      title: t("Enter the embed URL"),
      icon: Je
    },
    dns: {
      kind: "dns",
      title: t("Verify the DNS records"),
      icon: ts
    },
    "allowed-domains": {
      kind: "allowed-domains",
      title: t("Add allowed domains"),
      icon: ns
    },
    "signing-keys": {
      kind: "signing-keys",
      title: t("Add signing keys"),
      icon: G
    }
  }, f = a ? [
    u.hostname,
    u.dns,
    u["allowed-domains"],
    u["signing-keys"]
  ] : [u["allowed-domains"], u["signing-keys"]], ge = {
    hostname: !!n,
    dns: (n == null ? void 0 : n.status) === N.ACTIVE,
    "allowed-domains": p.length > 0,
    "signing-keys": m.length > 0
  }, P = f.map((b) => ge[b.kind]), Z = P.findIndex((b) => !b), v = Z === -1 ? P.length - 1 : Z, [R, he] = w.useState(null), ee = R !== null && R < v ? R : v, pe = (b) => {
    b > v || he(b === v ? null : b);
  }, fe = a ? t(
    "Run embedded workflows under your own domain — four quick steps to get set up."
  ) : t(
    "Configure who can embed your workflows and create the signing keys to authenticate sessions."
  ), h = f[ee];
  return /* @__PURE__ */ e.jsx(
    Ze,
    {
      featureKey: "SIGNING_KEYS",
      locked: !s.plan.embeddingEnabled,
      lockTitle: t("Unlock Embedding Through JS SDK"),
      lockDescription: t(
        "Enable signing keys to access embedding functionalities."
      ),
      children: /* @__PURE__ */ e.jsxs("div", { className: "w-full max-w-4/5 2xl:max-w-6xl mx-auto py-6", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1", children: [
          /* @__PURE__ */ e.jsx("h1", { className: "text-xl font-medium", children: t("Embed Onboarding") }),
          /* @__PURE__ */ e.jsxs("div", { className: "text-sm text-muted-foreground", children: [
            fe,
            /* @__PURE__ */ e.jsx(
              j,
              {
                variant: "link",
                size: "sm",
                className: "h-auto p-0 mt-0.5 ml-1",
                asChild: !0,
                children: /* @__PURE__ */ e.jsxs(
                  "a",
                  {
                    href: "https://www.activepieces.com/docs/embedding/overview",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: [
                      t("Read more"),
                      /* @__PURE__ */ e.jsx(es, { className: "size-3" })
                    ]
                  }
                )
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ e.jsx(ss, { className: "mt-4 mb-12" }),
        /* @__PURE__ */ e.jsxs("div", { className: "grid grid-cols-[16rem_1fr] gap-16", children: [
          /* @__PURE__ */ e.jsx(
            xs,
            {
              steps: f,
              completion: P,
              activeStepIndex: v,
              displayedIndex: ee,
              onStepClick: pe
            }
          ),
          /* @__PURE__ */ e.jsx("div", { className: "min-w-0", children: x ? /* @__PURE__ */ e.jsx(re, { numberOfItems: 3, className: "w-full h-[72px]" }) : (h == null ? void 0 : h.kind) === "hostname" ? /* @__PURE__ */ e.jsx(ys, { subdomain: n }) : (h == null ? void 0 : h.kind) === "dns" ? /* @__PURE__ */ e.jsx(ps, { subdomain: n }) : (h == null ? void 0 : h.kind) === "allowed-domains" ? /* @__PURE__ */ e.jsx(hs, { allowedEmbedOrigins: p }) : (h == null ? void 0 : h.kind) === "signing-keys" ? /* @__PURE__ */ e.jsx(
            ws,
            {
              signingKeys: m,
              isLoading: r,
              refetch: l
            }
          ) : null })
        ] })
      ] })
    }
  );
};
Is.displayName = "EmbedPage";
export {
  Is as EmbedPage
};
