import { g as w, at as W, c0 as P, c1 as E, b6 as R, e as q, eH as U, bU as I, j as e, bs as z, b_ as M, bt as L, bu as O, bv as K, a6 as a, c2 as V, c3 as m, c4 as d, aQ as p, aX as j, c8 as u, aI as A, eI as B, by as H, i as T, o as $, eJ as _, a as D, s as g, eK as J, u as G, I as X, d1 as Y, H as Z, eL as ee, aJ as se, cb as ae, cc as te, cj as re, ck as le, bC as oe, co as ie, a3 as ne, a4 as ce, aW as me, a5 as de, c7 as k, cp as v, c$ as pe, cY as ue, aa as ge, eM as he, cq as xe } from "./mount-builder-CqIEWsZv.mjs";
import { D as je } from "./dashboard-page-header-BfLKPs1b.mjs";
import { F as ye } from "./file-text-DULCzR4r.mjs";
const fe = $({
  displayName: g().min(1, a("Name is required")),
  summary: g(),
  description: g(),
  blogUrl: g(),
  template: _,
  tags: D(J).optional(),
  categories: D(g()).optional()
}), Ne = ({
  children: b,
  onDone: S
}) => {
  const [l, y] = w.useState(!1), { data: i } = W.useCurrentUser(), r = P({
    defaultValues: {
      displayName: "",
      blogUrl: "",
      summary: "",
      description: "",
      tags: [],
      categories: [],
      template: void 0
    },
    resolver: E(fe)
  }), { mutate: f, isPending: x } = R({
    mutationKey: ["create-template"],
    mutationFn: () => {
      const s = r.getValues(), h = i ? `${i.firstName} ${i.lastName}` : "Unknown User", N = {
        ...s.template,
        displayName: s.displayName,
        valid: s.template.valid ?? !0
      };
      return U.create({
        flows: [N],
        type: I.CUSTOM,
        name: s.displayName,
        summary: s.summary,
        description: s.description,
        tags: s.tags || [],
        blogUrl: s.blogUrl,
        metadata: null,
        author: h,
        categories: s.categories || []
      });
    },
    onSuccess: () => {
      S(), y(!1);
    },
    onError: (s) => {
      q.isError(s) && r.setError("template", {
        message: s.message
      });
    }
  }), C = () => {
    if (!r.getValues().template) {
      r.setError("template", {
        message: a("Template is required")
      });
      return;
    }
    f();
  };
  return /* @__PURE__ */ e.jsxs(
    z,
    {
      open: l,
      onOpenChange: (s) => {
        y(s), r.reset();
      },
      children: [
        /* @__PURE__ */ e.jsx(M, { asChild: !0, children: b }),
        /* @__PURE__ */ e.jsxs(L, { children: [
          /* @__PURE__ */ e.jsx(O, { children: /* @__PURE__ */ e.jsx(K, { children: a("Create New Template") }) }),
          /* @__PURE__ */ e.jsx(V, { ...r, children: /* @__PURE__ */ e.jsxs("form", { className: "grid space-y-4", onSubmit: (s) => s.preventDefault(), children: [
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "displayName",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "name", showRequiredIndicator: !0, children: a("Name") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      ...s,
                      required: !0,
                      id: "name",
                      placeholder: a("Template Name"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "summary",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "summary", children: a("Summary") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      ...s,
                      id: "summary",
                      placeholder: a("Template Summary"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "description",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "description", children: a("Description") }),
                  /* @__PURE__ */ e.jsx(
                    A,
                    {
                      ...s,
                      required: !0,
                      id: "description",
                      className: "rounded-sm",
                      placeholder: a("Template Description")
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "blogUrl",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "blogUrl", children: a("Blog URL") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      ...s,
                      required: !0,
                      id: "blogUrl",
                      placeholder: a("Template Blog URL"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "template",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "template", showRequiredIndicator: !0, children: a("Template") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      type: "file",
                      accept: ".json",
                      onChange: (h) => {
                        h.target.files && h.target.files[0].text().then((N) => {
                          const t = B.extractFlow(N);
                          t ? s.onChange(t) : r.setError("template", {
                            message: a("Invalid JSON")
                          });
                        });
                      },
                      required: !0,
                      id: "template",
                      placeholder: a("Template"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            )
          ] }) }),
          /* @__PURE__ */ e.jsxs(H, { children: [
            /* @__PURE__ */ e.jsx(
              T,
              {
                variant: "outline",
                onClick: (s) => {
                  s.stopPropagation(), s.preventDefault(), y(!1);
                },
                children: a("Cancel")
              }
            ),
            /* @__PURE__ */ e.jsx(
              T,
              {
                disabled: x,
                loading: x,
                onClick: (s) => {
                  r.handleSubmit(C)(s);
                },
                children: a("Save")
              }
            )
          ] })
        ] })
      ]
    }
  );
}, Te = $({
  displayName: g().min(1, a("Name is required")),
  summary: g(),
  description: g(),
  blogUrl: g(),
  template: G().optional(),
  tags: D(J).optional(),
  categories: D(g()).optional()
}), be = ({
  children: b,
  onDone: S,
  template: l
}) => {
  const [y, i] = w.useState(!1), r = P({
    defaultValues: {
      displayName: l.name,
      summary: l.summary || "",
      blogUrl: l.blogUrl || "",
      description: l.description,
      tags: l.tags || [],
      categories: l.categories || [],
      template: void 0
    },
    resolver: E(Te)
  }), { mutate: f, isPending: x } = R({
    mutationKey: ["update-template", l.id],
    mutationFn: () => {
      const s = r.getValues();
      return U.update(l.id, {
        name: s.displayName,
        summary: s.summary,
        description: s.description,
        tags: s.tags,
        blogUrl: s.blogUrl,
        metadata: l.metadata,
        categories: s.categories || [],
        flows: s.template ? [
          {
            ...s.template,
            displayName: s.displayName,
            valid: s.template.valid ?? !0
          }
        ] : void 0
      });
    },
    onSuccess: () => {
      S(), i(!1);
    },
    onError: (s) => {
      q.isError(s) && r.setError("template", {
        message: s.message
      });
    }
  }), C = () => {
    f();
  };
  return /* @__PURE__ */ e.jsxs(
    z,
    {
      open: y,
      onOpenChange: (s) => {
        i(s), s || r.reset();
      },
      children: [
        /* @__PURE__ */ e.jsx(M, { asChild: !0, children: b }),
        /* @__PURE__ */ e.jsxs(L, { children: [
          /* @__PURE__ */ e.jsx(O, { children: /* @__PURE__ */ e.jsx(K, { children: a("Update Template") }) }),
          /* @__PURE__ */ e.jsx(V, { ...r, children: /* @__PURE__ */ e.jsxs("form", { className: "grid space-y-4", onSubmit: (s) => s.preventDefault(), children: [
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "displayName",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "name", showRequiredIndicator: !0, children: a("Name") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      ...s,
                      required: !0,
                      id: "name",
                      placeholder: a("Template Name"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "summary",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "summary", children: a("Summary") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      ...s,
                      id: "summary",
                      placeholder: a("Template Summary"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "description",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "description", children: a("Description") }),
                  /* @__PURE__ */ e.jsx(
                    A,
                    {
                      ...s,
                      required: !0,
                      id: "description",
                      className: "rounded-sm",
                      placeholder: a("Template Description")
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "blogUrl",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "blogUrl", children: a("Blog URL") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      ...s,
                      required: !0,
                      id: "blogUrl",
                      placeholder: a("Template Blog URL"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              m,
              {
                name: "template",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(d, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(p, { htmlFor: "template", children: a("Template") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      type: "file",
                      accept: ".json",
                      onChange: (h) => {
                        h.target.files && h.target.files[0].text().then((N) => {
                          const t = B.extractFlow(N);
                          t ? s.onChange(t) : r.setError("template", {
                            message: a("Invalid JSON")
                          });
                        });
                      },
                      id: "template",
                      placeholder: a("Template"),
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(u, {})
                ] })
              }
            )
          ] }) }),
          /* @__PURE__ */ e.jsxs(H, { children: [
            /* @__PURE__ */ e.jsx(
              T,
              {
                variant: "outline",
                onClick: (s) => {
                  s.stopPropagation(), s.preventDefault(), i(!1);
                },
                children: a("Cancel")
              }
            ),
            /* @__PURE__ */ e.jsx(
              T,
              {
                disabled: x,
                loading: x,
                onClick: (s) => {
                  r.handleSubmit(C)(s);
                },
                children: a("Save")
              }
            )
          ] })
        ] })
      ]
    }
  );
}, De = () => {
  const { platform: b } = X.useCurrentPlatform(), [S] = Y(), { data: l, isLoading: y, refetch: i } = Z({
    queryKey: ["templates", S.toString()],
    staleTime: 0,
    meta: { showErrorDialog: !0, loadSubsetOptions: {} },
    queryFn: () => U.list({
      type: I.CUSTOM
    })
  }), [r, f] = w.useState([]), x = ee.useBulkDeleteTemplates({
    onSuccess: () => {
      i(), se.success(a("Templates deleted successfully"), {
        duration: 3e3
      });
    }
  }), C = [
    {
      id: "select",
      accessorKey: "select",
      size: 40,
      minSize: 40,
      maxSize: 40,
      header: ({ table: t }) => /* @__PURE__ */ e.jsx(
        k,
        {
          checked: t.getRowModel().rows.length > 0 && t.getRowModel().rows.every((n) => n.getIsSelected()),
          onCheckedChange: (n) => {
            t.toggleAllRowsSelected(!!n);
            const o = t.getRowModel().rows.map((c) => c.original);
            f(n ? o : []);
          }
        }
      ),
      cell: ({ row: t }) => {
        const n = r.some(
          (o) => o.id === t.original.id
        );
        return /* @__PURE__ */ e.jsx(
          k,
          {
            checked: n,
            onCheckedChange: (o) => {
              let c = [...r];
              o ? c.some(
                (Q) => Q.id === t.original.id
              ) || c.push(t.original) : c = c.filter(
                (F) => F.id !== t.original.id
              ), f(c), t.toggleSelected(!!o);
            }
          }
        );
      }
    },
    {
      accessorKey: "name",
      size: 200,
      header: ({ column: t }) => /* @__PURE__ */ e.jsx(v, { column: t, title: a("Name"), icon: pe }),
      cell: ({ row: t }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: t.original.name })
    },
    {
      accessorKey: "createdAt",
      size: 150,
      header: ({ column: t }) => /* @__PURE__ */ e.jsx(
        v,
        {
          column: t,
          title: a("Created"),
          icon: ge
        }
      ),
      cell: ({ row: t }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(ue, { date: new Date(t.original.created) }) })
    },
    {
      accessorKey: "pieces",
      size: 100,
      header: ({ column: t }) => /* @__PURE__ */ e.jsx(
        v,
        {
          column: t,
          title: a("Pieces"),
          icon: xe
        }
      ),
      cell: ({ row: t }) => {
        var o, c;
        const n = (c = (o = t.original.flows) == null ? void 0 : o[0]) == null ? void 0 : c.trigger;
        return n ? /* @__PURE__ */ e.jsx(he, { trigger: n, maxNumberOfIconsToShow: 2 }) : null;
      }
    }
  ], s = w.useMemo(
    () => [
      {
        render: (t, n) => /* @__PURE__ */ e.jsx("div", { onClick: (o) => o.stopPropagation(), children: /* @__PURE__ */ e.jsx(
          ae,
          {
            title: a("Delete Templates"),
            message: a(
              "Are you sure you want to delete the selected templates?"
            ),
            entityName: a("Templates"),
            mutationFn: async () => {
              await x.mutateAsync(
                r.map((o) => o.id)
              ), n(), f([]);
            },
            children: r.length > 0 && /* @__PURE__ */ e.jsxs(
              T,
              {
                variant: "ghost",
                size: "sm",
                className: "text-destructive hover:text-destructive",
                children: [
                  /* @__PURE__ */ e.jsx(te, { className: "mr-1 w-4" }),
                  `${a("Delete")} (${r.length})`
                ]
              }
            )
          }
        ) })
      }
    ],
    [r, x]
  ), h = w.useMemo(
    () => [
      /* @__PURE__ */ e.jsx(Ne, { onDone: () => i(), children: /* @__PURE__ */ e.jsx(re, { icon: le, iconSize: 16, size: "sm", children: a("New Template") }) }, "new-template")
    ],
    [i]
  ), N = b.plan.manageTemplatesEnabled;
  return /* @__PURE__ */ e.jsx(
    oe,
    {
      featureKey: "TEMPLATES",
      locked: !N,
      lockTitle: a("Unlock Templates"),
      lockDescription: a(
        "Convert the most common automations into reusable templates 1 click away from your users"
      ),
      lockVideoUrl: "/ap-cdn/videos/showcase/templates.mp4",
      children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col w-full", children: [
        /* @__PURE__ */ e.jsx(
          je,
          {
            description: a(
              "Convert the most common automations into reusable templates"
            ),
            title: a("Templates")
          }
        ),
        /* @__PURE__ */ e.jsx(
          ie,
          {
            emptyStateTextTitle: a("No templates found"),
            emptyStateTextDescription: a(
              "Create a template for your user to inspire them"
            ),
            emptyStateIcon: /* @__PURE__ */ e.jsx(ye, { className: "size-14" }),
            columns: C,
            page: l,
            hidePagination: !0,
            isLoading: y,
            bulkActions: s,
            toolbarButtons: h,
            actions: [
              (t) => /* @__PURE__ */ e.jsx("div", { className: "flex items-end justify-end", children: /* @__PURE__ */ e.jsxs(ne, { children: [
                /* @__PURE__ */ e.jsx(ce, { children: /* @__PURE__ */ e.jsx(
                  be,
                  {
                    onDone: () => i(),
                    template: t,
                    children: /* @__PURE__ */ e.jsx(T, { variant: "ghost", className: "size-8 p-0", children: /* @__PURE__ */ e.jsx(me, { className: "size-4" }) })
                  }
                ) }),
                /* @__PURE__ */ e.jsx(de, { side: "bottom", children: a("Edit template") })
              ] }) })
            ]
          }
        )
      ] })
    }
  );
};
export {
  De as PlatformTemplatesPage
};
