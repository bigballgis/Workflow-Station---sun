import { c as Q, I as F, cN as L, j as e, bs as $, bt as G, bu as J, bv as X, a6 as t, ch as de, cO as ue, at as Y, aj as me, as as w, aJ as Z, cP as he, c0 as pe, cQ as je, c2 as xe, cR as be, c3 as R, c4 as U, aQ as M, aX as z, c8 as O, cS as ge, cT as fe, cU as ye, by as V, i as C, g as j, cV as K, bw as Ce, cW as Ne, bi as Pe, cp as T, cr as ve, cX as ke, cY as Ee, aa as Se, au as v, cZ as De, c_ as Ie, c$ as Ae, d0 as Te, cd as we, a_ as Re, d1 as Ue, d2 as Me, a3 as _, a4 as H, c7 as B, a5 as W, cb as Oe, cc as Fe, d3 as Le, bC as ze, co as Ke, a9 as q, D as _e, cn as He, aW as Be } from "./mount-builder-CqIEWsZv.mjs";
import { D as We } from "./dashboard-page-header-BfLKPs1b.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const qe = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  ["path", { d: "M15 8h6", key: "8ybuxh" }],
  [
    "path",
    {
      d: "M16.243 3.757A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673A9.4 9.4 0 0 1 18.667 12",
      key: "bdwj86"
    }
  ]
], Qe = Q("bell-minus", qe);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const $e = [
  ["path", { d: "M10.268 21a2 2 0 0 0 3.464 0", key: "vwvbt9" }],
  ["path", { d: "M15 8h6", key: "8ybuxh" }],
  ["path", { d: "M18 5v6", key: "g5ayrv" }],
  [
    "path",
    {
      d: "M20.002 14.464a9 9 0 0 0 .738.863A1 1 0 0 1 20 17H4a1 1 0 0 1-.74-1.673C4.59 13.956 6 12.499 6 8a6 6 0 0 1 8.75-5.332",
      key: "1abcvy"
    }
  ]
], Ge = Q("bell-plus", $e);
function Je({
  open: o,
  onClose: r,
  projectId: s,
  initialValues: c
}) {
  const { platform: u } = F.useCurrentPlatform(), l = u.plan.globalConnectionsEnabled, { data: x, isLoading: f } = L.useGlobalConnections({
    request: { limit: 9999 },
    extraKeys: []
  }), N = (x == null ? void 0 : x.data) ?? [];
  return /* @__PURE__ */ e.jsx($, { open: o, onOpenChange: r, children: /* @__PURE__ */ e.jsxs(G, { className: "max-w-md w-full", children: [
    /* @__PURE__ */ e.jsxs(J, { children: [
      " ",
      /* @__PURE__ */ e.jsxs(X, { children: [
        t("Edit"),
        " ",
        c == null ? void 0 : c.projectName
      ] })
    ] }),
    !l || !f ? /* @__PURE__ */ e.jsx(
      Xe,
      {
        onClose: r,
        projectId: s,
        initialValues: c,
        globalConnections: N,
        globalConnectionsEnabled: l
      }
    ) : /* @__PURE__ */ e.jsx(de, { numberOfItems: 3, className: "h-10" })
  ] }) });
}
const Xe = ({
  onClose: o,
  projectId: r,
  initialValues: s,
  globalConnections: c,
  globalConnectionsEnabled: u
}) => {
  const { checkAccess: l } = ue(), { platform: x } = F.useCurrentPlatform(), f = Y.getCurrentUserPlatformRole(), N = me(), p = c.filter((i) => i.projectIds.includes(r)).map((i) => i.externalId), { mutate: m, isPending: b } = w.useUpdateProject(
    () => {
      N.invalidateQueries({
        queryKey: L.getGlobalConnectionsQueryKey([])
      }), Z.success(t("Your changes have been saved."), {
        duration: 3e3
      }), o();
    },
    (i) => {
      console.error(i), he();
    }
  ), k = pe({
    defaultValues: {
      displayName: s == null ? void 0 : s.projectName,
      externalId: s == null ? void 0 : s.externalId,
      globalConnectionExternalIds: p
    },
    disabled: l(je.WRITE_PROJECT) === !1
  });
  return /* @__PURE__ */ e.jsx(xe, { ...k, children: /* @__PURE__ */ e.jsxs(
    "form",
    {
      className: "space-y-4",
      onSubmit: k.handleSubmit((i) => {
        m({
          projectId: r,
          request: {
            displayName: i.displayName,
            externalId: i.externalId,
            globalConnectionExternalIds: i.globalConnectionExternalIds
          }
        });
      }),
      children: [
        u && /* @__PURE__ */ e.jsx(be, {}),
        /* @__PURE__ */ e.jsx(
          R,
          {
            name: "displayName",
            render: ({ field: i }) => /* @__PURE__ */ e.jsxs(U, { children: [
              /* @__PURE__ */ e.jsx(M, { htmlFor: "displayName", children: t("Project Name") }),
              /* @__PURE__ */ e.jsx(
                z,
                {
                  ...i,
                  id: "displayName",
                  placeholder: t("Project Name"),
                  className: "rounded-sm"
                }
              ),
              /* @__PURE__ */ e.jsx(O, {})
            ] })
          }
        ),
        x.plan.embeddingEnabled && f === ge.ADMIN && /* @__PURE__ */ e.jsx(
          R,
          {
            name: "externalId",
            render: ({ field: i }) => /* @__PURE__ */ e.jsxs(U, { children: [
              /* @__PURE__ */ e.jsx(M, { htmlFor: "externalId", children: t("External ID") }),
              /* @__PURE__ */ e.jsx(fe, { children: t("Used to identify the project based on your SaaS ID") }),
              /* @__PURE__ */ e.jsx(
                z,
                {
                  ...i,
                  id: "externalId",
                  placeholder: t("org-3412321"),
                  className: "rounded-sm"
                }
              ),
              /* @__PURE__ */ e.jsx(O, {})
            ] })
          }
        ),
        u && /* @__PURE__ */ e.jsx(
          R,
          {
            name: "globalConnectionExternalIds",
            render: ({ field: i }) => /* @__PURE__ */ e.jsxs(U, { children: [
              /* @__PURE__ */ e.jsx(M, { children: t("Global Connections") }),
              /* @__PURE__ */ e.jsx(
                ye,
                {
                  placeholder: t("Select global connections"),
                  options: c.map((E) => ({
                    value: E.externalId,
                    label: E.displayName
                  })),
                  loading: !1,
                  onChange: (E) => {
                    i.onChange(E ?? []);
                  },
                  initialValues: i.value ?? [],
                  showDeselect: (i.value ?? []).length > 0
                }
              ),
              /* @__PURE__ */ e.jsx(O, {})
            ] })
          }
        ),
        /* @__PURE__ */ e.jsxs(V, { className: "justify-end mt-6", children: [
          /* @__PURE__ */ e.jsx(C, { type: "button", variant: "outline", onClick: o, children: t("Cancel") }),
          /* @__PURE__ */ e.jsx(C, { type: "submit", disabled: b, loading: b, children: t("Save") })
        ] })
      ]
    }
  ) });
}, Ye = ({
  selectedProjects: o,
  resetSelection: r
}) => {
  const { data: s } = Y.useCurrentUser(), [c, u] = j.useState(!1), { mutate: l, isPending: x } = K.useBulkSubscribeAlerts(), { mutate: f, isPending: N } = K.useBulkUnsubscribeAlerts(), p = s == null ? void 0 : s.email;
  if (!p || o.length === 0)
    return null;
  const m = x || N, b = () => {
    l({ email: p, projects: o }), r();
  }, k = () => {
    u(!1), f({ email: p, projects: o }), r();
  };
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsxs(
      C,
      {
        variant: "ghost",
        size: "sm",
        disabled: m,
        onClick: b,
        children: [
          /* @__PURE__ */ e.jsx(Ge, { className: "mr-1 w-4" }),
          t("Subscribe to alerts")
        ]
      }
    ),
    /* @__PURE__ */ e.jsxs(
      C,
      {
        variant: "ghost",
        size: "sm",
        disabled: m,
        onClick: () => u(!0),
        children: [
          /* @__PURE__ */ e.jsx(Qe, { className: "mr-1 w-4" }),
          t("Unsubscribe from alerts")
        ]
      }
    ),
    /* @__PURE__ */ e.jsx(
      $,
      {
        open: c,
        onOpenChange: u,
        children: /* @__PURE__ */ e.jsxs(G, { children: [
          /* @__PURE__ */ e.jsxs(J, { children: [
            /* @__PURE__ */ e.jsx(X, { children: t("Unsubscribe from alerts on selected projects?") }),
            /* @__PURE__ */ e.jsx(Ce, { children: t("unsubscribeAlertsConfirmDescription", {
              email: p,
              count: o.length
            }) })
          ] }),
          /* @__PURE__ */ e.jsxs(V, { children: [
            /* @__PURE__ */ e.jsx(
              C,
              {
                variant: "outline",
                onClick: () => u(!1),
                children: t("Cancel")
              }
            ),
            /* @__PURE__ */ e.jsx(C, { variant: "destructive", onClick: k, children: t("Unsubscribe") })
          ] })
        ] })
      }
    )
  ] });
}, Ze = {
  isValidationError: (o) => {
    var r, s, c;
    return console.error("isValidationError", o), o instanceof Ne && ((r = o.response) == null ? void 0 : r.status) === 409 && ((c = (s = o.response) == null ? void 0 : s.data) == null ? void 0 : c.code) === "VALIDATION";
  }
}, Ve = ({
  platform: o
}) => {
  const r = [
    {
      accessorKey: "displayName",
      size: 270,
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(T, { column: s, title: t("Name"), icon: Ae }),
      cell: ({ row: s }) => {
        const c = s.original.plan.locked, u = s.original.type === v.PERSONAL;
        return /* @__PURE__ */ e.jsxs("div", { className: "text-left flex items-center justify-start ", children: [
          c && /* @__PURE__ */ e.jsx(De, { className: "size-3 mr-1.5", strokeWidth: 2.5 }),
          u && /* @__PURE__ */ e.jsx(Ie, { className: "size-4 mr-1.5" }),
          /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: s.original.displayName })
        ] });
      }
    },
    {
      accessorKey: "type",
      enableHiding: !0
    },
    {
      accessorKey: "users",
      size: 120,
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(
        T,
        {
          column: s,
          title: t("Active Users"),
          icon: Te,
          className: "w-full"
        }
      ),
      cell: ({ row: s }) => /* @__PURE__ */ e.jsxs("div", { className: "text-left tabular-nums", children: [
        /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: s.original.analytics.activeUsers }),
        /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: ` / ${s.original.analytics.totalUsers}` })
      ] })
    },
    {
      accessorKey: "flows",
      size: 120,
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(
        T,
        {
          column: s,
          title: t("Active Flows"),
          icon: we,
          className: "w-full"
        }
      ),
      cell: ({ row: s }) => /* @__PURE__ */ e.jsxs("div", { className: "text-left tabular-nums", children: [
        /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: s.original.analytics.activeFlows }),
        /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: ` / ${s.original.analytics.totalFlows}` })
      ] })
    }
  ];
  return o.plan.embeddingEnabled && r.push({
    accessorKey: "externalId",
    size: 150,
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(
      T,
      {
        column: s,
        title: t("External ID"),
        icon: ve
      }
    ),
    cell: ({ row: s }) => {
      var u;
      const c = Pe(s.original.externalId) || ((u = s.original.externalId) == null ? void 0 : u.length) === 0 ? "-" : s.original.externalId;
      return /* @__PURE__ */ e.jsx("div", { className: "text-left truncate", children: c });
    }
  }), o.plan.globalConnectionsEnabled && r.push({
    accessorKey: "globalConnectionsCount",
    size: 135,
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(
      T,
      {
        column: s,
        title: t("Global Connections"),
        icon: ke,
        className: "w-full"
      }
    ),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left tabular-nums", children: s.original.globalConnectionsCount })
  }), r.push({
    accessorKey: "createdAt",
    size: 110,
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(
      T,
      {
        column: s,
        title: t("Created"),
        icon: Se
      }
    ),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(Ee, { date: new Date(s.original.created) }) })
  }), r;
};
function ts() {
  const { platform: o } = F.useCurrentPlatform(), r = Re(), [s, c] = Ue(), u = o.plan.teamProjectsLimit !== Me.NONE, { project: l } = w.useCurrentProject();
  j.useEffect(() => {
    s.has("type") || c(
      (a) => {
        const n = new URLSearchParams(a);
        return n.set("type", v.TEAM), n;
      },
      { replace: !0 }
    );
  }, []);
  const x = s.get("displayName") || void 0, f = s.getAll("type"), N = j.useMemo(
    () => ({
      displayName: x,
      type: f.length > 0 ? f.map((a) => a) : void 0
    }),
    [x, f.join(",")]
  ), { data: p } = w.useAllPlatformProjects(N), [m, b] = j.useState([]), [k, i] = j.useState(!1), [E, ee] = j.useState(null), [se, te] = j.useState(""), { data: S } = L.useGlobalConnections({
    request: { limit: 9999 },
    extraKeys: []
  }), ae = j.useMemo(() => p.map((a) => {
    var n;
    return {
      ...a,
      globalConnectionsCount: ((n = S == null ? void 0 : S.data) == null ? void 0 : n.filter(
        (g) => g.projectIds.includes(a.id)
      ).length) ?? 0
    };
  }), [p, S == null ? void 0 : S.data]), ne = j.useMemo(
    () => Ve({
      platform: o
    }),
    [o]
  ), oe = [
    {
      id: "select",
      accessorKey: "select",
      size: 40,
      minSize: 40,
      maxSize: 40,
      header: ({ table: a }) => {
        const n = a.getRowModel().rows.filter(
          (h) => h.original.id !== (l == null ? void 0 : l.id) && h.original.type !== v.PERSONAL
        ), g = n.length > 0 && n.every((h) => h.getIsSelected()), d = n.some(
          (h) => h.getIsSelected()
        );
        return /* @__PURE__ */ e.jsx(
          B,
          {
            checked: g || d,
            onCheckedChange: (h) => {
              const P = !!h;
              if (n.forEach((D) => D.toggleSelected(P)), P) {
                const y = [
                  ...n.map(
                    (A) => A.original
                  ),
                  ...m
                ], I = Array.from(
                  new Map(
                    y.map((A) => [A.id, A])
                  ).values()
                );
                b(I);
              } else {
                const D = m.filter(
                  (y) => !n.some((I) => I.original.id === y.id)
                );
                b(D);
              }
            }
          }
        );
      },
      cell: ({ row: a }) => {
        const n = a.original.id === (l == null ? void 0 : l.id), g = a.original.type === v.PERSONAL, d = n || g, h = m.some(
          (P) => P.id === a.original.id
        );
        return /* @__PURE__ */ e.jsxs(_, { children: [
          /* @__PURE__ */ e.jsx(H, { children: /* @__PURE__ */ e.jsx("div", { className: d ? "cursor-not-allowed" : "", children: /* @__PURE__ */ e.jsx(
            B,
            {
              checked: h,
              disabled: d,
              onCheckedChange: (P) => {
                if (d) return;
                const D = !!P;
                let y = [...m];
                D ? y.some(
                  (A) => A.id === a.original.id
                ) || y.push(a.original) : y = y.filter(
                  (I) => I.id !== a.original.id
                ), b(y), a.toggleSelected(!!P);
              }
            }
          ) }) }),
          d && /* @__PURE__ */ e.jsx(W, { side: "right", children: n ? t(
            "Cannot delete active project, switch to another project first"
          ) : t(
            "Personal projects cannot be deleted, and you can't subscribe to their alerts"
          ) })
        ] });
      }
    },
    ...ne
  ], le = j.useMemo(
    () => [
      {
        render: (a, n) => /* @__PURE__ */ e.jsx(
          Ye,
          {
            selectedProjects: m,
            resetSelection: () => {
              n(), b([]);
            }
          }
        )
      },
      {
        render: (a, n) => {
          const g = m.some(
            (d) => d.id !== (l == null ? void 0 : l.id) && d.type !== v.PERSONAL
          );
          return /* @__PURE__ */ e.jsx("div", { onClick: (d) => d.stopPropagation(), children: /* @__PURE__ */ e.jsx(
            Oe,
            {
              title: t("Delete Projects"),
              message: t(
                "The selected projects and all their data will be permanently deleted."
              ),
              entityName: t("Projects"),
              buttonText: t("Delete"),
              mutationFn: async () => {
                const d = m.filter(
                  (h) => h.id !== (l == null ? void 0 : l.id) && h.type !== v.PERSONAL
                );
                w.delete(
                  d.map((h) => h.id)
                ), n(), b([]);
              },
              onError: (d) => {
                Z.error(t("Error"), {
                  description: re(d),
                  duration: 3e3
                });
              },
              children: m.length > 0 && /* @__PURE__ */ e.jsxs(
                C,
                {
                  variant: "ghost",
                  size: "sm",
                  className: "text-destructive hover:text-destructive",
                  disabled: !g,
                  children: [
                    /* @__PURE__ */ e.jsx(Fe, { className: "mr-1 w-4" }),
                    `${t("Delete")} (${m.length})`
                  ]
                }
              )
            }
          ) });
        }
      }
    ],
    [m, l]
  ), ie = j.useMemo(
    () => [
      /* @__PURE__ */ e.jsx(
        Le,
        {
          variant: "full",
          projects: p
        },
        "new-project"
      )
    ],
    [p]
  ), re = (a) => {
    var n, g, d;
    if (Ze.isValidationError(a)) {
      switch (console.error(t("Validation error"), a), (d = (g = (n = a.response) == null ? void 0 : n.data) == null ? void 0 : g.params) == null ? void 0 : d.message) {
        case "PROJECT_HAS_ENABLED_FLOWS":
          return t("Project has enabled flows. Please disable them first.");
        case "ACTIVE_PROJECT":
          return t(
            "This project is active. Please switch to another project first."
          );
      }
      return;
    }
  }, ce = [
    (a) => /* @__PURE__ */ e.jsx("div", { className: "flex items-end justify-end", children: /* @__PURE__ */ e.jsxs(_, { children: [
      /* @__PURE__ */ e.jsx(H, { asChild: !0, children: /* @__PURE__ */ e.jsx(
        C,
        {
          variant: "ghost",
          className: "size-8 p-0",
          onClick: async (n) => {
            n.stopPropagation(), n.preventDefault(), ee({
              projectName: a.displayName
            }), te(a.id), i(!0);
          },
          children: /* @__PURE__ */ e.jsx(Be, { className: "size-4" })
        }
      ) }),
      /* @__PURE__ */ e.jsx(W, { side: "bottom", children: t("Edit project") })
    ] }) })
  ];
  return /* @__PURE__ */ e.jsx(
    ze,
    {
      featureKey: "PROJECTS",
      locked: !u,
      lockTitle: t("Unlock Projects"),
      lockDescription: t(
        "Orchestrate your automation teams across projects with their own flows, connections and usage quotas"
      ),
      lockVideoUrl: "/ap-cdn/videos/showcase/projects.mp4",
      children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col w-full", children: [
        /* @__PURE__ */ e.jsx(
          We,
          {
            title: t("Projects"),
            description: t("Manage your automation projects")
          }
        ),
        /* @__PURE__ */ e.jsx(
          Ke,
          {
            emptyStateTextTitle: t("No projects found"),
            emptyStateTextDescription: t(
              "Start by creating projects to manage your automation teams"
            ),
            emptyStateIcon: /* @__PURE__ */ e.jsx(He, { className: "size-14" }),
            onRowClick: async (a) => {
              await w.setCurrentProject(a.id), r("/");
            },
            filters: [
              {
                type: "input",
                title: t("Name"),
                accessorKey: "displayName",
                icon: q
              },
              {
                type: "select",
                title: t("Type"),
                accessorKey: "type",
                options: Object.values(v).map((a) => ({
                  label: _e.convertEnumToHumanReadable(a) + " Project",
                  value: a
                })),
                icon: q
              }
            ],
            columns: oe,
            page: {
              data: ae,
              next: null,
              previous: null
            },
            isLoading: !1,
            clientPagination: !0,
            bulkActions: le,
            toolbarButtons: ie,
            actions: ce
          }
        ),
        /* @__PURE__ */ e.jsx(
          Je,
          {
            open: k,
            onClose: () => {
              i(!1);
            },
            initialValues: E,
            projectId: se
          }
        )
      ] })
    }
  );
}
export {
  ts as default
};
