import { k1 as w, g as s, k2 as r, k3 as n } from "./mount-builder-CqIEWsZv.mjs";
var u = function(a, t) {
  return new URLSearchParams(a).get(t);
}, f = function(a) {
  var t = window.location, o = s.useState(function() {
    return u(t.search, a);
  }), c = o[0], i = o[1];
  return s.useEffect(function() {
    var e = function() {
      i(u(t.search, a));
    };
    return r(window, "popstate", e), r(window, "pushstate", e), r(window, "replacestate", e), function() {
      n(window, "popstate", e), n(window, "pushstate", e), n(window, "replacestate", e);
    };
  }, []), c;
}, p = function() {
  return null;
};
const l = w ? f : p;
export {
  l as u
};
