var Mc = Object.defineProperty;
var Dc = Object.getPrototypeOf;
var Bc = Reflect.get;
var ma = (t) => {
  throw TypeError(t);
};
var Fc = (t, e, n) => e in t ? Mc(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var _ = (t, e, n) => Fc(t, typeof e != "symbol" ? e + "" : e, n), Ar = (t, e, n) => e.has(t) || ma("Cannot " + n);
var me = (t, e, n) => (Ar(t, e, "read from private field"), n ? n.call(t) : e.get(t)), at = (t, e, n) => e.has(t) ? ma("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, n), Ee = (t, e, n, r) => (Ar(t, e, "write to private field"), r ? r.call(t, n) : e.set(t, n), n), Ir = (t, e, n) => (Ar(t, e, "access private method"), n);
var ga = (t, e, n) => Bc(Dc(t), n, e);
import { o as G, s as P, _ as As, f as Ui, l as q, u as Pn, r as yt, d as Hi, n as Is, a as We, B as Gc, N as Ue, b as zc, c as Lt, e as Ze, g as y, j as u, h as $, i as V, C as on, k as Uc, t as Hc, m as ke, p as Ln, q as qc, v as Wc, w as Ts, x as Zc, y as ln, z as Vc, A as Jc, D as $n, E as Qc, W as ya, F as xa, G as ba, H as qi, I as Yc, J as Wi, K as Xc, L as wa, M as Es, O as Zi, P as Kc, Q as eu, R as tu, S as ka, T as nu, U as ru, V as su, X as au, Y as iu, Z as ou, $ as lu, a0 as cu, a1 as Vi, a2 as js, a3 as Ji, a4 as Rs, a5 as Ps, a6 as A, a7 as J, a8 as On, a9 as we, aa as uu, ab as Qi, ac as pu, ad as Yi, ae as ar, af as du, ag as va, ah as Xi, ai as Ki, aj as ir, ak as xt, al as Yr, am as Ls, an as eo, ao as to, ap as no, aq as hu, ar as kt, as as fu, at as mu, au as gu, av as it, aw as Tr, ax as ro, ay as so, az as ao, aA as io, aB as yu, aC as xu, aD as bu, aE as wu, aF as ku, aG as vu, aH as _u, aI as Su, aJ as Cu, aK as An, aL as Xr, aM as Ft, aN as oo, aO as Nu, aP as Au, aQ as Kr, aR as Iu, aS as Tu, aT as lo, aU as es, aV as co, aW as ts, aX as Mn, aY as _a, aZ as Eu, a_ as uo, a$ as Sa, b0 as ju, b1 as qt, b2 as Ru, b3 as po, b4 as Pu, b5 as Lu, b6 as $u, b7 as ho, b8 as Ou, b9 as Mu, ba as Du, bb as Bu, bc as Ca } from "./mount-builder-CqIEWsZv.mjs";
import { C as fo, a as mo } from "./collapsible-CCnqobod.mjs";
import { P as Dn } from "./piece-icon-from-name-CkNp4shA.mjs";
import { L as go } from "./list-checks-nm3lcqnf.mjs";
import { R as Fu } from "./rocket-DmQcsYfQ.mjs";
import { S as Gu } from "./shield-check-DaZf4pFn.mjs";
import { D as zu } from "./database-DZzKBFIH.mjs";
import { M as Uu } from "./message-square-ukP9go3c.mjs";
async function Ct(t) {
  try {
    return { data: await t(), error: null };
  } catch (e) {
    return { data: null, error: e };
  }
}
var In = /* @__PURE__ */ ((t) => (t.CHUNK = "CHUNK", t.FINISHED = "FINISHED", t.ERROR = "ERROR", t))(In || {});
const Hu = 10 * 1024 * 1024, qu = Math.ceil(Hu * 4 / 3), yo = [
  "image/png",
  "image/jpeg",
  "image/gif",
  "image/webp",
  "text/plain",
  "text/csv",
  "text/markdown",
  "application/json",
  "application/pdf"
], Wu = /^[^\x00-\x1f\r\n]*$/, Zu = G({
  name: P().min(1).max(255).refine(
    (t) => Wu.test(t),
    { message: Ui.invalidFileName }
  ),
  mimeType: As(yo),
  data: P().max(qu)
});
var Wt = /* @__PURE__ */ ((t) => (t.TEXT = "text", t.REASONING = "reasoning", t.TOOL_CALL = "tool-call", t.THINKING_STATUS = "thinking-status", t))(Wt || {}), xo = /* @__PURE__ */ ((t) => (t.COMPLETED = "completed", t.ERROR = "error", t))(xo || {});
const Vu = G({
  type: q(
    "text"
    /* TEXT */
  ),
  text: P()
}), Ju = G({
  type: q(
    "reasoning"
    /* REASONING */
  ),
  text: P()
}), Qu = G({
  type: q(
    "tool-call"
    /* TOOL_CALL */
  ),
  toolCallId: P(),
  toolName: P(),
  input: yt(P(), Pn()),
  output: Pn().optional(),
  status: As([
    "completed",
    "error"
    /* ERROR */
  ]),
  errorText: P().optional()
}), Yu = G({
  type: q(
    "thinking-status"
    /* THINKING_STATUS */
  ),
  text: P()
}), Xu = Hi("type", [
  Vu,
  Ju,
  Qu,
  Yu
]), Ku = G({
  role: As([
    "user",
    "assistant"
    /* ASSISTANT */
  ]),
  parts: We(Xu),
  thinkingDurationMs: Is().optional()
});
var Bn = /* @__PURE__ */ ((t) => (t.IDLE = "IDLE", t.STREAMING = "STREAMING", t.ERROR = "ERROR", t))(Bn || {});
G({
  ...Gc,
  platformId: P(),
  projectId: Ue(P()),
  userId: P(),
  title: Ue(P()),
  modelName: Ue(P()),
  status: zc(Bn).default(
    "IDLE"
    /* IDLE */
  ),
  messages: We(yt(P(), Pn())).default([]),
  uiMessages: We(Ku).nullable().default(null),
  summary: Ue(P()),
  summarizedUpToIndex: Ue(Is().int())
});
G({
  title: Ue(P()).optional(),
  modelName: Ue(P()).optional()
});
G({
  title: Ue(P()).optional(),
  modelName: Ue(P()).optional()
});
G({
  content: P().max(51200),
  files: We(Zu).max(10).optional()
}).refine(
  (t) => t.content.length > 0 || t.files && t.files.length > 0,
  { message: Ui.messageRequiresContentOrFiles }
);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ep = [
  ["path", { d: "M12 18V5", key: "adv99a" }],
  ["path", { d: "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4", key: "1e3is1" }],
  ["path", { d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5", key: "1gqd8o" }],
  ["path", { d: "M17.997 5.125a4 4 0 0 1 2.526 5.77", key: "iwvgf7" }],
  ["path", { d: "M18 18a4 4 0 0 0 2-7.464", key: "efp6ie" }],
  ["path", { d: "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517", key: "1gq6am" }],
  ["path", { d: "M6 18a4 4 0 0 1-2-7.464", key: "k1g0md" }],
  ["path", { d: "M6.003 5.125a4 4 0 0 0-2.526 5.77", key: "q97ue3" }]
], tp = Lt("brain", ep);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const np = [
  ["line", { x1: "5", x2: "19", y1: "9", y2: "9", key: "1nwqeh" }],
  ["line", { x1: "5", x2: "19", y1: "15", y2: "15", key: "g8yjpy" }]
], rp = Lt("equal", np);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const sp = [
  ["path", { d: "M12 19v3", key: "npa21l" }],
  ["path", { d: "M19 10v2a7 7 0 0 1-14 0v-2", key: "1vc78b" }],
  ["rect", { x: "9", y: "2", width: "6", height: "13", rx: "3", key: "s6n7sd" }]
], ap = Lt("mic", sp);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ip = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
], bo = Lt("square", ip);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const op = [
  [
    "path",
    {
      d: "M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z",
      key: "uqj9uw"
    }
  ],
  ["path", { d: "M16 9a5 5 0 0 1 0 6", key: "1q6k2b" }],
  ["path", { d: "M19.364 18.364a9 9 0 0 0 0-12.728", key: "ijwkga" }]
], lp = Lt("volume-2", op);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const cp = [
  ["path", { d: "M16 9a5 5 0 0 1 .95 2.293", key: "1fgyg8" }],
  ["path", { d: "M19.364 5.636a9 9 0 0 1 1.889 9.96", key: "l3zxae" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "m7 7-.587.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298V11",
      key: "1gbwow"
    }
  ],
  ["path", { d: "M9.828 4.172A.686.686 0 0 1 11 4.657v.686", key: "s2je0y" }]
], up = Lt("volume-off", cp), Na = {}.hasOwnProperty;
function pp(t, e) {
  const n = e || {};
  function r(s, ...a) {
    let i = r.invalid;
    const o = r.handlers;
    if (s && Na.call(s, t)) {
      const l = String(s[t]);
      i = Na.call(o, l) ? o[l] : r.unknown;
    }
    if (i)
      return i.call(this, s, ...a);
  }
  return r.handlers = n.handlers || {}, r.invalid = n.invalid, r.unknown = n.unknown, r;
}
async function dp(t) {
  return Ze.post("/v1/chat/conversations", t);
}
async function hp({
  cursor: t,
  limit: e = 20
}) {
  return Ze.get("/v1/chat/conversations", {
    limit: e,
    cursor: t
  });
}
async function fp(t) {
  return Ze.get(`/v1/chat/conversations/${t}`);
}
async function mp(t) {
  return Ze.get(
    `/v1/chat/conversations/${t}/messages`
  );
}
async function gp(t, e) {
  return Ze.post(`/v1/chat/conversations/${t}`, e);
}
async function yp(t) {
  return Ze.delete(`/v1/chat/conversations/${t}`);
}
async function xp({
  conversationId: t,
  content: e,
  files: n
}) {
  return Ze.post(
    `/v1/chat/conversations/${t}/messages`,
    { content: e, files: n }
  );
}
async function bp({
  gateId: t,
  approved: e
}) {
  return Ze.post(`/v1/chat/tool-approvals/${t}`, { approved: e });
}
const be = {
  createConversation: dp,
  listConversations: hp,
  getConversation: fp,
  getMessages: mp,
  updateConversation: gp,
  deleteConversation: yp,
  sendMessage: xp,
  approveToolCall: bp
};
/*!---------------------------------------------------------------------------------------------
 *  Copyright (c) StackBlitz. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/
const wp = {
  /**
   * A value from 0 to 1, on how much to damp the animation.
   * 0 means no damping, 1 means full damping.
   *
   * @default 0.7
   */
  damping: 0.7,
  /**
   * The stiffness of how fast/slow the animation gets up to speed.
   *
   * @default 0.05
   */
  stiffness: 0.05,
  /**
   * The inertial mass associated with the animation.
   * Higher numbers make the animation slower.
   *
   * @default 1.25
   */
  mass: 1.25
}, kp = 70, vp = 1e3 / 60, _p = 350;
let or = !1;
var Fi;
(Fi = globalThis.document) == null || Fi.addEventListener("mousedown", () => {
  or = !0;
});
var Gi;
(Gi = globalThis.document) == null || Gi.addEventListener("mouseup", () => {
  or = !1;
});
var zi;
(zi = globalThis.document) == null || zi.addEventListener("click", () => {
  or = !1;
});
const Sp = (t = {}) => {
  const [e, n] = y.useState(!1), [r, s] = y.useState(t.initial !== !1), [a, i] = y.useState(!1), o = y.useRef(null);
  o.current = t;
  const l = y.useCallback(() => {
    var k;
    if (!or)
      return !1;
    const w = window.getSelection();
    if (!w || !w.rangeCount)
      return !1;
    const x = w.getRangeAt(0);
    return x.commonAncestorContainer.contains(b.current) || ((k = b.current) == null ? void 0 : k.contains(x.commonAncestorContainer));
  }, []), c = y.useCallback((w) => {
    p.isAtBottom = w, s(w);
  }, []), d = y.useCallback((w) => {
    p.escapedFromLock = w, n(w);
  }, []), p = y.useMemo(() => {
    let w;
    return {
      escapedFromLock: e,
      isAtBottom: r,
      resizeDifference: 0,
      accumulated: 0,
      velocity: 0,
      listeners: /* @__PURE__ */ new Set(),
      get scrollTop() {
        var x;
        return ((x = b.current) == null ? void 0 : x.scrollTop) ?? 0;
      },
      set scrollTop(x) {
        b.current && (b.current.scrollTop = x, p.ignoreScrollToTop = b.current.scrollTop);
      },
      get targetScrollTop() {
        return !b.current || !v.current ? 0 : b.current.scrollHeight - 1 - b.current.clientHeight;
      },
      get calculatedTargetScrollTop() {
        if (!b.current || !v.current)
          return 0;
        const { targetScrollTop: x } = this;
        if (!t.targetScrollTop)
          return x;
        if ((w == null ? void 0 : w.targetScrollTop) === x)
          return w.calculatedScrollTop;
        const k = Math.max(Math.min(t.targetScrollTop(x, {
          scrollElement: b.current,
          contentElement: v.current
        }), x), 0);
        return w = { targetScrollTop: x, calculatedScrollTop: k }, requestAnimationFrame(() => {
          w = void 0;
        }), k;
      },
      get scrollDifference() {
        return this.calculatedTargetScrollTop - this.scrollTop;
      },
      get isNearBottom() {
        return this.scrollDifference <= kp;
      }
    };
  }, []), h = y.useCallback((w = {}) => {
    var O;
    typeof w == "string" && (w = { animation: w }), w.preserveScrollPosition || c(!0);
    const x = Date.now() + (Number(w.wait) || 0), k = jr(o.current, w.animation), { ignoreEscapes: S = !1 } = w;
    let N, C = p.calculatedTargetScrollTop;
    w.duration instanceof Promise ? w.duration.finally(() => {
      N = Date.now();
    }) : N = x + (w.duration ?? 0);
    const E = async () => {
      const R = new Promise(requestAnimationFrame).then(() => {
        var L;
        if (!p.isAtBottom)
          return p.animation = void 0, !1;
        const { scrollTop: I } = p, j = performance.now(), U = (j - (p.lastTick ?? j)) / vp;
        if (p.animation || (p.animation = { behavior: k, promise: R, ignoreEscapes: S }), p.animation.behavior === k && (p.lastTick = j), l() || x > Date.now())
          return E();
        if (I < Math.min(C, p.calculatedTargetScrollTop)) {
          if (((L = p.animation) == null ? void 0 : L.behavior) === k) {
            if (k === "instant")
              return p.scrollTop = p.calculatedTargetScrollTop, E();
            p.velocity = (k.damping * p.velocity + k.stiffness * p.scrollDifference) / k.mass, p.accumulated += p.velocity * U, p.scrollTop += p.accumulated, p.scrollTop !== I && (p.accumulated = 0);
          }
          return E();
        }
        return N > Date.now() ? (C = p.calculatedTargetScrollTop, E()) : (p.animation = void 0, p.scrollTop < p.calculatedTargetScrollTop ? h({
          animation: jr(o.current, o.current.resize),
          ignoreEscapes: S,
          duration: Math.max(0, N - Date.now()) || void 0
        }) : p.isAtBottom);
      });
      return R.then((I) => (requestAnimationFrame(() => {
        p.animation || (p.lastTick = void 0, p.velocity = 0);
      }), I));
    };
    return w.wait !== !0 && (p.animation = void 0), ((O = p.animation) == null ? void 0 : O.behavior) === k ? p.animation.promise : E();
  }, [c, l, p]), m = y.useCallback(() => {
    d(!0), c(!1);
  }, [d, c]), f = y.useCallback(({ target: w }) => {
    if (w !== b.current)
      return;
    const { scrollTop: x, ignoreScrollToTop: k } = p;
    let { lastScrollTop: S = x } = p;
    p.lastScrollTop = x, p.ignoreScrollToTop = void 0, k && k > x && (S = k), i(p.isNearBottom), setTimeout(() => {
      var E;
      if (p.resizeDifference || x === k)
        return;
      if (l()) {
        d(!0), c(!1);
        return;
      }
      const N = x > S, C = x < S;
      if ((E = p.animation) != null && E.ignoreEscapes) {
        p.scrollTop = S;
        return;
      }
      C && (d(!0), c(!1)), N && d(!1), !p.escapedFromLock && p.isNearBottom && c(!0);
    }, 1);
  }, [d, c, l, p]), g = y.useCallback(({ target: w, deltaY: x }) => {
    var S;
    let k = w;
    for (; !["scroll", "auto"].includes(getComputedStyle(k).overflow); ) {
      if (!k.parentElement)
        return;
      k = k.parentElement;
    }
    k === b.current && x < 0 && b.current.scrollHeight > b.current.clientHeight && !((S = p.animation) != null && S.ignoreEscapes) && (d(!0), c(!1));
  }, [d, c, p]), b = Aa((w) => {
    var x, k;
    (x = b.current) == null || x.removeEventListener("scroll", f), (k = b.current) == null || k.removeEventListener("wheel", g), w == null || w.addEventListener("scroll", f, { passive: !0 }), w == null || w.addEventListener("wheel", g, { passive: !0 });
  }, []), v = Aa((w) => {
    var k, S;
    if ((k = p.resizeObserver) == null || k.disconnect(), !w)
      return;
    let x;
    p.resizeObserver = new ResizeObserver(([N]) => {
      const { height: C } = N.contentRect, E = C - (x ?? C);
      if (p.resizeDifference = E, p.scrollTop > p.targetScrollTop && (p.scrollTop = p.targetScrollTop), i(p.isNearBottom), E >= 0) {
        const O = jr(o.current, x ? o.current.resize : o.current.initial);
        h({
          animation: O,
          wait: !0,
          preserveScrollPosition: !0,
          duration: O === "instant" ? void 0 : _p
        });
      } else
        p.isNearBottom && (d(!1), c(!0));
      x = C, requestAnimationFrame(() => {
        setTimeout(() => {
          p.resizeDifference === E && (p.resizeDifference = 0);
        }, 1);
      });
    }), (S = p.resizeObserver) == null || S.observe(w);
  }, []);
  return {
    contentRef: v,
    scrollRef: b,
    scrollToBottom: h,
    stopScroll: m,
    isAtBottom: r || a,
    isNearBottom: a,
    escapedFromLock: e,
    state: p
  };
};
function Aa(t, e) {
  const n = y.useCallback((r) => (n.current = r, t(r)), e);
  return n;
}
const Er = /* @__PURE__ */ new Map();
function jr(...t) {
  const e = { ...wp };
  let n = !1;
  for (const s of t) {
    if (s === "instant") {
      n = !0;
      continue;
    }
    typeof s == "object" && (n = !1, e.damping = s.damping ?? e.damping, e.stiffness = s.stiffness ?? e.stiffness, e.mass = s.mass ?? e.mass);
  }
  const r = JSON.stringify(e);
  return Er.has(r) || Er.set(r, Object.freeze(e)), n ? "instant" : Er.get(r);
}
/*!---------------------------------------------------------------------------------------------
 *  Copyright (c) StackBlitz. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/
const wo = y.createContext(null), Cp = typeof window < "u" ? y.useLayoutEffect : y.useEffect;
function Fn({ instance: t, children: e, resize: n, initial: r, mass: s, damping: a, stiffness: i, targetScrollTop: o, contextRef: l, ...c }) {
  const d = y.useRef(null), p = y.useCallback((S, N) => {
    const C = (k == null ? void 0 : k.targetScrollTop) ?? o;
    return (C == null ? void 0 : C(S, N)) ?? S;
  }, [o]), h = Sp({
    mass: s,
    damping: a,
    stiffness: i,
    resize: n,
    initial: r,
    targetScrollTop: p
  }), { scrollRef: m, contentRef: f, scrollToBottom: g, stopScroll: b, isAtBottom: v, escapedFromLock: w, state: x } = t ?? h, k = y.useMemo(() => ({
    scrollToBottom: g,
    stopScroll: b,
    scrollRef: m,
    isAtBottom: v,
    escapedFromLock: w,
    contentRef: f,
    state: x,
    get targetScrollTop() {
      return d.current;
    },
    set targetScrollTop(S) {
      d.current = S;
    }
  }), [
    g,
    v,
    f,
    m,
    b,
    w,
    x
  ]);
  return y.useImperativeHandle(l, () => k, [k]), Cp(() => {
    m.current && getComputedStyle(m.current).overflow === "visible" && (m.current.style.overflow = "auto");
  }, []), y.createElement(
    wo.Provider,
    { value: k },
    y.createElement("div", { ...c }, typeof e == "function" ? e(k) : e)
  );
}
(function(t) {
  function e({ children: n, scrollClassName: r, ...s }) {
    const a = ko();
    return y.createElement(
      "div",
      { ref: a.scrollRef, style: {
        height: "100%",
        width: "100%",
        scrollbarGutter: "stable both-edges"
      }, className: r },
      y.createElement("div", { ...s, ref: a.contentRef }, typeof n == "function" ? n(a) : n)
    );
  }
  t.Content = e;
})(Fn || (Fn = {}));
function ko() {
  const t = y.useContext(wo);
  if (!t)
    throw new Error("use-stick-to-bottom component context must be used within a StickToBottom component");
  return t;
}
function Np({
  children: t,
  className: e,
  ...n
}) {
  return /* @__PURE__ */ u.jsx(
    Fn,
    {
      className: $("flex overflow-y-auto", e),
      resize: "smooth",
      initial: "instant",
      role: "log",
      ...n,
      children: t
    }
  );
}
function Ap({
  children: t,
  className: e,
  ...n
}) {
  return /* @__PURE__ */ u.jsx(
    Fn.Content,
    {
      className: $("flex w-full flex-col", e),
      ...n,
      children: t
    }
  );
}
function Ip({
  className: t,
  ...e
}) {
  return /* @__PURE__ */ u.jsx(
    "div",
    {
      className: $("h-px w-full shrink-0 scroll-mt-4", t),
      "aria-hidden": "true",
      ...e
    }
  );
}
function Tp({
  className: t,
  variant: e = "outline",
  size: n = "sm",
  ...r
}) {
  const { isAtBottom: s, scrollToBottom: a } = ko();
  return /* @__PURE__ */ u.jsx(
    V,
    {
      variant: e,
      size: n,
      className: $(
        "h-10 w-10 rounded-full transition-all duration-150 ease-out",
        s ? "pointer-events-none translate-y-4 scale-95 opacity-0" : "translate-y-0 scale-100 opacity-100",
        t
      ),
      onClick: () => a(),
      ...r,
      children: /* @__PURE__ */ u.jsx(on, { className: "h-5 w-5" })
    }
  );
}
var vo = "vercel.ai.error", Ep = Symbol.for(vo), Ia, Ta, rt = class _o extends (Ta = Error, Ia = Ep, Ta) {
  /**
   * Creates an AI SDK Error.
   *
   * @param {Object} params - The parameters for creating the error.
   * @param {string} params.name - The name of the error.
   * @param {string} params.message - The error message.
   * @param {unknown} [params.cause] - The underlying cause of the error.
   */
  constructor({
    name: e,
    message: n,
    cause: r
  }) {
    super(n), this[Ia] = !0, this.name = e, this.cause = r;
  }
  /**
   * Checks if the given error is an AI SDK Error.
   * @param {unknown} error - The error to check.
   * @returns {boolean} True if the error is an AI SDK Error, false otherwise.
   */
  static isInstance(e) {
    return _o.hasMarker(e, vo);
  }
  static hasMarker(e, n) {
    const r = Symbol.for(n);
    return e != null && typeof e == "object" && r in e && typeof e[r] == "boolean" && e[r] === !0;
  }
};
function So(t) {
  return t == null ? "unknown error" : typeof t == "string" ? t : t instanceof Error ? t.message : JSON.stringify(t);
}
var Co = "AI_InvalidArgumentError", No = `vercel.ai.error.${Co}`, jp = Symbol.for(No), Ea, ja, Rp = class extends (ja = rt, Ea = jp, ja) {
  constructor({
    message: t,
    cause: e,
    argument: n
  }) {
    super({ name: Co, message: t, cause: e }), this[Ea] = !0, this.argument = n;
  }
  static isInstance(t) {
    return rt.hasMarker(t, No);
  }
}, Ao = "AI_JSONParseError", Io = `vercel.ai.error.${Ao}`, Pp = Symbol.for(Io), Ra, Pa, La = class extends (Pa = rt, Ra = Pp, Pa) {
  constructor({ text: t, cause: e }) {
    super({
      name: Ao,
      message: `JSON parsing failed: Text: ${t}.
Error message: ${So(e)}`,
      cause: e
    }), this[Ra] = !0, this.text = t;
  }
  static isInstance(t) {
    return rt.hasMarker(t, Io);
  }
}, To = "AI_TypeValidationError", Eo = `vercel.ai.error.${To}`, Lp = Symbol.for(Eo), $a, Oa, Yt = class ns extends (Oa = rt, $a = Lp, Oa) {
  constructor({
    value: e,
    cause: n,
    context: r
  }) {
    let s = "Type validation failed";
    if (r != null && r.field && (s += ` for ${r.field}`), r != null && r.entityName || r != null && r.entityId) {
      s += " (";
      const a = [];
      r.entityName && a.push(r.entityName), r.entityId && a.push(`id: "${r.entityId}"`), s += a.join(", "), s += ")";
    }
    super({
      name: To,
      message: `${s}: Value: ${JSON.stringify(e)}.
Error message: ${So(n)}`,
      cause: n
    }), this[$a] = !0, this.value = e, this.context = r;
  }
  static isInstance(e) {
    return rt.hasMarker(e, Eo);
  }
  /**
   * Wraps an error into a TypeValidationError.
   * If the cause is already a TypeValidationError with the same value and context, it returns the cause.
   * Otherwise, it creates a new TypeValidationError.
   *
   * @param {Object} params - The parameters for wrapping the error.
   * @param {unknown} params.value - The value that failed validation.
   * @param {unknown} params.cause - The original error or cause of the validation failure.
   * @param {TypeValidationContext} params.context - Optional context about what is being validated.
   * @returns {TypeValidationError} A TypeValidationError instance.
   */
  static wrap({
    value: e,
    cause: n,
    context: r
  }) {
    var s, a, i;
    return ns.isInstance(n) && n.value === e && ((s = n.context) == null ? void 0 : s.field) === (r == null ? void 0 : r.field) && ((a = n.context) == null ? void 0 : a.entityName) === (r == null ? void 0 : r.entityName) && ((i = n.context) == null ? void 0 : i.entityId) === (r == null ? void 0 : r.entityId) ? n : new ns({ value: e, cause: n, context: r });
  }
}, Xt;
(function(t) {
  t.assertEqual = (s) => {
  };
  function e(s) {
  }
  t.assertIs = e;
  function n(s) {
    throw new Error();
  }
  t.assertNever = n, t.arrayToEnum = (s) => {
    const a = {};
    for (const i of s)
      a[i] = i;
    return a;
  }, t.getValidEnumValues = (s) => {
    const a = t.objectKeys(s).filter((o) => typeof s[s[o]] != "number"), i = {};
    for (const o of a)
      i[o] = s[o];
    return t.objectValues(i);
  }, t.objectValues = (s) => t.objectKeys(s).map(function(a) {
    return s[a];
  }), t.objectKeys = typeof Object.keys == "function" ? (s) => Object.keys(s) : (s) => {
    const a = [];
    for (const i in s)
      Object.prototype.hasOwnProperty.call(s, i) && a.push(i);
    return a;
  }, t.find = (s, a) => {
    for (const i of s)
      if (a(i))
        return i;
  }, t.isInteger = typeof Number.isInteger == "function" ? (s) => Number.isInteger(s) : (s) => typeof s == "number" && Number.isFinite(s) && Math.floor(s) === s;
  function r(s, a = " | ") {
    return s.map((i) => typeof i == "string" ? `'${i}'` : i).join(a);
  }
  t.joinValues = r, t.jsonStringifyReplacer = (s, a) => typeof a == "bigint" ? a.toString() : a;
})(Xt || (Xt = {}));
var Ma;
(function(t) {
  t.mergeShapes = (e, n) => ({
    ...e,
    ...n
    // second overwrites first
  });
})(Ma || (Ma = {}));
Xt.arrayToEnum([
  "string",
  "nan",
  "number",
  "integer",
  "float",
  "boolean",
  "date",
  "bigint",
  "symbol",
  "function",
  "undefined",
  "null",
  "array",
  "object",
  "unknown",
  "promise",
  "void",
  "never",
  "map",
  "set"
]);
Xt.arrayToEnum([
  "invalid_type",
  "invalid_literal",
  "custom",
  "invalid_union",
  "invalid_union_discriminator",
  "invalid_enum_value",
  "unrecognized_keys",
  "invalid_arguments",
  "invalid_return_type",
  "invalid_date",
  "invalid_string",
  "too_small",
  "too_big",
  "invalid_intersection_types",
  "not_multiple_of",
  "not_finite"
]);
class Gn extends Error {
  get errors() {
    return this.issues;
  }
  constructor(e) {
    super(), this.issues = [], this.addIssue = (r) => {
      this.issues = [...this.issues, r];
    }, this.addIssues = (r = []) => {
      this.issues = [...this.issues, ...r];
    };
    const n = new.target.prototype;
    Object.setPrototypeOf ? Object.setPrototypeOf(this, n) : this.__proto__ = n, this.name = "ZodError", this.issues = e;
  }
  format(e) {
    const n = e || function(a) {
      return a.message;
    }, r = { _errors: [] }, s = (a) => {
      for (const i of a.issues)
        if (i.code === "invalid_union")
          i.unionErrors.map(s);
        else if (i.code === "invalid_return_type")
          s(i.returnTypeError);
        else if (i.code === "invalid_arguments")
          s(i.argumentsError);
        else if (i.path.length === 0)
          r._errors.push(n(i));
        else {
          let o = r, l = 0;
          for (; l < i.path.length; ) {
            const c = i.path[l];
            l === i.path.length - 1 ? (o[c] = o[c] || { _errors: [] }, o[c]._errors.push(n(i))) : o[c] = o[c] || { _errors: [] }, o = o[c], l++;
          }
        }
    };
    return s(this), r;
  }
  static assert(e) {
    if (!(e instanceof Gn))
      throw new Error(`Not a ZodError: ${e}`);
  }
  toString() {
    return this.message;
  }
  get message() {
    return JSON.stringify(this.issues, Xt.jsonStringifyReplacer, 2);
  }
  get isEmpty() {
    return this.issues.length === 0;
  }
  flatten(e = (n) => n.message) {
    const n = /* @__PURE__ */ Object.create(null), r = [];
    for (const s of this.issues)
      if (s.path.length > 0) {
        const a = s.path[0];
        n[a] = n[a] || [], n[a].push(e(s));
      } else
        r.push(e(s));
    return { formErrors: r, fieldErrors: n };
  }
  get formErrors() {
    return this.flatten();
  }
}
Gn.create = (t) => new Gn(t);
var Da;
(function(t) {
  t.errToObj = (e) => typeof e == "string" ? { message: e } : e || {}, t.toString = (e) => typeof e == "string" ? e : e == null ? void 0 : e.message;
})(Da || (Da = {}));
var D;
(function(t) {
  t.ZodString = "ZodString", t.ZodNumber = "ZodNumber", t.ZodNaN = "ZodNaN", t.ZodBigInt = "ZodBigInt", t.ZodBoolean = "ZodBoolean", t.ZodDate = "ZodDate", t.ZodSymbol = "ZodSymbol", t.ZodUndefined = "ZodUndefined", t.ZodNull = "ZodNull", t.ZodAny = "ZodAny", t.ZodUnknown = "ZodUnknown", t.ZodNever = "ZodNever", t.ZodVoid = "ZodVoid", t.ZodArray = "ZodArray", t.ZodObject = "ZodObject", t.ZodUnion = "ZodUnion", t.ZodDiscriminatedUnion = "ZodDiscriminatedUnion", t.ZodIntersection = "ZodIntersection", t.ZodTuple = "ZodTuple", t.ZodRecord = "ZodRecord", t.ZodMap = "ZodMap", t.ZodSet = "ZodSet", t.ZodFunction = "ZodFunction", t.ZodLazy = "ZodLazy", t.ZodLiteral = "ZodLiteral", t.ZodEnum = "ZodEnum", t.ZodEffects = "ZodEffects", t.ZodNativeEnum = "ZodNativeEnum", t.ZodOptional = "ZodOptional", t.ZodNullable = "ZodNullable", t.ZodDefault = "ZodDefault", t.ZodCatch = "ZodCatch", t.ZodPromise = "ZodPromise", t.ZodBranded = "ZodBranded", t.ZodPipeline = "ZodPipeline", t.ZodReadonly = "ZodReadonly";
})(D || (D = {}));
var cn = ({
  prefix: t,
  size: e = 16,
  alphabet: n = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
  separator: r = "-"
} = {}) => {
  const s = () => {
    const a = n.length, i = new Array(e);
    for (let o = 0; o < e; o++)
      i[o] = n[Math.random() * a | 0];
    return i.join("");
  };
  if (t == null)
    return s;
  if (n.includes(r))
    throw new Rp({
      argument: "separator",
      message: `The separator "${r}" must not be part of the alphabet "${n}".`
    });
  return () => `${t}${r}${s()}`;
};
cn();
var $p = /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*:/, Op = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
function Ba(t) {
  const e = JSON.parse(t);
  return e === null || typeof e != "object" || $p.test(t) === !1 && Op.test(t) === !1 ? e : Mp(e);
}
function Mp(t) {
  let e = [t];
  for (; e.length; ) {
    const n = e;
    e = [];
    for (const r of n) {
      if (Object.prototype.hasOwnProperty.call(r, "__proto__"))
        throw new SyntaxError("Object contains forbidden prototype property");
      if (Object.prototype.hasOwnProperty.call(r, "constructor") && r.constructor !== null && typeof r.constructor == "object" && Object.prototype.hasOwnProperty.call(r.constructor, "prototype"))
        throw new SyntaxError("Object contains forbidden prototype property");
      for (const s in r) {
        const a = r[s];
        a && typeof a == "object" && e.push(a);
      }
    }
  }
  return t;
}
function Dp(t) {
  const { stackTraceLimit: e } = Error;
  try {
    Error.stackTraceLimit = 0;
  } catch {
    return Ba(t);
  }
  try {
    return Ba(t);
  } finally {
    Error.stackTraceLimit = e;
  }
}
function $s(t) {
  if (t.type === "object" || Array.isArray(t.type) && t.type.includes("object")) {
    t.additionalProperties = !1;
    const { properties: n } = t;
    if (n != null)
      for (const r of Object.keys(n))
        n[r] = ot(n[r]);
  }
  t.items != null && (t.items = Array.isArray(t.items) ? t.items.map(ot) : ot(t.items)), t.anyOf != null && (t.anyOf = t.anyOf.map(ot)), t.allOf != null && (t.allOf = t.allOf.map(ot)), t.oneOf != null && (t.oneOf = t.oneOf.map(ot));
  const { definitions: e } = t;
  if (e != null)
    for (const n of Object.keys(e))
      e[n] = ot(e[n]);
  return t;
}
function ot(t) {
  return typeof t == "boolean" ? t : $s(t);
}
var Bp = /* @__PURE__ */ Symbol(
  "Let zodToJsonSchema decide on which parser to use"
), Fa = {
  name: void 0,
  $refStrategy: "root",
  basePath: ["#"],
  effectStrategy: "input",
  pipeStrategy: "all",
  dateStrategy: "format:date-time",
  mapStrategy: "entries",
  removeAdditionalStrategy: "passthrough",
  allowedAdditionalProperties: !0,
  rejectedAdditionalProperties: !1,
  definitionPath: "definitions",
  strictUnions: !1,
  definitions: {},
  errorMessages: !1,
  patternStrategy: "escape",
  applyRegexFlags: !1,
  emailStrategy: "format:email",
  base64Strategy: "contentEncoding:base64",
  nameStrategy: "ref"
}, Fp = (t) => typeof t == "string" ? {
  ...Fa,
  name: t
} : {
  ...Fa,
  ...t
};
function ve() {
  return {};
}
function Gp(t, e) {
  var n, r, s;
  const a = {
    type: "array"
  };
  return (n = t.type) != null && n._def && ((s = (r = t.type) == null ? void 0 : r._def) == null ? void 0 : s.typeName) !== D.ZodAny && (a.items = Z(t.type._def, {
    ...e,
    currentPath: [...e.currentPath, "items"]
  })), t.minLength && (a.minItems = t.minLength.value), t.maxLength && (a.maxItems = t.maxLength.value), t.exactLength && (a.minItems = t.exactLength.value, a.maxItems = t.exactLength.value), a;
}
function zp(t) {
  const e = {
    type: "integer",
    format: "int64"
  };
  if (!t.checks) return e;
  for (const n of t.checks)
    switch (n.kind) {
      case "min":
        n.inclusive ? e.minimum = n.value : e.exclusiveMinimum = n.value;
        break;
      case "max":
        n.inclusive ? e.maximum = n.value : e.exclusiveMaximum = n.value;
        break;
      case "multipleOf":
        e.multipleOf = n.value;
        break;
    }
  return e;
}
function Up() {
  return { type: "boolean" };
}
function jo(t, e) {
  return Z(t.type._def, e);
}
var Hp = (t, e) => Z(t.innerType._def, e);
function Ro(t, e, n) {
  const r = n ?? e.dateStrategy;
  if (Array.isArray(r))
    return {
      anyOf: r.map((s, a) => Ro(t, e, s))
    };
  switch (r) {
    case "string":
    case "format:date-time":
      return {
        type: "string",
        format: "date-time"
      };
    case "format:date":
      return {
        type: "string",
        format: "date"
      };
    case "integer":
      return qp(t);
  }
}
var qp = (t) => {
  const e = {
    type: "integer",
    format: "unix-time"
  };
  for (const n of t.checks)
    switch (n.kind) {
      case "min":
        e.minimum = n.value;
        break;
      case "max":
        e.maximum = n.value;
        break;
    }
  return e;
};
function Wp(t, e) {
  return {
    ...Z(t.innerType._def, e),
    default: t.defaultValue()
  };
}
function Zp(t, e) {
  return e.effectStrategy === "input" ? Z(t.schema._def, e) : ve();
}
function Vp(t) {
  return {
    type: "string",
    enum: Array.from(t.values)
  };
}
var Jp = (t) => "type" in t && t.type === "string" ? !1 : "allOf" in t;
function Qp(t, e) {
  const n = [
    Z(t.left._def, {
      ...e,
      currentPath: [...e.currentPath, "allOf", "0"]
    }),
    Z(t.right._def, {
      ...e,
      currentPath: [...e.currentPath, "allOf", "1"]
    })
  ].filter((s) => !!s), r = [];
  return n.forEach((s) => {
    if (Jp(s))
      r.push(...s.allOf);
    else {
      let a = s;
      if ("additionalProperties" in s && s.additionalProperties === !1) {
        const { additionalProperties: i, ...o } = s;
        a = o;
      }
      r.push(a);
    }
  }), r.length ? { allOf: r } : void 0;
}
function Yp(t) {
  const e = typeof t.value;
  return e !== "bigint" && e !== "number" && e !== "boolean" && e !== "string" ? {
    type: Array.isArray(t.value) ? "array" : "object"
  } : {
    type: e === "bigint" ? "integer" : e,
    const: t.value
  };
}
var Rr = void 0, je = {
  /**
   * `c` was changed to `[cC]` to replicate /i flag
   */
  cuid: /^[cC][^\s-]{8,}$/,
  cuid2: /^[0-9a-z]+$/,
  ulid: /^[0-9A-HJKMNP-TV-Z]{26}$/,
  /**
   * `a-z` was added to replicate /i flag
   */
  email: /^(?!\.)(?!.*\.\.)([a-zA-Z0-9_'+\-\.]*)[a-zA-Z0-9_+-]@([a-zA-Z0-9][a-zA-Z0-9\-]*\.)+[a-zA-Z]{2,}$/,
  /**
   * Constructed a valid Unicode RegExp
   *
   * Lazily instantiate since this type of regex isn't supported
   * in all envs (e.g. React Native).
   *
   * See:
   * https://github.com/colinhacks/zod/issues/2433
   * Fix in Zod:
   * https://github.com/colinhacks/zod/commit/9340fd51e48576a75adc919bff65dbc4a5d4c99b
   */
  emoji: () => (Rr === void 0 && (Rr = RegExp(
    "^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$",
    "u"
  )), Rr),
  /**
   * Unused
   */
  uuid: /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/,
  /**
   * Unused
   */
  ipv4: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
  ipv4Cidr: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,
  /**
   * Unused
   */
  ipv6: /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/,
  ipv6Cidr: /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
  base64: /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,
  base64url: /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,
  nanoid: /^[a-zA-Z0-9_-]{21}$/,
  jwt: /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/
};
function Po(t, e) {
  const n = {
    type: "string"
  };
  if (t.checks)
    for (const r of t.checks)
      switch (r.kind) {
        case "min":
          n.minLength = typeof n.minLength == "number" ? Math.max(n.minLength, r.value) : r.value;
          break;
        case "max":
          n.maxLength = typeof n.maxLength == "number" ? Math.min(n.maxLength, r.value) : r.value;
          break;
        case "email":
          switch (e.emailStrategy) {
            case "format:email":
              Re(n, "email", r.message, e);
              break;
            case "format:idn-email":
              Re(n, "idn-email", r.message, e);
              break;
            case "pattern:zod":
              ge(n, je.email, r.message, e);
              break;
          }
          break;
        case "url":
          Re(n, "uri", r.message, e);
          break;
        case "uuid":
          Re(n, "uuid", r.message, e);
          break;
        case "regex":
          ge(n, r.regex, r.message, e);
          break;
        case "cuid":
          ge(n, je.cuid, r.message, e);
          break;
        case "cuid2":
          ge(n, je.cuid2, r.message, e);
          break;
        case "startsWith":
          ge(
            n,
            RegExp(`^${Pr(r.value, e)}`),
            r.message,
            e
          );
          break;
        case "endsWith":
          ge(
            n,
            RegExp(`${Pr(r.value, e)}$`),
            r.message,
            e
          );
          break;
        case "datetime":
          Re(n, "date-time", r.message, e);
          break;
        case "date":
          Re(n, "date", r.message, e);
          break;
        case "time":
          Re(n, "time", r.message, e);
          break;
        case "duration":
          Re(n, "duration", r.message, e);
          break;
        case "length":
          n.minLength = typeof n.minLength == "number" ? Math.max(n.minLength, r.value) : r.value, n.maxLength = typeof n.maxLength == "number" ? Math.min(n.maxLength, r.value) : r.value;
          break;
        case "includes": {
          ge(
            n,
            RegExp(Pr(r.value, e)),
            r.message,
            e
          );
          break;
        }
        case "ip": {
          r.version !== "v6" && Re(n, "ipv4", r.message, e), r.version !== "v4" && Re(n, "ipv6", r.message, e);
          break;
        }
        case "base64url":
          ge(n, je.base64url, r.message, e);
          break;
        case "jwt":
          ge(n, je.jwt, r.message, e);
          break;
        case "cidr": {
          r.version !== "v6" && ge(n, je.ipv4Cidr, r.message, e), r.version !== "v4" && ge(n, je.ipv6Cidr, r.message, e);
          break;
        }
        case "emoji":
          ge(n, je.emoji(), r.message, e);
          break;
        case "ulid": {
          ge(n, je.ulid, r.message, e);
          break;
        }
        case "base64": {
          switch (e.base64Strategy) {
            case "format:binary": {
              Re(n, "binary", r.message, e);
              break;
            }
            case "contentEncoding:base64": {
              n.contentEncoding = "base64";
              break;
            }
            case "pattern:zod": {
              ge(n, je.base64, r.message, e);
              break;
            }
          }
          break;
        }
        case "nanoid":
          ge(n, je.nanoid, r.message, e);
      }
  return n;
}
function Pr(t, e) {
  return e.patternStrategy === "escape" ? Kp(t) : t;
}
var Xp = new Set(
  "ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvxyz0123456789"
);
function Kp(t) {
  let e = "";
  for (let n = 0; n < t.length; n++)
    Xp.has(t[n]) || (e += "\\"), e += t[n];
  return e;
}
function Re(t, e, n, r) {
  var s;
  t.format || (s = t.anyOf) != null && s.some((a) => a.format) ? (t.anyOf || (t.anyOf = []), t.format && (t.anyOf.push({
    format: t.format
  }), delete t.format), t.anyOf.push({
    format: e,
    ...n && r.errorMessages && { errorMessage: { format: n } }
  })) : t.format = e;
}
function ge(t, e, n, r) {
  var s;
  t.pattern || (s = t.allOf) != null && s.some((a) => a.pattern) ? (t.allOf || (t.allOf = []), t.pattern && (t.allOf.push({
    pattern: t.pattern
  }), delete t.pattern), t.allOf.push({
    pattern: Ga(e, r),
    ...n && r.errorMessages && { errorMessage: { pattern: n } }
  })) : t.pattern = Ga(e, r);
}
function Ga(t, e) {
  var n;
  if (!e.applyRegexFlags || !t.flags)
    return t.source;
  const r = {
    i: t.flags.includes("i"),
    // Case-insensitive
    m: t.flags.includes("m"),
    // `^` and `$` matches adjacent to newline characters
    s: t.flags.includes("s")
    // `.` matches newlines
  }, s = r.i ? t.source.toLowerCase() : t.source;
  let a = "", i = !1, o = !1, l = !1;
  for (let c = 0; c < s.length; c++) {
    if (i) {
      a += s[c], i = !1;
      continue;
    }
    if (r.i) {
      if (o) {
        if (s[c].match(/[a-z]/)) {
          l ? (a += s[c], a += `${s[c - 2]}-${s[c]}`.toUpperCase(), l = !1) : s[c + 1] === "-" && ((n = s[c + 2]) != null && n.match(/[a-z]/)) ? (a += s[c], l = !0) : a += `${s[c]}${s[c].toUpperCase()}`;
          continue;
        }
      } else if (s[c].match(/[a-z]/)) {
        a += `[${s[c]}${s[c].toUpperCase()}]`;
        continue;
      }
    }
    if (r.m) {
      if (s[c] === "^") {
        a += `(^|(?<=[\r
]))`;
        continue;
      } else if (s[c] === "$") {
        a += `($|(?=[\r
]))`;
        continue;
      }
    }
    if (r.s && s[c] === ".") {
      a += o ? `${s[c]}\r
` : `[${s[c]}\r
]`;
      continue;
    }
    a += s[c], s[c] === "\\" ? i = !0 : o && s[c] === "]" ? o = !1 : !o && s[c] === "[" && (o = !0);
  }
  try {
    new RegExp(a);
  } catch {
    return console.warn(
      `Could not convert regex pattern at ${e.currentPath.join(
        "/"
      )} to a flag-independent form! Falling back to the flag-ignorant source`
    ), t.source;
  }
  return a;
}
function Lo(t, e) {
  var n, r, s, a, i, o;
  const l = {
    type: "object",
    additionalProperties: (n = Z(t.valueType._def, {
      ...e,
      currentPath: [...e.currentPath, "additionalProperties"]
    })) != null ? n : e.allowedAdditionalProperties
  };
  if (((r = t.keyType) == null ? void 0 : r._def.typeName) === D.ZodString && ((s = t.keyType._def.checks) != null && s.length)) {
    const { type: c, ...d } = Po(t.keyType._def, e);
    return {
      ...l,
      propertyNames: d
    };
  } else {
    if (((a = t.keyType) == null ? void 0 : a._def.typeName) === D.ZodEnum)
      return {
        ...l,
        propertyNames: {
          enum: t.keyType._def.values
        }
      };
    if (((i = t.keyType) == null ? void 0 : i._def.typeName) === D.ZodBranded && t.keyType._def.type._def.typeName === D.ZodString && ((o = t.keyType._def.type._def.checks) != null && o.length)) {
      const { type: c, ...d } = jo(
        t.keyType._def,
        e
      );
      return {
        ...l,
        propertyNames: d
      };
    }
  }
  return l;
}
function ed(t, e) {
  if (e.mapStrategy === "record")
    return Lo(t, e);
  const n = Z(t.keyType._def, {
    ...e,
    currentPath: [...e.currentPath, "items", "items", "0"]
  }) || ve(), r = Z(t.valueType._def, {
    ...e,
    currentPath: [...e.currentPath, "items", "items", "1"]
  }) || ve();
  return {
    type: "array",
    maxItems: 125,
    items: {
      type: "array",
      items: [n, r],
      minItems: 2,
      maxItems: 2
    }
  };
}
function td(t) {
  const e = t.values, r = Object.keys(t.values).filter((a) => typeof e[e[a]] != "number").map((a) => e[a]), s = Array.from(
    new Set(r.map((a) => typeof a))
  );
  return {
    type: s.length === 1 ? s[0] === "string" ? "string" : "number" : ["string", "number"],
    enum: r
  };
}
function nd() {
  return { not: ve() };
}
function rd() {
  return {
    type: "null"
  };
}
var rs = {
  ZodString: "string",
  ZodNumber: "number",
  ZodBigInt: "integer",
  ZodBoolean: "boolean",
  ZodNull: "null"
};
function sd(t, e) {
  const n = t.options instanceof Map ? Array.from(t.options.values()) : t.options;
  if (n.every(
    (r) => r._def.typeName in rs && (!r._def.checks || !r._def.checks.length)
  )) {
    const r = n.reduce((s, a) => {
      const i = rs[a._def.typeName];
      return i && !s.includes(i) ? [...s, i] : s;
    }, []);
    return {
      type: r.length > 1 ? r : r[0]
    };
  } else if (n.every((r) => r._def.typeName === "ZodLiteral" && !r.description)) {
    const r = n.reduce(
      (s, a) => {
        const i = typeof a._def.value;
        switch (i) {
          case "string":
          case "number":
          case "boolean":
            return [...s, i];
          case "bigint":
            return [...s, "integer"];
          case "object":
            if (a._def.value === null) return [...s, "null"];
          case "symbol":
          case "undefined":
          case "function":
          default:
            return s;
        }
      },
      []
    );
    if (r.length === n.length) {
      const s = r.filter((a, i, o) => o.indexOf(a) === i);
      return {
        type: s.length > 1 ? s : s[0],
        enum: n.reduce(
          (a, i) => a.includes(i._def.value) ? a : [...a, i._def.value],
          []
        )
      };
    }
  } else if (n.every((r) => r._def.typeName === "ZodEnum"))
    return {
      type: "string",
      enum: n.reduce(
        (r, s) => [
          ...r,
          ...s._def.values.filter((a) => !r.includes(a))
        ],
        []
      )
    };
  return ad(t, e);
}
var ad = (t, e) => {
  const n = (t.options instanceof Map ? Array.from(t.options.values()) : t.options).map(
    (r, s) => Z(r._def, {
      ...e,
      currentPath: [...e.currentPath, "anyOf", `${s}`]
    })
  ).filter(
    (r) => !!r && (!e.strictUnions || typeof r == "object" && Object.keys(r).length > 0)
  );
  return n.length ? { anyOf: n } : void 0;
};
function id(t, e) {
  if (["ZodString", "ZodNumber", "ZodBigInt", "ZodBoolean", "ZodNull"].includes(
    t.innerType._def.typeName
  ) && (!t.innerType._def.checks || !t.innerType._def.checks.length))
    return {
      type: [
        rs[t.innerType._def.typeName],
        "null"
      ]
    };
  const n = Z(t.innerType._def, {
    ...e,
    currentPath: [...e.currentPath, "anyOf", "0"]
  });
  return n && { anyOf: [n, { type: "null" }] };
}
function od(t) {
  const e = {
    type: "number"
  };
  if (!t.checks) return e;
  for (const n of t.checks)
    switch (n.kind) {
      case "int":
        e.type = "integer";
        break;
      case "min":
        n.inclusive ? e.minimum = n.value : e.exclusiveMinimum = n.value;
        break;
      case "max":
        n.inclusive ? e.maximum = n.value : e.exclusiveMaximum = n.value;
        break;
      case "multipleOf":
        e.multipleOf = n.value;
        break;
    }
  return e;
}
function ld(t, e) {
  const n = {
    type: "object",
    properties: {}
  }, r = [], s = t.shape();
  for (const i in s) {
    let o = s[i];
    if (o === void 0 || o._def === void 0)
      continue;
    const l = ud(o), c = Z(o._def, {
      ...e,
      currentPath: [...e.currentPath, "properties", i],
      propertyPath: [...e.currentPath, "properties", i]
    });
    c !== void 0 && (n.properties[i] = c, l || r.push(i));
  }
  r.length && (n.required = r);
  const a = cd(t, e);
  return a !== void 0 && (n.additionalProperties = a), n;
}
function cd(t, e) {
  if (t.catchall._def.typeName !== "ZodNever")
    return Z(t.catchall._def, {
      ...e,
      currentPath: [...e.currentPath, "additionalProperties"]
    });
  switch (t.unknownKeys) {
    case "passthrough":
      return e.allowedAdditionalProperties;
    case "strict":
      return e.rejectedAdditionalProperties;
    case "strip":
      return e.removeAdditionalStrategy === "strict" ? e.allowedAdditionalProperties : e.rejectedAdditionalProperties;
  }
}
function ud(t) {
  try {
    return t.isOptional();
  } catch {
    return !0;
  }
}
var pd = (t, e) => {
  var n;
  if (e.currentPath.toString() === ((n = e.propertyPath) == null ? void 0 : n.toString()))
    return Z(t.innerType._def, e);
  const r = Z(t.innerType._def, {
    ...e,
    currentPath: [...e.currentPath, "anyOf", "1"]
  });
  return r ? { anyOf: [{ not: ve() }, r] } : ve();
}, dd = (t, e) => {
  if (e.pipeStrategy === "input")
    return Z(t.in._def, e);
  if (e.pipeStrategy === "output")
    return Z(t.out._def, e);
  const n = Z(t.in._def, {
    ...e,
    currentPath: [...e.currentPath, "allOf", "0"]
  }), r = Z(t.out._def, {
    ...e,
    currentPath: [...e.currentPath, "allOf", n ? "1" : "0"]
  });
  return {
    allOf: [n, r].filter((s) => s !== void 0)
  };
};
function hd(t, e) {
  return Z(t.type._def, e);
}
function fd(t, e) {
  const r = {
    type: "array",
    uniqueItems: !0,
    items: Z(t.valueType._def, {
      ...e,
      currentPath: [...e.currentPath, "items"]
    })
  };
  return t.minSize && (r.minItems = t.minSize.value), t.maxSize && (r.maxItems = t.maxSize.value), r;
}
function md(t, e) {
  return t.rest ? {
    type: "array",
    minItems: t.items.length,
    items: t.items.map(
      (n, r) => Z(n._def, {
        ...e,
        currentPath: [...e.currentPath, "items", `${r}`]
      })
    ).reduce(
      (n, r) => r === void 0 ? n : [...n, r],
      []
    ),
    additionalItems: Z(t.rest._def, {
      ...e,
      currentPath: [...e.currentPath, "additionalItems"]
    })
  } : {
    type: "array",
    minItems: t.items.length,
    maxItems: t.items.length,
    items: t.items.map(
      (n, r) => Z(n._def, {
        ...e,
        currentPath: [...e.currentPath, "items", `${r}`]
      })
    ).reduce(
      (n, r) => r === void 0 ? n : [...n, r],
      []
    )
  };
}
function gd() {
  return {
    not: ve()
  };
}
function yd() {
  return ve();
}
var xd = (t, e) => Z(t.innerType._def, e), bd = (t, e, n) => {
  switch (e) {
    case D.ZodString:
      return Po(t, n);
    case D.ZodNumber:
      return od(t);
    case D.ZodObject:
      return ld(t, n);
    case D.ZodBigInt:
      return zp(t);
    case D.ZodBoolean:
      return Up();
    case D.ZodDate:
      return Ro(t, n);
    case D.ZodUndefined:
      return gd();
    case D.ZodNull:
      return rd();
    case D.ZodArray:
      return Gp(t, n);
    case D.ZodUnion:
    case D.ZodDiscriminatedUnion:
      return sd(t, n);
    case D.ZodIntersection:
      return Qp(t, n);
    case D.ZodTuple:
      return md(t, n);
    case D.ZodRecord:
      return Lo(t, n);
    case D.ZodLiteral:
      return Yp(t);
    case D.ZodEnum:
      return Vp(t);
    case D.ZodNativeEnum:
      return td(t);
    case D.ZodNullable:
      return id(t, n);
    case D.ZodOptional:
      return pd(t, n);
    case D.ZodMap:
      return ed(t, n);
    case D.ZodSet:
      return fd(t, n);
    case D.ZodLazy:
      return () => t.getter()._def;
    case D.ZodPromise:
      return hd(t, n);
    case D.ZodNaN:
    case D.ZodNever:
      return nd();
    case D.ZodEffects:
      return Zp(t, n);
    case D.ZodAny:
      return ve();
    case D.ZodUnknown:
      return yd();
    case D.ZodDefault:
      return Wp(t, n);
    case D.ZodBranded:
      return jo(t, n);
    case D.ZodReadonly:
      return xd(t, n);
    case D.ZodCatch:
      return Hp(t, n);
    case D.ZodPipeline:
      return dd(t, n);
    case D.ZodFunction:
    case D.ZodVoid:
    case D.ZodSymbol:
      return;
    default:
      return /* @__PURE__ */ ((r) => {
      })();
  }
}, wd = (t, e) => {
  let n = 0;
  for (; n < t.length && n < e.length && t[n] === e[n]; n++)
    ;
  return [(t.length - n).toString(), ...e.slice(n)].join("/");
};
function Z(t, e, n = !1) {
  var r;
  const s = e.seen.get(t);
  if (e.override) {
    const l = (r = e.override) == null ? void 0 : r.call(
      e,
      t,
      e,
      s,
      n
    );
    if (l !== Bp)
      return l;
  }
  if (s && !n) {
    const l = kd(s, e);
    if (l !== void 0)
      return l;
  }
  const a = { def: t, path: e.currentPath, jsonSchema: void 0 };
  e.seen.set(t, a);
  const i = bd(t, t.typeName, e), o = typeof i == "function" ? Z(i(), e) : i;
  if (o && vd(t, e, o), e.postProcess) {
    const l = e.postProcess(o, t, e);
    return a.jsonSchema = o, l;
  }
  return a.jsonSchema = o, o;
}
var kd = (t, e) => {
  switch (e.$refStrategy) {
    case "root":
      return { $ref: t.path.join("/") };
    case "relative":
      return { $ref: wd(e.currentPath, t.path) };
    case "none":
    case "seen":
      return t.path.length < e.currentPath.length && t.path.every((n, r) => e.currentPath[r] === n) ? (console.warn(
        `Recursive reference detected at ${e.currentPath.join(
          "/"
        )}! Defaulting to any`
      ), ve()) : e.$refStrategy === "seen" ? ve() : void 0;
  }
}, vd = (t, e, n) => (t.description && (n.description = t.description), n), _d = (t) => {
  const e = Fp(t), n = e.name !== void 0 ? [...e.basePath, e.definitionPath, e.name] : e.basePath;
  return {
    ...e,
    currentPath: n,
    propertyPath: void 0,
    seen: new Map(
      Object.entries(e.definitions).map(([r, s]) => [
        s._def,
        {
          def: s._def,
          path: [...e.basePath, e.definitionPath, r],
          // Resolution of references will be forced even though seen, so it's ok that the schema is undefined here for now.
          jsonSchema: void 0
        }
      ])
    )
  };
}, Sd = (t, e) => {
  var n;
  const r = _d(e);
  let s = typeof e == "object" && e.definitions ? Object.entries(e.definitions).reduce(
    (c, [d, p]) => {
      var h;
      return {
        ...c,
        [d]: (h = Z(
          p._def,
          {
            ...r,
            currentPath: [...r.basePath, r.definitionPath, d]
          },
          !0
        )) != null ? h : ve()
      };
    },
    {}
  ) : void 0;
  const a = typeof e == "string" ? e : (e == null ? void 0 : e.nameStrategy) === "title" || e == null ? void 0 : e.name, i = (n = Z(
    t._def,
    a === void 0 ? r : {
      ...r,
      currentPath: [...r.basePath, r.definitionPath, a]
    },
    !1
  )) != null ? n : ve(), o = typeof e == "object" && e.name !== void 0 && e.nameStrategy === "title" ? e.name : void 0;
  o !== void 0 && (i.title = o);
  const l = a === void 0 ? s ? {
    ...i,
    [r.definitionPath]: s
  } : i : {
    $ref: [
      ...r.$refStrategy === "relative" ? [] : r.basePath,
      r.definitionPath,
      a
    ].join("/"),
    [r.definitionPath]: {
      ...s,
      [a]: i
    }
  };
  return l.$schema = "http://json-schema.org/draft-07/schema#", l;
}, ss = /* @__PURE__ */ Symbol.for("vercel.ai.schema");
function lr(t, {
  validate: e
} = {}) {
  return {
    [ss]: !0,
    _type: void 0,
    // should never be used directly
    get jsonSchema() {
      return typeof t == "function" && (t = t()), t;
    },
    validate: e
  };
}
function Cd(t) {
  return typeof t == "object" && t !== null && ss in t && t[ss] === !0 && "jsonSchema" in t && "validate" in t;
}
function Os(t) {
  return t == null ? lr({ properties: {}, additionalProperties: !1 }) : Cd(t) ? t : "~standard" in t ? t["~standard"].vendor === "zod" ? Ed(t) : Nd(t) : t();
}
function Nd(t) {
  return lr(
    () => $s(
      t["~standard"].jsonSchema.input({
        target: "draft-07"
      })
    ),
    {
      validate: async (e) => {
        const n = await t["~standard"].validate(e);
        return "value" in n ? { success: !0, value: n.value } : {
          success: !1,
          error: new Yt({
            value: e,
            cause: n.issues
          })
        };
      }
    }
  );
}
function Ad(t, e) {
  var n;
  const r = (n = void 0) != null ? n : !1;
  return lr(
    // defer json schema creation to avoid unnecessary computation when only validation is needed
    () => Sd(t, {
      $refStrategy: r ? "root" : "none"
    }),
    {
      validate: async (s) => {
        const a = await t.safeParseAsync(s);
        return a.success ? { success: !0, value: a.data } : { success: !1, error: a.error };
      }
    }
  );
}
function Id(t, e) {
  var n;
  const r = (n = void 0) != null ? n : !1;
  return lr(
    // defer json schema creation to avoid unnecessary computation when only validation is needed
    () => $s(
      Hc(t, {
        target: "draft-7",
        io: "input",
        reused: r ? "ref" : "inline"
      })
    ),
    {
      validate: async (s) => {
        const a = await Uc(t, s);
        return a.success ? { success: !0, value: a.data } : { success: !1, error: a.error };
      }
    }
  );
}
function Td(t) {
  return "_zod" in t;
}
function Ed(t, e) {
  return Td(t) ? Id(t) : Ad(t);
}
async function zn({
  value: t,
  schema: e,
  context: n
}) {
  const r = Os(e);
  try {
    if (r.validate == null)
      return { success: !0, value: t, rawValue: t };
    const s = await r.validate(t);
    return s.success ? { success: !0, value: s.value, rawValue: t } : {
      success: !1,
      error: Yt.wrap({ value: t, cause: s.error, context: n }),
      rawValue: t
    };
  } catch (s) {
    return {
      success: !1,
      error: Yt.wrap({ value: t, cause: s, context: n }),
      rawValue: t
    };
  }
}
async function Rt({
  text: t,
  schema: e
}) {
  try {
    const n = Dp(t);
    return e == null ? { success: !0, value: n, rawValue: n } : await zn({ value: n, schema: e });
  } catch (n) {
    return {
      success: !1,
      error: La.isInstance(n) ? n : new La({ text: t, cause: n }),
      rawValue: void 0
    };
  }
}
async function $o(t) {
  return typeof t == "function" && (t = t()), Promise.resolve(t);
}
var jd = Object.defineProperty, Rd = (t, e) => {
  for (var n in e)
    jd(t, n, { get: e[n], enumerable: !0 });
}, Oo = "AI_NoObjectGeneratedError", Mo = `vercel.ai.error.${Oo}`, Pd = Symbol.for(Mo), Do, et = class extends rt {
  constructor({
    message: t = "No object generated.",
    cause: e,
    text: n,
    response: r,
    usage: s,
    finishReason: a
  }) {
    super({ name: Oo, message: t, cause: e }), this[Do] = !0, this.text = n, this.response = r, this.usage = s, this.finishReason = a;
  }
  static isInstance(t) {
    return rt.hasMarker(t, Mo);
  }
};
Do = Pd;
var Bo = ke([
  P(),
  Ln(Uint8Array),
  Ln(ArrayBuffer),
  qc(
    // Buffer might not be available in some environments such as CloudFlare:
    (t) => {
      var e, n;
      return (n = (e = globalThis.Buffer) == null ? void 0 : e.isBuffer(t)) != null ? n : !1;
    },
    { message: "Must be a Buffer" }
  )
]), Kt = Wc(
  () => ke([
    Zc(),
    P(),
    Is(),
    Ts(),
    yt(P(), Kt.optional()),
    We(Kt)
  ])
), te = yt(
  P(),
  yt(P(), Kt.optional())
), Fo = G({
  type: q("text"),
  text: P(),
  providerOptions: te.optional()
}), Ld = G({
  type: q("image"),
  image: ke([Bo, Ln(URL)]),
  mediaType: P().optional(),
  providerOptions: te.optional()
}), Go = G({
  type: q("file"),
  data: ke([Bo, Ln(URL)]),
  filename: P().optional(),
  mediaType: P(),
  providerOptions: te.optional()
}), $d = G({
  type: q("reasoning"),
  text: P(),
  providerOptions: te.optional()
}), Od = G({
  type: q("tool-call"),
  toolCallId: P(),
  toolName: P(),
  input: Pn(),
  providerOptions: te.optional(),
  providerExecuted: Ts().optional()
}), Md = Hi(
  "type",
  [
    G({
      type: q("text"),
      value: P(),
      providerOptions: te.optional()
    }),
    G({
      type: q("json"),
      value: Kt,
      providerOptions: te.optional()
    }),
    G({
      type: q("execution-denied"),
      reason: P().optional(),
      providerOptions: te.optional()
    }),
    G({
      type: q("error-text"),
      value: P(),
      providerOptions: te.optional()
    }),
    G({
      type: q("error-json"),
      value: Kt,
      providerOptions: te.optional()
    }),
    G({
      type: q("content"),
      value: We(
        ke([
          G({
            type: q("text"),
            text: P(),
            providerOptions: te.optional()
          }),
          G({
            type: q("media"),
            data: P(),
            mediaType: P()
          }),
          G({
            type: q("file-data"),
            data: P(),
            mediaType: P(),
            filename: P().optional(),
            providerOptions: te.optional()
          }),
          G({
            type: q("file-url"),
            url: P(),
            providerOptions: te.optional()
          }),
          G({
            type: q("file-id"),
            fileId: ke([P(), yt(P(), P())]),
            providerOptions: te.optional()
          }),
          G({
            type: q("image-data"),
            data: P(),
            mediaType: P(),
            providerOptions: te.optional()
          }),
          G({
            type: q("image-url"),
            url: P(),
            providerOptions: te.optional()
          }),
          G({
            type: q("image-file-id"),
            fileId: ke([P(), yt(P(), P())]),
            providerOptions: te.optional()
          }),
          G({
            type: q("custom"),
            providerOptions: te.optional()
          })
        ])
      )
    })
  ]
), zo = G({
  type: q("tool-result"),
  toolCallId: P(),
  toolName: P(),
  output: Md,
  providerOptions: te.optional()
}), Dd = G({
  type: q("tool-approval-request"),
  approvalId: P(),
  toolCallId: P()
}), Bd = G({
  type: q("tool-approval-response"),
  approvalId: P(),
  approved: Ts(),
  reason: P().optional()
}), Fd = G(
  {
    role: q("system"),
    content: P(),
    providerOptions: te.optional()
  }
), Gd = G({
  role: q("user"),
  content: ke([
    P(),
    We(ke([Fo, Ld, Go]))
  ]),
  providerOptions: te.optional()
}), zd = G({
  role: q("assistant"),
  content: ke([
    P(),
    We(
      ke([
        Fo,
        Go,
        $d,
        Od,
        zo,
        Dd
      ])
    )
  ]),
  providerOptions: te.optional()
}), Ud = G({
  role: q("tool"),
  content: We(ke([zo, Bd])),
  providerOptions: te.optional()
});
ke([
  Fd,
  Gd,
  zd,
  Ud
]);
var Hd = {};
Rd(Hd, {
  array: () => Vd,
  choice: () => Jd,
  json: () => Qd,
  object: () => Zd,
  text: () => Wd
});
function qd(t) {
  const e = ["ROOT"];
  let n = -1, r = null;
  function s(l, c, d) {
    switch (l) {
      case '"': {
        n = c, e.pop(), e.push(d), e.push("INSIDE_STRING");
        break;
      }
      case "f":
      case "t":
      case "n": {
        n = c, r = c, e.pop(), e.push(d), e.push("INSIDE_LITERAL");
        break;
      }
      case "-": {
        e.pop(), e.push(d), e.push("INSIDE_NUMBER");
        break;
      }
      case "0":
      case "1":
      case "2":
      case "3":
      case "4":
      case "5":
      case "6":
      case "7":
      case "8":
      case "9": {
        n = c, e.pop(), e.push(d), e.push("INSIDE_NUMBER");
        break;
      }
      case "{": {
        n = c, e.pop(), e.push(d), e.push("INSIDE_OBJECT_START");
        break;
      }
      case "[": {
        n = c, e.pop(), e.push(d), e.push("INSIDE_ARRAY_START");
        break;
      }
    }
  }
  function a(l, c) {
    switch (l) {
      case ",": {
        e.pop(), e.push("INSIDE_OBJECT_AFTER_COMMA");
        break;
      }
      case "}": {
        n = c, e.pop();
        break;
      }
    }
  }
  function i(l, c) {
    switch (l) {
      case ",": {
        e.pop(), e.push("INSIDE_ARRAY_AFTER_COMMA");
        break;
      }
      case "]": {
        n = c, e.pop();
        break;
      }
    }
  }
  for (let l = 0; l < t.length; l++) {
    const c = t[l];
    switch (e[e.length - 1]) {
      case "ROOT":
        s(c, l, "FINISH");
        break;
      case "INSIDE_OBJECT_START": {
        switch (c) {
          case '"': {
            e.pop(), e.push("INSIDE_OBJECT_KEY");
            break;
          }
          case "}": {
            n = l, e.pop();
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_AFTER_COMMA": {
        switch (c) {
          case '"': {
            e.pop(), e.push("INSIDE_OBJECT_KEY");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_KEY": {
        switch (c) {
          case '"': {
            e.pop(), e.push("INSIDE_OBJECT_AFTER_KEY");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_AFTER_KEY": {
        switch (c) {
          case ":": {
            e.pop(), e.push("INSIDE_OBJECT_BEFORE_VALUE");
            break;
          }
        }
        break;
      }
      case "INSIDE_OBJECT_BEFORE_VALUE": {
        s(c, l, "INSIDE_OBJECT_AFTER_VALUE");
        break;
      }
      case "INSIDE_OBJECT_AFTER_VALUE": {
        a(c, l);
        break;
      }
      case "INSIDE_STRING": {
        switch (c) {
          case '"': {
            e.pop(), n = l;
            break;
          }
          case "\\": {
            e.push("INSIDE_STRING_ESCAPE");
            break;
          }
          default:
            n = l;
        }
        break;
      }
      case "INSIDE_ARRAY_START": {
        switch (c) {
          case "]": {
            n = l, e.pop();
            break;
          }
          default: {
            n = l, s(c, l, "INSIDE_ARRAY_AFTER_VALUE");
            break;
          }
        }
        break;
      }
      case "INSIDE_ARRAY_AFTER_VALUE": {
        switch (c) {
          case ",": {
            e.pop(), e.push("INSIDE_ARRAY_AFTER_COMMA");
            break;
          }
          case "]": {
            n = l, e.pop();
            break;
          }
          default: {
            n = l;
            break;
          }
        }
        break;
      }
      case "INSIDE_ARRAY_AFTER_COMMA": {
        s(c, l, "INSIDE_ARRAY_AFTER_VALUE");
        break;
      }
      case "INSIDE_STRING_ESCAPE": {
        e.pop(), n = l;
        break;
      }
      case "INSIDE_NUMBER": {
        switch (c) {
          case "0":
          case "1":
          case "2":
          case "3":
          case "4":
          case "5":
          case "6":
          case "7":
          case "8":
          case "9": {
            n = l;
            break;
          }
          case "e":
          case "E":
          case "-":
          case ".":
            break;
          case ",": {
            e.pop(), e[e.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && i(c, l), e[e.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" && a(c, l);
            break;
          }
          case "}": {
            e.pop(), e[e.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" && a(c, l);
            break;
          }
          case "]": {
            e.pop(), e[e.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && i(c, l);
            break;
          }
          default: {
            e.pop();
            break;
          }
        }
        break;
      }
      case "INSIDE_LITERAL": {
        const p = t.substring(r, l + 1);
        !"false".startsWith(p) && !"true".startsWith(p) && !"null".startsWith(p) ? (e.pop(), e[e.length - 1] === "INSIDE_OBJECT_AFTER_VALUE" ? a(c, l) : e[e.length - 1] === "INSIDE_ARRAY_AFTER_VALUE" && i(c, l)) : n = l;
        break;
      }
    }
  }
  let o = t.slice(0, n + 1);
  for (let l = e.length - 1; l >= 0; l--)
    switch (e[l]) {
      case "INSIDE_STRING": {
        o += '"';
        break;
      }
      case "INSIDE_OBJECT_KEY":
      case "INSIDE_OBJECT_AFTER_KEY":
      case "INSIDE_OBJECT_AFTER_COMMA":
      case "INSIDE_OBJECT_START":
      case "INSIDE_OBJECT_BEFORE_VALUE":
      case "INSIDE_OBJECT_AFTER_VALUE": {
        o += "}";
        break;
      }
      case "INSIDE_ARRAY_START":
      case "INSIDE_ARRAY_AFTER_COMMA":
      case "INSIDE_ARRAY_AFTER_VALUE": {
        o += "]";
        break;
      }
      case "INSIDE_LITERAL": {
        const d = t.substring(r, t.length);
        "true".startsWith(d) ? o += "true".slice(d.length) : "false".startsWith(d) ? o += "false".slice(d.length) : "null".startsWith(d) && (o += "null".slice(d.length));
      }
    }
  return o;
}
async function cr(t) {
  if (t === void 0)
    return { value: void 0, state: "undefined-input" };
  let e = await Rt({ text: t });
  return e.success ? { value: e.value, state: "successful-parse" } : (e = await Rt({ text: qd(t) }), e.success ? { value: e.value, state: "repaired-parse" } : { value: void 0, state: "failed-parse" });
}
var Wd = () => ({
  name: "text",
  responseFormat: Promise.resolve({ type: "text" }),
  async parseCompleteOutput({ text: t }) {
    return t;
  },
  async parsePartialOutput({ text: t }) {
    return { partial: t };
  },
  createElementStreamTransform() {
  }
}), Zd = ({
  schema: t,
  name: e,
  description: n
}) => {
  const r = Os(t);
  return {
    name: "object",
    responseFormat: $o(r.jsonSchema).then((s) => ({
      type: "json",
      schema: s,
      ...e != null && { name: e },
      ...n != null && { description: n }
    })),
    async parseCompleteOutput({ text: s }, a) {
      const i = await Rt({ text: s });
      if (!i.success)
        throw new et({
          message: "No object generated: could not parse the response.",
          cause: i.error,
          text: s,
          response: a.response,
          usage: a.usage,
          finishReason: a.finishReason
        });
      const o = await zn({
        value: i.value,
        schema: r
      });
      if (!o.success)
        throw new et({
          message: "No object generated: response did not match schema.",
          cause: o.error,
          text: s,
          response: a.response,
          usage: a.usage,
          finishReason: a.finishReason
        });
      return o.value;
    },
    async parsePartialOutput({ text: s }) {
      const a = await cr(s);
      switch (a.state) {
        case "failed-parse":
        case "undefined-input":
          return;
        case "repaired-parse":
        case "successful-parse":
          return {
            // Note: currently no validation of partial results:
            partial: a.value
          };
      }
    },
    createElementStreamTransform() {
    }
  };
}, Vd = ({
  element: t,
  name: e,
  description: n
}) => {
  const r = Os(t);
  return {
    name: "array",
    // JSON schema that describes an array of elements:
    responseFormat: $o(r.jsonSchema).then((s) => {
      const { $schema: a, ...i } = s;
      return {
        type: "json",
        schema: {
          $schema: "http://json-schema.org/draft-07/schema#",
          type: "object",
          properties: {
            elements: { type: "array", items: i }
          },
          required: ["elements"],
          additionalProperties: !1
        },
        ...e != null && { name: e },
        ...n != null && { description: n }
      };
    }),
    async parseCompleteOutput({ text: s }, a) {
      const i = await Rt({ text: s });
      if (!i.success)
        throw new et({
          message: "No object generated: could not parse the response.",
          cause: i.error,
          text: s,
          response: a.response,
          usage: a.usage,
          finishReason: a.finishReason
        });
      const o = i.value;
      if (o == null || typeof o != "object" || !("elements" in o) || !Array.isArray(o.elements))
        throw new et({
          message: "No object generated: response did not match schema.",
          cause: new Yt({
            value: o,
            cause: "response must be an object with an elements array"
          }),
          text: s,
          response: a.response,
          usage: a.usage,
          finishReason: a.finishReason
        });
      for (const l of o.elements) {
        const c = await zn({
          value: l,
          schema: r
        });
        if (!c.success)
          throw new et({
            message: "No object generated: response did not match schema.",
            cause: c.error,
            text: s,
            response: a.response,
            usage: a.usage,
            finishReason: a.finishReason
          });
      }
      return o.elements;
    },
    async parsePartialOutput({ text: s }) {
      const a = await cr(s);
      switch (a.state) {
        case "failed-parse":
        case "undefined-input":
          return;
        case "repaired-parse":
        case "successful-parse": {
          const i = a.value;
          if (i == null || typeof i != "object" || !("elements" in i) || !Array.isArray(i.elements))
            return;
          const o = a.state === "repaired-parse" && i.elements.length > 0 ? i.elements.slice(0, -1) : i.elements, l = [];
          for (const c of o) {
            const d = await zn({
              value: c,
              schema: r
            });
            d.success && l.push(d.value);
          }
          return { partial: l };
        }
      }
    },
    createElementStreamTransform() {
      let s = 0;
      return new TransformStream({
        transform({ partialOutput: a }, i) {
          if (a != null)
            for (; s < a.length; s++)
              i.enqueue(a[s]);
        }
      });
    }
  };
}, Jd = ({
  options: t,
  name: e,
  description: n
}) => ({
  name: "choice",
  // JSON schema that describes an enumeration:
  responseFormat: Promise.resolve({
    type: "json",
    schema: {
      $schema: "http://json-schema.org/draft-07/schema#",
      type: "object",
      properties: {
        result: { type: "string", enum: t }
      },
      required: ["result"],
      additionalProperties: !1
    },
    ...e != null && { name: e },
    ...n != null && { description: n }
  }),
  async parseCompleteOutput({ text: r }, s) {
    const a = await Rt({ text: r });
    if (!a.success)
      throw new et({
        message: "No object generated: could not parse the response.",
        cause: a.error,
        text: r,
        response: s.response,
        usage: s.usage,
        finishReason: s.finishReason
      });
    const i = a.value;
    if (i == null || typeof i != "object" || !("result" in i) || typeof i.result != "string" || !t.includes(i.result))
      throw new et({
        message: "No object generated: response did not match schema.",
        cause: new Yt({
          value: i,
          cause: "response must be an object that contains a choice value."
        }),
        text: r,
        response: s.response,
        usage: s.usage,
        finishReason: s.finishReason
      });
    return i.result;
  },
  async parsePartialOutput({ text: r }) {
    const s = await cr(r);
    switch (s.state) {
      case "failed-parse":
      case "undefined-input":
        return;
      case "repaired-parse":
      case "successful-parse": {
        const a = s.value;
        if (a == null || typeof a != "object" || !("result" in a) || typeof a.result != "string")
          return;
        const i = t.filter(
          (o) => o.startsWith(a.result)
        );
        return s.state === "successful-parse" ? i.includes(a.result) ? { partial: a.result } : void 0 : i.length === 1 ? { partial: i[0] } : void 0;
      }
    }
  },
  createElementStreamTransform() {
  }
}), Qd = ({
  name: t,
  description: e
} = {}) => ({
  name: "json",
  responseFormat: Promise.resolve({
    type: "json",
    ...t != null && { name: t },
    ...e != null && { description: e }
  }),
  async parseCompleteOutput({ text: n }, r) {
    const s = await Rt({ text: n });
    if (!s.success)
      throw new et({
        message: "No object generated: could not parse the response.",
        cause: s.error,
        text: n,
        response: r.response,
        usage: r.usage,
        finishReason: r.finishReason
      });
    return s.value;
  },
  async parsePartialOutput({ text: n }) {
    const r = await cr(n);
    switch (r.state) {
      case "failed-parse":
      case "undefined-input":
        return;
      case "repaired-parse":
      case "successful-parse":
        return r.value === void 0 ? void 0 : { partial: r.value };
    }
  },
  createElementStreamTransform() {
  }
});
cn({
  prefix: "aitxt",
  size: 24
});
(class extends TransformStream {
  constructor() {
    super({
      transform(t, e) {
        e.enqueue(`data: ${JSON.stringify(t)}

`);
      },
      flush(t) {
        t.enqueue(`data: [DONE]

`);
      }
    });
  }
});
function Yd(t) {
  return t.type.startsWith("tool-");
}
function Uo(t) {
  return t.type === "dynamic-tool";
}
function Xd(t) {
  return Yd(t) || Uo(t);
}
function Kd(t) {
  return t.type.split("-").slice(1).join("-");
}
function eh(t) {
  return Uo(t) ? t.toolName : Kd(t);
}
cn({
  prefix: "aitxt",
  size: 24
});
cn({ prefix: "aiobj", size: 24 });
cn({ prefix: "aiobj", size: 24 });
function th(t) {
  return Xd(t);
}
function nh(t) {
  try {
    return eh(t);
  } catch {
    const e = t.toolName;
    return typeof e == "string" ? e : "unknown";
  }
}
function rh(t) {
  return t.state !== "input-streaming" && t.input !== void 0;
}
const sh = "ap_update_thinking_status", ah = /* @__PURE__ */ new Set([
  "ap_select_project",
  "ap_deselect_project",
  "ap_update_plan"
]), Ho = /* @__PURE__ */ new Set([
  "ap_show_connection_required",
  "ap_show_connection_picker",
  "ap_show_project_picker",
  "ap_show_questions",
  "ap_show_quick_replies"
]);
function ih(t) {
  return Ho.has(t);
}
function qo(t) {
  if (t.state === "output-error")
    return {
      state: "error",
      errorText: "errorText" in t && typeof t.errorText == "string" ? t.errorText : "Tool call failed"
    };
  if (t.state !== "output-available" || t.output == null)
    return { state: "pending" };
  const e = t.output;
  return { state: "success", data: typeof e == "string" ? (() => {
    try {
      return JSON.parse(e);
    } catch {
      return e;
    }
  })() : e };
}
function oh(t, e) {
  return qo(t);
}
function lh(t) {
  return t === sh;
}
function ch(t) {
  return t.state === "output-available" ? "completed" : t.state === "output-error" ? "failed" : t.state === "output-denied" ? "stopped" : "running";
}
function uh(t) {
  if (t.state === "output-available" && t.output !== void 0)
    return typeof t.output == "string" ? t.output : JSON.stringify(t.output);
  if (t.state === "output-error" && t.errorText)
    return t.errorText;
}
function ph(t) {
  return t.startsWith("@") ? t : `@activepieces/piece-${(t.startsWith("piece-") ? t.slice(6) : t).replace(/_/g, "-")}`;
}
function dh(t) {
  if (!t) return [];
  const e = [];
  if (typeof t.pieceName == "string" && e.push(t.pieceName), Array.isArray(t.pieceNames))
    for (const n of t.pieceNames)
      typeof n == "string" && e.push(n);
  return ln(t.settings) && typeof t.settings.pieceName == "string" && e.push(t.settings.pieceName), e.map(ph);
}
const K = {
  isAnyToolPart: th,
  getToolPartName: nh,
  isReady: rh,
  isDisplayTool: ih,
  isThinkingStatusTool: lh,
  deriveToolStatus: ch,
  extractToolOutputText: uh,
  extractPieceNames: dh,
  parseToolOutput: qo,
  parseTypedToolOutput: oh,
  HIDDEN_TOOL_NAMES: ah,
  DISPLAY_TOOL_NAMES: Ho
};
function mn({
  gateId: t,
  approved: e
}) {
  be.approveToolCall({ gateId: t, approved: e });
}
function hh(t) {
  if (!t || t.role !== "assistant") return [];
  const e = t.parts.find(
    (r) => K.isAnyToolPart(r) && K.getToolPartName(r) === "ap_show_questions"
  );
  if (!e || !K.isAnyToolPart(e)) return [];
  const n = e.input;
  return (n == null ? void 0 : n.questions) ?? [];
}
function fh(t) {
  if (!t || t.role !== "assistant") return null;
  const e = t.parts.find(
    (a) => K.isAnyToolPart(a) && K.getToolPartName(a) === "ap_request_plan_approval"
  );
  if (!e) return null;
  const n = K.parseTypedToolOutput(
    e,
    "ap_request_plan_approval"
  );
  if (n.state === "error" || n.state === "success" && !n.data.success) return null;
  const r = e.input, s = (r == null ? void 0 : r.steps) ?? [];
  return s.length === 0 ? null : { title: (r == null ? void 0 : r.planSummary) ?? "", steps: s };
}
const mh = () => Vc((t, e) => ({
  pendingApprovalRequest: null,
  pendingPlanApproval: null,
  planProgressUpdates: [],
  planRejected: !1,
  displayCard: null,
  quickReplies: [],
  dismissedApprovalGateId: null,
  dismissedPlanGateId: null,
  lastDismissedFormId: null,
  approveToolCall: () => {
    const n = e().pendingApprovalRequest;
    n && (t({ dismissedApprovalGateId: n.gateId }), mn({ gateId: n.gateId, approved: !0 }));
  },
  rejectToolCall: () => {
    const n = e().pendingApprovalRequest;
    n && (t({ dismissedApprovalGateId: n.gateId }), mn({ gateId: n.gateId, approved: !1 }));
  },
  dismissApproval: () => {
    const n = e().pendingApprovalRequest;
    n && t({ dismissedApprovalGateId: n.gateId });
  },
  approvePlan: () => {
    const n = e().pendingPlanApproval;
    n && (t({ dismissedPlanGateId: n.gateId }), mn({ gateId: n.gateId, approved: !0 }));
  },
  rejectPlan: () => {
    const n = e().pendingPlanApproval;
    n && (t({ dismissedPlanGateId: n.gateId, planRejected: !0 }), mn({ gateId: n.gateId, approved: !1 }));
  },
  dismissPlan: () => {
    const n = e().pendingPlanApproval;
    n && t({ dismissedPlanGateId: n.gateId });
  },
  dismissForm: (n) => {
    t({ lastDismissedFormId: n });
  },
  resetInteractions: () => {
    t({
      pendingApprovalRequest: null,
      pendingPlanApproval: null,
      planProgressUpdates: [],
      quickReplies: [],
      displayCard: null,
      planRejected: !1
    });
  }
}));
function gh(t) {
  return t.pendingApprovalRequest !== null && t.pendingApprovalRequest.gateId !== t.dismissedApprovalGateId;
}
function yh(t) {
  var e;
  return ((e = t.pendingApprovalRequest) == null ? void 0 : e.displayName) ?? null;
}
function Wo(t) {
  return t.pendingPlanApproval !== null && t.pendingPlanApproval.gateId !== t.dismissedPlanGateId;
}
function Zo({
  state: t,
  lastAssistantMessage: e
}) {
  var n;
  return ((n = t.displayCard) == null ? void 0 : n.type) === "data-questions" ? t.displayCard.data.questions ?? [] : hh(e);
}
function xh({
  state: t,
  lastAssistantMessage: e
}) {
  var r;
  return Zo({ state: t, lastAssistantMessage: e }).length > 0 && (((r = t.displayCard) == null ? void 0 : r.type) === "data-questions" || !!e && e.id !== t.lastDismissedFormId);
}
function Vo({
  state: t,
  lastAssistantMessage: e
}) {
  return t.pendingPlanApproval && t.pendingPlanApproval.steps.length > 0 ? {
    title: t.pendingPlanApproval.planSummary,
    steps: t.pendingPlanApproval.steps
  } : fh(e);
}
function Jo({
  state: t
}) {
  return t.planProgressUpdates;
}
function bh({
  state: t,
  isStreaming: e,
  isLastAssistant: n,
  lastAssistantMessage: r
}) {
  if (Vo({ state: t, lastAssistantMessage: r }) === null) return !1;
  const a = Jo({ state: t }).length > 0, i = (r == null ? void 0 : r.parts.some(
    (l) => K.isAnyToolPart(l) && K.getToolPartName(l) === "ap_request_plan_approval" && l.state === "output-available"
  )) ?? !1, o = a || i;
  return n ? !Wo(t) && !t.planRejected && (!e || o) : !e && o;
}
const ut = {
  hasActiveApproval: gh,
  approvalDisplayName: yh,
  hasPlanApproval: Wo,
  activeQuestions: Zo,
  hasActiveForm: xh,
  planProgress: Vo,
  effectivePlanUpdates: Jo,
  shouldShowPlan: bh
}, Ms = y.createContext(null);
function wh({ children: t }) {
  const e = y.useRef(null);
  return e.current || (e.current = mh()), /* @__PURE__ */ u.jsx(Ms.Provider, { value: e.current, children: t });
}
function ce(t) {
  const e = y.useContext(Ms);
  if (!e)
    throw new Error(
      "useChatStoreContext must be used within ChatStoreProvider"
    );
  return Jc(e, t);
}
function kh() {
  const t = y.useContext(Ms);
  if (!t)
    throw new Error("useChatStoreApi must be used within ChatStoreProvider");
  return t;
}
function Qo(t) {
  return t.replace(/^@activepieces\/piece-/, "");
}
function as(t) {
  return $n.convertEnumToHumanReadable(
    Qo(t).replace(/-/g, "_")
  );
}
function za({
  part: t,
  includeContext: e = !0
}) {
  const n = K.getToolPartName(t), r = /^mcp__[^_]+__(.+)$/.exec(n), s = r ? r[1] : n, a = $n.convertEnumToHumanReadable(
    s.replace(/^ap_/, "")
  );
  if (!e) return a;
  const i = ln(t.input) ? t.input : void 0, o = Yo({ input: i });
  return o ? `${a} — ${o}` : a;
}
function Yo({
  input: t
}) {
  if (!t) return null;
  const e = [];
  return typeof t.pieceName == "string" && e.push(as(t.pieceName)), typeof t.actionName == "string" && t.actionName ? e.push($n.convertEnumToHumanReadable(t.actionName)) : typeof t.displayName == "string" && t.displayName && e.push(t.displayName), typeof t.triggerName == "string" && t.triggerName && e.push($n.convertEnumToHumanReadable(t.triggerName)), typeof t.flowId == "string" && e.length === 0 && e.push(t.flowId.slice(0, 8)), typeof t.query == "string" && e.length === 0 && e.push(
    `"${t.query.slice(0, 30)}${t.query.length > 30 ? "…" : ""}"`
  ), ln(t.settings) && typeof t.settings.pieceName == "string" && e.length === 0 && e.push(as(t.settings.pieceName)), e.length > 0 ? e.join(" ") : null;
}
function vh(t) {
  const e = [];
  if (t.thoughts && e.push({ type: "reasoning", text: t.thoughts }), t.content && e.push({ type: "text", text: t.content }), t.toolCalls)
    for (const n of t.toolCalls)
      n.status === "completed" ? e.push({
        type: "dynamic-tool",
        toolCallId: n.toolCallId,
        toolName: n.title,
        title: n.title,
        state: "output-available",
        input: n.input ?? {},
        output: n.output
      }) : e.push({
        type: "dynamic-tool",
        toolCallId: n.toolCallId,
        toolName: n.title,
        title: n.title,
        state: "output-error",
        input: n.input ?? {},
        errorText: typeof n.output == "string" ? n.output : "Tool call failed"
      });
  return e;
}
function _h(t) {
  if (t.length === 0) return !1;
  const e = t[0];
  return Array.isArray(e.parts) && !("content" in e);
}
function Sh(t, e) {
  switch (t.type) {
    case Wt.TEXT:
      return { type: "text", text: t.text };
    case Wt.REASONING:
      return { type: "reasoning", text: t.text };
    case Wt.THINKING_STATUS:
      return {
        type: "dynamic-tool",
        toolCallId: `thinking-status-${e}`,
        toolName: "ap_update_thinking_status",
        title: "ap_update_thinking_status",
        state: "output-available",
        input: { status: t.text },
        output: JSON.stringify({ success: !0 })
      };
    case Wt.TOOL_CALL:
      return t.status === xo.COMPLETED ? {
        type: "dynamic-tool",
        toolCallId: t.toolCallId,
        toolName: t.toolName,
        title: t.toolName,
        state: "output-available",
        input: t.input,
        output: typeof t.output == "string" ? t.output : JSON.stringify(t.output)
      } : {
        type: "dynamic-tool",
        toolCallId: t.toolCallId,
        toolName: t.toolName,
        title: t.toolName,
        state: "output-error",
        input: t.input,
        errorText: t.errorText ?? "Tool call failed"
      };
    default: {
      const n = t;
      throw new Error(
        `Unknown persisted part type: ${JSON.stringify(n)}`
      );
    }
  }
}
function Ch(t) {
  return t.map((e, n) => ({
    id: `hist-${n}`,
    role: e.role,
    parts: e.parts.map((r, s) => Sh(r, s)),
    ...e.thinkingDurationMs !== void 0 && {
      thinkingDurationMs: e.thinkingDurationMs
    }
  }));
}
function Nh(t) {
  if (t.length === 0) return [];
  if (_h(t))
    return Ch(t);
  const e = t, n = [];
  for (let r = 0; r < e.length; r++) {
    const s = e[r], a = vh(s), i = n[n.length - 1];
    s.role === "assistant" && (i == null ? void 0 : i.role) === "assistant" ? i.parts.push(...a) : n.push({ id: `hist-${r}`, role: s.role, parts: a });
  }
  return n;
}
function Ah(t) {
  const e = t[t.length - 1];
  if (!e || e.role !== "assistant") return [];
  for (let n = e.parts.length - 1; n >= 0; n--) {
    const r = e.parts[n];
    if (K.isAnyToolPart(r) && K.getToolPartName(r) === "ap_show_quick_replies") {
      const s = r.input;
      if (s != null && s.replies)
        return s.replies;
    }
  }
  return [];
}
const ct = {
  formatToolLabel: ({ part: t }) => za({ part: t }),
  formatToolActionName: ({ part: t }) => za({ part: t, includeContext: !1 }),
  extractToolContext: Yo,
  stripPiecePrefix: Qo,
  humanizePieceName: as,
  mapHistoryToUIMessages: Nh,
  extractQuickRepliesFromHistory: Ah
};
function Ih({
  messageId: t
} = {}) {
  return {
    message: {
      id: t ?? `stream-${Date.now()}`,
      role: "assistant",
      parts: []
    },
    activeTextParts: {},
    activeReasoningParts: {},
    partialToolCalls: {},
    seenToolCallIds: /* @__PURE__ */ new Set()
  };
}
function Gt({
  state: t,
  toolCallId: e
}) {
  return t.message.parts.findIndex(
    (n) => n.type === "dynamic-tool" && "toolCallId" in n && n.toolCallId === e
  );
}
function zt({
  state: t,
  idx: e,
  fields: n
}) {
  const r = t.message.parts[e];
  n.state !== void 0 && (r.state = n.state), "input" in n && (r.input = n.input), "output" in n && (r.output = n.output), "errorText" in n && (r.errorText = n.errorText);
}
function Xo({
  state: t,
  chunk: e
}) {
  switch (e.type) {
    case "start": {
      e.messageId && (t.message.id = e.messageId);
      break;
    }
    case "text-start": {
      const n = t.message.parts.length;
      t.message.parts.push({ type: "text", text: "" }), t.activeTextParts[e.id] = n;
      break;
    }
    case "text-delta": {
      const n = t.activeTextParts[e.id];
      if (n === void 0) break;
      const r = t.message.parts[n];
      (r == null ? void 0 : r.type) === "text" && (r.text += e.delta);
      break;
    }
    case "text-end": {
      delete t.activeTextParts[e.id];
      break;
    }
    case "reasoning-start": {
      const n = t.message.parts.length;
      t.message.parts.push({ type: "reasoning", text: "" }), t.activeReasoningParts[e.id] = n;
      break;
    }
    case "reasoning-delta": {
      const n = t.activeReasoningParts[e.id];
      if (n === void 0) break;
      const r = t.message.parts[n];
      (r == null ? void 0 : r.type) === "reasoning" && (r.text += e.delta);
      break;
    }
    case "reasoning-end": {
      delete t.activeReasoningParts[e.id];
      break;
    }
    case "tool-input-start": {
      if (t.seenToolCallIds.has(e.toolCallId)) break;
      t.seenToolCallIds.add(e.toolCallId), t.message.parts.push({
        type: "dynamic-tool",
        toolCallId: e.toolCallId,
        toolName: e.toolName,
        title: e.title ?? e.toolName,
        state: "input-streaming",
        input: void 0
      }), t.partialToolCalls[e.toolCallId] = {
        toolName: e.toolName,
        inputText: ""
      };
      break;
    }
    case "tool-input-delta": {
      const n = t.partialToolCalls[e.toolCallId];
      if (!n) break;
      n.inputText += e.inputTextDelta;
      break;
    }
    case "tool-input-available": {
      const n = Gt({ state: t, toolCallId: e.toolCallId });
      if (n === -1) {
        if (t.seenToolCallIds.has(e.toolCallId)) break;
        t.seenToolCallIds.add(e.toolCallId), t.message.parts.push({
          type: "dynamic-tool",
          toolCallId: e.toolCallId,
          toolName: e.toolName,
          title: e.title ?? e.toolName,
          state: "input-available",
          input: e.input
        });
      } else
        zt({
          state: t,
          idx: n,
          fields: { state: "input-available", input: e.input }
        });
      delete t.partialToolCalls[e.toolCallId];
      break;
    }
    case "tool-input-error": {
      const n = Gt({ state: t, toolCallId: e.toolCallId });
      n === -1 ? (t.message.parts.push({
        type: "dynamic-tool",
        toolCallId: e.toolCallId,
        toolName: e.toolName,
        title: e.title ?? e.toolName,
        state: "output-error",
        input: e.input,
        errorText: e.errorText
      }), t.seenToolCallIds.add(e.toolCallId)) : zt({
        state: t,
        idx: n,
        fields: {
          state: "output-error",
          input: e.input,
          errorText: e.errorText
        }
      }), delete t.partialToolCalls[e.toolCallId];
      break;
    }
    case "tool-output-available": {
      const n = Gt({ state: t, toolCallId: e.toolCallId });
      if (n === -1) break;
      zt({
        state: t,
        idx: n,
        fields: { state: "output-available", output: e.output }
      });
      break;
    }
    case "tool-output-error": {
      const n = Gt({ state: t, toolCallId: e.toolCallId });
      if (n === -1) break;
      zt({
        state: t,
        idx: n,
        fields: { state: "output-error", errorText: e.errorText }
      });
      break;
    }
    case "tool-output-denied": {
      const n = Gt({ state: t, toolCallId: e.toolCallId });
      if (n === -1) break;
      zt({ state: t, idx: n, fields: { state: "output-denied" } });
      break;
    }
    case "start-step": {
      t.message.parts.push({ type: "step-start" });
      break;
    }
    case "finish-step": {
      t.activeTextParts = {}, t.activeReasoningParts = {};
      break;
    }
    case "source-url": {
      t.message.parts.push({
        type: "source-url",
        sourceId: e.sourceId,
        url: e.url,
        title: e.title
      });
      break;
    }
    case "source-document": {
      t.message.parts.push({
        type: "source-document",
        sourceId: e.sourceId,
        mediaType: e.mediaType,
        title: e.title,
        filename: e.filename
      });
      break;
    }
    case "file": {
      t.message.parts.push({
        type: "file",
        mediaType: e.mediaType,
        url: e.url
      });
      break;
    }
    case "finish":
    case "error":
    case "abort":
    case "message-metadata":
    case "tool-approval-request":
      break;
    default: {
      Th({ state: t, chunk: e });
      break;
    }
  }
}
function Th({
  state: t,
  chunk: e
}) {
  var n;
  if ((n = e.type) != null && n.startsWith("data-") && !e.transient) {
    if (e.id) {
      const r = t.message.parts.findIndex(
        (s) => "id" in s && s.id === e.id && s.type === e.type
      );
      if (r >= 0) {
        t.message.parts[r].data = e.data;
        return;
      }
    }
    t.message.parts.push(e);
  }
}
function Eh({
  state: t,
  chunks: e
}) {
  for (const n of e)
    Xo({ state: t, chunk: n });
}
function jh({
  chunks: t
}) {
  const e = [];
  for (const n of t)
    typeof n.type == "string" && n.type.startsWith("data-") && "data" in n && e.push({
      type: n.type,
      data: n.data
    });
  return e;
}
function Rh({ state: t }) {
  return {
    ...t.message,
    parts: t.message.parts.map((e) => ({ ...e }))
  };
}
const gn = {
  createStreamingState: Ih,
  applyChunk: Xo,
  applyChunks: Eh,
  extractDataParts: jh,
  snapshotMessage: Rh
}, Ph = 100, Ua = 10 * 60 * 1e3;
function Lh({
  onDataPart: t,
  onStreamFinished: e,
  onStreamError: n
}) {
  const r = Qc(), [s, a] = y.useState(null), [i, o] = y.useState("idle"), [l, c] = y.useState(null), d = y.useRef("idle"), p = y.useRef(null), h = y.useRef([]), m = y.useRef(null), f = y.useRef(null), g = y.useRef(null), b = y.useRef(t);
  b.current = t;
  const v = y.useRef(e);
  v.current = e;
  const w = y.useRef(n);
  w.current = n;
  const x = y.useCallback((R) => {
    d.current !== R && (d.current = R, o(R));
  }, []), k = y.useCallback(() => {
    m.current = null;
    const R = h.current;
    if (R.length === 0) return;
    h.current = [];
    const I = gn.extractDataParts({ chunks: R });
    for (const U of I)
      b.current(U);
    const j = p.current;
    j && (gn.applyChunks({ state: j, chunks: R }), a(gn.snapshotMessage({ state: j })));
  }, []), S = y.useCallback(() => {
    m.current === null && (m.current = setTimeout(k, Ph));
  }, [k]), N = y.useCallback(() => {
    g.current && (g.current(), g.current = null), m.current !== null && (clearTimeout(m.current), m.current = null), f.current !== null && (clearTimeout(f.current), f.current = null), h.current = [], p.current = null;
  }, []);
  y.useEffect(() => () => {
    N();
  }, [N]);
  const C = y.useCallback(
    (R) => {
      N(), p.current = gn.createStreamingState(), a({
        id: p.current.message.id,
        role: "assistant",
        parts: []
      }), x("awaiting-stream"), c(null);
      const I = () => {
        k(), N(), x("reconciling"), v.current(R);
      }, j = ({
        errorMessage: L,
        errorCode: H
      }) => {
        k(), N(), c(L), x("reconciling"), w.current({ conversationId: R, errorMessage: L, errorCode: H });
      }, U = (L) => {
        if (L.conversationId === R)
          if (L.type === In.CHUNK) {
            x("streaming");
            const H = Array.isArray(L.data) ? L.data : [L.data];
            for (const ie of H)
              h.current.push(ie);
            S(), f.current !== null && clearTimeout(f.current), f.current = setTimeout(() => {
              j({ errorMessage: "Stream timed out" });
            }, Ua);
          } else if (L.type === In.ERROR) {
            const H = L.data;
            j({
              errorMessage: (H == null ? void 0 : H.message) ?? "An error occurred",
              errorCode: H == null ? void 0 : H.code
            });
          } else L.type === In.FINISHED && I();
      };
      r.on(ya.CHAT_MESSAGE_CHUNK, U), f.current = setTimeout(() => {
        j({ errorMessage: "Stream timed out" });
      }, Ua), g.current = () => {
        r.off(ya.CHAT_MESSAGE_CHUNK, U);
      };
    },
    [r, N, k, S, x]
  ), E = y.useCallback(() => {
    N(), a(null), c(null), x("idle");
  }, [N, x]), O = y.useCallback(() => {
    a(null), c(null), x("idle");
  }, [x]);
  return {
    streamingMessage: s,
    streamPhase: i,
    streamError: l,
    startStream: C,
    stopStream: E,
    clearStreamingState: O
  };
}
const $h = 10 * 1024 * 1024, Oh = 5e3, Mh = new Set(yo);
function Dh(t) {
  return Mh.has(t);
}
function Bh(t) {
  return new Promise((e, n) => {
    const r = t.type || "application/octet-stream";
    if (!Dh(r)) {
      n(new Error(`Unsupported file type: ${r}`));
      return;
    }
    const s = new FileReader();
    s.onload = () => {
      const a = s.result;
      if (typeof a != "string") {
        n(new Error("Failed to read file"));
        return;
      }
      const i = a.split(",")[1];
      e({ name: t.name, mimeType: r, data: i });
    }, s.onerror = n, s.readAsDataURL(t);
  });
}
function Ko(t) {
  return t.map((e) => ({
    type: "file",
    mediaType: "text/plain",
    url: "",
    filename: e
  }));
}
function Fh({
  messages: t,
  fileNames: e
}) {
  if (e.length === 0) return t;
  const n = t.findLastIndex((o) => o.role === "user");
  if (n === -1) return t;
  const r = t[n];
  if (r.parts.some((o) => o.type === "file")) return t;
  const a = {
    ...r,
    parts: [...r.parts, ...Ko(e)]
  }, i = [...t];
  return i[n] = a, i;
}
const Gh = /* @__PURE__ */ new Set([
  "data-connection-required",
  "data-connection-picker",
  "data-project-picker",
  "data-questions"
]);
function zh({
  onTitleUpdate: t,
  onConversationCreated: e,
  onCreditsExhausted: n
} = {}) {
  const r = kh(), [s, a] = y.useState(
    null
  ), [i, o] = y.useState(
    xa
  ), [l, c] = y.useState(!1), [d, p] = y.useState(!1), [h, m] = y.useState({ type: "idle" }), f = y.useRef({ type: "idle" }), g = y.useRef(n);
  g.current = n;
  const [b, v] = y.useState(
    []
  ), w = y.useRef(b);
  w.current = b;
  const [x, k] = y.useState(null), S = y.useRef(void 0), N = y.useRef([]), C = y.useRef(null), E = y.useRef(xa), O = y.useRef(t);
  O.current = t;
  const R = y.useRef(e);
  R.current = e;
  const I = y.useCallback(
    (F) => {
      var Y;
      if (!ln(F.data)) return;
      const M = F.data;
      switch (F.type === "data-session-title" && typeof M.title == "string" && ((Y = O.current) == null || Y.call(O, M.title)), F.type) {
        case "data-approval-request":
          typeof M.gateId == "string" && typeof M.toolName == "string" && r.setState({
            pendingApprovalRequest: {
              gateId: M.gateId,
              toolName: M.toolName,
              displayName: typeof M.displayName == "string" ? M.displayName : M.toolName
            }
          });
          break;
        case "data-plan-approval-request":
          typeof M.gateId == "string" && r.setState({
            pendingPlanApproval: {
              gateId: M.gateId,
              planSummary: typeof M.planSummary == "string" ? M.planSummary : "",
              steps: Array.isArray(M.steps) ? M.steps : []
            }
          });
          break;
        case "data-plan-progress":
          typeof M.stepIndex == "number" && typeof M.status == "string" && r.setState((xe) => {
            const Ie = M.stepIndex, Te = M.status, st = xe.planProgressUpdates.findIndex(
              (fe) => fe.stepIndex === Ie
            );
            if (st >= 0) {
              const fe = [...xe.planProgressUpdates];
              return fe[st] = { stepIndex: Ie, status: Te }, { planProgressUpdates: fe };
            }
            return {
              planProgressUpdates: [
                ...xe.planProgressUpdates,
                { stepIndex: Ie, status: Te }
              ]
            };
          });
          break;
        case "data-quick-replies":
          Array.isArray(M.replies) && r.setState({ quickReplies: M.replies });
          break;
        default:
          Gh.has(F.type) && r.setState({ displayCard: { type: F.type, data: M } });
          break;
      }
    },
    [r]
  ), j = y.useCallback((F) => {
    f.current = F, m(F);
  }, []), U = y.useCallback(
    async (F) => {
      if (C.current !== F) return;
      const { data: M } = await Ct(
        () => be.getMessages(F)
      );
      if (M && C.current === F) {
        const Y = ct.mapHistoryToUIMessages(M.data);
        v(Y);
        const xe = ct.extractQuickRepliesFromHistory(Y);
        xe.length > 0 && r.setState({ quickReplies: xe });
      }
      k(null);
    },
    [r]
  ), {
    streamingMessage: L,
    streamPhase: H,
    streamError: ie,
    startStream: hn,
    stopStream: Ve,
    clearStreamingState: Dt
  } = Lh({
    onDataPart: I,
    onStreamFinished: (F) => {
      U(F).then(() => Dt());
    },
    onStreamError: ({ conversationId: F, errorCode: M }) => {
      var Y;
      M === ba.AI_CREDIT_LIMIT_EXCEEDED && ((Y = g.current) == null || Y.call(g)), U(F).then(() => Dt());
    }
  }), T = H !== "idle", ee = T || f.current.type === "submitting" || d, ye = y.useMemo(() => {
    const F = [...b];
    return x && F.push(x), L && F.push(L), Fh({
      messages: F,
      fileNames: N.current
    });
  }, [b, x, L]), he = h.type === "error" ? h.message : ie || null, Ae = h.type === "cancelled", _t = y.useCallback(() => {
    Ve(), j({ type: "cancelled" }), k(null);
  }, [Ve, j]), Q = y.useCallback(
    async ({
      title: F,
      modelName: M
    } = {}) => {
      const Y = await be.createConversation({
        title: F ?? null,
        modelName: M ?? null
      });
      return C.current = Y.id, a(Y.id), Y;
    },
    []
  ), St = y.useCallback(
    async (F, M) => {
      var st;
      j({ type: "submitting" });
      const Y = (M == null ? void 0 : M.map((fe) => fe.name)) ?? [];
      N.current = Y;
      const xe = {
        id: `optimistic-${Date.now()}`,
        role: "user",
        parts: [
          { type: "text", text: F },
          ...Ko(Y)
        ]
      };
      if (k(xe), r.getState().resetInteractions(), M && M.length > 0) {
        const fe = M.find((Oc) => Oc.size > $h);
        if (fe) {
          k(null), j({
            type: "error",
            message: `File "${fe.name}" exceeds 10 MB limit`
          });
          return;
        }
        const { data: Nr, error: Bt } = await Ct(
          async () => Promise.all(M.map(Bh))
        );
        if (Bt) {
          k(null), j({
            type: "error",
            message: Bt.message ?? "Failed to read attached files"
          });
          return;
        }
        S.current = Nr;
      } else
        S.current = void 0;
      if (!C.current) {
        const { error: fe } = await Ct(async () => {
          var Bt;
          const Nr = await Q({
            title: F.slice(0, 100),
            modelName: E.current
          });
          (Bt = R.current) == null || Bt.call(R, Nr.id);
        });
        if (fe) {
          k(null), j({
            type: "error",
            message: fe.message ?? "Failed to start conversation"
          });
          return;
        }
        if (f.current.type === "cancelled") {
          k(null);
          return;
        }
      }
      const Ie = C.current;
      if (!Ie) {
        k(null), j({
          type: "error",
          message: "No conversation ID"
        });
        return;
      }
      hn(Ie), j({ type: "idle" });
      const { error: Te } = await Ct(
        async () => be.sendMessage({
          conversationId: Ie,
          content: F,
          files: S.current
        })
      );
      Te && (Ve(), k(null), Ze.isApError(Te, ba.AI_CREDIT_LIMIT_EXCEEDED) ? ((st = g.current) == null || st.call(g), j({ type: "idle" })) : j({
        type: "error",
        message: Te.message ?? "Failed to send message"
      }));
    },
    [Q, hn, Ve, j, r]
  ), Cr = y.useCallback(
    async (F) => {
      Ve(), p(!1), j({ type: "idle" }), C.current = F, a(F), r.getState().resetInteractions(), S.current = void 0, N.current = [], k(null), c(!0);
      const [M, Y] = await Promise.all([
        Ct(async () => be.getMessages(F)),
        Ct(async () => be.getConversation(F))
      ]);
      if (C.current === F) {
        if (M.error)
          j({
            type: "error",
            message: "Failed to load conversation history"
          });
        else {
          const xe = ct.mapHistoryToUIMessages(
            M.data.data
          );
          v(xe);
          const Ie = ct.extractQuickRepliesFromHistory(xe);
          Ie.length > 0 && r.setState({ quickReplies: Ie });
        }
        Y.data && (E.current = Y.data.modelName ?? null, o(Y.data.modelName ?? null), Y.data.status === Bn.STREAMING && p(!0)), c(!1);
      }
    },
    [Ve, j, r]
  );
  qi({
    queryKey: ["chat-agent-poll", s],
    queryFn: async () => {
      if (!s || C.current !== s)
        return null;
      const [F, M] = await Promise.all([
        be.getMessages(s),
        be.getConversation(s)
      ]);
      if (C.current !== s) return null;
      const Y = ct.mapHistoryToUIMessages(F.data), xe = w.current;
      if (Y.length !== xe.length || Y.some((Te, st) => {
        var fe;
        return Te.parts.length !== ((fe = xe[st]) == null ? void 0 : fe.parts.length);
      })) {
        v(Y);
        const Te = ct.extractQuickRepliesFromHistory(Y);
        Te.length > 0 && r.setState({ quickReplies: Te });
      }
      return M.status !== Bn.STREAMING && p(!1), Y;
    },
    enabled: d && !T,
    refetchInterval: Oh
  });
  const fn = y.useCallback(async (F) => {
    E.current = F, o(F);
    const M = C.current;
    M && await be.updateConversation(M, { modelName: F }).catch(() => {
    });
  }, []);
  return {
    conversationId: s,
    modelName: i,
    messages: ye,
    isStreaming: ee,
    wasCancelled: Ae,
    isLoadingHistory: l,
    error: he,
    sendMessage: St,
    cancelStream: _t,
    setConversationId: Cr,
    setModelName: fn
  };
}
const Uh = 70;
function Hh() {
  const { platform: t } = Yc.useCurrentPlatform(), { data: e } = Wi.useAiProviders(), [n, r] = y.useState(!1), [s, a] = y.useState(!1), i = s ? null : qh({ platform: t, providers: e }), o = Wh(
    t.plan.lastFreeAiCreditsRenewalDate
  ), l = y.useCallback(() => {
    a(!0);
  }, []);
  return {
    creditsWarning: i,
    daysUntilReset: o,
    creditsExhausted: n,
    setCreditsExhausted: r,
    warningDismissed: s,
    dismissCreditsWarning: l
  };
}
function qh({
  platform: t,
  providers: e
}) {
  if (!(e == null ? void 0 : e.some(
    (i) => i.provider === Xc.ACTIVEPIECES && i.enabledForChat
  )) || !t.usage || t.usage.aiCreditsLimit <= 0)
    return null;
  const { totalAiCreditsUsed: r, aiCreditsLimit: s } = t.usage, a = Math.round(r / s * 100);
  return a < Uh ? null : { percentage: a };
}
function Wh(t) {
  if (!t) return null;
  const e = wa(t).add(1, "month");
  return Math.max(0, e.diff(wa(), "day"));
}
function Ds() {
  return { async: !1, breaks: !1, extensions: null, gfm: !0, hooks: null, pedantic: !1, renderer: null, silent: !1, tokenizer: null, walkTokens: null };
}
var vt = Ds();
function el(t) {
  vt = t;
}
var pt = { exec: () => null };
function z(t, e = "") {
  let n = typeof t == "string" ? t : t.source, r = { replace: (s, a) => {
    let i = typeof a == "string" ? a : a.source;
    return i = i.replace(de.caret, "$1"), n = n.replace(s, i), r;
  }, getRegex: () => new RegExp(n, e) };
  return r;
}
var Zh = ((t = "") => {
  try {
    return !!new RegExp("(?<=1)(?<!1)" + t);
  } catch {
    return !1;
  }
})(), de = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] +\S/, listReplaceTask: /^\[[ xX]\] +/, listTaskCheckbox: /\[[ xX]\]/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: (t) => new RegExp(`^( {0,3}${t})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: (t) => new RegExp(`^ {0,${Math.min(3, t - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), hrRegex: (t) => new RegExp(`^ {0,${Math.min(3, t - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), fencesBeginRegex: (t) => new RegExp(`^ {0,${Math.min(3, t - 1)}}(?:\`\`\`|~~~)`), headingBeginRegex: (t) => new RegExp(`^ {0,${Math.min(3, t - 1)}}#`), htmlBeginRegex: (t) => new RegExp(`^ {0,${Math.min(3, t - 1)}}<(?:[a-z].*>|!--)`, "i"), blockquoteBeginRegex: (t) => new RegExp(`^ {0,${Math.min(3, t - 1)}}>`) }, Vh = /^(?:[ \t]*(?:\n|$))+/, Jh = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, Qh = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, un = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Yh = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Bs = / {0,3}(?:[*+-]|\d{1,9}[.)])/, tl = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, nl = z(tl).replace(/bull/g, Bs).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Xh = z(tl).replace(/bull/g, Bs).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), Fs = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, Kh = /^[^\n]+/, Gs = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, ef = z(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", Gs).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), tf = z(/^(bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Bs).getRegex(), ur = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", zs = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, nf = z("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", zs).replace("tag", ur).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), rl = z(Fs).replace("hr", un).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ur).getRegex(), rf = z(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", rl).getRegex(), Us = { blockquote: rf, code: Jh, def: ef, fences: Qh, heading: Yh, hr: un, html: nf, lheading: nl, list: tf, newline: Vh, paragraph: rl, table: pt, text: Kh }, Ha = z("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", un).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ur).getRegex(), sf = { ...Us, lheading: Xh, table: Ha, paragraph: z(Fs).replace("hr", un).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", Ha).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", ur).getRegex() }, af = { ...Us, html: z(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", zs).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: pt, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: z(Fs).replace("hr", un).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", nl).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() }, of = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, lf = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, sl = /^( {2,}|\\)\n(?!\s*$)/, cf = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, $t = /[\p{P}\p{S}]/u, pr = /[\s\p{P}\p{S}]/u, Hs = /[^\s\p{P}\p{S}]/u, uf = z(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, pr).getRegex(), al = /(?!~)[\p{P}\p{S}]/u, pf = /(?!~)[\s\p{P}\p{S}]/u, df = /(?:[^\s\p{P}\p{S}]|~)/u, hf = z(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", Zh ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex(), il = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/, ff = z(il, "u").replace(/punct/g, $t).getRegex(), mf = z(il, "u").replace(/punct/g, al).getRegex(), ol = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", gf = z(ol, "gu").replace(/notPunctSpace/g, Hs).replace(/punctSpace/g, pr).replace(/punct/g, $t).getRegex(), yf = z(ol, "gu").replace(/notPunctSpace/g, df).replace(/punctSpace/g, pf).replace(/punct/g, al).getRegex(), xf = z("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, Hs).replace(/punctSpace/g, pr).replace(/punct/g, $t).getRegex(), bf = z(/^~~?(?:((?!~)punct)|[^\s~])/, "u").replace(/punct/g, $t).getRegex(), wf = "^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)", kf = z(wf, "gu").replace(/notPunctSpace/g, Hs).replace(/punctSpace/g, pr).replace(/punct/g, $t).getRegex(), vf = z(/\\(punct)/, "gu").replace(/punct/g, $t).getRegex(), _f = z(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Sf = z(zs).replace("(?:-->|$)", "-->").getRegex(), Cf = z("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Sf).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), Un = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/, Nf = z(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?\s*\)/).replace("label", Un).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), ll = z(/^!?\[(label)\]\[(ref)\]/).replace("label", Un).replace("ref", Gs).getRegex(), cl = z(/^!?\[(ref)\](?:\[\])?/).replace("ref", Gs).getRegex(), Af = z("reflink|nolink(?!\\()", "g").replace("reflink", ll).replace("nolink", cl).getRegex(), qa = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/, qs = { _backpedal: pt, anyPunctuation: vf, autolink: _f, blockSkip: hf, br: sl, code: lf, del: pt, delLDelim: pt, delRDelim: pt, emStrongLDelim: ff, emStrongRDelimAst: gf, emStrongRDelimUnd: xf, escape: of, link: Nf, nolink: cl, punctuation: uf, reflink: ll, reflinkSearch: Af, tag: Cf, text: cf, url: pt }, If = { ...qs, link: z(/^!?\[(label)\]\((.*?)\)/).replace("label", Un).getRegex(), reflink: z(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", Un).getRegex() }, is = { ...qs, emStrongRDelimAst: yf, emStrongLDelim: mf, delLDelim: bf, delRDelim: kf, url: z(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", qa).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: z(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", qa).getRegex() }, Tf = { ...is, br: z(sl).replace("{2,}", "*").getRegex(), text: z(is.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() }, yn = { normal: Us, gfm: sf, pedantic: af }, Ut = { normal: qs, gfm: is, breaks: Tf, pedantic: If }, Ef = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }, Wa = (t) => Ef[t];
function Me(t, e) {
  if (e) {
    if (de.escapeTest.test(t)) return t.replace(de.escapeReplace, Wa);
  } else if (de.escapeTestNoEncode.test(t)) return t.replace(de.escapeReplaceNoEncode, Wa);
  return t;
}
function Za(t) {
  try {
    t = encodeURI(t).replace(de.percentDecode, "%");
  } catch {
    return null;
  }
  return t;
}
function Va(t, e) {
  var a;
  let n = t.replace(de.findPipe, (i, o, l) => {
    let c = !1, d = o;
    for (; --d >= 0 && l[d] === "\\"; ) c = !c;
    return c ? "|" : " |";
  }), r = n.split(de.splitPipe), s = 0;
  if (r[0].trim() || r.shift(), r.length > 0 && !((a = r.at(-1)) != null && a.trim()) && r.pop(), e) if (r.length > e) r.splice(e);
  else for (; r.length < e; ) r.push("");
  for (; s < r.length; s++) r[s] = r[s].trim().replace(de.slashPipe, "|");
  return r;
}
function Je(t, e, n) {
  let r = t.length;
  if (r === 0) return "";
  let s = 0;
  for (; s < r && t.charAt(r - s - 1) === e; )
    s++;
  return t.slice(0, r - s);
}
function Ja(t) {
  let e = t.split(`
`), n = e.length - 1;
  for (; n >= 0 && de.blankLine.test(e[n]); ) n--;
  return e.length - n <= 2 ? t : e.slice(0, n + 1).join(`
`);
}
function jf(t, e) {
  if (t.indexOf(e[1]) === -1) return -1;
  let n = 0;
  for (let r = 0; r < t.length; r++) if (t[r] === "\\") r++;
  else if (t[r] === e[0]) n++;
  else if (t[r] === e[1] && (n--, n < 0)) return r;
  return n > 0 ? -2 : -1;
}
function Rf(t, e = 0) {
  let n = e, r = "";
  for (let s of t) if (s === "	") {
    let a = 4 - n % 4;
    r += " ".repeat(a), n += a;
  } else r += s, n++;
  return r;
}
function Qa(t, e, n, r, s) {
  let a = e.href, i = e.title || null, o = t[1].replace(s.other.outputLinkReplace, "$1");
  r.state.inLink = !0;
  let l = { type: t[0].charAt(0) === "!" ? "image" : "link", raw: n, href: a, title: i, text: o, tokens: r.inlineTokens(o) };
  return r.state.inLink = !1, l;
}
function Pf(t, e, n) {
  let r = t.match(n.other.indentCodeCompensation);
  if (r === null) return e;
  let s = r[1];
  return e.split(`
`).map((a) => {
    let i = a.match(n.other.beginningSpace);
    if (i === null) return a;
    let [o] = i;
    return o.length >= s.length ? a.slice(s.length) : a;
  }).join(`
`);
}
var Hn = class {
  constructor(e) {
    _(this, "options");
    _(this, "rules");
    _(this, "lexer");
    this.options = e || vt;
  }
  space(e) {
    let n = this.rules.block.newline.exec(e);
    if (n && n[0].length > 0) return { type: "space", raw: n[0] };
  }
  code(e) {
    let n = this.rules.block.code.exec(e);
    if (n) {
      let r = this.options.pedantic ? n[0] : Ja(n[0]), s = r.replace(this.rules.other.codeRemoveIndent, "");
      return { type: "code", raw: r, codeBlockStyle: "indented", text: s };
    }
  }
  fences(e) {
    let n = this.rules.block.fences.exec(e);
    if (n) {
      let r = n[0], s = Pf(r, n[3] || "", this.rules);
      return { type: "code", raw: r, lang: n[2] ? n[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : n[2], text: s };
    }
  }
  heading(e) {
    let n = this.rules.block.heading.exec(e);
    if (n) {
      let r = n[2].trim();
      if (this.rules.other.endingHash.test(r)) {
        let s = Je(r, "#");
        (this.options.pedantic || !s || this.rules.other.endingSpaceChar.test(s)) && (r = s.trim());
      }
      return { type: "heading", raw: Je(n[0], `
`), depth: n[1].length, text: r, tokens: this.lexer.inline(r) };
    }
  }
  hr(e) {
    let n = this.rules.block.hr.exec(e);
    if (n) return { type: "hr", raw: Je(n[0], `
`) };
  }
  blockquote(e) {
    let n = this.rules.block.blockquote.exec(e);
    if (n) {
      let r = Je(n[0], `
`).split(`
`), s = "", a = "", i = [];
      for (; r.length > 0; ) {
        let o = !1, l = [], c;
        for (c = 0; c < r.length; c++) if (this.rules.other.blockquoteStart.test(r[c])) l.push(r[c]), o = !0;
        else if (!o) l.push(r[c]);
        else break;
        r = r.slice(c);
        let d = l.join(`
`), p = d.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        s = s ? `${s}
${d}` : d, a = a ? `${a}
${p}` : p;
        let h = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(p, i, !0), this.lexer.state.top = h, r.length === 0) break;
        let m = i.at(-1);
        if ((m == null ? void 0 : m.type) === "code") break;
        if ((m == null ? void 0 : m.type) === "blockquote") {
          let f = m, g = f.raw + `
` + r.join(`
`), b = this.blockquote(g);
          i[i.length - 1] = b, s = s.substring(0, s.length - f.raw.length) + b.raw, a = a.substring(0, a.length - f.text.length) + b.text;
          break;
        } else if ((m == null ? void 0 : m.type) === "list") {
          let f = m, g = f.raw + `
` + r.join(`
`), b = this.list(g);
          i[i.length - 1] = b, s = s.substring(0, s.length - m.raw.length) + b.raw, a = a.substring(0, a.length - f.raw.length) + b.raw, r = g.substring(i.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return { type: "blockquote", raw: s, tokens: i, text: a };
    }
  }
  list(e) {
    var r, s;
    let n = this.rules.block.list.exec(e);
    if (n) {
      let a = n[1].trim(), i = a.length > 1, o = { type: "list", raw: "", ordered: i, start: i ? +a.slice(0, -1) : "", loose: !1, items: [] };
      a = i ? `\\d{1,9}\\${a.slice(-1)}` : `\\${a}`, this.options.pedantic && (a = i ? a : "[*+-]");
      let l = this.rules.other.listItemRegex(a), c = !1;
      for (; e; ) {
        let p = !1, h = "", m = "";
        if (!(n = l.exec(e)) || this.rules.block.hr.test(e)) break;
        h = n[0], e = e.substring(h.length);
        let f = Rf(n[2].split(`
`, 1)[0], n[1].length), g = e.split(`
`, 1)[0], b = !f.trim(), v = 0;
        if (this.options.pedantic ? (v = 2, m = f.trimStart()) : b ? v = n[1].length + 1 : (v = f.search(this.rules.other.nonSpaceChar), v = v > 4 ? 1 : v, m = f.slice(v), v += n[1].length), b && this.rules.other.blankLine.test(g) && (h += g + `
`, e = e.substring(g.length + 1), p = !0), !p) {
          let w = this.rules.other.nextBulletRegex(v), x = this.rules.other.hrRegex(v), k = this.rules.other.fencesBeginRegex(v), S = this.rules.other.headingBeginRegex(v), N = this.rules.other.htmlBeginRegex(v), C = this.rules.other.blockquoteBeginRegex(v);
          for (; e; ) {
            let E = e.split(`
`, 1)[0], O;
            if (g = E, this.options.pedantic ? (g = g.replace(this.rules.other.listReplaceNesting, "  "), O = g) : O = g.replace(this.rules.other.tabCharGlobal, "    "), k.test(g) || S.test(g) || N.test(g) || C.test(g) || w.test(g) || x.test(g)) break;
            if (O.search(this.rules.other.nonSpaceChar) >= v || !g.trim()) m += `
` + O.slice(v);
            else {
              if (b || f.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || k.test(f) || S.test(f) || x.test(f)) break;
              m += `
` + g;
            }
            b = !g.trim(), h += E + `
`, e = e.substring(E.length + 1), f = O.slice(v);
          }
        }
        o.loose || (c ? o.loose = !0 : this.rules.other.doubleBlankLine.test(h) && (c = !0)), o.items.push({ type: "list_item", raw: h, task: !!this.options.gfm && this.rules.other.listIsTask.test(m), loose: !1, text: m, tokens: [] }), o.raw += h;
      }
      let d = o.items.at(-1);
      if (d) d.raw = d.raw.trimEnd(), d.text = d.text.trimEnd();
      else return;
      o.raw = o.raw.trimEnd();
      for (let p of o.items) {
        if (this.lexer.state.top = !1, p.tokens = this.lexer.blockTokens(p.text, []), p.task) {
          if (p.text = p.text.replace(this.rules.other.listReplaceTask, ""), ((r = p.tokens[0]) == null ? void 0 : r.type) === "text" || ((s = p.tokens[0]) == null ? void 0 : s.type) === "paragraph") {
            p.tokens[0].raw = p.tokens[0].raw.replace(this.rules.other.listReplaceTask, ""), p.tokens[0].text = p.tokens[0].text.replace(this.rules.other.listReplaceTask, "");
            for (let m = this.lexer.inlineQueue.length - 1; m >= 0; m--) if (this.rules.other.listIsTask.test(this.lexer.inlineQueue[m].src)) {
              this.lexer.inlineQueue[m].src = this.lexer.inlineQueue[m].src.replace(this.rules.other.listReplaceTask, "");
              break;
            }
          }
          let h = this.rules.other.listTaskCheckbox.exec(p.raw);
          if (h) {
            let m = { type: "checkbox", raw: h[0] + " ", checked: h[0] !== "[ ]" };
            p.checked = m.checked, o.loose ? p.tokens[0] && ["paragraph", "text"].includes(p.tokens[0].type) && "tokens" in p.tokens[0] && p.tokens[0].tokens ? (p.tokens[0].raw = m.raw + p.tokens[0].raw, p.tokens[0].text = m.raw + p.tokens[0].text, p.tokens[0].tokens.unshift(m)) : p.tokens.unshift({ type: "paragraph", raw: m.raw, text: m.raw, tokens: [m] }) : p.tokens.unshift(m);
          }
        }
        if (!o.loose) {
          let h = p.tokens.filter((f) => f.type === "space"), m = h.length > 0 && h.some((f) => this.rules.other.anyLine.test(f.raw));
          o.loose = m;
        }
      }
      if (o.loose) for (let p of o.items) {
        p.loose = !0;
        for (let h of p.tokens) h.type === "text" && (h.type = "paragraph");
      }
      return o;
    }
  }
  html(e) {
    let n = this.rules.block.html.exec(e);
    if (n) {
      let r = Ja(n[0]);
      return { type: "html", block: !0, raw: r, pre: n[1] === "pre" || n[1] === "script" || n[1] === "style", text: r };
    }
  }
  def(e) {
    let n = this.rules.block.def.exec(e);
    if (n) {
      let r = n[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), s = n[2] ? n[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", a = n[3] ? n[3].substring(1, n[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : n[3];
      return { type: "def", tag: r, raw: Je(n[0], `
`), href: s, title: a };
    }
  }
  table(e) {
    var o;
    let n = this.rules.block.table.exec(e);
    if (!n || !this.rules.other.tableDelimiter.test(n[2])) return;
    let r = Va(n[1]), s = n[2].replace(this.rules.other.tableAlignChars, "").split("|"), a = (o = n[3]) != null && o.trim() ? n[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], i = { type: "table", raw: Je(n[0], `
`), header: [], align: [], rows: [] };
    if (r.length === s.length) {
      for (let l of s) this.rules.other.tableAlignRight.test(l) ? i.align.push("right") : this.rules.other.tableAlignCenter.test(l) ? i.align.push("center") : this.rules.other.tableAlignLeft.test(l) ? i.align.push("left") : i.align.push(null);
      for (let l = 0; l < r.length; l++) i.header.push({ text: r[l], tokens: this.lexer.inline(r[l]), header: !0, align: i.align[l] });
      for (let l of a) i.rows.push(Va(l, i.header.length).map((c, d) => ({ text: c, tokens: this.lexer.inline(c), header: !1, align: i.align[d] })));
      return i;
    }
  }
  lheading(e) {
    let n = this.rules.block.lheading.exec(e);
    if (n) {
      let r = n[1].trim();
      return { type: "heading", raw: Je(n[0], `
`), depth: n[2].charAt(0) === "=" ? 1 : 2, text: r, tokens: this.lexer.inline(r) };
    }
  }
  paragraph(e) {
    let n = this.rules.block.paragraph.exec(e);
    if (n) {
      let r = n[1].charAt(n[1].length - 1) === `
` ? n[1].slice(0, -1) : n[1];
      return { type: "paragraph", raw: n[0], text: r, tokens: this.lexer.inline(r) };
    }
  }
  text(e) {
    let n = this.rules.block.text.exec(e);
    if (n) return { type: "text", raw: n[0], text: n[0], tokens: this.lexer.inline(n[0]) };
  }
  escape(e) {
    let n = this.rules.inline.escape.exec(e);
    if (n) return { type: "escape", raw: n[0], text: n[1] };
  }
  tag(e) {
    let n = this.rules.inline.tag.exec(e);
    if (n) return !this.lexer.state.inLink && this.rules.other.startATag.test(n[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(n[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(n[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(n[0]) && (this.lexer.state.inRawBlock = !1), { type: "html", raw: n[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: !1, text: n[0] };
  }
  link(e) {
    let n = this.rules.inline.link.exec(e);
    if (n) {
      let r = n[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(r)) {
        if (!this.rules.other.endAngleBracket.test(r)) return;
        let i = Je(r.slice(0, -1), "\\");
        if ((r.length - i.length) % 2 === 0) return;
      } else {
        let i = jf(n[2], "()");
        if (i === -2) return;
        if (i > -1) {
          let o = (n[0].indexOf("!") === 0 ? 5 : 4) + n[1].length + i;
          n[2] = n[2].substring(0, i), n[0] = n[0].substring(0, o).trim(), n[3] = "";
        }
      }
      let s = n[2], a = "";
      if (this.options.pedantic) {
        let i = this.rules.other.pedanticHrefTitle.exec(s);
        i && (s = i[1], a = i[3]);
      } else a = n[3] ? n[3].slice(1, -1) : "";
      return s = s.trim(), this.rules.other.startAngleBracket.test(s) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(r) ? s = s.slice(1) : s = s.slice(1, -1)), Qa(n, { href: s && s.replace(this.rules.inline.anyPunctuation, "$1"), title: a && a.replace(this.rules.inline.anyPunctuation, "$1") }, n[0], this.lexer, this.rules);
    }
  }
  reflink(e, n) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      let s = (r[2] || r[1]).replace(this.rules.other.multipleSpaceGlobal, " "), a = n[s.toLowerCase()];
      if (!a) {
        let i = r[0].charAt(0);
        return { type: "text", raw: i, text: i };
      }
      return Qa(r, a, r[0], this.lexer, this.rules);
    }
  }
  emStrong(e, n, r = "") {
    let s = this.rules.inline.emStrongLDelim.exec(e);
    if (!(!s || !s[1] && !s[2] && !s[3] && !s[4] || s[4] && r.match(this.rules.other.unicodeAlphaNumeric)) && (!(s[1] || s[3]) || !r || this.rules.inline.punctuation.exec(r))) {
      let a = [...s[0]].length - 1, i, o, l = a, c = 0, d = s[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (d.lastIndex = 0, n = n.slice(-1 * e.length + a); (s = d.exec(n)) !== null; ) {
        if (i = s[1] || s[2] || s[3] || s[4] || s[5] || s[6], !i) continue;
        if (o = [...i].length, s[3] || s[4]) {
          l += o;
          continue;
        } else if ((s[5] || s[6]) && a % 3 && !((a + o) % 3)) {
          c += o;
          continue;
        }
        if (l -= o, l > 0) continue;
        o = Math.min(o, o + l + c);
        let p = [...s[0]][0].length, h = e.slice(0, a + s.index + p + o);
        if (Math.min(a, o) % 2) {
          let f = h.slice(1, -1);
          return { type: "em", raw: h, text: f, tokens: this.lexer.inlineTokens(f) };
        }
        let m = h.slice(2, -2);
        return { type: "strong", raw: h, text: m, tokens: this.lexer.inlineTokens(m) };
      }
    }
  }
  codespan(e) {
    let n = this.rules.inline.code.exec(e);
    if (n) {
      let r = n[2].replace(this.rules.other.newLineCharGlobal, " "), s = this.rules.other.nonSpaceChar.test(r), a = this.rules.other.startingSpaceChar.test(r) && this.rules.other.endingSpaceChar.test(r);
      return s && a && (r = r.substring(1, r.length - 1)), { type: "codespan", raw: n[0], text: r };
    }
  }
  br(e) {
    let n = this.rules.inline.br.exec(e);
    if (n) return { type: "br", raw: n[0] };
  }
  del(e, n, r = "") {
    let s = this.rules.inline.delLDelim.exec(e);
    if (s && (!s[1] || !r || this.rules.inline.punctuation.exec(r))) {
      let a = [...s[0]].length - 1, i, o, l = a, c = this.rules.inline.delRDelim;
      for (c.lastIndex = 0, n = n.slice(-1 * e.length + a); (s = c.exec(n)) !== null; ) {
        if (i = s[1] || s[2] || s[3] || s[4] || s[5] || s[6], !i || (o = [...i].length, o !== a)) continue;
        if (s[3] || s[4]) {
          l += o;
          continue;
        }
        if (l -= o, l > 0) continue;
        o = Math.min(o, o + l);
        let d = [...s[0]][0].length, p = e.slice(0, a + s.index + d + o), h = p.slice(a, -a);
        return { type: "del", raw: p, text: h, tokens: this.lexer.inlineTokens(h) };
      }
    }
  }
  autolink(e) {
    let n = this.rules.inline.autolink.exec(e);
    if (n) {
      let r, s;
      return n[2] === "@" ? (r = n[1], s = "mailto:" + r) : (r = n[1], s = r), { type: "link", raw: n[0], text: r, href: s, tokens: [{ type: "text", raw: r, text: r }] };
    }
  }
  url(e) {
    var r;
    let n;
    if (n = this.rules.inline.url.exec(e)) {
      let s, a;
      if (n[2] === "@") s = n[0], a = "mailto:" + s;
      else {
        let i;
        do
          i = n[0], n[0] = ((r = this.rules.inline._backpedal.exec(n[0])) == null ? void 0 : r[0]) ?? "";
        while (i !== n[0]);
        s = n[0], n[1] === "www." ? a = "http://" + n[0] : a = n[0];
      }
      return { type: "link", raw: n[0], text: s, href: a, tokens: [{ type: "text", raw: s, text: s }] };
    }
  }
  inlineText(e) {
    let n = this.rules.inline.text.exec(e);
    if (n) {
      let r = this.lexer.state.inRawBlock;
      return { type: "text", raw: n[0], text: n[0], escaped: r };
    }
  }
}, Pe = class os {
  constructor(e) {
    _(this, "tokens");
    _(this, "options");
    _(this, "state");
    _(this, "inlineQueue");
    _(this, "tokenizer");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = e || vt, this.options.tokenizer = this.options.tokenizer || new Hn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: !1, inRawBlock: !1, top: !0 };
    let n = { other: de, block: yn.normal, inline: Ut.normal };
    this.options.pedantic ? (n.block = yn.pedantic, n.inline = Ut.pedantic) : this.options.gfm && (n.block = yn.gfm, this.options.breaks ? n.inline = Ut.breaks : n.inline = Ut.gfm), this.tokenizer.rules = n;
  }
  static get rules() {
    return { block: yn, inline: Ut };
  }
  static lex(e, n) {
    return new os(n).lex(e);
  }
  static lexInline(e, n) {
    return new os(n).inlineTokens(e);
  }
  lex(e) {
    e = e.replace(de.carriageReturn, `
`), this.blockTokens(e, this.tokens);
    for (let n = 0; n < this.inlineQueue.length; n++) {
      let r = this.inlineQueue[n];
      this.inlineTokens(r.src, r.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(e, n = [], r = !1) {
    var a, i, o;
    this.tokenizer.lexer = this, this.options.pedantic && (e = e.replace(de.tabCharGlobal, "    ").replace(de.spaceLine, ""));
    let s = 1 / 0;
    for (; e; ) {
      if (e.length < s) s = e.length;
      else {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
      let l;
      if ((i = (a = this.options.extensions) == null ? void 0 : a.block) != null && i.some((d) => (l = d.call({ lexer: this }, e, n)) ? (e = e.substring(l.raw.length), n.push(l), !0) : !1)) continue;
      if (l = this.tokenizer.space(e)) {
        e = e.substring(l.raw.length);
        let d = n.at(-1);
        l.raw.length === 1 && d !== void 0 ? d.raw += `
` : n.push(l);
        continue;
      }
      if (l = this.tokenizer.code(e)) {
        e = e.substring(l.raw.length);
        let d = n.at(-1);
        (d == null ? void 0 : d.type) === "paragraph" || (d == null ? void 0 : d.type) === "text" ? (d.raw += (d.raw.endsWith(`
`) ? "" : `
`) + l.raw, d.text += `
` + l.text, this.inlineQueue.at(-1).src = d.text) : n.push(l);
        continue;
      }
      if (l = this.tokenizer.fences(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      if (l = this.tokenizer.heading(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      if (l = this.tokenizer.hr(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      if (l = this.tokenizer.blockquote(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      if (l = this.tokenizer.list(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      if (l = this.tokenizer.html(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      if (l = this.tokenizer.def(e)) {
        e = e.substring(l.raw.length);
        let d = n.at(-1);
        (d == null ? void 0 : d.type) === "paragraph" || (d == null ? void 0 : d.type) === "text" ? (d.raw += (d.raw.endsWith(`
`) ? "" : `
`) + l.raw, d.text += `
` + l.raw, this.inlineQueue.at(-1).src = d.text) : this.tokens.links[l.tag] || (this.tokens.links[l.tag] = { href: l.href, title: l.title }, n.push(l));
        continue;
      }
      if (l = this.tokenizer.table(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      if (l = this.tokenizer.lheading(e)) {
        e = e.substring(l.raw.length), n.push(l);
        continue;
      }
      let c = e;
      if ((o = this.options.extensions) != null && o.startBlock) {
        let d = 1 / 0, p = e.slice(1), h;
        this.options.extensions.startBlock.forEach((m) => {
          h = m.call({ lexer: this }, p), typeof h == "number" && h >= 0 && (d = Math.min(d, h));
        }), d < 1 / 0 && d >= 0 && (c = e.substring(0, d + 1));
      }
      if (this.state.top && (l = this.tokenizer.paragraph(c))) {
        let d = n.at(-1);
        r && (d == null ? void 0 : d.type) === "paragraph" ? (d.raw += (d.raw.endsWith(`
`) ? "" : `
`) + l.raw, d.text += `
` + l.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = d.text) : n.push(l), r = c.length !== e.length, e = e.substring(l.raw.length);
        continue;
      }
      if (l = this.tokenizer.text(e)) {
        e = e.substring(l.raw.length);
        let d = n.at(-1);
        (d == null ? void 0 : d.type) === "text" ? (d.raw += (d.raw.endsWith(`
`) ? "" : `
`) + l.raw, d.text += `
` + l.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = d.text) : n.push(l);
        continue;
      }
      if (e) {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
    }
    return this.state.top = !0, n;
  }
  inline(e, n = []) {
    return this.inlineQueue.push({ src: e, tokens: n }), n;
  }
  inlineTokens(e, n = []) {
    var c, d, p, h, m;
    this.tokenizer.lexer = this;
    let r = e, s = null;
    if (this.tokens.links) {
      let f = Object.keys(this.tokens.links);
      if (f.length > 0) for (; (s = this.tokenizer.rules.inline.reflinkSearch.exec(r)) !== null; ) f.includes(s[0].slice(s[0].lastIndexOf("[") + 1, -1)) && (r = r.slice(0, s.index) + "[" + "a".repeat(s[0].length - 2) + "]" + r.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (s = this.tokenizer.rules.inline.anyPunctuation.exec(r)) !== null; ) r = r.slice(0, s.index) + "++" + r.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    let a;
    for (; (s = this.tokenizer.rules.inline.blockSkip.exec(r)) !== null; ) a = s[2] ? s[2].length : 0, r = r.slice(0, s.index + a) + "[" + "a".repeat(s[0].length - a - 2) + "]" + r.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    r = ((d = (c = this.options.hooks) == null ? void 0 : c.emStrongMask) == null ? void 0 : d.call({ lexer: this }, r)) ?? r;
    let i = !1, o = "", l = 1 / 0;
    for (; e; ) {
      if (e.length < l) l = e.length;
      else {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
      i || (o = ""), i = !1;
      let f;
      if ((h = (p = this.options.extensions) == null ? void 0 : p.inline) != null && h.some((b) => (f = b.call({ lexer: this }, e, n)) ? (e = e.substring(f.raw.length), n.push(f), !0) : !1)) continue;
      if (f = this.tokenizer.escape(e)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (f = this.tokenizer.tag(e)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (f = this.tokenizer.link(e)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (f = this.tokenizer.reflink(e, this.tokens.links)) {
        e = e.substring(f.raw.length);
        let b = n.at(-1);
        f.type === "text" && (b == null ? void 0 : b.type) === "text" ? (b.raw += f.raw, b.text += f.text) : n.push(f);
        continue;
      }
      if (f = this.tokenizer.emStrong(e, r, o)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (f = this.tokenizer.codespan(e)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (f = this.tokenizer.br(e)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (f = this.tokenizer.del(e, r, o)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (f = this.tokenizer.autolink(e)) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      if (!this.state.inLink && (f = this.tokenizer.url(e))) {
        e = e.substring(f.raw.length), n.push(f);
        continue;
      }
      let g = e;
      if ((m = this.options.extensions) != null && m.startInline) {
        let b = 1 / 0, v = e.slice(1), w;
        this.options.extensions.startInline.forEach((x) => {
          w = x.call({ lexer: this }, v), typeof w == "number" && w >= 0 && (b = Math.min(b, w));
        }), b < 1 / 0 && b >= 0 && (g = e.substring(0, b + 1));
      }
      if (f = this.tokenizer.inlineText(g)) {
        e = e.substring(f.raw.length), f.raw.slice(-1) !== "_" && (o = f.raw.slice(-1)), i = !0;
        let b = n.at(-1);
        (b == null ? void 0 : b.type) === "text" ? (b.raw += f.raw, b.text += f.text) : n.push(f);
        continue;
      }
      if (e) {
        this.infiniteLoopError(e.charCodeAt(0));
        break;
      }
    }
    return n;
  }
  infiniteLoopError(e) {
    let n = "Infinite loop on byte: " + e;
    if (this.options.silent) console.error(n);
    else throw new Error(n);
  }
}, qn = class {
  constructor(e) {
    _(this, "options");
    _(this, "parser");
    this.options = e || vt;
  }
  space(e) {
    return "";
  }
  code({ text: e, lang: n, escaped: r }) {
    var i;
    let s = (i = (n || "").match(de.notSpaceStart)) == null ? void 0 : i[0], a = e.replace(de.endingNewline, "") + `
`;
    return s ? '<pre><code class="language-' + Me(s) + '">' + (r ? a : Me(a, !0)) + `</code></pre>
` : "<pre><code>" + (r ? a : Me(a, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: e }) {
    return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
  }
  html({ text: e }) {
    return e;
  }
  def(e) {
    return "";
  }
  heading({ tokens: e, depth: n }) {
    return `<h${n}>${this.parser.parseInline(e)}</h${n}>
`;
  }
  hr(e) {
    return `<hr>
`;
  }
  list(e) {
    let n = e.ordered, r = e.start, s = "";
    for (let o = 0; o < e.items.length; o++) {
      let l = e.items[o];
      s += this.listitem(l);
    }
    let a = n ? "ol" : "ul", i = n && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + a + i + `>
` + s + "</" + a + `>
`;
  }
  listitem(e) {
    return `<li>${this.parser.parse(e.tokens)}</li>
`;
  }
  checkbox({ checked: e }) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox"> ';
  }
  paragraph({ tokens: e }) {
    return `<p>${this.parser.parseInline(e)}</p>
`;
  }
  table(e) {
    let n = "", r = "";
    for (let a = 0; a < e.header.length; a++) r += this.tablecell(e.header[a]);
    n += this.tablerow({ text: r });
    let s = "";
    for (let a = 0; a < e.rows.length; a++) {
      let i = e.rows[a];
      r = "";
      for (let o = 0; o < i.length; o++) r += this.tablecell(i[o]);
      s += this.tablerow({ text: r });
    }
    return s && (s = `<tbody>${s}</tbody>`), `<table>
<thead>
` + n + `</thead>
` + s + `</table>
`;
  }
  tablerow({ text: e }) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e) {
    let n = this.parser.parseInline(e.tokens), r = e.header ? "th" : "td";
    return (e.align ? `<${r} align="${e.align}">` : `<${r}>`) + n + `</${r}>
`;
  }
  strong({ tokens: e }) {
    return `<strong>${this.parser.parseInline(e)}</strong>`;
  }
  em({ tokens: e }) {
    return `<em>${this.parser.parseInline(e)}</em>`;
  }
  codespan({ text: e }) {
    return `<code>${Me(e, !0)}</code>`;
  }
  br(e) {
    return "<br>";
  }
  del({ tokens: e }) {
    return `<del>${this.parser.parseInline(e)}</del>`;
  }
  link({ href: e, title: n, tokens: r }) {
    let s = this.parser.parseInline(r), a = Za(e);
    if (a === null) return s;
    e = a;
    let i = '<a href="' + e + '"';
    return n && (i += ' title="' + Me(n) + '"'), i += ">" + s + "</a>", i;
  }
  image({ href: e, title: n, text: r, tokens: s }) {
    s && (r = this.parser.parseInline(s, this.parser.textRenderer));
    let a = Za(e);
    if (a === null) return Me(r);
    e = a;
    let i = `<img src="${e}" alt="${Me(r)}"`;
    return n && (i += ` title="${Me(n)}"`), i += ">", i;
  }
  text(e) {
    return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : Me(e.text);
  }
}, Ws = class {
  strong({ text: e }) {
    return e;
  }
  em({ text: e }) {
    return e;
  }
  codespan({ text: e }) {
    return e;
  }
  del({ text: e }) {
    return e;
  }
  html({ text: e }) {
    return e;
  }
  text({ text: e }) {
    return e;
  }
  link({ text: e }) {
    return "" + e;
  }
  image({ text: e }) {
    return "" + e;
  }
  br() {
    return "";
  }
  checkbox({ raw: e }) {
    return e;
  }
}, Le = class ls {
  constructor(e) {
    _(this, "options");
    _(this, "renderer");
    _(this, "textRenderer");
    this.options = e || vt, this.options.renderer = this.options.renderer || new qn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new Ws();
  }
  static parse(e, n) {
    return new ls(n).parse(e);
  }
  static parseInline(e, n) {
    return new ls(n).parseInline(e);
  }
  parse(e) {
    var r, s;
    this.renderer.parser = this;
    let n = "";
    for (let a = 0; a < e.length; a++) {
      let i = e[a];
      if ((s = (r = this.options.extensions) == null ? void 0 : r.renderers) != null && s[i.type]) {
        let l = i, c = this.options.extensions.renderers[l.type].call({ parser: this }, l);
        if (c !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "def", "paragraph", "text"].includes(l.type)) {
          n += c || "";
          continue;
        }
      }
      let o = i;
      switch (o.type) {
        case "space": {
          n += this.renderer.space(o);
          break;
        }
        case "hr": {
          n += this.renderer.hr(o);
          break;
        }
        case "heading": {
          n += this.renderer.heading(o);
          break;
        }
        case "code": {
          n += this.renderer.code(o);
          break;
        }
        case "table": {
          n += this.renderer.table(o);
          break;
        }
        case "blockquote": {
          n += this.renderer.blockquote(o);
          break;
        }
        case "list": {
          n += this.renderer.list(o);
          break;
        }
        case "checkbox": {
          n += this.renderer.checkbox(o);
          break;
        }
        case "html": {
          n += this.renderer.html(o);
          break;
        }
        case "def": {
          n += this.renderer.def(o);
          break;
        }
        case "paragraph": {
          n += this.renderer.paragraph(o);
          break;
        }
        case "text": {
          n += this.renderer.text(o);
          break;
        }
        default: {
          let l = 'Token with "' + o.type + '" type was not found.';
          if (this.options.silent) return console.error(l), "";
          throw new Error(l);
        }
      }
    }
    return n;
  }
  parseInline(e, n = this.renderer) {
    var s, a;
    this.renderer.parser = this;
    let r = "";
    for (let i = 0; i < e.length; i++) {
      let o = e[i];
      if ((a = (s = this.options.extensions) == null ? void 0 : s.renderers) != null && a[o.type]) {
        let c = this.options.extensions.renderers[o.type].call({ parser: this }, o);
        if (c !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(o.type)) {
          r += c || "";
          continue;
        }
      }
      let l = o;
      switch (l.type) {
        case "escape": {
          r += n.text(l);
          break;
        }
        case "html": {
          r += n.html(l);
          break;
        }
        case "link": {
          r += n.link(l);
          break;
        }
        case "image": {
          r += n.image(l);
          break;
        }
        case "checkbox": {
          r += n.checkbox(l);
          break;
        }
        case "strong": {
          r += n.strong(l);
          break;
        }
        case "em": {
          r += n.em(l);
          break;
        }
        case "codespan": {
          r += n.codespan(l);
          break;
        }
        case "br": {
          r += n.br(l);
          break;
        }
        case "del": {
          r += n.del(l);
          break;
        }
        case "text": {
          r += n.text(l);
          break;
        }
        default: {
          let c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent) return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return r;
  }
}, Nn, Zt = (Nn = class {
  constructor(e) {
    _(this, "options");
    _(this, "block");
    this.options = e || vt;
  }
  preprocess(e) {
    return e;
  }
  postprocess(e) {
    return e;
  }
  processAllTokens(e) {
    return e;
  }
  emStrongMask(e) {
    return e;
  }
  provideLexer(e = this.block) {
    return e ? Pe.lex : Pe.lexInline;
  }
  provideParser(e = this.block) {
    return e ? Le.parse : Le.parseInline;
  }
}, _(Nn, "passThroughHooks", /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"])), _(Nn, "passThroughHooksRespectAsync", /* @__PURE__ */ new Set(["preprocess", "postprocess", "processAllTokens"])), Nn), Lf = class {
  constructor(...e) {
    _(this, "defaults", Ds());
    _(this, "options", this.setOptions);
    _(this, "parse", this.parseMarkdown(!0));
    _(this, "parseInline", this.parseMarkdown(!1));
    _(this, "Parser", Le);
    _(this, "Renderer", qn);
    _(this, "TextRenderer", Ws);
    _(this, "Lexer", Pe);
    _(this, "Tokenizer", Hn);
    _(this, "Hooks", Zt);
    this.use(...e);
  }
  walkTokens(e, n) {
    var s, a;
    let r = [];
    for (let i of e) switch (r = r.concat(n.call(this, i)), i.type) {
      case "table": {
        let o = i;
        for (let l of o.header) r = r.concat(this.walkTokens(l.tokens, n));
        for (let l of o.rows) for (let c of l) r = r.concat(this.walkTokens(c.tokens, n));
        break;
      }
      case "list": {
        let o = i;
        r = r.concat(this.walkTokens(o.items, n));
        break;
      }
      default: {
        let o = i;
        (a = (s = this.defaults.extensions) == null ? void 0 : s.childTokens) != null && a[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((l) => {
          let c = o[l].flat(1 / 0);
          r = r.concat(this.walkTokens(c, n));
        }) : o.tokens && (r = r.concat(this.walkTokens(o.tokens, n)));
      }
    }
    return r;
  }
  use(...e) {
    let n = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      let s = { ...r };
      if (s.async = this.defaults.async || s.async || !1, r.extensions && (r.extensions.forEach((a) => {
        if (!a.name) throw new Error("extension name required");
        if ("renderer" in a) {
          let i = n.renderers[a.name];
          i ? n.renderers[a.name] = function(...o) {
            let l = a.renderer.apply(this, o);
            return l === !1 && (l = i.apply(this, o)), l;
          } : n.renderers[a.name] = a.renderer;
        }
        if ("tokenizer" in a) {
          if (!a.level || a.level !== "block" && a.level !== "inline") throw new Error("extension level must be 'block' or 'inline'");
          let i = n[a.level];
          i ? i.unshift(a.tokenizer) : n[a.level] = [a.tokenizer], a.start && (a.level === "block" ? n.startBlock ? n.startBlock.push(a.start) : n.startBlock = [a.start] : a.level === "inline" && (n.startInline ? n.startInline.push(a.start) : n.startInline = [a.start]));
        }
        "childTokens" in a && a.childTokens && (n.childTokens[a.name] = a.childTokens);
      }), s.extensions = n), r.renderer) {
        let a = this.defaults.renderer || new qn(this.defaults);
        for (let i in r.renderer) {
          if (!(i in a)) throw new Error(`renderer '${i}' does not exist`);
          if (["options", "parser"].includes(i)) continue;
          let o = i, l = r.renderer[o], c = a[o];
          a[o] = (...d) => {
            let p = l.apply(a, d);
            return p === !1 && (p = c.apply(a, d)), p || "";
          };
        }
        s.renderer = a;
      }
      if (r.tokenizer) {
        let a = this.defaults.tokenizer || new Hn(this.defaults);
        for (let i in r.tokenizer) {
          if (!(i in a)) throw new Error(`tokenizer '${i}' does not exist`);
          if (["options", "rules", "lexer"].includes(i)) continue;
          let o = i, l = r.tokenizer[o], c = a[o];
          a[o] = (...d) => {
            let p = l.apply(a, d);
            return p === !1 && (p = c.apply(a, d)), p;
          };
        }
        s.tokenizer = a;
      }
      if (r.hooks) {
        let a = this.defaults.hooks || new Zt();
        for (let i in r.hooks) {
          if (!(i in a)) throw new Error(`hook '${i}' does not exist`);
          if (["options", "block"].includes(i)) continue;
          let o = i, l = r.hooks[o], c = a[o];
          Zt.passThroughHooks.has(i) ? a[o] = (d) => {
            if (this.defaults.async && Zt.passThroughHooksRespectAsync.has(i)) return (async () => {
              let h = await l.call(a, d);
              return c.call(a, h);
            })();
            let p = l.call(a, d);
            return c.call(a, p);
          } : a[o] = (...d) => {
            if (this.defaults.async) return (async () => {
              let h = await l.apply(a, d);
              return h === !1 && (h = await c.apply(a, d)), h;
            })();
            let p = l.apply(a, d);
            return p === !1 && (p = c.apply(a, d)), p;
          };
        }
        s.hooks = a;
      }
      if (r.walkTokens) {
        let a = this.defaults.walkTokens, i = r.walkTokens;
        s.walkTokens = function(o) {
          let l = [];
          return l.push(i.call(this, o)), a && (l = l.concat(a.call(this, o))), l;
        };
      }
      this.defaults = { ...this.defaults, ...s };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, n) {
    return Pe.lex(e, n ?? this.defaults);
  }
  parser(e, n) {
    return Le.parse(e, n ?? this.defaults);
  }
  parseMarkdown(e) {
    return (n, r) => {
      let s = { ...r }, a = { ...this.defaults, ...s }, i = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && s.async === !1) return i(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof n > "u" || n === null) return i(new Error("marked(): input parameter is undefined or null"));
      if (typeof n != "string") return i(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(n) + ", string expected"));
      if (a.hooks && (a.hooks.options = a, a.hooks.block = e), a.async) return (async () => {
        let o = a.hooks ? await a.hooks.preprocess(n) : n, l = await (a.hooks ? await a.hooks.provideLexer(e) : e ? Pe.lex : Pe.lexInline)(o, a), c = a.hooks ? await a.hooks.processAllTokens(l) : l;
        a.walkTokens && await Promise.all(this.walkTokens(c, a.walkTokens));
        let d = await (a.hooks ? await a.hooks.provideParser(e) : e ? Le.parse : Le.parseInline)(c, a);
        return a.hooks ? await a.hooks.postprocess(d) : d;
      })().catch(i);
      try {
        a.hooks && (n = a.hooks.preprocess(n));
        let o = (a.hooks ? a.hooks.provideLexer(e) : e ? Pe.lex : Pe.lexInline)(n, a);
        a.hooks && (o = a.hooks.processAllTokens(o)), a.walkTokens && this.walkTokens(o, a.walkTokens);
        let l = (a.hooks ? a.hooks.provideParser(e) : e ? Le.parse : Le.parseInline)(o, a);
        return a.hooks && (l = a.hooks.postprocess(l)), l;
      } catch (o) {
        return i(o);
      }
    };
  }
  onError(e, n) {
    return (r) => {
      if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
        let s = "<p>An error occurred:</p><pre>" + Me(r.message + "", !0) + "</pre>";
        return n ? Promise.resolve(s) : s;
      }
      if (n) return Promise.reject(r);
      throw r;
    };
  }
}, bt = new Lf();
function W(t, e) {
  return bt.parse(t, e);
}
W.options = W.setOptions = function(t) {
  return bt.setOptions(t), W.defaults = bt.defaults, el(W.defaults), W;
};
W.getDefaults = Ds;
W.defaults = vt;
W.use = function(...t) {
  return bt.use(...t), W.defaults = bt.defaults, el(W.defaults), W;
};
W.walkTokens = function(t, e) {
  return bt.walkTokens(t, e);
};
W.parseInline = bt.parseInline;
W.Parser = Le;
W.parser = Le.parse;
W.Renderer = qn;
W.TextRenderer = Ws;
W.Lexer = Pe;
W.lexer = Pe.lex;
W.Tokenizer = Hn;
W.Hooks = Zt;
W.parse = W;
W.options;
W.setOptions;
W.use;
W.walkTokens;
W.parseInline;
Le.parse;
Pe.lex;
var cs = Object.defineProperty, $f = Object.getOwnPropertyDescriptor, Of = Object.getOwnPropertyNames, Mf = Object.prototype.hasOwnProperty, Zs = (t, e) => {
  let n = {};
  for (var r in t)
    cs(n, r, {
      get: t[r],
      enumerable: !0
    });
  return cs(n, Symbol.toStringTag, { value: "Module" }), n;
}, Df = (t, e, n, r) => {
  if (e && typeof e == "object" || typeof e == "function")
    for (var s = Of(e), a = 0, i = s.length, o; a < i; a++)
      o = s[a], !Mf.call(t, o) && o !== n && cs(t, o, {
        get: ((l) => e[l]).bind(null, o),
        enumerable: !(r = $f(e, o)) || r.enumerable
      });
  return t;
}, ul = (t, e, n) => (Df(t, e, "default"), n);
const dr = [
  {
    id: "abap",
    name: "ABAP",
    import: () => import("./abap-Y8Dl9g_6.mjs")
  },
  {
    id: "actionscript-3",
    name: "ActionScript",
    import: () => import("./actionscript-3-DQVEcJUW.mjs")
  },
  {
    id: "ada",
    name: "Ada",
    import: () => import("./ada-vP6ak0IW.mjs")
  },
  {
    id: "angular-html",
    name: "Angular HTML",
    import: () => import("./angular-html-lNFxrW4D.mjs").then((t) => t.f)
  },
  {
    id: "angular-ts",
    name: "Angular TypeScript",
    import: () => import("./angular-ts-BtJIZRsd.mjs")
  },
  {
    id: "apache",
    name: "Apache Conf",
    import: () => import("./apache-BUjz-sD2.mjs")
  },
  {
    id: "apex",
    name: "Apex",
    import: () => import("./apex-OyTfjCYK.mjs")
  },
  {
    id: "apl",
    name: "APL",
    import: () => import("./apl-BACOlzIL.mjs")
  },
  {
    id: "applescript",
    name: "AppleScript",
    import: () => import("./applescript-BPx7YFFu.mjs")
  },
  {
    id: "ara",
    name: "Ara",
    import: () => import("./ara-Z2fSOxSw.mjs")
  },
  {
    id: "asciidoc",
    name: "AsciiDoc",
    aliases: ["adoc"],
    import: () => import("./asciidoc-C1T9ziH6.mjs")
  },
  {
    id: "asm",
    name: "Assembly",
    import: () => import("./asm-BTWLY5ym.mjs")
  },
  {
    id: "astro",
    name: "Astro",
    import: () => import("./astro-BkMPLq0T.mjs")
  },
  {
    id: "awk",
    name: "AWK",
    import: () => import("./awk-Fb0P9dkn.mjs")
  },
  {
    id: "ballerina",
    name: "Ballerina",
    import: () => import("./ballerina-oZK-YekG.mjs")
  },
  {
    id: "bat",
    name: "Batch File",
    aliases: ["batch"],
    import: () => import("./bat-0FvbqU9S.mjs")
  },
  {
    id: "beancount",
    name: "Beancount",
    import: () => import("./beancount-DqJEb89h.mjs")
  },
  {
    id: "berry",
    name: "Berry",
    aliases: ["be"],
    import: () => import("./berry-DODBq_Ff.mjs")
  },
  {
    id: "bibtex",
    name: "BibTeX",
    import: () => import("./bibtex-EULQRLY5.mjs")
  },
  {
    id: "bicep",
    name: "Bicep",
    import: () => import("./bicep-BorU73w0.mjs")
  },
  {
    id: "bird2",
    name: "BIRD2 Configuration",
    aliases: ["bird"],
    import: () => import("./bird2-CSN72va7.mjs")
  },
  {
    id: "blade",
    name: "Blade",
    import: () => import("./blade-CIGuB2GL.mjs")
  },
  {
    id: "bsl",
    name: "1C (Enterprise)",
    aliases: ["1c"],
    import: () => import("./bsl-Dy8wYKq-.mjs")
  },
  {
    id: "c",
    name: "C",
    import: () => import("./c-eeMepfLm.mjs")
  },
  {
    id: "c3",
    name: "C3",
    import: () => import("./c3-BY5XW5ym.mjs")
  },
  {
    id: "cadence",
    name: "Cadence",
    aliases: ["cdc"],
    import: () => import("./cadence-02UX7mW8.mjs")
  },
  {
    id: "cairo",
    name: "Cairo",
    import: () => import("./cairo-DRXAUnCM.mjs")
  },
  {
    id: "clarity",
    name: "Clarity",
    import: () => import("./clarity-PKm5CwqM.mjs")
  },
  {
    id: "clojure",
    name: "Clojure",
    aliases: ["clj"],
    import: () => import("./clojure-CXJfHrL3.mjs")
  },
  {
    id: "cmake",
    name: "CMake",
    import: () => import("./cmake-BJz8BOTU.mjs")
  },
  {
    id: "cobol",
    name: "COBOL",
    import: () => import("./cobol-1B_UqKAC.mjs")
  },
  {
    id: "codeowners",
    name: "CODEOWNERS",
    import: () => import("./codeowners-Bt9yU6NX.mjs")
  },
  {
    id: "codeql",
    name: "CodeQL",
    aliases: ["ql"],
    import: () => import("./codeql-DHkodjjI.mjs")
  },
  {
    id: "coffee",
    name: "CoffeeScript",
    aliases: ["coffeescript"],
    import: () => import("./coffee-Q-gFdR7e.mjs")
  },
  {
    id: "common-lisp",
    name: "Common Lisp",
    aliases: ["lisp"],
    import: () => import("./common-lisp-EVqT9Zhp.mjs")
  },
  {
    id: "coq",
    name: "Coq",
    import: () => import("./coq-B0L9upzn.mjs")
  },
  {
    id: "cpp",
    name: "C++",
    aliases: ["c++"],
    import: () => import("./cpp-CGueNrnV.mjs")
  },
  {
    id: "crystal",
    name: "Crystal",
    import: () => import("./crystal-B8_YiGJQ.mjs")
  },
  {
    id: "csharp",
    name: "C#",
    aliases: ["c#", "cs"],
    import: () => import("./csharp-CCgA4A09.mjs")
  },
  {
    id: "css",
    name: "CSS",
    import: () => import("./css-M7EaDHN_.mjs")
  },
  {
    id: "csv",
    name: "CSV",
    import: () => import("./csv-CmYOceLb.mjs")
  },
  {
    id: "cue",
    name: "CUE",
    import: () => import("./cue-ZzumE7IT.mjs")
  },
  {
    id: "cypher",
    name: "Cypher",
    aliases: ["cql"],
    import: () => import("./cypher-jpdmjtA6.mjs")
  },
  {
    id: "d",
    name: "D",
    import: () => import("./d-CBagWSwH.mjs")
  },
  {
    id: "dart",
    name: "Dart",
    import: () => import("./dart-BoQ-8O4a.mjs")
  },
  {
    id: "dax",
    name: "DAX",
    import: () => import("./dax-CcDT-8dH.mjs")
  },
  {
    id: "desktop",
    name: "Desktop",
    import: () => import("./desktop-B93p9R9O.mjs")
  },
  {
    id: "diff",
    name: "Diff",
    import: () => import("./diff-BxzP2J8R.mjs")
  },
  {
    id: "docker",
    name: "Dockerfile",
    aliases: ["dockerfile"],
    import: () => import("./docker-CsHqm9tx.mjs")
  },
  {
    id: "dotenv",
    name: "dotEnv",
    import: () => import("./dotenv-BMjVjUL1.mjs")
  },
  {
    id: "dream-maker",
    name: "Dream Maker",
    import: () => import("./dream-maker-PAx17jaB.mjs")
  },
  {
    id: "edge",
    name: "Edge",
    import: () => import("./edge-ovVrfuFm.mjs")
  },
  {
    id: "elixir",
    name: "Elixir",
    import: () => import("./elixir-DgcyRSn9.mjs")
  },
  {
    id: "elm",
    name: "Elm",
    import: () => import("./elm-DCe9MkDR.mjs")
  },
  {
    id: "emacs-lisp",
    name: "Emacs Lisp",
    aliases: ["elisp"],
    import: () => import("./emacs-lisp-8iFotmUZ.mjs")
  },
  {
    id: "erb",
    name: "ERB",
    import: () => import("./erb-B0qYRPBj.mjs")
  },
  {
    id: "erlang",
    name: "Erlang",
    aliases: ["erl"],
    import: () => import("./erlang-CxyQpgjh.mjs")
  },
  {
    id: "fennel",
    name: "Fennel",
    import: () => import("./fennel-N4WcXuKx.mjs")
  },
  {
    id: "fish",
    name: "Fish",
    import: () => import("./fish-BTDEUgqH.mjs")
  },
  {
    id: "fluent",
    name: "Fluent",
    aliases: ["ftl"],
    import: () => import("./fluent-BMXUxfv1.mjs")
  },
  {
    id: "fortran-fixed-form",
    name: "Fortran (Fixed Form)",
    aliases: [
      "f",
      "for",
      "f77"
    ],
    import: () => import("./fortran-fixed-form-CYWf1Rx6.mjs")
  },
  {
    id: "fortran-free-form",
    name: "Fortran (Free Form)",
    aliases: [
      "f90",
      "f95",
      "f03",
      "f08",
      "f18"
    ],
    import: () => import("./fortran-free-form-CwqYvCLJ.mjs")
  },
  {
    id: "fsharp",
    name: "F#",
    aliases: ["f#", "fs"],
    import: () => import("./fsharp-DlcX35ZM.mjs")
  },
  {
    id: "gdresource",
    name: "GDResource",
    aliases: ["tscn", "tres"],
    import: () => import("./gdresource-jjZ_TMxS.mjs")
  },
  {
    id: "gdscript",
    name: "GDScript",
    aliases: ["gd"],
    import: () => import("./gdscript-DSAxJ_aS.mjs")
  },
  {
    id: "gdshader",
    name: "GDShader",
    import: () => import("./gdshader-Bk8fF6yr.mjs")
  },
  {
    id: "genie",
    name: "Genie",
    import: () => import("./genie-DzUvd7U9.mjs")
  },
  {
    id: "gherkin",
    name: "Gherkin",
    import: () => import("./gherkin-DHRaV0YP.mjs")
  },
  {
    id: "git-commit",
    name: "Git Commit Message",
    import: () => import("./git-commit-MKnTTyU-.mjs")
  },
  {
    id: "git-rebase",
    name: "Git Rebase Message",
    import: () => import("./git-rebase-CMl42lXc.mjs")
  },
  {
    id: "gleam",
    name: "Gleam",
    import: () => import("./gleam-Bv284lvN.mjs")
  },
  {
    id: "glimmer-js",
    name: "Glimmer JS",
    aliases: ["gjs"],
    import: () => import("./glimmer-js-BsY6YCkK.mjs")
  },
  {
    id: "glimmer-ts",
    name: "Glimmer TS",
    aliases: ["gts"],
    import: () => import("./glimmer-ts-BhrFcB93.mjs")
  },
  {
    id: "glsl",
    name: "GLSL",
    import: () => import("./glsl-CwleMY6T.mjs")
  },
  {
    id: "gn",
    name: "GN",
    import: () => import("./gn-XtJxiLa4.mjs")
  },
  {
    id: "gnuplot",
    name: "Gnuplot",
    import: () => import("./gnuplot-yPG9-sE_.mjs")
  },
  {
    id: "go",
    name: "Go",
    import: () => import("./go-EbF93JXO.mjs")
  },
  {
    id: "graphql",
    name: "GraphQL",
    aliases: ["gql"],
    import: () => import("./graphql-C2GhtI7U.mjs")
  },
  {
    id: "groovy",
    name: "Groovy",
    import: () => import("./groovy-CJQTphOW.mjs")
  },
  {
    id: "hack",
    name: "Hack",
    import: () => import("./hack-CoaZV4SK.mjs")
  },
  {
    id: "haml",
    name: "Ruby Haml",
    import: () => import("./haml-B5DPhreS.mjs")
  },
  {
    id: "handlebars",
    name: "Handlebars",
    aliases: ["hbs"],
    import: () => import("./handlebars-BazNiKNo.mjs")
  },
  {
    id: "haskell",
    name: "Haskell",
    aliases: ["hs"],
    import: () => import("./haskell-WeIwNIP6.mjs")
  },
  {
    id: "haxe",
    name: "Haxe",
    import: () => import("./haxe-TztHsm5T.mjs")
  },
  {
    id: "hcl",
    name: "HashiCorp HCL",
    import: () => import("./hcl-D438OF-I.mjs")
  },
  {
    id: "hjson",
    name: "Hjson",
    import: () => import("./hjson-DYBUbqOl.mjs")
  },
  {
    id: "hlsl",
    name: "HLSL",
    import: () => import("./hlsl-Bk8TCZNL.mjs")
  },
  {
    id: "html",
    name: "HTML",
    import: () => import("./html-BB9tIb0i.mjs")
  },
  {
    id: "html-derivative",
    name: "HTML (Derivative)",
    import: () => import("./html-derivative-C1R2Yf2t.mjs")
  },
  {
    id: "http",
    name: "HTTP",
    import: () => import("./http-Xl8ey4Mx.mjs")
  },
  {
    id: "hurl",
    name: "Hurl",
    import: () => import("./hurl-BP6fZ4DX.mjs")
  },
  {
    id: "hxml",
    name: "HXML",
    import: () => import("./hxml-L6NLEKuJ.mjs")
  },
  {
    id: "hy",
    name: "Hy",
    import: () => import("./hy-Brt5EZ7-.mjs")
  },
  {
    id: "imba",
    name: "Imba",
    import: () => import("./imba-CimUv-Uh.mjs")
  },
  {
    id: "ini",
    name: "INI",
    aliases: ["properties"],
    import: () => import("./ini-BZIuRIvJ.mjs")
  },
  {
    id: "java",
    name: "Java",
    import: () => import("./java-DY6VlHhP.mjs")
  },
  {
    id: "javascript",
    name: "JavaScript",
    aliases: [
      "js",
      "cjs",
      "mjs"
    ],
    import: () => import("./javascript-C25yR2R2.mjs")
  },
  {
    id: "jinja",
    name: "Jinja",
    import: () => import("./jinja-BfiZEZP1.mjs")
  },
  {
    id: "jison",
    name: "Jison",
    import: () => import("./jison-Dpv9Qnty.mjs")
  },
  {
    id: "json",
    name: "JSON",
    import: () => import("./json-DxJze_jm.mjs")
  },
  {
    id: "json5",
    name: "JSON5",
    import: () => import("./json5-BT4Fjg39.mjs")
  },
  {
    id: "jsonc",
    name: "JSON with Comments",
    import: () => import("./jsonc-CHjZD8gR.mjs")
  },
  {
    id: "jsonl",
    name: "JSON Lines",
    import: () => import("./jsonl-BGuvDmy9.mjs")
  },
  {
    id: "jsonnet",
    name: "Jsonnet",
    import: () => import("./jsonnet-Bx2cfsXg.mjs")
  },
  {
    id: "jssm",
    name: "JSSM",
    aliases: ["fsl"],
    import: () => import("./jssm-BcADi6EI.mjs")
  },
  {
    id: "jsx",
    name: "JSX",
    import: () => import("./jsx-BtKADgXT.mjs")
  },
  {
    id: "julia",
    name: "Julia",
    aliases: ["jl"],
    import: () => import("./julia-QwvTXUPU.mjs")
  },
  {
    id: "just",
    name: "Just",
    import: () => import("./just-XhCZAugK.mjs")
  },
  {
    id: "kdl",
    name: "KDL",
    import: () => import("./kdl-BNOv9TC3.mjs")
  },
  {
    id: "kotlin",
    name: "Kotlin",
    aliases: ["kt", "kts"],
    import: () => import("./kotlin-ByBMgTeR.mjs")
  },
  {
    id: "kusto",
    name: "Kusto",
    aliases: ["kql"],
    import: () => import("./kusto-BlqsQffZ.mjs")
  },
  {
    id: "latex",
    name: "LaTeX",
    import: () => import("./latex-BIROuDDD.mjs")
  },
  {
    id: "lean",
    name: "Lean 4",
    aliases: ["lean4"],
    import: () => import("./lean-BnVxaZxY.mjs")
  },
  {
    id: "less",
    name: "Less",
    import: () => import("./less-B1GLI2Di.mjs")
  },
  {
    id: "liquid",
    name: "Liquid",
    import: () => import("./liquid-DBOGX_wn.mjs")
  },
  {
    id: "llvm",
    name: "LLVM IR",
    import: () => import("./llvm-Bk2XctFf.mjs")
  },
  {
    id: "log",
    name: "Log file",
    import: () => import("./log-Al8wyEFV.mjs")
  },
  {
    id: "logo",
    name: "Logo",
    import: () => import("./logo-DBa4JDzV.mjs")
  },
  {
    id: "lua",
    name: "Lua",
    import: () => import("./lua-iI0nbkNb.mjs")
  },
  {
    id: "luau",
    name: "Luau",
    import: () => import("./luau-UQyhudEE.mjs")
  },
  {
    id: "make",
    name: "Makefile",
    aliases: ["makefile"],
    import: () => import("./make-CsMclxtr.mjs")
  },
  {
    id: "markdown",
    name: "Markdown",
    aliases: ["md"],
    import: () => import("./markdown-CrScaQ96.mjs")
  },
  {
    id: "marko",
    name: "Marko",
    import: () => import("./marko-CX5r0PxQ.mjs")
  },
  {
    id: "matlab",
    name: "MATLAB",
    import: () => import("./matlab-BOAaUVP0.mjs")
  },
  {
    id: "mdc",
    name: "MDC",
    import: () => import("./mdc-CWlfZSQV.mjs")
  },
  {
    id: "mdx",
    name: "MDX",
    import: () => import("./mdx-BOhZZUJ8.mjs")
  },
  {
    id: "mermaid",
    name: "Mermaid",
    aliases: ["mmd"],
    import: () => import("./mermaid-C3rz4dYh.mjs")
  },
  {
    id: "mipsasm",
    name: "MIPS Assembly",
    aliases: ["mips"],
    import: () => import("./mipsasm-CTx18fBl.mjs")
  },
  {
    id: "mojo",
    name: "Mojo",
    import: () => import("./mojo-EIZIZRTQ.mjs")
  },
  {
    id: "moonbit",
    name: "MoonBit",
    aliases: ["mbt", "mbti"],
    import: () => import("./moonbit-B1TV0fG3.mjs")
  },
  {
    id: "move",
    name: "Move",
    import: () => import("./move-Db4ltDq1.mjs")
  },
  {
    id: "narrat",
    name: "Narrat Language",
    aliases: ["nar"],
    import: () => import("./narrat-DmhDCBs-.mjs")
  },
  {
    id: "nextflow",
    name: "Nextflow",
    aliases: ["nf"],
    import: () => import("./nextflow-h8qxcPnC.mjs")
  },
  {
    id: "nextflow-groovy",
    name: "Nextflow Groovy",
    import: () => import("./nextflow-groovy-BXu3YCr0.mjs")
  },
  {
    id: "nginx",
    name: "Nginx",
    import: () => import("./nginx-I8jyit9T.mjs")
  },
  {
    id: "nim",
    name: "Nim",
    import: () => import("./nim-Cfr4mw83.mjs")
  },
  {
    id: "nix",
    name: "Nix",
    import: () => import("./nix-fTRXMGic.mjs")
  },
  {
    id: "nushell",
    name: "nushell",
    aliases: ["nu"],
    import: () => import("./nushell-BGCPRlV5.mjs")
  },
  {
    id: "objective-c",
    name: "Objective-C",
    aliases: ["objc"],
    import: () => import("./objective-c-Itk8tzmv.mjs")
  },
  {
    id: "objective-cpp",
    name: "Objective-C++",
    import: () => import("./objective-cpp-DGt5UKRO.mjs")
  },
  {
    id: "ocaml",
    name: "OCaml",
    import: () => import("./ocaml-eSVK32Eg.mjs")
  },
  {
    id: "odin",
    name: "Odin",
    import: () => import("./odin-BItnF517.mjs")
  },
  {
    id: "openscad",
    name: "OpenSCAD",
    aliases: ["scad"],
    import: () => import("./openscad-Sp5uZ6f2.mjs")
  },
  {
    id: "pascal",
    name: "Pascal",
    import: () => import("./pascal-xy8pJNns.mjs")
  },
  {
    id: "perl",
    name: "Perl",
    import: () => import("./perl-CY5lVRSj.mjs")
  },
  {
    id: "php",
    name: "PHP",
    import: () => import("./php-CFMwbGCV.mjs")
  },
  {
    id: "pkl",
    name: "Pkl",
    import: () => import("./pkl-C-zSNmaA.mjs")
  },
  {
    id: "plsql",
    name: "PL/SQL",
    import: () => import("./plsql-pVbGZfOv.mjs")
  },
  {
    id: "po",
    name: "Gettext PO",
    aliases: ["pot", "potx"],
    import: () => import("./po-BNfHvqmm.mjs")
  },
  {
    id: "polar",
    name: "Polar",
    import: () => import("./polar-CAZahv3u.mjs")
  },
  {
    id: "postcss",
    name: "PostCSS",
    import: () => import("./postcss-05aHdL-n.mjs")
  },
  {
    id: "powerquery",
    name: "PowerQuery",
    import: () => import("./powerquery-DI9HkTvs.mjs")
  },
  {
    id: "powershell",
    name: "PowerShell",
    aliases: ["ps", "ps1"],
    import: () => import("./powershell-Clc4ydu-.mjs")
  },
  {
    id: "prisma",
    name: "Prisma",
    import: () => import("./prisma-FZjmVtSl.mjs")
  },
  {
    id: "prolog",
    name: "Prolog",
    import: () => import("./prolog-C5-yg4TO.mjs")
  },
  {
    id: "proto",
    name: "Protocol Buffer 3",
    aliases: ["protobuf"],
    import: () => import("./proto-C7QgialS.mjs")
  },
  {
    id: "pug",
    name: "Pug",
    aliases: ["jade"],
    import: () => import("./pug-DGF9sKqX.mjs")
  },
  {
    id: "puppet",
    name: "Puppet",
    import: () => import("./puppet-CUJHmnxV.mjs")
  },
  {
    id: "purescript",
    name: "PureScript",
    import: () => import("./purescript-rUfGld-4.mjs")
  },
  {
    id: "python",
    name: "Python",
    aliases: ["py"],
    import: () => import("./python-BFNSHbwJ.mjs")
  },
  {
    id: "qml",
    name: "QML",
    import: () => import("./qml-BxN9rt5O.mjs")
  },
  {
    id: "qmldir",
    name: "QML Directory",
    import: () => import("./qmldir-BInDYbpo.mjs")
  },
  {
    id: "qss",
    name: "Qt Style Sheets",
    import: () => import("./qss-AeJTysr_.mjs")
  },
  {
    id: "r",
    name: "R",
    import: () => import("./r-CSmzDPi7.mjs")
  },
  {
    id: "racket",
    name: "Racket",
    import: () => import("./racket-B83wSAja.mjs")
  },
  {
    id: "raku",
    name: "Raku",
    aliases: ["perl6"],
    import: () => import("./raku-nEQ4ZJJ7.mjs")
  },
  {
    id: "razor",
    name: "ASP.NET Razor",
    import: () => import("./razor-CboOFVhy.mjs")
  },
  {
    id: "reg",
    name: "Windows Registry Script",
    import: () => import("./reg-m_s_Kiip.mjs")
  },
  {
    id: "regexp",
    name: "RegExp",
    aliases: ["regex"],
    import: () => import("./regexp-BazyLpPg.mjs")
  },
  {
    id: "rel",
    name: "Rel",
    import: () => import("./rel-BcRfyd6Q.mjs")
  },
  {
    id: "riscv",
    name: "RISC-V",
    import: () => import("./riscv-Ce8MAQLP.mjs")
  },
  {
    id: "ron",
    name: "RON",
    import: () => import("./ron-DCEEQypA.mjs")
  },
  {
    id: "rosmsg",
    name: "ROS Interface",
    import: () => import("./rosmsg-Cz0w1km8.mjs")
  },
  {
    id: "rst",
    name: "reStructuredText",
    import: () => import("./rst-ByxL8PUw.mjs")
  },
  {
    id: "ruby",
    name: "Ruby",
    aliases: ["rb"],
    import: () => import("./ruby-DZzBpFEF.mjs")
  },
  {
    id: "rust",
    name: "Rust",
    aliases: ["rs"],
    import: () => import("./rust-CLzF9zIN.mjs")
  },
  {
    id: "sas",
    name: "SAS",
    import: () => import("./sas-Dgv5I5OF.mjs")
  },
  {
    id: "sass",
    name: "Sass",
    import: () => import("./sass-DxHp5rTx.mjs")
  },
  {
    id: "scala",
    name: "Scala",
    import: () => import("./scala-D4grkFkl.mjs")
  },
  {
    id: "scheme",
    name: "Scheme",
    import: () => import("./scheme-BCRWuEm4.mjs")
  },
  {
    id: "scss",
    name: "SCSS",
    import: () => import("./scss-PX6N6aWB.mjs")
  },
  {
    id: "sdbl",
    name: "1C (Query)",
    aliases: ["1c-query"],
    import: () => import("./sdbl-B7T8abf4.mjs")
  },
  {
    id: "shaderlab",
    name: "ShaderLab",
    aliases: ["shader"],
    import: () => import("./shaderlab-D_9jCtR2.mjs")
  },
  {
    id: "shellscript",
    name: "Shell",
    aliases: [
      "bash",
      "sh",
      "shell",
      "zsh"
    ],
    import: () => import("./shellscript-InADTalH.mjs")
  },
  {
    id: "shellsession",
    name: "Shell Session",
    aliases: ["console"],
    import: () => import("./shellsession-DtcyY-Wh.mjs")
  },
  {
    id: "smalltalk",
    name: "Smalltalk",
    import: () => import("./smalltalk-BlI1_OkM.mjs")
  },
  {
    id: "solidity",
    name: "Solidity",
    import: () => import("./solidity-DUWnFhS6.mjs")
  },
  {
    id: "soy",
    name: "Closure Templates",
    aliases: ["closure-templates"],
    import: () => import("./soy-BdQKKL7E.mjs")
  },
  {
    id: "sparql",
    name: "SPARQL",
    import: () => import("./sparql-B6tDvEgg.mjs")
  },
  {
    id: "splunk",
    name: "Splunk Query Language",
    aliases: ["spl"],
    import: () => import("./splunk-CRXR8A9s.mjs")
  },
  {
    id: "sql",
    name: "SQL",
    import: () => import("./sql-Cn_v3PB0.mjs")
  },
  {
    id: "ssh-config",
    name: "SSH Config",
    import: () => import("./ssh-config-DP-hNVbF.mjs")
  },
  {
    id: "stata",
    name: "Stata",
    import: () => import("./stata-CuK25SjT.mjs")
  },
  {
    id: "stylus",
    name: "Stylus",
    aliases: ["styl"],
    import: () => import("./stylus-CyKEU1Ej.mjs")
  },
  {
    id: "surrealql",
    name: "SurrealQL",
    aliases: ["surql"],
    import: () => import("./surrealql-BDLrXDJ-.mjs")
  },
  {
    id: "svelte",
    name: "Svelte",
    import: () => import("./svelte-6X4Qklxg.mjs")
  },
  {
    id: "swift",
    name: "Swift",
    import: () => import("./swift-DJpUqPLg.mjs")
  },
  {
    id: "system-verilog",
    name: "SystemVerilog",
    import: () => import("./system-verilog-BCm7smPJ.mjs")
  },
  {
    id: "systemd",
    name: "Systemd Units",
    import: () => import("./systemd-C-4qm6XH.mjs")
  },
  {
    id: "talonscript",
    name: "TalonScript",
    aliases: ["talon"],
    import: () => import("./talonscript-CFF3LF_O.mjs")
  },
  {
    id: "tasl",
    name: "Tasl",
    import: () => import("./tasl-Cg_WBUAe.mjs")
  },
  {
    id: "tcl",
    name: "Tcl",
    import: () => import("./tcl-DN7buRTF.mjs")
  },
  {
    id: "templ",
    name: "Templ",
    import: () => import("./templ-JRmNQ6wm.mjs")
  },
  {
    id: "terraform",
    name: "Terraform",
    aliases: ["tf", "tfvars"],
    import: () => import("./terraform-DGvcn9zM.mjs")
  },
  {
    id: "tex",
    name: "TeX",
    import: () => import("./tex-DOhhcXXM.mjs")
  },
  {
    id: "toml",
    name: "TOML",
    import: () => import("./toml-DY62mUL_.mjs")
  },
  {
    id: "ts-tags",
    name: "TypeScript with Tags",
    aliases: ["lit"],
    import: () => import("./ts-tags-DTDJJFuY.mjs")
  },
  {
    id: "tsv",
    name: "TSV",
    import: () => import("./tsv-BtvSkaG0.mjs")
  },
  {
    id: "tsx",
    name: "TSX",
    import: () => import("./tsx-B8rCNbgL.mjs")
  },
  {
    id: "turtle",
    name: "Turtle",
    import: () => import("./turtle-_H59FV7D.mjs")
  },
  {
    id: "twig",
    name: "Twig",
    import: () => import("./twig-BLtMFr4A.mjs")
  },
  {
    id: "typescript",
    name: "TypeScript",
    aliases: [
      "ts",
      "cts",
      "mts"
    ],
    import: () => import("./typescript-RycA9KXf.mjs")
  },
  {
    id: "typespec",
    name: "TypeSpec",
    aliases: ["tsp"],
    import: () => import("./typespec-CGUtYYRV.mjs")
  },
  {
    id: "typst",
    name: "Typst",
    aliases: ["typ"],
    import: () => import("./typst-D_1QKWns.mjs")
  },
  {
    id: "v",
    name: "V",
    import: () => import("./v-BPCNiyYe.mjs")
  },
  {
    id: "vala",
    name: "Vala",
    import: () => import("./vala-uxaPR7d1.mjs")
  },
  {
    id: "vb",
    name: "Visual Basic",
    aliases: ["cmd"],
    import: () => import("./vb-D8_c5-KN.mjs")
  },
  {
    id: "verilog",
    name: "Verilog",
    import: () => import("./verilog-B-bybjPF.mjs")
  },
  {
    id: "vhdl",
    name: "VHDL",
    import: () => import("./vhdl-CUlNa8ac.mjs")
  },
  {
    id: "viml",
    name: "Vim Script",
    aliases: ["vim", "vimscript"],
    import: () => import("./viml-DsfA-sWm.mjs")
  },
  {
    id: "vue",
    name: "Vue",
    import: () => import("./vue-De04cH4b.mjs")
  },
  {
    id: "vue-html",
    name: "Vue HTML",
    import: () => import("./vue-html-Cg0YpUCP.mjs")
  },
  {
    id: "vue-vine",
    name: "Vue Vine",
    import: () => import("./vue-vine-DX5cRNW3.mjs")
  },
  {
    id: "vyper",
    name: "Vyper",
    aliases: ["vy"],
    import: () => import("./vyper-CPQuu50u.mjs")
  },
  {
    id: "wasm",
    name: "WebAssembly",
    import: () => import("./wasm-BBXxrAl7.mjs")
  },
  {
    id: "wenyan",
    name: "Wenyan",
    aliases: ["文言"],
    import: () => import("./wenyan-pbVjoM9_.mjs")
  },
  {
    id: "wgsl",
    name: "WGSL",
    import: () => import("./wgsl-DY4iK1q1.mjs")
  },
  {
    id: "wikitext",
    name: "Wikitext",
    aliases: ["mediawiki", "wiki"],
    import: () => import("./wikitext-Z-MoUasO.mjs")
  },
  {
    id: "wit",
    name: "WebAssembly Interface Types",
    import: () => import("./wit-CQMQOlTg.mjs")
  },
  {
    id: "wolfram",
    name: "Wolfram",
    aliases: ["wl"],
    import: () => import("./wolfram-Dz4KXISs.mjs")
  },
  {
    id: "xml",
    name: "XML",
    import: () => import("./xml-Dwj6NfjK.mjs")
  },
  {
    id: "xsl",
    name: "XSL",
    import: () => import("./xsl-Pe9theme.mjs")
  },
  {
    id: "yaml",
    name: "YAML",
    aliases: ["yml"],
    import: () => import("./yaml-DaO7k5B1.mjs")
  },
  {
    id: "zenscript",
    name: "ZenScript",
    import: () => import("./zenscript-CxBjpf9c.mjs")
  },
  {
    id: "zig",
    name: "Zig",
    import: () => import("./zig-Vm0PO9wB.mjs")
  }
], Vs = Object.fromEntries(dr.map((t) => [t.id, t.import])), Js = Object.fromEntries(dr.flatMap((t) => {
  var e;
  return ((e = t.aliases) == null ? void 0 : e.map((n) => [n, t.import])) || [];
})), hr = {
  ...Vs,
  ...Js
}, Qs = [
  {
    id: "andromeeda",
    displayName: "Andromeeda",
    type: "dark",
    import: () => import("./andromeeda-BbmzSJq1.mjs")
  },
  {
    id: "aurora-x",
    displayName: "Aurora X",
    type: "dark",
    import: () => import("./aurora-x-BwoVEUWZ.mjs")
  },
  {
    id: "ayu-dark",
    displayName: "Ayu Dark",
    type: "dark",
    import: () => import("./ayu-dark-DJoqd4M9.mjs")
  },
  {
    id: "ayu-light",
    displayName: "Ayu Light",
    type: "light",
    import: () => import("./ayu-light-BzXEJRJ-.mjs")
  },
  {
    id: "ayu-mirage",
    displayName: "Ayu Mirage",
    type: "dark",
    import: () => import("./ayu-mirage-BJ2oZGzi.mjs")
  },
  {
    id: "catppuccin-frappe",
    displayName: "Catppuccin Frappé",
    type: "dark",
    import: () => import("./catppuccin-frappe-D3cH2rXe.mjs")
  },
  {
    id: "catppuccin-latte",
    displayName: "Catppuccin Latte",
    type: "light",
    import: () => import("./catppuccin-latte-C0LRGUW4.mjs")
  },
  {
    id: "catppuccin-macchiato",
    displayName: "Catppuccin Macchiato",
    type: "dark",
    import: () => import("./catppuccin-macchiato-c5wQ11TT.mjs")
  },
  {
    id: "catppuccin-mocha",
    displayName: "Catppuccin Mocha",
    type: "dark",
    import: () => import("./catppuccin-mocha-WMD6Qvya.mjs")
  },
  {
    id: "dark-plus",
    displayName: "Dark Plus",
    type: "dark",
    import: () => import("./dark-plus-pUHDTVV0.mjs")
  },
  {
    id: "dracula",
    displayName: "Dracula Theme",
    type: "dark",
    import: () => import("./dracula-BtZx2Kac.mjs")
  },
  {
    id: "dracula-soft",
    displayName: "Dracula Theme Soft",
    type: "dark",
    import: () => import("./dracula-soft-BKa-aqBv.mjs")
  },
  {
    id: "everforest-dark",
    displayName: "Everforest Dark",
    type: "dark",
    import: () => import("./everforest-dark-DMCBqXCK.mjs")
  },
  {
    id: "everforest-light",
    displayName: "Everforest Light",
    type: "light",
    import: () => import("./everforest-light-BbXl82Em.mjs")
  },
  {
    id: "github-dark",
    displayName: "GitHub Dark",
    type: "dark",
    import: () => import("./github-dark-DenFmJkN.mjs")
  },
  {
    id: "github-dark-default",
    displayName: "GitHub Dark Default",
    type: "dark",
    import: () => import("./github-dark-default-BJPUVz4H.mjs")
  },
  {
    id: "github-dark-dimmed",
    displayName: "GitHub Dark Dimmed",
    type: "dark",
    import: () => import("./github-dark-dimmed-DUshB20C.mjs")
  },
  {
    id: "github-dark-high-contrast",
    displayName: "GitHub Dark High Contrast",
    type: "dark",
    import: () => import("./github-dark-high-contrast-D3aGCnF8.mjs")
  },
  {
    id: "github-light",
    displayName: "GitHub Light",
    type: "light",
    import: () => import("./github-light-JYsPkUQd.mjs")
  },
  {
    id: "github-light-default",
    displayName: "GitHub Light Default",
    type: "light",
    import: () => import("./github-light-default-D99KPAby.mjs")
  },
  {
    id: "github-light-high-contrast",
    displayName: "GitHub Light High Contrast",
    type: "light",
    import: () => import("./github-light-high-contrast-BbmZE-Mp.mjs")
  },
  {
    id: "gruvbox-dark-hard",
    displayName: "Gruvbox Dark Hard",
    type: "dark",
    import: () => import("./gruvbox-dark-hard-C5HOtKIh.mjs")
  },
  {
    id: "gruvbox-dark-medium",
    displayName: "Gruvbox Dark Medium",
    type: "dark",
    import: () => import("./gruvbox-dark-medium-FVgwJHuz.mjs")
  },
  {
    id: "gruvbox-dark-soft",
    displayName: "Gruvbox Dark Soft",
    type: "dark",
    import: () => import("./gruvbox-dark-soft-B46F314v.mjs")
  },
  {
    id: "gruvbox-light-hard",
    displayName: "Gruvbox Light Hard",
    type: "light",
    import: () => import("./gruvbox-light-hard-CJD38wDZ.mjs")
  },
  {
    id: "gruvbox-light-medium",
    displayName: "Gruvbox Light Medium",
    type: "light",
    import: () => import("./gruvbox-light-medium-BlIhMYTA.mjs")
  },
  {
    id: "gruvbox-light-soft",
    displayName: "Gruvbox Light Soft",
    type: "light",
    import: () => import("./gruvbox-light-soft-DoPHyLVZ.mjs")
  },
  {
    id: "horizon",
    displayName: "Horizon",
    type: "dark",
    import: () => import("./horizon-CJQ10nlf.mjs")
  },
  {
    id: "horizon-bright",
    displayName: "Horizon Bright",
    type: "light",
    import: () => import("./horizon-bright-2WzHy-Vo.mjs")
  },
  {
    id: "houston",
    displayName: "Houston",
    type: "dark",
    import: () => import("./houston-BDYrDoDW.mjs")
  },
  {
    id: "kanagawa-dragon",
    displayName: "Kanagawa Dragon",
    type: "dark",
    import: () => import("./kanagawa-dragon-CiKur4Hl.mjs")
  },
  {
    id: "kanagawa-lotus",
    displayName: "Kanagawa Lotus",
    type: "light",
    import: () => import("./kanagawa-lotus-BKu-smKu.mjs")
  },
  {
    id: "kanagawa-wave",
    displayName: "Kanagawa Wave",
    type: "dark",
    import: () => import("./kanagawa-wave-CQwozSzG.mjs")
  },
  {
    id: "laserwave",
    displayName: "LaserWave",
    type: "dark",
    import: () => import("./laserwave-6a00oqik.mjs")
  },
  {
    id: "light-plus",
    displayName: "Light Plus",
    type: "light",
    import: () => import("./light-plus-CZuVqSLX.mjs")
  },
  {
    id: "material-theme",
    displayName: "Material Theme",
    type: "dark",
    import: () => import("./material-theme-D6KBX41T.mjs")
  },
  {
    id: "material-theme-darker",
    displayName: "Material Theme Darker",
    type: "dark",
    import: () => import("./material-theme-darker-CkRroheE.mjs")
  },
  {
    id: "material-theme-lighter",
    displayName: "Material Theme Lighter",
    type: "light",
    import: () => import("./material-theme-lighter-BUBw43Yz.mjs")
  },
  {
    id: "material-theme-ocean",
    displayName: "Material Theme Ocean",
    type: "dark",
    import: () => import("./material-theme-ocean-ClGX14Ja.mjs")
  },
  {
    id: "material-theme-palenight",
    displayName: "Material Theme Palenight",
    type: "dark",
    import: () => import("./material-theme-palenight-C1RVm8K1.mjs")
  },
  {
    id: "min-dark",
    displayName: "Min Dark",
    type: "dark",
    import: () => import("./min-dark-C7ak0t6c.mjs")
  },
  {
    id: "min-light",
    displayName: "Min Light",
    type: "light",
    import: () => import("./min-light-CKFxVcPp.mjs")
  },
  {
    id: "monokai",
    displayName: "Monokai",
    type: "dark",
    import: () => import("./monokai-C1KBYcO0.mjs")
  },
  {
    id: "night-owl",
    displayName: "Night Owl",
    type: "dark",
    import: () => import("./night-owl-Bm2rzalh.mjs")
  },
  {
    id: "night-owl-light",
    displayName: "Night Owl Light",
    type: "light",
    import: () => import("./night-owl-light-CBI5u5kw.mjs")
  },
  {
    id: "nord",
    displayName: "Nord",
    type: "dark",
    import: () => import("./nord-CC5OiUXg.mjs")
  },
  {
    id: "one-dark-pro",
    displayName: "One Dark Pro",
    type: "dark",
    import: () => import("./one-dark-pro-DTA3VF0_.mjs")
  },
  {
    id: "one-light",
    displayName: "One Light",
    type: "light",
    import: () => import("./one-light-LkMrt1Cf.mjs")
  },
  {
    id: "plastic",
    displayName: "Plastic",
    type: "dark",
    import: () => import("./plastic-CSTz3KZp.mjs")
  },
  {
    id: "poimandres",
    displayName: "Poimandres",
    type: "dark",
    import: () => import("./poimandres-C-VADXHD.mjs")
  },
  {
    id: "red",
    displayName: "Red",
    type: "dark",
    import: () => import("./red-7y8PH7HH.mjs")
  },
  {
    id: "rose-pine",
    displayName: "Rosé Pine",
    type: "dark",
    import: () => import("./rose-pine-BKc3yVeu.mjs")
  },
  {
    id: "rose-pine-dawn",
    displayName: "Rosé Pine Dawn",
    type: "light",
    import: () => import("./rose-pine-dawn-BulJcPZT.mjs")
  },
  {
    id: "rose-pine-moon",
    displayName: "Rosé Pine Moon",
    type: "dark",
    import: () => import("./rose-pine-moon-j6jiXKV8.mjs")
  },
  {
    id: "slack-dark",
    displayName: "Slack Dark",
    type: "dark",
    import: () => import("./slack-dark-i7wN4OET.mjs")
  },
  {
    id: "slack-ochin",
    displayName: "Slack Ochin",
    type: "light",
    import: () => import("./slack-ochin-ndHf0LoP.mjs")
  },
  {
    id: "snazzy-light",
    displayName: "Snazzy Light",
    type: "light",
    import: () => import("./snazzy-light-BlSJXAu4.mjs")
  },
  {
    id: "solarized-dark",
    displayName: "Solarized Dark",
    type: "dark",
    import: () => import("./solarized-dark-UTmkh7lw.mjs")
  },
  {
    id: "solarized-light",
    displayName: "Solarized Light",
    type: "light",
    import: () => import("./solarized-light-BheCkDPT.mjs")
  },
  {
    id: "synthwave-84",
    displayName: "Synthwave '84",
    type: "dark",
    import: () => import("./synthwave-84-NU3C_KFZ.mjs")
  },
  {
    id: "tokyo-night",
    displayName: "Tokyo Night",
    type: "dark",
    import: () => import("./tokyo-night-DP4TmcQl.mjs")
  },
  {
    id: "vesper",
    displayName: "Vesper",
    type: "dark",
    import: () => import("./vesper-BckBta1U.mjs")
  },
  {
    id: "vitesse-black",
    displayName: "Vitesse Black",
    type: "dark",
    import: () => import("./vitesse-black-BoGvW84i.mjs")
  },
  {
    id: "vitesse-dark",
    displayName: "Vitesse Dark",
    type: "dark",
    import: () => import("./vitesse-dark-Cym-eLtO.mjs")
  },
  {
    id: "vitesse-light",
    displayName: "Vitesse Light",
    type: "light",
    import: () => import("./vitesse-light-CcmG315c.mjs")
  }
], Ys = Object.fromEntries(Qs.map((t) => [t.id, t.import]));
var Xs = class extends Error {
  constructor(e) {
    super(e), this.name = "ShikiError";
  }
};
function Bf() {
  return 2147483648;
}
function Ff() {
  return typeof performance < "u" ? performance.now() : Date.now();
}
const Gf = (t, e) => t + (e - t % e) % e;
async function zf(t) {
  let e, n;
  const r = {};
  function s(m) {
    n = m, r.HEAPU8 = new Uint8Array(m), r.HEAPU32 = new Uint32Array(m);
  }
  function a(m, f, g) {
    r.HEAPU8.copyWithin(m, f, f + g);
  }
  function i(m) {
    try {
      return e.grow(m - n.byteLength + 65535 >>> 16), s(e.buffer), 1;
    } catch {
    }
  }
  function o(m) {
    const f = r.HEAPU8.length;
    m = m >>> 0;
    const g = Bf();
    if (m > g)
      return !1;
    for (let b = 1; b <= 4; b *= 2) {
      let v = f * (1 + 0.2 / b);
      v = Math.min(v, m + 100663296);
      const w = Math.min(g, Gf(Math.max(m, v), 65536));
      if (i(w))
        return !0;
    }
    return !1;
  }
  const l = typeof TextDecoder < "u" ? new TextDecoder("utf8") : void 0;
  function c(m, f, g = 1024) {
    const b = f + g;
    let v = f;
    for (; m[v] && !(v >= b); ) ++v;
    if (v - f > 16 && m.buffer && l)
      return l.decode(m.subarray(f, v));
    let w = "";
    for (; f < v; ) {
      let x = m[f++];
      if (!(x & 128)) {
        w += String.fromCharCode(x);
        continue;
      }
      const k = m[f++] & 63;
      if ((x & 224) === 192) {
        w += String.fromCharCode((x & 31) << 6 | k);
        continue;
      }
      const S = m[f++] & 63;
      if ((x & 240) === 224 ? x = (x & 15) << 12 | k << 6 | S : x = (x & 7) << 18 | k << 12 | S << 6 | m[f++] & 63, x < 65536)
        w += String.fromCharCode(x);
      else {
        const N = x - 65536;
        w += String.fromCharCode(55296 | N >> 10, 56320 | N & 1023);
      }
    }
    return w;
  }
  function d(m, f) {
    return m ? c(r.HEAPU8, m, f) : "";
  }
  const p = {
    emscripten_get_now: Ff,
    emscripten_memcpy_big: a,
    emscripten_resize_heap: o,
    fd_write: () => 0
  };
  async function h() {
    const f = await t({
      env: p,
      wasi_snapshot_preview1: p
    });
    e = f.memory, s(e.buffer), Object.assign(r, f), r.UTF8ToString = d;
  }
  return await h(), r;
}
var Uf = Object.defineProperty, Hf = (t, e, n) => e in t ? Uf(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n, re = (t, e, n) => Hf(t, typeof e != "symbol" ? e + "" : e, n);
let oe = null;
function qf(t) {
  throw new Xs(t.UTF8ToString(t.getLastOnigError()));
}
class fr {
  constructor(e) {
    re(this, "utf16Length"), re(this, "utf8Length"), re(this, "utf16Value"), re(this, "utf8Value"), re(this, "utf16OffsetToUtf8"), re(this, "utf8OffsetToUtf16");
    const n = e.length, r = fr._utf8ByteLength(e), s = r !== n, a = s ? new Uint32Array(n + 1) : null;
    s && (a[n] = r);
    const i = s ? new Uint32Array(r + 1) : null;
    s && (i[r] = n);
    const o = new Uint8Array(r);
    let l = 0;
    for (let c = 0; c < n; c++) {
      const d = e.charCodeAt(c);
      let p = d, h = !1;
      if (d >= 55296 && d <= 56319 && c + 1 < n) {
        const m = e.charCodeAt(c + 1);
        m >= 56320 && m <= 57343 && (p = (d - 55296 << 10) + 65536 | m - 56320, h = !0);
      }
      s && (a[c] = l, h && (a[c + 1] = l), p <= 127 ? i[l + 0] = c : p <= 2047 ? (i[l + 0] = c, i[l + 1] = c) : p <= 65535 ? (i[l + 0] = c, i[l + 1] = c, i[l + 2] = c) : (i[l + 0] = c, i[l + 1] = c, i[l + 2] = c, i[l + 3] = c)), p <= 127 ? o[l++] = p : p <= 2047 ? (o[l++] = 192 | (p & 1984) >>> 6, o[l++] = 128 | (p & 63) >>> 0) : p <= 65535 ? (o[l++] = 224 | (p & 61440) >>> 12, o[l++] = 128 | (p & 4032) >>> 6, o[l++] = 128 | (p & 63) >>> 0) : (o[l++] = 240 | (p & 1835008) >>> 18, o[l++] = 128 | (p & 258048) >>> 12, o[l++] = 128 | (p & 4032) >>> 6, o[l++] = 128 | (p & 63) >>> 0), h && c++;
    }
    this.utf16Length = n, this.utf8Length = r, this.utf16Value = e, this.utf8Value = o, this.utf16OffsetToUtf8 = a, this.utf8OffsetToUtf16 = i;
  }
  static _utf8ByteLength(e) {
    let n = 0;
    for (let r = 0, s = e.length; r < s; r++) {
      const a = e.charCodeAt(r);
      let i = a, o = !1;
      if (a >= 55296 && a <= 56319 && r + 1 < s) {
        const l = e.charCodeAt(r + 1);
        l >= 56320 && l <= 57343 && (i = (a - 55296 << 10) + 65536 | l - 56320, o = !0);
      }
      i <= 127 ? n += 1 : i <= 2047 ? n += 2 : i <= 65535 ? n += 3 : n += 4, o && r++;
    }
    return n;
  }
  createString(e) {
    const n = e.omalloc(this.utf8Length);
    return e.HEAPU8.set(this.utf8Value, n), n;
  }
}
const mr = class De {
  constructor(e) {
    if (re(this, "id", ++De.LAST_ID), re(this, "_onigBinding"), re(this, "content"), re(this, "utf16Length"), re(this, "utf8Length"), re(this, "utf16OffsetToUtf8"), re(this, "utf8OffsetToUtf16"), re(this, "ptr"), !oe)
      throw new Xs("Must invoke loadWasm first.");
    this._onigBinding = oe, this.content = e;
    const n = new fr(e);
    this.utf16Length = n.utf16Length, this.utf8Length = n.utf8Length, this.utf16OffsetToUtf8 = n.utf16OffsetToUtf8, this.utf8OffsetToUtf16 = n.utf8OffsetToUtf16, this.utf8Length < 1e4 && !De._sharedPtrInUse ? (De._sharedPtr || (De._sharedPtr = oe.omalloc(1e4)), De._sharedPtrInUse = !0, oe.HEAPU8.set(n.utf8Value, De._sharedPtr), this.ptr = De._sharedPtr) : this.ptr = n.createString(oe);
  }
  convertUtf8OffsetToUtf16(e) {
    return this.utf8OffsetToUtf16 ? e < 0 ? 0 : e > this.utf8Length ? this.utf16Length : this.utf8OffsetToUtf16[e] : e;
  }
  convertUtf16OffsetToUtf8(e) {
    return this.utf16OffsetToUtf8 ? e < 0 ? 0 : e > this.utf16Length ? this.utf8Length : this.utf16OffsetToUtf8[e] : e;
  }
  dispose() {
    this.ptr === De._sharedPtr ? De._sharedPtrInUse = !1 : this._onigBinding.ofree(this.ptr);
  }
};
re(mr, "LAST_ID", 0);
re(mr, "_sharedPtr", 0);
re(mr, "_sharedPtrInUse", !1);
let pl = mr;
class Wf {
  constructor(e) {
    if (re(this, "_onigBinding"), re(this, "_ptr"), !oe)
      throw new Xs("Must invoke loadWasm first.");
    const n = [], r = [];
    for (let o = 0, l = e.length; o < l; o++) {
      const c = new fr(e[o]);
      n[o] = c.createString(oe), r[o] = c.utf8Length;
    }
    const s = oe.omalloc(4 * e.length);
    oe.HEAPU32.set(n, s / 4);
    const a = oe.omalloc(4 * e.length);
    oe.HEAPU32.set(r, a / 4);
    const i = oe.createOnigScanner(s, a, e.length);
    for (let o = 0, l = e.length; o < l; o++)
      oe.ofree(n[o]);
    oe.ofree(a), oe.ofree(s), i === 0 && qf(oe), this._onigBinding = oe, this._ptr = i;
  }
  dispose() {
    this._onigBinding.freeOnigScanner(this._ptr);
  }
  findNextMatchSync(e, n, r) {
    let s = 0;
    if (typeof r == "number" && (s = r), typeof e == "string") {
      e = new pl(e);
      const a = this._findNextMatchSync(e, n, !1, s);
      return e.dispose(), a;
    }
    return this._findNextMatchSync(e, n, !1, s);
  }
  _findNextMatchSync(e, n, r, s) {
    const a = this._onigBinding, i = a.findNextOnigScannerMatch(this._ptr, e.id, e.ptr, e.utf8Length, e.convertUtf16OffsetToUtf8(n), s);
    if (i === 0)
      return null;
    const o = a.HEAPU32;
    let l = i / 4;
    const c = o[l++], d = o[l++], p = [];
    for (let h = 0; h < d; h++) {
      const m = e.convertUtf8OffsetToUtf16(o[l++]), f = e.convertUtf8OffsetToUtf16(o[l++]);
      p[h] = {
        start: m,
        end: f,
        length: f - m
      };
    }
    return {
      index: c,
      captureIndices: p
    };
  }
}
function Zf(t) {
  return typeof t.instantiator == "function";
}
function Vf(t) {
  return typeof t.default == "function";
}
function Jf(t) {
  return typeof t.data < "u";
}
function Qf(t) {
  return typeof Response < "u" && t instanceof Response;
}
function Yf(t) {
  var e;
  return typeof ArrayBuffer < "u" && (t instanceof ArrayBuffer || ArrayBuffer.isView(t)) || typeof Buffer < "u" && ((e = Buffer.isBuffer) == null ? void 0 : e.call(Buffer, t)) || typeof SharedArrayBuffer < "u" && t instanceof SharedArrayBuffer || typeof Uint32Array < "u" && t instanceof Uint32Array;
}
let xn;
function Ks(t) {
  if (xn)
    return xn;
  async function e() {
    oe = await zf(async (n) => {
      let r = t;
      return r = await r, typeof r == "function" && (r = await r(n)), typeof r == "function" && (r = await r(n)), Zf(r) ? r = await r.instantiator(n) : Vf(r) ? r = await r.default(n) : (Jf(r) && (r = r.data), Qf(r) ? typeof WebAssembly.instantiateStreaming == "function" ? r = await Xf(r)(n) : r = await Kf(r)(n) : Yf(r) ? r = await Lr(r)(n) : r instanceof WebAssembly.Module ? r = await Lr(r)(n) : "default" in r && r.default instanceof WebAssembly.Module && (r = await Lr(r.default)(n))), "instance" in r && (r = r.instance), "exports" in r && (r = r.exports), r;
    });
  }
  return xn = e(), xn;
}
function Lr(t) {
  return (e) => WebAssembly.instantiate(t, e);
}
function Xf(t) {
  return (e) => WebAssembly.instantiateStreaming(t, e);
}
function Kf(t) {
  return async (e) => {
    const n = await t.arrayBuffer();
    return WebAssembly.instantiate(n, e);
  };
}
let dl;
function em(t) {
  dl = t;
}
function tm() {
  return dl;
}
async function hl(t) {
  return t && await Ks(t), {
    createScanner(e) {
      return new Wf(e.map((n) => typeof n == "string" ? n : n.source));
    },
    createString(e) {
      return new pl(e);
    }
  };
}
const nm = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  createOnigurumaEngine: hl,
  getDefaultWasmLoader: tm,
  loadWasm: Ks,
  setDefaultWasmLoader: em
}, Symbol.toStringTag, { value: "Module" }));
var fl = /* @__PURE__ */ Zs({});
ul(fl, nm);
var X = class extends Error {
  constructor(t) {
    super(t), this.name = "ShikiError";
  }
};
function rm(t) {
  return ea(t);
}
function ea(t) {
  return Array.isArray(t) ? sm(t) : t instanceof RegExp ? t : typeof t == "object" ? am(t) : t;
}
function sm(t) {
  let e = [];
  for (let n = 0, r = t.length; n < r; n++)
    e[n] = ea(t[n]);
  return e;
}
function am(t) {
  let e = {};
  for (let n in t)
    e[n] = ea(t[n]);
  return e;
}
function ml(t, ...e) {
  return e.forEach((n) => {
    for (let r in n)
      t[r] = n[r];
  }), t;
}
function gl(t) {
  const e = ~t.lastIndexOf("/") || ~t.lastIndexOf("\\");
  return e === 0 ? t : ~e === t.length - 1 ? gl(t.substring(0, t.length - 1)) : t.substr(~e + 1);
}
var $r = /\$(\d+)|\${(\d+):\/(downcase|upcase)}/g, bn = class {
  static hasCaptures(t) {
    return t === null ? !1 : ($r.lastIndex = 0, $r.test(t));
  }
  static replaceCaptures(t, e, n) {
    return t.replace($r, (r, s, a, i) => {
      let o = n[parseInt(s || a, 10)];
      if (o) {
        let l = e.substring(o.start, o.end);
        for (; l[0] === "."; )
          l = l.substring(1);
        switch (i) {
          case "downcase":
            return l.toLowerCase();
          case "upcase":
            return l.toUpperCase();
          default:
            return l;
        }
      } else
        return r;
    });
  }
};
function yl(t, e) {
  return t < e ? -1 : t > e ? 1 : 0;
}
function xl(t, e) {
  if (t === null && e === null)
    return 0;
  if (!t)
    return -1;
  if (!e)
    return 1;
  let n = t.length, r = e.length;
  if (n === r) {
    for (let s = 0; s < n; s++) {
      let a = yl(t[s], e[s]);
      if (a !== 0)
        return a;
    }
    return 0;
  }
  return n - r;
}
function Ya(t) {
  return !!(/^#[0-9a-f]{6}$/i.test(t) || /^#[0-9a-f]{8}$/i.test(t) || /^#[0-9a-f]{3}$/i.test(t) || /^#[0-9a-f]{4}$/i.test(t));
}
function bl(t) {
  return t.replace(/[\-\\\{\}\*\+\?\|\^\$\.\,\[\]\(\)\#\s]/g, "\\$&");
}
var wl = class {
  constructor(t) {
    _(this, "cache", /* @__PURE__ */ new Map());
    this.fn = t;
  }
  get(t) {
    if (this.cache.has(t))
      return this.cache.get(t);
    const e = this.fn(t);
    return this.cache.set(t, e), e;
  }
}, Wn = class {
  constructor(t, e, n) {
    _(this, "_cachedMatchRoot", new wl(
      (t) => this._root.match(t)
    ));
    this._colorMap = t, this._defaults = e, this._root = n;
  }
  static createFromRawTheme(t, e) {
    return this.createFromParsedTheme(lm(t), e);
  }
  static createFromParsedTheme(t, e) {
    return um(t, e);
  }
  getColorMap() {
    return this._colorMap.getColorMap();
  }
  getDefaults() {
    return this._defaults;
  }
  match(t) {
    if (t === null)
      return this._defaults;
    const e = t.scopeName, r = this._cachedMatchRoot.get(e).find(
      (s) => im(t.parent, s.parentScopes)
    );
    return r ? new kl(
      r.fontStyle,
      r.foreground,
      r.background
    ) : null;
  }
}, Or = class Tn {
  constructor(e, n) {
    this.parent = e, this.scopeName = n;
  }
  static push(e, n) {
    for (const r of n)
      e = new Tn(e, r);
    return e;
  }
  static from(...e) {
    let n = null;
    for (let r = 0; r < e.length; r++)
      n = new Tn(n, e[r]);
    return n;
  }
  push(e) {
    return new Tn(this, e);
  }
  getSegments() {
    let e = this;
    const n = [];
    for (; e; )
      n.push(e.scopeName), e = e.parent;
    return n.reverse(), n;
  }
  toString() {
    return this.getSegments().join(" ");
  }
  extends(e) {
    return this === e ? !0 : this.parent === null ? !1 : this.parent.extends(e);
  }
  getExtensionIfDefined(e) {
    const n = [];
    let r = this;
    for (; r && r !== e; )
      n.push(r.scopeName), r = r.parent;
    return r === e ? n.reverse() : void 0;
  }
};
function im(t, e) {
  if (e.length === 0)
    return !0;
  for (let n = 0; n < e.length; n++) {
    let r = e[n], s = !1;
    if (r === ">") {
      if (n === e.length - 1)
        return !1;
      r = e[++n], s = !0;
    }
    for (; t && !om(t.scopeName, r); ) {
      if (s)
        return !1;
      t = t.parent;
    }
    if (!t)
      return !1;
    t = t.parent;
  }
  return !0;
}
function om(t, e) {
  return e === t || t.startsWith(e) && t[e.length] === ".";
}
var kl = class {
  constructor(t, e, n) {
    this.fontStyle = t, this.foregroundId = e, this.backgroundId = n;
  }
};
function lm(t) {
  if (!t)
    return [];
  if (!t.settings || !Array.isArray(t.settings))
    return [];
  let e = t.settings, n = [], r = 0;
  for (let s = 0, a = e.length; s < a; s++) {
    let i = e[s];
    if (!i.settings)
      continue;
    let o;
    if (typeof i.scope == "string") {
      let p = i.scope;
      p = p.replace(/^[,]+/, ""), p = p.replace(/[,]+$/, ""), o = p.split(",");
    } else Array.isArray(i.scope) ? o = i.scope : o = [""];
    let l = -1;
    if (typeof i.settings.fontStyle == "string") {
      l = 0;
      let p = i.settings.fontStyle.split(" ");
      for (let h = 0, m = p.length; h < m; h++)
        switch (p[h]) {
          case "italic":
            l = l | 1;
            break;
          case "bold":
            l = l | 2;
            break;
          case "underline":
            l = l | 4;
            break;
          case "strikethrough":
            l = l | 8;
            break;
        }
    }
    let c = null;
    typeof i.settings.foreground == "string" && Ya(i.settings.foreground) && (c = i.settings.foreground);
    let d = null;
    typeof i.settings.background == "string" && Ya(i.settings.background) && (d = i.settings.background);
    for (let p = 0, h = o.length; p < h; p++) {
      let f = o[p].trim().split(" "), g = f[f.length - 1], b = null;
      f.length > 1 && (b = f.slice(0, f.length - 1), b.reverse()), n[r++] = new cm(
        g,
        b,
        s,
        l,
        c,
        d
      );
    }
  }
  return n;
}
var cm = class {
  constructor(t, e, n, r, s, a) {
    this.scope = t, this.parentScopes = e, this.index = n, this.fontStyle = r, this.foreground = s, this.background = a;
  }
}, pe = /* @__PURE__ */ ((t) => (t[t.NotSet = -1] = "NotSet", t[t.None = 0] = "None", t[t.Italic = 1] = "Italic", t[t.Bold = 2] = "Bold", t[t.Underline = 4] = "Underline", t[t.Strikethrough = 8] = "Strikethrough", t))(pe || {});
function um(t, e) {
  t.sort((l, c) => {
    let d = yl(l.scope, c.scope);
    return d !== 0 || (d = xl(l.parentScopes, c.parentScopes), d !== 0) ? d : l.index - c.index;
  });
  let n = 0, r = "#000000", s = "#ffffff";
  for (; t.length >= 1 && t[0].scope === ""; ) {
    let l = t.shift();
    l.fontStyle !== -1 && (n = l.fontStyle), l.foreground !== null && (r = l.foreground), l.background !== null && (s = l.background);
  }
  let a = new pm(e), i = new kl(n, a.getId(r), a.getId(s)), o = new hm(new us(0, null, -1, 0, 0), []);
  for (let l = 0, c = t.length; l < c; l++) {
    let d = t[l];
    o.insert(0, d.scope, d.parentScopes, d.fontStyle, a.getId(d.foreground), a.getId(d.background));
  }
  return new Wn(a, i, o);
}
var pm = class {
  constructor(t) {
    _(this, "_isFrozen");
    _(this, "_lastColorId");
    _(this, "_id2color");
    _(this, "_color2id");
    if (this._lastColorId = 0, this._id2color = [], this._color2id = /* @__PURE__ */ Object.create(null), Array.isArray(t)) {
      this._isFrozen = !0;
      for (let e = 0, n = t.length; e < n; e++)
        this._color2id[t[e]] = e, this._id2color[e] = t[e];
    } else
      this._isFrozen = !1;
  }
  getId(t) {
    if (t === null)
      return 0;
    t = t.toUpperCase();
    let e = this._color2id[t];
    if (e)
      return e;
    if (this._isFrozen)
      throw new Error(`Missing color in color map - ${t}`);
    return e = ++this._lastColorId, this._color2id[t] = e, this._id2color[e] = t, e;
  }
  getColorMap() {
    return this._id2color.slice(0);
  }
}, dm = Object.freeze([]), us = class vl {
  constructor(e, n, r, s, a) {
    _(this, "scopeDepth");
    _(this, "parentScopes");
    _(this, "fontStyle");
    _(this, "foreground");
    _(this, "background");
    this.scopeDepth = e, this.parentScopes = n || dm, this.fontStyle = r, this.foreground = s, this.background = a;
  }
  clone() {
    return new vl(this.scopeDepth, this.parentScopes, this.fontStyle, this.foreground, this.background);
  }
  static cloneArr(e) {
    let n = [];
    for (let r = 0, s = e.length; r < s; r++)
      n[r] = e[r].clone();
    return n;
  }
  acceptOverwrite(e, n, r, s) {
    this.scopeDepth > e ? console.log("how did this happen?") : this.scopeDepth = e, n !== -1 && (this.fontStyle = n), r !== 0 && (this.foreground = r), s !== 0 && (this.background = s);
  }
}, hm = class ps {
  constructor(e, n = [], r = {}) {
    _(this, "_rulesWithParentScopes");
    this._mainRule = e, this._children = r, this._rulesWithParentScopes = n;
  }
  static _cmpBySpecificity(e, n) {
    if (e.scopeDepth !== n.scopeDepth)
      return n.scopeDepth - e.scopeDepth;
    let r = 0, s = 0;
    for (; e.parentScopes[r] === ">" && r++, n.parentScopes[s] === ">" && s++, !(r >= e.parentScopes.length || s >= n.parentScopes.length); ) {
      const a = n.parentScopes[s].length - e.parentScopes[r].length;
      if (a !== 0)
        return a;
      r++, s++;
    }
    return n.parentScopes.length - e.parentScopes.length;
  }
  match(e) {
    if (e !== "") {
      let r = e.indexOf("."), s, a;
      if (r === -1 ? (s = e, a = "") : (s = e.substring(0, r), a = e.substring(r + 1)), this._children.hasOwnProperty(s))
        return this._children[s].match(a);
    }
    const n = this._rulesWithParentScopes.concat(this._mainRule);
    return n.sort(ps._cmpBySpecificity), n;
  }
  insert(e, n, r, s, a, i) {
    if (n === "") {
      this._doInsertHere(e, r, s, a, i);
      return;
    }
    let o = n.indexOf("."), l, c;
    o === -1 ? (l = n, c = "") : (l = n.substring(0, o), c = n.substring(o + 1));
    let d;
    this._children.hasOwnProperty(l) ? d = this._children[l] : (d = new ps(this._mainRule.clone(), us.cloneArr(this._rulesWithParentScopes)), this._children[l] = d), d.insert(e + 1, c, r, s, a, i);
  }
  _doInsertHere(e, n, r, s, a) {
    if (n === null) {
      this._mainRule.acceptOverwrite(e, r, s, a);
      return;
    }
    for (let i = 0, o = this._rulesWithParentScopes.length; i < o; i++) {
      let l = this._rulesWithParentScopes[i];
      if (xl(l.parentScopes, n) === 0) {
        l.acceptOverwrite(e, r, s, a);
        return;
      }
    }
    r === -1 && (r = this._mainRule.fontStyle), s === 0 && (s = this._mainRule.foreground), a === 0 && (a = this._mainRule.background), this._rulesWithParentScopes.push(new us(e, n, r, s, a));
  }
}, Pt = class _e {
  static toBinaryStr(e) {
    return e.toString(2).padStart(32, "0");
  }
  static print(e) {
    const n = _e.getLanguageId(e), r = _e.getTokenType(e), s = _e.getFontStyle(e), a = _e.getForeground(e), i = _e.getBackground(e);
    console.log({
      languageId: n,
      tokenType: r,
      fontStyle: s,
      foreground: a,
      background: i
    });
  }
  static getLanguageId(e) {
    return (e & 255) >>> 0;
  }
  static getTokenType(e) {
    return (e & 768) >>> 8;
  }
  static containsBalancedBrackets(e) {
    return (e & 1024) !== 0;
  }
  static getFontStyle(e) {
    return (e & 30720) >>> 11;
  }
  static getForeground(e) {
    return (e & 16744448) >>> 15;
  }
  static getBackground(e) {
    return (e & 4278190080) >>> 24;
  }
  /**
   * Updates the fields in `metadata`.
   * A value of `0`, `NotSet` or `null` indicates that the corresponding field should be left as is.
   */
  static set(e, n, r, s, a, i, o) {
    let l = _e.getLanguageId(e), c = _e.getTokenType(e), d = _e.containsBalancedBrackets(e) ? 1 : 0, p = _e.getFontStyle(e), h = _e.getForeground(e), m = _e.getBackground(e);
    return n !== 0 && (l = n), r !== 8 && (c = r), s !== null && (d = s ? 1 : 0), a !== -1 && (p = a), i !== 0 && (h = i), o !== 0 && (m = o), (l << 0 | c << 8 | d << 10 | p << 11 | h << 15 | m << 24) >>> 0;
  }
};
function Zn(t, e) {
  const n = [], r = fm(t);
  let s = r.next();
  for (; s !== null; ) {
    let l = 0;
    if (s.length === 2 && s.charAt(1) === ":") {
      switch (s.charAt(0)) {
        case "R":
          l = 1;
          break;
        case "L":
          l = -1;
          break;
        default:
          console.log(`Unknown priority ${s} in scope selector`);
      }
      s = r.next();
    }
    let c = i();
    if (n.push({ matcher: c, priority: l }), s !== ",")
      break;
    s = r.next();
  }
  return n;
  function a() {
    if (s === "-") {
      s = r.next();
      const l = a();
      return (c) => !!l && !l(c);
    }
    if (s === "(") {
      s = r.next();
      const l = o();
      return s === ")" && (s = r.next()), l;
    }
    if (Xa(s)) {
      const l = [];
      do
        l.push(s), s = r.next();
      while (Xa(s));
      return (c) => e(l, c);
    }
    return null;
  }
  function i() {
    const l = [];
    let c = a();
    for (; c; )
      l.push(c), c = a();
    return (d) => l.every((p) => p(d));
  }
  function o() {
    const l = [];
    let c = i();
    for (; c && (l.push(c), s === "|" || s === ","); ) {
      do
        s = r.next();
      while (s === "|" || s === ",");
      c = i();
    }
    return (d) => l.some((p) => p(d));
  }
}
function Xa(t) {
  return !!t && !!t.match(/[\w\.:]+/);
}
function fm(t) {
  let e = /([LR]:|[\w\.:][\w\.:\-]*|[\,\|\-\(\)])/g, n = e.exec(t);
  return {
    next: () => {
      if (!n)
        return null;
      const r = n[0];
      return n = e.exec(t), r;
    }
  };
}
function _l(t) {
  typeof t.dispose == "function" && t.dispose();
}
var en = class {
  constructor(t) {
    this.scopeName = t;
  }
  toKey() {
    return this.scopeName;
  }
}, mm = class {
  constructor(t, e) {
    this.scopeName = t, this.ruleName = e;
  }
  toKey() {
    return `${this.scopeName}#${this.ruleName}`;
  }
}, gm = class {
  constructor() {
    _(this, "_references", []);
    _(this, "_seenReferenceKeys", /* @__PURE__ */ new Set());
    _(this, "visitedRule", /* @__PURE__ */ new Set());
  }
  get references() {
    return this._references;
  }
  add(t) {
    const e = t.toKey();
    this._seenReferenceKeys.has(e) || (this._seenReferenceKeys.add(e), this._references.push(t));
  }
}, ym = class {
  constructor(t, e) {
    _(this, "seenFullScopeRequests", /* @__PURE__ */ new Set());
    _(this, "seenPartialScopeRequests", /* @__PURE__ */ new Set());
    _(this, "Q");
    this.repo = t, this.initialScopeName = e, this.seenFullScopeRequests.add(this.initialScopeName), this.Q = [new en(this.initialScopeName)];
  }
  processQueue() {
    const t = this.Q;
    this.Q = [];
    const e = new gm();
    for (const n of t)
      xm(n, this.initialScopeName, this.repo, e);
    for (const n of e.references)
      if (n instanceof en) {
        if (this.seenFullScopeRequests.has(n.scopeName))
          continue;
        this.seenFullScopeRequests.add(n.scopeName), this.Q.push(n);
      } else {
        if (this.seenFullScopeRequests.has(n.scopeName) || this.seenPartialScopeRequests.has(n.toKey()))
          continue;
        this.seenPartialScopeRequests.add(n.toKey()), this.Q.push(n);
      }
  }
};
function xm(t, e, n, r) {
  const s = n.lookup(t.scopeName);
  if (!s) {
    if (t.scopeName === e)
      throw new Error(`No grammar provided for <${e}>`);
    return;
  }
  const a = n.lookup(e);
  t instanceof en ? En({ baseGrammar: a, selfGrammar: s }, r) : ds(
    t.ruleName,
    { baseGrammar: a, selfGrammar: s, repository: s.repository },
    r
  );
  const i = n.injections(t.scopeName);
  if (i)
    for (const o of i)
      r.add(new en(o));
}
function ds(t, e, n) {
  if (e.repository && e.repository[t]) {
    const r = e.repository[t];
    Vn([r], e, n);
  }
}
function En(t, e) {
  t.selfGrammar.patterns && Array.isArray(t.selfGrammar.patterns) && Vn(
    t.selfGrammar.patterns,
    { ...t, repository: t.selfGrammar.repository },
    e
  ), t.selfGrammar.injections && Vn(
    Object.values(t.selfGrammar.injections),
    { ...t, repository: t.selfGrammar.repository },
    e
  );
}
function Vn(t, e, n) {
  for (const r of t) {
    if (n.visitedRule.has(r))
      continue;
    n.visitedRule.add(r);
    const s = r.repository ? ml({}, e.repository, r.repository) : e.repository;
    Array.isArray(r.patterns) && Vn(r.patterns, { ...e, repository: s }, n);
    const a = r.include;
    if (!a)
      continue;
    const i = Sl(a);
    switch (i.kind) {
      case 0:
        En({ ...e, selfGrammar: e.baseGrammar }, n);
        break;
      case 1:
        En(e, n);
        break;
      case 2:
        ds(i.ruleName, { ...e, repository: s }, n);
        break;
      case 3:
      case 4:
        const o = i.scopeName === e.selfGrammar.scopeName ? e.selfGrammar : i.scopeName === e.baseGrammar.scopeName ? e.baseGrammar : void 0;
        if (o) {
          const l = { baseGrammar: e.baseGrammar, selfGrammar: o, repository: s };
          i.kind === 4 ? ds(i.ruleName, l, n) : En(l, n);
        } else
          i.kind === 4 ? n.add(new mm(i.scopeName, i.ruleName)) : n.add(new en(i.scopeName));
        break;
    }
  }
}
var bm = class {
  constructor() {
    _(this, "kind", 0);
  }
}, wm = class {
  constructor() {
    _(this, "kind", 1);
  }
}, km = class {
  constructor(t) {
    _(this, "kind", 2);
    this.ruleName = t;
  }
}, vm = class {
  constructor(t) {
    _(this, "kind", 3);
    this.scopeName = t;
  }
}, _m = class {
  constructor(t, e) {
    _(this, "kind", 4);
    this.scopeName = t, this.ruleName = e;
  }
};
function Sl(t) {
  if (t === "$base")
    return new bm();
  if (t === "$self")
    return new wm();
  const e = t.indexOf("#");
  if (e === -1)
    return new vm(t);
  if (e === 0)
    return new km(t.substring(1));
  {
    const n = t.substring(0, e), r = t.substring(e + 1);
    return new _m(n, r);
  }
}
var Sm = /\\(\d+)/, Ka = /\\(\d+)/g, Cm = -1, Cl = -2;
var pn = class {
  constructor(t, e, n, r) {
    _(this, "$location");
    _(this, "id");
    _(this, "_nameIsCapturing");
    _(this, "_name");
    _(this, "_contentNameIsCapturing");
    _(this, "_contentName");
    this.$location = t, this.id = e, this._name = n || null, this._nameIsCapturing = bn.hasCaptures(this._name), this._contentName = r || null, this._contentNameIsCapturing = bn.hasCaptures(this._contentName);
  }
  get debugName() {
    const t = this.$location ? `${gl(this.$location.filename)}:${this.$location.line}` : "unknown";
    return `${this.constructor.name}#${this.id} @ ${t}`;
  }
  getName(t, e) {
    return !this._nameIsCapturing || this._name === null || t === null || e === null ? this._name : bn.replaceCaptures(this._name, t, e);
  }
  getContentName(t, e) {
    return !this._contentNameIsCapturing || this._contentName === null ? this._contentName : bn.replaceCaptures(this._contentName, t, e);
  }
}, Nm = class extends pn {
  constructor(e, n, r, s, a) {
    super(e, n, r, s);
    _(this, "retokenizeCapturedWithRuleId");
    this.retokenizeCapturedWithRuleId = a;
  }
  dispose() {
  }
  collectPatterns(e, n) {
    throw new Error("Not supported!");
  }
  compile(e, n) {
    throw new Error("Not supported!");
  }
  compileAG(e, n, r, s) {
    throw new Error("Not supported!");
  }
}, Am = class extends pn {
  constructor(e, n, r, s, a) {
    super(e, n, r, null);
    _(this, "_match");
    _(this, "captures");
    _(this, "_cachedCompiledPatterns");
    this._match = new tn(s, this.id), this.captures = a, this._cachedCompiledPatterns = null;
  }
  dispose() {
    this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null);
  }
  get debugMatchRegExp() {
    return `${this._match.source}`;
  }
  collectPatterns(e, n) {
    n.push(this._match);
  }
  compile(e, n) {
    return this._getCachedCompiledPatterns(e).compile(e);
  }
  compileAG(e, n, r, s) {
    return this._getCachedCompiledPatterns(e).compileAG(e, r, s);
  }
  _getCachedCompiledPatterns(e) {
    return this._cachedCompiledPatterns || (this._cachedCompiledPatterns = new nn(), this.collectPatterns(e, this._cachedCompiledPatterns)), this._cachedCompiledPatterns;
  }
}, ei = class extends pn {
  constructor(e, n, r, s, a) {
    super(e, n, r, s);
    _(this, "hasMissingPatterns");
    _(this, "patterns");
    _(this, "_cachedCompiledPatterns");
    this.patterns = a.patterns, this.hasMissingPatterns = a.hasMissingPatterns, this._cachedCompiledPatterns = null;
  }
  dispose() {
    this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null);
  }
  collectPatterns(e, n) {
    for (const r of this.patterns)
      e.getRule(r).collectPatterns(e, n);
  }
  compile(e, n) {
    return this._getCachedCompiledPatterns(e).compile(e);
  }
  compileAG(e, n, r, s) {
    return this._getCachedCompiledPatterns(e).compileAG(e, r, s);
  }
  _getCachedCompiledPatterns(e) {
    return this._cachedCompiledPatterns || (this._cachedCompiledPatterns = new nn(), this.collectPatterns(e, this._cachedCompiledPatterns)), this._cachedCompiledPatterns;
  }
}, hs = class extends pn {
  constructor(e, n, r, s, a, i, o, l, c, d) {
    super(e, n, r, s);
    _(this, "_begin");
    _(this, "beginCaptures");
    _(this, "_end");
    _(this, "endHasBackReferences");
    _(this, "endCaptures");
    _(this, "applyEndPatternLast");
    _(this, "hasMissingPatterns");
    _(this, "patterns");
    _(this, "_cachedCompiledPatterns");
    this._begin = new tn(a, this.id), this.beginCaptures = i, this._end = new tn(o || "￿", -1), this.endHasBackReferences = this._end.hasBackReferences, this.endCaptures = l, this.applyEndPatternLast = c || !1, this.patterns = d.patterns, this.hasMissingPatterns = d.hasMissingPatterns, this._cachedCompiledPatterns = null;
  }
  dispose() {
    this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null);
  }
  get debugBeginRegExp() {
    return `${this._begin.source}`;
  }
  get debugEndRegExp() {
    return `${this._end.source}`;
  }
  getEndWithResolvedBackReferences(e, n) {
    return this._end.resolveBackReferences(e, n);
  }
  collectPatterns(e, n) {
    n.push(this._begin);
  }
  compile(e, n) {
    return this._getCachedCompiledPatterns(e, n).compile(e);
  }
  compileAG(e, n, r, s) {
    return this._getCachedCompiledPatterns(e, n).compileAG(e, r, s);
  }
  _getCachedCompiledPatterns(e, n) {
    if (!this._cachedCompiledPatterns) {
      this._cachedCompiledPatterns = new nn();
      for (const r of this.patterns)
        e.getRule(r).collectPatterns(e, this._cachedCompiledPatterns);
      this.applyEndPatternLast ? this._cachedCompiledPatterns.push(this._end.hasBackReferences ? this._end.clone() : this._end) : this._cachedCompiledPatterns.unshift(this._end.hasBackReferences ? this._end.clone() : this._end);
    }
    return this._end.hasBackReferences && (this.applyEndPatternLast ? this._cachedCompiledPatterns.setSource(this._cachedCompiledPatterns.length() - 1, n) : this._cachedCompiledPatterns.setSource(0, n)), this._cachedCompiledPatterns;
  }
}, Jn = class extends pn {
  constructor(e, n, r, s, a, i, o, l, c) {
    super(e, n, r, s);
    _(this, "_begin");
    _(this, "beginCaptures");
    _(this, "whileCaptures");
    _(this, "_while");
    _(this, "whileHasBackReferences");
    _(this, "hasMissingPatterns");
    _(this, "patterns");
    _(this, "_cachedCompiledPatterns");
    _(this, "_cachedCompiledWhilePatterns");
    this._begin = new tn(a, this.id), this.beginCaptures = i, this.whileCaptures = l, this._while = new tn(o, Cl), this.whileHasBackReferences = this._while.hasBackReferences, this.patterns = c.patterns, this.hasMissingPatterns = c.hasMissingPatterns, this._cachedCompiledPatterns = null, this._cachedCompiledWhilePatterns = null;
  }
  dispose() {
    this._cachedCompiledPatterns && (this._cachedCompiledPatterns.dispose(), this._cachedCompiledPatterns = null), this._cachedCompiledWhilePatterns && (this._cachedCompiledWhilePatterns.dispose(), this._cachedCompiledWhilePatterns = null);
  }
  get debugBeginRegExp() {
    return `${this._begin.source}`;
  }
  get debugWhileRegExp() {
    return `${this._while.source}`;
  }
  getWhileWithResolvedBackReferences(e, n) {
    return this._while.resolveBackReferences(e, n);
  }
  collectPatterns(e, n) {
    n.push(this._begin);
  }
  compile(e, n) {
    return this._getCachedCompiledPatterns(e).compile(e);
  }
  compileAG(e, n, r, s) {
    return this._getCachedCompiledPatterns(e).compileAG(e, r, s);
  }
  _getCachedCompiledPatterns(e) {
    if (!this._cachedCompiledPatterns) {
      this._cachedCompiledPatterns = new nn();
      for (const n of this.patterns)
        e.getRule(n).collectPatterns(e, this._cachedCompiledPatterns);
    }
    return this._cachedCompiledPatterns;
  }
  compileWhile(e, n) {
    return this._getCachedCompiledWhilePatterns(e, n).compile(e);
  }
  compileWhileAG(e, n, r, s) {
    return this._getCachedCompiledWhilePatterns(e, n).compileAG(e, r, s);
  }
  _getCachedCompiledWhilePatterns(e, n) {
    return this._cachedCompiledWhilePatterns || (this._cachedCompiledWhilePatterns = new nn(), this._cachedCompiledWhilePatterns.push(this._while.hasBackReferences ? this._while.clone() : this._while)), this._while.hasBackReferences && this._cachedCompiledWhilePatterns.setSource(0, n || "￿"), this._cachedCompiledWhilePatterns;
  }
}, Nl = class ue {
  static createCaptureRule(e, n, r, s, a) {
    return e.registerRule((i) => new Nm(n, i, r, s, a));
  }
  static getCompiledRuleId(e, n, r) {
    return e.id || n.registerRule((s) => {
      if (e.id = s, e.match)
        return new Am(
          e.$vscodeTextmateLocation,
          e.id,
          e.name,
          e.match,
          ue._compileCaptures(e.captures, n, r)
        );
      if (typeof e.begin > "u") {
        e.repository && (r = ml({}, r, e.repository));
        let a = e.patterns;
        return typeof a > "u" && e.include && (a = [{ include: e.include }]), new ei(
          e.$vscodeTextmateLocation,
          e.id,
          e.name,
          e.contentName,
          ue._compilePatterns(a, n, r)
        );
      }
      return e.while ? new Jn(
        e.$vscodeTextmateLocation,
        e.id,
        e.name,
        e.contentName,
        e.begin,
        ue._compileCaptures(e.beginCaptures || e.captures, n, r),
        e.while,
        ue._compileCaptures(e.whileCaptures || e.captures, n, r),
        ue._compilePatterns(e.patterns, n, r)
      ) : new hs(
        e.$vscodeTextmateLocation,
        e.id,
        e.name,
        e.contentName,
        e.begin,
        ue._compileCaptures(e.beginCaptures || e.captures, n, r),
        e.end,
        ue._compileCaptures(e.endCaptures || e.captures, n, r),
        e.applyEndPatternLast,
        ue._compilePatterns(e.patterns, n, r)
      );
    }), e.id;
  }
  static _compileCaptures(e, n, r) {
    let s = [];
    if (e) {
      let a = 0;
      for (const i in e) {
        if (i === "$vscodeTextmateLocation")
          continue;
        const o = parseInt(i, 10);
        o > a && (a = o);
      }
      for (let i = 0; i <= a; i++)
        s[i] = null;
      for (const i in e) {
        if (i === "$vscodeTextmateLocation")
          continue;
        const o = parseInt(i, 10);
        let l = 0;
        e[i].patterns && (l = ue.getCompiledRuleId(e[i], n, r)), s[o] = ue.createCaptureRule(n, e[i].$vscodeTextmateLocation, e[i].name, e[i].contentName, l);
      }
    }
    return s;
  }
  static _compilePatterns(e, n, r) {
    let s = [];
    if (e)
      for (let a = 0, i = e.length; a < i; a++) {
        const o = e[a];
        let l = -1;
        if (o.include) {
          const c = Sl(o.include);
          switch (c.kind) {
            case 0:
            case 1:
              l = ue.getCompiledRuleId(r[o.include], n, r);
              break;
            case 2:
              let d = r[c.ruleName];
              d && (l = ue.getCompiledRuleId(d, n, r));
              break;
            case 3:
            case 4:
              const p = c.scopeName, h = c.kind === 4 ? c.ruleName : null, m = n.getExternalGrammar(p, r);
              if (m)
                if (h) {
                  let f = m.repository[h];
                  f && (l = ue.getCompiledRuleId(f, n, m.repository));
                } else
                  l = ue.getCompiledRuleId(m.repository.$self, n, m.repository);
              break;
          }
        } else
          l = ue.getCompiledRuleId(o, n, r);
        if (l !== -1) {
          const c = n.getRule(l);
          let d = !1;
          if ((c instanceof ei || c instanceof hs || c instanceof Jn) && c.hasMissingPatterns && c.patterns.length === 0 && (d = !0), d)
            continue;
          s.push(l);
        }
      }
    return {
      patterns: s,
      hasMissingPatterns: (e ? e.length : 0) !== s.length
    };
  }
}, tn = class Al {
  constructor(e, n) {
    _(this, "source");
    _(this, "ruleId");
    _(this, "hasAnchor");
    _(this, "hasBackReferences");
    _(this, "_anchorCache");
    if (e && typeof e == "string") {
      const r = e.length;
      let s = 0, a = [], i = !1;
      for (let o = 0; o < r; o++)
        if (e.charAt(o) === "\\" && o + 1 < r) {
          const c = e.charAt(o + 1);
          c === "z" ? (a.push(e.substring(s, o)), a.push("$(?!\\n)(?<!\\n)"), s = o + 2) : (c === "A" || c === "G") && (i = !0), o++;
        }
      this.hasAnchor = i, s === 0 ? this.source = e : (a.push(e.substring(s, r)), this.source = a.join(""));
    } else
      this.hasAnchor = !1, this.source = e;
    this.hasAnchor ? this._anchorCache = this._buildAnchorCache() : this._anchorCache = null, this.ruleId = n, typeof this.source == "string" ? this.hasBackReferences = Sm.test(this.source) : this.hasBackReferences = !1;
  }
  clone() {
    return new Al(this.source, this.ruleId);
  }
  setSource(e) {
    this.source !== e && (this.source = e, this.hasAnchor && (this._anchorCache = this._buildAnchorCache()));
  }
  resolveBackReferences(e, n) {
    if (typeof this.source != "string")
      throw new Error("This method should only be called if the source is a string");
    let r = n.map((s) => e.substring(s.start, s.end));
    return Ka.lastIndex = 0, this.source.replace(Ka, (s, a) => bl(r[parseInt(a, 10)] || ""));
  }
  _buildAnchorCache() {
    if (typeof this.source != "string")
      throw new Error("This method should only be called if the source is a string");
    let e = [], n = [], r = [], s = [], a, i, o, l;
    for (a = 0, i = this.source.length; a < i; a++)
      o = this.source.charAt(a), e[a] = o, n[a] = o, r[a] = o, s[a] = o, o === "\\" && a + 1 < i && (l = this.source.charAt(a + 1), l === "A" ? (e[a + 1] = "￿", n[a + 1] = "￿", r[a + 1] = "A", s[a + 1] = "A") : l === "G" ? (e[a + 1] = "￿", n[a + 1] = "G", r[a + 1] = "￿", s[a + 1] = "G") : (e[a + 1] = l, n[a + 1] = l, r[a + 1] = l, s[a + 1] = l), a++);
    return {
      A0_G0: e.join(""),
      A0_G1: n.join(""),
      A1_G0: r.join(""),
      A1_G1: s.join("")
    };
  }
  resolveAnchors(e, n) {
    return !this.hasAnchor || !this._anchorCache || typeof this.source != "string" ? this.source : e ? n ? this._anchorCache.A1_G1 : this._anchorCache.A1_G0 : n ? this._anchorCache.A0_G1 : this._anchorCache.A0_G0;
  }
}, nn = class {
  constructor() {
    _(this, "_items");
    _(this, "_hasAnchors");
    _(this, "_cached");
    _(this, "_anchorCache");
    this._items = [], this._hasAnchors = !1, this._cached = null, this._anchorCache = {
      A0_G0: null,
      A0_G1: null,
      A1_G0: null,
      A1_G1: null
    };
  }
  dispose() {
    this._disposeCaches();
  }
  _disposeCaches() {
    this._cached && (this._cached.dispose(), this._cached = null), this._anchorCache.A0_G0 && (this._anchorCache.A0_G0.dispose(), this._anchorCache.A0_G0 = null), this._anchorCache.A0_G1 && (this._anchorCache.A0_G1.dispose(), this._anchorCache.A0_G1 = null), this._anchorCache.A1_G0 && (this._anchorCache.A1_G0.dispose(), this._anchorCache.A1_G0 = null), this._anchorCache.A1_G1 && (this._anchorCache.A1_G1.dispose(), this._anchorCache.A1_G1 = null);
  }
  push(t) {
    this._items.push(t), this._hasAnchors = this._hasAnchors || t.hasAnchor;
  }
  unshift(t) {
    this._items.unshift(t), this._hasAnchors = this._hasAnchors || t.hasAnchor;
  }
  length() {
    return this._items.length;
  }
  setSource(t, e) {
    this._items[t].source !== e && (this._disposeCaches(), this._items[t].setSource(e));
  }
  compile(t) {
    if (!this._cached) {
      let e = this._items.map((n) => n.source);
      this._cached = new ti(t, e, this._items.map((n) => n.ruleId));
    }
    return this._cached;
  }
  compileAG(t, e, n) {
    return this._hasAnchors ? e ? n ? (this._anchorCache.A1_G1 || (this._anchorCache.A1_G1 = this._resolveAnchors(t, e, n)), this._anchorCache.A1_G1) : (this._anchorCache.A1_G0 || (this._anchorCache.A1_G0 = this._resolveAnchors(t, e, n)), this._anchorCache.A1_G0) : n ? (this._anchorCache.A0_G1 || (this._anchorCache.A0_G1 = this._resolveAnchors(t, e, n)), this._anchorCache.A0_G1) : (this._anchorCache.A0_G0 || (this._anchorCache.A0_G0 = this._resolveAnchors(t, e, n)), this._anchorCache.A0_G0) : this.compile(t);
  }
  _resolveAnchors(t, e, n) {
    let r = this._items.map((s) => s.resolveAnchors(e, n));
    return new ti(t, r, this._items.map((s) => s.ruleId));
  }
}, ti = class {
  constructor(t, e, n) {
    _(this, "scanner");
    this.regExps = e, this.rules = n, this.scanner = t.createOnigScanner(e);
  }
  dispose() {
    typeof this.scanner.dispose == "function" && this.scanner.dispose();
  }
  toString() {
    const t = [];
    for (let e = 0, n = this.rules.length; e < n; e++)
      t.push("   - " + this.rules[e] + ": " + this.regExps[e]);
    return t.join(`
`);
  }
  findNextMatchSync(t, e, n) {
    const r = this.scanner.findNextMatchSync(t, e, n);
    return r ? {
      ruleId: this.rules[r.index],
      captureIndices: r.captureIndices
    } : null;
  }
}, Mr = class {
  constructor(t, e) {
    this.languageId = t, this.tokenType = e;
  }
}, He, Im = (He = class {
  constructor(e, n) {
    _(this, "_defaultAttributes");
    _(this, "_embeddedLanguagesMatcher");
    _(this, "_getBasicScopeAttributes", new wl((e) => {
      const n = this._scopeToLanguage(e), r = this._toStandardTokenType(e);
      return new Mr(n, r);
    }));
    this._defaultAttributes = new Mr(
      e,
      8
      /* NotSet */
    ), this._embeddedLanguagesMatcher = new Tm(Object.entries(n || {}));
  }
  getDefaultAttributes() {
    return this._defaultAttributes;
  }
  getBasicScopeAttributes(e) {
    return e === null ? He._NULL_SCOPE_METADATA : this._getBasicScopeAttributes.get(e);
  }
  /**
   * Given a produced TM scope, return the language that token describes or null if unknown.
   * e.g. source.html => html, source.css.embedded.html => css, punctuation.definition.tag.html => null
   */
  _scopeToLanguage(e) {
    return this._embeddedLanguagesMatcher.match(e) || 0;
  }
  _toStandardTokenType(e) {
    const n = e.match(He.STANDARD_TOKEN_TYPE_REGEXP);
    if (!n)
      return 8;
    switch (n[1]) {
      case "comment":
        return 1;
      case "string":
        return 2;
      case "regex":
        return 3;
      case "meta.embedded":
        return 0;
    }
    throw new Error("Unexpected match for standard token type!");
  }
}, _(He, "_NULL_SCOPE_METADATA", new Mr(0, 0)), _(He, "STANDARD_TOKEN_TYPE_REGEXP", /\b(comment|string|regex|meta\.embedded)\b/), He), Tm = class {
  constructor(t) {
    _(this, "values");
    _(this, "scopesRegExp");
    if (t.length === 0)
      this.values = null, this.scopesRegExp = null;
    else {
      this.values = new Map(t);
      const e = t.map(
        ([n, r]) => bl(n)
      );
      e.sort(), e.reverse(), this.scopesRegExp = new RegExp(
        `^((${e.join(")|(")}))($|\\.)`,
        ""
      );
    }
  }
  match(t) {
    if (!this.scopesRegExp)
      return;
    const e = t.match(this.scopesRegExp);
    if (e)
      return this.values.get(e[1]);
  }
};
typeof process < "u" && process.env.VSCODE_TEXTMATE_DEBUG;
var ni = class {
  constructor(t, e) {
    this.stack = t, this.stoppedEarly = e;
  }
};
function Il(t, e, n, r, s, a, i, o) {
  const l = e.content.length;
  let c = !1, d = -1;
  if (i) {
    const m = Em(
      t,
      e,
      n,
      r,
      s,
      a
    );
    s = m.stack, r = m.linePos, n = m.isFirstLine, d = m.anchorPosition;
  }
  const p = Date.now();
  for (; !c; ) {
    if (o !== 0 && Date.now() - p > o)
      return new ni(s, !0);
    h();
  }
  return new ni(s, !1);
  function h() {
    const m = jm(
      t,
      e,
      n,
      r,
      s,
      d
    );
    if (!m) {
      a.produce(s, l), c = !0;
      return;
    }
    const f = m.captureIndices, g = m.matchedRuleId, b = f && f.length > 0 ? f[0].end > r : !1;
    if (g === Cm) {
      const v = s.getRule(t);
      a.produce(s, f[0].start), s = s.withContentNameScopesList(s.nameScopesList), Vt(
        t,
        e,
        n,
        s,
        a,
        v.endCaptures,
        f
      ), a.produce(s, f[0].end);
      const w = s;
      if (s = s.parent, d = w.getAnchorPos(), !b && w.getEnterPos() === r) {
        s = w, a.produce(s, l), c = !0;
        return;
      }
    } else {
      const v = t.getRule(g);
      a.produce(s, f[0].start);
      const w = s, x = v.getName(e.content, f), k = s.contentNameScopesList.pushAttributed(
        x,
        t
      );
      if (s = s.push(
        g,
        r,
        d,
        f[0].end === l,
        null,
        k,
        k
      ), v instanceof hs) {
        const S = v;
        Vt(
          t,
          e,
          n,
          s,
          a,
          S.beginCaptures,
          f
        ), a.produce(s, f[0].end), d = f[0].end;
        const N = S.getContentName(
          e.content,
          f
        ), C = k.pushAttributed(
          N,
          t
        );
        if (s = s.withContentNameScopesList(C), S.endHasBackReferences && (s = s.withEndRule(
          S.getEndWithResolvedBackReferences(
            e.content,
            f
          )
        )), !b && w.hasSameRuleAs(s)) {
          s = s.pop(), a.produce(s, l), c = !0;
          return;
        }
      } else if (v instanceof Jn) {
        const S = v;
        Vt(
          t,
          e,
          n,
          s,
          a,
          S.beginCaptures,
          f
        ), a.produce(s, f[0].end), d = f[0].end;
        const N = S.getContentName(
          e.content,
          f
        ), C = k.pushAttributed(
          N,
          t
        );
        if (s = s.withContentNameScopesList(C), S.whileHasBackReferences && (s = s.withEndRule(
          S.getWhileWithResolvedBackReferences(
            e.content,
            f
          )
        )), !b && w.hasSameRuleAs(s)) {
          s = s.pop(), a.produce(s, l), c = !0;
          return;
        }
      } else if (Vt(
        t,
        e,
        n,
        s,
        a,
        v.captures,
        f
      ), a.produce(s, f[0].end), s = s.pop(), !b) {
        s = s.safePop(), a.produce(s, l), c = !0;
        return;
      }
    }
    f[0].end > r && (r = f[0].end, n = !1);
  }
}
function Em(t, e, n, r, s, a) {
  let i = s.beginRuleCapturedEOL ? 0 : -1;
  const o = [];
  for (let l = s; l; l = l.pop()) {
    const c = l.getRule(t);
    c instanceof Jn && o.push({
      rule: c,
      stack: l
    });
  }
  for (let l = o.pop(); l; l = o.pop()) {
    const { ruleScanner: c, findOptions: d } = Lm(l.rule, t, l.stack.endRule, n, r === i), p = c.findNextMatchSync(e, r, d);
    if (p) {
      if (p.ruleId !== Cl) {
        s = l.stack.pop();
        break;
      }
      p.captureIndices && p.captureIndices.length && (a.produce(l.stack, p.captureIndices[0].start), Vt(t, e, n, l.stack, a, l.rule.whileCaptures, p.captureIndices), a.produce(l.stack, p.captureIndices[0].end), i = p.captureIndices[0].end, p.captureIndices[0].end > r && (r = p.captureIndices[0].end, n = !1));
    } else {
      s = l.stack.pop();
      break;
    }
  }
  return { stack: s, linePos: r, anchorPosition: i, isFirstLine: n };
}
function jm(t, e, n, r, s, a) {
  const i = Rm(t, e, n, r, s, a), o = t.getInjections();
  if (o.length === 0)
    return i;
  const l = Pm(o, t, e, n, r, s, a);
  if (!l)
    return i;
  if (!i)
    return l;
  const c = i.captureIndices[0].start, d = l.captureIndices[0].start;
  return d < c || l.priorityMatch && d === c ? l : i;
}
function Rm(t, e, n, r, s, a) {
  const i = s.getRule(t), { ruleScanner: o, findOptions: l } = Tl(i, t, s.endRule, n, r === a), c = o.findNextMatchSync(e, r, l);
  return c ? {
    captureIndices: c.captureIndices,
    matchedRuleId: c.ruleId
  } : null;
}
function Pm(t, e, n, r, s, a, i) {
  let o = Number.MAX_VALUE, l = null, c, d = 0;
  const p = a.contentNameScopesList.getScopeNames();
  for (let h = 0, m = t.length; h < m; h++) {
    const f = t[h];
    if (!f.matcher(p))
      continue;
    const g = e.getRule(f.ruleId), { ruleScanner: b, findOptions: v } = Tl(g, e, null, r, s === i), w = b.findNextMatchSync(n, s, v);
    if (!w)
      continue;
    const x = w.captureIndices[0].start;
    if (!(x >= o) && (o = x, l = w.captureIndices, c = w.ruleId, d = f.priority, o === s))
      break;
  }
  return l ? {
    priorityMatch: d === -1,
    captureIndices: l,
    matchedRuleId: c
  } : null;
}
function Tl(t, e, n, r, s) {
  return {
    ruleScanner: t.compileAG(e, n, r, s),
    findOptions: 0
    /* None */
  };
}
function Lm(t, e, n, r, s) {
  return {
    ruleScanner: t.compileWhileAG(e, n, r, s),
    findOptions: 0
    /* None */
  };
}
function Vt(t, e, n, r, s, a, i) {
  if (a.length === 0)
    return;
  const o = e.content, l = Math.min(a.length, i.length), c = [], d = i[0].end;
  for (let p = 0; p < l; p++) {
    const h = a[p];
    if (h === null)
      continue;
    const m = i[p];
    if (m.length === 0)
      continue;
    if (m.start > d)
      break;
    for (; c.length > 0 && c[c.length - 1].endPos <= m.start; )
      s.produceFromScopes(c[c.length - 1].scopes, c[c.length - 1].endPos), c.pop();
    if (c.length > 0 ? s.produceFromScopes(c[c.length - 1].scopes, m.start) : s.produce(r, m.start), h.retokenizeCapturedWithRuleId) {
      const g = h.getName(o, i), b = r.contentNameScopesList.pushAttributed(g, t), v = h.getContentName(o, i), w = b.pushAttributed(v, t), x = r.push(h.retokenizeCapturedWithRuleId, m.start, -1, !1, null, b, w), k = t.createOnigString(o.substring(0, m.end));
      Il(
        t,
        k,
        n && m.start === 0,
        m.start,
        x,
        s,
        !1,
        /* no time limit */
        0
      ), _l(k);
      continue;
    }
    const f = h.getName(o, i);
    if (f !== null) {
      const b = (c.length > 0 ? c[c.length - 1].scopes : r.contentNameScopesList).pushAttributed(f, t);
      c.push(new $m(b, m.end));
    }
  }
  for (; c.length > 0; )
    s.produceFromScopes(c[c.length - 1].scopes, c[c.length - 1].endPos), c.pop();
}
var $m = class {
  constructor(t, e) {
    _(this, "scopes");
    _(this, "endPos");
    this.scopes = t, this.endPos = e;
  }
};
function Om(t, e, n, r, s, a, i, o) {
  return new Dm(
    t,
    e,
    n,
    r,
    s,
    a,
    i,
    o
  );
}
function ri(t, e, n, r, s) {
  const a = Zn(e, Qn), i = Nl.getCompiledRuleId(n, r, s.repository);
  for (const o of a)
    t.push({
      debugSelector: e,
      matcher: o.matcher,
      ruleId: i,
      grammar: s,
      priority: o.priority
    });
}
function Qn(t, e) {
  if (e.length < t.length)
    return !1;
  let n = 0;
  return t.every((r) => {
    for (let s = n; s < e.length; s++)
      if (Mm(e[s], r))
        return n = s + 1, !0;
    return !1;
  });
}
function Mm(t, e) {
  if (!t)
    return !1;
  if (t === e)
    return !0;
  const n = e.length;
  return t.length > n && t.substr(0, n) === e && t[n] === ".";
}
var Dm = class {
  constructor(t, e, n, r, s, a, i, o) {
    _(this, "_rootId");
    _(this, "_lastRuleId");
    _(this, "_ruleId2desc");
    _(this, "_includedGrammars");
    _(this, "_grammarRepository");
    _(this, "_grammar");
    _(this, "_injections");
    _(this, "_basicScopeAttributesProvider");
    _(this, "_tokenTypeMatchers");
    if (this._rootScopeName = t, this.balancedBracketSelectors = a, this._onigLib = o, this._basicScopeAttributesProvider = new Im(
      n,
      r
    ), this._rootId = -1, this._lastRuleId = 0, this._ruleId2desc = [null], this._includedGrammars = {}, this._grammarRepository = i, this._grammar = si(e, null), this._injections = null, this._tokenTypeMatchers = [], s)
      for (const l of Object.keys(s)) {
        const c = Zn(l, Qn);
        for (const d of c)
          this._tokenTypeMatchers.push({
            matcher: d.matcher,
            type: s[l]
          });
      }
  }
  get themeProvider() {
    return this._grammarRepository;
  }
  dispose() {
    for (const t of this._ruleId2desc)
      t && t.dispose();
  }
  createOnigScanner(t) {
    return this._onigLib.createOnigScanner(t);
  }
  createOnigString(t) {
    return this._onigLib.createOnigString(t);
  }
  getMetadataForScope(t) {
    return this._basicScopeAttributesProvider.getBasicScopeAttributes(t);
  }
  _collectInjections() {
    const t = {
      lookup: (s) => s === this._rootScopeName ? this._grammar : this.getExternalGrammar(s),
      injections: (s) => this._grammarRepository.injections(s)
    }, e = [], n = this._rootScopeName, r = t.lookup(n);
    if (r) {
      const s = r.injections;
      if (s)
        for (let i in s)
          ri(
            e,
            i,
            s[i],
            this,
            r
          );
      const a = this._grammarRepository.injections(n);
      a && a.forEach((i) => {
        const o = this.getExternalGrammar(i);
        if (o) {
          const l = o.injectionSelector;
          l && ri(
            e,
            l,
            o,
            this,
            o
          );
        }
      });
    }
    return e.sort((s, a) => s.priority - a.priority), e;
  }
  getInjections() {
    return this._injections === null && (this._injections = this._collectInjections()), this._injections;
  }
  registerRule(t) {
    const e = ++this._lastRuleId, n = t(e);
    return this._ruleId2desc[e] = n, n;
  }
  getRule(t) {
    return this._ruleId2desc[t];
  }
  getExternalGrammar(t, e) {
    if (this._includedGrammars[t])
      return this._includedGrammars[t];
    if (this._grammarRepository) {
      const n = this._grammarRepository.lookup(t);
      if (n)
        return this._includedGrammars[t] = si(
          n,
          e && e.$base
        ), this._includedGrammars[t];
    }
  }
  tokenizeLine(t, e, n = 0) {
    const r = this._tokenize(t, e, !1, n);
    return {
      tokens: r.lineTokens.getResult(r.ruleStack, r.lineLength),
      ruleStack: r.ruleStack,
      stoppedEarly: r.stoppedEarly
    };
  }
  tokenizeLine2(t, e, n = 0) {
    const r = this._tokenize(t, e, !0, n);
    return {
      tokens: r.lineTokens.getBinaryResult(r.ruleStack, r.lineLength),
      ruleStack: r.ruleStack,
      stoppedEarly: r.stoppedEarly
    };
  }
  _tokenize(t, e, n, r) {
    this._rootId === -1 && (this._rootId = Nl.getCompiledRuleId(
      this._grammar.repository.$self,
      this,
      this._grammar.repository
    ), this.getInjections());
    let s;
    if (!e || e === fs.NULL) {
      s = !0;
      const c = this._basicScopeAttributesProvider.getDefaultAttributes(), d = this.themeProvider.getDefaults(), p = Pt.set(
        0,
        c.languageId,
        c.tokenType,
        null,
        d.fontStyle,
        d.foregroundId,
        d.backgroundId
      ), h = this.getRule(this._rootId).getName(
        null,
        null
      );
      let m;
      h ? m = Jt.createRootAndLookUpScopeName(
        h,
        p,
        this
      ) : m = Jt.createRoot(
        "unknown",
        p
      ), e = new fs(
        null,
        this._rootId,
        -1,
        -1,
        !1,
        null,
        m,
        m
      );
    } else
      s = !1, e.reset();
    t = t + `
`;
    const a = this.createOnigString(t), i = a.content.length, o = new Fm(
      n,
      t,
      this._tokenTypeMatchers,
      this.balancedBracketSelectors
    ), l = Il(
      this,
      a,
      s,
      0,
      e,
      o,
      !0,
      r
    );
    return _l(a), {
      lineLength: i,
      lineTokens: o,
      ruleStack: l.stack,
      stoppedEarly: l.stoppedEarly
    };
  }
};
function si(t, e) {
  return t = rm(t), t.repository = t.repository || {}, t.repository.$self = {
    $vscodeTextmateLocation: t.$vscodeTextmateLocation,
    patterns: t.patterns,
    name: t.scopeName
  }, t.repository.$base = e || t.repository.$self, t;
}
var Jt = class Be {
  /**
   * Invariant:
   * ```
   * if (parent && !scopePath.extends(parent.scopePath)) {
   * 	throw new Error();
   * }
   * ```
   */
  constructor(e, n, r) {
    this.parent = e, this.scopePath = n, this.tokenAttributes = r;
  }
  static fromExtension(e, n) {
    let r = e, s = (e == null ? void 0 : e.scopePath) ?? null;
    for (const a of n)
      s = Or.push(s, a.scopeNames), r = new Be(r, s, a.encodedTokenAttributes);
    return r;
  }
  static createRoot(e, n) {
    return new Be(null, new Or(null, e), n);
  }
  static createRootAndLookUpScopeName(e, n, r) {
    const s = r.getMetadataForScope(e), a = new Or(null, e), i = r.themeProvider.themeMatch(a), o = Be.mergeAttributes(
      n,
      s,
      i
    );
    return new Be(null, a, o);
  }
  get scopeName() {
    return this.scopePath.scopeName;
  }
  toString() {
    return this.getScopeNames().join(" ");
  }
  equals(e) {
    return Be.equals(this, e);
  }
  static equals(e, n) {
    do {
      if (e === n || !e && !n)
        return !0;
      if (!e || !n || e.scopeName !== n.scopeName || e.tokenAttributes !== n.tokenAttributes)
        return !1;
      e = e.parent, n = n.parent;
    } while (!0);
  }
  static mergeAttributes(e, n, r) {
    let s = -1, a = 0, i = 0;
    return r !== null && (s = r.fontStyle, a = r.foregroundId, i = r.backgroundId), Pt.set(
      e,
      n.languageId,
      n.tokenType,
      null,
      s,
      a,
      i
    );
  }
  pushAttributed(e, n) {
    if (e === null)
      return this;
    if (e.indexOf(" ") === -1)
      return Be._pushAttributed(this, e, n);
    const r = e.split(/ /g);
    let s = this;
    for (const a of r)
      s = Be._pushAttributed(s, a, n);
    return s;
  }
  static _pushAttributed(e, n, r) {
    const s = r.getMetadataForScope(n), a = e.scopePath.push(n), i = r.themeProvider.themeMatch(a), o = Be.mergeAttributes(
      e.tokenAttributes,
      s,
      i
    );
    return new Be(e, a, o);
  }
  getScopeNames() {
    return this.scopePath.getSegments();
  }
  getExtensionIfDefined(e) {
    var s;
    const n = [];
    let r = this;
    for (; r && r !== e; )
      n.push({
        encodedTokenAttributes: r.tokenAttributes,
        scopeNames: r.scopePath.getExtensionIfDefined(((s = r.parent) == null ? void 0 : s.scopePath) ?? null)
      }), r = r.parent;
    return r === e ? n.reverse() : void 0;
  }
}, Se, fs = (Se = class {
  /**
   * Invariant:
   * ```
   * if (contentNameScopesList !== nameScopesList && contentNameScopesList?.parent !== nameScopesList) {
   * 	throw new Error();
   * }
   * if (this.parent && !nameScopesList.extends(this.parent.contentNameScopesList)) {
   * 	throw new Error();
   * }
   * ```
   */
  constructor(e, n, r, s, a, i, o, l) {
    _(this, "_stackElementBrand");
    /**
     * The position on the current line where this state was pushed.
     * This is relevant only while tokenizing a line, to detect endless loops.
     * Its value is meaningless across lines.
     */
    _(this, "_enterPos");
    /**
     * The captured anchor position when this stack element was pushed.
     * This is relevant only while tokenizing a line, to restore the anchor position when popping.
     * Its value is meaningless across lines.
     */
    _(this, "_anchorPos");
    /**
     * The depth of the stack.
     */
    _(this, "depth");
    this.parent = e, this.ruleId = n, this.beginRuleCapturedEOL = a, this.endRule = i, this.nameScopesList = o, this.contentNameScopesList = l, this.depth = this.parent ? this.parent.depth + 1 : 1, this._enterPos = r, this._anchorPos = s;
  }
  equals(e) {
    return e === null ? !1 : Se._equals(this, e);
  }
  static _equals(e, n) {
    return e === n ? !0 : this._structuralEquals(e, n) ? Jt.equals(e.contentNameScopesList, n.contentNameScopesList) : !1;
  }
  /**
   * A structural equals check. Does not take into account `scopes`.
   */
  static _structuralEquals(e, n) {
    do {
      if (e === n || !e && !n)
        return !0;
      if (!e || !n || e.depth !== n.depth || e.ruleId !== n.ruleId || e.endRule !== n.endRule)
        return !1;
      e = e.parent, n = n.parent;
    } while (!0);
  }
  clone() {
    return this;
  }
  static _reset(e) {
    for (; e; )
      e._enterPos = -1, e._anchorPos = -1, e = e.parent;
  }
  reset() {
    Se._reset(this);
  }
  pop() {
    return this.parent;
  }
  safePop() {
    return this.parent ? this.parent : this;
  }
  push(e, n, r, s, a, i, o) {
    return new Se(
      this,
      e,
      n,
      r,
      s,
      a,
      i,
      o
    );
  }
  getEnterPos() {
    return this._enterPos;
  }
  getAnchorPos() {
    return this._anchorPos;
  }
  getRule(e) {
    return e.getRule(this.ruleId);
  }
  toString() {
    const e = [];
    return this._writeString(e, 0), "[" + e.join(",") + "]";
  }
  _writeString(e, n) {
    var r, s;
    return this.parent && (n = this.parent._writeString(e, n)), e[n++] = `(${this.ruleId}, ${(r = this.nameScopesList) == null ? void 0 : r.toString()}, ${(s = this.contentNameScopesList) == null ? void 0 : s.toString()})`, n;
  }
  withContentNameScopesList(e) {
    return this.contentNameScopesList === e ? this : this.parent.push(
      this.ruleId,
      this._enterPos,
      this._anchorPos,
      this.beginRuleCapturedEOL,
      this.endRule,
      this.nameScopesList,
      e
    );
  }
  withEndRule(e) {
    return this.endRule === e ? this : new Se(
      this.parent,
      this.ruleId,
      this._enterPos,
      this._anchorPos,
      this.beginRuleCapturedEOL,
      e,
      this.nameScopesList,
      this.contentNameScopesList
    );
  }
  // Used to warn of endless loops
  hasSameRuleAs(e) {
    let n = this;
    for (; n && n._enterPos === e._enterPos; ) {
      if (n.ruleId === e.ruleId)
        return !0;
      n = n.parent;
    }
    return !1;
  }
  toStateStackFrame() {
    var e, n, r;
    return {
      ruleId: this.ruleId,
      beginRuleCapturedEOL: this.beginRuleCapturedEOL,
      endRule: this.endRule,
      nameScopesList: ((n = this.nameScopesList) == null ? void 0 : n.getExtensionIfDefined(((e = this.parent) == null ? void 0 : e.nameScopesList) ?? null)) ?? [],
      contentNameScopesList: ((r = this.contentNameScopesList) == null ? void 0 : r.getExtensionIfDefined(this.nameScopesList)) ?? []
    };
  }
  static pushFrame(e, n) {
    const r = Jt.fromExtension((e == null ? void 0 : e.nameScopesList) ?? null, n.nameScopesList);
    return new Se(
      e,
      n.ruleId,
      n.enterPos ?? -1,
      n.anchorPos ?? -1,
      n.beginRuleCapturedEOL,
      n.endRule,
      r,
      Jt.fromExtension(r, n.contentNameScopesList)
    );
  }
}, // TODO remove me
_(Se, "NULL", new Se(
  null,
  0,
  0,
  0,
  !1,
  null,
  null,
  null
)), Se), Bm = class {
  constructor(t, e) {
    _(this, "balancedBracketScopes");
    _(this, "unbalancedBracketScopes");
    _(this, "allowAny", !1);
    this.balancedBracketScopes = t.flatMap(
      (n) => n === "*" ? (this.allowAny = !0, []) : Zn(n, Qn).map((r) => r.matcher)
    ), this.unbalancedBracketScopes = e.flatMap(
      (n) => Zn(n, Qn).map((r) => r.matcher)
    );
  }
  get matchesAlways() {
    return this.allowAny && this.unbalancedBracketScopes.length === 0;
  }
  get matchesNever() {
    return this.balancedBracketScopes.length === 0 && !this.allowAny;
  }
  match(t) {
    for (const e of this.unbalancedBracketScopes)
      if (e(t))
        return !1;
    for (const e of this.balancedBracketScopes)
      if (e(t))
        return !0;
    return this.allowAny;
  }
}, Fm = class {
  constructor(t, e, n, r) {
    _(this, "_emitBinaryTokens");
    /**
     * defined only if `false`.
     */
    _(this, "_lineText");
    /**
     * used only if `_emitBinaryTokens` is false.
     */
    _(this, "_tokens");
    /**
     * used only if `_emitBinaryTokens` is true.
     */
    _(this, "_binaryTokens");
    _(this, "_lastTokenEndIndex");
    _(this, "_tokenTypeOverrides");
    this.balancedBracketSelectors = r, this._emitBinaryTokens = t, this._tokenTypeOverrides = n, this._lineText = null, this._tokens = [], this._binaryTokens = [], this._lastTokenEndIndex = 0;
  }
  produce(t, e) {
    this.produceFromScopes(t.contentNameScopesList, e);
  }
  produceFromScopes(t, e) {
    var r;
    if (this._lastTokenEndIndex >= e)
      return;
    if (this._emitBinaryTokens) {
      let s = (t == null ? void 0 : t.tokenAttributes) ?? 0, a = !1;
      if ((r = this.balancedBracketSelectors) != null && r.matchesAlways && (a = !0), this._tokenTypeOverrides.length > 0 || this.balancedBracketSelectors && !this.balancedBracketSelectors.matchesAlways && !this.balancedBracketSelectors.matchesNever) {
        const i = (t == null ? void 0 : t.getScopeNames()) ?? [];
        for (const o of this._tokenTypeOverrides)
          o.matcher(i) && (s = Pt.set(
            s,
            0,
            o.type,
            null,
            -1,
            0,
            0
          ));
        this.balancedBracketSelectors && (a = this.balancedBracketSelectors.match(i));
      }
      if (a && (s = Pt.set(
        s,
        0,
        8,
        a,
        -1,
        0,
        0
      )), this._binaryTokens.length > 0 && this._binaryTokens[this._binaryTokens.length - 1] === s) {
        this._lastTokenEndIndex = e;
        return;
      }
      this._binaryTokens.push(this._lastTokenEndIndex), this._binaryTokens.push(s), this._lastTokenEndIndex = e;
      return;
    }
    const n = (t == null ? void 0 : t.getScopeNames()) ?? [];
    this._tokens.push({
      startIndex: this._lastTokenEndIndex,
      endIndex: e,
      // value: lineText.substring(lastTokenEndIndex, endIndex),
      scopes: n
    }), this._lastTokenEndIndex = e;
  }
  getResult(t, e) {
    return this._tokens.length > 0 && this._tokens[this._tokens.length - 1].startIndex === e - 1 && this._tokens.pop(), this._tokens.length === 0 && (this._lastTokenEndIndex = -1, this.produce(t, e), this._tokens[this._tokens.length - 1].startIndex = 0), this._tokens;
  }
  getBinaryResult(t, e) {
    this._binaryTokens.length > 0 && this._binaryTokens[this._binaryTokens.length - 2] === e - 1 && (this._binaryTokens.pop(), this._binaryTokens.pop()), this._binaryTokens.length === 0 && (this._lastTokenEndIndex = -1, this.produce(t, e), this._binaryTokens[this._binaryTokens.length - 2] = 0);
    const n = new Uint32Array(this._binaryTokens.length);
    for (let r = 0, s = this._binaryTokens.length; r < s; r++)
      n[r] = this._binaryTokens[r];
    return n;
  }
}, Gm = class {
  constructor(t, e) {
    _(this, "_grammars", /* @__PURE__ */ new Map());
    _(this, "_rawGrammars", /* @__PURE__ */ new Map());
    _(this, "_injectionGrammars", /* @__PURE__ */ new Map());
    _(this, "_theme");
    this._onigLib = e, this._theme = t;
  }
  dispose() {
    for (const t of this._grammars.values())
      t.dispose();
  }
  setTheme(t) {
    this._theme = t;
  }
  getColorMap() {
    return this._theme.getColorMap();
  }
  /**
   * Add `grammar` to registry and return a list of referenced scope names
   */
  addGrammar(t, e) {
    this._rawGrammars.set(t.scopeName, t), e && this._injectionGrammars.set(t.scopeName, e);
  }
  /**
   * Lookup a raw grammar.
   */
  lookup(t) {
    return this._rawGrammars.get(t);
  }
  /**
   * Returns the injections for the given grammar
   */
  injections(t) {
    return this._injectionGrammars.get(t);
  }
  /**
   * Get the default theme settings
   */
  getDefaults() {
    return this._theme.getDefaults();
  }
  /**
   * Match a scope in the theme.
   */
  themeMatch(t) {
    return this._theme.match(t);
  }
  /**
   * Lookup a grammar.
   */
  grammarForScopeName(t, e, n, r, s) {
    if (!this._grammars.has(t)) {
      let a = this._rawGrammars.get(t);
      if (!a)
        return null;
      this._grammars.set(t, Om(
        t,
        a,
        e,
        n,
        r,
        s,
        this,
        this._onigLib
      ));
    }
    return this._grammars.get(t);
  }
}, zm = class {
  constructor(e) {
    _(this, "_options");
    _(this, "_syncRegistry");
    _(this, "_ensureGrammarCache");
    this._options = e, this._syncRegistry = new Gm(
      Wn.createFromRawTheme(e.theme, e.colorMap),
      e.onigLib
    ), this._ensureGrammarCache = /* @__PURE__ */ new Map();
  }
  dispose() {
    this._syncRegistry.dispose();
  }
  /**
   * Change the theme. Once called, no previous `ruleStack` should be used anymore.
   */
  setTheme(e, n) {
    this._syncRegistry.setTheme(Wn.createFromRawTheme(e, n));
  }
  /**
   * Returns a lookup array for color ids.
   */
  getColorMap() {
    return this._syncRegistry.getColorMap();
  }
  /**
   * Load the grammar for `scopeName` and all referenced included grammars asynchronously.
   * Please do not use language id 0.
   */
  loadGrammarWithEmbeddedLanguages(e, n, r) {
    return this.loadGrammarWithConfiguration(e, n, { embeddedLanguages: r });
  }
  /**
   * Load the grammar for `scopeName` and all referenced included grammars asynchronously.
   * Please do not use language id 0.
   */
  loadGrammarWithConfiguration(e, n, r) {
    return this._loadGrammar(
      e,
      n,
      r.embeddedLanguages,
      r.tokenTypes,
      new Bm(
        r.balancedBracketSelectors || [],
        r.unbalancedBracketSelectors || []
      )
    );
  }
  /**
   * Load the grammar for `scopeName` and all referenced included grammars asynchronously.
   */
  loadGrammar(e) {
    return this._loadGrammar(e, 0, null, null, null);
  }
  _loadGrammar(e, n, r, s, a) {
    const i = new ym(this._syncRegistry, e);
    for (; i.Q.length > 0; )
      i.Q.map((o) => this._loadSingleGrammar(o.scopeName)), i.processQueue();
    return this._grammarForScopeName(
      e,
      n,
      r,
      s,
      a
    );
  }
  _loadSingleGrammar(e) {
    this._ensureGrammarCache.has(e) || (this._doLoadSingleGrammar(e), this._ensureGrammarCache.set(e, !0));
  }
  _doLoadSingleGrammar(e) {
    const n = this._options.loadGrammar(e);
    if (n) {
      const r = typeof this._options.getInjections == "function" ? this._options.getInjections(e) : void 0;
      this._syncRegistry.addGrammar(n, r);
    }
  }
  /**
   * Adds a rawGrammar.
   */
  addGrammar(e, n = [], r = 0, s = null) {
    return this._syncRegistry.addGrammar(e, n), this._grammarForScopeName(e.scopeName, r, s);
  }
  /**
   * Get the grammar for `scopeName`. The grammar must first be created via `loadGrammar` or `addGrammar`.
   */
  _grammarForScopeName(e, n = 0, r = null, s = null, a = null) {
    return this._syncRegistry.grammarForScopeName(
      e,
      n,
      r,
      s,
      a
    );
  }
}, ms = fs.NULL;
function Yn(t, e) {
  const n = typeof t == "string" ? {} : { ...t.colorReplacements }, r = typeof t == "string" ? t : t.name;
  for (const [s, a] of Object.entries((e == null ? void 0 : e.colorReplacements) || {})) typeof a == "string" ? n[s] = a : s === r && Object.assign(n, a);
  return n;
}
function tt(t, e) {
  return t && ((e == null ? void 0 : e[t == null ? void 0 : t.toLowerCase()]) || t);
}
function Um(t) {
  return Array.isArray(t) ? t : [t];
}
async function El(t) {
  return Promise.resolve(typeof t == "function" ? t() : t).then((e) => e.default || e);
}
function gr(t) {
  return !t || [
    "plaintext",
    "txt",
    "text",
    "plain"
  ].includes(t);
}
function jl(t) {
  return t === "ansi" || gr(t);
}
function yr(t) {
  return t === "none";
}
function Rl(t) {
  return yr(t);
}
function xr(t, e = !1) {
  var a;
  if (t.length === 0) return [["", 0]];
  const n = t.split(/(\r?\n)/g);
  let r = 0;
  const s = [];
  for (let i = 0; i < n.length; i += 2) {
    const o = e ? n[i] + (n[i + 1] || "") : n[i];
    s.push([o, r]), r += n[i].length, r += ((a = n[i + 1]) == null ? void 0 : a.length) || 0;
  }
  return s;
}
const ai = {
  light: "#333333",
  dark: "#bbbbbb"
}, ii = {
  light: "#fffffe",
  dark: "#1e1e1e"
}, oi = "__shiki_resolved";
function ta(t) {
  var o, l, c, d, p;
  if (t != null && t[oi]) return t;
  const e = { ...t };
  e.tokenColors && !e.settings && (e.settings = e.tokenColors, delete e.tokenColors), e.type || (e.type = "dark"), e.colorReplacements = { ...e.colorReplacements }, e.settings || (e.settings = []);
  let { bg: n, fg: r } = e;
  if (!n || !r) {
    const h = e.settings ? e.settings.find((m) => !m.name && !m.scope) : void 0;
    (o = h == null ? void 0 : h.settings) != null && o.foreground && (r = h.settings.foreground), (l = h == null ? void 0 : h.settings) != null && l.background && (n = h.settings.background), !r && ((c = e == null ? void 0 : e.colors) != null && c["editor.foreground"]) && (r = e.colors["editor.foreground"]), !n && ((d = e == null ? void 0 : e.colors) != null && d["editor.background"]) && (n = e.colors["editor.background"]), r || (r = e.type === "light" ? ai.light : ai.dark), n || (n = e.type === "light" ? ii.light : ii.dark), e.fg = r, e.bg = n;
  }
  e.settings[0] && e.settings[0].settings && !e.settings[0].scope || e.settings.unshift({ settings: {
    foreground: e.fg,
    background: e.bg
  } });
  let s = 0;
  const a = /* @__PURE__ */ new Map();
  function i(h) {
    var f;
    if (a.has(h)) return a.get(h);
    s += 1;
    const m = `#${s.toString(16).padStart(8, "0").toLowerCase()}`;
    return (f = e.colorReplacements) != null && f[`#${m}`] ? i(h) : (a.set(h, m), m);
  }
  e.settings = e.settings.map((h) => {
    var b, v;
    const m = ((b = h.settings) == null ? void 0 : b.foreground) && !h.settings.foreground.startsWith("#"), f = ((v = h.settings) == null ? void 0 : v.background) && !h.settings.background.startsWith("#");
    if (!m && !f) return h;
    const g = {
      ...h,
      settings: { ...h.settings }
    };
    if (m) {
      const w = i(h.settings.foreground);
      e.colorReplacements[w] = h.settings.foreground, g.settings.foreground = w;
    }
    if (f) {
      const w = i(h.settings.background);
      e.colorReplacements[w] = h.settings.background, g.settings.background = w;
    }
    return g;
  });
  for (const h of Object.keys(e.colors || {})) if ((h === "editor.foreground" || h === "editor.background" || h.startsWith("terminal.ansi")) && !((p = e.colors[h]) != null && p.startsWith("#"))) {
    const m = i(e.colors[h]);
    e.colorReplacements[m] = e.colors[h], e.colors[h] = m;
  }
  return Object.defineProperty(e, oi, {
    enumerable: !1,
    writable: !1,
    value: !0
  }), e;
}
async function Pl(t) {
  return Array.from(new Set((await Promise.all(t.filter((e) => !jl(e)).map(async (e) => await El(e).then((n) => Array.isArray(n) ? n : [n])))).flat()));
}
async function Ll(t) {
  return (await Promise.all(t.map(async (e) => Rl(e) ? null : ta(await El(e))))).filter((e) => !!e);
}
function $l(t, e) {
  if (!e) return t;
  if (e[t]) {
    const n = /* @__PURE__ */ new Set([t]);
    for (; e[t]; ) {
      if (t = e[t], n.has(t)) throw new X(`Circular alias \`${Array.from(n).join(" -> ")} -> ${t}\``);
      n.add(t);
    }
  }
  return t;
}
var Hm = class extends zm {
  constructor(e, n, r, s = {}) {
    super(e);
    _(this, "_resolvedThemes", /* @__PURE__ */ new Map());
    _(this, "_resolvedGrammars", /* @__PURE__ */ new Map());
    _(this, "_langMap", /* @__PURE__ */ new Map());
    _(this, "_langGraph", /* @__PURE__ */ new Map());
    _(this, "_textmateThemeCache", /* @__PURE__ */ new WeakMap());
    _(this, "_loadedThemesCache", null);
    _(this, "_loadedLanguagesCache", null);
    this._resolver = e, this._themes = n, this._langs = r, this._alias = s, this._themes.map((a) => this.loadTheme(a)), this.loadLanguages(this._langs);
  }
  getTheme(e) {
    return typeof e == "string" ? this._resolvedThemes.get(e) : this.loadTheme(e);
  }
  loadTheme(e) {
    const n = ta(e);
    return n.name && (this._resolvedThemes.set(n.name, n), this._loadedThemesCache = null), n;
  }
  getLoadedThemes() {
    return this._loadedThemesCache || (this._loadedThemesCache = [...this._resolvedThemes.keys()]), this._loadedThemesCache;
  }
  setTheme(e) {
    let n = this._textmateThemeCache.get(e);
    n || (n = Wn.createFromRawTheme(e), this._textmateThemeCache.set(e, n)), this._syncRegistry.setTheme(n);
  }
  getGrammar(e) {
    return e = $l(e, this._alias), this._resolvedGrammars.get(e);
  }
  loadLanguage(e) {
    var a, i, o, l;
    if (this.getGrammar(e.name)) return;
    const n = new Set([...this._langMap.values()].filter((c) => {
      var d;
      return (d = c.embeddedLangsLazy) == null ? void 0 : d.includes(e.name);
    }));
    this._resolver.addLanguage(e);
    const r = {
      balancedBracketSelectors: e.balancedBracketSelectors || ["*"],
      unbalancedBracketSelectors: e.unbalancedBracketSelectors || []
    };
    this._syncRegistry._rawGrammars.set(e.scopeName, e);
    const s = this.loadGrammarWithConfiguration(e.scopeName, 1, r);
    if (s.name = e.name, this._resolvedGrammars.set(e.name, s), e.aliases && e.aliases.forEach((c) => {
      this._alias[c] = e.name;
    }), this._loadedLanguagesCache = null, n.size) for (const c of n)
      this._resolvedGrammars.delete(c.name), this._loadedLanguagesCache = null, (i = (a = this._syncRegistry) == null ? void 0 : a._injectionGrammars) == null || i.delete(c.scopeName), (l = (o = this._syncRegistry) == null ? void 0 : o._grammars) == null || l.delete(c.scopeName), this.loadLanguage(this._langMap.get(c.name));
  }
  dispose() {
    super.dispose(), this._resolvedThemes.clear(), this._resolvedGrammars.clear(), this._langMap.clear(), this._langGraph.clear(), this._loadedThemesCache = null;
  }
  loadLanguages(e) {
    for (const s of e) this.resolveEmbeddedLanguages(s);
    const n = Array.from(this._langGraph.entries()), r = n.filter(([s, a]) => !a);
    if (r.length) {
      const s = n.filter(([a, i]) => {
        var o;
        return i ? (o = i.embeddedLanguages || i.embeddedLangs) == null ? void 0 : o.some((l) => r.map(([c]) => c).includes(l)) : !1;
      }).filter((a) => !r.includes(a));
      throw new X(`Missing languages ${r.map(([a]) => `\`${a}\``).join(", ")}, required by ${s.map(([a]) => `\`${a}\``).join(", ")}`);
    }
    for (const [s, a] of n) this._resolver.addLanguage(a);
    for (const [s, a] of n) this.loadLanguage(a);
  }
  getLoadedLanguages() {
    return this._loadedLanguagesCache || (this._loadedLanguagesCache = [.../* @__PURE__ */ new Set([...this._resolvedGrammars.keys(), ...Object.keys(this._alias)])]), this._loadedLanguagesCache;
  }
  resolveEmbeddedLanguages(e) {
    this._langMap.set(e.name, e), this._langGraph.set(e.name, e);
    const n = e.embeddedLanguages ?? e.embeddedLangs;
    if (n) for (const r of n) this._langGraph.set(r, this._langMap.get(r));
  }
}, qm = class {
  constructor(t, e) {
    _(this, "_langs", /* @__PURE__ */ new Map());
    _(this, "_scopeToLang", /* @__PURE__ */ new Map());
    _(this, "_injections", /* @__PURE__ */ new Map());
    _(this, "_onigLib");
    this._onigLib = {
      createOnigScanner: (n) => t.createScanner(n),
      createOnigString: (n) => t.createString(n)
    }, e.forEach((n) => this.addLanguage(n));
  }
  get onigLib() {
    return this._onigLib;
  }
  getLangRegistration(t) {
    return this._langs.get(t);
  }
  loadGrammar(t) {
    return this._scopeToLang.get(t);
  }
  addLanguage(t) {
    this._langs.set(t.name, t), t.aliases && t.aliases.forEach((e) => {
      this._langs.set(e, t);
    }), this._scopeToLang.set(t.scopeName, t), t.injectTo && t.injectTo.forEach((e) => {
      this._injections.get(e) || this._injections.set(e, []), this._injections.get(e).push(t.scopeName);
    });
  }
  getInjections(t) {
    const e = t.split(".");
    let n = [];
    for (let r = 1; r <= e.length; r++) {
      const s = e.slice(0, r).join(".");
      n = [...n, ...this._injections.get(s) || []];
    }
    return n;
  }
};
let Ht = 0;
function Wm(t) {
  Ht += 1, t.warnings !== !1 && Ht >= 10 && Ht % 10 === 0 && console.warn(`[Shiki] ${Ht} instances have been created. Shiki is supposed to be used as a singleton, consider refactoring your code to cache your highlighter instance; Or call \`highlighter.dispose()\` to release unused instances.`);
  let e = !1;
  if (!t.engine) throw new X("`engine` option is required for synchronous mode");
  const n = (t.langs || []).flat(1), r = (t.themes || []).flat(1).map(ta), s = new Hm(new qm(t.engine, n), r, n, t.langAlias);
  let a;
  function i(w) {
    return $l(w, t.langAlias);
  }
  function o(w) {
    b();
    const x = s.getGrammar(typeof w == "string" ? w : w.name);
    if (!x) throw new X(`Language \`${w}\` not found, you may need to load it first`);
    return x;
  }
  function l(w) {
    if (w === "none") return {
      bg: "",
      fg: "",
      name: "none",
      settings: [],
      type: "dark"
    };
    b();
    const x = s.getTheme(w);
    if (!x) throw new X(`Theme \`${w}\` not found, you may need to load it first`);
    return x;
  }
  function c(w) {
    b();
    const x = l(w);
    return a !== w && (s.setTheme(x), a = w), {
      theme: x,
      colorMap: s.getColorMap()
    };
  }
  function d() {
    return b(), s.getLoadedThemes();
  }
  function p() {
    return b(), s.getLoadedLanguages();
  }
  function h(...w) {
    b(), s.loadLanguages(w.flat(1));
  }
  async function m(...w) {
    return h(await Pl(w));
  }
  function f(...w) {
    b();
    for (const x of w.flat(1)) s.loadTheme(x);
  }
  async function g(...w) {
    return b(), f(await Ll(w));
  }
  function b() {
    if (e) throw new X("Shiki instance has been disposed");
  }
  function v() {
    e || (e = !0, s.dispose(), Ht -= 1);
  }
  return {
    setTheme: c,
    getTheme: l,
    getLanguage: o,
    getLoadedThemes: d,
    getLoadedLanguages: p,
    resolveLangAlias: i,
    loadLanguage: m,
    loadLanguageSync: h,
    loadTheme: g,
    loadThemeSync: f,
    dispose: v,
    [Symbol.dispose]: v
  };
}
async function Zm(t) {
  t.engine || console.warn("`engine` option is required. Use `createOnigurumaEngine` or `createJavaScriptRegexEngine` to create an engine.");
  const [e, n, r] = await Promise.all([
    Ll(t.themes || []),
    Pl(t.langs || []),
    t.engine
  ]);
  return Wm({
    ...t,
    themes: e,
    langs: n,
    engine: r
  });
}
const Ol = /* @__PURE__ */ new WeakMap();
function br(t, e) {
  Ol.set(t, e);
}
function rn(t) {
  return Ol.get(t);
}
var wr = class Ml {
  constructor(...e) {
    /**
    * Theme to Stack mapping
    */
    _(this, "_stacks", {});
    _(this, "lang");
    if (e.length === 2) {
      const [n, r] = e;
      this.lang = r, this._stacks = n;
    } else {
      const [n, r, s] = e;
      this.lang = r, this._stacks = { [s]: n };
    }
  }
  get themes() {
    return Object.keys(this._stacks);
  }
  get theme() {
    return this.themes[0];
  }
  get _stack() {
    return this._stacks[this.theme];
  }
  /**
  * Static method to create a initial grammar state.
  */
  static initial(e, n) {
    return new Ml(Object.fromEntries(Um(n).map((r) => [r, ms])), e);
  }
  /**
  * Get the internal stack object.
  * @internal
  */
  getInternalStack(e = this.theme) {
    return this._stacks[e];
  }
  getScopes(e = this.theme) {
    return Vm(this._stacks[e]);
  }
  toJSON() {
    return {
      lang: this.lang,
      theme: this.theme,
      themes: this.themes,
      scopes: this.getScopes()
    };
  }
};
function Vm(t) {
  const e = [], n = /* @__PURE__ */ new Set();
  function r(s) {
    var i;
    if (n.has(s)) return;
    n.add(s);
    const a = (i = s == null ? void 0 : s.nameScopesList) == null ? void 0 : i.scopeName;
    a && e.push(a), s.parent && r(s.parent);
  }
  return r(t), e;
}
function Jm(t, e) {
  if (!(t instanceof wr)) throw new X("Invalid grammar state");
  return t.getInternalStack(e);
}
function Dl(t, e, n = {}) {
  const { theme: r = t.getLoadedThemes()[0] } = n;
  if (gr(t.resolveLangAlias(n.lang || "text")) || yr(r)) return xr(e).map((o) => [{
    content: o[0],
    offset: o[1]
  }]);
  const { theme: s, colorMap: a } = t.setTheme(r), i = t.getLanguage(n.lang || "text");
  if (n.grammarState) {
    if (n.grammarState.lang !== i.name) throw new X(`Grammar state language "${n.grammarState.lang}" does not match highlight language "${i.name}"`);
    if (!n.grammarState.themes.includes(s.name)) throw new X(`Grammar state themes "${n.grammarState.themes}" do not contain highlight theme "${s.name}"`);
  }
  return Ym(e, i, s, a, n);
}
function Qm(...t) {
  if (t.length === 2) return rn(t[1]);
  const [e, n, r = {}] = t, { lang: s = "text", theme: a = e.getLoadedThemes()[0] } = r;
  if (gr(s) || yr(a)) throw new X("Plain language does not have grammar state");
  if (s === "ansi") throw new X("ANSI language does not have grammar state");
  const { theme: i, colorMap: o } = e.setTheme(a), l = e.getLanguage(s);
  return new wr(na(n, l, i, o, r).stateStack, l.name, i.name);
}
function Ym(t, e, n, r, s) {
  const a = na(t, e, n, r, s), i = new wr(a.stateStack, e.name, n.name);
  return br(a.tokens, i), a.tokens;
}
function na(t, e, n, r, s) {
  const a = Yn(n, s), { tokenizeMaxLineLength: i = 0, tokenizeTimeLimit: o = 500 } = s, l = xr(t);
  let c = s.grammarState ? Jm(s.grammarState, n.name) ?? ms : s.grammarContextCode != null ? na(s.grammarContextCode, e, n, r, {
    ...s,
    grammarState: void 0,
    grammarContextCode: void 0
  }).stateStack : ms, d = [];
  const p = [];
  for (let h = 0, m = l.length; h < m; h++) {
    const [f, g] = l[h];
    if (f === "") {
      d = [], p.push([]);
      continue;
    }
    if (i > 0 && f.length >= i) {
      d = [], p.push([{
        content: f,
        offset: g,
        color: "",
        fontStyle: 0
      }]);
      continue;
    }
    let b, v, w;
    s.includeExplanation && (b = e.tokenizeLine(f, c, o), v = b.tokens, w = 0);
    const x = e.tokenizeLine2(f, c, o), k = x.tokens.length / 2;
    for (let S = 0; S < k; S++) {
      const N = x.tokens[2 * S], C = S + 1 < k ? x.tokens[2 * S + 2] : f.length;
      if (N === C) continue;
      const E = x.tokens[2 * S + 1], O = tt(r[Pt.getForeground(E)], a), R = Pt.getFontStyle(E), I = {
        content: f.substring(N, C),
        offset: g + N,
        color: O,
        fontStyle: R
      };
      if (s.includeExplanation) {
        const j = [];
        if (s.includeExplanation !== "scopeName") for (const L of n.settings) {
          let H;
          switch (typeof L.scope) {
            case "string":
              H = L.scope.split(/,/).map((ie) => ie.trim());
              break;
            case "object":
              H = L.scope;
              break;
            default:
              continue;
          }
          j.push({
            settings: L,
            selectors: H.map((ie) => ie.split(/ /))
          });
        }
        I.explanation = [];
        let U = 0;
        for (; N + U < C; ) {
          const L = v[w], H = f.substring(L.startIndex, L.endIndex);
          U += H.length, I.explanation.push({
            content: H,
            scopes: s.includeExplanation === "scopeName" ? Xm(L.scopes) : Km(j, L.scopes)
          }), w += 1;
        }
      }
      d.push(I);
    }
    p.push(d), d = [], c = x.ruleStack;
  }
  return {
    tokens: p,
    stateStack: c
  };
}
function Xm(t) {
  return t.map((e) => ({ scopeName: e }));
}
function Km(t, e) {
  const n = [];
  for (let r = 0, s = e.length; r < s; r++) {
    const a = e[r];
    n[r] = {
      scopeName: a,
      themeMatches: tg(t, a, e.slice(0, r))
    };
  }
  return n;
}
function li(t, e) {
  return t === e || e.substring(0, t.length) === t && e[t.length] === ".";
}
function eg(t, e, n) {
  if (!li(t[t.length - 1], e)) return !1;
  let r = t.length - 2, s = n.length - 1;
  for (; r >= 0 && s >= 0; )
    li(t[r], n[s]) && (r -= 1), s -= 1;
  return r === -1;
}
function tg(t, e, n) {
  const r = [];
  for (const { selectors: s, settings: a } of t) for (const i of s) if (eg(i, e, n)) {
    r.push(a);
    break;
  }
  return r;
}
function Bl(t, e, n, r = Dl) {
  const s = Object.entries(n.themes).filter((c) => c[1]).map((c) => ({
    color: c[0],
    theme: c[1]
  })), a = s.map((c) => {
    const d = r(t, e, {
      ...n,
      theme: c.theme
    });
    return {
      tokens: d,
      state: rn(d),
      theme: typeof c.theme == "string" ? c.theme : c.theme.name
    };
  }), i = ng(...a.map((c) => c.tokens)), o = i[0].map((c, d) => c.map((p, h) => {
    const m = {
      content: p.content,
      variants: {},
      offset: p.offset
    };
    return "includeExplanation" in n && n.includeExplanation && (m.explanation = p.explanation), i.forEach((f, g) => {
      const { content: b, explanation: v, offset: w, ...x } = f[d][h];
      m.variants[s[g].color] = x;
    }), m;
  })), l = a[0].state ? new wr(Object.fromEntries(a.map((c) => {
    var d;
    return [c.theme, (d = c.state) == null ? void 0 : d.getInternalStack(c.theme)];
  })), a[0].state.lang) : void 0;
  return l && br(o, l), o;
}
function ng(...t) {
  const e = t.map(() => []), n = t.length;
  for (let r = 0; r < t[0].length; r++) {
    const s = t.map((l) => l[r]), a = e.map(() => []);
    e.forEach((l, c) => l.push(a[c]));
    const i = s.map(() => 0), o = s.map((l) => l[0]);
    for (; o.every((l) => l); ) {
      const l = Math.min(...o.map((c) => c.content.length));
      for (let c = 0; c < n; c++) {
        const d = o[c];
        d.content.length === l ? (a[c].push(d), i[c] += 1, o[c] = s[c][i[c]]) : (a[c].push({
          ...d,
          content: d.content.slice(0, l)
        }), o[c] = {
          ...d,
          content: d.content.slice(l),
          offset: d.offset + l
        });
      }
    }
  }
  return e;
}
const rg = [
  "area",
  "base",
  "basefont",
  "bgsound",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "image",
  "img",
  "input",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
], sg = /["&'<>`]/g, ag = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, ig = (
  // eslint-disable-next-line no-control-regex, unicorn/no-hex-escape
  /[\x01-\t\v\f\x0E-\x1F\x7F\x81\x8D\x8F\x90\x9D\xA0-\uFFFF]/g
), og = /[|\\{}()[\]^$+*?.]/g, ci = /* @__PURE__ */ new WeakMap();
function lg(t, e) {
  if (t = t.replace(
    e.subset ? cg(e.subset) : sg,
    r
  ), e.subset || e.escapeOnly)
    return t;
  return t.replace(ag, n).replace(ig, r);
  function n(s, a, i) {
    return e.format(
      (s.charCodeAt(0) - 55296) * 1024 + s.charCodeAt(1) - 56320 + 65536,
      i.charCodeAt(a + 2),
      e
    );
  }
  function r(s, a, i) {
    return e.format(
      s.charCodeAt(0),
      i.charCodeAt(a + 1),
      e
    );
  }
}
function cg(t) {
  let e = ci.get(t);
  return e || (e = ug(t), ci.set(t, e)), e;
}
function ug(t) {
  const e = [];
  let n = -1;
  for (; ++n < t.length; )
    e.push(t[n].replace(og, "\\$&"));
  return new RegExp("(?:" + e.join("|") + ")", "g");
}
const pg = /[\dA-Fa-f]/;
function dg(t, e, n) {
  const r = "&#x" + t.toString(16).toUpperCase();
  return n && e && !pg.test(String.fromCharCode(e)) ? r : r + ";";
}
const hg = /\d/;
function fg(t, e, n) {
  const r = "&#" + String(t);
  return n && e && !hg.test(String.fromCharCode(e)) ? r : r + ";";
}
const mg = [
  "AElig",
  "AMP",
  "Aacute",
  "Acirc",
  "Agrave",
  "Aring",
  "Atilde",
  "Auml",
  "COPY",
  "Ccedil",
  "ETH",
  "Eacute",
  "Ecirc",
  "Egrave",
  "Euml",
  "GT",
  "Iacute",
  "Icirc",
  "Igrave",
  "Iuml",
  "LT",
  "Ntilde",
  "Oacute",
  "Ocirc",
  "Ograve",
  "Oslash",
  "Otilde",
  "Ouml",
  "QUOT",
  "REG",
  "THORN",
  "Uacute",
  "Ucirc",
  "Ugrave",
  "Uuml",
  "Yacute",
  "aacute",
  "acirc",
  "acute",
  "aelig",
  "agrave",
  "amp",
  "aring",
  "atilde",
  "auml",
  "brvbar",
  "ccedil",
  "cedil",
  "cent",
  "copy",
  "curren",
  "deg",
  "divide",
  "eacute",
  "ecirc",
  "egrave",
  "eth",
  "euml",
  "frac12",
  "frac14",
  "frac34",
  "gt",
  "iacute",
  "icirc",
  "iexcl",
  "igrave",
  "iquest",
  "iuml",
  "laquo",
  "lt",
  "macr",
  "micro",
  "middot",
  "nbsp",
  "not",
  "ntilde",
  "oacute",
  "ocirc",
  "ograve",
  "ordf",
  "ordm",
  "oslash",
  "otilde",
  "ouml",
  "para",
  "plusmn",
  "pound",
  "quot",
  "raquo",
  "reg",
  "sect",
  "shy",
  "sup1",
  "sup2",
  "sup3",
  "szlig",
  "thorn",
  "times",
  "uacute",
  "ucirc",
  "ugrave",
  "uml",
  "uuml",
  "yacute",
  "yen",
  "yuml"
], Dr = {
  nbsp: " ",
  iexcl: "¡",
  cent: "¢",
  pound: "£",
  curren: "¤",
  yen: "¥",
  brvbar: "¦",
  sect: "§",
  uml: "¨",
  copy: "©",
  ordf: "ª",
  laquo: "«",
  not: "¬",
  shy: "­",
  reg: "®",
  macr: "¯",
  deg: "°",
  plusmn: "±",
  sup2: "²",
  sup3: "³",
  acute: "´",
  micro: "µ",
  para: "¶",
  middot: "·",
  cedil: "¸",
  sup1: "¹",
  ordm: "º",
  raquo: "»",
  frac14: "¼",
  frac12: "½",
  frac34: "¾",
  iquest: "¿",
  Agrave: "À",
  Aacute: "Á",
  Acirc: "Â",
  Atilde: "Ã",
  Auml: "Ä",
  Aring: "Å",
  AElig: "Æ",
  Ccedil: "Ç",
  Egrave: "È",
  Eacute: "É",
  Ecirc: "Ê",
  Euml: "Ë",
  Igrave: "Ì",
  Iacute: "Í",
  Icirc: "Î",
  Iuml: "Ï",
  ETH: "Ð",
  Ntilde: "Ñ",
  Ograve: "Ò",
  Oacute: "Ó",
  Ocirc: "Ô",
  Otilde: "Õ",
  Ouml: "Ö",
  times: "×",
  Oslash: "Ø",
  Ugrave: "Ù",
  Uacute: "Ú",
  Ucirc: "Û",
  Uuml: "Ü",
  Yacute: "Ý",
  THORN: "Þ",
  szlig: "ß",
  agrave: "à",
  aacute: "á",
  acirc: "â",
  atilde: "ã",
  auml: "ä",
  aring: "å",
  aelig: "æ",
  ccedil: "ç",
  egrave: "è",
  eacute: "é",
  ecirc: "ê",
  euml: "ë",
  igrave: "ì",
  iacute: "í",
  icirc: "î",
  iuml: "ï",
  eth: "ð",
  ntilde: "ñ",
  ograve: "ò",
  oacute: "ó",
  ocirc: "ô",
  otilde: "õ",
  ouml: "ö",
  divide: "÷",
  oslash: "ø",
  ugrave: "ù",
  uacute: "ú",
  ucirc: "û",
  uuml: "ü",
  yacute: "ý",
  thorn: "þ",
  yuml: "ÿ",
  fnof: "ƒ",
  Alpha: "Α",
  Beta: "Β",
  Gamma: "Γ",
  Delta: "Δ",
  Epsilon: "Ε",
  Zeta: "Ζ",
  Eta: "Η",
  Theta: "Θ",
  Iota: "Ι",
  Kappa: "Κ",
  Lambda: "Λ",
  Mu: "Μ",
  Nu: "Ν",
  Xi: "Ξ",
  Omicron: "Ο",
  Pi: "Π",
  Rho: "Ρ",
  Sigma: "Σ",
  Tau: "Τ",
  Upsilon: "Υ",
  Phi: "Φ",
  Chi: "Χ",
  Psi: "Ψ",
  Omega: "Ω",
  alpha: "α",
  beta: "β",
  gamma: "γ",
  delta: "δ",
  epsilon: "ε",
  zeta: "ζ",
  eta: "η",
  theta: "θ",
  iota: "ι",
  kappa: "κ",
  lambda: "λ",
  mu: "μ",
  nu: "ν",
  xi: "ξ",
  omicron: "ο",
  pi: "π",
  rho: "ρ",
  sigmaf: "ς",
  sigma: "σ",
  tau: "τ",
  upsilon: "υ",
  phi: "φ",
  chi: "χ",
  psi: "ψ",
  omega: "ω",
  thetasym: "ϑ",
  upsih: "ϒ",
  piv: "ϖ",
  bull: "•",
  hellip: "…",
  prime: "′",
  Prime: "″",
  oline: "‾",
  frasl: "⁄",
  weierp: "℘",
  image: "ℑ",
  real: "ℜ",
  trade: "™",
  alefsym: "ℵ",
  larr: "←",
  uarr: "↑",
  rarr: "→",
  darr: "↓",
  harr: "↔",
  crarr: "↵",
  lArr: "⇐",
  uArr: "⇑",
  rArr: "⇒",
  dArr: "⇓",
  hArr: "⇔",
  forall: "∀",
  part: "∂",
  exist: "∃",
  empty: "∅",
  nabla: "∇",
  isin: "∈",
  notin: "∉",
  ni: "∋",
  prod: "∏",
  sum: "∑",
  minus: "−",
  lowast: "∗",
  radic: "√",
  prop: "∝",
  infin: "∞",
  ang: "∠",
  and: "∧",
  or: "∨",
  cap: "∩",
  cup: "∪",
  int: "∫",
  there4: "∴",
  sim: "∼",
  cong: "≅",
  asymp: "≈",
  ne: "≠",
  equiv: "≡",
  le: "≤",
  ge: "≥",
  sub: "⊂",
  sup: "⊃",
  nsub: "⊄",
  sube: "⊆",
  supe: "⊇",
  oplus: "⊕",
  otimes: "⊗",
  perp: "⊥",
  sdot: "⋅",
  lceil: "⌈",
  rceil: "⌉",
  lfloor: "⌊",
  rfloor: "⌋",
  lang: "〈",
  rang: "〉",
  loz: "◊",
  spades: "♠",
  clubs: "♣",
  hearts: "♥",
  diams: "♦",
  quot: '"',
  amp: "&",
  lt: "<",
  gt: ">",
  OElig: "Œ",
  oelig: "œ",
  Scaron: "Š",
  scaron: "š",
  Yuml: "Ÿ",
  circ: "ˆ",
  tilde: "˜",
  ensp: " ",
  emsp: " ",
  thinsp: " ",
  zwnj: "‌",
  zwj: "‍",
  lrm: "‎",
  rlm: "‏",
  ndash: "–",
  mdash: "—",
  lsquo: "‘",
  rsquo: "’",
  sbquo: "‚",
  ldquo: "“",
  rdquo: "”",
  bdquo: "„",
  dagger: "†",
  Dagger: "‡",
  permil: "‰",
  lsaquo: "‹",
  rsaquo: "›",
  euro: "€"
}, gg = [
  "cent",
  "copy",
  "divide",
  "gt",
  "lt",
  "not",
  "para",
  "times"
], Fl = {}.hasOwnProperty, gs = {};
let wn;
for (wn in Dr)
  Fl.call(Dr, wn) && (gs[Dr[wn]] = wn);
const yg = /[^\dA-Za-z]/;
function xg(t, e, n, r) {
  const s = String.fromCharCode(t);
  if (Fl.call(gs, s)) {
    const a = gs[s], i = "&" + a;
    return n && mg.includes(a) && !gg.includes(a) && (!r || e && e !== 61 && yg.test(String.fromCharCode(e))) ? i : i + ";";
  }
  return "";
}
function bg(t, e, n) {
  let r = dg(t, e, n.omitOptionalSemicolons), s;
  if ((n.useNamedReferences || n.useShortestReferences) && (s = xg(
    t,
    e,
    n.omitOptionalSemicolons,
    n.attribute
  )), (n.useShortestReferences || !s) && n.useShortestReferences) {
    const a = fg(t, e, n.omitOptionalSemicolons);
    a.length < r.length && (r = a);
  }
  return s && (!n.useShortestReferences || s.length < r.length) ? s : r;
}
function jt(t, e) {
  return lg(t, Object.assign({ format: bg }, e));
}
const wg = /^>|^->|<!--|-->|--!>|<!-$/g, kg = [">"], vg = ["<", ">"];
function _g(t, e, n, r) {
  return r.settings.bogusComments ? "<?" + jt(
    t.value,
    Object.assign({}, r.settings.characterReferences, {
      subset: kg
    })
  ) + ">" : "<!--" + t.value.replace(wg, s) + "-->";
  function s(a) {
    return jt(
      a,
      Object.assign({}, r.settings.characterReferences, {
        subset: vg
      })
    );
  }
}
function Sg(t, e, n, r) {
  return "<!" + (r.settings.upperDoctype ? "DOCTYPE" : "doctype") + (r.settings.tightDoctype ? "" : " ") + "html>";
}
const ae = zl(1), Gl = zl(-1), Cg = [];
function zl(t) {
  return e;
  function e(n, r, s) {
    const a = n ? n.children : Cg;
    let i = (r || 0) + t, o = a[i];
    if (!s)
      for (; o && Es(o); )
        i += t, o = a[i];
    return o;
  }
}
const Ng = {}.hasOwnProperty;
function Ul(t) {
  return e;
  function e(n, r, s) {
    return Ng.call(t, n.tagName) && t[n.tagName](n, r, s);
  }
}
const ra = Ul({
  body: Ig,
  caption: Br,
  colgroup: Br,
  dd: Rg,
  dt: jg,
  head: Br,
  html: Ag,
  li: Eg,
  optgroup: Pg,
  option: Lg,
  p: Tg,
  rp: ui,
  rt: ui,
  tbody: Og,
  td: pi,
  tfoot: Mg,
  th: pi,
  thead: $g,
  tr: Dg
});
function Br(t, e, n) {
  const r = ae(n, e, !0);
  return !r || r.type !== "comment" && !(r.type === "text" && Es(r.value.charAt(0)));
}
function Ag(t, e, n) {
  const r = ae(n, e);
  return !r || r.type !== "comment";
}
function Ig(t, e, n) {
  const r = ae(n, e);
  return !r || r.type !== "comment";
}
function Tg(t, e, n) {
  const r = ae(n, e);
  return r ? r.type === "element" && (r.tagName === "address" || r.tagName === "article" || r.tagName === "aside" || r.tagName === "blockquote" || r.tagName === "details" || r.tagName === "div" || r.tagName === "dl" || r.tagName === "fieldset" || r.tagName === "figcaption" || r.tagName === "figure" || r.tagName === "footer" || r.tagName === "form" || r.tagName === "h1" || r.tagName === "h2" || r.tagName === "h3" || r.tagName === "h4" || r.tagName === "h5" || r.tagName === "h6" || r.tagName === "header" || r.tagName === "hgroup" || r.tagName === "hr" || r.tagName === "main" || r.tagName === "menu" || r.tagName === "nav" || r.tagName === "ol" || r.tagName === "p" || r.tagName === "pre" || r.tagName === "section" || r.tagName === "table" || r.tagName === "ul") : !n || // Confusing parent.
  !(n.type === "element" && (n.tagName === "a" || n.tagName === "audio" || n.tagName === "del" || n.tagName === "ins" || n.tagName === "map" || n.tagName === "noscript" || n.tagName === "video"));
}
function Eg(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && r.tagName === "li";
}
function jg(t, e, n) {
  const r = ae(n, e);
  return !!(r && r.type === "element" && (r.tagName === "dt" || r.tagName === "dd"));
}
function Rg(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && (r.tagName === "dt" || r.tagName === "dd");
}
function ui(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && (r.tagName === "rp" || r.tagName === "rt");
}
function Pg(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && r.tagName === "optgroup";
}
function Lg(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && (r.tagName === "option" || r.tagName === "optgroup");
}
function $g(t, e, n) {
  const r = ae(n, e);
  return !!(r && r.type === "element" && (r.tagName === "tbody" || r.tagName === "tfoot"));
}
function Og(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && (r.tagName === "tbody" || r.tagName === "tfoot");
}
function Mg(t, e, n) {
  return !ae(n, e);
}
function Dg(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && r.tagName === "tr";
}
function pi(t, e, n) {
  const r = ae(n, e);
  return !r || r.type === "element" && (r.tagName === "td" || r.tagName === "th");
}
const Bg = Ul({
  body: zg,
  colgroup: Ug,
  head: Gg,
  html: Fg,
  tbody: Hg
});
function Fg(t) {
  const e = ae(t, -1);
  return !e || e.type !== "comment";
}
function Gg(t) {
  const e = /* @__PURE__ */ new Set();
  for (const r of t.children)
    if (r.type === "element" && (r.tagName === "base" || r.tagName === "title")) {
      if (e.has(r.tagName)) return !1;
      e.add(r.tagName);
    }
  const n = t.children[0];
  return !n || n.type === "element";
}
function zg(t) {
  const e = ae(t, -1, !0);
  return !e || e.type !== "comment" && !(e.type === "text" && Es(e.value.charAt(0))) && !(e.type === "element" && (e.tagName === "meta" || e.tagName === "link" || e.tagName === "script" || e.tagName === "style" || e.tagName === "template"));
}
function Ug(t, e, n) {
  const r = Gl(n, e), s = ae(t, -1, !0);
  return n && r && r.type === "element" && r.tagName === "colgroup" && ra(r, n.children.indexOf(r), n) ? !1 : !!(s && s.type === "element" && s.tagName === "col");
}
function Hg(t, e, n) {
  const r = Gl(n, e), s = ae(t, -1);
  return n && r && r.type === "element" && (r.tagName === "thead" || r.tagName === "tbody") && ra(r, n.children.indexOf(r), n) ? !1 : !!(s && s.type === "element" && s.tagName === "tr");
}
const kn = {
  // See: <https://html.spec.whatwg.org/#attribute-name-state>.
  name: [
    [`	
\f\r &/=>`.split(""), `	
\f\r "&'/=>\``.split("")],
    [`\0	
\f\r "&'/<=>`.split(""), `\0	
\f\r "&'/<=>\``.split("")]
  ],
  // See: <https://html.spec.whatwg.org/#attribute-value-(unquoted)-state>.
  unquoted: [
    [`	
\f\r &>`.split(""), `\0	
\f\r "&'<=>\``.split("")],
    [`\0	
\f\r "&'<=>\``.split(""), `\0	
\f\r "&'<=>\``.split("")]
  ],
  // See: <https://html.spec.whatwg.org/#attribute-value-(single-quoted)-state>.
  single: [
    ["&'".split(""), "\"&'`".split("")],
    ["\0&'".split(""), "\0\"&'`".split("")]
  ],
  // See: <https://html.spec.whatwg.org/#attribute-value-(double-quoted)-state>.
  double: [
    ['"&'.split(""), "\"&'`".split("")],
    ['\0"&'.split(""), "\0\"&'`".split("")]
  ]
};
function qg(t, e, n, r) {
  const s = r.schema, a = s.space === "svg" ? !1 : r.settings.omitOptionalTags;
  let i = s.space === "svg" ? r.settings.closeEmptyElements : r.settings.voids.includes(t.tagName.toLowerCase());
  const o = [];
  let l;
  s.space === "html" && t.tagName === "svg" && (r.schema = Zi);
  const c = Wg(r, t.properties), d = r.all(
    s.space === "html" && t.tagName === "template" ? t.content : t
  );
  return r.schema = s, d && (i = !1), (c || !a || !Bg(t, e, n)) && (o.push("<", t.tagName, c ? " " + c : ""), i && (s.space === "svg" || r.settings.closeSelfClosing) && (l = c.charAt(c.length - 1), (!r.settings.tightSelfClosing || l === "/" || l && l !== '"' && l !== "'") && o.push(" "), o.push("/")), o.push(">")), o.push(d), !i && (!a || !ra(t, e, n)) && o.push("</" + t.tagName + ">"), o.join("");
}
function Wg(t, e) {
  const n = [];
  let r = -1, s;
  if (e) {
    for (s in e)
      if (e[s] !== null && e[s] !== void 0) {
        const a = Zg(t, s, e[s]);
        a && n.push(a);
      }
  }
  for (; ++r < n.length; ) {
    const a = t.settings.tightAttributes ? n[r].charAt(n[r].length - 1) : void 0;
    r !== n.length - 1 && a !== '"' && a !== "'" && (n[r] += " ");
  }
  return n.join("");
}
function Zg(t, e, n) {
  const r = Kc(t.schema, e), s = t.settings.allowParseErrors && t.schema.space === "html" ? 0 : 1, a = t.settings.allowDangerousCharacters ? 0 : 1;
  let i = t.quote, o;
  if (r.overloadedBoolean && (n === r.attribute || n === "") ? n = !0 : (r.boolean || r.overloadedBoolean) && (typeof n != "string" || n === r.attribute || n === "") && (n = !!n), n == null || n === !1 || typeof n == "number" && Number.isNaN(n))
    return "";
  const l = jt(
    r.attribute,
    Object.assign({}, t.settings.characterReferences, {
      // Always encode without parse errors in non-HTML.
      subset: kn.name[s][a]
    })
  );
  return n === !0 || (n = Array.isArray(n) ? (r.commaSeparated ? eu : tu)(n, {
    padLeft: !t.settings.tightCommaSeparatedLists
  }) : String(n), t.settings.collapseEmptyAttributes && !n) ? l : (t.settings.preferUnquoted && (o = jt(
    n,
    Object.assign({}, t.settings.characterReferences, {
      attribute: !0,
      subset: kn.unquoted[s][a]
    })
  )), o !== n && (t.settings.quoteSmart && ka(n, i) > ka(n, t.alternative) && (i = t.alternative), o = i + jt(
    n,
    Object.assign({}, t.settings.characterReferences, {
      // Always encode without parse errors in non-HTML.
      subset: (i === "'" ? kn.single : kn.double)[s][a],
      attribute: !0
    })
  ) + i), l + (o && "=" + o));
}
const Vg = ["<", "&"];
function Hl(t, e, n, r) {
  return n && n.type === "element" && (n.tagName === "script" || n.tagName === "style") ? t.value : jt(
    t.value,
    Object.assign({}, r.settings.characterReferences, {
      subset: Vg
    })
  );
}
function Jg(t, e, n, r) {
  return r.settings.allowDangerousHtml ? t.value : Hl(t, e, n, r);
}
function Qg(t, e, n, r) {
  return r.all(t);
}
const Yg = pp("type", {
  invalid: Xg,
  unknown: Kg,
  handlers: { comment: _g, doctype: Sg, element: qg, raw: Jg, root: Qg, text: Hl }
});
function Xg(t) {
  throw new Error("Expected node, not `" + t + "`");
}
function Kg(t) {
  const e = (
    /** @type {Nodes} */
    t
  );
  throw new Error("Cannot compile unknown node `" + e.type + "`");
}
const ey = {}, ty = {}, ny = [];
function ry(t, e) {
  const n = e || ey, r = n.quote || '"', s = r === '"' ? "'" : '"';
  if (r !== '"' && r !== "'")
    throw new Error("Invalid quote `" + r + "`, expected `'` or `\"`");
  return {
    one: sy,
    all: ay,
    settings: {
      omitOptionalTags: n.omitOptionalTags || !1,
      allowParseErrors: n.allowParseErrors || !1,
      allowDangerousCharacters: n.allowDangerousCharacters || !1,
      quoteSmart: n.quoteSmart || !1,
      preferUnquoted: n.preferUnquoted || !1,
      tightAttributes: n.tightAttributes || !1,
      upperDoctype: n.upperDoctype || !1,
      tightDoctype: n.tightDoctype || !1,
      bogusComments: n.bogusComments || !1,
      tightCommaSeparatedLists: n.tightCommaSeparatedLists || !1,
      tightSelfClosing: n.tightSelfClosing || !1,
      collapseEmptyAttributes: n.collapseEmptyAttributes || !1,
      allowDangerousHtml: n.allowDangerousHtml || !1,
      voids: n.voids || rg,
      characterReferences: n.characterReferences || ty,
      closeSelfClosing: n.closeSelfClosing || !1,
      closeEmptyElements: n.closeEmptyElements || !1
    },
    schema: n.space === "svg" ? Zi : nu,
    quote: r,
    alternative: s
  }.one(
    Array.isArray(t) ? { type: "root", children: t } : t,
    void 0,
    void 0
  );
}
function sy(t, e, n) {
  return Yg(t, e, n, this);
}
function ay(t) {
  const e = [], n = t && t.children || ny;
  let r = -1;
  for (; ++r < n.length; )
    e[r] = this.one(n[r], r, t);
  return e.join("");
}
function ql(t, e) {
  var r;
  if (!e) return t;
  t.properties || (t.properties = {}), (r = t.properties).class || (r.class = []), typeof t.properties.class == "string" && (t.properties.class = t.properties.class.split(/\s+/g)), Array.isArray(t.properties.class) || (t.properties.class = []);
  const n = Array.isArray(e) ? e : e.split(/\s+/g);
  for (const s of n) s && !t.properties.class.includes(s) && t.properties.class.push(s);
  return t;
}
function iy(t) {
  const e = xr(t, !0).map(([s]) => s);
  function n(s) {
    if (s === t.length) return {
      line: e.length - 1,
      character: e[e.length - 1].length
    };
    let a = s, i = 0;
    for (const o of e) {
      if (a < o.length) break;
      a -= o.length, i++;
    }
    return {
      line: i,
      character: a
    };
  }
  function r(s, a) {
    let i = 0;
    for (let o = 0; o < s; o++) i += e[o].length;
    return i += a, i;
  }
  return {
    lines: e,
    indexToPos: n,
    posToIndex: r
  };
}
function oy(t, e, n) {
  const r = /* @__PURE__ */ new Set();
  for (const a of t.matchAll(/:?lang=["']([^"']+)["']/g)) {
    const i = a[1].toLowerCase().trim();
    i && r.add(i);
  }
  for (const a of t.matchAll(/(?:```|~~~)([\w-]+)/g)) {
    const i = a[1].toLowerCase().trim();
    i && r.add(i);
  }
  for (const a of t.matchAll(/\\begin\{([\w-]+)\}/g)) {
    const i = a[1].toLowerCase().trim();
    i && r.add(i);
  }
  for (const a of t.matchAll(/<script\s+(?:type|lang)=["']([^"']+)["']/gi)) {
    const i = a[1].toLowerCase().trim(), o = i.includes("/") ? i.split("/").pop() : i;
    o && r.add(o);
  }
  if (!n) return Array.from(r);
  const s = n.getBundledLanguages();
  return Array.from(r).filter((a) => a && s[a]);
}
const sa = "light-dark()", ly = ["color", "background-color"];
function cy(t, e) {
  let n = 0;
  const r = [];
  for (const s of e)
    s > n && r.push({
      ...t,
      content: t.content.slice(n, s),
      offset: t.offset + n
    }), n = s;
  return n < t.content.length && r.push({
    ...t,
    content: t.content.slice(n),
    offset: t.offset + n
  }), r;
}
function uy(t, e) {
  const n = Array.from(e instanceof Set ? e : new Set(e)).sort((r, s) => r - s);
  return n.length ? t.map((r) => r.flatMap((s) => {
    const a = n.filter((i) => s.offset < i && i < s.offset + s.content.length).map((i) => i - s.offset).sort((i, o) => i - o);
    return a.length ? cy(s, a) : s;
  })) : t;
}
function py(t, e, n, r, s = "css-vars") {
  const a = {
    content: t.content,
    explanation: t.explanation,
    offset: t.offset
  }, i = e.map((d) => Xn(t.variants[d])), o = new Set(i.flatMap((d) => Object.keys(d))), l = {}, c = (d, p) => {
    const h = p === "color" ? "" : p === "background-color" ? "-bg" : `-${p}`;
    return n + e[d] + (p === "color" ? "" : h);
  };
  return i.forEach((d, p) => {
    for (const h of o) {
      const m = d[h] || "inherit";
      if (p === 0 && r && ly.includes(h)) if (r === sa && i.length > 1) {
        const f = e.findIndex((b) => b === "light"), g = e.findIndex((b) => b === "dark");
        if (f === -1 || g === -1) throw new X('When using `defaultColor: "light-dark()"`, you must provide both `light` and `dark` themes');
        l[h] = `light-dark(${i[f][h] || "inherit"}, ${i[g][h] || "inherit"})`, s === "css-vars" && (l[c(p, h)] = m);
      } else l[h] = m;
      else s === "css-vars" && (l[c(p, h)] = m);
    }
  }), a.htmlStyle = l, a;
}
function Xn(t) {
  const e = {};
  if (t.color && (e.color = t.color), t.bgColor && (e["background-color"] = t.bgColor), t.fontStyle) {
    t.fontStyle & pe.Italic && (e["font-style"] = "italic"), t.fontStyle & pe.Bold && (e["font-weight"] = "bold");
    const n = [];
    t.fontStyle & pe.Underline && n.push("underline"), t.fontStyle & pe.Strikethrough && n.push("line-through"), n.length && (e["text-decoration"] = n.join(" "));
  }
  return e;
}
function ys(t) {
  return typeof t == "string" ? t : Object.entries(t).map(([e, n]) => `${e}:${n}`).join(";");
}
function dy() {
  const t = /* @__PURE__ */ new WeakMap();
  function e(n) {
    if (!t.has(n.meta)) {
      let s = function(i) {
        if (typeof i == "number") {
          if (i < 0 || i > n.source.length) throw new X(`Invalid decoration offset: ${i}. Code length: ${n.source.length}`);
          return {
            ...r.indexToPos(i),
            offset: i
          };
        } else {
          const o = r.lines[i.line];
          if (o === void 0) throw new X(`Invalid decoration position ${JSON.stringify(i)}. Lines length: ${r.lines.length}`);
          let l = i.character;
          if (l < 0 && (l = o.length + l), l < 0 || l > o.length) throw new X(`Invalid decoration position ${JSON.stringify(i)}. Line ${i.line} length: ${o.length}`);
          return {
            ...i,
            character: l,
            offset: r.posToIndex(i.line, l)
          };
        }
      };
      const r = iy(n.source), a = (n.options.decorations || []).map((i) => ({
        ...i,
        start: s(i.start),
        end: s(i.end)
      }));
      hy(a), t.set(n.meta, {
        decorations: a,
        converter: r,
        source: n.source
      });
    }
    return t.get(n.meta);
  }
  return {
    name: "shiki:decorations",
    tokens(n) {
      var r;
      if ((r = this.options.decorations) != null && r.length)
        return uy(n, e(this).decorations.flatMap((s) => [s.start.offset, s.end.offset]));
    },
    code(n) {
      var d;
      if (!((d = this.options.decorations) != null && d.length)) return;
      const r = e(this), s = Array.from(n.children).filter((p) => p.type === "element" && p.tagName === "span");
      if (s.length !== r.converter.lines.length) throw new X(`Number of lines in code element (${s.length}) does not match the number of lines in the source (${r.converter.lines.length}). Failed to apply decorations.`);
      function a(p, h, m, f) {
        const g = s[p];
        let b = "", v = -1, w = -1;
        if (h === 0 && (v = 0), m === 0 && (w = 0), m === Number.POSITIVE_INFINITY && (w = g.children.length), v === -1 || w === -1) for (let k = 0; k < g.children.length; k++)
          b += Wl(g.children[k]), v === -1 && b.length === h && (v = k + 1), w === -1 && b.length === m && (w = k + 1);
        if (v === -1) throw new X(`Failed to find start index for decoration ${JSON.stringify(f.start)}`);
        if (w === -1) throw new X(`Failed to find end index for decoration ${JSON.stringify(f.end)}`);
        const x = g.children.slice(v, w);
        if (!f.alwaysWrap && x.length === g.children.length) o(g, f, "line");
        else if (!f.alwaysWrap && x.length === 1 && x[0].type === "element") o(x[0], f, "token");
        else {
          const k = {
            type: "element",
            tagName: "span",
            properties: {},
            children: x
          };
          o(k, f, "wrapper"), g.children.splice(v, x.length, k);
        }
      }
      function i(p, h) {
        s[p] = o(s[p], h, "line");
      }
      function o(p, h, m) {
        var b;
        const f = h.properties || {}, g = h.transform || ((v) => v);
        return p.tagName = h.tagName || "span", p.properties = {
          ...p.properties,
          ...f,
          class: p.properties.class
        }, (b = h.properties) != null && b.class && ql(p, h.properties.class), p = g(p, m) || p, p;
      }
      const l = [], c = r.decorations.sort((p, h) => h.start.offset - p.start.offset || p.end.offset - h.end.offset);
      for (const p of c) {
        const { start: h, end: m } = p;
        if (h.line === m.line) a(h.line, h.character, m.character, p);
        else if (h.line < m.line) {
          a(h.line, h.character, Number.POSITIVE_INFINITY, p);
          for (let f = h.line + 1; f < m.line; f++) l.unshift(() => i(f, p));
          a(m.line, 0, m.character, p);
        }
      }
      l.forEach((p) => p());
    }
  };
}
function hy(t) {
  for (let e = 0; e < t.length; e++) {
    const n = t[e];
    if (n.start.offset > n.end.offset) throw new X(`Invalid decoration range: ${JSON.stringify(n.start)} - ${JSON.stringify(n.end)}`);
    for (let r = e + 1; r < t.length; r++) {
      const s = t[r], a = n.start.offset <= s.start.offset && s.start.offset < n.end.offset, i = n.start.offset < s.end.offset && s.end.offset <= n.end.offset, o = s.start.offset <= n.start.offset && n.start.offset < s.end.offset, l = s.start.offset < n.end.offset && n.end.offset <= s.end.offset;
      if (a || i || o || l) {
        if (a && i || o && l || o && n.start.offset === n.end.offset || i && s.start.offset === s.end.offset) continue;
        throw new X(`Decorations ${JSON.stringify(n.start)} and ${JSON.stringify(s.start)} intersect.`);
      }
    }
  }
}
function Wl(t) {
  return t.type === "text" ? t.value : t.type === "element" ? t.children.map(Wl).join("") : "";
}
const fy = [/* @__PURE__ */ dy()];
function Kn(t) {
  const e = my(t.transformers || []);
  return [
    ...e.pre,
    ...e.normal,
    ...e.post,
    ...fy
  ];
}
function my(t) {
  const e = [], n = [], r = [];
  for (const s of t) switch (s.enforce) {
    case "pre":
      e.push(s);
      break;
    case "post":
      n.push(s);
      break;
    default:
      r.push(s);
  }
  return {
    pre: e,
    post: n,
    normal: r
  };
}
var ht = [
  "black",
  "red",
  "green",
  "yellow",
  "blue",
  "magenta",
  "cyan",
  "white",
  "brightBlack",
  "brightRed",
  "brightGreen",
  "brightYellow",
  "brightBlue",
  "brightMagenta",
  "brightCyan",
  "brightWhite"
], Fr = {
  1: "bold",
  2: "dim",
  3: "italic",
  4: "underline",
  7: "reverse",
  8: "hidden",
  9: "strikethrough"
};
function gy(t, e) {
  const n = t.indexOf("\x1B", e);
  if (n !== -1 && t[n + 1] === "[") {
    const r = t.indexOf("m", n);
    if (r !== -1) return {
      sequence: t.substring(n + 2, r).split(";"),
      startPosition: n,
      position: r + 1
    };
  }
  return { position: t.length };
}
function di(t) {
  const e = t.shift();
  if (e === "2") {
    const n = t.splice(0, 3).map((r) => Number.parseInt(r));
    return n.length !== 3 || n.some((r) => Number.isNaN(r)) ? void 0 : {
      type: "rgb",
      rgb: n
    };
  } else if (e === "5") {
    const n = t.shift();
    if (n) return {
      type: "table",
      index: Number(n)
    };
  }
}
function yy(t) {
  const e = [];
  for (; t.length > 0; ) {
    const n = t.shift();
    if (!n) continue;
    const r = Number.parseInt(n);
    if (!Number.isNaN(r))
      if (r === 0) e.push({ type: "resetAll" });
      else if (r <= 9)
        Fr[r] && e.push({
          type: "setDecoration",
          value: Fr[r]
        });
      else if (r <= 29) {
        const s = Fr[r - 20];
        s && (e.push({
          type: "resetDecoration",
          value: s
        }), s === "dim" && e.push({
          type: "resetDecoration",
          value: "bold"
        }));
      } else if (r <= 37) e.push({
        type: "setForegroundColor",
        value: {
          type: "named",
          name: ht[r - 30]
        }
      });
      else if (r === 38) {
        const s = di(t);
        s && e.push({
          type: "setForegroundColor",
          value: s
        });
      } else if (r === 39) e.push({ type: "resetForegroundColor" });
      else if (r <= 47) e.push({
        type: "setBackgroundColor",
        value: {
          type: "named",
          name: ht[r - 40]
        }
      });
      else if (r === 48) {
        const s = di(t);
        s && e.push({
          type: "setBackgroundColor",
          value: s
        });
      } else r === 49 ? e.push({ type: "resetBackgroundColor" }) : r === 53 ? e.push({
        type: "setDecoration",
        value: "overline"
      }) : r === 55 ? e.push({
        type: "resetDecoration",
        value: "overline"
      }) : r >= 90 && r <= 97 ? e.push({
        type: "setForegroundColor",
        value: {
          type: "named",
          name: ht[r - 90 + 8]
        }
      }) : r >= 100 && r <= 107 && e.push({
        type: "setBackgroundColor",
        value: {
          type: "named",
          name: ht[r - 100 + 8]
        }
      });
  }
  return e;
}
function xy() {
  let t = null, e = null, n = /* @__PURE__ */ new Set();
  return { parse(r) {
    const s = [];
    let a = 0;
    do {
      const i = gy(r, a), o = i.sequence ? r.substring(a, i.startPosition) : r.substring(a);
      if (o.length > 0 && s.push({
        value: o,
        foreground: t,
        background: e,
        decorations: new Set(n)
      }), i.sequence) {
        const l = yy(i.sequence);
        for (const c of l) c.type === "resetAll" ? (t = null, e = null, n.clear()) : c.type === "resetForegroundColor" ? t = null : c.type === "resetBackgroundColor" ? e = null : c.type === "resetDecoration" && n.delete(c.value);
        for (const c of l) c.type === "setForegroundColor" ? t = c.value : c.type === "setBackgroundColor" ? e = c.value : c.type === "setDecoration" && n.add(c.value);
      }
      a = i.position;
    } while (a < r.length);
    return s;
  } };
}
var by = {
  black: "#000000",
  red: "#bb0000",
  green: "#00bb00",
  yellow: "#bbbb00",
  blue: "#0000bb",
  magenta: "#ff00ff",
  cyan: "#00bbbb",
  white: "#eeeeee",
  brightBlack: "#555555",
  brightRed: "#ff5555",
  brightGreen: "#00ff00",
  brightYellow: "#ffff55",
  brightBlue: "#5555ff",
  brightMagenta: "#ff55ff",
  brightCyan: "#55ffff",
  brightWhite: "#ffffff"
};
function wy(t = by) {
  function e(o) {
    return t[o];
  }
  function n(o) {
    return `#${o.map((l) => Math.max(0, Math.min(l, 255)).toString(16).padStart(2, "0")).join("")}`;
  }
  let r;
  function s() {
    if (r) return r;
    r = [];
    for (let c = 0; c < ht.length; c++) r.push(e(ht[c]));
    let o = [
      0,
      95,
      135,
      175,
      215,
      255
    ];
    for (let c = 0; c < 6; c++) for (let d = 0; d < 6; d++) for (let p = 0; p < 6; p++) r.push(n([
      o[c],
      o[d],
      o[p]
    ]));
    let l = 8;
    for (let c = 0; c < 24; c++, l += 10) r.push(n([
      l,
      l,
      l
    ]));
    return r;
  }
  function a(o) {
    return s()[o];
  }
  function i(o) {
    switch (o.type) {
      case "named":
        return e(o.name);
      case "rgb":
        return n(o.rgb);
      case "table":
        return a(o.index);
    }
  }
  return { value: i };
}
const ky = {
  black: "#000000",
  red: "#cd3131",
  green: "#0DBC79",
  yellow: "#E5E510",
  blue: "#2472C8",
  magenta: "#BC3FBC",
  cyan: "#11A8CD",
  white: "#E5E5E5",
  brightBlack: "#666666",
  brightRed: "#F14C4C",
  brightGreen: "#23D18B",
  brightYellow: "#F5F543",
  brightBlue: "#3B8EEA",
  brightMagenta: "#D670D6",
  brightCyan: "#29B8DB",
  brightWhite: "#FFFFFF"
};
function vy(t, e, n) {
  const r = Yn(t, n), s = xr(e), a = wy(Object.fromEntries(ht.map((o) => {
    var c;
    const l = `terminal.ansi${o[0].toUpperCase()}${o.substring(1)}`;
    return [o, ((c = t.colors) == null ? void 0 : c[l]) || ky[o]];
  }))), i = xy();
  return s.map((o) => i.parse(o[0]).map((l) => {
    let c, d;
    l.decorations.has("reverse") ? (c = l.background ? a.value(l.background) : t.bg, d = l.foreground ? a.value(l.foreground) : t.fg) : (c = l.foreground ? a.value(l.foreground) : t.fg, d = l.background ? a.value(l.background) : void 0), c = tt(c, r), d = tt(d, r), l.decorations.has("dim") && (c = _y(c));
    let p = pe.None;
    return l.decorations.has("bold") && (p |= pe.Bold), l.decorations.has("italic") && (p |= pe.Italic), l.decorations.has("underline") && (p |= pe.Underline), l.decorations.has("strikethrough") && (p |= pe.Strikethrough), {
      content: l.value,
      offset: o[1],
      color: c,
      bgColor: d,
      fontStyle: p
    };
  }));
}
function _y(t) {
  const e = t.match(/#([0-9a-f]{3,8})/i);
  if (e) {
    const r = e[1];
    if (r.length === 8) {
      const s = Math.round(Number.parseInt(r.slice(6, 8), 16) / 2).toString(16).padStart(2, "0");
      return `#${r.slice(0, 6)}${s}`;
    } else {
      if (r.length === 6) return `#${r}80`;
      if (r.length === 4) {
        const s = r[0], a = r[1], i = r[2], o = r[3];
        return `#${s}${s}${a}${a}${i}${i}${Math.round(Number.parseInt(`${o}${o}`, 16) / 2).toString(16).padStart(2, "0")}`;
      } else if (r.length === 3) {
        const s = r[0], a = r[1], i = r[2];
        return `#${s}${s}${a}${a}${i}${i}80`;
      }
    }
  }
  const n = t.match(/var\((--[\w-]+-ansi-[\w-]+)\)/);
  return n ? `var(${n[1]}-dim)` : t;
}
function xs(t, e, n = {}) {
  const r = t.resolveLangAlias(n.lang || "text"), { theme: s = t.getLoadedThemes()[0] } = n;
  if (!gr(r) && !yr(s) && r === "ansi") {
    const { theme: a } = t.setTheme(s);
    return vy(a, e, n);
  }
  return Dl(t, e, n);
}
function er(t, e, n) {
  let r, s, a, i, o, l;
  if ("themes" in n) {
    const { defaultColor: c = "light", cssVariablePrefix: d = "--shiki-", colorsRendering: p = "css-vars" } = n, h = Object.entries(n.themes).filter((v) => v[1]).map((v) => ({
      color: v[0],
      theme: v[1]
    })).sort((v, w) => v.color === c ? -1 : w.color === c ? 1 : 0);
    if (h.length === 0) throw new X("`themes` option must not be empty");
    const m = Bl(t, e, n, xs);
    if (l = rn(m), c && sa !== c && !h.find((v) => v.color === c)) throw new X(`\`themes\` option must contain the defaultColor key \`${c}\``);
    const f = h.map((v) => t.getTheme(v.theme)), g = h.map((v) => v.color);
    a = m.map((v) => v.map((w) => py(w, g, d, c, p))), l && br(a, l);
    const b = h.map((v) => Yn(v.theme, n));
    s = hi(h, f, b, d, c, "fg", p), r = hi(h, f, b, d, c, "bg", p), i = `shiki-themes ${f.map((v) => v.name).join(" ")}`, o = c ? void 0 : [s, r].join(";");
  } else if ("theme" in n) {
    const c = Yn(n.theme, n);
    a = xs(t, e, n);
    const d = t.getTheme(n.theme);
    r = tt(d.bg, c), s = tt(d.fg, c), i = d.name, l = rn(a);
  } else throw new X("Invalid options, either `theme` or `themes` must be provided");
  return {
    tokens: a,
    fg: s,
    bg: r,
    themeName: i,
    rootStyle: o,
    grammarState: l
  };
}
function hi(t, e, n, r, s, a, i) {
  return t.map((o, l) => {
    const c = tt(e[l][a], n[l]) || "inherit", d = `${r + o.color}${a === "bg" ? "-bg" : ""}:${c}`;
    if (l === 0 && s) {
      if (s === sa && t.length > 1) {
        const p = t.findIndex((m) => m.color === "light"), h = t.findIndex((m) => m.color === "dark");
        if (p === -1 || h === -1) throw new X('When using `defaultColor: "light-dark()"`, you must provide both `light` and `dark` themes');
        return `light-dark(${tt(e[p][a], n[p]) || "inherit"}, ${tt(e[h][a], n[h]) || "inherit"});${d}`;
      }
      return c;
    }
    return i === "css-vars" ? d : null;
  }).filter((o) => !!o).join(";");
}
function tr(t, e, n, r = {
  meta: {},
  options: n,
  codeToHast: (s, a) => tr(t, s, a),
  codeToTokens: (s, a) => er(t, s, a)
}) {
  var f, g;
  let s = e;
  for (const b of Kn(n)) s = ((f = b.preprocess) == null ? void 0 : f.call(r, s, n)) || s;
  let { tokens: a, fg: i, bg: o, themeName: l, rootStyle: c, grammarState: d } = er(t, s, n);
  const { mergeWhitespaces: p = !0, mergeSameStyleTokens: h = !1 } = n;
  p === !0 ? a = Cy(a) : p === "never" && (a = Ny(a)), h && (a = Ay(a));
  const m = {
    ...r,
    get source() {
      return s;
    }
  };
  for (const b of Kn(n)) a = ((g = b.tokens) == null ? void 0 : g.call(m, a)) || a;
  return Sy(a, {
    ...n,
    fg: i,
    bg: o,
    themeName: l,
    rootStyle: n.rootStyle === !1 ? !1 : n.rootStyle ?? c
  }, m, d);
}
function Sy(t, e, n, r = rn(t)) {
  var g, b, v, w;
  const s = Kn(e), a = [], i = {
    type: "root",
    children: []
  }, { structure: o = "classic", tabindex: l = "0" } = e, c = { class: `shiki ${e.themeName || ""}` };
  e.rootStyle !== !1 && (e.rootStyle != null ? c.style = e.rootStyle : c.style = `background-color:${e.bg};color:${e.fg}`), l !== !1 && l != null && (c.tabindex = l.toString());
  for (const [x, k] of Object.entries(e.meta || {})) x.startsWith("_") || (c[x] = k);
  let d = {
    type: "element",
    tagName: "pre",
    properties: c,
    children: [],
    data: e.data
  }, p = {
    type: "element",
    tagName: "code",
    properties: {},
    children: a
  };
  const h = [], m = {
    ...n,
    structure: o,
    addClassToHast: ql,
    get source() {
      return n.source;
    },
    get tokens() {
      return t;
    },
    get options() {
      return e;
    },
    get root() {
      return i;
    },
    get pre() {
      return d;
    },
    get code() {
      return p;
    },
    get lines() {
      return h;
    }
  };
  if (t.forEach((x, k) => {
    var C, E;
    k && (o === "inline" ? i.children.push({
      type: "element",
      tagName: "br",
      properties: {},
      children: []
    }) : o === "classic" && a.push({
      type: "text",
      value: `
`
    }));
    let S = {
      type: "element",
      tagName: "span",
      properties: { class: "line" },
      children: []
    }, N = 0;
    for (const O of x) {
      let R = {
        type: "element",
        tagName: "span",
        properties: { ...O.htmlAttrs },
        children: [{
          type: "text",
          value: O.content
        }]
      };
      const I = ys(O.htmlStyle || Xn(O));
      I && (R.properties.style = I);
      for (const j of s) R = ((C = j == null ? void 0 : j.span) == null ? void 0 : C.call(m, R, k + 1, N, S, O)) || R;
      o === "inline" ? i.children.push(R) : o === "classic" && S.children.push(R), N += O.content.length;
    }
    if (o === "classic") {
      for (const O of s) S = ((E = O == null ? void 0 : O.line) == null ? void 0 : E.call(m, S, k + 1)) || S;
      h.push(S), a.push(S);
    } else o === "inline" && h.push(S);
  }), o === "classic") {
    for (const x of s) p = ((g = x == null ? void 0 : x.code) == null ? void 0 : g.call(m, p)) || p;
    d.children.push(p);
    for (const x of s) d = ((b = x == null ? void 0 : x.pre) == null ? void 0 : b.call(m, d)) || d;
    i.children.push(d);
  } else if (o === "inline") {
    const x = [];
    let k = {
      type: "element",
      tagName: "span",
      properties: { class: "line" },
      children: []
    };
    for (const N of i.children) N.type === "element" && N.tagName === "br" ? (x.push(k), k = {
      type: "element",
      tagName: "span",
      properties: { class: "line" },
      children: []
    }) : (N.type === "element" || N.type === "text") && k.children.push(N);
    x.push(k);
    let S = {
      type: "element",
      tagName: "code",
      properties: {},
      children: x
    };
    for (const N of s) S = ((v = N == null ? void 0 : N.code) == null ? void 0 : v.call(m, S)) || S;
    i.children = [];
    for (let N = 0; N < S.children.length; N++) {
      N > 0 && i.children.push({
        type: "element",
        tagName: "br",
        properties: {},
        children: []
      });
      const C = S.children[N];
      C.type === "element" && i.children.push(...C.children);
    }
  }
  let f = i;
  for (const x of s) f = ((w = x == null ? void 0 : x.root) == null ? void 0 : w.call(m, f)) || f;
  return r && br(f, r), f;
}
function Cy(t) {
  return t.map((e) => {
    const n = [];
    let r = "", s;
    return e.forEach((a, i) => {
      const o = !(a.fontStyle && (a.fontStyle & pe.Underline || a.fontStyle & pe.Strikethrough));
      o && a.content.match(/^\s+$/) && e[i + 1] ? (s === void 0 && (s = a.offset), r += a.content) : r ? (o ? n.push({
        ...a,
        offset: s,
        content: r + a.content
      }) : n.push({
        content: r,
        offset: s
      }, a), s = void 0, r = "") : n.push(a);
    }), n;
  });
}
function Ny(t) {
  return t.map((e) => e.flatMap((n) => {
    if (n.content.match(/^\s+$/)) return n;
    const r = n.content.match(/^(\s*)(.*?)(\s*)$/);
    if (!r) return n;
    const [, s, a, i] = r;
    if (!s && !i) return n;
    const o = [{
      ...n,
      offset: n.offset + s.length,
      content: a
    }];
    return s && o.unshift({
      content: s,
      offset: n.offset
    }), i && o.push({
      content: i,
      offset: n.offset + s.length + a.length
    }), o;
  }));
}
function Ay(t) {
  return t.map((e) => {
    const n = [];
    for (const r of e) {
      if (n.length === 0) {
        n.push({ ...r });
        continue;
      }
      const s = n[n.length - 1], a = ys(s.htmlStyle || Xn(s)), i = ys(r.htmlStyle || Xn(r)), o = s.fontStyle && (s.fontStyle & pe.Underline || s.fontStyle & pe.Strikethrough), l = r.fontStyle && (r.fontStyle & pe.Underline || r.fontStyle & pe.Strikethrough);
      !o && !l && a === i ? s.content += r.content : n.push({ ...r });
    }
    return n;
  });
}
const Iy = ry;
function Ty(t, e, n) {
  var a;
  const r = {
    meta: {},
    options: n,
    codeToHast: (i, o) => tr(t, i, o),
    codeToTokens: (i, o) => er(t, i, o)
  };
  let s = Iy(tr(t, e, n, r));
  for (const i of Kn(n)) s = ((a = i.postprocess) == null ? void 0 : a.call(r, s, n)) || s;
  return s;
}
async function Ey(t) {
  const e = await Zm(t);
  return {
    getLastGrammarState: (...n) => Qm(e, ...n),
    codeToTokensBase: (n, r) => xs(e, n, r),
    codeToTokensWithThemes: (n, r) => Bl(e, n, r),
    codeToTokens: (n, r) => er(e, n, r),
    codeToHast: (n, r) => tr(e, n, r),
    codeToHtml: (n, r) => Ty(e, n, r),
    getBundledLanguages: () => ({}),
    getBundledThemes: () => ({}),
    ...e,
    getInternalContext: () => e
  };
}
function jy(t) {
  const e = t.langs, n = t.themes, r = t.engine;
  async function s(a) {
    function i(p) {
      var h;
      if (typeof p == "string") {
        if (p = ((h = a.langAlias) == null ? void 0 : h[p]) || p, jl(p)) return [];
        const m = e[p];
        if (!m) throw new X(`Language \`${p}\` is not included in this bundle. You may want to load it from external source.`);
        return m;
      }
      return p;
    }
    function o(p) {
      if (Rl(p)) return "none";
      if (typeof p == "string") {
        const h = n[p];
        if (!h) throw new X(`Theme \`${p}\` is not included in this bundle. You may want to load it from external source.`);
        return h;
      }
      return p;
    }
    const l = (a.themes ?? []).map((p) => o(p)), c = (a.langs ?? []).map((p) => i(p)), d = await Ey({
      engine: a.engine ?? r(),
      ...a,
      themes: l,
      langs: c
    });
    return {
      ...d,
      loadLanguage(...p) {
        return d.loadLanguage(...p.map(i));
      },
      loadTheme(...p) {
        return d.loadTheme(...p.map(o));
      },
      getBundledLanguages() {
        return e;
      },
      getBundledThemes() {
        return n;
      }
    };
  }
  return s;
}
function Ry(t) {
  let e;
  async function n(r = {}) {
    if (e) {
      const s = await e;
      return await Promise.all([s.loadTheme(...r.themes || []), s.loadLanguage(...r.langs || [])]), s;
    } else {
      e = t({
        ...r,
        themes: [],
        langs: []
      });
      const s = await e;
      return await Promise.all([s.loadTheme(...r.themes || []), s.loadLanguage(...r.langs || [])]), s;
    }
  }
  return n;
}
function Py(t, e) {
  const n = Ry(t);
  async function r(s, a) {
    var l;
    const i = await n({
      langs: [a.lang],
      themes: "theme" in a ? [a.theme] : Object.values(a.themes)
    }), o = await ((l = e == null ? void 0 : e.guessEmbeddedLanguages) == null ? void 0 : l.call(e, s, a.lang, i));
    return o && await i.loadLanguage(...o), i;
  }
  return {
    getSingletonHighlighter(s) {
      return n(s);
    },
    async codeToHtml(s, a) {
      return (await r(s, a)).codeToHtml(s, a);
    },
    async codeToHast(s, a) {
      return (await r(s, a)).codeToHast(s, a);
    },
    async codeToTokens(s, a) {
      return (await r(s, a)).codeToTokens(s, a);
    },
    async codeToTokensBase(s, a) {
      return (await r(s, a)).codeToTokensBase(s, a);
    },
    async codeToTokensWithThemes(s, a) {
      return (await r(s, a)).codeToTokensWithThemes(s, a);
    },
    async getLastGrammarState(s, a) {
      return (await n({
        langs: [a.lang],
        themes: [a.theme]
      })).getLastGrammarState(s, a);
    }
  };
}
var Ly = /* @__PURE__ */ Zs({
  bundledLanguages: () => hr,
  bundledLanguagesAlias: () => Js,
  bundledLanguagesBase: () => Vs,
  bundledLanguagesInfo: () => dr,
  bundledThemes: () => Ys,
  bundledThemesInfo: () => Qs,
  codeToHast: () => Vl,
  codeToHtml: () => Zl,
  codeToTokens: () => nr,
  codeToTokensBase: () => Jl,
  codeToTokensWithThemes: () => Ql,
  createHighlighter: () => aa,
  getLastGrammarState: () => Xl,
  getSingletonHighlighter: () => Yl
});
const aa = /* @__PURE__ */ jy({
  langs: hr,
  themes: Ys,
  engine: () => (0, fl.createOnigurumaEngine)(import("./wasm-DQxwEHae.mjs"))
}), { codeToHtml: Zl, codeToHast: Vl, codeToTokens: nr, codeToTokensBase: Jl, codeToTokensWithThemes: Ql, getSingletonHighlighter: Yl, getLastGrammarState: Xl } = /* @__PURE__ */ Py(aa, { guessEmbeddedLanguages: oy }), fi = 4294967295;
var $y = class {
  constructor(t, e = {}) {
    _(this, "regexps");
    this.patterns = t, this.options = e;
    const { forgiving: n = !1, cache: r, regexConstructor: s } = e;
    if (!s) throw new Error("Option `regexConstructor` is not provided");
    this.regexps = t.map((a) => {
      if (typeof a != "string") return a;
      const i = r == null ? void 0 : r.get(a);
      if (i) {
        if (i instanceof RegExp) return i;
        if (n) return null;
        throw i;
      }
      try {
        const o = s(a);
        return r == null || r.set(a, o), o;
      } catch (o) {
        if (r == null || r.set(a, o), n) return null;
        throw o;
      }
    });
  }
  findNextMatchSync(t, e, n) {
    const r = typeof t == "string" ? t : t.content, s = [];
    function a(i, o, l = 0) {
      return {
        index: i,
        captureIndices: o.indices.map((c) => c == null ? {
          start: fi,
          end: fi,
          length: 0
        } : {
          start: c[0] + l,
          end: c[1] + l,
          length: c[1] - c[0]
        })
      };
    }
    for (let i = 0; i < this.regexps.length; i++) {
      const o = this.regexps[i];
      if (o)
        try {
          o.lastIndex = e;
          const l = o.exec(r);
          if (!l) continue;
          if (l.index === e) return a(i, l, 0);
          s.push([
            i,
            l,
            0
          ]);
        } catch (l) {
          if (this.options.forgiving) continue;
          throw l;
        }
    }
    if (s.length) {
      const i = Math.min(...s.map((o) => o[1].index));
      for (const [o, l, c] of s) if (l.index === i) return a(o, l, c);
    }
    return null;
  }
};
function Ot(t) {
  if ([...t].length !== 1) throw new Error(`Expected "${t}" to be a single code point`);
  return t.codePointAt(0);
}
function Oy(t, e, n) {
  return t.has(e) || t.set(e, n), t.get(e);
}
const ia = /* @__PURE__ */ new Set(["alnum", "alpha", "ascii", "blank", "cntrl", "digit", "graph", "lower", "print", "punct", "space", "upper", "word", "xdigit"]), le = String.raw;
function Mt(t, e) {
  if (t == null) throw new Error(e ?? "Value expected");
  return t;
}
const Kl = le`\[\^?`, ec = `c.? | C(?:-.?)?|${le`[pP]\{(?:\^?[-\x20_]*[A-Za-z][-\x20\w]*\})?`}|${le`x[89A-Fa-f]\p{AHex}(?:\\x[89A-Fa-f]\p{AHex})*`}|${le`u(?:\p{AHex}{4})? | x\{[^\}]*\}? | x\p{AHex}{0,2}`}|${le`o\{[^\}]*\}?`}|${le`\d{1,3}`}`, oa = /[?*+][?+]?|\{(?:\d+(?:,\d*)?|,\d+)\}\??/, vn = new RegExp(le`
  \\ (?:
    ${ec}
    | [gk]<[^>]*>?
    | [gk]'[^']*'?
    | .
  )
  | \( (?:
    \? (?:
      [:=!>({]
      | <[=!]
      | <[^>]*>
      | '[^']*'
      | ~\|?
      | #(?:[^)\\]|\\.?)*
      | [^:)]*[:)]
    )?
    | \*[^\)]*\)?
  )?
  | (?:${oa.source})+
  | ${Kl}
  | .
`.replace(/\s+/g, ""), "gsu"), Gr = new RegExp(le`
  \\ (?:
    ${ec}
    | .
  )
  | \[:(?:\^?\p{Alpha}+|\^):\]
  | ${Kl}
  | &&
  | .
`.replace(/\s+/g, ""), "gsu");
function My(t, e = {}) {
  const n = { flags: "", ...e, rules: { captureGroup: !1, singleline: !1, ...e.rules } };
  if (typeof t != "string") throw new Error("String expected as pattern");
  const r = nx(n.flags), s = [r.extended], a = { captureGroup: n.rules.captureGroup, getCurrentModX() {
    return s.at(-1);
  }, numOpenGroups: 0, popModX() {
    s.pop();
  }, pushModX(p) {
    s.push(p);
  }, replaceCurrentModX(p) {
    s[s.length - 1] = p;
  }, singleline: n.rules.singleline };
  let i = [], o;
  for (vn.lastIndex = 0; o = vn.exec(t); ) {
    const p = Dy(a, t, o[0], vn.lastIndex);
    p.tokens ? i.push(...p.tokens) : p.token && i.push(p.token), p.lastIndex !== void 0 && (vn.lastIndex = p.lastIndex);
  }
  const l = [];
  let c = 0;
  i.filter((p) => p.type === "GroupOpen").forEach((p) => {
    p.kind === "capturing" ? p.number = ++c : p.raw === "(" && l.push(p);
  }), c || l.forEach((p, h) => {
    p.kind = "capturing", p.number = h + 1;
  });
  const d = c || l.length;
  return { tokens: i.map((p) => p.type === "EscapedNumber" ? sx(p, d) : p).flat(), flags: r };
}
function Dy(t, e, n, r) {
  const [s, a] = n;
  if (n === "[" || n === "[^") {
    const i = By(e, n, r);
    return { tokens: i.tokens, lastIndex: i.lastIndex };
  }
  if (s === "\\") {
    if ("AbBGyYzZ".includes(a)) return { token: mi(n, n) };
    if (/^\\g[<']/.test(n)) {
      if (!/^\\g(?:<[^>]+>|'[^']+')$/.test(n)) throw new Error(`Invalid group name "${n}"`);
      return { token: Jy(n) };
    }
    if (/^\\k[<']/.test(n)) {
      if (!/^\\k(?:<[^>]+>|'[^']+')$/.test(n)) throw new Error(`Invalid group name "${n}"`);
      return { token: nc(n) };
    }
    if (a === "K") return { token: rc("keep", n) };
    if (a === "N" || a === "R") return { token: ft("newline", n, { negate: a === "N" }) };
    if (a === "O") return { token: ft("any", n) };
    if (a === "X") return { token: ft("text_segment", n) };
    const i = tc(n, { inCharClass: !1 });
    return Array.isArray(i) ? { tokens: i } : { token: i };
  }
  if (s === "(") {
    if (a === "*") return { token: Ky(n) };
    if (n === "(?{") throw new Error(`Unsupported callout "${n}"`);
    if (n.startsWith("(?#")) {
      if (e[r] !== ")") throw new Error('Unclosed comment group "(?#"');
      return { lastIndex: r + 1 };
    }
    if (/^\(\?[-imx]+[:)]$/.test(n)) return { token: Xy(n, t) };
    if (t.pushModX(t.getCurrentModX()), t.numOpenGroups++, n === "(" && !t.captureGroup || n === "(?:") return { token: Tt("group", n) };
    if (n === "(?>") return { token: Tt("atomic", n) };
    if (n === "(?=" || n === "(?!" || n === "(?<=" || n === "(?<!") return { token: Tt(n[2] === "<" ? "lookbehind" : "lookahead", n, { negate: n.endsWith("!") }) };
    if (n === "(" && t.captureGroup || n.startsWith("(?<") && n.endsWith(">") || n.startsWith("(?'") && n.endsWith("'")) return { token: Tt("capturing", n, { ...n !== "(" && { name: n.slice(3, -1) } }) };
    if (n.startsWith("(?~")) {
      if (n === "(?~|") throw new Error(`Unsupported absence function kind "${n}"`);
      return { token: Tt("absence_repeater", n) };
    }
    throw n === "(?(" ? new Error(`Unsupported conditional "${n}"`) : new Error(`Invalid or unsupported group option "${n}"`);
  }
  if (n === ")") {
    if (t.popModX(), t.numOpenGroups--, t.numOpenGroups < 0) throw new Error('Unmatched ")"');
    return { token: Wy(n) };
  }
  if (t.getCurrentModX()) {
    if (n === "#") {
      const i = e.indexOf(`
`, r);
      return { lastIndex: i === -1 ? e.length : i };
    }
    if (/^\s$/.test(n)) {
      const i = /\s+/y;
      return i.lastIndex = r, { lastIndex: i.exec(e) ? i.lastIndex : r };
    }
  }
  if (n === ".") return { token: ft("dot", n) };
  if (n === "^" || n === "$") {
    const i = t.singleline ? { "^": le`\A`, $: le`\Z` }[n] : n;
    return { token: mi(i, n) };
  }
  return n === "|" ? { token: Gy(n) } : oa.test(n) ? { tokens: ax(n) } : { token: qe(Ot(n), n) };
}
function By(t, e, n) {
  const r = [gi(e[1] === "^", e)];
  let s = 1, a;
  for (Gr.lastIndex = n; a = Gr.exec(t); ) {
    const i = a[0];
    if (i[0] === "[" && i[1] !== ":") s++, r.push(gi(i[1] === "^", i));
    else if (i === "]") {
      if (r.at(-1).type === "CharacterClassOpen") r.push(qe(93, i));
      else if (s--, r.push(zy(i)), !s) break;
    } else {
      const o = Fy(i);
      Array.isArray(o) ? r.push(...o) : r.push(o);
    }
  }
  return { tokens: r, lastIndex: Gr.lastIndex || t.length };
}
function Fy(t) {
  if (t[0] === "\\") return tc(t, { inCharClass: !0 });
  if (t[0] === "[") {
    const e = /\[:(?<negate>\^?)(?<name>[a-z]+):\]/.exec(t);
    if (!e || !ia.has(e.groups.name)) throw new Error(`Invalid POSIX class "${t}"`);
    return ft("posix", t, { value: e.groups.name, negate: !!e.groups.negate });
  }
  return t === "-" ? Uy(t) : t === "&&" ? Hy(t) : qe(Ot(t), t);
}
function tc(t, { inCharClass: e }) {
  const n = t[1];
  if (n === "c" || n === "C") return Yy(t);
  if ("dDhHsSwW".includes(n)) return ex(t);
  if (t.startsWith(le`\o{`)) throw new Error(`Incomplete, invalid, or unsupported octal code point "${t}"`);
  if (/^\\[pP]\{/.test(t)) {
    if (t.length === 3) throw new Error(`Incomplete or invalid Unicode property "${t}"`);
    return tx(t);
  }
  if (new RegExp("^\\\\x[89A-Fa-f]\\p{AHex}", "u").test(t)) try {
    const r = t.split(/\\x/).slice(1).map((i) => parseInt(i, 16)), s = new TextDecoder("utf-8", { ignoreBOM: !0, fatal: !0 }).decode(new Uint8Array(r)), a = new TextEncoder();
    return [...s].map((i) => {
      const o = [...a.encode(i)].map((l) => `\\x${l.toString(16)}`).join("");
      return qe(Ot(i), o);
    });
  } catch {
    throw new Error(`Multibyte code "${t}" incomplete or invalid in Oniguruma`);
  }
  if (n === "u" || n === "x") return qe(rx(t), t);
  if (yi.has(n)) return qe(yi.get(n), t);
  if (/\d/.test(n)) return qy(e, t);
  if (t === "\\") throw new Error(le`Incomplete escape "\"`);
  if (n === "M") throw new Error(`Unsupported meta "${t}"`);
  if ([...t].length === 2) return qe(t.codePointAt(1), t);
  throw new Error(`Unexpected escape "${t}"`);
}
function Gy(t) {
  return { type: "Alternator", raw: t };
}
function mi(t, e) {
  return { type: "Assertion", kind: t, raw: e };
}
function nc(t) {
  return { type: "Backreference", raw: t };
}
function qe(t, e) {
  return { type: "Character", value: t, raw: e };
}
function zy(t) {
  return { type: "CharacterClassClose", raw: t };
}
function Uy(t) {
  return { type: "CharacterClassHyphen", raw: t };
}
function Hy(t) {
  return { type: "CharacterClassIntersector", raw: t };
}
function gi(t, e) {
  return { type: "CharacterClassOpen", negate: t, raw: e };
}
function ft(t, e, n = {}) {
  return { type: "CharacterSet", kind: t, ...n, raw: e };
}
function rc(t, e, n = {}) {
  return t === "keep" ? { type: "Directive", kind: t, raw: e } : { type: "Directive", kind: t, flags: Mt(n.flags), raw: e };
}
function qy(t, e) {
  return { type: "EscapedNumber", inCharClass: t, raw: e };
}
function Wy(t) {
  return { type: "GroupClose", raw: t };
}
function Tt(t, e, n = {}) {
  return { type: "GroupOpen", kind: t, ...n, raw: e };
}
function Zy(t, e, n, r) {
  return { type: "NamedCallout", kind: t, tag: e, arguments: n, raw: r };
}
function Vy(t, e, n, r) {
  return { type: "Quantifier", kind: t, min: e, max: n, raw: r };
}
function Jy(t) {
  return { type: "Subroutine", raw: t };
}
const Qy = /* @__PURE__ */ new Set(["COUNT", "CMP", "ERROR", "FAIL", "MAX", "MISMATCH", "SKIP", "TOTAL_COUNT"]), yi = /* @__PURE__ */ new Map([["a", 7], ["b", 8], ["e", 27], ["f", 12], ["n", 10], ["r", 13], ["t", 9], ["v", 11]]);
function Yy(t) {
  const e = t[1] === "c" ? t[2] : t[3];
  if (!e || !/[A-Za-z]/.test(e)) throw new Error(`Unsupported control character "${t}"`);
  return qe(Ot(e.toUpperCase()) - 64, t);
}
function Xy(t, e) {
  let { on: n, off: r } = /^\(\?(?<on>[imx]*)(?:-(?<off>[-imx]*))?/.exec(t).groups;
  r ?? (r = "");
  const s = (e.getCurrentModX() || n.includes("x")) && !r.includes("x"), a = bi(n), i = bi(r), o = {};
  if (a && (o.enable = a), i && (o.disable = i), t.endsWith(")")) return e.replaceCurrentModX(s), rc("flags", t, { flags: o });
  if (t.endsWith(":")) return e.pushModX(s), e.numOpenGroups++, Tt("group", t, { ...(a || i) && { flags: o } });
  throw new Error(`Unexpected flag modifier "${t}"`);
}
function Ky(t) {
  const e = /\(\*(?<name>[A-Za-z_]\w*)?(?:\[(?<tag>(?:[A-Za-z_]\w*)?)\])?(?:\{(?<args>[^}]*)\})?\)/.exec(t);
  if (!e) throw new Error(`Incomplete or invalid named callout "${t}"`);
  const { name: n, tag: r, args: s } = e.groups;
  if (!n) throw new Error(`Invalid named callout "${t}"`);
  if (r === "") throw new Error(`Named callout tag with empty value not allowed "${t}"`);
  const a = s ? s.split(",").filter((d) => d !== "").map((d) => /^[+-]?\d+$/.test(d) ? +d : d) : [], [i, o, l] = a, c = Qy.has(n) ? n.toLowerCase() : "custom";
  switch (c) {
    case "fail":
    case "mismatch":
    case "skip":
      if (a.length > 0) throw new Error(`Named callout arguments not allowed "${a}"`);
      break;
    case "error":
      if (a.length > 1) throw new Error(`Named callout allows only one argument "${a}"`);
      if (typeof i == "string") throw new Error(`Named callout argument must be a number "${i}"`);
      break;
    case "max":
      if (!a.length || a.length > 2) throw new Error(`Named callout must have one or two arguments "${a}"`);
      if (typeof i == "string" && !/^[A-Za-z_]\w*$/.test(i)) throw new Error(`Named callout argument one must be a tag or number "${i}"`);
      if (a.length === 2 && (typeof o == "number" || !/^[<>X]$/.test(o))) throw new Error(`Named callout optional argument two must be '<', '>', or 'X' "${o}"`);
      break;
    case "count":
    case "total_count":
      if (a.length > 1) throw new Error(`Named callout allows only one argument "${a}"`);
      if (a.length === 1 && (typeof i == "number" || !/^[<>X]$/.test(i))) throw new Error(`Named callout optional argument must be '<', '>', or 'X' "${i}"`);
      break;
    case "cmp":
      if (a.length !== 3) throw new Error(`Named callout must have three arguments "${a}"`);
      if (typeof i == "string" && !/^[A-Za-z_]\w*$/.test(i)) throw new Error(`Named callout argument one must be a tag or number "${i}"`);
      if (typeof o == "number" || !/^(?:[<>!=]=|[<>])$/.test(o)) throw new Error(`Named callout argument two must be '==', '!=', '>', '<', '>=', or '<=' "${o}"`);
      if (typeof l == "string" && !/^[A-Za-z_]\w*$/.test(l)) throw new Error(`Named callout argument three must be a tag or number "${l}"`);
      break;
    case "custom":
      throw new Error(`Undefined callout name "${n}"`);
    default:
      throw new Error(`Unexpected named callout kind "${c}"`);
  }
  return Zy(c, r ?? null, (s == null ? void 0 : s.split(",")) ?? null, t);
}
function xi(t) {
  let e = null, n, r;
  if (t[0] === "{") {
    const { minStr: s, maxStr: a } = /^\{(?<minStr>\d*)(?:,(?<maxStr>\d*))?/.exec(t).groups, i = 1e5;
    if (+s > i || a && +a > i) throw new Error("Quantifier value unsupported in Oniguruma");
    if (n = +s, r = a === void 0 ? +s : a === "" ? 1 / 0 : +a, n > r && (e = "possessive", [n, r] = [r, n]), t.endsWith("?")) {
      if (e === "possessive") throw new Error('Unsupported possessive interval quantifier chain with "?"');
      e = "lazy";
    } else e || (e = "greedy");
  } else n = t[0] === "+" ? 1 : 0, r = t[0] === "?" ? 1 : 1 / 0, e = t[1] === "+" ? "possessive" : t[1] === "?" ? "lazy" : "greedy";
  return Vy(e, n, r, t);
}
function ex(t) {
  const e = t[1].toLowerCase();
  return ft({ d: "digit", h: "hex", s: "space", w: "word" }[e], t, { negate: t[1] !== e });
}
function tx(t) {
  const { p: e, neg: n, value: r } = /^\\(?<p>[pP])\{(?<neg>\^?)(?<value>[^}]+)/.exec(t).groups;
  return ft("property", t, { value: r, negate: e === "P" && !n || e === "p" && !!n });
}
function bi(t) {
  const e = {};
  return t.includes("i") && (e.ignoreCase = !0), t.includes("m") && (e.dotAll = !0), t.includes("x") && (e.extended = !0), Object.keys(e).length ? e : null;
}
function nx(t) {
  const e = { ignoreCase: !1, dotAll: !1, extended: !1, digitIsAscii: !1, posixIsAscii: !1, spaceIsAscii: !1, wordIsAscii: !1, textSegmentMode: null };
  for (let n = 0; n < t.length; n++) {
    const r = t[n];
    if (!"imxDPSWy".includes(r)) throw new Error(`Invalid flag "${r}"`);
    if (r === "y") {
      if (!/^y{[gw]}/.test(t.slice(n))) throw new Error('Invalid or unspecified flag "y" mode');
      e.textSegmentMode = t[n + 2] === "g" ? "grapheme" : "word", n += 3;
      continue;
    }
    e[{ i: "ignoreCase", m: "dotAll", x: "extended", D: "digitIsAscii", P: "posixIsAscii", S: "spaceIsAscii", W: "wordIsAscii" }[r]] = !0;
  }
  return e;
}
function rx(t) {
  if (new RegExp("^(?:\\\\u(?!\\p{AHex}{4})|\\\\x(?!\\p{AHex}{1,2}|\\{\\p{AHex}{1,8}\\}))", "u").test(t)) throw new Error(`Incomplete or invalid escape "${t}"`);
  const e = t[2] === "{" ? new RegExp("^\\\\x\\{\\s*(?<hex>\\p{AHex}+)", "u").exec(t).groups.hex : t.slice(2);
  return parseInt(e, 16);
}
function sx(t, e) {
  const { raw: n, inCharClass: r } = t, s = n.slice(1);
  if (!r && (s !== "0" && s.length === 1 || s[0] !== "0" && +s <= e)) return [nc(n)];
  const a = [], i = s.match(/^[0-7]+|\d/g);
  for (let o = 0; o < i.length; o++) {
    const l = i[o];
    let c;
    if (o === 0 && l !== "8" && l !== "9") {
      if (c = parseInt(l, 8), c > 127) throw new Error(le`Octal encoded byte above 177 unsupported "${n}"`);
    } else c = Ot(l);
    a.push(qe(c, (o === 0 ? "\\" : "") + l));
  }
  return a;
}
function ax(t) {
  const e = [], n = new RegExp(oa, "gy");
  let r;
  for (; r = n.exec(t); ) {
    const s = r[0];
    if (s[0] === "{") {
      const a = /^\{(?<min>\d+),(?<max>\d+)\}\??$/.exec(s);
      if (a) {
        const { min: i, max: o } = a.groups;
        if (+i > +o && s.endsWith("?")) {
          n.lastIndex--, e.push(xi(s.slice(0, -1)));
          continue;
        }
      }
    }
    e.push(xi(s));
  }
  return e;
}
function sc(t, e) {
  if (!Array.isArray(t.body)) throw new Error("Expected node with body array");
  if (t.body.length !== 1) return !1;
  const n = t.body[0];
  return !e || Object.keys(e).every((r) => e[r] === n[r]);
}
function ix(t) {
  return ox.has(t.type);
}
const ox = /* @__PURE__ */ new Set(["AbsenceFunction", "Backreference", "CapturingGroup", "Character", "CharacterClass", "CharacterSet", "Group", "Quantifier", "Subroutine"]);
function ac(t, e = {}) {
  const n = { flags: "", normalizeUnknownPropertyNames: !1, skipBackrefValidation: !1, skipLookbehindValidation: !1, skipPropertyNameValidation: !1, unicodePropertyMap: null, ...e, rules: { captureGroup: !1, singleline: !1, ...e.rules } }, r = My(t, { flags: n.flags, rules: { captureGroup: n.rules.captureGroup, singleline: n.rules.singleline } }), s = (h, m) => {
    const f = r.tokens[a.nextIndex];
    switch (a.parent = h, a.nextIndex++, f.type) {
      case "Alternator":
        return wt();
      case "Assertion":
        return lx(f);
      case "Backreference":
        return cx(f, a);
      case "Character":
        return kr(f.value, { useLastValid: !!m.isCheckingRangeEnd });
      case "CharacterClassHyphen":
        return ux(f, a, m);
      case "CharacterClassOpen":
        return px(f, a, m);
      case "CharacterSet":
        return dx(f, a);
      case "Directive":
        return xx(f.kind, { flags: f.flags });
      case "GroupOpen":
        return hx(f, a, m);
      case "NamedCallout":
        return wx(f.kind, f.tag, f.arguments);
      case "Quantifier":
        return fx(f, a);
      case "Subroutine":
        return mx(f, a);
      default:
        throw new Error(`Unexpected token type "${f.type}"`);
    }
  }, a = { capturingGroups: [], hasNumberedRef: !1, namedGroupsByName: /* @__PURE__ */ new Map(), nextIndex: 0, normalizeUnknownPropertyNames: n.normalizeUnknownPropertyNames, parent: null, skipBackrefValidation: n.skipBackrefValidation, skipLookbehindValidation: n.skipLookbehindValidation, skipPropertyNameValidation: n.skipPropertyNameValidation, subroutines: [], tokens: r.tokens, unicodePropertyMap: n.unicodePropertyMap, walk: s }, i = vx(bx(r.flags));
  let o = i.body[0];
  for (; a.nextIndex < r.tokens.length; ) {
    const h = s(o, {});
    h.type === "Alternative" ? (i.body.push(h), o = h) : o.body.push(h);
  }
  const { capturingGroups: l, hasNumberedRef: c, namedGroupsByName: d, subroutines: p } = a;
  if (c && d.size && !n.rules.captureGroup) throw new Error("Numbered backref/subroutine not allowed when using named capture");
  for (const { ref: h } of p) if (typeof h == "number") {
    if (h > l.length) throw new Error("Subroutine uses a group number that's not defined");
    h && (l[h - 1].isSubroutined = !0);
  } else if (d.has(h)) {
    if (d.get(h).length > 1) throw new Error(le`Subroutine uses a duplicate group name "\g<${h}>"`);
    d.get(h)[0].isSubroutined = !0;
  } else throw new Error(le`Subroutine uses a group name that's not defined "\g<${h}>"`);
  return i;
}
function lx({ kind: t }) {
  return bs(Mt({ "^": "line_start", $: "line_end", "\\A": "string_start", "\\b": "word_boundary", "\\B": "word_boundary", "\\G": "search_start", "\\y": "text_segment_boundary", "\\Y": "text_segment_boundary", "\\z": "string_end", "\\Z": "string_end_newline" }[t], `Unexpected assertion kind "${t}"`), { negate: t === le`\B` || t === le`\Y` });
}
function cx({ raw: t }, e) {
  const n = /^\\k[<']/.test(t), r = n ? t.slice(3, -1) : t.slice(1), s = (a, i = !1) => {
    const o = e.capturingGroups.length;
    let l = !1;
    if (a > o) if (e.skipBackrefValidation) l = !0;
    else throw new Error(`Not enough capturing groups defined to the left "${t}"`);
    return e.hasNumberedRef = !0, ws(i ? o + 1 - a : a, { orphan: l });
  };
  if (n) {
    const a = /^(?<sign>-?)0*(?<num>[1-9]\d*)$/.exec(r);
    if (a) return s(+a.groups.num, !!a.groups.sign);
    if (/[-+]/.test(r)) throw new Error(`Invalid backref name "${t}"`);
    if (!e.namedGroupsByName.has(r)) throw new Error(`Group name not defined to the left "${t}"`);
    return ws(r);
  }
  return s(+r);
}
function ux(t, e, n) {
  const { tokens: r, walk: s } = e, a = e.parent, i = a.body.at(-1), o = r[e.nextIndex];
  if (!n.isCheckingRangeEnd && i && i.type !== "CharacterClass" && i.type !== "CharacterClassRange" && o && o.type !== "CharacterClassOpen" && o.type !== "CharacterClassClose" && o.type !== "CharacterClassIntersector") {
    const l = s(a, { ...n, isCheckingRangeEnd: !0 });
    if (i.type === "Character" && l.type === "Character") return a.body.pop(), yx(i, l);
    throw new Error("Invalid character class range");
  }
  return kr(Ot("-"));
}
function px({ negate: t }, e, n) {
  const { tokens: r, walk: s } = e, a = [jn()], i = r[e.nextIndex];
  let o = vi(i);
  for (; o.type !== "CharacterClassClose"; ) {
    if (o.type === "CharacterClassIntersector") a.push(jn()), e.nextIndex++;
    else {
      const c = a.at(-1);
      c.body.push(s(c, n));
    }
    o = vi(r[e.nextIndex], i);
  }
  const l = jn({ negate: t });
  return a.length === 1 ? l.body = a[0].body : (l.kind = "intersection", l.body = a.map((c) => c.body.length === 1 ? c.body[0] : c)), e.nextIndex++, l;
}
function dx({ kind: t, negate: e, value: n }, r) {
  const { normalizeUnknownPropertyNames: s, skipPropertyNameValidation: a, unicodePropertyMap: i } = r;
  if (t === "property") {
    const o = vr(n);
    if (ia.has(o) && !(i != null && i.has(o))) t = "posix", n = o;
    else return Et(n, { negate: e, normalizeUnknownPropertyNames: s, skipPropertyNameValidation: a, unicodePropertyMap: i });
  }
  return t === "posix" ? kx(n, { negate: e }) : ks(t, { negate: e });
}
function hx(t, e, n) {
  const { tokens: r, capturingGroups: s, namedGroupsByName: a, skipLookbehindValidation: i, walk: o } = e, l = _x(t), c = l.type === "AbsenceFunction", d = ki(l), p = d && l.negate;
  if (l.type === "CapturingGroup" && (s.push(l), l.name && Oy(a, l.name, []).push(l)), c && n.isInAbsenceFunction) throw new Error("Nested absence function not supported by Oniguruma");
  let h = _i(r[e.nextIndex]);
  for (; h.type !== "GroupClose"; ) {
    if (h.type === "Alternator") l.body.push(wt()), e.nextIndex++;
    else {
      const m = l.body.at(-1), f = o(m, { ...n, isInAbsenceFunction: n.isInAbsenceFunction || c, isInLookbehind: n.isInLookbehind || d, isInNegLookbehind: n.isInNegLookbehind || p });
      if (m.body.push(f), (d || n.isInLookbehind) && !i) {
        const g = "Lookbehind includes a pattern not allowed by Oniguruma";
        if (p || n.isInNegLookbehind) {
          if (wi(f) || f.type === "CapturingGroup") throw new Error(g);
        } else if (wi(f) || ki(f) && f.negate) throw new Error(g);
      }
    }
    h = _i(r[e.nextIndex]);
  }
  return e.nextIndex++, l;
}
function fx({ kind: t, min: e, max: n }, r) {
  const s = r.parent, a = s.body.at(-1);
  if (!a || !ix(a)) throw new Error("Quantifier requires a repeatable token");
  const i = oc(t, e, n, a);
  return s.body.pop(), i;
}
function mx({ raw: t }, e) {
  const { capturingGroups: n, subroutines: r } = e;
  let s = t.slice(3, -1);
  const a = /^(?<sign>[-+]?)0*(?<num>[1-9]\d*)$/.exec(s);
  if (a) {
    const o = +a.groups.num, l = n.length;
    if (e.hasNumberedRef = !0, s = { "": o, "+": l + o, "-": l + 1 - o }[a.groups.sign], s < 1) throw new Error("Invalid subroutine number");
  } else s === "0" && (s = 0);
  const i = lc(s);
  return r.push(i), i;
}
function gx(t, e) {
  return { type: "AbsenceFunction", kind: t, body: dn(e == null ? void 0 : e.body) };
}
function wt(t) {
  return { type: "Alternative", body: cc(t == null ? void 0 : t.body) };
}
function bs(t, e) {
  const n = { type: "Assertion", kind: t };
  return (t === "word_boundary" || t === "text_segment_boundary") && (n.negate = !!(e != null && e.negate)), n;
}
function ws(t, e) {
  const n = !!(e != null && e.orphan);
  return { type: "Backreference", ref: t, ...n && { orphan: n } };
}
function ic(t, e) {
  const n = { name: void 0, isSubroutined: !1, ...e };
  if (n.name !== void 0 && !Sx(n.name)) throw new Error(`Group name "${n.name}" invalid in Oniguruma`);
  return { type: "CapturingGroup", number: t, ...n.name && { name: n.name }, ...n.isSubroutined && { isSubroutined: n.isSubroutined }, body: dn(e == null ? void 0 : e.body) };
}
function kr(t, e) {
  const n = { useLastValid: !1, ...e };
  if (t > 1114111) {
    const r = t.toString(16);
    if (n.useLastValid) t = 1114111;
    else throw t > 1310719 ? new Error(`Invalid code point out of range "\\x{${r}}"`) : new Error(`Invalid code point out of range in JS "\\x{${r}}"`);
  }
  return { type: "Character", value: t };
}
function jn(t) {
  const e = { kind: "union", negate: !1, ...t };
  return { type: "CharacterClass", kind: e.kind, negate: e.negate, body: cc(t == null ? void 0 : t.body) };
}
function yx(t, e) {
  if (e.value < t.value) throw new Error("Character class range out of order");
  return { type: "CharacterClassRange", min: t, max: e };
}
function ks(t, e) {
  const n = !!(e != null && e.negate), r = { type: "CharacterSet", kind: t };
  return (t === "digit" || t === "hex" || t === "newline" || t === "space" || t === "word") && (r.negate = n), (t === "text_segment" || t === "newline" && !n) && (r.variableLength = !0), r;
}
function xx(t, e = {}) {
  if (t === "keep") return { type: "Directive", kind: t };
  if (t === "flags") return { type: "Directive", kind: t, flags: Mt(e.flags) };
  throw new Error(`Unexpected directive kind "${t}"`);
}
function bx(t) {
  return { type: "Flags", ...t };
}
function $e(t) {
  const e = t == null ? void 0 : t.atomic, n = t == null ? void 0 : t.flags;
  if (e && n) throw new Error("Atomic group cannot have flags");
  return { type: "Group", ...e && { atomic: e }, ...n && { flags: n }, body: dn(t == null ? void 0 : t.body) };
}
function dt(t) {
  const e = { behind: !1, negate: !1, ...t };
  return { type: "LookaroundAssertion", kind: e.behind ? "lookbehind" : "lookahead", negate: e.negate, body: dn(t == null ? void 0 : t.body) };
}
function wx(t, e, n) {
  return { type: "NamedCallout", kind: t, tag: e, arguments: n };
}
function kx(t, e) {
  const n = !!(e != null && e.negate);
  if (!ia.has(t)) throw new Error(`Invalid POSIX class "${t}"`);
  return { type: "CharacterSet", kind: "posix", value: t, negate: n };
}
function oc(t, e, n, r) {
  if (e > n) throw new Error("Invalid reversed quantifier range");
  return { type: "Quantifier", kind: t, min: e, max: n, body: r };
}
function vx(t, e) {
  return { type: "Regex", body: dn(e == null ? void 0 : e.body), flags: t };
}
function lc(t) {
  return { type: "Subroutine", ref: t };
}
function Et(t, e) {
  var s;
  const n = { negate: !1, normalizeUnknownPropertyNames: !1, skipPropertyNameValidation: !1, unicodePropertyMap: null, ...e };
  let r = (s = n.unicodePropertyMap) == null ? void 0 : s.get(vr(t));
  if (!r) {
    if (n.normalizeUnknownPropertyNames) r = Cx(t);
    else if (n.unicodePropertyMap && !n.skipPropertyNameValidation) throw new Error(le`Invalid Unicode property "\p{${t}}"`);
  }
  return { type: "CharacterSet", kind: "property", value: r ?? t, negate: n.negate };
}
function _x({ flags: t, kind: e, name: n, negate: r, number: s }) {
  switch (e) {
    case "absence_repeater":
      return gx("repeater");
    case "atomic":
      return $e({ atomic: !0 });
    case "capturing":
      return ic(s, { name: n });
    case "group":
      return $e({ flags: t });
    case "lookahead":
    case "lookbehind":
      return dt({ behind: e === "lookbehind", negate: r });
    default:
      throw new Error(`Unexpected group kind "${e}"`);
  }
}
function dn(t) {
  if (t === void 0) t = [wt()];
  else if (!Array.isArray(t) || !t.length || !t.every((e) => e.type === "Alternative")) throw new Error("Invalid body; expected array of one or more Alternative nodes");
  return t;
}
function cc(t) {
  if (t === void 0) t = [];
  else if (!Array.isArray(t) || !t.every((e) => !!e.type)) throw new Error("Invalid body; expected array of nodes");
  return t;
}
function wi(t) {
  return t.type === "LookaroundAssertion" && t.kind === "lookahead";
}
function ki(t) {
  return t.type === "LookaroundAssertion" && t.kind === "lookbehind";
}
function Sx(t) {
  return /^[\p{Alpha}\p{Pc}][^)]*$/u.test(t);
}
function Cx(t) {
  return t.trim().replace(/[- _]+/g, "_").replace(/[A-Z][a-z]+(?=[A-Z])/g, "$&_").replace(/[A-Za-z]+/g, (e) => e[0].toUpperCase() + e.slice(1).toLowerCase());
}
function vr(t) {
  return t.replace(/[- _]+/g, "").toLowerCase();
}
function vi(t, e) {
  const n = e;
  return Mt(t, `Unclosed character class${(n == null ? void 0 : n.type) === "Character" && n.value === 93 && n.raw === "]" ? ' (started with "]")' : ""}`);
}
function _i(t) {
  return Mt(t, "Unclosed group");
}
function Qt(t, e, n = null) {
  function r(a, i) {
    for (let o = 0; o < a.length; o++) {
      const l = s(a[o], i, o, a);
      o = Math.max(-1, o + l);
    }
  }
  function s(a, i = null, o = null, l = null) {
    var v, w;
    let c = 0, d = !1;
    const p = { node: a, parent: i, key: o, container: l, root: t, remove() {
      _n(l).splice(Math.max(0, Nt(o) + c), 1), c--, d = !0;
    }, removeAllNextSiblings() {
      return _n(l).splice(Nt(o) + 1);
    }, removeAllPrevSiblings() {
      const x = Nt(o) + c;
      return c -= x, _n(l).splice(0, Math.max(0, x));
    }, replaceWith(x, k = {}) {
      const S = !!k.traverse;
      l ? l[Math.max(0, Nt(o) + c)] = x : Mt(i, "Can't replace root node")[o] = x, S && s(x, i, o, l), d = !0;
    }, replaceWithMultiple(x, k = {}) {
      const S = !!k.traverse;
      if (_n(l).splice(Math.max(0, Nt(o) + c), 1, ...x), c += x.length - 1, S) {
        let N = 0;
        for (let C = 0; C < x.length; C++) N += s(x[C], i, Nt(o) + C + N, l);
      }
      d = !0;
    }, skip() {
      d = !0;
    } }, { type: h } = a, m = e["*"], f = e[h], g = typeof m == "function" ? m : m == null ? void 0 : m.enter, b = typeof f == "function" ? f : f == null ? void 0 : f.enter;
    if (g == null || g(p, n), b == null || b(p, n), !d) switch (h) {
      case "AbsenceFunction":
      case "Alternative":
      case "CapturingGroup":
      case "CharacterClass":
      case "Group":
      case "LookaroundAssertion":
        r(a.body, a);
        break;
      case "Assertion":
      case "Backreference":
      case "Character":
      case "CharacterSet":
      case "Directive":
      case "Flags":
      case "NamedCallout":
      case "Subroutine":
        break;
      case "CharacterClassRange":
        s(a.min, a, "min"), s(a.max, a, "max");
        break;
      case "Quantifier":
        s(a.body, a, "body");
        break;
      case "Regex":
        r(a.body, a), s(a.flags, a, "flags");
        break;
      default:
        throw new Error(`Unexpected node type "${h}"`);
    }
    return (v = f == null ? void 0 : f.exit) == null || v.call(f, p, n), (w = m == null ? void 0 : m.exit) == null || w.call(m, p, n), c;
  }
  return s(t), t;
}
function _n(t) {
  if (!Array.isArray(t)) throw new Error("Container expected");
  return t;
}
function Nt(t) {
  if (typeof t != "number") throw new Error("Numeric key expected");
  return t;
}
const Nx = String.raw`\(\?(?:[:=!>A-Za-z\-]|<[=!]|\(DEFINE\))`;
function Ax(t, e) {
  for (let n = 0; n < t.length; n++)
    t[n] >= e && t[n]++;
}
function Ix(t, e, n, r) {
  return t.slice(0, e) + r + t.slice(e + n.length);
}
const Ne = Object.freeze({
  DEFAULT: "DEFAULT",
  CHAR_CLASS: "CHAR_CLASS"
});
function la(t, e, n, r) {
  const s = new RegExp(String.raw`${e}|(?<$skip>\[\^?|\\?.)`, "gsu"), a = [!1];
  let i = 0, o = "";
  for (const l of t.matchAll(s)) {
    const { 0: c, groups: { $skip: d } } = l;
    if (!d && (!r || r === Ne.DEFAULT == !i)) {
      n instanceof Function ? o += n(l, {
        context: i ? Ne.CHAR_CLASS : Ne.DEFAULT,
        negated: a[a.length - 1]
      }) : o += n;
      continue;
    }
    c[0] === "[" ? (i++, a.push(c[1] === "^")) : c === "]" && i && (i--, a.pop()), o += c;
  }
  return o;
}
function uc(t, e, n, r) {
  la(t, e, n, r);
}
function Tx(t, e, n = 0, r) {
  if (!new RegExp(e, "su").test(t))
    return null;
  const s = new RegExp(`${e}|(?<$skip>\\\\?.)`, "gsu");
  s.lastIndex = n;
  let a = 0, i;
  for (; i = s.exec(t); ) {
    const { 0: o, groups: { $skip: l } } = i;
    if (!l && (!r || r === Ne.DEFAULT == !a))
      return i;
    o === "[" ? a++ : o === "]" && a && a--, s.lastIndex == i.index && s.lastIndex++;
  }
  return null;
}
function Sn(t, e, n) {
  return !!Tx(t, e, 0, n);
}
function Ex(t, e) {
  const n = /\\?./gsu;
  n.lastIndex = e;
  let r = t.length, s = 0, a = 1, i;
  for (; i = n.exec(t); ) {
    const [o] = i;
    if (o === "[")
      s++;
    else if (s)
      o === "]" && s--;
    else if (o === "(")
      a++;
    else if (o === ")" && (a--, !a)) {
      r = i.index;
      break;
    }
  }
  return t.slice(e, r);
}
const Si = new RegExp(String.raw`(?<noncapturingStart>${Nx})|(?<capturingStart>\((?:\?<[^>]+>)?)|\\?.`, "gsu");
function jx(t, e) {
  const n = (e == null ? void 0 : e.hiddenCaptures) ?? [];
  let r = (e == null ? void 0 : e.captureTransfers) ?? /* @__PURE__ */ new Map();
  if (!/\(\?>/.test(t))
    return {
      pattern: t,
      captureTransfers: r,
      hiddenCaptures: n
    };
  const s = "(?>", a = "(?:(?=(", i = [0], o = [];
  let l = 0, c = 0, d = NaN, p;
  do {
    p = !1;
    let h = 0, m = 0, f = !1, g;
    for (Si.lastIndex = Number.isNaN(d) ? 0 : d + a.length; g = Si.exec(t); ) {
      const { 0: b, index: v, groups: { capturingStart: w, noncapturingStart: x } } = g;
      if (b === "[")
        h++;
      else if (h)
        b === "]" && h--;
      else if (b === s && !f)
        d = v, f = !0;
      else if (f && x)
        m++;
      else if (w)
        f ? m++ : (l++, i.push(l + c));
      else if (b === ")" && f) {
        if (!m) {
          c++;
          const k = l + c;
          if (t = `${t.slice(0, d)}${a}${t.slice(d + s.length, v)}))<$$${k}>)${t.slice(v + 1)}`, p = !0, o.push(k), Ax(n, k), r.size) {
            const S = /* @__PURE__ */ new Map();
            r.forEach((N, C) => {
              S.set(
                C >= k ? C + 1 : C,
                N.map((E) => E >= k ? E + 1 : E)
              );
            }), r = S;
          }
          break;
        }
        m--;
      }
    }
  } while (p);
  return n.push(...o), t = la(
    t,
    String.raw`\\(?<backrefNum>[1-9]\d*)|<\$\$(?<wrappedBackrefNum>\d+)>`,
    ({ 0: h, groups: { backrefNum: m, wrappedBackrefNum: f } }) => {
      if (m) {
        const g = +m;
        if (g > i.length - 1)
          throw new Error(`Backref "${h}" greater than number of captures`);
        return `\\${i[g]}`;
      }
      return `\\${f}`;
    },
    Ne.DEFAULT
  ), {
    pattern: t,
    captureTransfers: r,
    hiddenCaptures: n
  };
}
const pc = String.raw`(?:[?*+]|\{\d+(?:,\d*)?\})`, zr = new RegExp(String.raw`
\\(?: \d+
  | c[A-Za-z]
  | [gk]<[^>]+>
  | [pPu]\{[^\}]+\}
  | u[A-Fa-f\d]{4}
  | x[A-Fa-f\d]{2}
  )
| \((?: \? (?: [:=!>]
  | <(?:[=!]|[^>]+>)
  | [A-Za-z\-]+:
  | \(DEFINE\)
  ))?
| (?<qBase>${pc})(?<qMod>[?+]?)(?<invalidQ>[?*+\{]?)
| \\?.
`.replace(/\s+/g, ""), "gsu");
function Rx(t) {
  if (!new RegExp(`${pc}\\+`).test(t))
    return {
      pattern: t
    };
  const e = [];
  let n = null, r = null, s = "", a = 0, i;
  for (zr.lastIndex = 0; i = zr.exec(t); ) {
    const { 0: o, index: l, groups: { qBase: c, qMod: d, invalidQ: p } } = i;
    if (o === "[")
      a || (r = l), a++;
    else if (o === "]")
      a ? a-- : r = null;
    else if (!a)
      if (d === "+" && s && !s.startsWith("(")) {
        if (p)
          throw new Error(`Invalid quantifier "${o}"`);
        let h = -1;
        if (/^\{\d+\}$/.test(c))
          t = Ix(t, l + c.length, d, "");
        else {
          if (s === ")" || s === "]") {
            const m = s === ")" ? n : r;
            if (m === null)
              throw new Error(`Invalid unmatched "${s}"`);
            t = `${t.slice(0, m)}(?>${t.slice(m, l)}${c})${t.slice(l + o.length)}`;
          } else
            t = `${t.slice(0, l - s.length)}(?>${s}${c})${t.slice(l + o.length)}`;
          h += 4;
        }
        zr.lastIndex += h;
      } else o[0] === "(" ? e.push(l) : o === ")" && (n = e.length ? e.pop() : null);
    s = o;
  }
  return {
    pattern: t
  };
}
const Ce = String.raw, Px = Ce`\\g<(?<gRNameOrNum>[^>&]+)&R=(?<gRDepth>[^>]+)>`, vs = Ce`\(\?R=(?<rDepth>[^\)]+)\)|${Px}`, _r = Ce`\(\?<(?![=!])(?<captureName>[^>]+)>`, dc = Ce`${_r}|(?<unnamed>\()(?!\?)`, lt = new RegExp(Ce`${_r}|${vs}|\(\?|\\?.`, "gsu"), Ur = "Cannot use multiple overlapping recursions";
function Lx(t, e) {
  const { hiddenCaptures: n, mode: r } = {
    hiddenCaptures: [],
    mode: "plugin",
    ...e
  };
  let s = (e == null ? void 0 : e.captureTransfers) ?? /* @__PURE__ */ new Map();
  if (!new RegExp(vs, "su").test(t))
    return {
      pattern: t,
      captureTransfers: s,
      hiddenCaptures: n
    };
  if (r === "plugin" && Sn(t, Ce`\(\?\(DEFINE\)`, Ne.DEFAULT))
    throw new Error("DEFINE groups cannot be used with recursion");
  const a = [], i = Sn(t, Ce`\\[1-9]`, Ne.DEFAULT), o = /* @__PURE__ */ new Map(), l = [];
  let c = !1, d = 0, p = 0, h;
  for (lt.lastIndex = 0; h = lt.exec(t); ) {
    const { 0: m, groups: { captureName: f, rDepth: g, gRNameOrNum: b, gRDepth: v } } = h;
    if (m === "[")
      d++;
    else if (d)
      m === "]" && d--;
    else if (g) {
      if (Ci(g), c)
        throw new Error(Ur);
      if (i)
        throw new Error(
          // When used in `external` mode by transpilers other than Regex+, backrefs might have
          // gone through conversion from named to numbered, so avoid a misleading error
          `${r === "external" ? "Backrefs" : "Numbered backrefs"} cannot be used with global recursion`
        );
      const w = t.slice(0, h.index), x = t.slice(lt.lastIndex);
      if (Sn(x, vs, Ne.DEFAULT))
        throw new Error(Ur);
      const k = +g - 1;
      t = Ni(
        w,
        x,
        k,
        !1,
        n,
        a,
        p
      ), s = Ii(
        s,
        w,
        k,
        a.length,
        0,
        p
      );
      break;
    } else if (b) {
      Ci(v);
      let w = !1;
      for (const j of l)
        if (j.name === b || j.num === +b) {
          if (w = !0, j.hasRecursedWithin)
            throw new Error(Ur);
          break;
        }
      if (!w)
        throw new Error(Ce`Recursive \g cannot be used outside the referenced group "${r === "external" ? b : Ce`\g<${b}&R=${v}>`}"`);
      const x = o.get(b), k = Ex(t, x);
      if (i && Sn(k, Ce`${_r}|\((?!\?)`, Ne.DEFAULT))
        throw new Error(
          // When used in `external` mode by transpilers other than Regex+, backrefs might have
          // gone through conversion from named to numbered, so avoid a misleading error
          `${r === "external" ? "Backrefs" : "Numbered backrefs"} cannot be used with recursion of capturing groups`
        );
      const S = t.slice(x, h.index), N = k.slice(S.length + m.length), C = a.length, E = +v - 1, O = Ni(
        S,
        N,
        E,
        !0,
        n,
        a,
        p
      );
      s = Ii(
        s,
        S,
        E,
        a.length - C,
        C,
        p
      );
      const R = t.slice(0, x), I = t.slice(x + k.length);
      t = `${R}${O}${I}`, lt.lastIndex += O.length - m.length - S.length - N.length, l.forEach((j) => j.hasRecursedWithin = !0), c = !0;
    } else if (f)
      p++, o.set(String(p), lt.lastIndex), o.set(f, lt.lastIndex), l.push({
        num: p,
        name: f
      });
    else if (m[0] === "(") {
      const w = m === "(";
      w && (p++, o.set(String(p), lt.lastIndex)), l.push(w ? { num: p } : {});
    } else m === ")" && l.pop();
  }
  return n.push(...a), {
    pattern: t,
    captureTransfers: s,
    hiddenCaptures: n
  };
}
function Ci(t) {
  const e = `Max depth must be integer between 2 and 100; used ${t}`;
  if (!/^[1-9]\d*$/.test(t))
    throw new Error(e);
  if (t = +t, t < 2 || t > 100)
    throw new Error(e);
}
function Ni(t, e, n, r, s, a, i) {
  const o = /* @__PURE__ */ new Set();
  r && uc(t + e, _r, ({ groups: { captureName: c } }) => {
    o.add(c);
  }, Ne.DEFAULT);
  const l = [
    n,
    r ? o : null,
    s,
    a,
    i
  ];
  return `${t}${Ai(`(?:${t}`, "forward", ...l)}(?:)${Ai(`${e})`, "backward", ...l)}${e}`;
}
function Ai(t, e, n, r, s, a, i) {
  const l = (d) => e === "forward" ? d + 2 : n - d + 2 - 1;
  let c = "";
  for (let d = 0; d < n; d++) {
    const p = l(d);
    c += la(
      t,
      Ce`${dc}|\\k<(?<backref>[^>]+)>`,
      ({ 0: h, groups: { captureName: m, unnamed: f, backref: g } }) => {
        if (g && r && !r.has(g))
          return h;
        const b = `_$${p}`;
        if (f || m) {
          const v = i + a.length + 1;
          return a.push(v), $x(s, v), f ? h : `(?<${m}${b}>`;
        }
        return Ce`\k<${g}${b}>`;
      },
      Ne.DEFAULT
    );
  }
  return c;
}
function $x(t, e) {
  for (let n = 0; n < t.length; n++)
    t[n] >= e && t[n]++;
}
function Ii(t, e, n, r, s, a) {
  if (t.size && r) {
    let i = 0;
    uc(e, dc, () => i++, Ne.DEFAULT);
    const o = a - i + s, l = /* @__PURE__ */ new Map();
    return t.forEach((c, d) => {
      const p = (r - i * n) / n, h = i * n, m = d > o + i ? d + r : d, f = [];
      for (const g of c)
        if (g <= o)
          f.push(g);
        else if (g > o + i + p)
          f.push(g + r);
        else if (g <= o + i)
          for (let b = 0; b <= n; b++)
            f.push(g + i * b);
        else
          for (let b = 0; b <= n; b++)
            f.push(g + h + p * b);
      l.set(m, f);
    }), l;
  }
  return t;
}
var se = String.fromCodePoint, B = String.raw, Oe = {}, Sr = globalThis.RegExp;
Oe.flagGroups = (() => {
  try {
    new Sr("(?i:)");
  } catch {
    return !1;
  }
  return !0;
})();
Oe.unicodeSets = (() => {
  try {
    new Sr("[[]]", "v");
  } catch {
    return !1;
  }
  return !0;
})();
Oe.bugFlagVLiteralHyphenIsRange = Oe.unicodeSets ? (() => {
  try {
    new Sr(B`[\d\-a]`, "v");
  } catch {
    return !0;
  }
  return !1;
})() : !1;
Oe.bugNestedClassIgnoresNegation = Oe.unicodeSets && new Sr("[[^a]]", "v").test("a");
function rr(t, { enable: e, disable: n }) {
  return {
    dotAll: !(n != null && n.dotAll) && !!(e != null && e.dotAll || t.dotAll),
    ignoreCase: !(n != null && n.ignoreCase) && !!(e != null && e.ignoreCase || t.ignoreCase)
  };
}
function sn(t, e, n) {
  return t.has(e) || t.set(e, n), t.get(e);
}
function _s(t, e) {
  return Ti[t] >= Ti[e];
}
function Ox(t, e) {
  if (t == null)
    throw new Error(e ?? "Value expected");
  return t;
}
var Ti = {
  ES2025: 2025,
  ES2024: 2024,
  ES2018: 2018
}, Mx = (
  /** @type {const} */
  {
    auto: "auto",
    ES2025: "ES2025",
    ES2024: "ES2024",
    ES2018: "ES2018"
  }
);
function hc(t = {}) {
  if ({}.toString.call(t) !== "[object Object]")
    throw new Error("Unexpected options");
  if (t.target !== void 0 && !Mx[t.target])
    throw new Error(`Unexpected target "${t.target}"`);
  const e = {
    // Sets the level of emulation rigor/strictness.
    accuracy: "default",
    // Disables advanced emulation that relies on returning a `RegExp` subclass, resulting in
    // certain patterns not being emulatable.
    avoidSubclass: !1,
    // Oniguruma flags; a string with `i`, `m`, `x`, `D`, `S`, `W`, `y{g}` in any order (all
    // optional). Oniguruma's `m` is equivalent to JavaScript's `s` (`dotAll`).
    flags: "",
    // Include JavaScript flag `g` (`global`) in the result.
    global: !1,
    // Include JavaScript flag `d` (`hasIndices`) in the result.
    hasIndices: !1,
    // Delay regex construction until first use if the transpiled pattern is at least this length.
    lazyCompileLength: 1 / 0,
    // JavaScript version used for generated regexes. Using `auto` detects the best value based on
    // your environment. Later targets allow faster processing, simpler generated source, and
    // support for additional features.
    target: "auto",
    // Disables minifications that simplify the pattern without changing the meaning.
    verbose: !1,
    ...t,
    // Advanced options that override standard behavior, error checking, and flags when enabled.
    rules: {
      // Useful with TextMate grammars that merge backreferences across patterns.
      allowOrphanBackrefs: !1,
      // Use ASCII `\b` and `\B`, which increases search performance of generated regexes.
      asciiWordBoundaries: !1,
      // Allow unnamed captures and numbered calls (backreferences and subroutines) when using
      // named capture. This is Oniguruma option `ONIG_OPTION_CAPTURE_GROUP`; on by default in
      // `vscode-oniguruma`.
      captureGroup: !1,
      // Change the recursion depth limit from Oniguruma's `20` to an integer `2`–`20`.
      recursionLimit: 20,
      // `^` as `\A`; `$` as`\Z`. Improves search performance of generated regexes without changing
      // the meaning if searching line by line. This is Oniguruma option `ONIG_OPTION_SINGLELINE`.
      singleline: !1,
      ...t.rules
    }
  };
  return e.target === "auto" && (e.target = Oe.flagGroups ? "ES2025" : Oe.unicodeSets ? "ES2024" : "ES2018"), e;
}
var Dx = "[	-\r ]", Bx = /* @__PURE__ */ new Set([
  se(304),
  // İ
  se(305)
  // ı
]), Fe = B`[\p{L}\p{M}\p{N}\p{Pc}]`;
function fc(t) {
  if (Bx.has(t))
    return [t];
  const e = /* @__PURE__ */ new Set(), n = t.toLowerCase(), r = n.toUpperCase(), s = zx.get(n), a = Fx.get(n), i = Gx.get(n);
  return [...r].length === 1 && e.add(r), i && e.add(i), s && e.add(s), e.add(n), a && e.add(a), [...e];
}
var ca = /* @__PURE__ */ new Map(
  `C Other
Cc Control cntrl
Cf Format
Cn Unassigned
Co Private_Use
Cs Surrogate
L Letter
LC Cased_Letter
Ll Lowercase_Letter
Lm Modifier_Letter
Lo Other_Letter
Lt Titlecase_Letter
Lu Uppercase_Letter
M Mark Combining_Mark
Mc Spacing_Mark
Me Enclosing_Mark
Mn Nonspacing_Mark
N Number
Nd Decimal_Number digit
Nl Letter_Number
No Other_Number
P Punctuation punct
Pc Connector_Punctuation
Pd Dash_Punctuation
Pe Close_Punctuation
Pf Final_Punctuation
Pi Initial_Punctuation
Po Other_Punctuation
Ps Open_Punctuation
S Symbol
Sc Currency_Symbol
Sk Modifier_Symbol
Sm Math_Symbol
So Other_Symbol
Z Separator
Zl Line_Separator
Zp Paragraph_Separator
Zs Space_Separator
ASCII
ASCII_Hex_Digit AHex
Alphabetic Alpha
Any
Assigned
Bidi_Control Bidi_C
Bidi_Mirrored Bidi_M
Case_Ignorable CI
Cased
Changes_When_Casefolded CWCF
Changes_When_Casemapped CWCM
Changes_When_Lowercased CWL
Changes_When_NFKC_Casefolded CWKCF
Changes_When_Titlecased CWT
Changes_When_Uppercased CWU
Dash
Default_Ignorable_Code_Point DI
Deprecated Dep
Diacritic Dia
Emoji
Emoji_Component EComp
Emoji_Modifier EMod
Emoji_Modifier_Base EBase
Emoji_Presentation EPres
Extended_Pictographic ExtPict
Extender Ext
Grapheme_Base Gr_Base
Grapheme_Extend Gr_Ext
Hex_Digit Hex
IDS_Binary_Operator IDSB
IDS_Trinary_Operator IDST
ID_Continue IDC
ID_Start IDS
Ideographic Ideo
Join_Control Join_C
Logical_Order_Exception LOE
Lowercase Lower
Math
Noncharacter_Code_Point NChar
Pattern_Syntax Pat_Syn
Pattern_White_Space Pat_WS
Quotation_Mark QMark
Radical
Regional_Indicator RI
Sentence_Terminal STerm
Soft_Dotted SD
Terminal_Punctuation Term
Unified_Ideograph UIdeo
Uppercase Upper
Variation_Selector VS
White_Space space
XID_Continue XIDC
XID_Start XIDS`.split(/\s/).map((t) => [vr(t), t])
), Fx = /* @__PURE__ */ new Map([
  ["s", se(383)],
  // s, ſ
  [se(383), "s"]
  // ſ, s
]), Gx = /* @__PURE__ */ new Map([
  [se(223), se(7838)],
  // ß, ẞ
  [se(107), se(8490)],
  // k, K (Kelvin)
  [se(229), se(8491)],
  // å, Å (Angstrom)
  [se(969), se(8486)]
  // ω, Ω (Ohm)
]), zx = new Map([
  Qe(453),
  Qe(456),
  Qe(459),
  Qe(498),
  ...Hr(8072, 8079),
  ...Hr(8088, 8095),
  ...Hr(8104, 8111),
  Qe(8124),
  Qe(8140),
  Qe(8188)
]), Ux = /* @__PURE__ */ new Map([
  ["alnum", B`[\p{Alpha}\p{Nd}]`],
  ["alpha", B`\p{Alpha}`],
  ["ascii", B`\p{ASCII}`],
  ["blank", B`[\p{Zs}\t]`],
  ["cntrl", B`\p{Cc}`],
  ["digit", B`\p{Nd}`],
  ["graph", B`[\P{space}&&\P{Cc}&&\P{Cn}&&\P{Cs}]`],
  ["lower", B`\p{Lower}`],
  ["print", B`[[\P{space}&&\P{Cc}&&\P{Cn}&&\P{Cs}]\p{Zs}]`],
  ["punct", B`[\p{P}\p{S}]`],
  // Updated value from Onig 6.9.9; changed from Unicode `\p{punct}`
  ["space", B`\p{space}`],
  ["upper", B`\p{Upper}`],
  ["word", B`[\p{Alpha}\p{M}\p{Nd}\p{Pc}]`],
  ["xdigit", B`\p{AHex}`]
]);
function Hx(t, e) {
  const n = [];
  for (let r = t; r <= e; r++)
    n.push(r);
  return n;
}
function Qe(t) {
  const e = se(t);
  return [e.toLowerCase(), e];
}
function Hr(t, e) {
  return Hx(t, e).map((n) => Qe(n));
}
var mc = /* @__PURE__ */ new Set([
  "Lower",
  "Lowercase",
  "Upper",
  "Uppercase",
  "Ll",
  "Lowercase_Letter",
  "Lt",
  "Titlecase_Letter",
  "Lu",
  "Uppercase_Letter"
  // The `Changes_When_*` properties (and their aliases) could be included, but they're very rare.
  // Some other properties include a handful of chars with specific cases only, but these chars are
  // generally extreme edge cases and using such properties case insensitively generally produces
  // undesired behavior anyway
]);
function qx(t, e) {
  const n = {
    // A couple edge cases exist where options `accuracy` and `bestEffortTarget` are used:
    // - `CharacterSet` kind `text_segment` (`\X`): An exact representation would require heavy
    //   Unicode data; a best-effort approximation requires knowing the target.
    // - `CharacterSet` kind `posix` with values `graph` and `print`: Their complex Unicode
    //   representations would be hard to change to ASCII versions after the fact in the generator
    //   based on `target`/`accuracy`, so produce the appropriate structure here.
    accuracy: "default",
    asciiWordBoundaries: !1,
    avoidSubclass: !1,
    bestEffortTarget: "ES2025",
    ...e
  };
  gc(t);
  const r = {
    accuracy: n.accuracy,
    asciiWordBoundaries: n.asciiWordBoundaries,
    avoidSubclass: n.avoidSubclass,
    flagDirectivesByAlt: /* @__PURE__ */ new Map(),
    jsGroupNameMap: /* @__PURE__ */ new Map(),
    minTargetEs2024: _s(n.bestEffortTarget, "ES2024"),
    passedLookbehind: !1,
    strategy: null,
    // Subroutines can appear before the groups they ref, so collect reffed nodes for a second pass 
    subroutineRefMap: /* @__PURE__ */ new Map(),
    supportedGNodes: /* @__PURE__ */ new Set(),
    digitIsAscii: t.flags.digitIsAscii,
    spaceIsAscii: t.flags.spaceIsAscii,
    wordIsAscii: t.flags.wordIsAscii
  };
  Qt(t, Wx, r);
  const s = {
    dotAll: t.flags.dotAll,
    ignoreCase: t.flags.ignoreCase
  }, a = {
    currentFlags: s,
    prevFlags: null,
    globalFlags: s,
    groupOriginByCopy: /* @__PURE__ */ new Map(),
    groupsByName: /* @__PURE__ */ new Map(),
    multiplexCapturesToLeftByRef: /* @__PURE__ */ new Map(),
    openRefs: /* @__PURE__ */ new Map(),
    reffedNodesByReferencer: /* @__PURE__ */ new Map(),
    subroutineRefMap: r.subroutineRefMap
  };
  Qt(t, Zx, a);
  const i = {
    groupsByName: a.groupsByName,
    highestOrphanBackref: 0,
    numCapturesToLeft: 0,
    reffedNodesByReferencer: a.reffedNodesByReferencer
  };
  return Qt(t, Vx, i), t._originMap = a.groupOriginByCopy, t._strategy = r.strategy, t;
}
var Wx = {
  AbsenceFunction({ node: t, parent: e, replaceWith: n }) {
    const { body: r, kind: s } = t;
    if (s === "repeater") {
      const a = $e();
      a.body[0].body.push(
        // Insert own alts as `body`
        dt({ negate: !0, body: r }),
        Et("Any")
      );
      const i = $e();
      i.body[0].body.push(
        oc("greedy", 0, 1 / 0, a)
      ), n(ne(i, e), { traverse: !0 });
    } else
      throw new Error('Unsupported absence function "(?~|"');
  },
  Alternative: {
    enter({ node: t, parent: e, key: n }, { flagDirectivesByAlt: r }) {
      const s = t.body.filter((a) => a.kind === "flags");
      for (let a = n + 1; a < e.body.length; a++) {
        const i = e.body[a];
        sn(r, i, []).push(...s);
      }
    },
    exit({ node: t }, { flagDirectivesByAlt: e }) {
      var n;
      if ((n = e.get(t)) != null && n.length) {
        const r = xc(e.get(t));
        if (r) {
          const s = $e({ flags: r });
          s.body[0].body = t.body, t.body = [ne(s, t)];
        }
      }
    }
  },
  Assertion({ node: t, parent: e, key: n, container: r, root: s, remove: a, replaceWith: i }, o) {
    const { kind: l, negate: c } = t, { asciiWordBoundaries: d, avoidSubclass: p, supportedGNodes: h, wordIsAscii: m } = o;
    if (l === "text_segment_boundary")
      throw new Error(`Unsupported text segment boundary "\\${c ? "Y" : "y"}"`);
    if (l === "line_end")
      i(ne(dt({ body: [
        wt({ body: [bs("string_end")] }),
        wt({ body: [kr(10)] })
        // `\n`
      ] }), e));
    else if (l === "line_start")
      i(ne(Ge(B`(?<=\A|\n(?!\z))`, { skipLookbehindValidation: !0 }), e));
    else if (l === "search_start")
      if (h.has(t))
        s.flags.sticky = !0, a();
      else {
        const f = r[n - 1];
        if (f && eb(f))
          i(ne(dt({ negate: !0 }), e));
        else {
          if (p)
            throw new Error(B`Uses "\G" in a way that requires a subclass`);
          i(Ye(bs("string_start"), e)), o.strategy = "clip_search";
        }
      }
    else if (!(l === "string_end" || l === "string_start")) if (l === "string_end_newline")
      i(ne(Ge(B`(?=\n?\z)`), e));
    else if (l === "word_boundary") {
      if (!m && !d) {
        const f = `(?:(?<=${Fe})(?!${Fe})|(?<!${Fe})(?=${Fe}))`, g = `(?:(?<=${Fe})(?=${Fe})|(?<!${Fe})(?!${Fe}))`;
        i(ne(Ge(c ? g : f), e));
      }
    } else
      throw new Error(`Unexpected assertion kind "${l}"`);
  },
  Backreference({ node: t }, { jsGroupNameMap: e }) {
    let { ref: n } = t;
    typeof n == "string" && !Wr(n) && (n = qr(n, e), t.ref = n);
  },
  CapturingGroup({ node: t }, { jsGroupNameMap: e, subroutineRefMap: n }) {
    let { name: r } = t;
    r && !Wr(r) && (r = qr(r, e), t.name = r), n.set(t.number, t), r && n.set(r, t);
  },
  CharacterClassRange({ node: t, parent: e, replaceWith: n }) {
    if (e.kind === "intersection") {
      const r = jn({ body: [t] });
      n(ne(r, e), { traverse: !0 });
    }
  },
  CharacterSet({ node: t, parent: e, replaceWith: n }, { accuracy: r, minTargetEs2024: s, digitIsAscii: a, spaceIsAscii: i, wordIsAscii: o }) {
    const { kind: l, negate: c, value: d } = t;
    if (a && (l === "digit" || d === "digit")) {
      n(Ye(ks("digit", { negate: c }), e));
      return;
    }
    if (i && (l === "space" || d === "space")) {
      n(ne(Zr(Ge(Dx), c), e));
      return;
    }
    if (o && (l === "word" || d === "word")) {
      n(Ye(ks("word", { negate: c }), e));
      return;
    }
    if (l === "any")
      n(Ye(Et("Any"), e));
    else if (l === "digit")
      n(Ye(Et("Nd", { negate: c }), e));
    else if (l !== "dot") if (l === "text_segment") {
      if (r === "strict")
        throw new Error(B`Use of "\X" requires non-strict accuracy`);
      const p = "\\p{Emoji}(?:\\p{EMod}|\\uFE0F\\u20E3?|[\\x{E0020}-\\x{E007E}]+\\x{E007F})?", h = B`\p{RI}{2}|${p}(?:\u200D${p})*`;
      n(ne(Ge(
        // Close approximation of an extended grapheme cluster; see <unicode.org/reports/tr29/>
        B`(?>\r\n|${s ? B`\p{RGI_Emoji}` : h}|\P{M}\p{M}*)`,
        // Allow JS property `RGI_Emoji` through
        { skipPropertyNameValidation: !0 }
      ), e));
    } else if (l === "hex")
      n(Ye(Et("AHex", { negate: c }), e));
    else if (l === "newline")
      n(ne(Ge(c ? `[^
]` : `(?>\r
?|[
\v\f\u2028\u2029])`), e));
    else if (l === "posix")
      if (!s && (d === "graph" || d === "print")) {
        if (r === "strict")
          throw new Error(`POSIX class "${d}" requires min target ES2024 or non-strict accuracy`);
        let p = {
          graph: "!-~",
          print: " -~"
        }[d];
        c && (p = `\0-${se(p.codePointAt(0) - 1)}${se(p.codePointAt(2) + 1)}-􏿿`), n(ne(Ge(`[${p}]`), e));
      } else
        n(ne(Zr(Ge(Ux.get(d)), c), e));
    else if (l === "property")
      ca.has(vr(d)) || (t.key = "sc");
    else if (l === "space")
      n(Ye(Et("space", { negate: c }), e));
    else if (l === "word")
      n(ne(Zr(Ge(Fe), c), e));
    else
      throw new Error(`Unexpected character set kind "${l}"`);
  },
  Directive({ node: t, parent: e, root: n, remove: r, replaceWith: s, removeAllPrevSiblings: a, removeAllNextSiblings: i }) {
    const { kind: o, flags: l } = t;
    if (o === "flags")
      if (!l.enable && !l.disable)
        r();
      else {
        const c = $e({ flags: l });
        c.body[0].body = i(), s(ne(c, e), { traverse: !0 });
      }
    else if (o === "keep") {
      const c = n.body[0], p = n.body.length === 1 && // Not emulatable if within a `CapturingGroup`
      sc(c, { type: "Group" }) && c.body[0].body.length === 1 ? c.body[0] : n;
      if (e.parent !== p || p.body.length > 1)
        throw new Error(B`Uses "\K" in a way that's unsupported`);
      const h = dt({ behind: !0 });
      h.body[0].body = a(), s(ne(h, e));
    } else
      throw new Error(`Unexpected directive kind "${o}"`);
  },
  Flags({ node: t, parent: e }) {
    if (t.posixIsAscii)
      throw new Error('Unsupported flag "P"');
    if (t.textSegmentMode === "word")
      throw new Error('Unsupported flag "y{w}"');
    [
      "digitIsAscii",
      // Flag D
      "extended",
      // Flag x
      "posixIsAscii",
      // Flag P
      "spaceIsAscii",
      // Flag S
      "wordIsAscii",
      // Flag W
      "textSegmentMode"
      // Flag y{g} or y{w}
    ].forEach((n) => delete t[n]), Object.assign(t, {
      // JS flag g; no Onig equiv
      global: !1,
      // JS flag d; no Onig equiv
      hasIndices: !1,
      // JS flag m; no Onig equiv but its behavior is always on in Onig. Onig's only line break
      // char is line feed, unlike JS, so this flag isn't used since it would produce inaccurate
      // results (also allows `^` and `$` to be used in the generator for string start and end)
      multiline: !1,
      // JS flag y; no Onig equiv, but used for `\G` emulation
      sticky: t.sticky ?? !1
      // Note: Regex+ doesn't allow explicitly adding flags it handles implicitly, so leave out
      // properties `unicode` (JS flag u) and `unicodeSets` (JS flag v). Keep the existing values
      // for `ignoreCase` (flag i) and `dotAll` (JS flag s, but Onig flag m)
    }), e.options = {
      disable: {
        // Onig uses different rules for flag x than Regex+, so disable the implicit flag
        x: !0,
        // Onig has no flag to control "named capture only" mode but contextually applies its
        // behavior when named capturing is used, so disable Regex+'s implicit flag for it
        n: !0
      },
      force: {
        // Always add flag v because we're generating an AST that relies on it (it enables JS
        // support for Onig features nested classes, intersection, Unicode properties, etc.).
        // However, the generator might disable flag v based on its `target` option
        v: !0
      }
    };
  },
  Group({ node: t }) {
    if (!t.flags)
      return;
    const { enable: e, disable: n } = t.flags;
    e != null && e.extended && delete e.extended, n != null && n.extended && delete n.extended, e != null && e.dotAll && (n != null && n.dotAll) && delete e.dotAll, e != null && e.ignoreCase && (n != null && n.ignoreCase) && delete e.ignoreCase, e && !Object.keys(e).length && delete t.flags.enable, n && !Object.keys(n).length && delete t.flags.disable, !t.flags.enable && !t.flags.disable && delete t.flags;
  },
  LookaroundAssertion({ node: t }, e) {
    const { kind: n } = t;
    n === "lookbehind" && (e.passedLookbehind = !0);
  },
  NamedCallout({ node: t, parent: e, replaceWith: n }) {
    const { kind: r } = t;
    if (r === "fail")
      n(ne(dt({ negate: !0 }), e));
    else
      throw new Error(`Unsupported named callout "(*${r.toUpperCase()}"`);
  },
  Quantifier({ node: t }) {
    if (t.body.type === "Quantifier") {
      const e = $e();
      e.body[0].body.push(t.body), t.body = ne(e, t);
    }
  },
  Regex: {
    enter({ node: t }, { supportedGNodes: e }) {
      const n = [];
      let r = !1, s = !1;
      for (const a of t.body)
        if (a.body.length === 1 && a.body[0].kind === "search_start")
          a.body.pop();
        else {
          const i = wc(a.body);
          i ? (r = !0, Array.isArray(i) ? n.push(...i) : n.push(i)) : s = !0;
        }
      r && !s && n.forEach((a) => e.add(a));
    },
    exit(t, { accuracy: e, passedLookbehind: n, strategy: r }) {
      if (e === "strict" && n && r)
        throw new Error(B`Uses "\G" in a way that requires non-strict accuracy`);
    }
  },
  Subroutine({ node: t }, { jsGroupNameMap: e }) {
    let { ref: n } = t;
    typeof n == "string" && !Wr(n) && (n = qr(n, e), t.ref = n);
  }
}, Zx = {
  Backreference({ node: t }, { multiplexCapturesToLeftByRef: e, reffedNodesByReferencer: n }) {
    const { orphan: r, ref: s } = t;
    r || n.set(t, [...e.get(s).map(({ node: a }) => a)]);
  },
  CapturingGroup: {
    enter({
      node: t,
      parent: e,
      replaceWith: n,
      skip: r
    }, {
      groupOriginByCopy: s,
      groupsByName: a,
      multiplexCapturesToLeftByRef: i,
      openRefs: o,
      reffedNodesByReferencer: l
    }) {
      const c = s.get(t);
      if (c && o.has(t.number)) {
        const p = Ye(Ei(t.number), e);
        l.set(p, o.get(t.number)), n(p);
        return;
      }
      o.set(t.number, t), i.set(t.number, []), t.name && sn(i, t.name, []);
      const d = i.get(t.name ?? t.number);
      for (let p = 0; p < d.length; p++) {
        const h = d[p];
        if (
          // This group is from subroutine expansion, and there's a multiplex value from either the
          // origin node or a prior subroutine expansion group with the same origin
          c === h.node || c && c === h.origin || // This group is not from subroutine expansion, and it comes after a subroutine expansion
          // group that refers to this group
          t === h.origin
        ) {
          d.splice(p, 1);
          break;
        }
      }
      if (i.get(t.number).push({ node: t, origin: c }), t.name && i.get(t.name).push({ node: t, origin: c }), t.name) {
        const p = sn(a, t.name, /* @__PURE__ */ new Map());
        let h = !1;
        if (c)
          h = !0;
        else
          for (const m of p.values())
            if (!m.hasDuplicateNameToRemove) {
              h = !0;
              break;
            }
        a.get(t.name).set(t, { node: t, hasDuplicateNameToRemove: h });
      }
    },
    exit({ node: t }, { openRefs: e }) {
      e.get(t.number) === t && e.delete(t.number);
    }
  },
  Group: {
    enter({ node: t }, e) {
      e.prevFlags = e.currentFlags, t.flags && (e.currentFlags = rr(e.currentFlags, t.flags));
    },
    exit(t, e) {
      e.currentFlags = e.prevFlags;
    }
  },
  Subroutine({ node: t, parent: e, replaceWith: n }, r) {
    const { isRecursive: s, ref: a } = t;
    if (s) {
      let d = e;
      for (; (d = d.parent) && !(d.type === "CapturingGroup" && (d.name === a || d.number === a)); )
        ;
      r.reffedNodesByReferencer.set(t, d);
      return;
    }
    const i = r.subroutineRefMap.get(a), o = a === 0, l = o ? Ei(0) : (
      // The reffed group might itself contain subroutines, which are expanded during sub-traversal
      yc(i, r.groupOriginByCopy, null)
    );
    let c = l;
    if (!o) {
      const d = xc(Yx(
        i,
        (h) => h.type === "Group" && !!h.flags
      )), p = d ? rr(r.globalFlags, d) : r.globalFlags;
      Jx(p, r.currentFlags) || (c = $e({
        flags: Xx(p)
      }), c.body[0].body.push(l));
    }
    n(ne(c, e), { traverse: !o });
  }
}, Vx = {
  Backreference({ node: t, parent: e, replaceWith: n }, r) {
    if (t.orphan) {
      r.highestOrphanBackref = Math.max(r.highestOrphanBackref, t.ref);
      return;
    }
    const a = r.reffedNodesByReferencer.get(t).filter((i) => Qx(i, t));
    if (!a.length)
      n(ne(dt({ negate: !0 }), e));
    else if (a.length > 1) {
      const i = $e({
        atomic: !0,
        body: a.reverse().map((o) => wt({
          body: [ws(o.number)]
        }))
      });
      n(ne(i, e));
    } else
      t.ref = a[0].number;
  },
  CapturingGroup({ node: t }, e) {
    t.number = ++e.numCapturesToLeft, t.name && e.groupsByName.get(t.name).get(t).hasDuplicateNameToRemove && delete t.name;
  },
  Regex: {
    exit({ node: t }, e) {
      const n = Math.max(e.highestOrphanBackref - e.numCapturesToLeft, 0);
      for (let r = 0; r < n; r++) {
        const s = ic();
        t.body.at(-1).body.push(s);
      }
    }
  },
  Subroutine({ node: t }, e) {
    !t.isRecursive || t.ref === 0 || (t.ref = e.reffedNodesByReferencer.get(t).number);
  }
};
function gc(t) {
  Qt(t, {
    "*"({ node: e, parent: n }) {
      e.parent = n;
    }
  });
}
function Jx(t, e) {
  return t.dotAll === e.dotAll && t.ignoreCase === e.ignoreCase;
}
function Qx(t, e) {
  let n = e;
  do {
    if (n.type === "Regex")
      return !1;
    if (n.type === "Alternative")
      continue;
    if (n === t)
      return !1;
    const r = bc(n.parent);
    for (const s of r) {
      if (s === n)
        break;
      if (s === t || kc(s, t))
        return !0;
    }
  } while (n = n.parent);
  throw new Error("Unexpected path");
}
function yc(t, e, n, r) {
  const s = Array.isArray(t) ? [] : {};
  for (const [a, i] of Object.entries(t))
    a === "parent" ? s.parent = Array.isArray(n) ? r : n : i && typeof i == "object" ? s[a] = yc(i, e, s, n) : (a === "type" && i === "CapturingGroup" && e.set(s, e.get(t) ?? t), s[a] = i);
  return s;
}
function Ei(t) {
  const e = lc(t);
  return e.isRecursive = !0, e;
}
function Yx(t, e) {
  const n = [];
  for (; t = t.parent; )
    (!e || e(t)) && n.push(t);
  return n;
}
function qr(t, e) {
  if (e.has(t))
    return e.get(t);
  const n = `$${e.size}_${t.replace(/^[^$_\p{IDS}]|[^$\u200C\u200D\p{IDC}]/ug, "_")}`;
  return e.set(t, n), n;
}
function xc(t) {
  const e = ["dotAll", "ignoreCase"], n = { enable: {}, disable: {} };
  return t.forEach(({ flags: r }) => {
    e.forEach((s) => {
      var a, i;
      (a = r.enable) != null && a[s] && (delete n.disable[s], n.enable[s] = !0), (i = r.disable) != null && i[s] && (n.disable[s] = !0);
    });
  }), Object.keys(n.enable).length || delete n.enable, Object.keys(n.disable).length || delete n.disable, n.enable || n.disable ? n : null;
}
function Xx({ dotAll: t, ignoreCase: e }) {
  const n = {};
  return (t || e) && (n.enable = {}, t && (n.enable.dotAll = !0), e && (n.enable.ignoreCase = !0)), (!t || !e) && (n.disable = {}, !t && (n.disable.dotAll = !0), !e && (n.disable.ignoreCase = !0)), n;
}
function bc(t) {
  if (!t)
    throw new Error("Node expected");
  const { body: e } = t;
  return Array.isArray(e) ? e : e ? [e] : null;
}
function wc(t) {
  const e = t.find((n) => n.kind === "search_start" || tb(n, { negate: !1 }) || !Kx(n));
  if (!e)
    return null;
  if (e.kind === "search_start")
    return e;
  if (e.type === "LookaroundAssertion")
    return e.body[0].body[0];
  if (e.type === "CapturingGroup" || e.type === "Group") {
    const n = [];
    for (const r of e.body) {
      const s = wc(r.body);
      if (!s)
        return null;
      Array.isArray(s) ? n.push(...s) : n.push(s);
    }
    return n;
  }
  return null;
}
function kc(t, e) {
  const n = bc(t) ?? [];
  for (const r of n)
    if (r === e || kc(r, e))
      return !0;
  return !1;
}
function Kx({ type: t }) {
  return t === "Assertion" || t === "Directive" || t === "LookaroundAssertion";
}
function eb(t) {
  const e = [
    "Character",
    "CharacterClass",
    "CharacterSet"
  ];
  return e.includes(t.type) || t.type === "Quantifier" && t.min && e.includes(t.body.type);
}
function tb(t, e) {
  const n = {
    negate: null,
    ...e
  };
  return t.type === "LookaroundAssertion" && (n.negate === null || t.negate === n.negate) && t.body.length === 1 && sc(t.body[0], {
    type: "Assertion",
    kind: "search_start"
  });
}
function Wr(t) {
  return /^[$_\p{IDS}][$\u200C\u200D\p{IDC}]*$/u.test(t);
}
function Ge(t, e) {
  const r = ac(t, {
    ...e,
    // Providing a custom set of Unicode property names avoids converting some JS Unicode
    // properties (ex: `\p{Alpha}`) to Onig POSIX classes
    unicodePropertyMap: ca
  }).body;
  return r.length > 1 || r[0].body.length > 1 ? $e({ body: r }) : r[0].body[0];
}
function Zr(t, e) {
  return t.negate = e, t;
}
function Ye(t, e) {
  return t.parent = e, t;
}
function ne(t, e) {
  return gc(t), t.parent = e, t;
}
function nb(t, e) {
  const n = hc(e), r = _s(n.target, "ES2024"), s = _s(n.target, "ES2025"), a = n.rules.recursionLimit;
  if (!Number.isInteger(a) || a < 2 || a > 20)
    throw new Error("Invalid recursionLimit; use 2-20");
  let i = null, o = null;
  if (!s) {
    const m = [t.flags.ignoreCase];
    Qt(t, rb, {
      getCurrentModI: () => m.at(-1),
      popModI() {
        m.pop();
      },
      pushModI(f) {
        m.push(f);
      },
      setHasCasedChar() {
        m.at(-1) ? i = !0 : o = !0;
      }
    });
  }
  const l = {
    dotAll: t.flags.dotAll,
    // - Turn global flag i on if a case insensitive node was used and no case sensitive nodes were
    //   used (to avoid unnecessary node expansion).
    // - Turn global flag i off if a case sensitive node was used (since case sensitivity can't be
    //   forced without the use of ES2025 flag groups)
    ignoreCase: !!((t.flags.ignoreCase || i) && !o)
  };
  let c = t;
  const d = {
    accuracy: n.accuracy,
    appliedGlobalFlags: l,
    captureMap: /* @__PURE__ */ new Map(),
    currentFlags: {
      dotAll: t.flags.dotAll,
      ignoreCase: t.flags.ignoreCase
    },
    inCharClass: !1,
    lastNode: c,
    originMap: t._originMap,
    recursionLimit: a,
    useAppliedIgnoreCase: !!(!s && i && o),
    useFlagMods: s,
    useFlagV: r,
    verbose: n.verbose
  };
  function p(m) {
    return d.lastNode = c, c = m, Ox(sb[m.type], `Unexpected node type "${m.type}"`)(m, d, p);
  }
  const h = {
    pattern: t.body.map(p).join("|"),
    // Could reset `lastNode` at this point via `lastNode = ast`, but it isn't needed by flags
    flags: p(t.flags),
    options: { ...t.options }
  };
  return r || (delete h.options.force.v, h.options.disable.v = !0, h.options.unicodeSetsPlugin = null), h._captureTransfers = /* @__PURE__ */ new Map(), h._hiddenCaptures = [], d.captureMap.forEach((m, f) => {
    m.hidden && h._hiddenCaptures.push(f), m.transferTo && sn(h._captureTransfers, m.transferTo, []).push(f);
  }), h;
}
var rb = {
  "*": {
    enter({ node: t }, e) {
      if (Ri(t)) {
        const n = e.getCurrentModI();
        e.pushModI(
          t.flags ? rr({ ignoreCase: n }, t.flags).ignoreCase : n
        );
      }
    },
    exit({ node: t }, e) {
      Ri(t) && e.popModI();
    }
  },
  Backreference(t, e) {
    e.setHasCasedChar();
  },
  Character({ node: t }, e) {
    ua(se(t.value)) && e.setHasCasedChar();
  },
  CharacterClassRange({ node: t, skip: e }, n) {
    e(), vc(t, { firstOnly: !0 }).length && n.setHasCasedChar();
  },
  CharacterSet({ node: t }, e) {
    t.kind === "property" && mc.has(t.value) && e.setHasCasedChar();
  }
}, sb = {
  /**
  @param {AlternativeNode} node
  */
  Alternative({ body: t }, e, n) {
    return t.map(n).join("");
  },
  /**
  @param {AssertionNode} node
  */
  Assertion({ kind: t, negate: e }) {
    if (t === "string_end")
      return "$";
    if (t === "string_start")
      return "^";
    if (t === "word_boundary")
      return e ? B`\B` : B`\b`;
    throw new Error(`Unexpected assertion kind "${t}"`);
  },
  /**
  @param {BackreferenceNode} node
  */
  Backreference({ ref: t }, e) {
    if (typeof t != "number")
      throw new Error("Unexpected named backref in transformed AST");
    if (!e.useFlagMods && e.accuracy === "strict" && e.currentFlags.ignoreCase && !e.captureMap.get(t).ignoreCase)
      throw new Error("Use of case-insensitive backref to case-sensitive group requires target ES2025 or non-strict accuracy");
    return "\\" + t;
  },
  /**
  @param {CapturingGroupNode} node
  */
  CapturingGroup(t, e, n) {
    const { body: r, name: s, number: a } = t, i = { ignoreCase: e.currentFlags.ignoreCase }, o = e.originMap.get(t);
    return o && (i.hidden = !0, a > o.number && (i.transferTo = o.number)), e.captureMap.set(a, i), `(${s ? `?<${s}>` : ""}${r.map(n).join("|")})`;
  },
  /**
  @param {CharacterNode} node
  */
  Character({ value: t }, e) {
    const n = se(t), r = At(t, {
      escDigit: e.lastNode.type === "Backreference",
      inCharClass: e.inCharClass,
      useFlagV: e.useFlagV
    });
    if (r !== n)
      return r;
    if (e.useAppliedIgnoreCase && e.currentFlags.ignoreCase && ua(n)) {
      const s = fc(n);
      return e.inCharClass ? s.join("") : s.length > 1 ? `[${s.join("")}]` : s[0];
    }
    return n;
  },
  /**
  @param {CharacterClassNode} node
  */
  CharacterClass(t, e, n) {
    const { kind: r, negate: s, parent: a } = t;
    let { body: i } = t;
    if (r === "intersection" && !e.useFlagV)
      throw new Error("Use of character class intersection requires min target ES2024");
    Oe.bugFlagVLiteralHyphenIsRange && e.useFlagV && i.some(Pi) && (i = [kr(45), ...i.filter((c) => !Pi(c))]);
    const o = () => `[${s ? "^" : ""}${i.map(n).join(r === "intersection" ? "&&" : "")}]`;
    if (!e.inCharClass) {
      if (
        // Already established `kind !== 'intersection'` if `!state.useFlagV`; don't check again
        (!e.useFlagV || Oe.bugNestedClassIgnoresNegation) && !s
      ) {
        const d = i.filter(
          (p) => p.type === "CharacterClass" && p.kind === "union" && p.negate
        );
        if (d.length) {
          const p = $e(), h = p.body[0];
          return p.parent = a, h.parent = p, i = i.filter((m) => !d.includes(m)), t.body = i, i.length ? (t.parent = h, h.body.push(t)) : p.body.pop(), d.forEach((m) => {
            const f = wt({ body: [m] });
            m.parent = f, f.parent = p, p.body.push(f);
          }), n(p);
        }
      }
      e.inCharClass = !0;
      const c = o();
      return e.inCharClass = !1, c;
    }
    const l = i[0];
    if (
      // Already established that the parent is a char class via `inCharClass`; don't check again
      r === "union" && !s && l && // Allows many nested classes to work with `target` ES2018 which doesn't support nesting
      ((!e.useFlagV || !e.verbose) && a.kind === "union" && !(Oe.bugFlagVLiteralHyphenIsRange && e.useFlagV) || !e.verbose && a.kind === "intersection" && // JS doesn't allow intersection with union or ranges
      i.length === 1 && l.type !== "CharacterClassRange")
    )
      return i.map(n).join("");
    if (!e.useFlagV && a.type === "CharacterClass")
      throw new Error("Uses nested character class in a way that requires min target ES2024");
    return o();
  },
  /**
  @param {CharacterClassRangeNode} node
  */
  CharacterClassRange(t, e) {
    const n = t.min.value, r = t.max.value, s = {
      escDigit: !1,
      inCharClass: !0,
      useFlagV: e.useFlagV
    }, a = At(n, s), i = At(r, s), o = /* @__PURE__ */ new Set();
    if (e.useAppliedIgnoreCase && e.currentFlags.ignoreCase) {
      const l = vc(t);
      cb(l).forEach((d) => {
        o.add(
          Array.isArray(d) ? `${At(d[0], s)}-${At(d[1], s)}` : At(d, s)
        );
      });
    }
    return `${a}-${i}${[...o].join("")}`;
  },
  /**
  @param {CharacterSetNode} node
  */
  CharacterSet({ kind: t, negate: e, value: n, key: r }, s) {
    if (t === "dot")
      return s.currentFlags.dotAll ? s.appliedGlobalFlags.dotAll || s.useFlagMods ? "." : "[^]" : (
        // Onig's only line break char is line feed, unlike JS
        B`[^\n]`
      );
    if (t === "digit")
      return e ? B`\D` : B`\d`;
    if (t === "property") {
      if (s.useAppliedIgnoreCase && s.currentFlags.ignoreCase && mc.has(n))
        throw new Error(`Unicode property "${n}" can't be case-insensitive when other chars have specific case`);
      return `${e ? B`\P` : B`\p`}{${r ? `${r}=` : ""}${n}}`;
    }
    if (t === "word")
      return e ? B`\W` : B`\w`;
    throw new Error(`Unexpected character set kind "${t}"`);
  },
  /**
  @param {FlagsNode} node
  */
  Flags(t, e) {
    return (
      // The transformer should never turn on the properties for flags d, g, m since Onig doesn't
      // have equivs. Flag m is never used since Onig uses different line break chars than JS
      // (node.hasIndices ? 'd' : '') +
      // (node.global ? 'g' : '') +
      // (node.multiline ? 'm' : '') +
      (e.appliedGlobalFlags.ignoreCase ? "i" : "") + (t.dotAll ? "s" : "") + (t.sticky ? "y" : "")
    );
  },
  /**
  @param {GroupNode} node
  */
  Group({ atomic: t, body: e, flags: n, parent: r }, s, a) {
    const i = s.currentFlags;
    n && (s.currentFlags = rr(i, n));
    const o = e.map(a).join("|"), l = !s.verbose && e.length === 1 && // Single alt
    r.type !== "Quantifier" && !t && (!s.useFlagMods || !n) ? o : `(?${ub(t, n, s.useFlagMods)}${o})`;
    return s.currentFlags = i, l;
  },
  /**
  @param {LookaroundAssertionNode} node
  */
  LookaroundAssertion({ body: t, kind: e, negate: n }, r, s) {
    return `(?${`${e === "lookahead" ? "" : "<"}${n ? "!" : "="}`}${t.map(s).join("|")})`;
  },
  /**
  @param {QuantifierNode} node
  */
  Quantifier(t, e, n) {
    return n(t.body) + pb(t);
  },
  /**
  @param {SubroutineNode & {isRecursive: true}} node
  */
  Subroutine({ isRecursive: t, ref: e }, n) {
    if (!t)
      throw new Error("Unexpected non-recursive subroutine in transformed AST");
    const r = n.recursionLimit;
    return e === 0 ? `(?R=${r})` : B`\g<${e}&R=${r}>`;
  }
}, ab = /* @__PURE__ */ new Set([
  "$",
  "(",
  ")",
  "*",
  "+",
  ".",
  "?",
  "[",
  "\\",
  "]",
  "^",
  "{",
  "|",
  "}"
]), ib = /* @__PURE__ */ new Set([
  "-",
  "\\",
  "]",
  "^",
  // Literal `[` doesn't require escaping with flag u, but this can help work around regex source
  // linters and regex syntax processors that expect unescaped `[` to create a nested class
  "["
]), ob = /* @__PURE__ */ new Set([
  "(",
  ")",
  "-",
  "/",
  "[",
  "\\",
  "]",
  "^",
  "{",
  "|",
  "}",
  // Double punctuators; also includes already-listed `-` and `^`
  "!",
  "#",
  "$",
  "%",
  "&",
  "*",
  "+",
  ",",
  ".",
  ":",
  ";",
  "<",
  "=",
  ">",
  "?",
  "@",
  "`",
  "~"
]), ji = /* @__PURE__ */ new Map([
  [9, B`\t`],
  // horizontal tab
  [10, B`\n`],
  // line feed
  [11, B`\v`],
  // vertical tab
  [12, B`\f`],
  // form feed
  [13, B`\r`],
  // carriage return
  [8232, B`\u2028`],
  // line separator
  [8233, B`\u2029`],
  // paragraph separator
  [65279, B`\uFEFF`]
  // ZWNBSP/BOM
]), lb = new RegExp("^\\p{Cased}$", "u");
function ua(t) {
  return lb.test(t);
}
function vc(t, e) {
  const n = !!(e != null && e.firstOnly), r = t.min.value, s = t.max.value, a = [];
  if (r < 65 && (s === 65535 || s >= 131071) || r === 65536 && s >= 131071)
    return a;
  for (let i = r; i <= s; i++) {
    const o = se(i);
    if (!ua(o))
      continue;
    const l = fc(o).filter((c) => {
      const d = c.codePointAt(0);
      return d < r || d > s;
    });
    if (l.length && (a.push(...l), n))
      break;
  }
  return a;
}
function At(t, { escDigit: e, inCharClass: n, useFlagV: r }) {
  if (ji.has(t))
    return ji.get(t);
  if (
    // Control chars, etc.; condition modeled on the Chrome developer console's display for strings
    t < 32 || t > 126 && t < 160 || // Unicode planes 4-16; unassigned, special purpose, and private use area
    t > 262143 || // Avoid corrupting a preceding backref by immediately following it with a literal digit
    e && db(t)
  )
    return t > 255 ? `\\u{${t.toString(16).toUpperCase()}}` : `\\x${t.toString(16).toUpperCase().padStart(2, "0")}`;
  const s = n ? r ? ob : ib : ab, a = se(t);
  return (s.has(a) ? "\\" : "") + a;
}
function cb(t) {
  const e = t.map((s) => s.codePointAt(0)).sort((s, a) => s - a), n = [];
  let r = null;
  for (let s = 0; s < e.length; s++)
    e[s + 1] === e[s] + 1 ? r ?? (r = e[s]) : r === null ? n.push(e[s]) : (n.push([r, e[s]]), r = null);
  return n;
}
function ub(t, e, n) {
  if (t)
    return ">";
  let r = "";
  if (e && n) {
    const { enable: s, disable: a } = e;
    r = (s != null && s.ignoreCase ? "i" : "") + (s != null && s.dotAll ? "s" : "") + (a ? "-" : "") + (a != null && a.ignoreCase ? "i" : "") + (a != null && a.dotAll ? "s" : "");
  }
  return `${r}:`;
}
function pb({ kind: t, max: e, min: n }) {
  let r;
  return !n && e === 1 ? r = "?" : !n && e === 1 / 0 ? r = "*" : n === 1 && e === 1 / 0 ? r = "+" : n === e ? r = `{${n}}` : r = `{${n},${e === 1 / 0 ? "" : e}}`, r + {
    greedy: "",
    lazy: "?",
    possessive: "+"
  }[t];
}
function Ri({ type: t }) {
  return t === "CapturingGroup" || t === "Group" || t === "LookaroundAssertion";
}
function db(t) {
  return t > 47 && t < 58;
}
function Pi({ type: t, value: e }) {
  return t === "Character" && e === 45;
}
var Xe, ze, mt, Ke, gt, an, Ss, nt, hb = (nt = class extends RegExp {
  /**
  @overload
  @param {string} pattern
  @param {string} [flags]
  @param {EmulatedRegExpOptions} [options]
  */
  /**
  @overload
  @param {EmulatedRegExp} pattern
  @param {string} [flags]
  */
  constructor(n, r, s) {
    var e = (...Gw) => (super(...Gw), at(this, an), /**
    @type {Map<number, {
      hidden?: true;
      transferTo?: number;
    }>}
    */
    at(this, Xe, /* @__PURE__ */ new Map()), /**
    @type {RegExp | EmulatedRegExp | null}
    */
    at(this, ze, null), /**
    @type {string}
    */
    at(this, mt), /**
    @type {Map<number, string>?}
    */
    at(this, Ke, null), /**
    @type {string?}
    */
    at(this, gt, null), /**
    Can be used to serialize the instance.
    @type {EmulatedRegExpOptions}
    */
    _(this, "rawOptions", {}), this);
    const a = !!(s != null && s.lazyCompile);
    if (n instanceof RegExp) {
      if (s)
        throw new Error("Cannot provide options when copying a regexp");
      const i = n;
      e(i, r), Ee(this, mt, i.source), i instanceof nt && (Ee(this, Xe, me(i, Xe)), Ee(this, Ke, me(i, Ke)), Ee(this, gt, me(i, gt)), this.rawOptions = i.rawOptions);
    } else {
      const i = {
        hiddenCaptures: [],
        strategy: null,
        transfers: [],
        ...s
      };
      e(a ? "" : n, r), Ee(this, mt, n), Ee(this, Xe, mb(i.hiddenCaptures, i.transfers)), Ee(this, gt, i.strategy), this.rawOptions = s ?? {};
    }
    a || Ee(this, ze, this);
  }
  // Override the getter with one that works with lazy-compiled regexes
  get source() {
    return me(this, mt) || "(?:)";
  }
  /**
  Called internally by all String/RegExp methods that use regexes.
  @override
  @param {string} str
  @returns {RegExpExecArray?}
  */
  exec(n) {
    if (!me(this, ze)) {
      const { lazyCompile: a, ...i } = this.rawOptions;
      Ee(this, ze, new nt(me(this, mt), this.flags, i));
    }
    const r = this.global || this.sticky, s = this.lastIndex;
    if (me(this, gt) === "clip_search" && r && s) {
      this.lastIndex = 0;
      const a = Ir(this, an, Ss).call(this, n.slice(s));
      return a && (fb(a, s, n, this.hasIndices), this.lastIndex += s), a;
    }
    return Ir(this, an, Ss).call(this, n);
  }
}, Xe = new WeakMap(), ze = new WeakMap(), mt = new WeakMap(), Ke = new WeakMap(), gt = new WeakMap(), an = new WeakSet(), /**
Adds support for hidden and transfer captures.
@param {string} str
@returns
*/
Ss = function(n) {
  me(this, ze).lastIndex = this.lastIndex;
  const r = ga(nt.prototype, this, "exec").call(me(this, ze), n);
  if (this.lastIndex = me(this, ze).lastIndex, !r || !me(this, Xe).size)
    return r;
  const s = [...r];
  r.length = 1;
  let a;
  this.hasIndices && (a = [...r.indices], r.indices.length = 1);
  const i = [0];
  for (let o = 1; o < s.length; o++) {
    const { hidden: l, transferTo: c } = me(this, Xe).get(o) ?? {};
    if (l ? i.push(null) : (i.push(r.length), r.push(s[o]), this.hasIndices && r.indices.push(a[o])), c && s[o] !== void 0) {
      const d = i[c];
      if (!d)
        throw new Error(`Invalid capture transfer to "${d}"`);
      if (r[d] = s[o], this.hasIndices && (r.indices[d] = a[o]), r.groups) {
        me(this, Ke) || Ee(this, Ke, gb(this.source));
        const p = me(this, Ke).get(c);
        p && (r.groups[p] = s[o], this.hasIndices && (r.indices.groups[p] = a[o]));
      }
    }
  }
  return r;
}, nt);
function fb(t, e, n, r) {
  if (t.index += e, t.input = n, r) {
    const s = t.indices;
    for (let i = 0; i < s.length; i++) {
      const o = s[i];
      o && (s[i] = [o[0] + e, o[1] + e]);
    }
    const a = s.groups;
    a && Object.keys(a).forEach((i) => {
      const o = a[i];
      o && (a[i] = [o[0] + e, o[1] + e]);
    });
  }
}
function mb(t, e) {
  const n = /* @__PURE__ */ new Map();
  for (const r of t)
    n.set(r, {
      hidden: !0
    });
  for (const [r, s] of e)
    for (const a of s)
      sn(n, a, {}).transferTo = r;
  return n;
}
function gb(t) {
  const e = /(?<capture>\((?:\?<(?![=!])(?<name>[^>]+)>|(?!\?)))|\\?./gsu, n = /* @__PURE__ */ new Map();
  let r = 0, s = 0, a;
  for (; a = e.exec(t); ) {
    const { 0: i, groups: { capture: o, name: l } } = a;
    i === "[" ? r++ : r ? i === "]" && r-- : o && (s++, l && n.set(s, l));
  }
  return n;
}
function yb(t, e) {
  const n = xb(t, e);
  return n.options ? new hb(n.pattern, n.flags, n.options) : new RegExp(n.pattern, n.flags);
}
function xb(t, e) {
  const n = hc(e), r = ac(t, {
    flags: n.flags,
    normalizeUnknownPropertyNames: !0,
    rules: {
      captureGroup: n.rules.captureGroup,
      singleline: n.rules.singleline
    },
    skipBackrefValidation: n.rules.allowOrphanBackrefs,
    unicodePropertyMap: ca
  }), s = qx(r, {
    accuracy: n.accuracy,
    asciiWordBoundaries: n.rules.asciiWordBoundaries,
    avoidSubclass: n.avoidSubclass,
    bestEffortTarget: n.target
  }), a = nb(s, n), i = Lx(a.pattern, {
    captureTransfers: a._captureTransfers,
    hiddenCaptures: a._hiddenCaptures,
    mode: "external"
  }), o = Rx(i.pattern), l = jx(o.pattern, {
    captureTransfers: i.captureTransfers,
    hiddenCaptures: i.hiddenCaptures
  }), c = {
    pattern: l.pattern,
    flags: `${n.hasIndices ? "d" : ""}${n.global ? "g" : ""}${a.flags}${a.options.disable.v ? "u" : "v"}`
  };
  if (n.avoidSubclass) {
    if (n.lazyCompileLength !== 1 / 0)
      throw new Error("Lazy compilation requires subclass");
  } else {
    const d = l.hiddenCaptures.sort((f, g) => f - g), p = Array.from(l.captureTransfers), h = s._strategy, m = c.pattern.length >= n.lazyCompileLength;
    (d.length || p.length || h || m) && (c.options = {
      ...d.length && { hiddenCaptures: d },
      ...p.length && { transfers: p },
      ...h && { strategy: h },
      ...m && { lazyCompile: m }
    });
  }
  return c;
}
function _c(t, e) {
  return yb(t, {
    global: !0,
    hasIndices: !0,
    lazyCompileLength: 3e3,
    rules: {
      allowOrphanBackrefs: !0,
      asciiWordBoundaries: !0,
      captureGroup: !0,
      recursionLimit: 5,
      singleline: !0
    },
    ...e
  });
}
function bb(t = {}) {
  const e = Object.assign({
    target: "auto",
    cache: /* @__PURE__ */ new Map()
  }, t);
  return e.regexConstructor || (e.regexConstructor = (n) => _c(n, { target: e.target })), {
    createScanner(n) {
      return new $y(n, e);
    },
    createString(n) {
      return { content: n };
    }
  };
}
var wb = /* @__PURE__ */ Zs({
  bundledLanguages: () => hr,
  bundledLanguagesAlias: () => Js,
  bundledLanguagesBase: () => Vs,
  bundledLanguagesInfo: () => dr,
  bundledThemes: () => Ys,
  bundledThemesInfo: () => Qs,
  codeToHast: () => Vl,
  codeToHtml: () => Zl,
  codeToTokens: () => nr,
  codeToTokensBase: () => Jl,
  codeToTokensWithThemes: () => Ql,
  createHighlighter: () => aa,
  createJavaScriptRegexEngine: () => bb,
  createOnigurumaEngine: () => hl,
  defaultJavaScriptRegexConstructor: () => _c,
  getLastGrammarState: () => Xl,
  getSingletonHighlighter: () => Yl,
  loadWasm: () => Ks
});
ul(wb, Ly);
function kb({ children: t, className: e, ...n }) {
  return /* @__PURE__ */ u.jsx(
    "div",
    {
      className: $(
        "not-prose flex w-full flex-col overflow-clip border",
        "border-border bg-card text-card-foreground rounded-xl",
        e
      ),
      ...n,
      children: t
    }
  );
}
function vb({
  code: t,
  language: e = "tsx",
  theme: n,
  className: r,
  ...s
}) {
  const [a, i] = y.useState(null);
  y.useEffect(() => {
    if (!t) {
      i(null);
      return;
    }
    let c = !1;
    async function d() {
      const p = n ? { theme: n } : {
        themes: { light: "vitesse-light", dark: "vitesse-dark" },
        defaultColor: !1
      }, h = Eb(e) ? e : "plaintext";
      let m;
      try {
        m = await nr(t, { lang: h, ...p });
      } catch {
        if (h === "plaintext") return;
        try {
          m = await nr(t, {
            lang: "plaintext",
            ...p
          });
        } catch {
          return;
        }
      }
      c || i({
        lines: m.tokens.map(
          (f) => f.map((g) => ({
            content: g.content,
            style: Ib(g)
          }))
        ),
        preStyle: typeof m.rootStyle == "string" ? Tb(m.rootStyle) : {}
      });
    }
    return d(), () => {
      c = !0;
    };
  }, [t, e, n]);
  const o = $(
    "w-full overflow-x-auto text-[13px] [&>pre]:px-4 [&>pre]:py-4",
    r
  );
  if (!a)
    return /* @__PURE__ */ u.jsx("div", { className: o, ...s, children: /* @__PURE__ */ u.jsx("pre", { children: /* @__PURE__ */ u.jsx("code", { children: t }) }) });
  const l = a.lines.length - 1;
  return /* @__PURE__ */ u.jsx("div", { className: o, ...s, children: /* @__PURE__ */ u.jsx("pre", { className: "shiki", style: a.preStyle, children: /* @__PURE__ */ u.jsx("code", { children: a.lines.map((c, d) => /* @__PURE__ */ u.jsxs("span", { className: "line", children: [
    c.map((p, h) => /* @__PURE__ */ u.jsx("span", { style: p.style, children: p.content }, h)),
    d < l ? `
` : ""
  ] }, d)) }) }) });
}
function _b({
  children: t,
  className: e,
  ...n
}) {
  return /* @__PURE__ */ u.jsx(
    "div",
    {
      className: $("flex items-center justify-between", e),
      ...n,
      children: t
    }
  );
}
const Sb = {}, Cb = 1, Nb = 2, Ab = 4;
function Ib(t) {
  if (t.htmlStyle) {
    const n = {};
    for (const [r, s] of Object.entries(t.htmlStyle))
      Object.assign(n, { [Sc(r)]: s });
    return n;
  }
  const e = {};
  return t.color && (e.color = t.color), t.fontStyle && (t.fontStyle & Cb && (e.fontStyle = "italic"), t.fontStyle & Nb && (e.fontWeight = "bold"), t.fontStyle & Ab && (e.textDecoration = "underline")), !t.color && !t.fontStyle ? Sb : e;
}
function Tb(t) {
  const e = {};
  for (const n of t.split(";")) {
    const r = n.indexOf(":");
    if (r === -1) continue;
    const s = n.slice(0, r).trim(), a = n.slice(r + 1).trim();
    s && a && Object.assign(e, { [Sc(s)]: a });
  }
  return e;
}
function Sc(t) {
  return t.startsWith("--") ? t : t.replace(/-([a-z])/g, (e, n) => n.toUpperCase());
}
function Eb(t) {
  return t in hr;
}
function jb(t) {
  try {
    return new URL(t).hostname.replace("www.", "");
  } catch {
    return t;
  }
}
function Rb(t) {
  try {
    const e = new URL(t).origin;
    return !e || e === "null" ? "" : `${e}/favicon.ico`;
  } catch {
    return "";
  }
}
function Li({ url: t, size: e }) {
  const n = Rb(t), [r, s] = y.useState(!1), a = e === "sm" ? "h-3.5 w-3.5" : "h-4 w-4", i = e === "sm" ? "h-4 w-4" : "h-5 w-5";
  return !n || r ? /* @__PURE__ */ u.jsx(iu, { className: $(a, "shrink-0 text-muted-foreground") }) : /* @__PURE__ */ u.jsx(
    "img",
    {
      src: n,
      alt: "",
      className: $(i, "shrink-0 rounded-sm"),
      onError: () => s(!0)
    }
  );
}
function Pb({ href: t, title: e, className: n }) {
  const r = jb(t);
  return /* @__PURE__ */ u.jsxs(ru, { openDelay: 300, closeDelay: 100, children: [
    /* @__PURE__ */ u.jsx(su, { asChild: !0, children: /* @__PURE__ */ u.jsxs(
      "a",
      {
        href: t,
        target: "_blank",
        rel: "noopener noreferrer",
        className: $(
          "inline-flex items-center gap-1.5 rounded-full border bg-muted/50 px-2.5 py-1 text-xs transition-colors hover:bg-muted no-underline",
          n
        ),
        children: [
          /* @__PURE__ */ u.jsx(Li, { url: t, size: "sm" }),
          /* @__PURE__ */ u.jsx("span", { className: "max-w-[200px] truncate text-foreground/80", children: r })
        ]
      }
    ) }),
    /* @__PURE__ */ u.jsx(au, { align: "start", className: "w-72 p-3", children: /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col gap-2", children: [
      /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ u.jsx(Li, { url: t, size: "md" }),
        /* @__PURE__ */ u.jsx("span", { className: "text-xs text-muted-foreground truncate", children: r })
      ] }),
      e && /* @__PURE__ */ u.jsx("p", { className: "text-sm font-medium leading-snug line-clamp-2", children: e }),
      /* @__PURE__ */ u.jsx("p", { className: "text-xs text-muted-foreground truncate", children: t })
    ] }) })
  ] });
}
function Lb(t) {
  var a;
  let e = t;
  e = e.replace(/^(#{1,6}\s)/gm, `
$1`);
  const n = e.split(`
`), r = [];
  let s = !1;
  for (let i = 0; i < n.length; i++) {
    const o = n[i], l = o.trim();
    if (l.startsWith("```")) {
      s = !s, r.push(o);
      continue;
    }
    if (s) {
      r.push(o);
      continue;
    }
    if (l.startsWith("|") || /^\s*[-*+]\s/.test(l) || /^\s*\d+[.)]\s/.test(l)) {
      r.push(o);
      continue;
    }
    const c = ((a = r[r.length - 1]) == null ? void 0 : a.trim()) ?? "", d = c.startsWith("|") || /^\s*[-*+]\s/.test(c) || /^\s*\d+[.)]\s/.test(c);
    i > 0 && c !== "" && l !== "" && !d && r.push(""), r.push(o);
  }
  return r.join(`
`);
}
function $b(t) {
  const e = Lb(t);
  return W.lexer(e).map((r) => r.raw).filter((r) => r.trim().length > 0);
}
function Ob(t) {
  if (!t) return "plaintext";
  const e = t.match(/language-(\w+)/);
  return e ? e[1] : "plaintext";
}
function Cc(t) {
  var r, s;
  const e = ((r = t.children) == null ? void 0 : r.filter((a) => {
    var i;
    return !(a.type === "text" && !((i = a.value) != null && i.trim()));
  })) ?? [];
  if (e.length !== 1) return !1;
  const n = e[0];
  if (n.type === "element" && n.tagName === "a") return !0;
  if (n.type === "element" && n.tagName === "p") {
    const a = ((s = n.children) == null ? void 0 : s.filter((i) => {
      var o;
      return !(i.type === "text" && !((o = i.value) != null && o.trim()));
    })) ?? [];
    return a.length === 1 && a[0].type === "element" && a[0].tagName === "a";
  }
  return !1;
}
function $i(t) {
  if (!(t != null && t.children)) return !1;
  const e = t.children.filter(
    (n) => n.type === "element" && n.tagName === "li"
  );
  return e.length > 0 && e.every(Cc);
}
function Cs(t) {
  return typeof t == "string" ? t.trim().length > 0 : Array.isArray(t) ? t.some(Cs) : Vi.isValidElement(t) ? Cs(
    t.props.children
  ) : !!t;
}
const Mb = {
  h1: "text-2xl font-bold mt-6 first:mt-0 mb-3",
  h2: "text-xl font-semibold mt-5 first:mt-0 mb-2",
  h3: "text-lg font-semibold mt-4 first:mt-0 mb-2"
};
function Vr(t) {
  const e = function({ children: n }) {
    return Cs(n) ? /* @__PURE__ */ u.jsx(t, { className: Mb[t], children: n }) : null;
  };
  return e.displayName = t.toUpperCase(), e;
}
const Nc = {
  table: function({ children: e }) {
    return /* @__PURE__ */ u.jsx("div", { className: "my-4 overflow-hidden rounded-md border border-border", children: /* @__PURE__ */ u.jsx("table", { className: "w-full text-sm border-collapse", children: e }) });
  },
  h1: Vr("h1"),
  h2: Vr("h2"),
  h3: Vr("h3"),
  ul: function({ children: e, node: n }) {
    return $i(n) ? /* @__PURE__ */ u.jsx("div", { className: "flex flex-wrap gap-1.5 my-2", children: e }) : /* @__PURE__ */ u.jsx("ul", { className: "list-disc pl-6 my-2 space-y-1", children: e });
  },
  ol: function({ children: e, node: n }) {
    return $i(n) ? /* @__PURE__ */ u.jsx("div", { className: "flex flex-wrap gap-1.5 my-2", children: e }) : /* @__PURE__ */ u.jsx("ol", { className: "list-decimal pl-6 my-2 space-y-1", children: e });
  },
  li: function({ children: e, node: n }) {
    return n && Cc(n) ? /* @__PURE__ */ u.jsx(u.Fragment, { children: e }) : /* @__PURE__ */ u.jsx("li", { className: "pl-1", children: e });
  },
  a: function({ href: e, children: n, node: r }) {
    var c;
    if (!e) return /* @__PURE__ */ u.jsx(u.Fragment, { children: n });
    const s = e.startsWith("http://") || e.startsWith("https://");
    if (!(s || e.startsWith("mailto:") || e.startsWith("tel:")))
      return /* @__PURE__ */ u.jsx("span", { children: n });
    if (!s)
      return /* @__PURE__ */ u.jsx(
        "a",
        {
          href: e,
          className: "text-primary underline underline-offset-2 hover:text-primary/80 transition-colors",
          children: n
        }
      );
    const i = typeof n == "string" ? n : "", o = ((c = r == null ? void 0 : r.position) == null ? void 0 : c.start.column) && r.position.start.column > 1;
    return !o && i.startsWith("http") || o ? /* @__PURE__ */ u.jsx(Pb, { href: e, title: i !== e ? i : void 0 }) : /* @__PURE__ */ u.jsx(
      "a",
      {
        href: e,
        target: "_blank",
        rel: "noopener noreferrer",
        className: "text-primary underline underline-offset-2 hover:text-primary/80 transition-colors",
        children: n
      }
    );
  },
  code: function({ className: e, children: n, ...r }) {
    var o, l, c, d, p, h;
    if (!((l = (o = r.node) == null ? void 0 : o.position) != null && l.start.line) || ((d = (c = r.node) == null ? void 0 : c.position) == null ? void 0 : d.start.line) === ((h = (p = r.node) == null ? void 0 : p.position) == null ? void 0 : h.end.line))
      return /* @__PURE__ */ u.jsx(
        "span",
        {
          className: $(
            "bg-muted text-foreground rounded-sm px-1 font-mono text-sm",
            e
          ),
          ...r,
          children: n
        }
      );
    const a = Ob(e), i = n;
    return /* @__PURE__ */ u.jsxs(kb, { className: e, children: [
      /* @__PURE__ */ u.jsxs(_b, { className: "border-b px-3 py-1.5", children: [
        /* @__PURE__ */ u.jsx("span", { className: "text-xs text-muted-foreground font-mono", children: a !== "plaintext" ? a : "" }),
        /* @__PURE__ */ u.jsx(
          cu,
          {
            textToCopy: i,
            withoutTooltip: !0,
            variant: "ghost",
            className: "h-6 w-6 p-0"
          }
        )
      ] }),
      /* @__PURE__ */ u.jsx(vb, { code: i, language: a })
    ] });
  },
  hr: function() {
    return /* @__PURE__ */ u.jsx("hr", { className: "my-6 border-t border-border/50" });
  },
  pre: function({ children: e }) {
    return /* @__PURE__ */ u.jsx(u.Fragment, { children: e });
  }
}, Ac = y.memo(
  function({
    content: e,
    components: n = Nc
  }) {
    return /* @__PURE__ */ u.jsx(ou, { remarkPlugins: [lu], components: n, children: e });
  },
  function(e, n) {
    return e.content === n.content;
  }
);
Ac.displayName = "MemoizedMarkdownBlock";
function Db({
  children: t,
  id: e,
  className: n,
  components: r = Nc
}) {
  const s = y.useId(), a = e ?? s, i = y.useMemo(() => $b(t), [t]);
  return /* @__PURE__ */ u.jsx(
    "div",
    {
      className: $(
        "[&_pre]:overflow-x-auto [&_pre]:max-w-full",
        "[&_th]:text-left [&_th]:p-2.5 [&_th]:border-b [&_th]:border-border [&_th]:font-semibold",
        "[&_td]:p-2.5 [&_td]:border-b [&_td]:border-border",
        "[&_tr:last-child_td]:border-b-0",
        n
      ),
      children: i.map((o, l) => /* @__PURE__ */ u.jsx(
        Ac,
        {
          content: o,
          components: r
        },
        `${a}-block-${l}`
      ))
    }
  );
}
const pa = y.memo(Db);
pa.displayName = "Markdown";
const Ic = ({ children: t, className: e, ...n }) => /* @__PURE__ */ u.jsx("div", { className: $("flex gap-3", e), ...n, children: t }), Bb = ({
  children: t,
  markdown: e = !1,
  className: n,
  ...r
}) => {
  const s = $(
    "rounded-lg p-2 text-foreground prose break-words whitespace-normal",
    n
  );
  return e ? /* @__PURE__ */ u.jsx(pa, { className: s, ...r, children: t }) : /* @__PURE__ */ u.jsx("div", { className: s, ...r, children: t });
}, Tc = ({
  children: t,
  className: e,
  ...n
}) => /* @__PURE__ */ u.jsx(
  "div",
  {
    className: $("text-muted-foreground flex items-center gap-2", e),
    ...n,
    children: t
  }
), Rn = ({
  tooltip: t,
  children: e,
  className: n,
  side: r = "top",
  ...s
}) => /* @__PURE__ */ u.jsx(js, { children: /* @__PURE__ */ u.jsxs(Ji, { ...s, children: [
  /* @__PURE__ */ u.jsx(Rs, { asChild: !0, children: e }),
  /* @__PURE__ */ u.jsx(Ps, { side: r, className: n, children: t })
] }) }), Cn = typeof window < "u" && "speechSynthesis" in window;
function Fb() {
  const [t, e] = y.useState(!1), n = y.useRef(null), r = y.useCallback((a) => {
    if (!Cn) return;
    window.speechSynthesis.cancel(), n.current = null;
    const i = new SpeechSynthesisUtterance(a);
    i.lang = navigator.language, i.rate = 1, i.onend = () => {
      e(!1), n.current = null;
    }, i.onerror = () => {
      e(!1), n.current = null;
    }, n.current = i, e(!0), window.speechSynthesis.speak(i);
  }, []), s = y.useCallback(() => {
    Cn && window.speechSynthesis.cancel(), e(!1), n.current = null;
  }, []);
  return y.useEffect(() => () => {
    Cn && window.speechSynthesis.cancel();
  }, []), { isSpeaking: t, isSupported: Cn, speak: r, stop: s };
}
function sr(t) {
  const e = t.replace(/[^a-z0-9-]/gi, "");
  return t.startsWith("@activepieces/") ? t : `@activepieces/piece-${e}`;
}
function da(t) {
  return t.filter((e) => e.type === "text").map((e) => e.text).join("");
}
function ha({
  as: t = "span",
  className: e,
  duration: n = 4,
  spread: r = 20,
  children: s,
  ...a
}) {
  const i = Math.min(Math.max(r, 5), 45), o = t;
  return /* @__PURE__ */ u.jsx(
    o,
    {
      className: $(
        "bg-[length:200%_auto] bg-clip-text font-medium text-transparent",
        "animate-[shimmer_4s_infinite_linear]",
        e
      ),
      style: {
        backgroundImage: `linear-gradient(to right, var(--muted-foreground) ${50 - i}%, var(--foreground) 50%, var(--muted-foreground) ${50 + i}%)`,
        animationDuration: `${n}s`
      },
      ...a,
      children: s
    }
  );
}
function Gb({
  thinkingSteps: t,
  reasoningText: e,
  isStreaming: n,
  thinkingDurationMs: r
}) {
  const [s, a] = y.useState(!1), i = e.length > 0, o = t.length > 0;
  if (!o && !i && !n) return null;
  const l = o || i, c = r !== void 0 ? A("Thought for {seconds} seconds", {
    seconds: Math.round(r / 1e3)
  }) : A("Thought for a few seconds"), d = o ? t[t.length - 1] : null, p = t.length - 1;
  return /* @__PURE__ */ u.jsx(
    J.div,
    {
      initial: { opacity: 0, y: 6 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.3, ease: "easeOut" },
      children: /* @__PURE__ */ u.jsxs(fo, { open: s, onOpenChange: a, children: [
        /* @__PURE__ */ u.jsxs(
          "button",
          {
            type: "button",
            disabled: !l,
            onClick: () => a(!s),
            className: $(
              "flex items-center gap-1.5 text-sm text-muted-foreground text-left w-full",
              l && "hover:text-foreground transition-colors cursor-pointer"
            ),
            children: [
              n ? /* @__PURE__ */ u.jsx(ha, { className: "text-sm", duration: 3, children: A("Thinking...") }) : /* @__PURE__ */ u.jsx("span", { children: c }),
              l && /* @__PURE__ */ u.jsx(
                on,
                {
                  className: $(
                    "size-4 shrink-0 text-muted-foreground/50 transition-transform",
                    s && "rotate-180"
                  )
                }
              )
            ]
          }
        ),
        !s && n && d && /* @__PURE__ */ u.jsx("div", { className: "mt-3 ml-1", children: /* @__PURE__ */ u.jsx(On, { mode: "wait", children: /* @__PURE__ */ u.jsx(
          J.div,
          {
            initial: { opacity: 0, y: 4 },
            animate: { opacity: 1, y: 0 },
            exit: { opacity: 0 },
            transition: { duration: 0.3 },
            children: /* @__PURE__ */ u.jsx(
              Oi,
              {
                step: d,
                showConnector: !1,
                isStreaming: !0,
                showIcon: !1
              }
            )
          },
          `step-${p}`
        ) }) }),
        /* @__PURE__ */ u.jsx(mo, { className: "data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down overflow-hidden", children: /* @__PURE__ */ u.jsxs("div", { className: "mt-3 ml-1", children: [
          t.map((h, m) => /* @__PURE__ */ u.jsx(
            Oi,
            {
              step: h,
              showConnector: !0,
              isStreaming: n,
              showIcon: !0
            },
            h.kind === "tool" ? h.part.toolCallId : `${h.kind}-${m}`
          )),
          !n && o && /* @__PURE__ */ u.jsxs("div", { className: "flex gap-3 items-center", children: [
            /* @__PURE__ */ u.jsx("div", { className: "flex items-center justify-center size-5 rounded-full bg-muted", children: /* @__PURE__ */ u.jsx(we, { className: "size-3 text-muted-foreground" }) }),
            /* @__PURE__ */ u.jsx("span", { className: "text-xs text-muted-foreground", children: A("Done") })
          ] })
        ] }) })
      ] })
    }
  );
}
function Oi({
  step: t,
  showConnector: e,
  isStreaming: n,
  showIcon: r
}) {
  switch (t.kind) {
    case "reasoning":
      return /* @__PURE__ */ u.jsx(
        Ns,
        {
          showIcon: r,
          showConnector: e,
          icon: tp,
          children: /* @__PURE__ */ u.jsx(
            "p",
            {
              className: $(
                "whitespace-pre-wrap break-words line-clamp-3",
                n ? "text-sm text-foreground" : "text-xs text-muted-foreground"
              ),
              children: t.text
            }
          )
        }
      );
    case "thinking-status":
      return t.toolPart ? /* @__PURE__ */ u.jsx(
        Mi,
        {
          part: t.toolPart,
          showConnector: e,
          showIcon: r,
          label: t.text
        }
      ) : /* @__PURE__ */ u.jsx(
        Ns,
        {
          showIcon: r,
          showConnector: e,
          icon: uu,
          children: n ? /* @__PURE__ */ u.jsx(ha, { className: "text-sm", duration: 3, children: t.text }) : /* @__PURE__ */ u.jsx("p", { className: "text-xs text-muted-foreground", children: t.text })
        }
      );
    case "tool":
      return /* @__PURE__ */ u.jsx(
        Mi,
        {
          part: t.part,
          showConnector: e,
          showIcon: r
        }
      );
  }
}
function Ns({
  showIcon: t,
  showConnector: e,
  icon: n,
  children: r
}) {
  return /* @__PURE__ */ u.jsxs("div", { className: "flex gap-3", children: [
    t && /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col items-center shrink-0", children: [
      /* @__PURE__ */ u.jsx("div", { className: "flex items-center justify-center size-5 rounded-full bg-muted", children: /* @__PURE__ */ u.jsx(n, { className: "size-3 text-muted-foreground" }) }),
      e && /* @__PURE__ */ u.jsx("div", { className: "w-px flex-1 bg-border min-h-3" })
    ] }),
    /* @__PURE__ */ u.jsx("div", { className: "flex-1 min-w-0 pb-4 pt-0.5", children: r })
  ] });
}
function Mi({
  part: t,
  showConnector: e,
  showIcon: n,
  label: r
}) {
  const s = K.deriveToolStatus(t), a = s === "running" ? Qi : s === "failed" ? pu : Yi;
  return /* @__PURE__ */ u.jsx(Ns, { showIcon: n, showConnector: e, icon: a, children: /* @__PURE__ */ u.jsx(zb, { part: t, label: r }) });
}
function zb({ part: t, label: e }) {
  const [n, r] = y.useState(!1), s = ln(t.input) ? t.input : void 0, a = K.extractToolOutputText(t), i = s && Object.keys(s).length > 0, o = !!a, l = i || o, c = y.useMemo(
    () => n && a ? Hb(a) : void 0,
    [n, a]
  ), d = y.useMemo(
    () => K.extractPieceNames(s),
    [s]
  ), { summaries: p } = ar.usePieceSummariesByNames({
    names: d
  }), h = Ub({ part: t }), m = e ?? h.label, f = p.find((g) => g.logoUrl);
  return /* @__PURE__ */ u.jsxs(fo, { open: n, onOpenChange: r, children: [
    /* @__PURE__ */ u.jsxs(
      "div",
      {
        className: $(
          "inline-flex items-center gap-1.5 rounded-md border border-border bg-background px-2.5 py-1",
          l && "cursor-pointer hover:bg-muted/50 transition-colors"
        ),
        onClick: () => l && r(!n),
        children: [
          f ? /* @__PURE__ */ u.jsx(
            du,
            {
              displayName: f.displayName,
              logoUrl: f.logoUrl,
              size: "xxs",
              border: !1,
              showTooltip: !1
            }
          ) : /* @__PURE__ */ u.jsx(h.icon, { className: "size-3 text-muted-foreground shrink-0" }),
          /* @__PURE__ */ u.jsx("span", { className: "text-xs text-muted-foreground whitespace-nowrap", children: m }),
          l && /* @__PURE__ */ u.jsx(
            on,
            {
              className: $(
                "size-3 shrink-0 text-muted-foreground/50 transition-transform",
                n && "rotate-180"
              )
            }
          )
        ]
      }
    ),
    l && /* @__PURE__ */ u.jsx(mo, { className: "data-[state=closed]:animate-collapsible-up data-[state=open]:animate-collapsible-down overflow-hidden", children: /* @__PURE__ */ u.jsxs("div", { className: "mt-1.5 space-y-1.5 text-[11px]", children: [
      i && s && /* @__PURE__ */ u.jsxs("div", { children: [
        /* @__PURE__ */ u.jsx("p", { className: "text-muted-foreground font-medium mb-0.5", children: A("Input") }),
        /* @__PURE__ */ u.jsx(
          va,
          {
            data: s,
            hideCopyButton: !0,
            maxHeight: 100,
            fontSize: "11px"
          }
        )
      ] }),
      o && c !== void 0 && /* @__PURE__ */ u.jsxs("div", { children: [
        /* @__PURE__ */ u.jsx("p", { className: "text-muted-foreground font-medium mb-0.5", children: A("Output") }),
        /* @__PURE__ */ u.jsx(
          va,
          {
            data: c,
            hideCopyButton: !0,
            maxHeight: 120,
            fontSize: "11px"
          }
        )
      ] })
    ] }) })
  ] });
}
function Ub({ part: t }) {
  const e = K.getToolPartName(t);
  return { icon: e === "ap_run_one_time_action" ? Xi : e.startsWith("mcp__") ? Yi : Ki, label: ct.formatToolActionName({ part: t }) };
}
function Hb(t) {
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}
function qb(t) {
  return t === xt.ACTIVE;
}
function Wb(t) {
  return t === xt.ERROR ? A("Expired") : t === xt.MISSING ? A("Missing") : null;
}
function Zb({
  pieceName: t,
  connection: e,
  displayName: n
}) {
  return /* @__PURE__ */ u.jsx(
    J.div,
    {
      className: "rounded-xl border bg-background overflow-hidden my-2",
      initial: { opacity: 0, scale: 0.98 },
      animate: { opacity: 1, scale: 1 },
      transition: { duration: 0.2 },
      children: /* @__PURE__ */ u.jsxs("div", { className: "p-4 flex items-center gap-3", children: [
        /* @__PURE__ */ u.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ u.jsx(
            Dn,
            {
              pieceName: t,
              size: "sm",
              border: !1,
              showTooltip: !1
            }
          ),
          /* @__PURE__ */ u.jsx("div", { className: "absolute -bottom-0.5 -right-0.5 bg-green-500 rounded-full p-0.5", children: /* @__PURE__ */ u.jsx(we, { className: "h-2 w-2 text-white" }) })
        ] }),
        /* @__PURE__ */ u.jsxs("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ u.jsx("div", { className: "text-sm font-semibold", children: e.label }),
          /* @__PURE__ */ u.jsx("div", { className: "text-xs text-muted-foreground", children: A("Using this {name} account", { name: n }) })
        ] })
      ] })
    }
  );
}
function Vb({
  connections: t,
  pieceName: e,
  enabled: n
}) {
  const [r, s] = y.useState(
    {}
  ), [a, i] = y.useState(!1), o = y.useRef({}), l = y.useMemo(
    () => [...new Set(t.map((c) => c.projectId))].sort().join(","),
    [t]
  );
  return y.useEffect(() => {
    if (!n || !l) return;
    let c = !1;
    i(!0);
    const d = l.split(",");
    return Promise.all(
      d.map(async (p) => {
        const h = p || to.getProjectId();
        return h ? (await no.list({
          projectId: h,
          pieceName: e,
          limit: 100
        })).data : [];
      })
    ).then((p) => {
      if (c) return;
      const h = {}, m = {};
      for (const f of p)
        for (const g of f)
          h[g.externalId] = g.status, m[g.externalId] = g;
      o.current = m, s(h), i(!1);
    }).catch(() => {
      c || i(!1);
    }), () => {
      c = !0;
    };
  }, [l, e, n]), { statuses: r, fullConnections: o.current, isLoading: a };
}
function Jb({
  picker: t,
  onSelect: e,
  isInteractive: n = !0,
  selectedProjectId: r
}) {
  const s = ir(), a = sr(t.piece), i = y.useMemo(() => {
    if (!r) return t;
    const k = t.connections.filter(
      (S) => S.projectId === r
    );
    return { ...t, connections: k };
  }, [t, r]), { pieceModel: o, isLoading: l } = ar.usePiece({
    name: a
  }), [c, d] = y.useState(!1), [p, h] = y.useState(null), [m, f] = y.useState(null), {
    statuses: g,
    fullConnections: b,
    isLoading: v
  } = Vb({
    connections: i.connections,
    pieceName: a,
    enabled: n && !m
  }), w = (k) => {
    const S = b[k];
    S && (h(S), d(!0));
  }, x = () => {
    h(null), d(!0);
  };
  return m ? /* @__PURE__ */ u.jsx(
    Zb,
    {
      pieceName: a,
      connection: m,
      displayName: i.displayName
    }
  ) : n ? /* @__PURE__ */ u.jsxs(u.Fragment, { children: [
    /* @__PURE__ */ u.jsxs(
      J.div,
      {
        className: "rounded-xl border bg-background overflow-hidden my-2",
        initial: { opacity: 0, y: 12 },
        animate: { opacity: 1, y: 0 },
        transition: {
          duration: 0.3,
          type: "spring",
          stiffness: 300,
          damping: 25
        },
        children: [
          /* @__PURE__ */ u.jsx("div", { className: "p-4 pb-3", children: /* @__PURE__ */ u.jsx("h3", { className: "font-semibold text-base", children: A("Which {name} account should I use?", {
            name: i.displayName
          }) }) }),
          /* @__PURE__ */ u.jsx("div", { className: "max-h-64 overflow-auto", children: i.connections.map((k) => {
            const S = g[k.externalId] ?? k.status, N = qb(S);
            return /* @__PURE__ */ u.jsxs(
              "div",
              {
                className: "flex items-center gap-3 px-4 py-3 border-t",
                children: [
                  /* @__PURE__ */ u.jsx(
                    Dn,
                    {
                      pieceName: a,
                      size: "sm",
                      border: !1,
                      showTooltip: !1
                    }
                  ),
                  /* @__PURE__ */ u.jsxs("div", { className: "flex-1 min-w-0", children: [
                    /* @__PURE__ */ u.jsx("div", { className: "text-sm font-medium truncate", children: k.label }),
                    /* @__PURE__ */ u.jsx("div", { className: "text-xs text-muted-foreground", children: N ? k.project : `${k.project} · ${Wb(S)}` })
                  ] }),
                  N ? /* @__PURE__ */ u.jsx(
                    V,
                    {
                      size: "sm",
                      variant: "outline",
                      className: "shrink-0",
                      onClick: () => {
                        f(k), e(
                          `Use "${k.label}" from ${k.project} (${k.externalId}).`
                        );
                      },
                      children: A("Use")
                    }
                  ) : S === xt.MISSING ? /* @__PURE__ */ u.jsxs(
                    V,
                    {
                      size: "sm",
                      variant: "outline",
                      className: "shrink-0 gap-1.5",
                      disabled: l,
                      onClick: x,
                      children: [
                        /* @__PURE__ */ u.jsx(Yr, { className: "h-3 w-3" }),
                        A("Connect")
                      ]
                    }
                  ) : /* @__PURE__ */ u.jsxs(
                    V,
                    {
                      size: "sm",
                      variant: "outline",
                      className: "shrink-0 gap-1.5",
                      disabled: l || v,
                      onClick: () => w(k.externalId),
                      children: [
                        /* @__PURE__ */ u.jsx(Ls, { className: "h-3 w-3" }),
                        A("Reconnect & Use")
                      ]
                    }
                  )
                ]
              },
              k.externalId
            );
          }) }),
          /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-3 px-4 py-3 border-t bg-muted/30", children: [
            /* @__PURE__ */ u.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ u.jsx("div", { className: "text-sm font-medium", children: A("Use a different account") }),
              /* @__PURE__ */ u.jsx("div", { className: "text-xs text-muted-foreground", children: A("Connect a new {name} account", {
                name: i.displayName
              }) })
            ] }),
            /* @__PURE__ */ u.jsxs(
              V,
              {
                size: "sm",
                className: "shrink-0 gap-1.5",
                disabled: l,
                onClick: x,
                children: [
                  /* @__PURE__ */ u.jsx(Yr, { className: "h-3.5 w-3.5" }),
                  A("Connect")
                ]
              }
            )
          ] })
        ]
      }
    ),
    o && /* @__PURE__ */ u.jsx(
      eo,
      {
        piece: o,
        open: c,
        projectId: r,
        setOpen: (k, S) => {
          d(k), S && (s.invalidateQueries({
            queryKey: ["app-connections"]
          }), f({
            label: S.displayName,
            project: "",
            externalId: S.externalId,
            projectId: "",
            status: xt.ACTIVE
          }), e(`Connected ${S.displayName}`));
        },
        reconnectConnection: p,
        isGlobalConnection: !1
      }
    )
  ] }) : /* @__PURE__ */ u.jsx(
    J.div,
    {
      className: "rounded-xl border bg-background overflow-hidden my-2",
      initial: { opacity: 0, scale: 0.98 },
      animate: { opacity: 1, scale: 1 },
      transition: { duration: 0.2 },
      children: /* @__PURE__ */ u.jsxs("div", { className: "p-4 flex items-center gap-3", children: [
        /* @__PURE__ */ u.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ u.jsx(
            Dn,
            {
              pieceName: a,
              size: "sm",
              border: !1,
              showTooltip: !1
            }
          ),
          /* @__PURE__ */ u.jsx("div", { className: "absolute -bottom-0.5 -right-0.5 bg-green-500 rounded-full p-0.5", children: /* @__PURE__ */ u.jsx(we, { className: "h-2 w-2 text-white" }) })
        ] }),
        /* @__PURE__ */ u.jsxs("div", { className: "flex-1 min-w-0", children: [
          /* @__PURE__ */ u.jsx("div", { className: "text-sm font-semibold", children: A("Which {name} account should I use?", {
            name: i.displayName
          }) }),
          /* @__PURE__ */ u.jsx("div", { className: "text-xs text-muted-foreground", children: A("Connected") })
        ] })
      ] })
    }
  );
}
function Qb({
  connections: t,
  onSend: e,
  projectId: n
}) {
  const r = ir(), [s, a] = y.useState(/* @__PURE__ */ new Set()), [i, o] = y.useState({}), [l, c] = y.useState(null), [d, p] = y.useState(!1), h = l ? sr(l.piece) : null, { pieceModel: m } = ar.usePiece({
    name: h ?? "",
    enabled: !!h
  }), f = y.useMemo(
    () => t.map((v) => v.piece).join(","),
    [t]
  );
  y.useEffect(() => {
    const v = n ?? to.getProjectId();
    if (!v) return;
    let w = !1;
    return Promise.all(
      t.map(async (x) => {
        const k = sr(x.piece), S = await no.list({
          projectId: v,
          pieceName: k,
          limit: 1
        });
        return { piece: x.piece, connection: S.data[0] ?? null };
      })
    ).then((x) => {
      if (w) return;
      const k = {}, S = /* @__PURE__ */ new Set(), N = new Set(
        t.filter((C) => C.status === "error").map((C) => C.piece)
      );
      for (const { piece: C, connection: E } of x)
        E && (k[C] = E, E.status === xt.ACTIVE && !N.has(C) && S.add(C));
      o(k), S.size > 0 && a(S), S.size === t.length && p(!0);
    }), () => {
      w = !0;
    };
  }, [f, n]);
  const g = t.every((v) => s.has(v.piece));
  function b(v) {
    c(v);
  }
  return /* @__PURE__ */ u.jsxs(u.Fragment, { children: [
    /* @__PURE__ */ u.jsxs(
      J.div,
      {
        className: "rounded-xl border bg-background overflow-hidden my-2",
        initial: { opacity: 0, y: 12 },
        animate: { opacity: 1, y: 0 },
        transition: {
          duration: 0.3,
          type: "spring",
          stiffness: 300,
          damping: 25
        },
        children: [
          t.map((v) => /* @__PURE__ */ u.jsx(
            Yb,
            {
              connection: v,
              isConnected: s.has(v.piece),
              existingConn: i[v.piece] ?? null,
              onConnect: () => b(v)
            },
            v.piece
          )),
          g && /* @__PURE__ */ u.jsx("div", { className: "border-t px-4 py-3 bg-muted/30", children: d ? /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", children: [
            /* @__PURE__ */ u.jsx(we, { className: "h-3.5 w-3.5 text-green-600 dark:text-green-400" }),
            A("All connected")
          ] }) : e && /* @__PURE__ */ u.jsxs(
            V,
            {
              size: "sm",
              className: "gap-1.5",
              onClick: () => {
                p(!0), e(A("All connections are ready, continue building."));
              },
              children: [
                /* @__PURE__ */ u.jsx(we, { className: "h-3.5 w-3.5" }),
                A("Continue")
              ]
            }
          ) })
        ]
      }
    ),
    m && l && /* @__PURE__ */ u.jsx(
      eo,
      {
        piece: m,
        open: !0,
        projectId: n,
        setOpen: (v, w) => {
          v || (w && (a((x) => {
            const k = new Set(x);
            return k.add(l.piece), k;
          }), r.invalidateQueries({
            queryKey: ["app-connections"]
          })), c(null));
        },
        reconnectConnection: i[l.piece] ?? null,
        isGlobalConnection: !1
      },
      l.piece
    )
  ] });
}
function Yb({
  connection: t,
  isConnected: e,
  existingConn: n,
  onConnect: r
}) {
  const s = sr(t.piece), { isLoading: a } = ar.usePiece({ name: s }), i = n !== null && n.status !== xt.ACTIVE;
  return /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-3 px-4 py-3 border-t first:border-t-0", children: [
    /* @__PURE__ */ u.jsx(
      Dn,
      {
        pieceName: s,
        size: "sm",
        border: !1,
        showTooltip: !1
      }
    ),
    /* @__PURE__ */ u.jsxs("div", { className: "flex-1 min-w-0", children: [
      /* @__PURE__ */ u.jsx("div", { className: "text-sm font-medium", children: t.displayName }),
      /* @__PURE__ */ u.jsx("div", { className: "text-xs text-muted-foreground", children: e ? A("Ready to use") : i ? A("Your {name} connection is expired", {
        name: t.displayName
      }) : A("Not connected") })
    ] }),
    e ? /* @__PURE__ */ u.jsx(
      J.span,
      {
        initial: { scale: 0 },
        animate: { scale: 1 },
        transition: { type: "spring", stiffness: 400, damping: 15 },
        className: "shrink-0 flex items-center justify-center",
        children: /* @__PURE__ */ u.jsx(we, { className: "h-5 w-5 text-green-600 dark:text-green-400" })
      }
    ) : /* @__PURE__ */ u.jsx(
      V,
      {
        size: "sm",
        variant: "outline",
        className: "gap-1.5 shrink-0",
        disabled: a,
        onClick: r,
        children: i ? A("Reconnect") : A("Connect")
      }
    )
  ] });
}
const Ec = y.forwardRef(function({ textToCopy: e, className: n, ...r }, s) {
  const [a, i] = y.useState(!1), o = async () => {
    try {
      await navigator.clipboard.writeText(e), i(!0), setTimeout(() => i(!1), 1500);
    } catch {
    }
  };
  return /* @__PURE__ */ u.jsx(
    "button",
    {
      ref: s,
      type: "button",
      ...r,
      onClick: (l) => {
        var c;
        (c = r.onClick) == null || c.call(r, l), l.defaultPrevented || o();
      },
      className: $(
        "flex items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
        n
      ),
      children: a ? /* @__PURE__ */ u.jsx(we, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ u.jsx(hu, { className: "h-3.5 w-3.5" })
    }
  );
});
function Xb({
  stepCount: t,
  updates: e
}) {
  const n = Array.from(
    { length: t },
    () => "pending"
  );
  for (const r of e)
    r.stepIndex >= 0 && r.stepIndex < t && (n[r.stepIndex] = r.status);
  return n;
}
function Kb({
  status: t,
  index: e
}) {
  switch (t) {
    case "done":
      return /* @__PURE__ */ u.jsx("span", { className: "flex h-5 w-5 items-center justify-center rounded-full bg-green-100 dark:bg-green-500/20", children: /* @__PURE__ */ u.jsx(we, { className: "h-3 w-3 text-green-600 dark:text-green-400" }) });
    case "executing":
      return /* @__PURE__ */ u.jsx("span", { className: "flex h-5 w-5 items-center justify-center", children: /* @__PURE__ */ u.jsx(Qi, { className: "h-4 w-4 text-primary animate-spin" }) });
    case "error":
      return /* @__PURE__ */ u.jsx("span", { className: "flex h-5 w-5 items-center justify-center rounded-full bg-destructive/10", children: /* @__PURE__ */ u.jsx(kt, { className: "h-3 w-3 text-destructive" }) });
    default:
      return /* @__PURE__ */ u.jsx("span", { className: "flex h-5 w-5 items-center justify-center rounded-full bg-muted text-muted-foreground/50 text-[10px] font-medium", children: e + 1 });
  }
}
function e0(t) {
  return t.some((e) => e === "error") ? "error" : t.every((e) => e === "done") ? "done" : t.some((e) => e === "executing" || e === "done") ? "executing" : "pending";
}
function t0(t) {
  return t.filter((e) => e === "done").length;
}
function n0({
  progress: t,
  updates: e,
  currentActivity: n,
  isStreaming: r = !1
}) {
  const s = y.useMemo(
    () => Xb({
      stepCount: t.steps.length,
      updates: e
    }),
    [t.steps.length, e]
  ), a = e0(s), i = r && a === "done" ? "executing" : a, o = t0(s), l = t.steps.length;
  return /* @__PURE__ */ u.jsxs(
    J.div,
    {
      className: "rounded-xl border bg-background overflow-hidden my-2",
      initial: { opacity: 0, y: 12 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.3 },
      children: [
        /* @__PURE__ */ u.jsx("div", { className: "px-3.5 pt-3 pb-2", children: /* @__PURE__ */ u.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
          /* @__PURE__ */ u.jsxs("h3", { className: "font-medium text-xs flex items-center gap-1.5 text-foreground", children: [
            /* @__PURE__ */ u.jsx(go, { className: "h-3.5 w-3.5 text-muted-foreground" }),
            t.title
          ] }),
          i === "done" ? /* @__PURE__ */ u.jsxs("span", { className: "inline-flex items-center gap-1 text-green-600 dark:text-green-400 text-xs font-medium", children: [
            /* @__PURE__ */ u.jsx(we, { className: "h-3 w-3" }),
            A("Done")
          ] }) : i === "error" ? /* @__PURE__ */ u.jsxs("span", { className: "inline-flex items-center gap-1 text-destructive text-xs font-medium", children: [
            /* @__PURE__ */ u.jsx(kt, { className: "h-3 w-3" }),
            A("Error")
          ] }) : i === "executing" ? /* @__PURE__ */ u.jsxs("span", { className: "text-xs text-muted-foreground", children: [
            o,
            "/",
            l
          ] }) : null
        ] }) }),
        /* @__PURE__ */ u.jsx("div", { className: "px-3.5 pb-3", children: /* @__PURE__ */ u.jsx("div", { className: "flex flex-col gap-0.5", children: t.steps.map((c, d) => {
          const p = s[d];
          return /* @__PURE__ */ u.jsxs("div", { children: [
            /* @__PURE__ */ u.jsxs(
              J.div,
              {
                className: "flex items-center gap-2.5 py-1 px-1 rounded-md",
                initial: !1,
                animate: {
                  backgroundColor: p === "executing" ? "var(--color-primary-50, rgba(99,102,241,0.05))" : "transparent"
                },
                transition: { duration: 0.2 },
                children: [
                  /* @__PURE__ */ u.jsx(Kb, { status: p, index: d }),
                  /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
                    /* @__PURE__ */ u.jsx(
                      "span",
                      {
                        className: $(
                          "text-xs transition-all duration-200",
                          p === "done" && "line-through text-muted-foreground",
                          p === "executing" && "font-medium text-foreground",
                          p === "error" && "text-destructive",
                          p === "pending" && "text-muted-foreground"
                        ),
                        children: c
                      }
                    ),
                    p === "executing" && /* @__PURE__ */ u.jsx("span", { className: "text-[11px] text-primary font-medium shrink-0", children: A("Running") })
                  ] })
                ]
              }
            ),
            /* @__PURE__ */ u.jsx(On, { children: p === "executing" && n && /* @__PURE__ */ u.jsx(
              J.div,
              {
                className: "ml-8 mt-0.5 mb-1",
                initial: { opacity: 0, height: 0 },
                animate: { opacity: 1, height: "auto" },
                exit: { opacity: 0, height: 0 },
                transition: { duration: 0.2 },
                children: /* @__PURE__ */ u.jsx(
                  ha,
                  {
                    className: "text-[11px] text-muted-foreground",
                    duration: 3,
                    children: n
                  }
                )
              }
            ) })
          ] }, d);
        }) }) })
      ]
    }
  );
}
function r0({
  picker: t,
  onSelect: e,
  isInteractive: n = !0,
  selectedProjectId: r
}) {
  var m, f;
  const { data: s } = fu.useAll(), { data: a } = mu.useCurrentUser(), i = y.useMemo(() => {
    const g = s ?? [];
    return a ? g.filter(
      (b) => b.type !== gu.PERSONAL || b.ownerId === a.id
    ) : g;
  }, [s, a]), [o, l] = y.useState(null), [c, d] = y.useState(!1), p = t.suggestedProjects ?? [];
  function h(g, b) {
    l(g), e(g, b);
  }
  if (o || !n) {
    const g = o ?? r, b = g ? i.find((w) => w.id === g) : null, v = b ? it(b) : g ? ((m = p.find((w) => w.id === g)) == null ? void 0 : m.name) ?? "" : ((f = p[0]) == null ? void 0 : f.name) ?? "";
    return /* @__PURE__ */ u.jsx(
      J.div,
      {
        className: "rounded-xl border bg-background overflow-hidden my-2",
        initial: { opacity: 0, scale: 0.98 },
        animate: { opacity: 1, scale: 1 },
        transition: { duration: 0.2 },
        children: /* @__PURE__ */ u.jsxs("div", { className: "p-4 flex items-center gap-3", children: [
          /* @__PURE__ */ u.jsx("div", { className: "relative", children: b ? /* @__PURE__ */ u.jsx(
            Tr,
            {
              title: it(b),
              icon: b.icon,
              projectType: b.type,
              iconClassName: "size-5",
              titleClassName: "text-sm font-semibold"
            }
          ) : v && /* @__PURE__ */ u.jsx("span", { className: "text-sm font-semibold", children: v }) }),
          /* @__PURE__ */ u.jsx("div", { className: "ml-auto", children: /* @__PURE__ */ u.jsx("div", { className: "bg-green-100 dark:bg-green-500/20 rounded-full p-1", children: /* @__PURE__ */ u.jsx(we, { className: "h-3 w-3 text-green-600 dark:text-green-400" }) }) })
        ] })
      }
    );
  }
  return /* @__PURE__ */ u.jsxs(
    J.div,
    {
      className: "flex flex-wrap gap-2 my-2",
      initial: { opacity: 0, y: 8 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.25 },
      children: [
        p.filter((g) => i.some((b) => b.id === g.id)).map((g, b) => {
          const v = i.find((w) => w.id === g.id);
          return /* @__PURE__ */ u.jsx(
            J.button,
            {
              type: "button",
              onClick: () => h(
                g.id,
                v ? it(v) : g.name
              ),
              className: "inline-flex items-center gap-2 rounded-full border bg-background px-3 py-1.5 text-sm hover:bg-muted transition-colors cursor-pointer",
              initial: { opacity: 0, y: 6 },
              animate: { opacity: 1, y: 0 },
              transition: { duration: 0.2, delay: b * 0.04 },
              children: v ? /* @__PURE__ */ u.jsx(
                Tr,
                {
                  title: it(v),
                  icon: v.icon,
                  projectType: v.type,
                  iconClassName: "size-4",
                  titleClassName: "text-sm"
                }
              ) : /* @__PURE__ */ u.jsx("span", { children: g.name })
            },
            g.id
          );
        }),
        /* @__PURE__ */ u.jsxs(ro, { open: c, onOpenChange: d, children: [
          /* @__PURE__ */ u.jsx(so, { asChild: !0, children: /* @__PURE__ */ u.jsxs(
            J.button,
            {
              type: "button",
              className: "inline-flex items-center gap-1.5 rounded-full border border-dashed bg-background px-3 py-1.5 text-sm text-muted-foreground hover:bg-muted hover:text-foreground transition-colors cursor-pointer",
              initial: { opacity: 0, y: 6 },
              animate: { opacity: 1, y: 0 },
              transition: {
                duration: 0.2,
                delay: p.length * 0.04
              },
              children: [
                /* @__PURE__ */ u.jsx(ao, { className: "size-3.5" }),
                A("Another project")
              ]
            }
          ) }),
          /* @__PURE__ */ u.jsx(io, { className: "p-0 w-72", align: "start", children: /* @__PURE__ */ u.jsxs(yu, { children: [
            /* @__PURE__ */ u.jsx(xu, { placeholder: A("Search projects...") }),
            /* @__PURE__ */ u.jsx(bu, { children: A("No project found.") }),
            /* @__PURE__ */ u.jsx(wu, { className: "max-h-64 overflow-auto", children: i.map((g) => /* @__PURE__ */ u.jsxs(
              ku,
              {
                value: it(g),
                onSelect: () => {
                  h(g.id, it(g)), d(!1);
                },
                className: "cursor-pointer gap-2",
                children: [
                  /* @__PURE__ */ u.jsx(
                    Tr,
                    {
                      title: it(g),
                      icon: g.icon,
                      projectType: g.type,
                      iconClassName: "size-4"
                    }
                  ),
                  /* @__PURE__ */ u.jsx(
                    we,
                    {
                      className: $(
                        "ml-auto size-4",
                        r === g.id ? "opacity-100" : "opacity-0"
                      )
                    }
                  )
                ]
              },
              g.id
            )) })
          ] }) })
        ] })
      ]
    }
  );
}
const s0 = "max-w-none break-words text-sm [&_p]:mb-4 [&_p:last-child]:mb-0 [&_table]:mb-4 [&_h1]:text-[18px] [&_h2]:text-[18px] [&_h3]:text-[18px]", Di = "flex h-6 w-6 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground", a0 = y.memo(function({
  message: e,
  isStreaming: n,
  isLastMessage: r = !1,
  onRetry: s,
  onSend: a,
  lastAssistantMessage: i
}) {
  const { blocks: o, hasContent: l } = y.useMemo(() => {
    const x = [];
    let k = null, S = !1, N = null;
    function C() {
      k && (k.steps.length > 0 || k.reasoningText.length > 0) && x.push({ kind: "thinking", ...k }), k = null;
    }
    function E() {
      return k || (k = { steps: [], reasoningText: "" }), k;
    }
    for (let R = 0; R < e.parts.length; R++) {
      const I = e.parts[R];
      if (I.type === "text" && I.text.length > 0)
        C(), S = !0, x.push({ kind: "text", text: I.text });
      else if (I.type === "reasoning") {
        const j = E();
        j.reasoningText += I.text;
        const U = I.text.trim();
        U && j.steps.push({ kind: "reasoning", text: U });
      } else if (K.isAnyToolPart(I)) {
        const j = K.getToolPartName(I);
        if (K.isThinkingStatusTool(j)) {
          const U = I.input, L = ((U == null ? void 0 : U.status) ?? "").trim();
          L && (E().steps.push({
            kind: "thinking-status",
            text: L
          }), N = L);
          continue;
        }
        if (K.HIDDEN_TOOL_NAMES.has(j))
          continue;
        if (K.isDisplayTool(j))
          C(), x.push({ kind: "display-tool", part: I });
        else if (j === "ap_request_plan_approval")
          C(), x.push({ kind: "plan-marker", part: I });
        else {
          const U = E(), L = U.steps[U.steps.length - 1];
          N && (L == null ? void 0 : L.kind) === "thinking-status" && L.text === N ? U.steps[U.steps.length - 1] = {
            ...L,
            toolPart: I
          } : U.steps.push({ kind: "tool", part: I }), N = null;
        }
      }
    }
    C();
    const O = x.findLastIndex(
      (R) => R.kind === "display-tool"
    );
    if (O > -1)
      for (let R = x.length - 1; R >= 0; R--)
        x[R].kind === "display-tool" && R !== O && x.splice(R, 1);
    return n && !x.some((R) => R.kind === "thinking") && x.length === 0 && x.push({ kind: "thinking", steps: [], reasoningText: "" }), { blocks: x, hasContent: S };
  }, [e.parts, n]), c = y.useMemo(
    () => n ? "" : da(e.parts),
    [n, e.parts]
  ), { isSpeaking: d, isSupported: p, speak: h, stop: m } = Fb(), f = o.some((x) => x.kind === "plan-marker"), g = o.some(
    (x) => x.kind !== "plan-marker" && x.kind !== "thinking"
  ), b = o.some((x) => x.kind === "thinking");
  if (!l && !g && !n && !f && !b)
    return null;
  const v = e.id.startsWith("hist-"), w = o.findLastIndex((x) => x.kind === "thinking");
  return /* @__PURE__ */ u.jsx(
    J.div,
    {
      className: "py-3 group/msg",
      initial: v ? !1 : { opacity: 0, y: 10 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.3 },
      children: /* @__PURE__ */ u.jsx(Ic, { children: /* @__PURE__ */ u.jsxs("div", { className: "min-w-0 space-y-2 flex-1", children: [
        o.map((x, k) => {
          switch (x.kind) {
            case "thinking":
              return /* @__PURE__ */ u.jsx(
                Gb,
                {
                  thinkingSteps: x.steps,
                  reasoningText: x.reasoningText,
                  isStreaming: n && k === w,
                  thinkingDurationMs: k === w ? e.thinkingDurationMs : void 0
                },
                `thinking-${k}`
              );
            case "text":
              return /* @__PURE__ */ u.jsx("div", { className: s0, children: /* @__PURE__ */ u.jsx(pa, { children: x.text }) }, `text-${k}`);
            case "display-tool":
              return n ? null : /* @__PURE__ */ u.jsx(
                o0,
                {
                  part: x.part,
                  onSend: a,
                  isInteractive: r
                },
                x.part.toolCallId
              );
            case "plan-marker":
              return /* @__PURE__ */ u.jsx(
                i0,
                {
                  planPart: x.part,
                  lastAssistantMessage: i,
                  isStreaming: n
                },
                `plan-${k}`
              );
            default:
              return null;
          }
        }),
        /* @__PURE__ */ u.jsx(
          Tc,
          {
            className: $(
              "gap-1 transition-opacity",
              r ? "opacity-100" : "opacity-0 group-hover/msg:opacity-100"
            ),
            children: l && !n && /* @__PURE__ */ u.jsxs(u.Fragment, { children: [
              /* @__PURE__ */ u.jsx(Rn, { tooltip: A("Copy"), children: /* @__PURE__ */ u.jsx(Ec, { textToCopy: c, className: "h-6 w-6" }) }),
              p && /* @__PURE__ */ u.jsx(
                Rn,
                {
                  tooltip: d ? A("Stop reading") : A("Read aloud"),
                  children: /* @__PURE__ */ u.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => d ? m() : h(c),
                      className: $(
                        Di,
                        d && "text-foreground"
                      ),
                      children: d ? /* @__PURE__ */ u.jsx(up, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ u.jsx(lp, { className: "h-3.5 w-3.5" })
                    }
                  )
                }
              ),
              /* @__PURE__ */ u.jsx(Rn, { tooltip: A("Regenerate"), children: /* @__PURE__ */ u.jsx(
                "button",
                {
                  type: "button",
                  onClick: s,
                  className: Di,
                  children: /* @__PURE__ */ u.jsx(Ls, { className: "h-3.5 w-3.5" })
                }
              ) })
            ] })
          }
        )
      ] }) })
    }
  );
});
function i0({
  planPart: t,
  lastAssistantMessage: e,
  isStreaming: n
}) {
  const r = ce(
    (c) => ut.planProgress({ state: c, lastAssistantMessage: e })
  ), s = ce(
    (c) => ut.effectivePlanUpdates({ state: c })
  ), a = (() => {
    const c = K.parseTypedToolOutput(
      t,
      "ap_request_plan_approval"
    );
    if (c.state === "success" && !c.data.success) return null;
    const d = t.input, p = (d == null ? void 0 : d.steps) ?? [];
    return p.length === 0 ? null : { title: (d == null ? void 0 : d.planSummary) ?? "", steps: p };
  })(), i = r ?? a, o = !n && (() => {
    const c = K.parseTypedToolOutput(
      t,
      "ap_request_plan_approval"
    );
    return c.state === "success" && c.data.success;
  })(), l = y.useMemo(() => i ? o ? i.steps.map(
    (c, d) => ({ stepIndex: d, status: "done" })
  ) : s : [], [s, i, o]);
  return i ? /* @__PURE__ */ u.jsx(
    n0,
    {
      progress: i,
      updates: l,
      isStreaming: n
    }
  ) : null;
}
function o0({
  part: t,
  onSend: e,
  isInteractive: n
}) {
  if (!K.isReady(t)) return null;
  const r = t.input;
  switch (K.getToolPartName(t)) {
    case "ap_show_connection_required":
      return /* @__PURE__ */ u.jsx(
        Qb,
        {
          connections: [r],
          onSend: e
        }
      );
    case "ap_show_connection_picker":
      return /* @__PURE__ */ u.jsx(
        Jb,
        {
          picker: r,
          onSelect: e,
          isInteractive: n
        }
      );
    case "ap_show_project_picker":
      return /* @__PURE__ */ u.jsx(
        r0,
        {
          picker: r,
          isInteractive: n,
          onSelect: (a, i) => {
            e(`Use ${i}.`);
          }
        }
      );
    default:
      return null;
  }
}
const fa = y.createContext(null);
function l0({
  onFilesAdded: t,
  children: e,
  multiple: n = !0,
  accept: r,
  disabled: s = !1
}) {
  const a = y.useRef(null), [i, o] = y.useState(!1), l = y.useRef(0), c = y.useCallback(
    (p) => {
      const h = Array.from(p);
      t(n ? h : h.slice(0, 1));
    },
    [n, t]
  );
  y.useEffect(() => {
    const p = (g) => {
      g.preventDefault(), g.stopPropagation();
    }, h = (g) => {
      var b;
      p(g), l.current++, (b = g.dataTransfer) != null && b.items.length && o(!0);
    }, m = (g) => {
      p(g), l.current--, l.current === 0 && o(!1);
    }, f = (g) => {
      var b;
      p(g), o(!1), l.current = 0, (b = g.dataTransfer) != null && b.files.length && c(g.dataTransfer.files);
    };
    return window.addEventListener("dragenter", h), window.addEventListener("dragleave", m), window.addEventListener("dragover", p), window.addEventListener("drop", f), () => {
      window.removeEventListener("dragenter", h), window.removeEventListener("dragleave", m), window.removeEventListener("dragover", p), window.removeEventListener("drop", f);
    };
  }, [c, t, n]);
  const d = (p) => {
    var h;
    (h = p.target.files) != null && h.length && (c(p.target.files), p.target.value = "");
  };
  return /* @__PURE__ */ u.jsxs(
    fa.Provider,
    {
      value: { isDragging: i, inputRef: a, multiple: n, disabled: s },
      children: [
        /* @__PURE__ */ u.jsx(
          "input",
          {
            type: "file",
            ref: a,
            onChange: d,
            className: "hidden",
            multiple: n,
            accept: r,
            "aria-hidden": !0,
            disabled: s
          }
        ),
        e
      ]
    }
  );
}
function c0({
  asChild: t = !1,
  className: e,
  children: n,
  ...r
}) {
  const s = y.useContext(fa), a = () => {
    var i;
    return (i = s == null ? void 0 : s.inputRef.current) == null ? void 0 : i.click();
  };
  if (t) {
    const i = y.Children.only(n);
    return y.cloneElement(i, {
      ...r,
      role: "button",
      className: $(e, i.props.className),
      onClick: (o) => {
        var l, c;
        o.stopPropagation(), a(), (c = (l = i.props).onClick) == null || c.call(l, o);
      }
    });
  }
  return /* @__PURE__ */ u.jsx(
    "button",
    {
      type: "button",
      className: e,
      onClick: a,
      ...r,
      children: n
    }
  );
}
function u0({ className: t, ...e }) {
  const n = y.useContext(fa), [r, s] = y.useState(!1);
  if (y.useEffect(() => (s(!0), () => s(!1)), []), !(n != null && n.isDragging) || !r || n != null && n.disabled)
    return null;
  const a = /* @__PURE__ */ u.jsx(
    "div",
    {
      className: $(
        "bg-background/80 fixed inset-0 z-50 flex items-center justify-center backdrop-blur-sm",
        "animate-in fade-in-0 slide-in-from-bottom-10 zoom-in-90 duration-150",
        t
      ),
      ...e
    }
  );
  return vu.createPortal(a, _u.getPortalContainer() ?? document.body);
}
const jc = y.createContext({
  isLoading: !1,
  value: "",
  setValue: () => {
  },
  maxHeight: 240,
  onSubmit: void 0,
  disabled: !1,
  textareaRef: Vi.createRef()
});
function Rc() {
  return y.useContext(jc);
}
function p0({
  className: t,
  isLoading: e = !1,
  maxHeight: n = 240,
  value: r,
  onValueChange: s,
  onSubmit: a,
  children: i,
  disabled: o = !1,
  onClick: l,
  ...c
}) {
  const [d, p] = y.useState(r || ""), h = y.useRef(null), m = (g) => {
    p(g), s == null || s(g);
  }, f = (g) => {
    var b;
    o || (b = h.current) == null || b.focus(), l == null || l(g);
  };
  return /* @__PURE__ */ u.jsx(js, { children: /* @__PURE__ */ u.jsx(
    jc.Provider,
    {
      value: {
        isLoading: e,
        value: r ?? d,
        setValue: s ?? m,
        maxHeight: n,
        onSubmit: a,
        disabled: o,
        textareaRef: h
      },
      children: /* @__PURE__ */ u.jsx(
        "div",
        {
          onClick: f,
          className: $(
            "border-input bg-background cursor-text rounded-3xl border p-2 shadow-xs",
            o && "cursor-not-allowed opacity-60",
            t
          ),
          ...c,
          children: i
        }
      )
    }
  ) });
}
function d0({
  className: t,
  onKeyDown: e,
  disableAutosize: n = !1,
  ...r
}) {
  const { value: s, setValue: a, maxHeight: i, onSubmit: o, disabled: l, textareaRef: c } = Rc(), d = (f) => {
    !f || n || (f.style.height = "auto", typeof i == "number" ? f.style.height = `${Math.min(f.scrollHeight, i)}px` : f.style.height = `min(${f.scrollHeight}px, ${i})`);
  }, p = (f) => {
    c.current = f, d(f);
  };
  y.useLayoutEffect(() => {
    if (!c.current || n) return;
    const f = c.current;
    f.style.height = "auto", typeof i == "number" ? f.style.height = `${Math.min(f.scrollHeight, i)}px` : f.style.height = `min(${f.scrollHeight}px, ${i})`;
  }, [s, i, n]);
  const h = (f) => {
    d(f.target), a(f.target.value);
  }, m = (f) => {
    f.key === "Enter" && !f.shiftKey && (f.preventDefault(), o == null || o()), e == null || e(f);
  };
  return /* @__PURE__ */ u.jsx(
    Su,
    {
      ref: p,
      value: s,
      onChange: h,
      onKeyDown: m,
      className: $(
        "text-foreground min-h-[44px] w-full resize-none border-none bg-transparent shadow-none outline-none focus-visible:ring-0 focus-visible:ring-offset-0",
        t
      ),
      rows: 1,
      disabled: l,
      ...r
    }
  );
}
function h0({
  children: t,
  className: e,
  ...n
}) {
  return /* @__PURE__ */ u.jsx("div", { className: $("flex items-center gap-2", e), ...n, children: t });
}
function It({
  tooltip: t,
  children: e,
  className: n,
  side: r = "top",
  ...s
}) {
  const { disabled: a } = Rc();
  return /* @__PURE__ */ u.jsxs(Ji, { ...s, children: [
    /* @__PURE__ */ u.jsx(
      Rs,
      {
        asChild: !0,
        disabled: a,
        onClick: (i) => i.stopPropagation(),
        children: e
      }
    ),
    /* @__PURE__ */ u.jsx(Ps, { side: r, className: n, children: t })
  ] });
}
const f0 = [
  { duration: "0.8s", delay: "0s" },
  { duration: "0.6s", delay: "0.15s" },
  { duration: "0.9s", delay: "0.05s" },
  { duration: "0.7s", delay: "0.2s" },
  { duration: "0.85s", delay: "0.1s" }
];
function m0() {
  return /* @__PURE__ */ u.jsx("div", { className: "flex h-3.5 items-center gap-[2px]", children: f0.map((t, e) => /* @__PURE__ */ u.jsx(
    "span",
    {
      className: "w-[3px] h-full rounded-full bg-foreground origin-center animate-[voice-bar_ease-in-out_infinite_alternate]",
      style: {
        animationDuration: t.duration,
        animationDelay: t.delay
      }
    },
    e
  )) });
}
function g0() {
  const t = globalThis;
  return t.SpeechRecognition ? t.SpeechRecognition : t.webkitSpeechRecognition ? t.webkitSpeechRecognition : null;
}
const Jr = g0();
function Pc({
  frequency: t,
  duration: e,
  ramp: n
}) {
  const r = new AudioContext(), s = r.createOscillator(), a = r.createGain();
  s.type = "sine", s.frequency.value = t, s.connect(a), a.connect(r.destination), a.gain.setValueAtTime(0.15, r.currentTime), n === "up" ? s.frequency.linearRampToValueAtTime(
    t * 1.3,
    r.currentTime + e
  ) : s.frequency.linearRampToValueAtTime(
    t * 0.7,
    r.currentTime + e
  ), a.gain.exponentialRampToValueAtTime(1e-3, r.currentTime + e), s.start(), s.stop(r.currentTime + e), s.onended = () => r.close();
}
function y0() {
  Pc({ frequency: 600, duration: 0.15, ramp: "up" });
}
function x0() {
  Pc({ frequency: 500, duration: 0.12, ramp: "down" });
}
function b0({
  onTranscript: t,
  onInterim: e,
  onError: n
}) {
  const [r, s] = y.useState(!1), a = y.useRef(null), i = y.useRef(""), o = y.useRef(!1), l = y.useCallback(() => {
    a.current && (o.current = !1, a.current.stop());
  }, []), c = y.useCallback(() => {
    a.current && (o.current = !0, a.current.stop());
  }, []), d = y.useCallback(() => {
    if (!Jr) {
      n("Voice input is not available in this browser.");
      return;
    }
    i.current = "", o.current = !1;
    const p = new Jr();
    p.continuous = !0, p.interimResults = !0, p.lang = navigator.language, p.onresult = (h) => {
      let m = "";
      for (let f = h.resultIndex; f < h.results.length; f++) {
        const g = h.results[f];
        g.isFinal ? i.current += g[0].transcript : m += g[0].transcript;
      }
      e(i.current + m);
    }, p.onerror = (h) => {
      h.error !== "aborted" && h.error !== "no-speech" && n("Could not access microphone. Check browser permissions."), s(!1), a.current = null;
    }, p.onend = () => {
      if (!o.current) {
        x0();
        const h = i.current.trim();
        h && t(h);
      }
      s(!1), a.current = null, o.current = !1;
    }, a.current = p, p.start(), y0(), s(!0);
  }, [t, e, n]);
  return y.useEffect(() => () => {
    a.current && (a.current.stop(), a.current = null);
  }, []), {
    isRecording: r,
    isSupported: Jr !== null,
    startRecording: d,
    stopRecording: l,
    cancelRecording: c
  };
}
function Lc({
  isStreaming: t,
  onSend: e,
  onStop: n,
  placeholder: r,
  leftActions: s,
  rightActions: a
}) {
  const [i, o] = y.useState(""), [l, c] = y.useState([]), [d, p] = y.useState(""), h = y.useCallback((N) => {
    o((C) => {
      const E = C.length > 0 ? " " : "";
      return C + E + N;
    }), p("");
  }, []), m = y.useCallback((N) => {
    Cu.error(A(N)), p("");
  }, []), {
    isRecording: f,
    isSupported: g,
    startRecording: b,
    stopRecording: v,
    cancelRecording: w
  } = b0({
    onTranscript: h,
    onInterim: p,
    onError: m
  });
  y.useEffect(() => {
    if (!f) return;
    const N = (C) => {
      C.key === "Escape" && (C.preventDefault(), w(), p(""));
    };
    return window.addEventListener("keydown", N), () => window.removeEventListener("keydown", N);
  }, [f, w]);
  const x = y.useCallback(() => {
    !t && (i.trim() || l.length > 0) && (e(
      i.trim(),
      l.length > 0 ? l : void 0
    ), o(""), c([]));
  }, [t, i, l, e]), k = y.useCallback((N) => {
    c((C) => [...C, ...N]);
  }, []), S = i.trim().length > 0 || l.length > 0;
  return /* @__PURE__ */ u.jsxs(l0, { onFilesAdded: k, multiple: !0, children: [
    /* @__PURE__ */ u.jsxs(
      p0,
      {
        isLoading: t,
        value: i,
        onValueChange: o,
        onSubmit: x,
        className: "border-0 rounded-none shadow-none",
        children: [
          l.length > 0 && /* @__PURE__ */ u.jsx("div", { className: "flex flex-wrap gap-2 px-3 pt-2", children: l.map((N) => /* @__PURE__ */ u.jsxs(
            "div",
            {
              className: "flex items-center gap-2 rounded-lg border bg-muted/50 px-3 py-1.5 text-sm",
              onClick: (C) => C.stopPropagation(),
              children: [
                /* @__PURE__ */ u.jsx(An, { className: "size-3.5 shrink-0 text-muted-foreground" }),
                /* @__PURE__ */ u.jsx("span", { className: "max-w-[150px] truncate text-foreground/80", children: N.name }),
                /* @__PURE__ */ u.jsx(
                  "button",
                  {
                    type: "button",
                    onClick: () => c(
                      (C) => C.filter((E) => E.name !== N.name)
                    ),
                    className: "text-muted-foreground hover:text-foreground rounded-full p-0.5 transition-colors",
                    children: /* @__PURE__ */ u.jsx(kt, { className: "size-3.5" })
                  }
                )
              ]
            },
            N.name
          )) }),
          f ? /* @__PURE__ */ u.jsx("div", { className: "min-h-[44px] px-3 py-2 text-sm text-foreground whitespace-pre-wrap break-words", children: d || /* @__PURE__ */ u.jsx("span", { className: "text-muted-foreground", children: A("Listening...") }) }) : /* @__PURE__ */ u.jsx(
            d0,
            {
              autoFocus: !0,
              placeholder: r ?? A("Tell me what you need..."),
              className: "min-h-[44px] text-sm"
            }
          ),
          /* @__PURE__ */ u.jsxs(h0, { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ u.jsx(It, { tooltip: A("Attach files"), children: /* @__PURE__ */ u.jsx(c0, { asChild: !0, children: /* @__PURE__ */ u.jsx("div", { className: "flex h-7 w-7 cursor-pointer items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground", children: /* @__PURE__ */ u.jsx(An, { className: "size-4" }) }) }) }),
              s
            ] }),
            /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-1", children: [
              a,
              t && n ? /* @__PURE__ */ u.jsx(It, { tooltip: A("Stop"), children: /* @__PURE__ */ u.jsx(
                V,
                {
                  variant: "default",
                  size: "icon",
                  className: "h-7 w-7 rounded-full",
                  onClick: n,
                  children: /* @__PURE__ */ u.jsx(bo, { className: "size-3 fill-current" })
                }
              ) }) : f ? /* @__PURE__ */ u.jsx(It, { tooltip: A("Stop recording"), children: /* @__PURE__ */ u.jsxs(
                V,
                {
                  variant: "outline",
                  className: "h-7 gap-1.5 rounded-full px-3",
                  onClick: v,
                  children: [
                    /* @__PURE__ */ u.jsx(m0, {}),
                    /* @__PURE__ */ u.jsx("span", { className: "text-xs font-medium", children: A("Stop") })
                  ]
                }
              ) }) : S ? /* @__PURE__ */ u.jsx(It, { tooltip: A("Send message"), children: /* @__PURE__ */ u.jsx(
                V,
                {
                  variant: "default",
                  size: "icon",
                  className: "h-7 w-7 rounded-full",
                  onClick: x,
                  disabled: t,
                  children: /* @__PURE__ */ u.jsx(Xr, { className: "size-4" })
                }
              ) }) : g ? /* @__PURE__ */ u.jsx(It, { tooltip: A("Voice input"), children: /* @__PURE__ */ u.jsx(
                "button",
                {
                  type: "button",
                  onClick: b,
                  className: "flex h-7 w-7 cursor-pointer items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
                  children: /* @__PURE__ */ u.jsx(ap, { className: "size-4" })
                }
              ) }) : /* @__PURE__ */ u.jsx(It, { tooltip: A("Send message"), children: /* @__PURE__ */ u.jsx(
                V,
                {
                  variant: "default",
                  size: "icon",
                  className: "h-7 w-7 rounded-full",
                  onClick: x,
                  disabled: !0,
                  children: /* @__PURE__ */ u.jsx(Xr, { className: "size-4" })
                }
              ) })
            ] })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ u.jsx(u0, { children: /* @__PURE__ */ u.jsx("div", { className: "flex min-h-[200px] w-full items-center justify-center backdrop-blur-sm", children: /* @__PURE__ */ u.jsxs("div", { className: "bg-background/90 m-4 w-full max-w-md rounded-lg border p-8 shadow-lg", children: [
      /* @__PURE__ */ u.jsx("div", { className: "mb-4 flex justify-center", children: /* @__PURE__ */ u.jsx(An, { className: "text-muted-foreground size-8" }) }),
      /* @__PURE__ */ u.jsx("h3", { className: "mb-2 text-center text-base font-medium", children: A("Drop files here") }),
      /* @__PURE__ */ u.jsx("p", { className: "text-muted-foreground text-center text-sm", children: A("Release to add files to your message") })
    ] }) }) })
  ] });
}
const Qr = {
  fast: {
    icon: rp,
    displayLabel: "Fast",
    description: "Quick replies for simple tasks"
  },
  smart: {
    icon: oo,
    displayLabel: "Expert",
    description: "Best for everyday use"
  },
  premium: {
    icon: Fu,
    displayLabel: "Heavy",
    description: "Highest quality, a bit slower"
  }
};
function $c({
  selectedModel: t,
  onModelChange: e
}) {
  const [n, r] = y.useState(!1), [s, a] = y.useState(-1), i = y.useRef(null), o = t ?? "smart", l = Qr[o] ?? Qr.smart;
  y.useEffect(() => {
    if (!n) return;
    const d = Ft.findIndex(
      (h) => h.id === o
    );
    a(d >= 0 ? d : 0);
    const p = requestAnimationFrame(() => {
      var h;
      return (h = i.current) == null ? void 0 : h.focus();
    });
    return () => cancelAnimationFrame(p);
  }, [n, o]);
  const c = y.useCallback(
    (d) => {
      if (d.key === "ArrowDown")
        d.preventDefault(), a(
          (p) => p < Ft.length - 1 ? p + 1 : 0
        );
      else if (d.key === "ArrowUp")
        d.preventDefault(), a(
          (p) => p > 0 ? p - 1 : Ft.length - 1
        );
      else if (d.key === "Enter") {
        d.preventDefault();
        const p = Ft[s];
        p && (e(p.id), r(!1));
      }
    },
    [s, e]
  );
  return /* @__PURE__ */ u.jsxs(ro, { open: n, onOpenChange: r, children: [
    /* @__PURE__ */ u.jsx(so, { asChild: !0, children: /* @__PURE__ */ u.jsxs(
      V,
      {
        variant: "ghost",
        size: "sm",
        role: "combobox",
        "aria-expanded": n,
        className: "h-7 gap-1 rounded-full px-2.5 text-xs text-muted-foreground hover:text-foreground",
        children: [
          /* @__PURE__ */ u.jsx("span", { children: A(l.displayLabel) }),
          /* @__PURE__ */ u.jsx(on, { className: "size-3 opacity-50" })
        ]
      }
    ) }),
    /* @__PURE__ */ u.jsx(
      io,
      {
        className: "w-[330px] p-0",
        align: "end",
        side: "top",
        onOpenAutoFocus: (d) => d.preventDefault(),
        children: /* @__PURE__ */ u.jsxs(
          "div",
          {
            ref: i,
            tabIndex: 0,
            onKeyDown: c,
            className: "outline-none",
            children: [
              /* @__PURE__ */ u.jsx("div", { className: "py-1", children: Ft.map((d, p) => {
                const h = Qr[d.id];
                if (!h) return null;
                const m = h.icon, f = o === d.id, g = s === p;
                return /* @__PURE__ */ u.jsxs(
                  "div",
                  {
                    onClick: () => {
                      e(d.id), r(!1);
                    },
                    onMouseEnter: () => a(p),
                    className: $(
                      "flex items-center gap-3 px-3 py-3.5 cursor-pointer transition-colors",
                      g && "bg-accent"
                    ),
                    children: [
                      /* @__PURE__ */ u.jsx("div", { className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border bg-background", children: /* @__PURE__ */ u.jsx(m, { className: "size-4 text-foreground" }) }),
                      /* @__PURE__ */ u.jsxs("div", { className: "flex flex-1 flex-col gap-0.5", children: [
                        /* @__PURE__ */ u.jsx("span", { className: "text-sm font-medium", children: A(h.displayLabel) }),
                        /* @__PURE__ */ u.jsx("span", { className: "text-xs text-muted-foreground", children: A(h.description) })
                      ] }),
                      /* @__PURE__ */ u.jsx(
                        we,
                        {
                          className: $(
                            "size-4 shrink-0",
                            f ? "opacity-100" : "opacity-0"
                          )
                        }
                      )
                    ]
                  },
                  d.id
                );
              }) }),
              /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-3 border-t px-3 py-2 text-xs text-muted-foreground", children: [
                /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ u.jsx("kbd", { className: "flex h-5 w-5 items-center justify-center rounded border bg-muted", children: /* @__PURE__ */ u.jsx(Xr, { className: "size-3" }) }),
                  /* @__PURE__ */ u.jsx("kbd", { className: "flex h-5 w-5 items-center justify-center rounded border bg-muted", children: /* @__PURE__ */ u.jsx(Nu, { className: "size-3" }) }),
                  /* @__PURE__ */ u.jsx("span", { children: A("to navigate") })
                ] }),
                /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-1", children: [
                  /* @__PURE__ */ u.jsx("kbd", { className: "flex h-5 w-5 items-center justify-center rounded border bg-muted", children: /* @__PURE__ */ u.jsx(Au, { className: "size-3" }) }),
                  /* @__PURE__ */ u.jsx("span", { children: A("to select") })
                ] })
              ] })
            ]
          }
        )
      }
    )
  ] });
}
function w0({
  questions: t,
  onSubmit: e,
  onDismiss: n
}) {
  var Dt;
  const [r, s] = y.useState(0), [a, i] = y.useState({}), [o, l] = y.useState(!1), [c, d] = y.useState(null), [p, h] = y.useState(null), m = y.useId(), f = y.useRef(null), g = y.useRef(null), b = y.useRef(null), v = y.useRef(null), w = y.useRef(null), x = r === t.length - 1, k = ((Dt = a[r]) == null ? void 0 : Dt.trim()) ?? "";
  y.useEffect(() => {
    const T = f.current ?? v.current;
    T && w.current !== T && (T.focus({ preventScroll: !0 }), w.current = T);
  }, [r]);
  function S(T) {
    i((ee) => ({ ...ee, [r]: T }));
  }
  function N(T) {
    f.current = T, T && w.current !== T && (T.focus({ preventScroll: !0 }), w.current = T);
  }
  function C(T) {
    v.current = T, T && w.current !== T && (T.focus({ preventScroll: !0 }), w.current = T);
  }
  function E(T) {
    if ((T ?? k).trim())
      if (T !== void 0 && i((ye) => ({ ...ye, [r]: T })), x) {
        if (o) return;
        const ye = T !== void 0 ? { ...a, [r]: T } : a;
        l(!0);
        const he = t.map((Ae, _t) => {
          var St;
          const Q = (St = ye[_t]) == null ? void 0 : St.trim();
          return Q ? `- **${Ae.question}** ${Q}` : null;
        }).filter((Ae) => Ae !== null);
        if (he.length === 0) {
          n == null || n();
          return;
        }
        e(he.join(`
`));
      } else
        s((ye) => ye + 1);
  }
  function O() {
    if (x) {
      if (o) return;
      const T = t.map((ee, ye) => {
        var Ae;
        const he = (Ae = a[ye]) == null ? void 0 : Ae.trim();
        return he ? `- **${ee.question}** ${he}` : null;
      }).filter((ee) => ee !== null);
      if (T.length === 0) {
        n == null || n();
        return;
      }
      l(!0), e(T.join(`
`));
    } else
      s((T) => T + 1);
  }
  if (o)
    return /* @__PURE__ */ u.jsxs(
      J.div,
      {
        className: "my-3 flex items-center gap-2 text-sm text-muted-foreground",
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        children: [
          /* @__PURE__ */ u.jsx(we, { className: "size-4 text-green-600 dark:text-green-400" }),
          /* @__PURE__ */ u.jsx("span", { children: A("Answers submitted") })
        ]
      }
    );
  const R = t[r];
  if (!R) return null;
  const I = R.type === "choice" && !!R.options && !!a[r] && !R.options.includes(a[r]), j = R.type === "choice" ? R.options ?? [] : [], U = j.findIndex(
    (T) => a[r] === T
  ), L = j.length - 1, H = (T) => c === T || p === T || U === T, ie = c === "custom" || p === "custom" || I, hn = (T) => H(T) || H(T - 1), Ve = H(L) || ie;
  return /* @__PURE__ */ u.jsxs(
    J.div,
    {
      className: "rounded-2xl border border-border/60 bg-background p-5 shadow-[0_12px_40px_-12px_rgba(0,0,0,0.12)] dark:bg-neutral-900 dark:shadow-[0_12px_40px_-12px_rgba(0,0,0,0.45)] backdrop-blur-sm transition-colors",
      initial: { opacity: 0, y: 16, scale: 0.98 },
      animate: { opacity: 1, y: 0, scale: 1 },
      exit: { opacity: 0, y: 8, scale: 0.98 },
      transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
      children: [
        /* @__PURE__ */ u.jsxs("div", { className: "flex items-start justify-between gap-4", children: [
          /* @__PURE__ */ u.jsx("div", { className: "flex-1 min-w-0", children: /* @__PURE__ */ u.jsx(On, { mode: "wait", children: /* @__PURE__ */ u.jsx(
            J.div,
            {
              initial: { opacity: 0, x: 12 },
              animate: { opacity: 1, x: 0 },
              exit: { opacity: 0, x: -12 },
              transition: { duration: 0.2 },
              children: /* @__PURE__ */ u.jsx(
                Kr,
                {
                  htmlFor: m,
                  className: "block text-base font-semibold leading-snug text-foreground",
                  children: R.question
                }
              )
            },
            `q-${r}`
          ) }) }),
          /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-1 text-muted-foreground shrink-0", children: [
            /* @__PURE__ */ u.jsx(
              V,
              {
                variant: "ghost",
                size: "icon",
                className: "h-7 w-7",
                onClick: () => s((T) => T - 1),
                disabled: r === 0,
                "aria-label": A("Back"),
                children: /* @__PURE__ */ u.jsx(Iu, { className: "size-4" })
              }
            ),
            /* @__PURE__ */ u.jsx("span", { className: "text-xs tabular-nums px-1", children: A("{current} of {total}", {
              current: r + 1,
              total: t.length
            }) }),
            /* @__PURE__ */ u.jsx(
              V,
              {
                variant: "ghost",
                size: "icon",
                className: "h-7 w-7",
                onClick: () => E(),
                disabled: !k,
                "aria-label": A("Next"),
                children: /* @__PURE__ */ u.jsx(Tu, { className: "size-4" })
              }
            ),
            /* @__PURE__ */ u.jsx(
              V,
              {
                variant: "ghost",
                size: "icon",
                className: "ms-1 h-7 w-7",
                onClick: n,
                "aria-label": A("Close"),
                children: /* @__PURE__ */ u.jsx(kt, { className: "size-4" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ u.jsx(On, { mode: "wait", children: /* @__PURE__ */ u.jsx(
          J.div,
          {
            initial: { opacity: 0, x: 12 },
            animate: { opacity: 1, x: 0 },
            exit: { opacity: 0, x: -12 },
            transition: { duration: 0.2 },
            className: "mt-4",
            children: /* @__PURE__ */ u.jsxs("div", { children: [
              R.type === "choice" && R.options && /* @__PURE__ */ u.jsxs("div", { children: [
                /* @__PURE__ */ u.jsx(
                  lo,
                  {
                    value: R.options.includes(a[r] ?? "") ? a[r] : "",
                    onValueChange: S,
                    className: "gap-0",
                    children: R.options.map((T, ee) => {
                      const ye = `${m}-opt-${ee}`, he = a[r] === T, Ae = ee === 0, _t = ee === R.options.length - 1;
                      return /* @__PURE__ */ u.jsxs(y.Fragment, { children: [
                        ee > 0 && /* @__PURE__ */ u.jsx("div", { className: "px-3", children: /* @__PURE__ */ u.jsx(
                          es,
                          {
                            className: $(
                              "bg-border/60 transition-opacity duration-150",
                              hn(ee) && "opacity-0"
                            )
                          }
                        ) }),
                        /* @__PURE__ */ u.jsxs(
                          "div",
                          {
                            onClick: () => {
                              E(T);
                            },
                            onMouseEnter: () => h(ee),
                            onMouseLeave: () => h((Q) => Q === ee ? null : Q),
                            onFocus: () => d(ee),
                            onBlur: () => d((Q) => Q === ee ? null : Q),
                            className: $(
                              "group flex items-center gap-3 rounded-xl px-2 py-2 text-sm font-normal cursor-pointer transition-colors hover:bg-muted",
                              c === ee && !he && "bg-muted",
                              he && "bg-muted-foreground/15"
                            ),
                            children: [
                              /* @__PURE__ */ u.jsx(
                                co,
                                {
                                  ref: (Q) => {
                                    Ae && N(Q), _t && (g.current = Q);
                                  },
                                  id: ye,
                                  value: T,
                                  className: "peer sr-only",
                                  onKeyDownCapture: (Q) => {
                                    var fn;
                                    if (Q.key === "Enter") {
                                      Q.preventDefault(), Q.stopPropagation(), E(T);
                                      return;
                                    }
                                    if (Q.key === "ArrowLeft" || Q.key === "ArrowRight") {
                                      Q.preventDefault(), Q.stopPropagation();
                                      return;
                                    }
                                    const St = Q.key === "ArrowDown" && _t, Cr = Q.key === "ArrowUp" && Ae;
                                    (St || Cr) && (Q.preventDefault(), Q.stopPropagation(), S(""), (fn = b.current) == null || fn.focus());
                                  }
                                }
                              ),
                              /* @__PURE__ */ u.jsx(
                                "span",
                                {
                                  "aria-hidden": !0,
                                  className: $(
                                    "flex size-8 shrink-0 items-center justify-center rounded-md bg-muted-foreground/10 text-xs font-medium text-muted-foreground transition-colors peer-focus:bg-foreground peer-focus:text-background",
                                    he && "bg-foreground text-background"
                                  ),
                                  children: ee + 1
                                }
                              ),
                              /* @__PURE__ */ u.jsx("span", { className: "flex-1 leading-snug", children: T })
                            ]
                          }
                        )
                      ] }, T);
                    })
                  }
                ),
                /* @__PURE__ */ u.jsx("div", { className: "px-3", children: /* @__PURE__ */ u.jsx(
                  es,
                  {
                    className: $(
                      "bg-border/60 transition-opacity duration-150",
                      Ve && "opacity-0"
                    )
                  }
                ) }),
                /* @__PURE__ */ u.jsxs(
                  "label",
                  {
                    htmlFor: m,
                    onMouseEnter: () => h("custom"),
                    onMouseLeave: () => h((T) => T === "custom" ? null : T),
                    onFocus: () => d("custom"),
                    onBlur: () => d((T) => T === "custom" ? null : T),
                    className: $(
                      "group flex items-center gap-3 rounded-xl px-2 py-2 text-sm font-normal cursor-text transition-colors hover:bg-muted focus-within:bg-muted",
                      I && "bg-muted"
                    ),
                    children: [
                      /* @__PURE__ */ u.jsx(
                        "span",
                        {
                          "aria-hidden": !0,
                          className: $(
                            "flex size-8 shrink-0 items-center justify-center rounded-md bg-muted-foreground/10 text-muted-foreground transition-colors group-focus-within:bg-foreground group-focus-within:text-background",
                            I && "bg-foreground text-background"
                          ),
                          children: /* @__PURE__ */ u.jsx(ts, { className: "size-3.5" })
                        }
                      ),
                      /* @__PURE__ */ u.jsx(
                        Mn,
                        {
                          ref: b,
                          id: m,
                          className: "h-auto flex-1 min-w-0 border-0 bg-transparent p-0 text-sm shadow-none focus-visible:ring-0 focus-visible:border-0 dark:bg-transparent",
                          placeholder: A("Type your answer..."),
                          value: I ? a[r] : "",
                          onFocus: () => {
                            R.options.includes(a[r] ?? "") && S("");
                          },
                          onChange: (T) => S(T.target.value),
                          onKeyDown: (T) => {
                            var ee, ye;
                            if (T.key === "ArrowUp") {
                              T.preventDefault();
                              const he = R.options[R.options.length - 1];
                              S(he), (ee = g.current) == null || ee.focus();
                              return;
                            }
                            if (T.key === "ArrowDown") {
                              T.preventDefault();
                              const he = R.options[0];
                              S(he), (ye = f.current) == null || ye.focus();
                              return;
                            }
                            T.key === "Enter" && k && (T.preventDefault(), E());
                          }
                        }
                      ),
                      /* @__PURE__ */ u.jsx(
                        V,
                        {
                          type: "button",
                          variant: I ? "default" : "outline",
                          size: I ? "icon" : "sm",
                          className: $(
                            "h-7 shrink-0",
                            I ? "w-7" : "px-2.5 text-sm"
                          ),
                          onClick: () => I ? E() : O(),
                          "aria-label": I ? A("Send") : A("Skip"),
                          children: I ? /* @__PURE__ */ u.jsx(_a, { className: "size-4" }) : A("Skip")
                        }
                      )
                    ]
                  }
                )
              ] }),
              R.type === "text" && /* @__PURE__ */ u.jsxs(
                "label",
                {
                  htmlFor: m,
                  className: $(
                    "group flex items-center gap-3 rounded-xl px-2 py-2 text-sm font-normal cursor-text transition-colors hover:bg-muted focus-within:bg-muted",
                    k && "bg-muted"
                  ),
                  children: [
                    /* @__PURE__ */ u.jsx(
                      "span",
                      {
                        "aria-hidden": !0,
                        className: $(
                          "flex size-8 shrink-0 items-center justify-center rounded-md bg-muted-foreground/10 text-muted-foreground transition-colors group-focus-within:bg-foreground group-focus-within:text-background",
                          k && "bg-foreground text-background"
                        ),
                        children: /* @__PURE__ */ u.jsx(ts, { className: "size-3.5" })
                      }
                    ),
                    /* @__PURE__ */ u.jsx(
                      Mn,
                      {
                        ref: C,
                        id: m,
                        className: "h-auto flex-1 min-w-0 border-0 bg-transparent p-0 text-sm shadow-none focus-visible:ring-0 focus-visible:border-0 dark:bg-transparent",
                        placeholder: R.placeholder,
                        value: a[r] ?? "",
                        onChange: (T) => S(T.target.value),
                        onKeyDown: (T) => {
                          T.key === "Enter" && k && (T.preventDefault(), E());
                        }
                      }
                    ),
                    /* @__PURE__ */ u.jsx(
                      V,
                      {
                        type: "button",
                        variant: k ? "default" : "outline",
                        size: k ? "icon" : "sm",
                        className: $(
                          "h-7 shrink-0",
                          k ? "w-7" : "px-2.5 text-sm"
                        ),
                        onClick: () => k ? E() : O(),
                        "aria-label": k ? A("Send") : A("Skip"),
                        children: k ? /* @__PURE__ */ u.jsx(_a, { className: "size-4" }) : A("Skip")
                      }
                    )
                  ]
                }
              )
            ] })
          },
          `opts-${r}`
        ) })
      ]
    }
  );
}
function k0({
  planSummary: t,
  steps: e,
  onApprove: n,
  onReject: r,
  onDismiss: s
}) {
  return /* @__PURE__ */ u.jsxs(
    J.div,
    {
      className: "rounded-2xl border bg-background overflow-hidden shadow-sm",
      initial: { opacity: 0, y: 12, scale: 0.98 },
      animate: { opacity: 1, y: 0, scale: 1 },
      exit: { opacity: 0, y: 8, scale: 0.98 },
      transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
      children: [
        /* @__PURE__ */ u.jsx("div", { className: "px-4 pt-4 pb-3", children: /* @__PURE__ */ u.jsxs("div", { className: "flex items-start justify-between gap-3", children: [
          /* @__PURE__ */ u.jsxs("div", { className: "flex items-start gap-2.5 flex-1 min-w-0", children: [
            /* @__PURE__ */ u.jsx("div", { className: "flex items-center justify-center h-8 w-8 rounded-lg bg-primary/10 shrink-0 mt-0.5", children: /* @__PURE__ */ u.jsx(go, { className: "h-4 w-4 text-primary" }) }),
            /* @__PURE__ */ u.jsxs("div", { className: "flex-1 min-w-0", children: [
              /* @__PURE__ */ u.jsx("p", { className: "text-sm font-medium text-foreground", children: A("Ready to execute") }),
              /* @__PURE__ */ u.jsx("p", { className: "text-xs text-muted-foreground mt-0.5 leading-relaxed", children: t })
            ] })
          ] }),
          /* @__PURE__ */ u.jsx(
            "button",
            {
              type: "button",
              className: "shrink-0 rounded-md p-1 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors",
              onClick: s,
              "aria-label": A("Close"),
              children: /* @__PURE__ */ u.jsx(kt, { className: "size-3.5" })
            }
          )
        ] }) }),
        e.length > 0 && /* @__PURE__ */ u.jsx("div", { className: "px-4 pb-3", children: /* @__PURE__ */ u.jsx("div", { className: "flex flex-col gap-0.5", children: e.map((a, i) => /* @__PURE__ */ u.jsxs(
          "div",
          {
            className: "flex items-center gap-2.5 py-1.5 px-2 rounded-md",
            children: [
              /* @__PURE__ */ u.jsx(Eu, { className: "h-3 w-3 text-muted-foreground/30 shrink-0" }),
              /* @__PURE__ */ u.jsx("span", { className: "text-xs text-muted-foreground", children: a })
            ]
          },
          i
        )) }) }),
        /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-2 px-4 py-3 border-t bg-muted/30", children: [
          /* @__PURE__ */ u.jsxs(V, { size: "sm", onClick: n, className: "gap-1.5", type: "button", children: [
            /* @__PURE__ */ u.jsx(we, { className: "size-3.5" }),
            A("Approve")
          ] }),
          /* @__PURE__ */ u.jsx(
            V,
            {
              size: "sm",
              variant: "ghost",
              onClick: r,
              className: "text-muted-foreground",
              type: "button",
              children: A("Cancel")
            }
          )
        ] })
      ]
    }
  );
}
const v0 = [
  { value: "approve", labelKey: "Yes, proceed" },
  { value: "reject", labelKey: "No, cancel" }
];
function _0({
  displayName: t,
  onApprove: e,
  onReject: n,
  onDismiss: r
}) {
  const s = y.useId(), [a, i] = y.useState(null);
  function o(l) {
    l === "approve" ? e() : l === "reject" && n();
  }
  return /* @__PURE__ */ u.jsxs(
    J.div,
    {
      className: "rounded-2xl border border-border/60 bg-background p-5 shadow-[0_12px_40px_-12px_rgba(0,0,0,0.12)] dark:bg-neutral-900 dark:shadow-[0_12px_40px_-12px_rgba(0,0,0,0.45)] backdrop-blur-sm transition-colors",
      initial: { opacity: 0, y: 16, scale: 0.98 },
      animate: { opacity: 1, y: 0, scale: 1 },
      exit: { opacity: 0, y: 8, scale: 0.98 },
      transition: { duration: 0.22, ease: [0.16, 1, 0.3, 1] },
      children: [
        /* @__PURE__ */ u.jsxs("div", { className: "flex items-start justify-between gap-4", children: [
          /* @__PURE__ */ u.jsx("div", { className: "flex-1 min-w-0", children: /* @__PURE__ */ u.jsx(Kr, { className: "block text-base font-semibold leading-snug text-foreground", children: t }) }),
          /* @__PURE__ */ u.jsx(
            V,
            {
              variant: "ghost",
              size: "icon",
              className: "h-7 w-7 shrink-0",
              onClick: r,
              "aria-label": A("Close"),
              children: /* @__PURE__ */ u.jsx(kt, { className: "size-4" })
            }
          )
        ] }),
        /* @__PURE__ */ u.jsx("div", { className: "mt-4", children: /* @__PURE__ */ u.jsx(lo, { value: "", onValueChange: o, className: "gap-0", children: v0.map((l, c) => {
          const d = `${s}-opt-${c}`, p = a === c, h = a === c - 1;
          return /* @__PURE__ */ u.jsxs(y.Fragment, { children: [
            c > 0 && /* @__PURE__ */ u.jsx("div", { className: "px-3", children: /* @__PURE__ */ u.jsx(
              es,
              {
                className: $(
                  "bg-border/60 transition-opacity duration-150",
                  (p || h) && "opacity-0"
                )
              }
            ) }),
            /* @__PURE__ */ u.jsxs(
              Kr,
              {
                htmlFor: d,
                onClick: () => o(l.value),
                onMouseEnter: () => i(c),
                onMouseLeave: () => i((m) => m === c ? null : m),
                className: "group flex items-center gap-3 rounded-xl px-2 py-2 text-sm font-normal cursor-pointer transition-colors hover:bg-muted",
                children: [
                  /* @__PURE__ */ u.jsx(
                    co,
                    {
                      id: d,
                      value: l.value,
                      className: "peer sr-only"
                    }
                  ),
                  /* @__PURE__ */ u.jsx(
                    "span",
                    {
                      "aria-hidden": !0,
                      className: "flex size-8 shrink-0 items-center justify-center rounded-md bg-muted-foreground/10 text-xs font-medium text-muted-foreground transition-colors",
                      children: c + 1
                    }
                  ),
                  /* @__PURE__ */ u.jsx("span", { className: "flex-1 leading-snug", children: A(l.labelKey) })
                ]
              }
            )
          ] }, l.value);
        }) }) })
      ]
    }
  );
}
function S0({
  isStreaming: t,
  onSend: e,
  onStop: n,
  selectedModel: r,
  onModelChange: s,
  lastAssistantMessage: a,
  lastMessageId: i
}) {
  const o = ce(
    ut.hasPlanApproval
  ), l = ce((S) => S.pendingPlanApproval), c = ce((S) => S.approvePlan), d = ce((S) => S.rejectPlan), p = ce((S) => S.dismissPlan), h = ce(
    ut.hasActiveApproval
  ), m = ce(
    ut.approvalDisplayName
  ), f = ce(
    (S) => S.pendingApprovalRequest
  ), g = ce((S) => S.approveToolCall), b = ce((S) => S.rejectToolCall), v = ce((S) => S.dismissApproval), w = ce(
    (S) => ut.activeQuestions({ state: S, lastAssistantMessage: a })
  ), x = ce(
    (S) => ut.hasActiveForm({ state: S, lastAssistantMessage: a })
  ), k = ce((S) => S.dismissForm);
  return o && l ? /* @__PURE__ */ u.jsx(
    k0,
    {
      planSummary: l.planSummary,
      steps: l.steps,
      onApprove: c,
      onReject: d,
      onDismiss: p
    },
    l.gateId
  ) : h ? /* @__PURE__ */ u.jsx(
    _0,
    {
      displayName: m ?? "",
      onApprove: g,
      onReject: b,
      onDismiss: v
    },
    f == null ? void 0 : f.gateId
  ) : x && !t ? /* @__PURE__ */ u.jsx(
    w0,
    {
      questions: w,
      onSubmit: (S) => {
        i && k(i), e(S);
      },
      onDismiss: () => {
        i && k(i), e(A("Skip these questions"));
      }
    },
    i
  ) : /* @__PURE__ */ u.jsx(
    Lc,
    {
      isStreaming: t,
      onSend: e,
      onStop: n,
      placeholder: A("Reply..."),
      rightActions: /* @__PURE__ */ u.jsx(
        $c,
        {
          selectedModel: r,
          onModelChange: s
        }
      )
    }
  );
}
function C0({
  children: t,
  variant: e,
  size: n,
  className: r,
  highlight: s,
  ...a
}) {
  const i = s !== void 0 && s.trim() !== "", o = typeof t == "string" ? t : "";
  if (!i)
    return /* @__PURE__ */ u.jsx(
      V,
      {
        variant: e || "outline",
        size: n || "lg",
        className: $("rounded-full", r),
        ...a,
        children: t
      }
    );
  if (!o)
    return /* @__PURE__ */ u.jsx(
      V,
      {
        variant: e || "ghost",
        size: n || "sm",
        className: $(
          "w-full cursor-pointer justify-start rounded-xl py-2",
          "hover:bg-accent",
          r
        ),
        ...a,
        children: t
      }
    );
  const l = s.trim(), c = o.toLowerCase(), d = l.toLowerCase(), p = c.includes(d);
  return /* @__PURE__ */ u.jsx(
    V,
    {
      variant: e || "ghost",
      size: n || "sm",
      className: $(
        "w-full cursor-pointer justify-start gap-0 rounded-xl py-2",
        "hover:bg-accent",
        r
      ),
      ...a,
      children: p ? (() => {
        const h = c.indexOf(d);
        if (h === -1)
          return /* @__PURE__ */ u.jsx("span", { className: "text-muted-foreground whitespace-pre-wrap", children: o });
        const m = o.substring(
          h,
          h + d.length
        ), f = o.substring(0, h), g = o.substring(h + m.length);
        return /* @__PURE__ */ u.jsxs(u.Fragment, { children: [
          f && /* @__PURE__ */ u.jsx("span", { className: "text-muted-foreground whitespace-pre-wrap", children: f }),
          /* @__PURE__ */ u.jsx("span", { className: "text-primary font-medium whitespace-pre-wrap", children: m }),
          g && /* @__PURE__ */ u.jsx("span", { className: "text-muted-foreground whitespace-pre-wrap", children: g })
        ] });
      })() : /* @__PURE__ */ u.jsx("span", { className: "text-muted-foreground whitespace-pre-wrap", children: o })
    }
  );
}
function N0({ incognito: t }) {
  const e = t ? A("Private Chat") : A("What would you like to work on?");
  return /* @__PURE__ */ u.jsxs(
    J.div,
    {
      className: "flex items-center gap-3",
      initial: { opacity: 0, y: 12 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.4 },
      children: [
        /* @__PURE__ */ u.jsx(ju, { className: "h-7 w-7 text-primary shrink-0" }),
        /* @__PURE__ */ u.jsx(
          "h2",
          {
            className: "text-[28px] font-bold leading-tight bg-[length:200%_100%] animate-[shimmer_3s_ease-in-out_infinite] bg-gradient-to-r from-foreground via-primary to-foreground bg-clip-text text-transparent",
            style: { textWrap: "balance" },
            children: e
          }
        )
      ]
    }
  );
}
function A0({
  onSend: t
}) {
  const e = [
    { icon: Xi, text: A("Automate a task") },
    { icon: Gu, text: A("Handle approvals") },
    { icon: zu, text: A("Check my data") },
    { icon: oo, text: A("Brainstorm ideas") }
  ];
  return /* @__PURE__ */ u.jsx("div", { className: "flex flex-wrap justify-center gap-2 mt-3", children: e.map((n, r) => /* @__PURE__ */ u.jsx(
    J.div,
    {
      initial: { opacity: 0, y: 8 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.3, delay: 0.3 + r * 0.08 },
      children: /* @__PURE__ */ u.jsxs(C0, { onClick: () => t(n.text), children: [
        /* @__PURE__ */ u.jsx(n.icon, { className: "h-3.5 w-3.5" }),
        n.text
      ] })
    },
    n.text
  )) });
}
function I0() {
  const t = uo();
  return /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col items-center justify-center h-full text-center gap-4 py-20 flex-1 min-w-0", children: [
    /* @__PURE__ */ u.jsx("div", { className: "flex items-center justify-center h-16 w-16 rounded-2xl bg-muted", children: /* @__PURE__ */ u.jsx(Sa, { className: "h-8 w-8 text-muted-foreground" }) }),
    /* @__PURE__ */ u.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ u.jsx("h2", { className: "text-xl font-semibold", children: A("Set up an AI provider to get started") }),
      /* @__PURE__ */ u.jsx("p", { className: "text-muted-foreground text-sm max-w-md", children: A(
        "AI Chat requires an AI provider. Add your provider in the AI settings to start chatting."
      ) })
    ] }),
    /* @__PURE__ */ u.jsxs(V, { onClick: () => t("/platform/setup/ai"), className: "gap-2", children: [
      /* @__PURE__ */ u.jsx(Sa, { className: "h-4 w-4" }),
      A("Go to AI Settings")
    ] })
  ] });
}
function T0() {
  return /* @__PURE__ */ u.jsxs("div", { className: "space-y-8 animate-in fade-in duration-300 py-4", children: [
    /* @__PURE__ */ u.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ u.jsx(qt, { className: "h-10 w-48 rounded-2xl" }) }),
    /* @__PURE__ */ u.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ u.jsx(qt, { className: "h-4 w-3/4" }),
      /* @__PURE__ */ u.jsx(qt, { className: "h-4 w-full" }),
      /* @__PURE__ */ u.jsx(qt, { className: "h-4 w-1/2" })
    ] })
  ] });
}
function Bi({
  creditsExhausted: t,
  creditsWarning: e,
  daysUntilReset: n,
  onDismiss: r
}) {
  const s = Ru(), a = !!t, i = a ? n != null ? A("You've reached your credits limit. Resets in {days} days.", {
    days: n
  }) : A("You've reached your credits limit.") : n != null ? A("You've used {percentage}% of your credits. Resets in {days} days.", {
    percentage: e == null ? void 0 : e.percentage,
    days: n
  }) : A("You've used {percentage}% of your credits.", {
    percentage: e == null ? void 0 : e.percentage
  });
  return /* @__PURE__ */ u.jsxs(
    "div",
    {
      className: $(
        "flex items-center gap-2 px-4 py-2 text-sm",
        a ? "bg-destructive/5 text-destructive" : "bg-warning/5 text-warning"
      ),
      children: [
        /* @__PURE__ */ u.jsx(po, { className: "h-3.5 w-3.5 shrink-0" }),
        /* @__PURE__ */ u.jsx("span", { className: "flex-1", children: i }),
        s && /* @__PURE__ */ u.jsx(
          Pu,
          {
            to: "/platform/setup/billing",
            className: "shrink-0 text-sm font-medium underline",
            children: A("Show Usage")
          }
        ),
        !a && /* @__PURE__ */ u.jsx(
          V,
          {
            variant: "ghost",
            size: "sm",
            className: "text-warning hover:text-warning shrink-0 h-6 w-6 p-0",
            onClick: r,
            children: /* @__PURE__ */ u.jsx(kt, { className: "h-3 w-3" })
          }
        )
      ]
    }
  );
}
function E0({
  replies: t,
  onSend: e
}) {
  return t.length === 0 ? null : /* @__PURE__ */ u.jsx("div", { className: "flex flex-wrap gap-2 py-2", children: t.map((n, r) => /* @__PURE__ */ u.jsx(
    J.button,
    {
      type: "button",
      onClick: () => e(n),
      className: "px-3 py-1.5 text-sm rounded-full border bg-background hover:bg-muted transition-colors cursor-pointer",
      initial: { opacity: 0, y: 6 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.25, delay: r * 0.06 },
      children: n
    },
    n
  )) });
}
const j0 = y.memo(function({
  message: e,
  isLastMessage: n = !1
}) {
  const r = da(e.parts), s = e.parts.filter(
    (i) => i.type === "file" && "filename" in i && typeof i.filename == "string"
  ).map((i) => i.filename), a = e.id.startsWith("hist-");
  return /* @__PURE__ */ u.jsx(
    J.div,
    {
      className: "flex justify-end py-3 group/msg",
      initial: a ? !1 : { opacity: 0, x: 16 },
      animate: { opacity: 1, x: 0 },
      transition: { duration: 0.25 },
      children: /* @__PURE__ */ u.jsxs("div", { className: "max-w-[80%]", children: [
        /* @__PURE__ */ u.jsx(Ic, { className: "flex-row-reverse", children: /* @__PURE__ */ u.jsxs("div", { className: "bg-muted rounded-2xl rounded-br-md px-2.5 py-1 text-sm", children: [
          s.length > 0 && /* @__PURE__ */ u.jsx("div", { className: "flex flex-wrap gap-1.5 mb-1.5", children: s.map((i, o) => /* @__PURE__ */ u.jsxs(
            "span",
            {
              className: "inline-flex items-center gap-1 rounded-md bg-background/60 px-2 py-0.5 text-xs text-muted-foreground",
              children: [
                /* @__PURE__ */ u.jsx(An, { className: "size-3" }),
                /* @__PURE__ */ u.jsx("span", { className: "max-w-[150px] truncate", children: i })
              ]
            },
            o
          )) }),
          /* @__PURE__ */ u.jsx(Bb, { markdown: !0, className: "prose-sm", children: r })
        ] }) }),
        /* @__PURE__ */ u.jsx(
          Tc,
          {
            className: $(
              "justify-end mt-1 transition-opacity",
              n ? "opacity-100" : "opacity-0 group-hover/msg:opacity-100"
            ),
            children: /* @__PURE__ */ u.jsx(Rn, { tooltip: A("Copy"), children: /* @__PURE__ */ u.jsx(Ec, { textToCopy: r, className: "h-6 w-6" }) })
          }
        )
      ] })
    }
  );
});
function R0({
  incognito: t,
  conversationId: e,
  onTitleUpdate: n,
  onConversationCreated: r
}) {
  const { data: s, isLoading: a } = Wi.useAiProviders(), o = !!(s == null ? void 0 : s.find((l) => l.enabledForChat));
  return !a && !o ? /* @__PURE__ */ u.jsx(I0, {}) : /* @__PURE__ */ u.jsx(wh, { children: /* @__PURE__ */ u.jsx(
    P0,
    {
      incognito: t,
      conversationId: e,
      onTitleUpdate: n,
      onConversationCreated: r
    }
  ) });
}
function P0({
  incognito: t,
  conversationId: e,
  onTitleUpdate: n,
  onConversationCreated: r
}) {
  const s = Hh(), {
    messages: a,
    modelName: i,
    isStreaming: o,
    wasCancelled: l,
    isLoadingHistory: c,
    error: d,
    sendMessage: p,
    cancelStream: h,
    setConversationId: m,
    setModelName: f
  } = zh({
    onTitleUpdate: n,
    onConversationCreated: r,
    onCreditsExhausted: () => s.setCreditsExhausted(!0)
  }), g = ce((N) => N.quickReplies);
  y.useEffect(() => {
    e && m(e);
  }, [e, m]);
  const b = y.useCallback(
    async (N, C) => {
      !N.trim() && (!C || C.length === 0) || await p(N.trim(), C);
    },
    [p]
  ), v = y.useCallback(() => {
    const N = a.findLast((C) => C.role === "user");
    N && p(da(N.parts));
  }, [a, p]), w = a[a.length - 1], x = y.useMemo(
    () => a.findLast((N) => N.role === "assistant"),
    [a]
  ), k = s.creditsExhausted || s.creditsWarning;
  return a.length === 0 && !c && !o ? /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col h-full flex-1 min-w-0 items-center justify-center px-6 pb-8", children: [
    /* @__PURE__ */ u.jsx("div", { className: "flex-1" }),
    /* @__PURE__ */ u.jsx(N0, { incognito: t }),
    /* @__PURE__ */ u.jsxs("div", { className: "w-full max-w-3xl mt-6", children: [
      /* @__PURE__ */ u.jsx(A0, { onSend: b }),
      /* @__PURE__ */ u.jsx("div", { className: "mt-3", children: /* @__PURE__ */ u.jsxs("div", { className: "overflow-hidden rounded-2xl border border-foreground/20 hover:border-foreground/40 focus-within:border-foreground/40 transition-colors", children: [
        k && /* @__PURE__ */ u.jsx(
          Bi,
          {
            creditsExhausted: s.creditsExhausted,
            creditsWarning: s.creditsWarning,
            daysUntilReset: s.daysUntilReset,
            onDismiss: s.dismissCreditsWarning
          }
        ),
        /* @__PURE__ */ u.jsx(
          Lc,
          {
            isStreaming: o,
            onSend: b,
            onStop: h,
            rightActions: /* @__PURE__ */ u.jsx(
              $c,
              {
                selectedModel: i,
                onModelChange: f
              }
            )
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ u.jsx("div", { className: "flex-1" })
  ] }) : /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col h-full flex-1 min-w-0", children: [
    /* @__PURE__ */ u.jsxs(
      Np,
      {
        className: "flex-1 relative",
        style: {
          maskImage: "linear-gradient(to bottom, black 0%, black calc(100% - 40px), transparent 100%)",
          WebkitMaskImage: "linear-gradient(to bottom, black 0%, black calc(100% - 40px), transparent 100%)"
        },
        children: [
          /* @__PURE__ */ u.jsxs(Ap, { className: "max-w-3xl mx-auto px-6 pt-8 pb-16 gap-0", children: [
            c && /* @__PURE__ */ u.jsx(T0, {}),
            a.map((N, C) => {
              if (N.role === "user")
                return /* @__PURE__ */ u.jsx(
                  j0,
                  {
                    message: N,
                    isLastMessage: C === a.length - 1
                  },
                  N.id
                );
              const E = o && C === a.length - 1, O = C === a.length - 1;
              return /* @__PURE__ */ u.jsx(
                a0,
                {
                  message: N,
                  isStreaming: E,
                  isLastMessage: O,
                  onRetry: v,
                  onSend: b,
                  lastAssistantMessage: O ? x : N
                },
                N.id
              );
            }),
            !o && !l && g.length > 0 && /* @__PURE__ */ u.jsx(E0, { replies: g, onSend: b }),
            l && /* @__PURE__ */ u.jsxs("div", { className: "flex items-center gap-2 py-2 text-xs text-muted-foreground animate-in fade-in duration-200", children: [
              /* @__PURE__ */ u.jsx(bo, { className: "h-3 w-3 fill-current" }),
              /* @__PURE__ */ u.jsx("span", { children: A("Response stopped") })
            ] }),
            d && /* @__PURE__ */ u.jsxs(
              J.div,
              {
                className: "flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-destructive text-sm",
                initial: { opacity: 0, y: 4 },
                animate: { opacity: 1, y: 0 },
                transition: { duration: 0.2 },
                children: [
                  /* @__PURE__ */ u.jsx(po, { className: "h-4 w-4 shrink-0" }),
                  /* @__PURE__ */ u.jsx("span", { className: "flex-1", children: d }),
                  /* @__PURE__ */ u.jsxs(
                    V,
                    {
                      variant: "ghost",
                      size: "sm",
                      className: "text-destructive hover:text-destructive gap-1.5 shrink-0 h-7 px-2",
                      onClick: v,
                      children: [
                        /* @__PURE__ */ u.jsx(Ls, { className: "h-3 w-3" }),
                        A("Retry")
                      ]
                    }
                  )
                ]
              }
            ),
            /* @__PURE__ */ u.jsx(Ip, {})
          ] }),
          /* @__PURE__ */ u.jsx(Tp, { className: "absolute bottom-4 right-1/2 translate-x-1/2" })
        ]
      }
    ),
    /* @__PURE__ */ u.jsx("div", { className: "px-6 pb-4", children: /* @__PURE__ */ u.jsx("div", { className: "max-w-3xl mx-auto relative", children: /* @__PURE__ */ u.jsxs("div", { className: "overflow-hidden rounded-2xl border border-foreground/20 hover:border-foreground/40 focus-within:border-foreground/40 transition-colors", children: [
      k && /* @__PURE__ */ u.jsx(
        Bi,
        {
          creditsExhausted: s.creditsExhausted,
          creditsWarning: s.creditsWarning,
          daysUntilReset: s.daysUntilReset,
          onDismiss: s.dismissCreditsWarning
        }
      ),
      /* @__PURE__ */ u.jsx(
        S0,
        {
          isStreaming: o,
          onSend: b,
          onStop: h,
          selectedModel: i,
          onModelChange: f,
          lastAssistantMessage: x,
          lastMessageId: w == null ? void 0 : w.id
        }
      )
    ] }) }) })
  ] });
}
const L0 = 0.03;
function $0({
  text: t,
  className: e
}) {
  const [n, r] = y.useState(t), [s, a] = y.useState(!1);
  return y.useEffect(() => {
    t !== n && (a(!0), r(t));
  }, [t, n]), s ? /* @__PURE__ */ u.jsx("span", { className: e, children: t.split("").map((i, o) => /* @__PURE__ */ u.jsx(
    J.span,
    {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      transition: { duration: 0.1, delay: o * L0 },
      onAnimationComplete: o === t.length - 1 ? () => a(!1) : void 0,
      children: i
    },
    `${t}-${o}`
  )) }) : /* @__PURE__ */ u.jsx("span", { className: e, children: t });
}
function O0({
  delayDuration: t = 400,
  children: e,
  ...n
}) {
  return /* @__PURE__ */ u.jsx(js, { delayDuration: t, children: /* @__PURE__ */ u.jsx(Lu, { "data-slot": "tooltip", ...n, children: e }) });
}
function M0({
  onSelect: t,
  onNewChat: e,
  selectedId: n
}) {
  const r = ir(), [s, a] = y.useState({}), [i, o] = y.useState(!1), [l, c] = y.useState(!1), [d, p] = y.useState(""), h = y.useRef(null), { data: m, isLoading: f } = qi({
    queryKey: ["chat-conversations"],
    queryFn: () => be.listConversations({ limit: 100 })
  }), g = y.useRef(n);
  g.current = n;
  const { mutate: b } = $u({
    mutationFn: (I) => be.deleteConversation(I),
    onSuccess: (I, j) => {
      r.invalidateQueries({
        queryKey: ["chat-conversations"]
      }), g.current === j && (e == null || e());
    }
  }), v = (m == null ? void 0 : m.data) ?? [], w = y.useMemo(() => {
    if (!d.trim()) return v;
    const I = d.toLowerCase();
    return v.filter(
      (j) => (j.title ?? "").toLowerCase().includes(I)
    );
  }, [v, d]), x = y.useCallback(() => {
    const I = h.current;
    I && (o(I.scrollTop > 5), c(I.scrollTop + I.clientHeight < I.scrollHeight - 5));
  }, []);
  y.useEffect(() => {
    x();
  }, [s, w, x]);
  const { today: k, yesterday: S, older: N } = y.useMemo(() => {
    const I = (/* @__PURE__ */ new Date()).toDateString(), j = /* @__PURE__ */ new Date();
    j.setDate(j.getDate() - 1);
    const U = j.toDateString(), L = {
      today: [],
      yesterday: [],
      older: []
    };
    for (const H of w) {
      const ie = new Date(H.created).toDateString();
      ie === I ? L.today.push(H) : ie === U ? L.yesterday.push(H) : L.older.push(H);
    }
    return L;
  }, [w]), C = (I) => {
    t == null || t(I.id);
  }, E = (I, j) => {
    I.stopPropagation(), b(j);
  }, O = (I) => {
    a((j) => ({ ...j, [I]: !j[I] }));
  }, R = (I, j) => {
    if (j.length === 0) return null;
    const U = s[I];
    return /* @__PURE__ */ u.jsxs("div", { className: "mb-2 flex flex-col gap-px", children: [
      /* @__PURE__ */ u.jsxs(
        "button",
        {
          type: "button",
          className: "flex items-center gap-0.5 rounded-md bg-transparent border-none cursor-pointer text-[11px] font-semibold px-2 py-1 uppercase tracking-wider text-muted-foreground transition-colors hover:text-foreground",
          onClick: () => O(I),
          children: [
            I,
            /* @__PURE__ */ u.jsx(
              on,
              {
                size: 10,
                className: $(
                  "shrink-0 transition-transform duration-150",
                  U && "-rotate-90"
                )
              }
            )
          ]
        }
      ),
      !U && j.map((L, H) => /* @__PURE__ */ u.jsxs(
        "button",
        {
          type: "button",
          className: $(
            "group flex items-center w-full px-2 py-1.5 rounded-md bg-transparent border-none cursor-pointer text-left text-xs transition-all hover:bg-muted relative animate-in fade-in slide-in-from-top-1 duration-200",
            n === L.id && "bg-muted font-semibold border-l-2 border-l-primary"
          ),
          style: { animationDelay: `${H * 30}ms` },
          onClick: () => C(L),
          children: [
            /* @__PURE__ */ u.jsx("span", { className: "overflow-hidden text-ellipsis whitespace-nowrap pr-5 flex-1", children: L.title ?? A("New conversation") }),
            /* @__PURE__ */ u.jsxs(O0, { children: [
              /* @__PURE__ */ u.jsx(Rs, { asChild: !0, children: /* @__PURE__ */ u.jsx(
                "span",
                {
                  role: "button",
                  tabIndex: 0,
                  className: "absolute right-1 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 p-1 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all",
                  onClick: (ie) => E(ie, L.id),
                  onKeyDown: (ie) => {
                    ie.key === "Enter" && (ie.stopPropagation(), b(L.id));
                  },
                  children: /* @__PURE__ */ u.jsx(ho, { size: 12 })
                }
              ) }),
              /* @__PURE__ */ u.jsx(
                Ps,
                {
                  side: "right",
                  align: "center",
                  className: "pointer-events-none",
                  children: A("Delete")
                }
              )
            ] })
          ]
        },
        L.id
      ))
    ] });
  };
  return /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col h-full shrink-0", style: { width: "220px" }, children: [
    /* @__PURE__ */ u.jsxs("div", { className: "px-2 pt-3 pb-2 space-y-2", children: [
      /* @__PURE__ */ u.jsxs(
        "button",
        {
          type: "button",
          className: "flex items-center justify-between gap-1.5 w-full px-2 py-1.5 rounded-md border border-border bg-transparent cursor-pointer text-xs text-foreground transition-colors hover:bg-accent",
          onClick: () => {
            e == null || e();
          },
          children: [
            /* @__PURE__ */ u.jsxs("span", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ u.jsx(Yr, { size: 14 }),
              A("New chat")
            ] }),
            /* @__PURE__ */ u.jsx("span", { className: "text-[11px] opacity-50", children: "⇧⌘O" })
          ]
        }
      ),
      v.length > 5 && /* @__PURE__ */ u.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ u.jsx(Ki, { className: "absolute left-2 top-1/2 -translate-y-1/2 h-3 w-3 text-muted-foreground" }),
        /* @__PURE__ */ u.jsx(
          Mn,
          {
            value: d,
            onChange: (I) => p(I.target.value),
            placeholder: A("Search..."),
            className: "h-7 pl-7 text-xs rounded-md"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ u.jsxs("div", { className: "flex-1 relative min-h-0", children: [
      i && /* @__PURE__ */ u.jsx("div", { className: "absolute top-0 left-0 right-0 h-5 pointer-events-none z-[1] bg-gradient-to-b from-background to-transparent" }),
      /* @__PURE__ */ u.jsx(
        "div",
        {
          ref: h,
          onScroll: x,
          className: "h-full overflow-y-auto px-2 pb-3 scrollbar-thin",
          children: f ? /* @__PURE__ */ u.jsx("div", { className: "space-y-2 px-2 pt-2", children: Array.from({ length: 4 }).map((I, j) => /* @__PURE__ */ u.jsx(qt, { className: "h-7 w-full rounded-md" }, j)) }) : w.length === 0 ? /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col items-center justify-center py-8 px-4 text-center", children: [
            /* @__PURE__ */ u.jsx(Uu, { className: "h-8 w-8 text-muted-foreground/30 mb-2" }),
            /* @__PURE__ */ u.jsx("p", { className: "text-xs text-muted-foreground", children: d.trim() ? A("No chats found") : A("Start your first chat") })
          ] }) : /* @__PURE__ */ u.jsxs(u.Fragment, { children: [
            R(A("Today"), k),
            R(A("Yesterday"), S),
            R(A("Older"), N)
          ] })
        }
      ),
      l && /* @__PURE__ */ u.jsx("div", { className: "absolute bottom-0 left-0 right-0 h-[70px] pointer-events-none z-[1] bg-gradient-to-t from-background to-transparent" })
    ] })
  ] });
}
function ew() {
  const t = ir(), e = uo(), { conversationId: n } = Ou(), [r, s] = y.useState(0), [a, i] = y.useState(null), [o, l] = y.useState(
    null
  ), [c, d] = y.useState(!1), [p, h] = y.useState(""), m = y.useRef(!1), f = n ?? null, g = y.useCallback(() => {
    s((C) => C + 1), i(null), l(null), e("/chat", { replace: !0 });
  }, [e]), b = y.useCallback(
    (C) => {
      i(null), l(null), e(`/chat/${C}`, {
        replace: !0
      });
    },
    [e]
  ), v = y.useCallback(
    (C) => {
      i(C), window.history.replaceState(null, "", `/chat/${C}`), t.invalidateQueries({
        queryKey: ["chat-conversations"]
      });
    },
    [t]
  ), w = y.useCallback(
    (C) => {
      l(C), t.invalidateQueries({
        queryKey: ["chat-conversations"]
      });
    },
    [t]
  ), x = y.useCallback(async () => {
    if (m.current) {
      m.current = !1;
      return;
    }
    const C = f ?? a;
    if (!C || !p.trim()) {
      d(!1);
      return;
    }
    m.current = !0;
    try {
      await be.updateConversation(C, {
        title: p.trim()
      }), l(p.trim()), t.invalidateQueries({
        queryKey: ["chat-conversations"]
      });
    } catch {
    } finally {
      m.current = !1, d(!1);
    }
  }, [f, a, p, t]), k = y.useCallback(async () => {
    const C = f ?? a;
    if (C)
      try {
        await be.deleteConversation(C), t.invalidateQueries({
          queryKey: ["chat-conversations"]
        }), g();
      } catch {
      }
  }, [
    f,
    a,
    t,
    g
  ]);
  y.useEffect(() => {
    if (!f || o) return;
    let C = !1;
    return be.getConversation(f).then((E) => {
      !C && E.title && l(E.title);
    }).catch(() => {
    }), () => {
      C = !0;
    };
  }, [f, o]), y.useEffect(() => {
    const C = (E) => {
      (E.metaKey || E.ctrlKey) && E.shiftKey && E.key.toLowerCase() === "o" && (E.preventDefault(), g());
    };
    return window.addEventListener("keydown", C), () => window.removeEventListener("keydown", C);
  }, [g]);
  const S = f ?? a, N = o ?? A("New conversation");
  return /* @__PURE__ */ u.jsxs("div", { className: "flex h-full overflow-hidden", children: [
    /* @__PURE__ */ u.jsx("div", { className: "shrink-0 overflow-hidden opacity-40 hover:opacity-100 transition-opacity duration-200", children: /* @__PURE__ */ u.jsx(
      M0,
      {
        onNewChat: g,
        onSelect: b,
        selectedId: a ?? f
      }
    ) }),
    /* @__PURE__ */ u.jsxs("div", { className: "flex flex-col flex-1 min-w-0 min-h-0 overflow-hidden", children: [
      /* @__PURE__ */ u.jsx("div", { className: "shrink-0 flex items-center gap-1.5 px-6 py-3 border-b", children: c ? /* @__PURE__ */ u.jsx(
        Mn,
        {
          autoFocus: !0,
          value: p,
          onChange: (C) => h(C.target.value),
          onBlur: () => void x(),
          onKeyDown: (C) => {
            C.key === "Enter" && x(), C.key === "Escape" && (m.current = !0, d(!1));
          },
          className: "h-7 text-sm font-semibold max-w-[300px]"
        }
      ) : /* @__PURE__ */ u.jsxs(u.Fragment, { children: [
        /* @__PURE__ */ u.jsx(
          $0,
          {
            text: N,
            className: "text-sm font-semibold truncate max-w-[400px]"
          }
        ),
        S && /* @__PURE__ */ u.jsxs(Mu, { children: [
          /* @__PURE__ */ u.jsx(Du, { asChild: !0, children: /* @__PURE__ */ u.jsx(
            V,
            {
              variant: "ghost",
              size: "icon",
              className: "h-6 w-6 shrink-0",
              children: /* @__PURE__ */ u.jsx(ao, { className: "h-3.5 w-3.5" })
            }
          ) }),
          /* @__PURE__ */ u.jsxs(Bu, { align: "start", children: [
            /* @__PURE__ */ u.jsxs(
              Ca,
              {
                onClick: () => {
                  h(o ?? ""), d(!0);
                },
                children: [
                  /* @__PURE__ */ u.jsx(ts, { className: "h-4 w-4 mr-2" }),
                  A("Rename")
                ]
              }
            ),
            /* @__PURE__ */ u.jsxs(
              Ca,
              {
                className: "text-destructive focus:text-destructive",
                onClick: () => void k(),
                children: [
                  /* @__PURE__ */ u.jsx(ho, { className: "h-4 w-4 mr-2" }),
                  A("Delete")
                ]
              }
            )
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ u.jsx("div", { className: "flex-1 min-h-0", children: /* @__PURE__ */ u.jsx(
        R0,
        {
          incognito: !1,
          conversationId: f,
          onTitleUpdate: w,
          onConversationCreated: v
        },
        `${f ?? "new"}-${r}`
      ) })
    ] })
  ] });
}
export {
  ew as ChatWithAIPage
};
