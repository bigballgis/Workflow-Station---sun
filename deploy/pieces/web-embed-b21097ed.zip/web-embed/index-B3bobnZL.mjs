import { c as V, g, cQ as s, dp as S, j as e, bs as $, b_ as q, bt as H, bu as G, bv as K, a6 as a, dq as E, bw as Q, aX as X, c6 as Y, i as N, dr as y, db as Z, dc as ee, dd as se, de as ae, ds as te, ab as ne, d0 as v, dt as ie, bj as O, du as re, bl as L, bm as z, bp as U, b4 as de, I as W, ch as le, dv as M, ci as ce, bk as oe, bB as me, bq as xe, d9 as k, aW as he, cb as ue, cc as fe, a3 as Ee, a4 as Ne, cj as I, ck as P, a5 as je, bC as pe } from "./mount-builder-CqIEWsZv.mjs";
import { C as Re } from "./centered-page-C5JGBrkC.mjs";
import { S as ge } from "./shield-check-DaZf4pFn.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const we = [
  ["path", { d: "M13 21h8", key: "1jsn5i" }],
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ]
], Te = V("pen-line", we), w = [
  {
    name: "Project",
    description: "Project settings and configuration",
    read: [s.READ_PROJECT],
    write: [s.READ_PROJECT, s.WRITE_PROJECT],
    disableNone: !0
  },
  {
    name: "Flows",
    description: "Read and write flows",
    read: [s.READ_FLOW],
    write: [s.READ_FLOW, s.WRITE_FLOW],
    disableNone: !0
  },
  {
    name: "Flow Status",
    description: "Update flow status",
    disableRead: !0,
    read: [],
    write: [s.UPDATE_FLOW_STATUS]
  },
  {
    name: "App Connections",
    description: "Read and write app connections",
    read: [s.READ_APP_CONNECTION],
    write: [s.READ_APP_CONNECTION, s.WRITE_APP_CONNECTION]
  },
  {
    name: "Runs",
    description: "Read and write runs",
    read: [s.READ_RUN],
    write: [s.READ_RUN, s.WRITE_RUN]
  },
  {
    name: "Alerts",
    description: "Read and write alerts",
    read: [s.READ_ALERT],
    write: [s.READ_ALERT, s.WRITE_ALERT]
  },
  {
    name: "Folders",
    description: "Read and write folders",
    read: [s.READ_FOLDER],
    write: [s.READ_FOLDER, s.WRITE_FOLDER]
  },
  {
    name: "Project Members",
    description: "Read and write project members",
    read: [s.READ_PROJECT_MEMBER],
    write: [s.READ_PROJECT_MEMBER, s.WRITE_PROJECT_MEMBER]
  },
  {
    name: "Invitations",
    description: "Read and write invitations",
    read: [s.READ_INVITATION],
    write: [s.READ_INVITATION, s.WRITE_INVITATION]
  },
  {
    name: "Project Releases",
    description: "Read and write project releases",
    read: [s.READ_PROJECT_RELEASE],
    write: [s.READ_PROJECT_RELEASE, s.WRITE_PROJECT_RELEASE]
  },
  {
    name: "Tables",
    description: "Read and write tables",
    read: [s.READ_TABLE],
    write: [s.READ_TABLE, s.WRITE_TABLE]
  },
  {
    name: "MCP",
    description: "Read and write MCP",
    read: [s.READ_MCP],
    write: [s.READ_MCP, s.WRITE_MCP]
  }
], F = ({
  mode: i,
  projectRole: t,
  onSave: h,
  children: c,
  disabled: m = !1
}) => {
  const [f, u] = g.useState(!1), [p, T] = g.useState((t == null ? void 0 : t.name) || ""), [j, l] = g.useState(() => {
    if (!(t != null && t.permissions)) {
      const d = /* @__PURE__ */ new Set();
      return w.forEach((x) => {
        x.disableNone && x.read.forEach((n) => d.add(n));
      }), Array.from(d);
    }
    return t.permissions;
  }), { mutate: B } = S.useUpsertProjectRole({
    onSave: () => {
      u(!1), h();
    }
  }), A = (d, x) => {
    const n = w.find(
      (r) => r.name === d
    ), o = new Set(j);
    n != null && n.disableNone ? (n.read.forEach((r) => o.delete(r)), n.write.forEach((r) => o.delete(r)), x === "Read" ? n.read.forEach((r) => o.add(r)) : x === "Write" && n.write.forEach((r) => o.add(r))) : x === "None" ? (n == null || n.read.forEach((r) => o.delete(r)), n == null || n.write.forEach((r) => o.delete(r))) : x === "Read" ? (n == null || n.write.forEach((r) => o.delete(r)), n == null || n.read.forEach((r) => o.add(r))) : x === "Write" && (n == null || n.write.forEach((r) => o.add(r))), l(Array.from(o));
  }, D = (d, x) => {
    const n = w.find(
      (R) => R.name === d
    ), o = new Set((n == null ? void 0 : n.write) || []), r = new Set((n == null ? void 0 : n.read) || []), C = new Set(j), b = o.size > 0 && [...o].every((R) => C.has(R)), _ = r.size > 0 && [...r].every((R) => C.has(R)) && !b;
    return x === "Write" && b || x === "Read" && _ || x === "None" && !_ && !b ? "default" : "ghost";
  }, J = () => {
    m || B({
      mode: i,
      roleId: t == null ? void 0 : t.id,
      name: p,
      permissions: j,
      type: E.CUSTOM
    });
  };
  return /* @__PURE__ */ e.jsxs($, { open: f, onOpenChange: u, children: [
    /* @__PURE__ */ e.jsx(q, { asChild: !0, children: c }),
    /* @__PURE__ */ e.jsxs(H, { className: "w-full max-w-3xl", children: [
      /* @__PURE__ */ e.jsxs(G, { children: [
        /* @__PURE__ */ e.jsx(K, { children: i === "create" ? a("Create Role") : (t == null ? void 0 : t.type) === E.DEFAULT ? a("View Role: {name}", { name: t == null ? void 0 : t.name }) : a("Edit Role: {name}", { name: t == null ? void 0 : t.name }) }),
        /* @__PURE__ */ e.jsx(Q, { children: i === "create" ? a(
          "Define a custom role with specific permissions for project members."
        ) : a("Review and manage permissions for this role.") })
      ] }),
      /* @__PURE__ */ e.jsxs("div", { className: "grid space-y-4 mt-4", children: [
        /* @__PURE__ */ e.jsxs("div", { children: [
          /* @__PURE__ */ e.jsx("span", { className: "text-sm font-medium text-foreground", children: a("Name") }),
          /* @__PURE__ */ e.jsx(
            X,
            {
              value: p,
              onChange: (d) => T(d.target.value),
              required: !0,
              id: "name",
              type: "text",
              placeholder: a("Role Name"),
              className: "rounded-sm mt-2",
              disabled: m
            }
          )
        ] }),
        /* @__PURE__ */ e.jsxs("div", { children: [
          /* @__PURE__ */ e.jsx("span", { className: "text-sm font-medium text-foreground", children: a("Permissions") }),
          /* @__PURE__ */ e.jsx("div", { className: "overflow-y-auto p-2 rounded-md", children: /* @__PURE__ */ e.jsx(Y, { className: "h-[55vh] pr-4", children: /* @__PURE__ */ e.jsx("div", { className: "grid grid-cols-2 gap-x-6", children: w.map((d) => /* @__PURE__ */ e.jsxs(
            "div",
            {
              className: "flex flex-col justify-between py-3 border-b last:border-b-0",
              children: [
                /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row items-center justify-between gap-2", children: [
                  /* @__PURE__ */ e.jsx("span", { className: "font-semibold text-sm text-foreground", children: d.name }),
                  /* @__PURE__ */ e.jsxs("div", { className: "flex bg-accent rounded-sm", children: [
                    !d.disableNone && /* @__PURE__ */ e.jsx(
                      N,
                      {
                        className: "h-9 px-4",
                        variant: D(
                          d.name,
                          "None"
                        ),
                        onClick: () => A(d.name, "None"),
                        disabled: m,
                        children: a("None")
                      }
                    ),
                    !d.disableRead && /* @__PURE__ */ e.jsx(
                      N,
                      {
                        className: "h-9 px-4",
                        variant: D(
                          d.name,
                          "Read"
                        ),
                        onClick: () => A(d.name, "Read"),
                        disabled: m,
                        children: a("Read")
                      }
                    ),
                    /* @__PURE__ */ e.jsx(
                      N,
                      {
                        className: "h-9 px-4",
                        variant: D(d.name, "Write"),
                        onClick: () => A(d.name, "Write"),
                        disabled: m,
                        children: a("Write")
                      }
                    )
                  ] })
                ] }),
                /* @__PURE__ */ e.jsx("span", { className: "text-xs text-muted-foreground mt-1", children: d.description })
              ]
            },
            d.name
          )) }) }) })
        ] }),
        !m && /* @__PURE__ */ e.jsx(N, { onClick: J, children: i === "create" ? a("Create") : a("Save") })
      ] })
    ] })
  ] });
}, Ae = ({
  projectRole: i,
  isOpen: t,
  onOpenChange: h
}) => {
  const { data: c, isLoading: m } = y.useProjectRoleMembers(
    i == null ? void 0 : i.id,
    t && i !== null
  ), f = (c == null ? void 0 : c.data) ?? [];
  return /* @__PURE__ */ e.jsx(Z, { open: t, onOpenChange: h, children: /* @__PURE__ */ e.jsxs(ee, { className: "w-[600px] sm:max-w-[600px] flex flex-col p-0", children: [
    /* @__PURE__ */ e.jsxs(se, { className: "px-6 py-4 border-b shrink-0", children: [
      /* @__PURE__ */ e.jsxs(ae, { className: "text-base", children: [
        i == null ? void 0 : i.name,
        " ",
        a("Role"),
        " ",
        a("Users")
      ] }),
      /* @__PURE__ */ e.jsx(te, { children: a("View the users assigned to this role") })
    ] }),
    /* @__PURE__ */ e.jsx("div", { className: "flex-1 overflow-hidden", children: m ? /* @__PURE__ */ e.jsx("div", { className: "flex items-center justify-center h-full", children: /* @__PURE__ */ e.jsx(ne, { className: "size-8 animate-spin text-muted-foreground" }) }) : f.length === 0 ? /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center justify-center h-full gap-2 text-muted-foreground", children: [
      /* @__PURE__ */ e.jsx(v, { className: "size-14" }),
      /* @__PURE__ */ e.jsx("p", { className: "text-sm font-medium", children: a("No users found") }),
      /* @__PURE__ */ e.jsx("p", { className: "text-xs", children: a("Start by assigning users to this role") })
    ] }) : /* @__PURE__ */ e.jsx(
      ie,
      {
        items: f,
        estimateSize: () => 64,
        getItemKey: (u) => f[u].id,
        renderItem: (u) => De(u)
      }
    ) })
  ] }) });
};
function De(i) {
  const { user: t, project: h } = i, c = `${t.firstName} ${t.lastName}`.trim();
  return /* @__PURE__ */ e.jsxs(O, { size: "sm", children: [
    /* @__PURE__ */ e.jsx(
      re,
      {
        name: c,
        email: t.email,
        imageUrl: t.imageUrl,
        size: 36,
        disableTooltip: !0
      }
    ),
    /* @__PURE__ */ e.jsxs(L, { children: [
      /* @__PURE__ */ e.jsx(z, { children: c }),
      /* @__PURE__ */ e.jsxs(U, { children: [
        t.email,
        " · ",
        /* @__PURE__ */ e.jsx(de, { to: `/projects/${h.id}/settings/team`, children: h.displayName })
      ] })
    ] })
  ] });
}
function be(i) {
  switch (i) {
    case "Admin":
      return /* @__PURE__ */ e.jsx(ge, {});
    case "Editor":
      return /* @__PURE__ */ e.jsx(Te, {});
    case "Viewer":
      return /* @__PURE__ */ e.jsx(k, {});
    default:
      return /* @__PURE__ */ e.jsx(M, {});
  }
}
const Ce = ({
  projectRoles: i,
  isLoading: t,
  refetch: h
}) => {
  const { platform: c } = W.useCurrentPlatform(), [m, f] = g.useState(null), [u, p] = g.useState(!1), { mutate: T } = S.useDeleteProjectRole({
    onSuccess: () => h()
  });
  if (t)
    return /* @__PURE__ */ e.jsx(le, { numberOfItems: 3, className: "w-full h-[60px]" });
  const j = (i == null ? void 0 : i.data) ?? [];
  return j.length === 0 ? /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center gap-3 py-12 text-muted-foreground", children: [
    /* @__PURE__ */ e.jsx(M, { className: "size-10" }),
    /* @__PURE__ */ e.jsx("p", { className: "text-sm", children: a("No project roles yet. Create one to get started.") })
  ] }) : /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(ce, { className: "gap-2", children: j.map((l) => /* @__PURE__ */ e.jsxs(O, { variant: "outline", size: "sm", children: [
      /* @__PURE__ */ e.jsx(oe, { variant: "icon", children: be(l.name) }),
      /* @__PURE__ */ e.jsxs(L, { children: [
        /* @__PURE__ */ e.jsx(z, { children: l.name }),
        /* @__PURE__ */ e.jsx(U, { children: /* @__PURE__ */ e.jsx(
          me,
          {
            variant: l.type === E.DEFAULT ? "accent" : "secondary",
            children: l.type === E.DEFAULT ? a("Default") : a("Custom")
          }
        ) })
      ] }),
      /* @__PURE__ */ e.jsxs(xe, { children: [
        /* @__PURE__ */ e.jsxs(
          N,
          {
            variant: "ghost",
            size: "sm",
            className: "flex items-center gap-1.5 px-2 h-8 text-muted-foreground",
            onClick: () => {
              f(l), p(!0);
            },
            children: [
              /* @__PURE__ */ e.jsx(v, { className: "size-4" }),
              /* @__PURE__ */ e.jsx("span", { className: "text-xs", children: l.userCount === 1 ? a("1 user") : a(`${l.userCount} users`) })
            ]
          }
        ),
        /* @__PURE__ */ e.jsx(
          F,
          {
            mode: "edit",
            projectRole: l,
            platformId: c.id,
            onSave: () => h(),
            disabled: l.type === E.DEFAULT,
            children: /* @__PURE__ */ e.jsx(N, { variant: "ghost", size: "sm", className: "size-8 p-0", children: l.type === E.DEFAULT ? /* @__PURE__ */ e.jsx(k, { className: "size-4" }) : /* @__PURE__ */ e.jsx(he, { className: "size-4" }) })
          }
        ),
        l.type !== E.DEFAULT && /* @__PURE__ */ e.jsx(
          ue,
          {
            isDanger: !0,
            title: a("Delete Role"),
            message: a(
              "Deleting this role will remove {count} project member(s) and all associated invitations.",
              { count: l.userCount }
            ),
            entityName: `${a("Project Role")} ${l.name}`,
            buttonText: a("Delete Role"),
            mutationFn: async () => T(l.name),
            children: /* @__PURE__ */ e.jsx(N, { variant: "ghost", size: "sm", className: "size-8 p-0", children: /* @__PURE__ */ e.jsx(fe, { className: "size-4 text-destructive" }) })
          }
        )
      ] })
    ] }, l.id)) }),
    /* @__PURE__ */ e.jsx(
      Ae,
      {
        projectRole: m,
        isOpen: u,
        onOpenChange: p
      }
    )
  ] });
}, _e = () => {
  const { platform: i } = W.useCurrentPlatform(), { data: t, isLoading: h, refetch: c } = y.useProjectRoles(
    i.plan.projectRolesEnabled
  ), m = i.plan.customRolesEnabled ? /* @__PURE__ */ e.jsx(
    F,
    {
      mode: "create",
      onSave: () => c(),
      platformId: i.id,
      children: /* @__PURE__ */ e.jsx(I, { icon: P, iconSize: 16, size: "sm", children: a("New Role") })
    }
  ) : /* @__PURE__ */ e.jsxs(Ee, { children: [
    /* @__PURE__ */ e.jsx(Ne, { children: /* @__PURE__ */ e.jsx(I, { icon: P, iconSize: 16, size: "sm", disabled: !0, children: a("New Role") }) }),
    /* @__PURE__ */ e.jsx(je, { side: "bottom", children: a("Contact sales to unlock custom roles") })
  ] });
  return /* @__PURE__ */ e.jsx(
    pe,
    {
      featureKey: "TEAM",
      locked: !i.plan.projectRolesEnabled,
      lockTitle: a("Project Role Management"),
      lockDescription: a(
        "Define custom roles and permissions to control what your team members can access and modify"
      ),
      lockVideoUrl: "/ap-cdn/videos/showcase/roles.mp4",
      children: /* @__PURE__ */ e.jsx(
        Re,
        {
          title: a("Project Role Management"),
          description: a(
            "Define custom roles and permissions that can be assigned to your team members"
          ),
          actions: m,
          children: /* @__PURE__ */ e.jsx(
            Ce,
            {
              projectRoles: t,
              isLoading: h,
              refetch: c
            }
          )
        }
      )
    }
  );
};
_e.displayName = "ProjectRolePage";
export {
  _e as ProjectRolePage
};
