import { hl as d, a6 as m, jf as u, c_ as x, j as t, cp as f, fa as j } from "./mount-builder-CqIEWsZv.mjs";
function p(e, r) {
  const {
    embedState: { isEmbedded: i }
  } = d();
  if (i)
    return e;
  const o = {
    accessorKey: "owner",
    size: 180,
    header: ({ column: n }) => /* @__PURE__ */ t.jsx(f, { column: n, title: m("Owner"), icon: x }),
    cell: ({ row: n }) => {
      var s;
      return "ownerId" in n.original ? /* @__PURE__ */ t.jsx(c, { ownerId: n.original.ownerId }) : "owner" in n.original ? /* @__PURE__ */ t.jsx(c, { ownerId: (s = n.original.owner) == null ? void 0 : s.id }) : /* @__PURE__ */ t.jsx("div", { className: "text-left", children: "-" });
    }
  }, a = u({ index: r, limit: e.length });
  return [
    ...e.slice(0, a),
    o,
    ...e.slice(a)
  ];
}
function b(e, r, i) {
  const {
    embedState: { isEmbedded: o }
  } = d();
  if (o)
    return e;
  const a = i == null ? void 0 : i.map((l) => ({
    label: `${l.firstName} ${l.lastName} (${l.email})`,
    value: l.email
  })), n = {
    type: "select",
    title: m("Owner"),
    accessorKey: "owner",
    icon: x,
    options: a ?? []
  }, s = u({ index: r, limit: e.length });
  return [
    ...e.slice(0, s),
    n,
    ...e.slice(s)
  ];
}
const h = {
  useOwnerColumn: p,
  useOwnerColumnFilter: b
}, c = ({ ownerId: e }) => /* @__PURE__ */ t.jsxs("div", { className: "text-left", children: [
  e && /* @__PURE__ */ t.jsx(
    j,
    {
      id: e,
      includeAvatar: !0,
      includeName: !0,
      size: "small"
    }
  ),
  !e && /* @__PURE__ */ t.jsx("div", { className: "text-left", children: "-" })
] });
export {
  h as o
};
