import { o as i, a as y, s as e, r as f, u as T, m as D, l, b as x, bS as ne, n as o, d as F, w as I, cu as H, cv as ie, cw as S, cx as ce, cy as le, cz as de, cA as ue, cB as pe, x as me, cC as xe, B as he, cD as Ee, _ as fe, c as G, e as ge, H as Ie, g as A, D as C, L as R, j as t, ax as Te, ay as ye, i as Ne, a6 as c, aA as je, be, bf as De, cE as k, ah as M, cF as B, cG as P, cH as ve, cI as we, cJ as K, cK as q, cL as z, cM as J, bg as Se, h as W, a3 as _e, a4 as Oe, bB as L, a5 as Ae, aa as Ce } from "./mount-builder-CqIEWsZv.mjs";
import { a as Re } from "./index-C5tdr9I_.mjs";
import { D as ke } from "./dashboard-page-header-BfLKPs1b.mjs";
import { C as Me, M as Be, H as Pe } from "./memory-stick-ZV4hBPBO.mjs";
var _ = /* @__PURE__ */ ((s) => (s.BEGIN = "BEGIN", s.RESUME = "RESUME", s))(_ || {});
i({
  steps: f(e(), T()),
  tags: y(e())
});
const Le = i({
  type: l("inline"),
  value: xe()
}), Ue = i({
  type: l("ref"),
  fileId: e()
}), X = F("type", [Le, Ue]), Ve = i({
  schemaVersion: o(),
  projectId: e(),
  platformId: e(),
  flowVersionId: e(),
  flowId: e(),
  jobType: l(
    "RENEW_WEBHOOK"
    /* RENEW_WEBHOOK */
  )
}), Fe = i({
  projectId: e(),
  platformId: e(),
  schemaVersion: o(),
  flowVersionId: e(),
  flowId: e(),
  triggerType: x(ne),
  jobType: l(
    "EXECUTE_POLLING"
    /* EXECUTE_POLLING */
  )
}), Y = i({
  projectId: e(),
  platformId: e(),
  jobType: l(
    "EXECUTE_FLOW"
    /* EXECUTE_FLOW */
  ),
  environment: x(H),
  schemaVersion: o(),
  flowId: e(),
  flowVersionId: e(),
  runId: e(),
  workerHandlerId: D([e(), me()]).optional(),
  httpRequestId: e().optional(),
  payload: X,
  streamStepProgress: x(pe),
  stepNameToTest: e().optional(),
  sampleData: f(e(), T()).optional(),
  logsFileId: e(),
  traceContext: f(e(), e()).optional()
}), He = Y.extend({
  executionType: l(_.BEGIN),
  executeTrigger: I().optional()
}), Ge = Y.extend({
  executionType: l(_.RESUME),
  resumeReason: x(ie)
}), Ke = F("executionType", [He, Ge]), qe = i({
  projectId: e(),
  platformId: e(),
  schemaVersion: o(),
  requestId: e(),
  payload: X,
  runEnvironment: x(H),
  flowId: e(),
  saveSampleData: I(),
  flowVersionIdToRun: e(),
  execute: I(),
  jobType: l(
    "EXECUTE_WEBHOOK"
    /* EXECUTE_WEBHOOK */
  ),
  parentRunId: e().optional(),
  failParentOnFailure: I().optional(),
  traceContext: f(e(), e()).optional()
}), $ = i({
  jobType: l(
    "EXECUTE_VALIDATION"
    /* EXECUTE_VALIDATION */
  ),
  projectId: e().optional(),
  platformId: e(),
  piece: S,
  schemaVersion: o(),
  connectionValue: T(),
  requestId: e(),
  webserverId: e()
}), Z = i({
  jobType: l(
    "EXECUTE_TRIGGER_HOOK"
    /* EXECUTE_TRIGGER_HOOK */
  ),
  platformId: e(),
  projectId: e(),
  schemaVersion: o(),
  flowId: e(),
  flowVersionId: e(),
  test: I(),
  hookType: x(le),
  triggerPayload: ce.optional(),
  requestId: e(),
  webserverId: e()
}), Q = i({
  jobType: l(
    "EXECUTE_PROPERTY"
    /* EXECUTE_PROPERTY */
  ),
  projectId: e(),
  platformId: e(),
  schemaVersion: o(),
  flowVersion: de.optional(),
  propertyName: e(),
  piece: S,
  actionOrTriggerName: e(),
  input: f(e(), T()),
  sampleData: f(e(), T()),
  searchValue: e().optional(),
  requestId: e(),
  webserverId: e()
}), ee = i({
  schemaVersion: o(),
  jobType: l(
    "EXECUTE_EXTRACT_PIECE_INFORMATION"
    /* EXECUTE_EXTRACT_PIECE_INFORMATION */
  ),
  projectId: ue(),
  platformId: e(),
  piece: S,
  requestId: e(),
  webserverId: e()
}), ze = D([
  $,
  Z,
  Q,
  ee
]);
D([
  $.omit({ schemaVersion: !0, requestId: !0, webserverId: !0 }),
  Z.omit({ schemaVersion: !0, requestId: !0, webserverId: !0 }),
  Q.omit({ schemaVersion: !0, requestId: !0, webserverId: !0 }),
  ee.omit({ schemaVersion: !0, requestId: !0, webserverId: !0 })
]);
const Je = i({
  schemaVersion: o(),
  jobType: l(
    "EXECUTE_CHAT_AGENT"
    /* EXECUTE_CHAT_AGENT */
  ),
  conversationId: e(),
  projectId: e().nullable(),
  platformId: e(),
  userId: e(),
  userMessage: e(),
  modelName: e().nullable(),
  files: y(i({
    name: e(),
    mimeType: e(),
    data: e()
  })).optional()
}), We = i({
  schemaVersion: o(),
  platformId: e(),
  projectId: e().optional(),
  webhookId: e(),
  webhookUrl: e(),
  payload: Re,
  jobType: l(
    "EVENT_DESTINATION"
    /* EVENT_DESTINATION */
  )
}), Xe = D([
  Fe,
  Ve,
  Ke,
  qe,
  ze,
  We,
  Je
]);
var O = /* @__PURE__ */ ((s) => (s.ONLINE = "ONLINE", s.OFFLINE = "OFFLINE", s))(O || {}), E = /* @__PURE__ */ ((s) => (s.SHARED = "SHARED", s.DEDICATED = "DEDICATED", s))(E || {}), te = /* @__PURE__ */ ((s) => (s.UNRESTRICTED = "UNRESTRICTED", s.STRICT = "STRICT", s))(te || {});
const Ye = i({
  cpuUsagePercentage: o(),
  diskInfo: i({
    total: o(),
    free: o(),
    used: o(),
    percentage: o()
  }),
  workerId: e(),
  workerProps: f(e(), e()),
  ramUsagePercentage: o(),
  totalAvailableRamInBytes: o(),
  totalCpuCores: o(),
  ip: e()
}), $e = i({
  ...he,
  information: Ye
});
$e.extend({
  status: x(O),
  type: x(E),
  workerGroupId: e().optional()
});
i({
  jobId: e(),
  jobData: Xe,
  attempsStarted: o(),
  engineToken: e(),
  token: e(),
  queueName: e()
});
i({
  status: x(Ee),
  errorMessage: e().optional(),
  logs: e().optional(),
  response: T().optional()
});
i({
  PUBLIC_URL: e(),
  TRIGGER_TIMEOUT_SECONDS: o(),
  TRIGGER_HOOKS_TIMEOUT_SECONDS: o(),
  PAUSED_FLOW_TIMEOUT_DAYS: o(),
  EXECUTION_MODE: e(),
  FLOW_TIMEOUT_SECONDS: o(),
  LOG_LEVEL: e(),
  LOG_PRETTY: e(),
  ENVIRONMENT: e(),
  APP_WEBHOOK_SECRETS: e(),
  MAX_FLOW_RUN_LOG_SIZE_MB: o(),
  MAX_FILE_SIZE_MB: o(),
  SANDBOX_MEMORY_LIMIT: e(),
  SANDBOX_PROPAGATED_ENV_VARS: y(e()),
  DEV_PIECES: y(e()),
  SENTRY_DSN: e().optional(),
  LOKI_PASSWORD: e().optional(),
  LOKI_URL: e().optional(),
  LOKI_USERNAME: e().optional(),
  BETTERSTACK_HOST: e().optional(),
  BETTERSTACK_TOKEN: e().optional(),
  OTEL_ENABLED: I(),
  HYPERDX_TOKEN: e().optional(),
  FILE_STORAGE_LOCATION: e(),
  S3_USE_SIGNED_URLS: e(),
  EVENT_DESTINATION_TIMEOUT_SECONDS: o(),
  WORKER_GROUP_ID: e().optional(),
  EDITION: e(),
  NETWORK_MODE: fe(te),
  SSRF_ALLOW_LIST: y(e()),
  PAGE_ONCALL_WEBHOOK: e().optional()
});
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ze = [
  ["rect", { width: "20", height: "8", x: "2", y: "2", rx: "2", ry: "2", key: "ngkwjq" }],
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", ry: "2", key: "iecqi9" }],
  ["line", { x1: "6", x2: "6.01", y1: "6", y2: "6", key: "16zg32" }],
  ["line", { x1: "6", x2: "6.01", y1: "18", y2: "18", key: "nzw8ys" }]
], se = G("server", Ze);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Qe = [
  ["path", { d: "M10 5H3", key: "1qgfaw" }],
  ["path", { d: "M12 19H3", key: "yhmn1j" }],
  ["path", { d: "M14 3v4", key: "1sua03" }],
  ["path", { d: "M16 17v4", key: "1q0r14" }],
  ["path", { d: "M21 12h-9", key: "1o4lsq" }],
  ["path", { d: "M21 19h-5", key: "1rlt1p" }],
  ["path", { d: "M21 5h-7", key: "1oszz2" }],
  ["path", { d: "M8 10v4", key: "tgpxqk" }],
  ["path", { d: "M8 12H3", key: "a7s4jb" }]
], et = G("sliders-horizontal", Qe), tt = {
  list() {
    return ge.get("/v1/worker-machines");
  }
}, st = {
  all: ["worker-machines"]
}, at = {
  useWorkerMachines: () => Ie({
    queryKey: st.all,
    staleTime: 0,
    gcTime: 0,
    refetchInterval: 5e3,
    queryFn: () => tt.list()
  })
}, rt = [
  "B",
  "kB",
  "MB",
  "GB",
  "TB",
  "PB",
  "EB",
  "ZB",
  "YB"
], ot = [
  "B",
  "KiB",
  "MiB",
  "GiB",
  "TiB",
  "PiB",
  "EiB",
  "ZiB",
  "YiB"
], nt = [
  "b",
  "kbit",
  "Mbit",
  "Gbit",
  "Tbit",
  "Pbit",
  "Ebit",
  "Zbit",
  "Ybit"
], it = [
  "b",
  "kibit",
  "Mibit",
  "Gibit",
  "Tibit",
  "Pibit",
  "Eibit",
  "Zibit",
  "Yibit"
], U = (s, a, r) => {
  let n = s;
  return typeof a == "string" || Array.isArray(a) ? n = s.toLocaleString(a, r) : (a === !0 || r !== void 0) && (n = s.toLocaleString(void 0, r)), n;
}, ae = (s) => {
  if (typeof s == "number")
    return Math.log10(s);
  const a = s.toString(10);
  return a.length + Math.log10(`0.${a.slice(0, 15)}`);
}, ct = (s) => typeof s == "number" ? Math.log(s) : ae(s) * Math.log(10), lt = (s, a) => {
  if (typeof s == "number")
    return s / a;
  const r = s / BigInt(a), n = s % BigInt(a);
  return Number(r) + Number(n) / a;
}, V = (s, a) => {
  if (a === void 0)
    return s;
  if (typeof a != "number" || !Number.isSafeInteger(a) || a < 0)
    throw new TypeError(`Expected fixedWidth to be a non-negative integer, got ${typeof a}: ${a}`);
  return a === 0 ? s : s.length < a ? s.padStart(a, " ") : s;
}, dt = (s) => {
  const { minimumFractionDigits: a, maximumFractionDigits: r } = s;
  if (!(a === void 0 && r === void 0))
    return {
      ...a !== void 0 && { minimumFractionDigits: a },
      ...r !== void 0 && { maximumFractionDigits: r },
      roundingMode: "trunc"
    };
};
function b(s, a) {
  if (typeof s != "bigint" && !Number.isFinite(s))
    throw new TypeError(`Expected a finite number, got ${typeof s}: ${s}`);
  a = {
    bits: !1,
    binary: !1,
    space: !0,
    nonBreakingSpace: !1,
    ...a
  };
  const r = a.bits ? a.binary ? it : nt : a.binary ? ot : rt, n = a.space ? a.nonBreakingSpace ? " " : " " : "", m = typeof s == "number" ? s === 0 : s === 0n;
  if (a.signed && m) {
    const h = ` 0${n}${r[0]}`;
    return V(h, a.fixedWidth);
  }
  const u = s < 0, p = u ? "-" : a.signed ? "+" : "";
  u && (s = -s);
  const d = dt(a);
  let g;
  if (s < 1) {
    const h = U(s, a.locale, d);
    g = p + h + n + r[0];
  } else {
    const h = Math.min(Math.floor(a.binary ? ct(s) / Math.log(1024) : ae(s) / 3), r.length - 1);
    if (s = lt(s, (a.binary ? 1024 : 1e3) ** h), !d) {
      const v = Math.max(3, Math.floor(s).toString().length);
      s = s.toPrecision(v);
    }
    const N = U(Number(s), a.locale, d), j = r[h];
    g = p + N + n + j;
  }
  return V(g, a.fixedWidth);
}
const ut = (s) => {
  const [a, r] = A.useState(
    () => C.formatDateToAgo(s)
  );
  return A.useEffect(() => {
    const m = setInterval(() => {
      r(C.formatDateToAgo(s));
    }, (() => {
      const u = R(), p = R(s), d = u.diff(p, "second");
      return d < 60 ? 1e3 : d < 3600 ? 6e4 : d < 86400 ? 36e5 : 864e5;
    })());
    return () => clearInterval(m);
  }, [s]), a;
}, pt = ({ workerProps: s }) => {
  const a = Object.entries(s ?? {});
  return /* @__PURE__ */ t.jsxs(Te, { children: [
    /* @__PURE__ */ t.jsx(ye, { asChild: !0, children: /* @__PURE__ */ t.jsx(
      Ne,
      {
        variant: "ghost",
        size: "icon",
        className: "size-7 text-muted-foreground hover:text-foreground",
        title: c("Configs"),
        children: /* @__PURE__ */ t.jsx(et, { size: 14 })
      }
    ) }),
    /* @__PURE__ */ t.jsx(je, { className: "w-auto p-0", align: "end", children: /* @__PURE__ */ t.jsxs("table", { className: "text-xs", children: [
      /* @__PURE__ */ t.jsx("thead", { children: /* @__PURE__ */ t.jsxs("tr", { className: "border-b", children: [
        /* @__PURE__ */ t.jsx("th", { className: "px-3 py-2 text-left font-medium text-muted-foreground", children: c("Variable") }),
        /* @__PURE__ */ t.jsx("th", { className: "px-3 py-2 text-left font-medium text-muted-foreground", children: c("Value") })
      ] }) }),
      /* @__PURE__ */ t.jsx("tbody", { children: a.map(([r, n]) => /* @__PURE__ */ t.jsxs("tr", { className: "border-b last:border-b-0", children: [
        /* @__PURE__ */ t.jsx("td", { className: "px-3 py-2 font-mono font-medium", children: r }),
        /* @__PURE__ */ t.jsx("td", { className: "px-3 py-2 font-mono text-muted-foreground", children: n })
      ] }, r)) })
    ] }) })
  ] });
};
function gt() {
  var u;
  const { data: s } = be.useFlag(De.EDITION), a = s === Se.CLOUD, { data: r, isLoading: n } = at.useWorkerMachines(), m = (u = r == null ? void 0 : r[0]) == null ? void 0 : u.type;
  return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col w-full gap-4 px-4", children: [
    /* @__PURE__ */ t.jsx(
      ke,
      {
        description: c("Check the health of your workers"),
        title: c("Workers")
      }
    ),
    a && m === E.SHARED && /* @__PURE__ */ t.jsxs(k, { variant: "primary", children: [
      /* @__PURE__ */ t.jsx(M, { size: 16 }),
      /* @__PURE__ */ t.jsx(B, { children: c("Upgrade to Dedicated Workers") }),
      /* @__PURE__ */ t.jsx(P, { className: "text-xs", children: c(
        "Your automations run on shared workers where strict sandboxing adds overhead to every execution. Dedicated workers give you your own execution pool that stays warm and ready, so your automations start much faster."
      ) }),
      /* @__PURE__ */ t.jsx(ve, { children: /* @__PURE__ */ t.jsx(
        we,
        {
          featureKey: "DEDICATED_WORKERS",
          buttonVariant: "default",
          buttonSize: "xs"
        }
      ) })
    ] }),
    a && m === E.DEDICATED && /* @__PURE__ */ t.jsxs(k, { variant: "success", children: [
      /* @__PURE__ */ t.jsx(M, { size: 16 }),
      /* @__PURE__ */ t.jsx(B, { children: c("Dedicated Workers Active") }),
      /* @__PURE__ */ t.jsx(P, { className: "text-xs", children: c(
        "Your workers run exclusively for your platform. The execution pool stays warm with no sandboxing overhead, so your automations start instantly."
      ) })
    ] }),
    n && /* @__PURE__ */ t.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4", children: [0, 1, 2].map((p) => /* @__PURE__ */ t.jsxs(K, { className: "animate-pulse", children: [
      /* @__PURE__ */ t.jsx(q, { className: "pb-3", children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ t.jsx("div", { className: "h-4 w-28 bg-muted rounded" }),
        /* @__PURE__ */ t.jsx("div", { className: "h-5 w-16 bg-muted rounded-full" })
      ] }) }),
      /* @__PURE__ */ t.jsxs(z, { className: "space-y-3", children: [
        /* @__PURE__ */ t.jsx("div", { className: "h-3 w-full bg-muted rounded" }),
        /* @__PURE__ */ t.jsx("div", { className: "h-3 w-full bg-muted rounded" }),
        /* @__PURE__ */ t.jsx("div", { className: "h-3 w-full bg-muted rounded" })
      ] }),
      /* @__PURE__ */ t.jsx(J, { children: /* @__PURE__ */ t.jsx("div", { className: "h-4 w-full bg-muted rounded" }) })
    ] }, p)) }),
    !n && (r ?? []).length === 0 && /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col items-center justify-center py-16 gap-3 text-muted-foreground", children: [
      /* @__PURE__ */ t.jsx(se, { className: "size-14" }),
      /* @__PURE__ */ t.jsx("p", { className: "font-medium text-foreground", children: c("No workers found") }),
      /* @__PURE__ */ t.jsx("p", { className: "text-sm text-center max-w-sm", children: c(
        "You don't have any workers yet. Spin up new workers to execute your automations"
      ) })
    ] }),
    !n && (r ?? []).length > 0 && /* @__PURE__ */ t.jsx("div", { className: "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4", children: (r ?? []).map((p, d) => /* @__PURE__ */ t.jsx(
      mt,
      {
        worker: p,
        index: d,
        isCloud: a
      },
      p.id
    )) })
  ] });
}
function w({ label: s, value: a, detail: r }) {
  const n = a > 95 ? "bg-destructive" : a > 80 ? "bg-warning" : "bg-emerald-500";
  return /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ t.jsx("span", { className: "w-16 text-xs text-muted-foreground shrink-0 flex items-center gap-1.5", children: s }),
    /* @__PURE__ */ t.jsx("div", { className: "flex-1 h-2 bg-muted rounded-full overflow-hidden", children: /* @__PURE__ */ t.jsx(
      "div",
      {
        className: W("h-full rounded-full", n),
        style: { width: `${Math.min(a, 100)}%` }
      }
    ) }),
    /* @__PURE__ */ t.jsxs("span", { className: "text-xs font-medium w-10 text-right shrink-0", children: [
      a.toFixed(1),
      "%"
    ] }),
    r && /* @__PURE__ */ t.jsx("span", { className: "text-xs text-foreground shrink-0 w-28 text-right", children: r })
  ] });
}
function mt({ worker: s, index: a, isCloud: r }) {
  const n = ut(new Date(s.updated)), m = s.status === O.ONLINE, {
    diskInfo: u,
    cpuUsagePercentage: p,
    ramUsagePercentage: d,
    totalAvailableRamInBytes: g,
    ip: h,
    workerProps: N,
    totalCpuCores: j
  } = s.information, v = g * (d / 100), re = u.used, oe = N.version ?? "v0.39.4";
  return /* @__PURE__ */ t.jsxs(K, { children: [
    /* @__PURE__ */ t.jsx(q, { className: "pb-3", children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
        /* @__PURE__ */ t.jsx(
          se,
          {
            size: 18,
            className: W("shrink-0", {
              "text-destructive": !m
            })
          }
        ),
        /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col min-w-0", children: [
          /* @__PURE__ */ t.jsxs("span", { className: "text-sm font-medium truncate", children: [
            "Machine #",
            a + 1
          ] }),
          /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground font-mono", children: h })
        ] })
      ] }),
      /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1.5 shrink-0", children: [
        r && /* @__PURE__ */ t.jsxs(_e, { children: [
          /* @__PURE__ */ t.jsx(Oe, { asChild: !0, children: /* @__PURE__ */ t.jsx(
            L,
            {
              variant: s.type === E.DEDICATED ? "success" : "secondary",
              children: s.type === E.DEDICATED ? c("Dedicated") : c("Shared")
            }
          ) }),
          /* @__PURE__ */ t.jsx(Ae, { className: "max-w-xs", children: s.type === E.DEDICATED ? c(
            "This worker runs exclusively for your platform with no sandboxing overhead."
          ) : c(
            "This worker is shared across platforms and uses strict sandboxing for isolation."
          ) })
        ] }),
        /* @__PURE__ */ t.jsx(L, { variant: m ? "success" : "destructive", children: c(s.status.toLowerCase()) }),
        /* @__PURE__ */ t.jsx(pt, { workerProps: N })
      ] })
    ] }) }),
    /* @__PURE__ */ t.jsxs(z, { className: "space-y-2.5", children: [
      /* @__PURE__ */ t.jsx(
        w,
        {
          label: /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
            /* @__PURE__ */ t.jsx(Me, { className: "size-3" }),
            /* @__PURE__ */ t.jsx("span", { children: "CPU" })
          ] }),
          value: p,
          detail: `${j} core${j === 1 ? "" : "s"}`
        }
      ),
      /* @__PURE__ */ t.jsx(
        w,
        {
          label: /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
            /* @__PURE__ */ t.jsx(Be, { className: "size-3" }),
            /* @__PURE__ */ t.jsx("span", { children: "RAM" })
          ] }),
          value: d,
          detail: `${b(v, {
            binary: !0
          })} / ${b(g, { binary: !0 })}`
        }
      ),
      /* @__PURE__ */ t.jsx(
        w,
        {
          label: /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
            /* @__PURE__ */ t.jsx(Pe, { className: "size-3" }),
            /* @__PURE__ */ t.jsx("span", { children: "Disk" })
          ] }),
          value: u.percentage,
          detail: `${b(re, {
            binary: !0
          })} / ${b(u.total, { binary: !0 })}`
        }
      )
    ] }),
    /* @__PURE__ */ t.jsxs(J, { className: "justify-between pt-0 gap-2", children: [
      /* @__PURE__ */ t.jsx("div", { className: "flex items-center gap-3 text-xs text-muted-foreground min-w-0", children: /* @__PURE__ */ t.jsxs("span", { className: "flex items-center gap-1 truncate", children: [
        /* @__PURE__ */ t.jsx(Ce, { size: 12, className: "shrink-0" }),
        c("seen"),
        " ",
        n
      ] }) }),
      /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground font-mono shrink-0", children: oe })
    ] })
  ] });
}
export {
  gt as default
};
