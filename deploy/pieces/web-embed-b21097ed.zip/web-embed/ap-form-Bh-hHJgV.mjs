import { o as u, b as $, s as r, w as F, a as v, m as R, l as E, e as f, cm as K, j as a, h as b, eq as B, g as k, be as W, bf as H, c0 as Y, c1 as J, b6 as Q, aJ as y, a6 as h, c2 as z, cJ as Z, cK as ee, fh as se, cL as ae, c3 as te, c4 as L, c9 as T, c7 as re, c5 as A, id as I, aI as ne, aX as D, i as oe, aU as ce, dW as ie, u as le } from "./mount-builder-CqIEWsZv.mjs";
var l = /* @__PURE__ */ ((e) => (e.TEXT = "text", e.FILE = "file", e.TEXT_AREA = "text_area", e.TOGGLE = "toggle", e))(l || {});
const de = u({
  displayName: r(),
  required: F(),
  description: r(),
  type: $(l)
}), me = u({
  inputs: v(de),
  waitForResponse: F()
});
u({
  id: r(),
  title: r(),
  props: me,
  projectId: r(),
  version: r()
});
const ue = u({
  botName: r()
});
u({
  id: r(),
  title: r(),
  props: ue,
  projectId: r(),
  platformLogoUrl: r(),
  platformName: r()
});
const S = "useDraft", pe = u({
  base64Url: r(),
  fileName: r(),
  extension: r().optional()
}), he = u({
  mimeType: r(),
  url: r(),
  fileName: r().optional()
}), U = R([pe, he]);
var j = /* @__PURE__ */ ((e) => (e.FILE = "file", e.MARKDOWN = "markdown", e))(j || {});
function O(e) {
  return e.toLowerCase().replace(/\s+(\w)/g, (n, o) => o.toUpperCase()).replace(/^(.)/, (n) => n.toLowerCase()).replaceAll(/[\\"''\n\r\t]/g, "");
}
R([
  u({
    type: E(
      "file"
      /* FILE */
    ),
    value: U
  }),
  u({
    type: E(
      "markdown"
      /* MARKDOWN */
    ),
    value: r(),
    files: v(U).optional()
  })
]);
u({
  sessionId: r(),
  message: r(),
  files: v(r()).optional()
});
const fe = {
  getForm: (e, t) => f.get(`/v1/human-input/form/${e}`, {
    [S]: t ?? !1
  }),
  getChatUI: (e, t) => f.get(`/v1/human-input/chat/${e}`, {
    [S]: t ?? !1
  }),
  submitForm: async (e, t, n) => {
    const o = await ge(
      n,
      e
    ), d = _(
      t ? "draft" : "locked",
      e.props.waitForResponse
    );
    return f.post(
      `/v1/webhooks/${e.id}${d}`,
      o,
      void 0,
      {
        "Content-Type": o instanceof FormData ? "multipart/form-data" : "application/json"
      }
    );
  },
  sendMessage: async ({
    flowId: e,
    chatId: t,
    message: n,
    files: o,
    mode: d
  }) => {
    const i = new FormData();
    i.append("chatId", t), i.append("message", n), o.forEach((x, g) => {
      i.append(`file[${g}]`, x);
    });
    const m = _(d, !0);
    return f.post(
      `/v1/webhooks/${e}${m}`,
      i,
      void 0,
      {
        "Content-Type": "multipart/form-data"
      }
    );
  }
}, xe = (e) => new Promise((t, n) => {
  const o = new FileReader();
  o.readAsDataURL(e), o.onloadend = () => {
    o.result ? t(o.result) : n(new Error("Failed to read file"));
  }, o.onerror = () => {
    n(o.error);
  };
});
async function ge(e, t) {
  const n = K.gte(t.version, "0.4.1"), o = new FormData(), d = {};
  for (const [i, m] of Object.entries(e))
    n ? o.append(i, m instanceof File ? m : String(m)) : d[i] = m instanceof File ? await xe(m) : m;
  return n ? o : d;
}
function _(e, t) {
  return e === "test" ? "/test" : e === "draft" ? t ? "/draft/sync" : "/draft" : t ? "/sync" : "";
}
const M = ({ show: e, position: t = "sticky" }) => e ? /* @__PURE__ */ a.jsx(
  "div",
  {
    className: b("bottom-3 right-5 pointer-events-none z-10000", t, {
      "-mt-[30px]": t === "sticky",
      "mr-5": t === "sticky"
    }),
    children: /* @__PURE__ */ a.jsxs(
      "div",
      {
        className: b(
          "justify-end p-1 text-muted-foreground/70 text-sm items-center flex gap-1 transition group ",
          {
            "justify-center": t === "static"
          }
        ),
        children: [
          /* @__PURE__ */ a.jsx("div", { className: " text-sm transition", children: "Built with" }),
          /* @__PURE__ */ a.jsxs("div", { className: "justify-center flex items-center gap-1", children: [
            /* @__PURE__ */ a.jsx(
              "svg",
              {
                width: 15,
                height: 15,
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 24 24",
                className: "transition fill-muted-foreground/70",
                children: /* @__PURE__ */ a.jsx("path", { d: "M6.46013 5.81759C5.30809 4.10962 5.75876 1.79113 7.46672 0.639093C9.17469 -0.512944 11.4932 -0.0622757 12.6452 1.64569L20.4261 13.1813C21.5781 14.8893 21.1274 17.2077 19.4195 18.3598C17.7115 19.5118 15.393 19.0611 14.241 17.3532L10.8676 12.3519C10.4339 11.8054 9.55114 11.8905 9.02108 12.4205C8.58152 12.8601 8.43761 13.9846 8.31301 14.9582C8.29474 15.1009 8.27689 15.2405 8.25858 15.3741C8.19097 16.0114 7.97092 16.6418 7.58762 17.2101C6.33511 19.067 3.81375 19.5565 1.95682 18.304C0.0998936 17.0515 -0.390738 14.5304 0.861776 12.6734C1.51136 11.7104 2.50224 11.1151 3.56472 10.9399L3.56322 10.9384C6.63307 10.4932 7.20222 7.02864 6.64041 6.08487L6.46013 5.81759Z" })
              }
            ),
            /* @__PURE__ */ a.jsx("div", { className: "font-semibold", children: "activepieces" })
          ] })
        ]
      }
    )
  }
) : null;
M.displayName = "ShowPoweredBy";
const we = (e, t) => t.reduce((n, o) => {
  const d = O(o.displayName);
  return n[d] = e[d], n;
}, {}), ye = (e) => {
  switch (e.type) {
    case l.TOGGLE:
      return F();
    case l.TEXT:
    case l.TEXT_AREA:
      return e.required ? r().min(1, h("This field is required")) : r();
    case l.FILE:
      return le();
  }
};
function je(e) {
  return {
    properties: u(
      e.reduce((t, n) => (t[n.name] = ye(n), t), {})
    ),
    defaultValues: e.reduce(
      (t, n) => (t[n.name] = n.type === l.TOGGLE ? !1 : "", t),
      {}
    )
  };
}
const P = (e) => {
  const t = document.createElement("a");
  "url" in e ? t.href = e.url : (t.download = e.fileName, t.href = e.base64Url, URL.revokeObjectURL(e.base64Url)), t.target = "_blank", t.rel = "noreferrer noopener", t.click();
}, Fe = ({ form: e, useDraft: t }) => {
  const n = B(), o = new URLSearchParams(n.search), d = Array.from(o.entries()).reduce(
    (s, [c, p]) => (s[c.toLowerCase()] = p, s),
    {}
  ), i = k.useRef(
    e.props.inputs.map((s) => ({
      ...s,
      name: O(s.displayName)
    }))
  ), m = je(i.current), x = { ...m.defaultValues };
  i.current.forEach((s) => {
    const c = d[s.name.toLowerCase()];
    c !== void 0 && (x[s.name] = c);
  });
  const [g, G] = k.useState(null), { data: q } = W.useFlag(
    H.SHOW_POWERED_BY_IN_FORM
  ), w = Y({
    defaultValues: x,
    resolver: J(m.properties)
  }), { mutate: V, isPending: X } = Q(
    {
      mutationFn: async () => fe.submitForm(
        e,
        t,
        we(w.getValues(), i.current)
      ),
      onSuccess: (s) => {
        switch (s == null ? void 0 : s.type) {
          case j.MARKDOWN: {
            G(s.value), s.files && s.files.forEach((c) => {
              P(c);
            });
            break;
          }
          case j.FILE:
            P(s.value);
            break;
          default:
            y.success(h("Your submission was successfully received."), {
              duration: 3e3
            });
            break;
        }
      },
      onError: (s) => {
        var c;
        f.isError(s) && (((c = s.response) == null ? void 0 : c.status) === 404 ? y.error(h("Flow not found"), {
          description: h(
            "The flow you are trying to submit to does not exist."
          ),
          duration: 3e3
        }) : y.error(h("The flow failed to execute."), {
          duration: 3e3
        })), console.error(s);
      }
    }
  );
  return /* @__PURE__ */ a.jsx("div", { className: "w-full h-full flex", children: /* @__PURE__ */ a.jsx("div", { className: "container py-20", children: /* @__PURE__ */ a.jsx(z, { ...w, children: /* @__PURE__ */ a.jsxs("form", { onSubmit: (s) => w.handleSubmit(() => V())(s), children: [
    /* @__PURE__ */ a.jsxs(Z, { className: "w-[500px] mx-auto", children: [
      /* @__PURE__ */ a.jsx(ee, { children: /* @__PURE__ */ a.jsx(se, { className: "text-center", children: e == null ? void 0 : e.title }) }),
      /* @__PURE__ */ a.jsxs(ae, { children: [
        /* @__PURE__ */ a.jsx("div", { className: "grid w-full items-center gap-3", children: i.current.map((s) => /* @__PURE__ */ a.jsx(
          te,
          {
            control: w.control,
            name: s.name,
            render: ({ field: c }) => /* @__PURE__ */ a.jsxs(a.Fragment, { children: [
              s.type === l.TOGGLE && /* @__PURE__ */ a.jsxs(a.Fragment, { children: [
                /* @__PURE__ */ a.jsxs(L, { className: "flex items-center gap-2 h-full", children: [
                  /* @__PURE__ */ a.jsx(T, { children: /* @__PURE__ */ a.jsx(
                    re,
                    {
                      onCheckedChange: (p) => c.onChange(p),
                      checked: c.value
                    }
                  ) }),
                  /* @__PURE__ */ a.jsx(
                    A,
                    {
                      htmlFor: s.name,
                      className: "flex items-center",
                      children: s.displayName
                    }
                  )
                ] }),
                /* @__PURE__ */ a.jsx(
                  I,
                  {
                    text: s.description ?? ""
                  }
                )
              ] }),
              s.type !== l.TOGGLE && /* @__PURE__ */ a.jsxs(L, { className: "flex flex-col gap-1", children: [
                /* @__PURE__ */ a.jsxs(
                  A,
                  {
                    htmlFor: s.name,
                    className: "flex items-center justify-between",
                    children: [
                      s.displayName,
                      " ",
                      s.required && "*"
                    ]
                  }
                ),
                /* @__PURE__ */ a.jsx(T, { className: "flex flex-col gap-1", children: /* @__PURE__ */ a.jsxs(a.Fragment, { children: [
                  s.type === l.TEXT_AREA && /* @__PURE__ */ a.jsx(
                    ne,
                    {
                      ...c,
                      name: s.name,
                      id: s.name,
                      onChange: c.onChange,
                      value: c.value
                    }
                  ),
                  s.type === l.TEXT && /* @__PURE__ */ a.jsx(
                    D,
                    {
                      ...c,
                      onChange: c.onChange,
                      id: s.name,
                      name: s.name,
                      value: c.value
                    }
                  ),
                  s.type === l.FILE && /* @__PURE__ */ a.jsx(
                    D,
                    {
                      name: s.name,
                      id: s.name,
                      onChange: (p) => {
                        var N;
                        const C = (N = p.target.files) == null ? void 0 : N[0];
                        C && c.onChange(C);
                      },
                      placeholder: s.displayName,
                      type: "file"
                    }
                  ),
                  /* @__PURE__ */ a.jsx(
                    I,
                    {
                      text: s.description ?? ""
                    }
                  )
                ] }) })
              ] })
            ] })
          },
          s.name
        )) }),
        /* @__PURE__ */ a.jsx(
          oe,
          {
            type: "submit",
            className: "w-full mt-4",
            loading: X,
            children: h("Submit")
          }
        ),
        g && /* @__PURE__ */ a.jsxs(a.Fragment, { children: [
          /* @__PURE__ */ a.jsx(ce, { className: "my-4" }),
          /* @__PURE__ */ a.jsx(ie, { markdown: g })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ a.jsx("div", { className: "mt-2", children: /* @__PURE__ */ a.jsx(M, { position: "static", show: q ?? !1 }) })
  ] }) }) }) });
};
Fe.displayName = "ApForm";
export {
  Fe as A,
  U as F,
  j as H,
  M as S,
  S as U,
  fe as h
};
