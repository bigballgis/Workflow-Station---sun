import { I, c0 as k, c1 as S, g as x, b6 as L, aJ as V, a6 as a, dR as A, j as e, c2 as B, c3 as c, c4 as i, c5 as t, aX as u, c8 as l, ep as E, i as D, o as G, s as d, bC as M } from "./mount-builder-CqIEWsZv.mjs";
import { C as q } from "./centered-page-C5JGBrkC.mjs";
const z = G({
  name: d(),
  logoUrl: d(),
  iconUrl: d(),
  faviconUrl: d(),
  color: d()
}), H = () => {
  var j, h, v;
  const { platform: s } = I.useCurrentPlatform(), r = k({
    defaultValues: {
      name: s == null ? void 0 : s.name,
      logoUrl: s == null ? void 0 : s.fullLogoUrl,
      iconUrl: s == null ? void 0 : s.logoIconUrl,
      faviconUrl: s == null ? void 0 : s.favIconUrl,
      color: s == null ? void 0 : s.primaryColor
    },
    resolver: S(z)
  }), g = x.useRef(null), f = x.useRef(null), p = x.useRef(null), { mutate: P, isPending: R } = L({
    mutationFn: async () => {
      var N, y, U, C, b, w;
      const o = (y = (N = g.current) == null ? void 0 : N.files) == null ? void 0 : y[0], m = (C = (U = f.current) == null ? void 0 : U.files) == null ? void 0 : C[0], F = (w = (b = p.current) == null ? void 0 : b.files) == null ? void 0 : w[0], n = new FormData();
      n.append("name", r.getValues().name), n.append("primaryColor", r.getValues().color), o && n.append("fullLogo", o), m && n.append("logoIcon", m), F && n.append("favIcon", F), await A.updateWithFormData(n, s.id), window.location.reload();
    },
    onSuccess: () => {
      V.success(a("Your changes have been saved."), {
        duration: 3e3
      }), r.reset(r.getValues());
    }
  });
  return /* @__PURE__ */ e.jsx(e.Fragment, { children: /* @__PURE__ */ e.jsx("div", { className: "grid gap-4", children: /* @__PURE__ */ e.jsx(B, { ...r, children: /* @__PURE__ */ e.jsxs(
    "form",
    {
      className: "grid space-y-4 mt-4",
      onSubmit: r.handleSubmit(() => P()),
      children: [
        /* @__PURE__ */ e.jsxs("div", { className: "max-w-[600px] grid space-y-4", children: [
          /* @__PURE__ */ e.jsx(
            c,
            {
              name: "name",
              render: ({ field: o }) => /* @__PURE__ */ e.jsxs(i, { className: "grid space-y-2", children: [
                /* @__PURE__ */ e.jsx(t, { htmlFor: "name", children: a("Platform Name") }),
                /* @__PURE__ */ e.jsx(
                  u,
                  {
                    ...o,
                    required: !0,
                    id: "name",
                    placeholder: a("Platform Name"),
                    className: "rounded-sm"
                  }
                ),
                /* @__PURE__ */ e.jsx(l, {})
              ] })
            }
          ),
          /* @__PURE__ */ e.jsx(
            c,
            {
              name: "logoUrl",
              render: () => /* @__PURE__ */ e.jsxs(i, { className: "grid space-y-2", children: [
                /* @__PURE__ */ e.jsx(t, { htmlFor: "logoFile", children: a("Logo") }),
                /* @__PURE__ */ e.jsx("div", { className: "flex flex-row gap-2 items-center", children: /* @__PURE__ */ e.jsx(
                  u,
                  {
                    type: "file",
                    ref: g,
                    defaultFileName: s == null ? void 0 : s.fullLogoUrl,
                    accept: "image/*",
                    id: "logoFile",
                    className: "rounded-sm"
                  }
                ) }),
                /* @__PURE__ */ e.jsx(l, {})
              ] })
            }
          ),
          /* @__PURE__ */ e.jsx(
            c,
            {
              name: "iconUrl",
              render: () => /* @__PURE__ */ e.jsxs(i, { className: "grid space-y-2", children: [
                /* @__PURE__ */ e.jsx(t, { htmlFor: "iconFile", children: a("Icon") }),
                /* @__PURE__ */ e.jsx("div", { className: "flex flex-row gap-2 items-center", children: /* @__PURE__ */ e.jsx(
                  u,
                  {
                    type: "file",
                    ref: f,
                    defaultFileName: s == null ? void 0 : s.logoIconUrl,
                    accept: "image/*",
                    id: "iconFile",
                    className: "rounded-sm"
                  }
                ) }),
                /* @__PURE__ */ e.jsx(l, {})
              ] })
            }
          ),
          /* @__PURE__ */ e.jsx(
            c,
            {
              name: "faviconUrl",
              render: () => /* @__PURE__ */ e.jsxs(i, { className: "grid space-y-2", children: [
                /* @__PURE__ */ e.jsx(t, { htmlFor: "faviconUrl", children: a("Favicon URL") }),
                /* @__PURE__ */ e.jsx("div", { className: "flex flex-row gap-2 items-center", children: /* @__PURE__ */ e.jsx(
                  u,
                  {
                    type: "file",
                    ref: p,
                    defaultFileName: s == null ? void 0 : s.favIconUrl,
                    accept: "image/*",
                    id: "faviconFile",
                    className: "rounded-sm"
                  }
                ) }),
                /* @__PURE__ */ e.jsx(l, {})
              ] })
            }
          ),
          /* @__PURE__ */ e.jsx(
            c,
            {
              name: "color",
              render: ({ field: o }) => /* @__PURE__ */ e.jsxs(i, { className: "grid space-y-2", children: [
                /* @__PURE__ */ e.jsx(t, { htmlFor: "color", children: a("Primary Color") }),
                /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row gap-2 items-center", children: [
                  /* @__PURE__ */ e.jsx(
                    E,
                    {
                      value: o.value,
                      onChange: (m) => o.onChange(m),
                      className: "flex flex-row gap-2 items-center"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(l, {})
                ] })
              ] })
            }
          )
        ] }),
        ((v = (h = (j = r == null ? void 0 : r.formState) == null ? void 0 : j.errors) == null ? void 0 : h.root) == null ? void 0 : v.serverError) && /* @__PURE__ */ e.jsx(l, { children: r.formState.errors.root.serverError.message }),
        /* @__PURE__ */ e.jsx("div", { className: "flex gap-2 justify-end mt-4", children: /* @__PURE__ */ e.jsx(
          D,
          {
            type: "submit",
            loading: R,
            disabled: !r.formState.isValid,
            children: a("Save")
          }
        ) })
      ]
    }
  ) }) }) });
}, T = () => {
  const { platform: s } = I.useCurrentPlatform();
  return /* @__PURE__ */ e.jsx(
    M,
    {
      featureKey: "BRANDING",
      locked: !s.plan.customAppearanceEnabled,
      lockTitle: a("Brand Activepieces"),
      lockDescription: a(
        "Give your users an experience that looks like you by customizing the color, logo and more"
      ),
      lockVideoUrl: "/ap-cdn/videos/showcase/appearance.mp4",
      children: /* @__PURE__ */ e.jsx(
        q,
        {
          title: a("Branding"),
          description: a("Configure the appearance for your platform."),
          children: /* @__PURE__ */ e.jsx(H, {})
        }
      )
    }
  );
};
export {
  T as BrandingPage
};
