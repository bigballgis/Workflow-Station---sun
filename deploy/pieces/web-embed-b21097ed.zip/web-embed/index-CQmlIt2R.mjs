import { c as g, e as b, d1 as S, I as y, H as F, d5 as O, d6 as U, g as p, as as C, d7 as w, d0 as j, d8 as x, a9 as k, D as o, a6 as t, j as e, bC as P, co as W, bi as H, cp as u, c_ as M, b4 as V, cY as R, aa as z, i as K, d9 as B, da as G, db as $, dc as q, dd as J, de as Y, aU as D, ag as Q, cX as N, cd as X } from "./mount-builder-CqIEWsZv.mjs";
import { A as a, s as Z } from "./index-C5tdr9I_.mjs";
import { D as ee } from "./dashboard-page-header-BfLKPs1b.mjs";
import { F as ae } from "./file-text-DULCzR4r.mjs";
import { K as se } from "./key-m_VycdsK.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const te = [
  ["path", { d: "M3 5h1", key: "1mv5vm" }],
  ["path", { d: "M3 12h1", key: "lp3yf2" }],
  ["path", { d: "M3 19h1", key: "w6f3n9" }],
  ["path", { d: "M8 5h1", key: "1nxr5w" }],
  ["path", { d: "M8 12h1", key: "1con00" }],
  ["path", { d: "M8 19h1", key: "k7p10e" }],
  ["path", { d: "M13 5h8", key: "a7qcls" }],
  ["path", { d: "M13 12h8", key: "h98zly" }],
  ["path", { d: "M13 19h8", key: "c3s6r1" }]
], re = g("logs", te);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ne = [
  ["path", { d: "M15 4V2", key: "z1p9b7" }],
  ["path", { d: "M15 16v-2", key: "px0unx" }],
  ["path", { d: "M8 9h2", key: "1g203m" }],
  ["path", { d: "M20 9h2", key: "19tzq7" }],
  ["path", { d: "M17.8 11.8 19 13", key: "yihg8r" }],
  ["path", { d: "M15 9h.01", key: "x1ddxp" }],
  ["path", { d: "M17.8 6.2 19 5", key: "fd4us0" }],
  ["path", { d: "m3 21 9-9", key: "1jfql5" }],
  ["path", { d: "M12.2 6.2 11 5", key: "i3da3b" }]
], _ = g("wand", ne), oe = {
  list(n) {
    return b.get("/v1/audit-events", n);
  }
}, ie = {
  all: (n) => ["audit-logs", n]
}, le = {
  useAuditLogs: () => {
    const [n] = S(), { platform: s } = y.useCurrentPlatform();
    return F({
      queryKey: ie.all(n.toString()),
      staleTime: 0,
      gcTime: 0,
      enabled: s.plan.auditLogEnabled,
      meta: { showErrorDialog: !0, loadSubsetOptions: {} },
      queryFn: async () => {
        const i = n.get(O), m = n.get(U), E = n.getAll("action"), c = n.getAll("projectId"), d = n.get("userId");
        return oe.list({
          cursor: i ?? void 0,
          limit: m ? parseInt(m) : void 0,
          action: E ?? void 0,
          projectId: c ?? void 0,
          userId: d ?? void 0,
          createdBefore: n.get("createdBefore") ?? void 0,
          createdAfter: n.get("createdAfter") ?? void 0
        });
      }
    });
  }
};
function xe() {
  var h;
  const { platform: n } = y.useCurrentPlatform(), [s, i] = p.useState(
    null
  ), [m, E] = p.useState(!1), { data: c } = C.useAll(), { data: d } = w.useUsers(), L = [
    {
      type: "select",
      title: t("Action"),
      accessorKey: "action",
      options: Object.values(a).map((r) => ({
        label: o.convertEnumToHumanReadable(r),
        value: r
      })),
      icon: _
    },
    {
      type: "select",
      title: t("Performed By"),
      accessorKey: "userId",
      options: ((h = d == null ? void 0 : d.data) == null ? void 0 : h.map((r) => ({
        label: r.email,
        value: r.id
      }))) ?? [],
      icon: j
    },
    {
      type: "select",
      title: t("Project"),
      accessorKey: "projectId",
      options: (c == null ? void 0 : c.map((r) => ({
        label: r.displayName,
        value: r.id
      }))) ?? [],
      icon: x
    },
    {
      type: "date",
      title: t("Created"),
      accessorKey: "created",
      icon: k
    }
  ], { data: A, isLoading: v } = le.useAuditLogs(), I = n.plan.auditLogEnabled;
  return /* @__PURE__ */ e.jsx(
    P,
    {
      featureKey: "AUDIT_LOGS",
      locked: !I,
      lockTitle: t("Unlock Audit Logs"),
      lockDescription: t(
        "Comply with internal and external security policies by tracking activities done within your account"
      ),
      children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col  w-full", children: [
        /* @__PURE__ */ e.jsx(
          ee,
          {
            description: t("Track activities done within your platform"),
            title: t("Audit Logs")
          }
        ),
        /* @__PURE__ */ e.jsx(
          W,
          {
            emptyStateTextTitle: t("No audit logs found"),
            emptyStateTextDescription: t(
              "Come back later when you have some activity to audit"
            ),
            emptyStateIcon: /* @__PURE__ */ e.jsx(G, { className: "size-14" }),
            filters: L,
            columns: [
              {
                accessorKey: "action",
                size: 180,
                header: ({ column: r }) => /* @__PURE__ */ e.jsx(
                  u,
                  {
                    column: r,
                    title: t("Action"),
                    icon: _
                  }
                ),
                cell: ({ row: r }) => {
                  const l = ce(r.original);
                  return /* @__PURE__ */ e.jsxs("div", { className: "text-left flex items-center gap-2", children: [
                    !H(l == null ? void 0 : l.icon) && /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground shrink-0", children: l.icon }),
                    o.convertEnumToHumanReadable(
                      r.original.action
                    )
                  ] });
                }
              },
              {
                accessorKey: "details",
                size: 320,
                header: ({ column: r }) => /* @__PURE__ */ e.jsx(
                  u,
                  {
                    column: r,
                    title: t("Details"),
                    icon: ae
                  }
                ),
                cell: ({ row: r }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: f(r.original) })
              },
              {
                accessorKey: "userId",
                size: 200,
                header: ({ column: r }) => /* @__PURE__ */ e.jsx(
                  u,
                  {
                    column: r,
                    title: t("Performed By"),
                    icon: M
                  }
                ),
                cell: ({ row: r }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: r.original.userEmail })
              },
              {
                accessorKey: "projectId",
                size: 130,
                header: ({ column: r }) => /* @__PURE__ */ e.jsx(
                  u,
                  {
                    column: r,
                    title: t("Project"),
                    icon: x
                  }
                ),
                cell: ({ row: r }) => {
                  var l;
                  return r.original.projectId && "project" in r.original.data ? /* @__PURE__ */ e.jsx(V, { to: `/projects/${r.original.projectId}`, children: /* @__PURE__ */ e.jsx("div", { className: "text-left text-primary hover:underline", children: (l = r.original.data.project) == null ? void 0 : l.displayName }) }) : /* @__PURE__ */ e.jsx("div", { className: "text-left", children: t("N/A") });
                }
              },
              {
                accessorKey: "created",
                size: 110,
                header: ({ column: r }) => /* @__PURE__ */ e.jsx(
                  u,
                  {
                    column: r,
                    title: t("Created"),
                    icon: z
                  }
                ),
                cell: ({ row: r }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(R, { date: new Date(r.original.created) }) })
              },
              {
                id: "view",
                size: 50,
                cell: ({ row: r }) => /* @__PURE__ */ e.jsx(
                  K,
                  {
                    variant: "ghost",
                    size: "icon",
                    className: "size-8",
                    onClick: () => {
                      i(r.original), E(!0);
                    },
                    children: /* @__PURE__ */ e.jsx(B, { className: "size-4 text-muted-foreground" })
                  }
                )
              }
            ],
            page: A,
            isLoading: v
          }
        ),
        /* @__PURE__ */ e.jsx($, { open: m, onOpenChange: E, children: /* @__PURE__ */ e.jsxs(q, { className: "w-[480px] sm:max-w-[480px] flex flex-col p-0", children: [
          /* @__PURE__ */ e.jsxs(J, { className: "px-6 py-4 border-b shrink-0", children: [
            /* @__PURE__ */ e.jsx(Y, { className: "text-base", children: o.convertEnumToHumanReadable(
              (s == null ? void 0 : s.action) ?? ""
            ) }),
            /* @__PURE__ */ e.jsx("p", { className: "text-sm text-muted-foreground mt-1", children: s && f(s) })
          ] }),
          /* @__PURE__ */ e.jsxs("div", { className: "flex-1 overflow-y-auto", children: [
            /* @__PURE__ */ e.jsxs("div", { className: "px-6 py-5 flex flex-col gap-4", children: [
              /* @__PURE__ */ e.jsx("p", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide", children: t("Who & When") }),
              /* @__PURE__ */ e.jsxs("div", { className: "grid grid-cols-[150px_1fr] gap-y-3 text-sm", children: [
                (s == null ? void 0 : s.userEmail) && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
                  /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: t("Performed By") }),
                  /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: s.userEmail })
                ] }),
                (s == null ? void 0 : s.projectDisplayName) && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
                  /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: t("Project") }),
                  /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: s.projectDisplayName })
                ] }),
                (s == null ? void 0 : s.ip) && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
                  /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: t("IP Address") }),
                  /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: s.ip })
                ] }),
                /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: t("Created") }),
                /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: s && /* @__PURE__ */ e.jsx(R, { date: new Date(s.created) }) })
              ] })
            ] }),
            s && T(s).length > 0 && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
              /* @__PURE__ */ e.jsx(D, {}),
              /* @__PURE__ */ e.jsxs("div", { className: "px-6 py-5 flex flex-col gap-4", children: [
                /* @__PURE__ */ e.jsx("p", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide", children: t("Event Details") }),
                /* @__PURE__ */ e.jsx("div", { className: "grid grid-cols-[150px_1fr] gap-y-3 text-sm", children: T(s).map(
                  ({ label: r, value: l }) => /* @__PURE__ */ e.jsxs(p.Fragment, { children: [
                    /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: r }),
                    /* @__PURE__ */ e.jsx("span", { className: "font-medium", children: l })
                  ] }, r)
                ) })
              ] })
            ] }),
            /* @__PURE__ */ e.jsx(D, {}),
            /* @__PURE__ */ e.jsxs("div", { className: "px-6 py-5 flex flex-col gap-4", children: [
              /* @__PURE__ */ e.jsx("p", { className: "text-xs font-semibold text-muted-foreground uppercase tracking-wide", children: t("Full Payload") }),
              /* @__PURE__ */ e.jsx(Q, { data: (s == null ? void 0 : s.data) ?? {} })
            ] })
          ] })
        ] }) })
      ] })
    }
  );
}
function ce(n) {
  switch (n.action) {
    case a.FLOW_RUN_FINISHED:
    case a.FLOW_RUN_STARTED:
    case a.FLOW_RUN_RESUMED:
    case a.FLOW_RUN_RETRIED:
      return {
        icon: /* @__PURE__ */ e.jsx(re, { className: "size-4" }),
        tooltip: t("Flow Run")
      };
    case a.FLOW_CREATED:
    case a.FLOW_DELETED:
    case a.FLOW_UPDATED:
    case a.FLOW_PUBLISHED:
    case a.FLOW_ACTIVATED:
    case a.FLOW_DEACTIVATED:
      return {
        icon: /* @__PURE__ */ e.jsx(X, { className: "size-4" }),
        tooltip: t("Flow")
      };
    case a.FOLDER_CREATED:
    case a.FOLDER_DELETED:
    case a.FOLDER_UPDATED:
      return {
        icon: /* @__PURE__ */ e.jsx(x, { className: "size-4" }),
        tooltip: t("Folder")
      };
    case a.CONNECTION_DELETED:
    case a.CONNECTION_UPSERTED:
      return {
        icon: /* @__PURE__ */ e.jsx(N, { className: "size-4" }),
        tooltip: t("Connection")
      };
    case a.VARIABLE_UPSERTED:
    case a.VARIABLE_DELETED:
    case a.VARIABLE_VALUE_REVEALED:
      return {
        icon: /* @__PURE__ */ e.jsx(N, { className: "size-4" }),
        tooltip: t("Variable")
      };
    case a.USER_SIGNED_UP:
    case a.USER_SIGNED_IN:
    case a.USER_PASSWORD_RESET:
    case a.USER_EMAIL_VERIFIED:
      return {
        icon: /* @__PURE__ */ e.jsx(j, { className: "size-4" }),
        tooltip: t("User")
      };
    case a.SIGNING_KEY_CREATED:
      return {
        icon: /* @__PURE__ */ e.jsx(se, { className: "size-4" }),
        tooltip: t("Signing Key")
      };
    default:
      return;
  }
}
function f(n) {
  switch (n.action) {
    case a.FLOW_RUN_STARTED:
      return `Flow run started in ${o.convertEnumToHumanReadable(
        n.data.flowRun.environment
      )} environment`;
    case a.FLOW_RUN_FINISHED:
      return `Flow run finished — ${o.convertEnumToHumanReadable(
        n.data.flowRun.status
      )}`;
    case a.FLOW_RUN_RESUMED:
      return `Flow run resumed in ${o.convertEnumToHumanReadable(
        n.data.flowRun.environment
      )} environment`;
    case a.FLOW_RUN_RETRIED:
      return `Flow run retried from failed step in ${o.convertEnumToHumanReadable(
        n.data.flowRun.environment
      )} environment`;
    case a.FLOW_CREATED:
      return t("A new flow was created");
    case a.FLOW_DELETED:
      return `Flow "${n.data.flowVersion.displayName}" was deleted`;
    default:
      return Z(n) ?? "";
  }
}
function T(n) {
  switch (n.action) {
    case a.FLOW_RUN_STARTED:
    case a.FLOW_RUN_FINISHED:
    case a.FLOW_RUN_RESUMED:
    case a.FLOW_RUN_RETRIED: {
      const { flowRun: s } = n.data, i = [
        {
          label: t("Status"),
          value: o.convertEnumToHumanReadable(s.status)
        },
        {
          label: t("Environment"),
          value: o.convertEnumToHumanReadable(s.environment)
        }
      ];
      return s.triggeredBy && i.push({
        label: t("Triggered By"),
        value: o.convertEnumToHumanReadable(s.triggeredBy)
      }), s.startTime && i.push({
        label: t("Start Time"),
        value: new Date(s.startTime).toLocaleString()
      }), s.finishTime && i.push({
        label: t("Finish Time"),
        value: new Date(s.finishTime).toLocaleString()
      }), i;
    }
    case a.FLOW_CREATED:
      return [];
    case a.FLOW_DELETED:
    case a.FLOW_UPDATED:
    case a.FLOW_PUBLISHED:
    case a.FLOW_ACTIVATED:
    case a.FLOW_DEACTIVATED:
      return [{ label: t("Flow"), value: n.data.flowVersion.displayName }];
    case a.CONNECTION_UPSERTED:
    case a.CONNECTION_DELETED: {
      const { connection: s } = n.data;
      return [
        { label: t("Connection"), value: s.displayName },
        { label: t("Piece"), value: s.pieceName ?? t("N/A") },
        {
          label: t("Type"),
          value: o.convertEnumToHumanReadable(s.type)
        },
        {
          label: t("Status"),
          value: o.convertEnumToHumanReadable(s.status)
        }
      ];
    }
    case a.VARIABLE_UPSERTED:
    case a.VARIABLE_DELETED:
    case a.VARIABLE_VALUE_REVEALED: {
      const { variable: s } = n.data;
      return [{ label: t("Variable"), value: s.name }];
    }
    case a.FOLDER_CREATED:
    case a.FOLDER_UPDATED:
    case a.FOLDER_DELETED:
      return [{ label: t("Folder"), value: n.data.folder.displayName }];
    case a.USER_SIGNED_IN:
    case a.USER_PASSWORD_RESET:
    case a.USER_EMAIL_VERIFIED:
      return [];
    case a.USER_SIGNED_UP:
      return [
        {
          label: t("Source"),
          value: o.convertEnumToHumanReadable(n.data.source)
        }
      ];
    case a.SIGNING_KEY_CREATED:
      return [
        { label: t("Key Name"), value: n.data.signingKey.displayName }
      ];
    case a.PROJECT_ROLE_CREATED:
    case a.PROJECT_ROLE_UPDATED:
    case a.PROJECT_ROLE_DELETED: {
      const { projectRole: s } = n.data;
      return [
        { label: t("Role"), value: s.name },
        {
          label: t("Permissions"),
          value: s.permissions.map((i) => o.convertEnumToHumanReadable(i)).join(", ")
        }
      ];
    }
    case a.PROJECT_RELEASE_CREATED: {
      const { release: s } = n.data, i = [
        { label: t("Release"), value: s.name },
        {
          label: t("Type"),
          value: o.convertEnumToHumanReadable(s.type)
        }
      ];
      return s.description && i.push({ label: t("Description"), value: s.description }), i;
    }
  }
}
export {
  xe as default
};
