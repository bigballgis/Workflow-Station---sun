import { fe as I } from "./mount-builder-CqIEWsZv.mjs";
function O(g, x) {
  for (var y = 0; y < x.length; y++) {
    const l = x[y];
    if (typeof l != "string" && !Array.isArray(l)) {
      for (const o in l)
        if (o !== "default" && !(o in g)) {
          const i = Object.getOwnPropertyDescriptor(l, o);
          i && Object.defineProperty(g, o, i.get ? i : {
            enumerable: !0,
            get: () => l[o]
          });
        }
    }
  }
  return Object.freeze(Object.defineProperty(g, Symbol.toStringTag, { value: "Module" }));
}
var S = { exports: {} }, w;
function j() {
  return w || (w = 1, function(g, x) {
    (function(y, l) {
      g.exports = l();
    })(window, function() {
      return function(y) {
        var l = {};
        function o(i) {
          if (l[i]) return l[i].exports;
          var u = l[i] = { i, l: !1, exports: {} };
          return y[i].call(u.exports, u, u.exports, o), u.l = !0, u.exports;
        }
        return o.m = y, o.c = l, o.d = function(i, u, d) {
          o.o(i, u) || Object.defineProperty(i, u, { enumerable: !0, get: d });
        }, o.r = function(i) {
          typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(i, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(i, "__esModule", { value: !0 });
        }, o.t = function(i, u) {
          if (1 & u && (i = o(i)), 8 & u || 4 & u && typeof i == "object" && i && i.__esModule) return i;
          var d = /* @__PURE__ */ Object.create(null);
          if (o.r(d), Object.defineProperty(d, "default", { enumerable: !0, value: i }), 2 & u && typeof i != "string") for (var c in i) o.d(d, c, (function(f) {
            return i[f];
          }).bind(null, c));
          return d;
        }, o.n = function(i) {
          var u = i && i.__esModule ? function() {
            return i.default;
          } : function() {
            return i;
          };
          return o.d(u, "a", u), u;
        }, o.o = function(i, u) {
          return Object.prototype.hasOwnProperty.call(i, u);
        }, o.p = "", o(o.s = 2);
      }([function(y, l, o) {
        o.r(l);
        var i = typeof fetch == "function" ? fetch.bind() : function(u, d) {
          return d = d || {}, new Promise(function(c, f) {
            var r = new XMLHttpRequest();
            for (var a in r.open(d.method || "get", u, !0), d.headers) r.setRequestHeader(a, d.headers[a]);
            function t() {
              var e, n = [], s = [], p = {};
              return r.getAllResponseHeaders().replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, function(h, m, b) {
                n.push(m = m.toLowerCase()), s.push([m, b]), e = p[m], p[m] = e ? e + "," + b : b;
              }), { ok: (r.status / 100 | 0) == 2, status: r.status, statusText: r.statusText, url: r.responseURL, clone: t, text: function() {
                return Promise.resolve(r.responseText);
              }, json: function() {
                return Promise.resolve(r.responseText).then(JSON.parse);
              }, blob: function() {
                return Promise.resolve(new Blob([r.response]));
              }, headers: { keys: function() {
                return n;
              }, entries: function() {
                return s;
              }, get: function(h) {
                return p[h.toLowerCase()];
              }, has: function(h) {
                return h.toLowerCase() in p;
              } } };
            }
            r.withCredentials = d.credentials == "include", r.onload = function() {
              c(t());
            }, r.onerror = f, r.send(d.body);
          });
        };
        l.default = i;
      }, function(y, l, o) {
        Object.defineProperty(l, "__esModule", { value: !0 });
        var i = /* @__PURE__ */ function() {
          function d(c, f) {
            for (var r = 0; r < f.length; r++) {
              var a = f[r];
              a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(c, a.key, a);
            }
          }
          return function(c, f, r) {
            return f && d(c.prototype, f), r && d(c, r), c;
          };
        }(), u = function() {
          function d(c, f) {
            (function(r, a) {
              if (!(r instanceof a)) throw new TypeError("Cannot call a class as a function");
            })(this, d), this.pluginName = c;
          }
          return i(d, [{ key: "track", value: function(c, f) {
            window.analytics.track(c, f, { integration: { name: this.pluginName } });
          } }]), d;
        }();
        l.default = u;
      }, function(y, l, o) {
        Object.defineProperty(l, "__esModule", { value: !0 }), l.YouTubeAnalytics = l.VimeoAnalytics = void 0;
        var i = d(o(3)), u = d(o(4));
        function d(c) {
          return c && c.__esModule ? c : { default: c };
        }
        l.VimeoAnalytics = i.default, l.YouTubeAnalytics = u.default;
      }, function(y, l, o) {
        Object.defineProperty(l, "__esModule", { value: !0 });
        var i = /* @__PURE__ */ function() {
          function f(r, a) {
            for (var t = 0; t < a.length; t++) {
              var e = a[t];
              e.enumerable = e.enumerable || !1, e.configurable = !0, "value" in e && (e.writable = !0), Object.defineProperty(r, e.key, e);
            }
          }
          return function(r, a, t) {
            return a && f(r.prototype, a), t && f(r, t), r;
          };
        }(), u = d(o(0));
        function d(f) {
          return f && f.__esModule ? f : { default: f };
        }
        var c = function(f) {
          function r(a, t) {
            (function(n, s) {
              if (!(n instanceof s)) throw new TypeError("Cannot call a class as a function");
            })(this, r);
            var e = function(n, s) {
              if (!n) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
              return !s || typeof s != "object" && typeof s != "function" ? n : s;
            }(this, (r.__proto__ || Object.getPrototypeOf(r)).call(this, "VimeoAnalytics"));
            return e.authToken = t, e.player = a, e.metadata = { content: {}, playback: { videoPlayer: "Vimeo" } }, e.mostRecentHeartbeat = 0, e.isPaused = !1, e;
          }
          return function(a, t) {
            if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            a.prototype = Object.create(t && t.prototype, { constructor: { value: a, enumerable: !1, writable: !0, configurable: !0 } }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(a, t) : a.__proto__ = t);
          }(r, f), i(r, [{ key: "initialize", value: function() {
            var a = this, t = { loaded: this.retrieveMetadata, play: this.trackPlay, pause: this.trackPause, ended: this.trackEnded, timeupdate: this.trackHeartbeat };
            for (var e in t) this.registerHandler(e, t[e]);
            this.player.getVideoId().then(function(n) {
              a.retrieveMetadata({ id: n });
            }).catch(console.error);
          } }, { key: "registerHandler", value: function(a, t) {
            var e = this;
            this.player.on(a, function(n) {
              e.updateMetadata(n), t.call(e, n);
            });
          } }, { key: "trackPlay", value: function() {
            this.isPaused ? (this.track("Video Playback Resumed", this.metadata.playback), this.isPaused = !1) : (this.track("Video Playback Started", this.metadata.playback), this.track("Video Content Started", this.metadata.content));
          } }, { key: "trackEnded", value: function() {
            this.track("Video Playback Completed", this.metadata.playback), this.track("Video Content Completed", this.metadata.content);
          } }, { key: "trackHeartbeat", value: function() {
            var a = this.mostRecentHeartbeat, t = this.metadata.playback.position;
            t !== a && t - a >= 10 && (this.track("Video Content Playing", this.metadata.content), this.mostRecentHeartbeat = Math.floor(t));
          } }, { key: "trackPause", value: function() {
            this.isPaused = !0, this.track("Video Playback Paused", this.metadata.playback);
          } }, { key: "retrieveMetadata", value: function(a) {
            var t = this;
            return new Promise(function(e, n) {
              var s = a.id;
              (0, u.default)("https://api.vimeo.com/videos/" + s, { headers: { Authorization: "Bearer " + t.authToken } }).then(function(p) {
                return p.ok ? p.json() : n(p);
              }).then(function(p) {
                t.metadata.content.title = p.name, t.metadata.content.description = p.description, t.metadata.content.publisher = p.user.name, t.metadata.playback.position = 0, t.metadata.playback.totalLength = p.duration;
              }).catch(function(p) {
                return console.error("Request to Vimeo API Failed with: ", p), n(p);
              });
            });
          } }, { key: "updateMetadata", value: function(a) {
            var t = this;
            return new Promise(function(e, n) {
              t.player.getVolume().then(function(s) {
                s && (t.metadata.playback.sound = 100 * s), t.metadata.playback.position = a.seconds, e();
              }).catch(n);
            });
          } }]), r;
        }(d(o(1)).default);
        l.default = c;
      }, function(y, l, o) {
        Object.defineProperty(l, "__esModule", { value: !0 });
        var i = /* @__PURE__ */ function() {
          function a(t, e) {
            for (var n = 0; n < e.length; n++) {
              var s = e[n];
              s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(t, s.key, s);
            }
          }
          return function(t, e, n) {
            return e && a(t.prototype, e), n && a(t, n), t;
          };
        }(), u = c(o(0)), d = c(o(1));
        function c(a) {
          return a && a.__esModule ? a : { default: a };
        }
        var f = function(a) {
          function t(e, n) {
            (function(p, h) {
              if (!(p instanceof h)) throw new TypeError("Cannot call a class as a function");
            })(this, t);
            var s = function(p, h) {
              if (!p) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
              return !h || typeof h != "object" && typeof h != "function" ? p : h;
            }(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, "YoutubeAnalytics"));
            return s.player = e, s.apiKey = n, s.playerLoaded = !1, s.playbackStarted = !1, s.contentStarted = !1, s.isPaused = !1, s.isBuffering = !1, s.isSeeking = !1, s.lastRecordedTime = { timeReported: Date.now(), timeElapsed: 0 }, s.metadata = [{ playback: { video_player: "youtube" }, content: {} }], s.playlistIndex = 0, s;
          }
          return function(e, n) {
            if (typeof n != "function" && n !== null) throw new TypeError("Super expression must either be null or a function, not " + typeof n);
            e.prototype = Object.create(n && n.prototype, { constructor: { value: e, enumerable: !1, writable: !0, configurable: !0 } }), n && (Object.setPrototypeOf ? Object.setPrototypeOf(e, n) : e.__proto__ = n);
          }(t, a), i(t, [{ key: "initialize", value: function() {
            window.segmentYoutubeOnStateChange = this.onPlayerStateChange.bind(this), window.segmentYoutubeOnReady = this.onPlayerReady.bind(this), this.player.addEventListener("onReady", "segmentYoutubeOnReady"), this.player.addEventListener("onStateChange", "segmentYoutubeOnStateChange");
          } }, { key: "onPlayerReady", value: function(e) {
            this.retrieveMetadata();
          } }, { key: "onPlayerStateChange", value: function(e) {
            var n = this.player.getCurrentTime();
            switch (this.metadata[this.playlistIndex] && (this.metadata[this.playlistIndex].playback.position = this.metadata[this.playlistIndex].content.position = n, this.metadata[this.playlistIndex].playback.quality = this.player.getPlaybackQuality(), this.metadata[this.playlistIndex].playback.sound = this.player.isMuted() ? 0 : this.player.getVolume()), e.data) {
              case -1:
                if (this.playerLoaded) break;
                this.retrieveMetadata(), this.playerLoaded = !0;
                break;
              case YT.PlayerState.BUFFERING:
                this.handleBuffer();
                break;
              case YT.PlayerState.PLAYING:
                this.handlePlay();
                break;
              case YT.PlayerState.PAUSED:
                this.handlePause();
                break;
              case YT.PlayerState.ENDED:
                this.handleEnd();
            }
            this.lastRecordedTime = { timeReported: Date.now(), timeElapsed: 1e3 * this.player.getCurrentTime() };
          } }, { key: "retrieveMetadata", value: function() {
            var e = this;
            return new Promise(function(n, s) {
              var p = e.player.getVideoData(), h = e.player.getPlaylist() || [p.video_id], m = h.join();
              (0, u.default)("https://www.googleapis.com/youtube/v3/videos?id=" + m + "&part=snippet,contentDetails&key=" + e.apiKey).then(function(b) {
                if (!b.ok) {
                  var v = new Error("Segment request to Youtube API failed (likely due to a bad API Key. Events will still be sent but will not contain video metadata)");
                  throw v.response = b, v;
                }
                return b.json();
              }).then(function(b) {
                e.metadata = [];
                for (var v = 0, k = 0; k < h.length; k++) {
                  var P = b.items[k];
                  e.metadata.push({ content: { title: P.snippet.title, description: P.snippet.description, keywords: P.snippet.tags, channel: P.snippet.channelTitle, airdate: P.snippet.publishedAt } }), v += r(P.contentDetails.duration);
                }
                for (k = 0; k < h.length; k++) e.metadata[k].playback = { total_length: v, video_player: "youtube" };
                n();
              }).catch(function(b) {
                e.metadata = h.map(function(v) {
                  return { playback: { video_player: "youtube" }, content: {} };
                }), s(b);
              });
            });
          } }, { key: "handleBuffer", value: function() {
            var e = this.determineSeek();
            this.playbackStarted || (this.playbackStarted = !0, this.track("Video Playback Started", this.metadata[this.playlistIndex].playback)), e && !this.isSeeking && (this.isSeeking = !0, this.track("Video Playback Seek Started", this.metadata[this.playlistIndex].playback)), this.isSeeking && (this.track("Video Playback Seek Completed", this.metadata[this.playlistIndex].playback), this.isSeeking = !1);
            var n = this.player.getPlaylist();
            n && this.player.getCurrentTime() === 0 && this.player.getPlaylistIndex() !== this.playlistIndex && (this.contentStarted = !1, this.playlistIndex === n.length - 1 && this.player.getPlaylistIndex() === 0 && (this.track("Video Playback Completed", this.metadata[this.player.getPlaylistIndex()].playback), this.track("Video Playback Started", this.metadata[this.player.getPlaylistIndex()].playback))), this.track("Video Playback Buffer Started", this.metadata[this.playlistIndex].playback), this.isBuffering = !0;
          } }, { key: "handlePlay", value: function() {
            this.contentStarted || (this.playlistIndex = this.player.getPlaylistIndex(), this.playlistIndex === -1 && (this.playlistIndex = 0), this.track("Video Content Started", this.metadata[this.playlistIndex].content), this.contentStarted = !0), this.isBuffering && (this.track("Video Playback Buffer Completed", this.metadata[this.playlistIndex].playback), this.isBuffering = !1), this.isPaused && (this.track("Video Playback Resumed", this.metadata[this.playlistIndex].playback), this.isPaused = !1);
          } }, { key: "handlePause", value: function() {
            var e = this.determineSeek();
            this.isBuffering && (this.track("Video Playback Buffer Completed", this.metadata[this.playlistIndex].playback), this.isBuffering = !1), this.isPaused || (e ? (this.track("Video Playback Seek Started", this.metadata[this.playlistIndex].playback), this.isSeeking = !0) : (this.track("Video Playback Paused", this.metadata[this.playlistIndex].playback), this.isPaused = !0));
          } }, { key: "handleEnd", value: function() {
            this.track("Video Content Completed", this.metadata[this.playlistIndex].content), this.contentStarted = !1;
            var e = this.player.getPlaylistIndex(), n = this.player.getPlaylist();
            (n && e === n.length - 1 || e === -1) && (this.track("Video Playback Completed", this.metadata[this.playlistIndex].playback), this.playbackStarted = !1);
          } }, { key: "determineSeek", value: function() {
            var e = this.isPaused || this.isBuffering ? 0 : Date.now() - this.lastRecordedTime.timeReported, n = 1e3 * this.player.getCurrentTime() - this.lastRecordedTime.timeElapsed;
            return Math.abs(e - n) > 2e3;
          } }]), t;
        }(d.default);
        function r(a) {
          var t = a.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
          return t = t.slice(1).map(function(e) {
            if (e != null) return e.replace(/\D/, "");
          }), 3600 * (parseInt(t[0]) || 0) + 60 * (parseInt(t[1]) || 0) + (parseInt(t[2]) || 0);
        }
        l.default = f;
      }]);
    });
  }(S)), S.exports;
}
var _ = j();
const C = /* @__PURE__ */ I(_), V = /* @__PURE__ */ O({
  __proto__: null,
  default: C
}, [_]);
export {
  V as i
};
