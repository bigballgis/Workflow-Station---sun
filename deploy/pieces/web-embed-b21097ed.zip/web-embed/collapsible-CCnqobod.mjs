import { j as t, j4 as o, j5 as s, j6 as a } from "./mount-builder-CqIEWsZv.mjs";
function i({
  ...l
}) {
  return /* @__PURE__ */ t.jsx(o, { "data-slot": "collapsible", ...l });
}
function n({
  ...l
}) {
  return /* @__PURE__ */ t.jsx(
    s,
    {
      "data-slot": "collapsible-trigger",
      ...l
    }
  );
}
function r({
  ...l
}) {
  return /* @__PURE__ */ t.jsx(
    a,
    {
      "data-slot": "collapsible-content",
      ...l
    }
  );
}
export {
  i as C,
  r as a,
  n as b
};
