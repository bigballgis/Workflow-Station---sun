import { bH as h, bI as ue, bJ as G, at as me, as as k, b6 as v, au as pe, a6 as e, bK as Ee, bL as q, bM as he, e as b, bN as De, bO as fe, bP as we, bQ as Te, bR as I, bS as be, bT as ge, bU as xe, bV as K, bW as A, bX as z, bY as J, bZ as $, g as N, j as t, bs as Ne, b_ as _e, bt as Ie, be as X, bf as Y, o as ye, a as Re, _ as Ae, b$ as Se, c0 as ve, c1 as Le, aJ as T, bi as Ce, bv as Fe, bw as Oe, c2 as je, c3 as U, c4 as P, c5 as W, c6 as ke, c7 as Ue, aQ as Pe, c8 as We, c9 as Ve, aX as Me, i as g, b0 as He, by as Be, b9 as Q, ba as Z, C as Ge, bb as ee, bc as L, ca as qe, aW as Ke, cb as ze, cc as Je, bj as $e, bk as Xe, a3 as V, a4 as M, cd as te, Y as Ye, a5 as H, bl as Qe, ce as Ze, bm as et, bp as tt, bB as at, D as st, bq as nt, cf as ot, I as rt, cg as it, bC as lt, ch as ct, ci as dt, cj as ut, ck as mt } from "./mount-builder-CqIEWsZv.mjs";
import { C as pt } from "./centered-page-C5JGBrkC.mjs";
import { A as s } from "./index-C5tdr9I_.mjs";
import { t as Et } from "./trigger-events-api-DEKnD3ub.mjs";
const ht = ({ event: a, platformId: n, projectId: r }) => {
  const o = (/* @__PURE__ */ new Date()).toISOString(), i = {
    id: h(),
    created: o,
    updated: o,
    ip: "127.0.0.1",
    platformId: n,
    projectId: r,
    userId: h()
  }, c = { displayName: "Dream Department" }, l = { id: h(), externalId: h(), created: o, updated: o }, u = {
    id: h(),
    displayName: "Sample flow",
    flowId: l.id,
    created: o,
    updated: o
  }, E = {
    id: h(),
    email: "sample@example.com",
    firstName: "Sample",
    lastName: "User"
  };
  switch (a) {
    case s.FLOW_RUN_STARTED:
    case s.FLOW_RUN_FINISHED:
    case s.FLOW_RUN_RESUMED:
    case s.FLOW_RUN_RETRIED:
      return {
        ...i,
        action: a,
        data: {
          flowRun: {
            id: h(),
            startTime: o,
            finishTime: o,
            duration: 1234,
            environment: "PRODUCTION",
            flowId: l.id,
            flowVersionId: u.id,
            flowDisplayName: u.displayName,
            status: a === s.FLOW_RUN_FINISHED ? "FAILED" : "RUNNING"
          },
          project: c
        }
      };
    case s.FLOW_CREATED:
      return {
        ...i,
        action: s.FLOW_CREATED,
        data: { flow: l, project: c }
      };
    case s.FLOW_DELETED:
      return {
        ...i,
        action: s.FLOW_DELETED,
        data: { flow: l, flowVersion: u, project: c }
      };
    case s.FLOW_UPDATED:
      return {
        ...i,
        action: s.FLOW_UPDATED,
        data: {
          flow: l,
          flowVersion: u,
          request: {
            type: G.LOCK_AND_PUBLISH,
            request: { status: ue.ENABLED }
          },
          project: c
        }
      };
    case s.FLOW_PUBLISHED:
      return {
        ...i,
        action: s.FLOW_PUBLISHED,
        data: { flow: l, flowVersion: u, project: c }
      };
    case s.FLOW_ACTIVATED:
      return {
        ...i,
        action: s.FLOW_ACTIVATED,
        data: { flow: l, flowVersion: u, project: c }
      };
    case s.FLOW_DEACTIVATED:
      return {
        ...i,
        action: s.FLOW_DEACTIVATED,
        data: { flow: l, flowVersion: u, project: c }
      };
    case s.FOLDER_CREATED:
    case s.FOLDER_UPDATED:
    case s.FOLDER_DELETED:
      return {
        ...i,
        action: a,
        data: {
          folder: {
            id: h(),
            displayName: "Sample folder",
            created: o,
            updated: o
          },
          project: c
        }
      };
    case s.CONNECTION_UPSERTED:
    case s.CONNECTION_DELETED:
      return {
        ...i,
        action: a,
        data: {
          connection: {
            id: h(),
            displayName: "Sample connection",
            externalId: "sample-connection",
            pieceName: "@activepieces/piece-sample",
            status: "ACTIVE",
            type: "CUSTOM_AUTH",
            created: o,
            updated: o
          },
          project: c
        }
      };
    case s.VARIABLE_UPSERTED:
    case s.VARIABLE_DELETED:
    case s.VARIABLE_VALUE_REVEALED:
      return {
        ...i,
        action: a,
        data: {
          variable: {
            id: h(),
            name: "SAMPLE_VARIABLE",
            created: o,
            updated: o
          },
          project: c
        }
      };
    case s.USER_SIGNED_IN:
    case s.USER_PASSWORD_RESET:
    case s.USER_EMAIL_VERIFIED:
      return {
        ...i,
        action: a,
        data: { user: E }
      };
    case s.USER_SIGNED_UP:
      return {
        ...i,
        action: s.USER_SIGNED_UP,
        data: { source: "credentials", user: E }
      };
    case s.SIGNING_KEY_CREATED:
      return {
        ...i,
        action: s.SIGNING_KEY_CREATED,
        data: {
          signingKey: {
            id: h(),
            displayName: "Sample signing key",
            created: o,
            updated: o
          }
        }
      };
    case s.PROJECT_ROLE_CREATED:
    case s.PROJECT_ROLE_UPDATED:
    case s.PROJECT_ROLE_DELETED:
      return {
        ...i,
        action: a,
        data: {
          projectRole: {
            id: h(),
            created: o,
            updated: o,
            name: "Sample role",
            permissions: [],
            platformId: n
          }
        }
      };
    case s.PROJECT_RELEASE_CREATED:
      return {
        ...i,
        action: s.PROJECT_RELEASE_CREATED,
        data: {
          release: {
            name: "v1.0.0",
            description: "Sample release",
            type: "PROJECT",
            projectId: r ?? h()
          }
        }
      };
  }
}, Dt = new Te(), R = fe(
  we({
    queryKey: ["event-destinations"],
    queryClient: Dt,
    queryFn: async () => (await b.get(
      "/v1/event-destinations"
    )).data,
    getKey: (a) => a.id,
    onUpdate: async ({ transaction: a }) => {
      for (const { original: n, modified: r } of a.mutations) {
        const o = {
          url: r.url,
          events: r.events
        };
        await b.patch(
          `/v1/event-destinations/${n.id}`,
          o
        );
      }
    },
    onInsert: async ({ transaction: a }) => {
      for (const { modified: n } of a.mutations) {
        const r = {
          url: n.url,
          events: n.events
        };
        await b.post("/v1/event-destinations", r);
      }
    },
    onDelete: async ({ transaction: a }) => {
      for (const { original: n } of a.mutations)
        await b.delete(`/v1/event-destinations/${n.id}`);
    }
  })
), x = {
  useAll: (a) => {
    const n = De(
      (r) => r.from({ destination: R }).select(({ destination: o }) => ({ ...o })),
      []
    );
    return a ? n : {
      data: [],
      isLoading: !1,
      isError: !1,
      isSuccess: !0
    };
  },
  useCreateEventDestination: (a, n) => v({
    mutationFn: (r) => b.post("/v1/event-destinations", r),
    onSuccess: (r) => {
      R.utils.writeInsert(r), a(r);
    },
    onError: (r) => {
      n(r);
    }
  }),
  update: (a, n) => {
    R.update(a, (r) => {
      Object.assign(
        r,
        Object.fromEntries(
          Object.entries(n).filter(([o, i]) => i !== void 0)
        )
      );
    });
  },
  delete: (a) => {
    R.delete(a);
  },
  useTestEventDestination: () => v({
    mutationFn: (a) => b.post("/v1/event-destinations/test", a)
  }),
  useImportHandlerFlow: (a, n) => {
    const { data: r } = me.useCurrentUser(), { data: o } = k.useAll();
    return v({
      mutationFn: async ({ template: i, selectedEvents: c }) => {
        const l = o.find(
          (f) => f.type === pe.PERSONAL && f.ownerId === (r == null ? void 0 : r.id)
        );
        if (!l)
          throw new Error(
            e("You need a personal project to generate the handler flow.")
          );
        k.setCurrentProject(l.id);
        const E = (await Ee.importFlowsFromTemplates({
          templates: [i],
          projectId: l.id
        }))[0];
        if (!E)
          throw new Error(e("Flow import returned no flow."));
        const p = E.version.trigger.name, m = c.map(
          (f) => ft(
            ht({
              event: f,
              platformId: l.platformId,
              projectId: l.id
            })
          )
        );
        for (const f of m)
          await Et.saveTriggerMockdata({
            projectId: l.id,
            flowId: E.id,
            mockData: f
          });
        return await q.update(E.id, {
          type: G.SAVE_SAMPLE_DATA,
          request: {
            stepName: p,
            payload: m[0],
            type: he.OUTPUT
          }
        }), E;
      },
      onSuccess: a,
      onError: n
    });
  }
};
function ft(a) {
  return {
    body: a,
    headers: {},
    queryParams: {}
  };
}
const wt = "20", B = "@activepieces/piece-webhook", Tt = "0.1.33", bt = "catch_webhook", gt = "{{trigger['body']['action']}}", xt = "{{trigger['body']['data']['flowRun']['status']}}", Nt = {
  buildHandlerFlowTemplate: ({ events: a, labels: n }) => {
    if (a.length === 0)
      throw new Error(
        "At least one event is required to build a handler flow."
      );
    const r = _t(a, n), o = (/* @__PURE__ */ new Date()).toISOString(), i = It({
      content: n.noteContent,
      timestamp: o
    }), c = yt({
      content: n.sampleDataNoteContent,
      timestamp: o
    });
    return {
      id: h(),
      created: o,
      updated: o,
      name: n.flowDisplayName,
      type: xe.CUSTOM,
      summary: n.flowDisplayName,
      description: n.flowDescription,
      tags: [],
      blogUrl: null,
      metadata: null,
      author: "Activepieces",
      categories: [],
      pieces: [B],
      platformId: null,
      status: ge.PUBLISHED,
      tables: [],
      flows: [
        {
          displayName: n.flowDisplayName,
          schemaVersion: wt,
          valid: !0,
          notes: [i, c],
          trigger: {
            name: "trigger",
            type: be.PIECE,
            valid: !0,
            displayName: n.webhookTriggerDisplayName,
            lastUpdatedDate: o,
            settings: {
              pieceName: B,
              pieceVersion: Tt,
              triggerName: bt,
              input: { authType: "none", authFields: {} },
              propertySettings: {
                authType: { type: I.MANUAL },
                authFields: {
                  type: I.MANUAL,
                  schema: {}
                },
                liveMarkdown: { type: I.MANUAL },
                syncMarkdown: { type: I.MANUAL },
                testMarkdown: { type: I.MANUAL }
              }
            },
            nextAction: r
          }
        }
      ]
    };
  }
};
function _t(a, n) {
  const r = (/* @__PURE__ */ new Date()).toISOString(), o = a.map(({ name: l, label: u }) => ({
    branchType: A.CONDITION,
    branchName: u,
    conditions: [
      [
        {
          operator: K.TEXT_EXACTLY_MATCHES,
          firstValue: gt,
          secondValue: l,
          caseSensitive: !1
        }
      ]
    ]
  }));
  o.push({
    branchType: A.FALLBACK,
    branchName: n.otherwiseBranchName
  });
  let i = 2;
  const c = a.map(({ name: l }) => {
    if (l !== s.FLOW_RUN_FINISHED)
      return null;
    const u = `step_${i++}`;
    return Rt({
      stepName: u,
      lastUpdatedDate: r,
      labels: n
    });
  });
  return c.push(null), {
    name: "step_1",
    type: J.ROUTER,
    valid: !0,
    skip: !1,
    displayName: n.eventTypeRouterDisplayName,
    lastUpdatedDate: r,
    settings: {
      executionType: z.EXECUTE_FIRST_MATCH,
      branches: o
    },
    children: c
  };
}
function It({
  content: a,
  timestamp: n
}) {
  return {
    id: h(),
    content: a,
    ownerId: null,
    color: $.YELLOW,
    position: { x: -375, y: -105 },
    size: { width: 300, height: 298 },
    createdAt: n,
    updatedAt: n
  };
}
function yt({
  content: a,
  timestamp: n
}) {
  return {
    id: h(),
    content: a,
    ownerId: null,
    color: $.BLUE,
    position: { x: 300, y: -105 },
    size: { width: 239, height: 242 },
    createdAt: n,
    updatedAt: n
  };
}
function Rt({
  stepName: a,
  lastUpdatedDate: n,
  labels: r
}) {
  return {
    name: a,
    type: J.ROUTER,
    valid: !0,
    skip: !1,
    displayName: r.runStatusRouterDisplayName,
    lastUpdatedDate: n,
    settings: {
      executionType: z.EXECUTE_FIRST_MATCH,
      branches: [
        {
          branchType: A.CONDITION,
          branchName: r.failedRunBranchName,
          conditions: [
            [
              {
                operator: K.TEXT_EXACTLY_MATCHES,
                firstValue: xt,
                secondValue: "FAILED",
                caseSensitive: !1
              }
            ]
          ]
        },
        {
          branchType: A.FALLBACK,
          branchName: r.otherwiseBranchName
        }
      ]
    },
    children: [null, null]
  };
}
const ae = () => ({
  [s.FLOW_RUN_STARTED]: { label: e("Flow run started") },
  [s.FLOW_RUN_FINISHED]: {
    label: e("Flow run finished"),
    description: e("Fires for every finished run — successful and failed.")
  },
  [s.FLOW_RUN_RESUMED]: { label: e("Flow run resumed") },
  [s.FLOW_RUN_RETRIED]: { label: e("Flow run retried") },
  [s.FLOW_CREATED]: { label: e("Flow created") },
  [s.FLOW_UPDATED]: { label: e("Flow updated") },
  [s.FLOW_DELETED]: { label: e("Flow deleted") },
  [s.FOLDER_CREATED]: { label: e("Folder created") },
  [s.FOLDER_UPDATED]: { label: e("Folder updated") },
  [s.FOLDER_DELETED]: { label: e("Folder deleted") },
  [s.CONNECTION_UPSERTED]: {
    label: e("Connection saved")
  },
  [s.CONNECTION_DELETED]: {
    label: e("Connection deleted")
  },
  [s.VARIABLE_UPSERTED]: {
    label: e("Variable saved")
  },
  [s.VARIABLE_DELETED]: {
    label: e("Variable deleted")
  },
  [s.VARIABLE_VALUE_REVEALED]: {
    label: e("Variable value revealed")
  },
  [s.USER_SIGNED_UP]: { label: e("User signed up") },
  [s.USER_SIGNED_IN]: { label: e("User signed in") },
  [s.USER_PASSWORD_RESET]: {
    label: e("User password reset")
  },
  [s.USER_EMAIL_VERIFIED]: {
    label: e("User email verified")
  },
  [s.SIGNING_KEY_CREATED]: {
    label: e("Signing key created")
  },
  [s.PROJECT_ROLE_CREATED]: {
    label: e("Project role created")
  },
  [s.PROJECT_ROLE_UPDATED]: {
    label: e("Project role updated")
  },
  [s.PROJECT_ROLE_DELETED]: {
    label: e("Project role deleted")
  },
  [s.PROJECT_RELEASE_CREATED]: {
    label: e("Project release created")
  },
  [s.FLOW_PUBLISHED]: {
    label: e("Flow published")
  },
  [s.FLOW_ACTIVATED]: {
    label: e("Flow activated")
  },
  [s.FLOW_DEACTIVATED]: {
    label: e("Flow deactivated")
  }
}), se = ({
  children: a,
  destination: n
}) => {
  const [r, o] = N.useState(!1);
  return /* @__PURE__ */ t.jsxs(Ne, { open: r, onOpenChange: o, children: [
    /* @__PURE__ */ t.jsx(_e, { asChild: !0, children: a }),
    /* @__PURE__ */ t.jsx(Ie, { className: "max-w-2xl gap-2", children: /* @__PURE__ */ t.jsx(
      At,
      {
        destination: n,
        onClose: () => o(!1)
      },
      r ? "open" : "closed"
    ) })
  ] });
}, At = ({
  destination: a,
  onClose: n
}) => {
  const r = ae(), { data: o } = X.useFlag(
    Y.WEBHOOK_URL_PREFIX
  ), i = N.useId(), c = ye({
    url: Se(e("Invalid URL")).min(1, e("Webhook URL is required")),
    events: Re(Ae(s)).min(1, e("Select at least one event"))
  }), l = ve({
    resolver: Le(c),
    mode: "onChange",
    defaultValues: {
      url: (a == null ? void 0 : a.url) ?? "",
      events: (a == null ? void 0 : a.events) ?? []
    }
  }), u = l.watch("url"), E = l.watch("events") ?? [], { mutate: p, isPending: m } = x.useTestEventDestination(), { mutate: f, isPending: _ } = x.useCreateEventDestination(
    () => {
      T.success(e("Success"), {
        description: e("Destination created successfully")
      }), n();
    },
    (d) => {
      T.error(e("Error"), {
        description: d.message
      });
    }
  ), y = (d) => {
    if (a)
      try {
        x.update(a.id, d), T.success(e("Success"), {
          description: e("Destination updated successfully")
        }), n();
      } catch (D) {
        T.error(e("Error"), {
          description: D instanceof Error ? D.message : "Unknown error"
        });
      }
    else
      f(d);
  }, { mutate: ne, isPending: S } = x.useImportHandlerFlow(
    (d) => {
      l.setValue("url", `${o}/${d.id}`, {
        shouldValidate: !0
      }), window.open(
        `/flows/${d.id}`,
        "_blank",
        "noopener,noreferrer"
      );
    },
    (d) => {
      T.error(
        d.message || e("Failed to generate the handler flow. Please try again.")
      );
    }
  ), oe = () => {
    const d = l.getValues("events") ?? [];
    if (d.length === 0) {
      l.setError("events", {
        message: e("Select at least one event")
      });
      return;
    }
    if (!o) {
      T.error(e("Webhook URL prefix is not configured."));
      return;
    }
    const D = Nt.buildHandlerFlowTemplate({
      events: d.map((w) => ({
        name: w,
        label: r[w].label
      })),
      labels: {
        flowDisplayName: e("Event handler starter"),
        flowDescription: e(
          "Routes audit events into branches you can wire to Slack, Gmail, Teams, or any HTTP endpoint."
        ),
        webhookTriggerDisplayName: e("Catch Webhook"),
        eventTypeRouterDisplayName: e("Event type checker"),
        runStatusRouterDisplayName: e("Run status check"),
        failedRunBranchName: e("Failed run"),
        otherwiseBranchName: e("Otherwise"),
        noteContent: e(
          `**Audit event handler**

This flow runs whenever any of these events fire:

{events}

**Add your channel** (Slack, Gmail, Teams, HTTP…) inside each branch below.

Once you are done:

1. **Publish this flow** so it can receive events.
2. Head back to the **Event Streaming** tab and create the destination to start sending events here.`,
          {
            events: d.map((w) => `- ${r[w].label}`).join(`
`)
          }
        ),
        sampleDataNoteContent: e(
          `**Test different scenarios**

Open the trigger and edit its **Sample Data** to swap in a different event payload and test each branch without firing real audit events.`
        )
      }
    });
    ne({ template: D, selectedEvents: d });
  }, re = Object.values(s), C = _ || S, ie = m || !u || !Ce(l.formState.errors.url) || E.length === 0;
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsx(Fe, { children: a ? e("Edit Destination") : e("New Destination") }),
    /* @__PURE__ */ t.jsx(Oe, { children: a ? e("Update the webhook endpoint and event subscriptions.") : e(
      "Send audit events to a webhook. Use an internal flow to route them to your notification channels — Slack, Gmail, Microsoft Teams, or any other channel."
    ) }),
    /* @__PURE__ */ t.jsx(je, { ...l, children: /* @__PURE__ */ t.jsxs("form", { onSubmit: l.handleSubmit(y), className: "space-y-4", children: [
      /* @__PURE__ */ t.jsx(
        U,
        {
          control: l.control,
          name: "events",
          render: ({ field: d }) => /* @__PURE__ */ t.jsxs(P, { children: [
            /* @__PURE__ */ t.jsx(W, { showRequiredIndicator: !0, className: "text-base", children: e("Events") }),
            /* @__PURE__ */ t.jsx(
              ke,
              {
                className: "h-48 rounded-md ",
                viewPortClassName: "px-0",
                children: /* @__PURE__ */ t.jsx("div", { className: "grid grid-cols-2 gap-2", children: re.map((D) => {
                  var F, O;
                  const w = `${i}-${D}`, le = ((F = d.value) == null ? void 0 : F.includes(D)) ?? !1;
                  return /* @__PURE__ */ t.jsxs(
                    "div",
                    {
                      className: "flex flex-row items-center gap-3",
                      children: [
                        /* @__PURE__ */ t.jsx(
                          Ue,
                          {
                            id: w,
                            checked: le,
                            onCheckedChange: (ce) => {
                              const j = d.value ?? [];
                              d.onChange(
                                ce ? [...j, D] : j.filter((de) => de !== D)
                              );
                            }
                          }
                        ),
                        /* @__PURE__ */ t.jsx(
                          Pe,
                          {
                            htmlFor: w,
                            className: "cursor-pointer text-sm font-normal",
                            children: ((O = r[D]) == null ? void 0 : O.label) ?? D
                          }
                        )
                      ]
                    },
                    D
                  );
                }) })
              }
            ),
            /* @__PURE__ */ t.jsx(We, {})
          ] })
        }
      ),
      /* @__PURE__ */ t.jsx(
        U,
        {
          control: l.control,
          name: "url",
          render: ({ field: d }) => /* @__PURE__ */ t.jsxs(P, { children: [
            /* @__PURE__ */ t.jsx(W, { showRequiredIndicator: !0, children: e("Webhook URL") }),
            /* @__PURE__ */ t.jsx(Ve, { children: /* @__PURE__ */ t.jsx(Me, { placeholder: "https://example.com/webhook", ...d }) }),
            !a && /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-1 pt-1", children: [
              /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground", children: e(
                  "Or generate an internal flow to handle the selected events:"
                ) }),
                /* @__PURE__ */ t.jsxs(
                  g,
                  {
                    type: "button",
                    variant: "outline",
                    size: "sm",
                    onClick: oe,
                    disabled: S || _,
                    loading: S,
                    children: [
                      /* @__PURE__ */ t.jsx(He, { className: "size-4" }),
                      e("Generate handler flow")
                    ]
                  }
                )
              ] }),
              /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground", children: e(
                "Don't forget to publish your flow before creating the alert."
              ) })
            ] })
          ] })
        }
      ),
      /* @__PURE__ */ t.jsxs(Be, { children: [
        /* @__PURE__ */ t.jsx(
          g,
          {
            type: "button",
            variant: "outline",
            onClick: n,
            disabled: C,
            children: e("Cancel")
          }
        ),
        /* @__PURE__ */ t.jsxs(Q, { children: [
          /* @__PURE__ */ t.jsx(Z, { asChild: !0, children: /* @__PURE__ */ t.jsxs(
            g,
            {
              type: "button",
              variant: "outline",
              disabled: ie,
              children: [
                m ? e("Testing...") : e("Test webhook"),
                /* @__PURE__ */ t.jsx(Ge, { className: "size-4" })
              ]
            }
          ) }),
          /* @__PURE__ */ t.jsx(ee, { align: "end", children: E.map((d) => {
            var D;
            return /* @__PURE__ */ t.jsx(
              L,
              {
                onSelect: () => p({
                  url: u,
                  event: d
                }),
                children: ((D = r[d]) == null ? void 0 : D.label) ?? d
              },
              d
            );
          }) })
        ] }),
        /* @__PURE__ */ t.jsx(
          g,
          {
            type: "submit",
            disabled: C,
            loading: _,
            children: a ? e("Save changes") : e("Create alert")
          }
        )
      ] })
    ] }) })
  ] });
}, St = ({
  destination: a
}) => {
  const [n, r] = N.useState(!1);
  return /* @__PURE__ */ t.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ t.jsxs(
    Q,
    {
      modal: !0,
      open: n,
      onOpenChange: r,
      children: [
        /* @__PURE__ */ t.jsx(Z, { asChild: !0, children: /* @__PURE__ */ t.jsx(g, { variant: "ghost", className: "h-8 w-8 p-0", children: /* @__PURE__ */ t.jsx(qe, { className: "h-4 w-4" }) }) }),
        /* @__PURE__ */ t.jsxs(ee, { children: [
          /* @__PURE__ */ t.jsx(se, { destination: a, children: /* @__PURE__ */ t.jsxs(
            L,
            {
              onSelect: (o) => {
                o.preventDefault();
              },
              children: [
                /* @__PURE__ */ t.jsx(Ke, { className: "h-4 w-4 mr-2" }),
                e("Edit")
              ]
            }
          ) }),
          /* @__PURE__ */ t.jsx(
            ze,
            {
              title: e("Delete destination"),
              message: e(
                "Deleting this destination will stop all event notifications to its webhook."
              ),
              entityName: e("destination"),
              buttonText: e("Delete"),
              showToast: !0,
              mutationFn: async () => {
                a && x.delete([a.id]);
              },
              isDanger: !0,
              children: /* @__PURE__ */ t.jsxs(
                L,
                {
                  variant: "destructive",
                  onSelect: (o) => {
                    o.preventDefault();
                  },
                  children: [
                    /* @__PURE__ */ t.jsx(Je, { className: "h-4 w-4 mr-2" }),
                    e("Delete")
                  ]
                }
              )
            }
          )
        ] })
      ]
    }
  ) });
}, vt = ({
  destination: a,
  parsed: n,
  flowDisplayName: r,
  eventLabels: o
}) => {
  const i = n.kind === "flow", c = n.kind === "flow" ? n.flowId : void 0, l = i && r ? r : i && c ? e("Destination (flow {flowId})", { flowId: c }) : a.url;
  return /* @__PURE__ */ t.jsxs($e, { variant: "outline", children: [
    /* @__PURE__ */ t.jsx(Xe, { variant: "icon", children: /* @__PURE__ */ t.jsxs(V, { children: [
      /* @__PURE__ */ t.jsx(M, { asChild: !0, children: /* @__PURE__ */ t.jsx("span", { tabIndex: 0, className: "inline-flex", children: i ? /* @__PURE__ */ t.jsx(te, {}) : /* @__PURE__ */ t.jsx(Ye, {}) }) }),
      /* @__PURE__ */ t.jsx(H, { children: i ? e("Internal Flow") : e("External") })
    ] }) }),
    /* @__PURE__ */ t.jsxs(Qe, { className: "min-w-0", children: [
      /* @__PURE__ */ t.jsx(Ze, { tooltipMessage: l, children: /* @__PURE__ */ t.jsx(
        et,
        {
          className: i ? "truncate" : "truncate font-mono text-xs",
          children: l
        }
      ) }),
      /* @__PURE__ */ t.jsxs(tt, { className: "text-xs !flex flex-wrap items-center gap-x-1 gap-y-2 overflow-visible [text-wrap:unset] mt-1", children: [
        /* @__PURE__ */ t.jsx("span", { className: "text-muted-foreground shrink-0 mr-1.5", children: e("Events") }),
        a.events.map((u) => {
          var E;
          return /* @__PURE__ */ t.jsx(at, { variant: "outline", className: "text-xs", children: ((E = o[u]) == null ? void 0 : E.label) ?? u }, u);
        })
      ] }),
      /* @__PURE__ */ t.jsxs("p", { className: "text-xs text-muted-foreground mt-2", children: [
        e("Created"),
        " ",
        st.formatDateToAgo(new Date(a.created))
      ] })
    ] }),
    /* @__PURE__ */ t.jsxs(nt, { children: [
      i && c && /* @__PURE__ */ t.jsxs(V, { children: [
        /* @__PURE__ */ t.jsx(M, { asChild: !0, children: /* @__PURE__ */ t.jsx(
          g,
          {
            variant: "ghost",
            size: "sm",
            onClick: () => window.open(
              `/flows/${c}`,
              "_blank",
              "noopener,noreferrer"
            ),
            children: /* @__PURE__ */ t.jsx(ot, { className: "size-4" })
          }
        ) }),
        /* @__PURE__ */ t.jsx(H, { children: e("View flow") })
      ] }),
      /* @__PURE__ */ t.jsx(St, { destination: a })
    ] })
  ] });
}, Lt = ({
  url: a,
  webhookPrefixUrl: n
}) => {
  var c;
  if (!n || n.length === 0)
    return { kind: "external" };
  const r = n.endsWith("/") ? n.slice(0, -1) : n;
  if (!a.startsWith(`${r}/`))
    return { kind: "external" };
  const i = (c = a.slice(r.length + 1).split("/")[0]) == null ? void 0 : c.split("?")[0];
  return !i || i.length === 0 ? { kind: "external" } : { kind: "flow", flowId: i };
}, kt = () => {
  const { platform: a } = rt.useCurrentPlatform(), n = a.plan.eventStreamingEnabled, { data: r, isLoading: o } = x.useAll(n), { data: i } = X.useFlag(
    Y.WEBHOOK_URL_PREFIX
  ), c = ae(), l = N.useMemo(
    () => r.map((m) => ({
      destination: m,
      parsed: Lt({
        url: m.url,
        webhookPrefixUrl: i ?? null
      })
    })),
    [r, i]
  ), u = N.useMemo(
    () => Array.from(
      new Set(
        l.map(
          ({ parsed: m }) => m.kind === "flow" ? m.flowId : null
        ).filter((m) => m !== null)
      )
    ),
    [l]
  ), E = it({
    queries: u.map((m) => ({
      queryKey: ["flow-display-name", m],
      queryFn: () => q.get(m)
    }))
  }), p = N.useMemo(() => {
    const m = /* @__PURE__ */ new Map();
    return E.forEach((f, _) => {
      const y = f.data;
      y && m.set(u[_], y.version.displayName);
    }), m;
  }, [E, u]);
  return /* @__PURE__ */ t.jsx(
    lt,
    {
      featureKey: "EVENT_DESTINATIONS",
      locked: !n,
      lockTitle: e("Unlock Event Streaming"),
      lockDescription: e(
        "Forward every audit event we emit to a webhook, then handle it in a flow — wire it to Slack, Gmail, PagerDuty, or anywhere else."
      ),
      children: /* @__PURE__ */ t.jsxs(
        pt,
        {
          title: e("Event Streaming"),
          description: e(
            "Send a webhook for every audit event and build fully customizable alerts on top."
          ),
          actions: /* @__PURE__ */ t.jsx(se, { destination: null, children: /* @__PURE__ */ t.jsx(ut, { icon: mt, iconSize: 16, size: "sm", children: e("New Destination") }) }),
          children: [
            o && /* @__PURE__ */ t.jsx(ct, { numberOfItems: 3, className: "w-full h-[72px]" }),
            !o && l.length === 0 && /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col items-center gap-3 py-12 text-muted-foreground", children: [
              /* @__PURE__ */ t.jsx(te, { className: "size-10" }),
              /* @__PURE__ */ t.jsx("p", { className: "text-sm", children: e("No destinations yet. Create one to get started.") })
            ] }),
            !o && l.length > 0 && /* @__PURE__ */ t.jsx(dt, { className: "gap-2", children: l.map(({ destination: m, parsed: f }) => /* @__PURE__ */ t.jsx(
              vt,
              {
                destination: m,
                parsed: f,
                flowDisplayName: f.kind === "flow" ? p.get(f.flowId) : void 0,
                eventLabels: c
              },
              m.id
            )) })
          ]
        }
      )
    }
  );
};
export {
  kt as default
};
