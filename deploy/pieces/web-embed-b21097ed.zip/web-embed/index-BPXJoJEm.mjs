import { j as e, h as j, g as o, co as le, a6 as t, cp as m, f6 as ee, fl as we, f5 as ye, D as k, fm as Me, fa as Le, fn as Ae, a3 as M, a4 as L, a5 as A, I as ke, as as De, f8 as Fe, cg as Pe, fo as Ee, bC as Ie, fp as Re, eX as Ue, L as $e, i as w, dK as Be, aJ as He, dB as Oe, dC as _e, cs as ze, dD as Ke, dE as Ze, dF as v, eQ as Ve, ej as Qe, ek as We, el as se, d0 as qe, f7 as Ge, f9 as ae, fq as Xe, ax as Je, ay as Ye, aa as e1, C as s1, aA as a1, ar as t1, fb as n1, em as te, fr as ne } from "./mount-builder-CqIEWsZv.mjs";
import { A as f, p as y, b as r1, T as p, c as re } from "./impact-utils-BRhn6NxM.mjs";
import { R as i1 } from "./rocket-DmQcsYfQ.mjs";
const l1 = ({ className: s }) => /* @__PURE__ */ e.jsx("div", { className: j(s), children: /* @__PURE__ */ e.jsxs("svg", { className: "block size-full", fill: "none", viewBox: "0 0 24 24", children: [
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M3.86036 8.61578C3.71445 7.95825 3.73685 7.27451 3.9255 6.62795C4.11414 5.98139 4.46292 5.39295 4.9395 4.91718C5.41607 4.44142 6.00501 4.09373 6.65171 3.90637C7.29841 3.719 7.98193 3.69802 8.63889 3.84537C9.00049 3.27962 9.49863 2.81404 10.0874 2.49154C10.6762 2.16904 11.3366 1.99999 12.0079 1.99999C12.6791 1.99999 13.3395 2.16904 13.9283 2.49154C14.5171 2.81404 15.0152 3.27962 15.3768 3.84537C16.0348 3.69738 16.7195 3.71827 17.3672 3.90609C18.0149 4.09391 18.6047 4.44256 19.0815 4.91961C19.5584 5.39667 19.9069 5.98663 20.0947 6.63461C20.2824 7.2826 20.3033 7.96756 20.1554 8.62578C20.7209 8.98752 21.1863 9.48586 21.5086 10.0749C21.831 10.6639 22 11.3246 22 11.9961C22 12.6676 21.831 13.3283 21.5086 13.9173C21.1863 14.5063 20.7209 15.0046 20.1554 15.3664C20.3026 16.0236 20.2817 16.7074 20.0944 17.3543C19.9071 18.0013 19.5595 18.5905 19.084 19.0672C18.6084 19.544 18.0202 19.8929 17.3739 20.0816C16.7276 20.2703 16.0441 20.2927 15.3868 20.1468C15.0257 20.7147 14.5272 21.1823 13.9374 21.5062C13.3476 21.8302 12.6857 22 12.0129 22C11.34 22 10.6781 21.8302 10.0883 21.5062C9.49855 21.1823 9.00002 20.7147 8.63889 20.1468C7.98193 20.2941 7.29841 20.2731 6.65171 20.0858C6.00501 19.8984 5.41607 19.5507 4.9395 19.075C4.46292 18.5992 4.11414 18.0108 3.9255 17.3642C3.73685 16.7176 3.71445 16.0339 3.86036 15.3764C3.29049 15.0156 2.82109 14.5165 2.49583 13.9255C2.17056 13.3344 2 12.6707 2 11.9961C2 11.3214 2.17056 10.6577 2.49583 10.0667C2.82109 9.47568 3.29049 8.97657 3.86036 8.61578Z",
      fill: "#FFCC00",
      stroke: "#FFCC00",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: "2"
    }
  ),
  /* @__PURE__ */ e.jsx("circle", { cx: "12", cy: "12", fill: "#FFBA25", r: "8" }),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M12 3.99999C14.4635 3.99999 16.6663 5.11405 18.1338 6.86522C16.7444 5.7013 14.9543 4.99999 13 4.99999C8.58172 4.99999 5 8.58171 5 13C5 14.9543 5.70131 16.7444 6.86523 18.1338C5.11407 16.6663 4 14.4635 4 12C4 7.58171 7.58172 3.99999 12 3.99999Z",
      fill: "#F39313"
    }
  ),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M12.0814 9.79504C12.0814 8.82867 11.9625 8.68 10.446 8.68H10.0595L10 7.92177C10.6393 7.9069 13.0924 7.28248 13.5384 7L14.1331 7.22301C14.0588 8.50159 14.029 9.78017 14.029 10.9398C14.029 13.7497 14.1777 15.8757 14.1777 15.8757L13.0775 16.2623L12.4977 16.5448H12.0219C12.0219 16.5448 12.0963 14.9688 12.0963 12.6198C12.0963 11.7575 12.0814 10.806 12.0814 9.79504Z",
      fill: "#A34900"
    }
  ),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M21.249 7.67578C21.2514 7.84446 21.2471 8.01328 21.2324 8.18164C21.6987 8.57689 22.0904 9.05517 22.3857 9.59473C22.7887 10.3309 23 11.1568 23 11.9961C23 12.0535 22.9961 12.1107 22.9941 12.168L12.6953 22.9512C12.4697 22.9823 12.2418 23 12.0127 23C11.1716 23 10.3437 22.7878 9.60645 22.3828C9.09106 22.0997 8.63308 21.7273 8.24902 21.2871L21.249 7.67578Z",
      fill: "white",
      fillOpacity: "0.3"
    }
  )
] }) }), o1 = ({ className: s }) => /* @__PURE__ */ e.jsx("div", { className: j(s), children: /* @__PURE__ */ e.jsxs("svg", { className: "block size-full", fill: "none", viewBox: "0 0 24 24", children: [
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M3.86036 8.61578C3.71445 7.95825 3.73685 7.27451 3.9255 6.62795C4.11414 5.98139 4.46292 5.39295 4.9395 4.91718C5.41607 4.44142 6.00501 4.09373 6.65171 3.90637C7.29841 3.719 7.98193 3.69802 8.63889 3.84537C9.00049 3.27962 9.49863 2.81404 10.0874 2.49154C10.6762 2.16904 11.3366 1.99999 12.0079 1.99999C12.6791 1.99999 13.3395 2.16904 13.9283 2.49154C14.5171 2.81404 15.0152 3.27962 15.3768 3.84537C16.0348 3.69738 16.7195 3.71827 17.3672 3.90609C18.0149 4.09391 18.6047 4.44256 19.0815 4.91961C19.5584 5.39667 19.9069 5.98663 20.0947 6.63461C20.2824 7.2826 20.3033 7.96756 20.1554 8.62578C20.7209 8.98752 21.1863 9.48586 21.5086 10.0749C21.831 10.6639 22 11.3246 22 11.9961C22 12.6676 21.831 13.3283 21.5086 13.9173C21.1863 14.5063 20.7209 15.0046 20.1554 15.3664C20.3026 16.0236 20.2817 16.7074 20.0944 17.3543C19.9071 18.0013 19.5595 18.5905 19.084 19.0672C18.6084 19.544 18.0202 19.8929 17.3739 20.0816C16.7276 20.2703 16.0441 20.2927 15.3868 20.1468C15.0257 20.7147 14.5272 21.1823 13.9374 21.5062C13.3476 21.8302 12.6857 22 12.0129 22C11.34 22 10.6781 21.8302 10.0883 21.5062C9.49855 21.1823 9.00002 20.7147 8.63889 20.1468C7.98193 20.2941 7.29841 20.2731 6.65171 20.0858C6.00501 19.8984 5.41607 19.5507 4.9395 19.075C4.46292 18.5992 4.11414 18.0108 3.9255 17.3642C3.73685 16.7176 3.71445 16.0339 3.86036 15.3764C3.29049 15.0156 2.82109 14.5165 2.49583 13.9255C2.17056 13.3344 2 12.6707 2 11.9961C2 11.3214 2.17056 10.6577 2.49583 10.0667C2.82109 9.47568 3.29049 8.97657 3.86036 8.61578Z",
      fill: "#BEC4DF",
      stroke: "#BEC4DF",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: "2"
    }
  ),
  /* @__PURE__ */ e.jsx("circle", { cx: "12", cy: "12", fill: "#ADB4D2", r: "8" }),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M12 3.99999C14.4635 3.99999 16.6663 5.11406 18.1338 6.86523C16.7444 5.7013 14.9543 4.99999 13 4.99999C8.58172 4.99999 5 8.58172 5 13C5 14.9543 5.70131 16.7444 6.86523 18.1338C5.11407 16.6663 4 14.4635 4 12C4 7.58172 7.58172 3.99999 12 3.99999Z",
      fill: "#8E96BB"
    }
  ),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M15.3053 14.4978V14.8406L15.0072 15.6009L14.7836 16.4654H9.31303L9 15.7499C10.8186 13.8121 12.6669 11.8445 12.6669 9.9067C12.6669 8.83346 11.9514 8.53534 11.1018 8.53534C10.6248 8.53534 9.90928 8.77383 9.52172 8.96761L9.17887 8.40118C9.84965 7.61115 10.9378 7 12.2645 7C13.6507 7 14.8134 7.83475 14.8134 9.56386C14.8134 11.5464 12.5775 13.7078 11.1465 14.8705L15.3053 14.4978Z",
      fill: "#4D536E"
    }
  ),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M21.249 7.67578C21.2514 7.84446 21.2471 8.01327 21.2324 8.18164C21.6987 8.57689 22.0904 9.05517 22.3857 9.59472C22.7887 10.3309 23 11.1568 23 11.9961C23 12.0535 22.9961 12.1107 22.9941 12.168L12.6953 22.9512C12.4697 22.9823 12.2418 23 12.0127 23C11.1716 23 10.3437 22.7878 9.60645 22.3828C9.09106 22.0997 8.63308 21.7273 8.24902 21.2871L21.249 7.67578Z",
      fill: "white",
      fillOpacity: "0.3"
    }
  )
] }) }), c1 = ({ className: s }) => /* @__PURE__ */ e.jsx("div", { className: j(s), children: /* @__PURE__ */ e.jsxs("svg", { className: "block size-full", fill: "none", viewBox: "0 0 24 24", children: [
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M3.86036 8.61578C3.71445 7.95825 3.73685 7.27451 3.9255 6.62795C4.11414 5.98139 4.46292 5.39295 4.9395 4.91718C5.41607 4.44142 6.00501 4.09373 6.65171 3.90637C7.29841 3.719 7.98193 3.69802 8.63889 3.84537C9.00049 3.27962 9.49863 2.81404 10.0874 2.49154C10.6762 2.16904 11.3366 1.99999 12.0079 1.99999C12.6791 1.99999 13.3395 2.16904 13.9283 2.49154C14.5171 2.81404 15.0152 3.27962 15.3768 3.84537C16.0348 3.69738 16.7195 3.71827 17.3672 3.90609C18.0149 4.09391 18.6047 4.44256 19.0815 4.91961C19.5584 5.39667 19.9069 5.98663 20.0947 6.63461C20.2824 7.2826 20.3033 7.96756 20.1554 8.62578C20.7209 8.98752 21.1863 9.48586 21.5086 10.0749C21.831 10.6639 22 11.3246 22 11.9961C22 12.6676 21.831 13.3283 21.5086 13.9173C21.1863 14.5063 20.7209 15.0046 20.1554 15.3664C20.3026 16.0236 20.2817 16.7074 20.0944 17.3543C19.9071 18.0013 19.5595 18.5905 19.084 19.0672C18.6084 19.544 18.0202 19.8929 17.3739 20.0816C16.7276 20.2703 16.0441 20.2927 15.3868 20.1468C15.0257 20.7147 14.5272 21.1823 13.9374 21.5062C13.3476 21.8302 12.6857 22 12.0129 22C11.34 22 10.6781 21.8302 10.0883 21.5062C9.49855 21.1823 9.00002 20.7147 8.63889 20.1468C7.98193 20.2941 7.29841 20.2731 6.65171 20.0858C6.00501 19.8984 5.41607 19.5507 4.9395 19.075C4.46292 18.5992 4.11414 18.0108 3.9255 17.3642C3.73685 16.7176 3.71445 16.0339 3.86036 15.3764C3.29049 15.0156 2.82109 14.5165 2.49583 13.9255C2.17056 13.3344 2 12.6707 2 11.9961C2 11.3214 2.17056 10.6577 2.49583 10.0667C2.82109 9.47568 3.29049 8.97657 3.86036 8.61578Z",
      fill: "#FAB658",
      stroke: "#FAB658",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: "2"
    }
  ),
  /* @__PURE__ */ e.jsx("circle", { cx: "12", cy: "12", fill: "#FFD191", r: "8" }),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M12 3.99999C14.4635 3.99999 16.6663 5.11406 18.1338 6.86523C16.7444 5.7013 14.9543 4.99999 13 4.99999C8.58172 4.99999 5 8.58172 5 13C5 14.9543 5.70131 16.7444 6.86523 18.1338C5.11407 16.6663 4 14.4635 4 12C4 7.58172 7.58172 3.99999 12 3.99999Z",
      fill: "#EE9740"
    }
  ),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M15.8664 14.328C15.8664 15.6383 14.2733 17.4994 11.7718 17.4994C10.9976 17.4994 10.4318 17.3356 10.0298 17.0825L10.8934 15.3554C11.2656 15.6085 12.0696 15.9658 12.963 15.9658C13.767 15.9658 14.1392 15.534 14.1392 14.9682C14.1392 13.8962 13.1268 13.2113 11.5038 13.1815L11.2954 12.437C12.5014 12.1541 13.365 11.499 13.365 10.5014C13.365 9.75695 12.7992 9.41449 12.0696 9.41449C11.5038 9.41449 10.8785 9.59316 10.4318 9.86117L10 9.28049C10.4913 8.71469 11.5485 8 12.7992 8C14.437 8 15.4942 8.78914 15.4942 10.0845C15.4942 11.1119 14.5562 11.9457 13.5139 12.3179C14.7646 12.4073 15.8664 13.0028 15.8664 14.328Z",
      fill: "#954F07"
    }
  ),
  /* @__PURE__ */ e.jsx(
    "path",
    {
      d: "M21.249 7.67578C21.2514 7.84446 21.2471 8.01327 21.2324 8.18164C21.6987 8.57689 22.0904 9.05517 22.3857 9.59472C22.7887 10.3309 23 11.1568 23 11.9961C23 12.0535 22.9961 12.1107 22.9941 12.168L12.6953 22.9512C12.4697 22.9823 12.2418 23 12.0127 23C11.1716 23 10.3437 22.7878 9.60645 22.3828C9.09106 22.0997 8.63308 21.7273 8.24902 21.2871L21.249 7.67578Z",
      fill: "white",
      fillOpacity: "0.3"
    }
  )
] }) }), d1 = (s) => s === 1 ? /* @__PURE__ */ e.jsx(l1, { className: "size-6" }) : s === 2 ? /* @__PURE__ */ e.jsx(o1, { className: "size-6" }) : s === 3 ? /* @__PURE__ */ e.jsx(c1, { className: "size-6" }) : null, u1 = (s) => s <= 3 ? null : `#${s}`;
function oe({ rank: s }) {
  const r = d1(s);
  return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
    r && /* @__PURE__ */ e.jsx("div", { children: r }),
    /* @__PURE__ */ e.jsx("span", { className: "text-sm text-foreground", children: u1(s) })
  ] });
}
const m1 = () => [
  {
    accessorKey: "rank",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Rank") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx(oe, { rank: s.original.rank }),
    enableSorting: !1,
    size: 20
  },
  {
    accessorKey: "projectName",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Projects") }),
    cell: ({ row: s }) => {
      const r = s.original.iconColor ? ee[s.original.iconColor] : ee[we.BLUE];
      return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ e.jsx(
          ye,
          {
            className: "size-6 text-xs font-medium flex items-center justify-center rounded-sm shrink-0",
            style: {
              backgroundColor: r.color,
              color: r.textColor
            },
            children: s.original.projectName.charAt(0).toUpperCase()
          }
        ),
        /* @__PURE__ */ e.jsx("p", { className: "h-8 flex items-center", children: s.original.projectName })
      ] });
    },
    enableSorting: !1
  },
  {
    accessorKey: "flowCount",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Active Flows") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: s.original.flowCount }),
    enableSorting: !1
  },
  {
    accessorKey: "minutesSaved",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Time Saved") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: k.formatToHoursAndMinutes(s.original.minutesSaved) }),
    enableSorting: !1
  }
], C1 = (s, r) => s.rank <= 3 ? "bg-primary/5 hover:bg-primary/10" : "hover:bg-accent";
function x1({
  data: s,
  isLoading: r
}) {
  const d = o.useMemo(() => m1(), []);
  return /* @__PURE__ */ e.jsx(
    le,
    {
      columns: d,
      page: {
        data: s,
        next: null,
        previous: null
      },
      isLoading: r ?? !1,
      clientPagination: !0,
      getRowClassName: C1,
      emptyStateTextTitle: t("No projects on the board yet"),
      emptyStateTextDescription: t(
        "Projects will rank here as flows are created and time is saved"
      ),
      emptyStateIcon: /* @__PURE__ */ e.jsx(i1, { className: "h-10 w-10 text-muted-foreground" }),
      onRowClick: (l) => {
        window.open(`/projects/${l.projectId}`, "_blank");
      }
    }
  );
}
const h1 = ({
  badges: s,
  isTopRank: r
}) => !s || s.length === 0 ? /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: "-" }) : /* @__PURE__ */ e.jsx("div", { className: "flex items-center gap-0.5", children: s.map((d) => {
  const l = Ae[d.name];
  return l ? /* @__PURE__ */ e.jsxs(M, { children: [
    /* @__PURE__ */ e.jsx(L, { asChild: !0, children: /* @__PURE__ */ e.jsx(
      "img",
      {
        src: l.imageUrl,
        alt: l.title,
        className: j(
          "h-7 w-7 object-cover rounded-md transition-opacity",
          !r && "opacity-30 group-hover/leaderrow:opacity-100"
        )
      }
    ) }),
    /* @__PURE__ */ e.jsxs(A, { className: "text-left", children: [
      /* @__PURE__ */ e.jsx("p", { className: "font-semibold", children: l.title }),
      /* @__PURE__ */ e.jsx("p", { className: "text-xs", children: l.description })
    ] })
  ] }, d.name) : null;
}) }), f1 = () => [
  {
    accessorKey: "rank",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Rank") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx(oe, { rank: s.original.rank }),
    enableSorting: !1,
    size: 25
  },
  {
    accessorKey: "userName",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("User") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "flex items-center gap-3", children: /* @__PURE__ */ e.jsx(
      Le,
      {
        id: s.original.visibleId,
        size: "small",
        includeAvatar: !0,
        includeName: !0
      }
    ) }),
    enableSorting: !1
  },
  {
    accessorKey: "flowCount",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Active Flows") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: s.original.flowCount }),
    enableSorting: !1,
    size: 120
  },
  {
    accessorKey: "minutesSaved",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Time Saved") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: k.formatToHoursAndMinutes(s.original.minutesSaved) }),
    enableSorting: !1,
    size: 120
  },
  {
    accessorKey: "badges",
    header: ({ column: s }) => /* @__PURE__ */ e.jsx(m, { column: s, title: t("Badges") }),
    cell: ({ row: s }) => /* @__PURE__ */ e.jsx(
      h1,
      {
        badges: s.original.badges,
        isTopRank: s.original.rank <= 3
      }
    ),
    enableSorting: !1
  }
], p1 = (s, r) => s.rank <= 3 ? "group/leaderrow bg-primary/5 hover:bg-primary/10" : "group/leaderrow hover:bg-accent";
function j1({ data: s, isLoading: r }) {
  const d = o.useMemo(() => f1(), []);
  return /* @__PURE__ */ e.jsx(
    le,
    {
      columns: d,
      page: {
        data: s,
        next: null,
        previous: null
      },
      isLoading: r ?? !1,
      clientPagination: !0,
      getRowClassName: p1,
      emptyStateTextTitle: t("No automation heroes yet"),
      emptyStateTextDescription: t(
        "Once your team starts building flows, their achievements will shine here"
      ),
      emptyStateIcon: /* @__PURE__ */ e.jsx(Me, { className: "h-10 w-10 text-muted-foreground" })
    }
  );
}
const U = {
  min: "",
  max: "",
  unitMin: "Sec",
  unitMax: "Sec"
};
function ie(s, r) {
  let d = s;
  const l = r.min ? parseFloat(r.min) : null, S = r.max ? parseFloat(r.max) : null;
  return l !== null && (d = d.filter(
    (u) => u.minutesSaved >= re(l, r.unitMin)
  )), S !== null && (d = d.filter(
    (u) => u.minutesSaved <= re(S, r.unitMax)
  )), d;
}
function N1() {
  const { platform: s } = ke.useCurrentPlatform(), [r, d] = o.useState(
    f.LAST_WEEK
  ), { data: l, isLoading: S } = y.useAnalytics(), { data: u, isLoading: ce } = y.useUsersLeaderboard(r), { data: D, isLoading: de } = y.useProjectLeaderboard(r), { data: N } = De.useAllPlatformProjects(), $ = o.useMemo(() => {
    const a = /* @__PURE__ */ new Map();
    return N == null || N.forEach((n) => {
      n.icon && a.set(n.id, n.icon.color);
    }), a;
  }, [N]), [h, ue] = o.useState("creators"), [C, F] = o.useState(""), [P, me] = o.useState(U), [E, Ce] = o.useState(U), c = h === "creators" ? P : E, B = h === "creators" ? me : Ce, [H, O] = o.useState(""), [_, z] = o.useState(""), [I, K] = o.useState("Sec"), [R, Z] = o.useState("Sec"), [xe, V] = o.useState(!1), { mutate: he } = y.useRefreshAnalytics(), { isRefreshing: Q } = o.useContext(Fe), W = o.useMemo(
    () => (u == null ? void 0 : u.map((a) => a.userId)) ?? [],
    [u]
  ), q = Pe({
    queries: W.map((a) => ({
      queryKey: ["user-badges", a],
      queryFn: () => Ee.getUserById(a),
      staleTime: 5 * 60 * 1e3,
      enabled: W.length > 0
    }))
  }), G = o.useMemo(() => {
    const a = /* @__PURE__ */ new Map();
    return q.forEach((n) => {
      n.data && a.set(n.data.id, n.data.badges);
    }), a;
  }, [q]), x = S || ce || de, fe = () => {
    const a = p.indexOf(I);
    K(p[(a + 1) % p.length]);
  }, pe = () => {
    const a = p.indexOf(R);
    Z(p[(a + 1) % p.length]);
  }, je = (a) => {
    a && (O(c.min), z(c.max), K(c.unitMin), Z(c.unitMax)), V(a);
  }, ge = () => {
    B({
      min: H,
      max: _,
      unitMin: I,
      unitMax: R
    }), V(!1);
  }, ve = C !== "" || c.min !== "" || c.max !== "", Se = () => {
    F(""), B(U);
  }, X = o.useMemo(() => {
    if (!c.min && !c.max) return null;
    const a = c.min ? `${c.min} ${c.unitMin}` : "0", n = c.max ? `${c.max} ${c.unitMax}` : "∞";
    return `${a} – ${n}`;
  }, [c]), J = o.useMemo(() => {
    if (x || !(l != null && l.users) || !u)
      return [];
    const a = new Map(l.users.map((n) => [n.id, n]));
    return u.reduce((n, i) => {
      const g = a.get(i.userId);
      return g && n.push({
        id: i.userId,
        visibleId: i.userId,
        userName: `${g.firstName} ${g.lastName}`.trim() || g.email,
        userEmail: g.email,
        flowCount: i.flowCount ?? 0,
        minutesSaved: i.minutesSaved ?? 0,
        badges: G.get(i.userId)
      }), n;
    }, []).sort((n, i) => i.minutesSaved - n.minutesSaved).map((n, i) => ({ ...n, rank: i + 1 }));
  }, [l == null ? void 0 : l.users, u, x, G]), Y = o.useMemo(() => x || !D ? [] : D.map((a) => ({
    id: a.projectId,
    projectId: a.projectId,
    projectName: a.projectName,
    flowCount: a.flowCount ?? 0,
    minutesSaved: a.minutesSaved ?? 0,
    iconColor: $.get(a.projectId)
  })).sort((a, n) => n.minutesSaved - a.minutesSaved).map((a, n) => ({ ...a, rank: n + 1 })), [D, x, $]), T = o.useMemo(() => {
    let a = J;
    if (C) {
      const n = C.toLowerCase();
      a = a.filter(
        (i) => i.userName.toLowerCase().includes(n) || i.userEmail.toLowerCase().includes(n)
      );
    }
    return ie(a, P);
  }, [J, C, P]), b = o.useMemo(() => {
    let a = Y;
    if (C) {
      const n = C.toLowerCase();
      a = a.filter((i) => i.projectName.toLowerCase().includes(n));
    }
    return ie(a, E);
  }, [Y, C, E]), Ne = () => {
    if (h === "creators") {
      if (T.length === 0) return;
      const a = `Name,Email,Flows,Time Saved
`, n = T.map(
        (i) => `"${i.userName}","${i.userEmail}",${i.flowCount},"${k.formatToHoursAndMinutes(
          i.minutesSaved || 0
        )}"`
      ).join(`
`);
      ne({
        obj: a + n,
        fileName: "people-leaderboard",
        extension: "csv"
      });
    } else {
      if (b.length === 0) return;
      const a = `Project,Flows,Time Saved
`, n = b.map(
        (i) => `"${i.projectName}",${i.flowCount},"${k.formatToHoursAndMinutes(
          i.minutesSaved || 0
        )}"`
      ).join(`
`);
      ne({
        obj: a + n,
        fileName: "projects-leaderboard",
        extension: "csv"
      });
    }
  }, Te = x || h === "creators" && T.length === 0 || h === "projects" && b.length === 0, be = (a) => {
    ue(a), F("");
  };
  return /* @__PURE__ */ e.jsx(
    Ie,
    {
      featureKey: "ANALYTICS",
      locked: !s.plan.analyticsEnabled,
      lockTitle: t("Unlock Leaderboard"),
      lockDescription: t(
        "See top performers by flows created and time saved across your platform"
      ),
      children: /* @__PURE__ */ e.jsx(Re, { children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2 w-full", children: [
        /* @__PURE__ */ e.jsx(
          Ue,
          {
            showSidebarToggle: !0,
            title: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ e.jsx("span", { className: "text-sm font-medium", children: t("Leaderboard") }),
              /* @__PURE__ */ e.jsxs(M, { children: [
                /* @__PURE__ */ e.jsx(L, { asChild: !0, children: /* @__PURE__ */ e.jsx(Ve, { className: "h-4 w-4 text-muted-foreground cursor-help" }) }),
                /* @__PURE__ */ e.jsx(A, { children: t("See top performers by flows created and time saved") })
              ] })
            ] }),
            rightContent: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 px-3 py-1.5 border border-dashed rounded-md text-sm text-muted-foreground", children: [
                /* @__PURE__ */ e.jsxs("span", { children: [
                  t("Updated"),
                  " ",
                  $e(l == null ? void 0 : l.cachedAt).format("MMM DD, hh:mm A"),
                  " — ",
                  t("Refreshes daily")
                ] }),
                /* @__PURE__ */ e.jsxs(M, { children: [
                  /* @__PURE__ */ e.jsx(L, { asChild: !0, children: /* @__PURE__ */ e.jsx(
                    w,
                    {
                      variant: "ghost",
                      size: "icon",
                      className: "h-6 w-6",
                      onClick: () => he(void 0, {
                        onSuccess: () => He.success(t("Data refreshed successfully"))
                      }),
                      disabled: Q,
                      children: /* @__PURE__ */ e.jsx(
                        Be,
                        {
                          className: `h-3.5 w-3.5 ${Q ? "animate-spin" : ""}`
                        }
                      )
                    }
                  ) }),
                  /* @__PURE__ */ e.jsx(A, { children: t("Refresh analytics") })
                ] })
              ] }),
              /* @__PURE__ */ e.jsxs(
                Oe,
                {
                  value: r,
                  onValueChange: (a) => d(a),
                  children: [
                    /* @__PURE__ */ e.jsxs(_e, { className: "w-auto gap-2 h-8", children: [
                      /* @__PURE__ */ e.jsx(ze, { className: "h-4 w-4" }),
                      /* @__PURE__ */ e.jsx(Ke, {})
                    ] }),
                    /* @__PURE__ */ e.jsxs(Ze, { side: "bottom", align: "end", children: [
                      /* @__PURE__ */ e.jsx(v, { value: f.LAST_WEEK, children: t("Last 7 days") }),
                      /* @__PURE__ */ e.jsx(v, { value: f.LAST_MONTH, children: t("Last 30 days") }),
                      /* @__PURE__ */ e.jsx(v, { value: f.LAST_THREE_MONTHS, children: t("Last 3 months") }),
                      /* @__PURE__ */ e.jsx(v, { value: f.LAST_SIX_MONTHS, children: t("Last 6 months") }),
                      /* @__PURE__ */ e.jsx(v, { value: f.LAST_YEAR, children: t("Last year") })
                    ] })
                  ]
                }
              )
            ] }),
            className: "min-w-full"
          }
        ),
        /* @__PURE__ */ e.jsxs(
          Qe,
          {
            defaultValue: "creators",
            className: "w-full mt-2",
            onValueChange: be,
            children: [
              /* @__PURE__ */ e.jsxs(
                We,
                {
                  variant: "outline",
                  className: j("border-b w-full", ae),
                  children: [
                    /* @__PURE__ */ e.jsxs(se, { variant: "outline", value: "creators", children: [
                      /* @__PURE__ */ e.jsx(qe, { className: "w-4 h-4 mr-1.5" }),
                      t("People")
                    ] }),
                    /* @__PURE__ */ e.jsxs(se, { variant: "outline", value: "projects", children: [
                      /* @__PURE__ */ e.jsx(Ge, { className: "w-4 h-4 mr-1.5" }),
                      t("Projects")
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ e.jsxs(
                "div",
                {
                  className: j(
                    "flex items-center justify-between mt-4 mb-4",
                    ae
                  ),
                  children: [
                    /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ e.jsx(
                        Xe,
                        {
                          value: C,
                          onChange: F,
                          placeholder: h === "creators" ? t("Search users") : t("Search projects"),
                          className: "w-[200px]"
                        }
                      ),
                      /* @__PURE__ */ e.jsxs(
                        Je,
                        {
                          open: xe,
                          onOpenChange: je,
                          children: [
                            /* @__PURE__ */ e.jsx(Ye, { asChild: !0, children: /* @__PURE__ */ e.jsxs(
                              w,
                              {
                                variant: "outline",
                                className: "gap-2 font-normal border-dashed",
                                children: [
                                  /* @__PURE__ */ e.jsx(e1, { className: "h-4 w-4" }),
                                  /* @__PURE__ */ e.jsx("span", { children: t("Time Saved") }),
                                  X && /* @__PURE__ */ e.jsx("span", { className: "rounded bg-accent px-1.5 py-0.5 text-xs font-medium", children: X }),
                                  /* @__PURE__ */ e.jsx(s1, { className: "h-4 w-4 opacity-50" })
                                ]
                              }
                            ) }),
                            /* @__PURE__ */ e.jsx(a1, { className: "w-[200px] p-4", align: "start", children: /* @__PURE__ */ e.jsx(
                              r1,
                              {
                                draftMin: H,
                                onMinChange: O,
                                unitMin: I,
                                onCycleUnitMin: fe,
                                draftMax: _,
                                onMaxChange: z,
                                unitMax: R,
                                onCycleUnitMax: pe,
                                onApply: ge
                              }
                            ) })
                          ]
                        }
                      ),
                      ve && /* @__PURE__ */ e.jsxs(w, { variant: "ghost", size: "sm", onClick: Se, children: [
                        /* @__PURE__ */ e.jsx(t1, { className: "h-4 w-4" }),
                        t("Clear")
                      ] })
                    ] }),
                    /* @__PURE__ */ e.jsxs(M, { children: [
                      /* @__PURE__ */ e.jsx(L, { asChild: !0, children: /* @__PURE__ */ e.jsxs(
                        w,
                        {
                          variant: "outline",
                          size: "sm",
                          onClick: Ne,
                          disabled: Te,
                          children: [
                            /* @__PURE__ */ e.jsx(n1, { className: "h-4 w-4 mr-2" }),
                            t("Download")
                          ]
                        }
                      ) }),
                      /* @__PURE__ */ e.jsx(A, { children: t("Download leaderboard data") })
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ e.jsx(te, { value: "creators", children: /* @__PURE__ */ e.jsx(
                j1,
                {
                  data: T,
                  isLoading: x
                }
              ) }),
              /* @__PURE__ */ e.jsx(te, { value: "projects", children: /* @__PURE__ */ e.jsx(
                x1,
                {
                  data: b,
                  isLoading: x
                }
              ) })
            ]
          }
        )
      ] }) })
    }
  );
}
export {
  N1 as default
};
