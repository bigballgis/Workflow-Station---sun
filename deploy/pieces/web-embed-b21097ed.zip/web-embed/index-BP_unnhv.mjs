import { b8 as c, H as m, ao as p, eY as r, j as a, bF as x, bi as f, eZ as g, a6 as s, b4 as h, h as j, e_ as b, e$ as v, bL as F } from "./mount-builder-CqIEWsZv.mjs";
import { B as y, a as D } from "./builder-state-provider-DiNVbDPS.mjs";
const N = () => {
  const { flowId: t } = c(), {
    data: e,
    isLoading: i,
    isError: o
  } = m({
    queryKey: ["flow", t, p.getProjectId()],
    queryFn: () => F.get(t),
    gcTime: 0,
    retry: !1,
    refetchOnWindowFocus: !1
  }), { data: n, isLoading: l } = r.useSampleDataForFlow(e == null ? void 0 : e.version, e == null ? void 0 : e.projectId), { data: d, isLoading: u } = r.useSampleDataInputForFlow(e == null ? void 0 : e.version, e == null ? void 0 : e.projectId);
  return i || l || u ? /* @__PURE__ */ a.jsx("div", { className: "bg-background flex h-full w-full items-center justify-center ", children: /* @__PURE__ */ a.jsx(x, { isLarge: !0 }) }) : f(e) || o ? /* @__PURE__ */ a.jsxs("div", { className: "flex flex-col items-center justify-center h-full text-center space-y-4", children: [
    /* @__PURE__ */ a.jsx("div", { className: "rounded-full bg-muted p-4", children: /* @__PURE__ */ a.jsx(g, { className: "size-9 text-muted-foreground" }) }),
    /* @__PURE__ */ a.jsxs("div", { children: [
      /* @__PURE__ */ a.jsx("h2", { className: "text-lg font-semibold", children: s("Flow not found") }),
      /* @__PURE__ */ a.jsx("p", { className: "text-sm text-muted-foreground", children: s("The flow you are looking for doesn't exist or was removed.") })
    ] }),
    /* @__PURE__ */ a.jsx(
      h,
      {
        className: j(b({ variant: "outline" })),
        to: "/dashboard",
        children: s("Go to Dashboard")
      }
    )
  ] }) : /* @__PURE__ */ a.jsx(v, { children: /* @__PURE__ */ a.jsx(
    y,
    {
      flow: e,
      flowVersion: e.version,
      readonly: !1,
      hideTestWidget: !1,
      run: null,
      outputSampleData: n ?? {},
      inputSampleData: d ?? {},
      children: /* @__PURE__ */ a.jsx(D, {})
    }
  ) });
};
export {
  N as FlowBuilderPage
};
