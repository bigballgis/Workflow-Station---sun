import { k4 as e, k5 as o } from "./mount-builder-CqIEWsZv.mjs";
function a(n) {
  return e(this, void 0, void 0, function() {
    var t;
    return o(this, function(i) {
      switch (i.label) {
        case 0:
          return [
            4,
            import(
              // @ts-expect-error
              "./index.umd-By6yRw0s.mjs"
            ).then((r) => r.i)
            // This is super gross, but we need to support the `window.analytics.plugins` namespace
            // that is linked in the segment docs in order to be backwards compatible with ajs-classic
            // @ts-expect-error
          ];
        case 1:
          return t = i.sent(), n._plugins = t, [
            2
            /*return*/
          ];
      }
    });
  });
}
export {
  a as loadLegacyVideoPlugins
};
