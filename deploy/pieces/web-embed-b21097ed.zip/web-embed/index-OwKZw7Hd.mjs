import { e as u, aj as C, b6 as b, H as v, be as j, bf as g, j as e, bF as y, a6 as s, ej as P, ek as M, el as r, em as n, d4 as T, en as U, eo as N } from "./mount-builder-CqIEWsZv.mjs";
import { C as l } from "./centered-page-C5JGBrkC.mjs";
async function S() {
  return u.get("/v1/mcp-server");
}
async function I(t) {
  return u.post("/v1/mcp-server", t);
}
const i = {
  get: S,
  update: I
}, c = ["platform-mcp-server"], d = {
  usePlatformMcpServer() {
    return v({
      queryKey: c,
      queryFn: () => i.get(),
      retry: !1,
      meta: { showErrorDialog: !0, loadSubsetOptions: {} }
    });
  },
  useUpdatePlatformMcpTools() {
    const t = C();
    return b({
      mutationFn: i.update,
      onSuccess: (a) => {
        t.setQueryData(c, a);
      }
    });
  }
};
function k() {
  const { data: t, isLoading: a } = d.usePlatformMcpServer(), { mutate: p, isPending: m } = d.useUpdatePlatformMcpTools(), { data: f } = j.useFlag(g.PUBLIC_URL);
  if (a)
    return /* @__PURE__ */ e.jsx(
      l,
      {
        title: s("Platform MCP Server"),
        description: s(
          "Configure the platform-wide MCP server used by the AI Chat assistant and external MCP clients."
        ),
        children: /* @__PURE__ */ e.jsx("div", { className: "flex items-center justify-center py-20", children: /* @__PURE__ */ e.jsx(y, {}) })
      }
    );
  const o = `${(f ?? "").replace(/\/$/, "")}/mcp/platform`, x = {
    mcpServers: {
      activepieces: {
        url: o
      }
    }
  };
  return /* @__PURE__ */ e.jsx(
    l,
    {
      title: s("Platform MCP Server"),
      description: s(
        "Configure the platform-wide MCP server used by the AI Chat assistant and external MCP clients."
      ),
      children: /* @__PURE__ */ e.jsx("div", { className: "space-y-6", children: t && /* @__PURE__ */ e.jsxs(P, { defaultValue: "connection", children: [
        /* @__PURE__ */ e.jsxs(M, { children: [
          /* @__PURE__ */ e.jsx(r, { value: "connection", children: s("Connection") }),
          /* @__PURE__ */ e.jsx(r, { value: "tools", children: s("Tools") })
        ] }),
        /* @__PURE__ */ e.jsx(n, { value: "connection", className: "mt-4 pb-6", tabIndex: -1, children: /* @__PURE__ */ e.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1.5", children: [
            /* @__PURE__ */ e.jsx("label", { className: "text-sm font-medium", children: s("Server URL") }),
            /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground", children: s(
              "Use this URL to connect from Cursor, Windsurf, Claude Desktop, or any MCP-compatible client. Authentication is handled via OAuth."
            ) }),
            /* @__PURE__ */ e.jsx(
              T,
              {
                textToCopy: o,
                useInput: !0
              }
            )
          ] }),
          /* @__PURE__ */ e.jsx(
            U,
            {
              json: x,
              label: s("JSON Configuration"),
              description: s(
                "Copy this into your MCP client config (Cursor, Windsurf, Claude Desktop, etc.)."
              ),
              defaultOpen: !1
            }
          )
        ] }) }),
        /* @__PURE__ */ e.jsx(
          n,
          {
            value: "tools",
            className: "mt-4 space-y-6 pb-6",
            tabIndex: -1,
            children: /* @__PURE__ */ e.jsxs("div", { children: [
              /* @__PURE__ */ e.jsx("h3", { className: "font-semibold text-base mb-1", children: s("Internal Tools") }),
              /* @__PURE__ */ e.jsx("p", { className: "text-sm text-muted-foreground mb-3", children: s(
                "Control which built-in tools are available to the AI Chat and external agents via the platform MCP server."
              ) }),
              /* @__PURE__ */ e.jsx(
                N,
                {
                  disabledTools: t.disabledTools,
                  isPending: m,
                  onUpdateDisabledTools: (h) => p({ disabledTools: h })
                }
              )
            ] })
          }
        )
      ] }) })
    }
  );
}
export {
  k as default
};
