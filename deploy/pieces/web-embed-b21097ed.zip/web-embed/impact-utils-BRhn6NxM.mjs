import { o as y, n as b, s as m, N as R, b as j, bI as se, dj as ae, B as oe, a as k, di as ce, w as ie, e as S, aj as le, g as D, f8 as ue, b6 as fe, I as E, H as C, j as h, aQ as O, a6 as L, aX as _, i as he, fr as me } from "./mount-builder-CqIEWsZv.mjs";
var M = /* @__PURE__ */ ((e) => (e.LAST_WEEK = "last-week", e.LAST_MONTH = "last-month", e.LAST_THREE_MONTHS = "last-three-months", e.LAST_SIX_MONTHS = "last-six-months", e.LAST_YEAR = "last-year", e))(M || {});
const de = y({
  day: m(),
  flowId: m(),
  runs: b()
}), ge = k(de), ye = y({
  flowId: m(),
  flowName: m(),
  projectId: m(),
  projectName: m(),
  status: j(se),
  timeSavedPerRun: R(b()),
  ownerId: R(m())
}), we = k(ye);
y({
  ...oe,
  cachedAt: ae,
  runs: ge,
  outdated: ie(),
  flows: we,
  platformId: m(),
  users: k(ce)
});
y({
  projectId: m(),
  projectName: m(),
  flowCount: b(),
  minutesSaved: R(b())
});
y({
  userId: m(),
  flowCount: b(),
  minutesSaved: R(b())
});
y({
  timePeriod: j(M).optional()
});
y({
  timePeriod: j(M)
});
const x = {
  get(e) {
    return S.get("/v1/analytics", { timePeriod: e });
  },
  refresh() {
    return S.post("/v1/analytics/refresh");
  },
  markAsOutdated() {
    return S.post("/v1/analytics/mark-outdated");
  },
  getProjectLeaderboard(e) {
    return S.get(
      "/v1/analytics/project-leaderboard",
      { timePeriod: e }
    );
  },
  getUserLeaderboard(e) {
    return S.get("/v1/analytics/user-leaderboard", {
      timePeriod: e
    });
  }
}, F = ["analytics"], pe = (e) => [
  "project-leaderboard",
  e
], be = (e) => [
  "user-leaderboard",
  e
], dt = {
  useUsersLeaderboard: (e) => {
    const { platform: t } = E.useCurrentPlatform(), { data: r, isLoading: n } = C({
      queryKey: be(e),
      queryFn: () => x.getUserLeaderboard(e),
      enabled: t.plan.analyticsEnabled
    });
    return {
      data: r ?? null,
      isLoading: n
    };
  },
  useProjectLeaderboard: (e) => {
    const { platform: t } = E.useCurrentPlatform(), { data: r, isLoading: n } = C({
      queryKey: pe(e),
      queryFn: () => x.getProjectLeaderboard(e),
      enabled: t.plan.analyticsEnabled
    });
    return {
      data: r ?? null,
      isLoading: n
    };
  },
  useAnalytics: () => {
    const { platform: e } = E.useCurrentPlatform(), { data: t, isLoading: r } = C({
      queryKey: F,
      queryFn: () => x.get(),
      enabled: e.plan.analyticsEnabled
    });
    return { data: t, isLoading: r };
  },
  useAnalyticsTimeBased: (e, t) => {
    const r = D.useCallback(
      (o) => {
        if (!t)
          return o;
        const c = o.flows.filter(
          (l) => l.projectId === t
        ), i = o.runs.filter(
          (l) => c.some((d) => d.flowId === l.flowId)
        );
        return {
          ...o,
          flows: c,
          runs: i
        };
      },
      [t]
    ), { platform: n } = E.useCurrentPlatform(), { data: s, isLoading: a } = C({
      queryKey: [...F, e],
      queryFn: () => x.get(e),
      select: r,
      enabled: n.plan.analyticsEnabled
    });
    return {
      isLoading: a,
      data: s ?? null
    };
  },
  useRefreshAnalytics: () => {
    const e = le(), { setIsRefreshing: t } = D.useContext(ue);
    return fe({
      mutationFn: async () => (t(!0), await new Promise((r) => setTimeout(r, 5e3)), x.refresh()),
      onSuccess: () => {
        t(!1), e.invalidateQueries({ queryKey: F }), e.invalidateQueries({ queryKey: ["project-leaderboard"] }), e.invalidateQueries({ queryKey: ["user-leaderboard"] });
      },
      retry: !0,
      retryDelay: 5e4
    });
  }
};
function gt({
  draftMin: e,
  onMinChange: t,
  unitMin: r,
  onCycleUnitMin: n,
  draftMax: s,
  onMaxChange: a,
  unitMax: o,
  onCycleUnitMax: c,
  onApply: i
}) {
  return /* @__PURE__ */ h.jsxs("div", { className: "flex flex-col gap-3", children: [
    /* @__PURE__ */ h.jsxs("div", { className: "flex flex-col gap-1.5", children: [
      /* @__PURE__ */ h.jsx(O, { className: "text-sm text-muted-foreground", children: L("Minimum") }),
      /* @__PURE__ */ h.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ h.jsx(
          _,
          {
            type: "number",
            min: 0,
            placeholder: "0",
            value: e,
            onChange: (l) => t(l.target.value),
            className: "pr-12"
          }
        ),
        /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: n,
            className: "absolute bg-accent px-1.5 py-0.5 rounded-sm right-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground cursor-pointer select-none",
            children: r
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ h.jsxs("div", { className: "flex flex-col gap-1.5", children: [
      /* @__PURE__ */ h.jsx(O, { className: "text-sm text-muted-foreground", children: L("Maximum") }),
      /* @__PURE__ */ h.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ h.jsx(
          _,
          {
            type: "number",
            min: 0,
            placeholder: "∞",
            value: s,
            onChange: (l) => a(l.target.value),
            className: s ? "pr-12" : ""
          }
        ),
        s && /* @__PURE__ */ h.jsx(
          "button",
          {
            type: "button",
            onClick: c,
            className: "absolute bg-accent px-1.5 py-0.5 rounded-sm right-2.5 top-1/2 -translate-y-1/2 text-xs text-muted-foreground hover:text-foreground cursor-pointer select-none",
            children: o
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ h.jsx(he, { onClick: i, className: "w-full mt-1", children: L("Apply") })
  ] });
}
function Se(e, t) {
  if (e.match(/^[a-z]+:\/\//i))
    return e;
  if (e.match(/^\/\//))
    return window.location.protocol + e;
  if (e.match(/^[a-z]+:/i))
    return e;
  const r = document.implementation.createHTMLDocument(), n = r.createElement("base"), s = r.createElement("a");
  return r.head.appendChild(n), r.body.appendChild(s), t && (n.href = t), s.href = e, s.href;
}
const xe = /* @__PURE__ */ (() => {
  let e = 0;
  const t = () => (
    // eslint-disable-next-line no-bitwise
    `0000${(Math.random() * 36 ** 4 << 0).toString(36)}`.slice(-4)
  );
  return () => (e += 1, `u${t()}${e}`);
})();
function g(e) {
  const t = [];
  for (let r = 0, n = e.length; r < n; r++)
    t.push(e[r]);
  return t;
}
let w = null;
function G(e = {}) {
  return w || (e.includeStyleProperties ? (w = e.includeStyleProperties, w) : (w = g(window.getComputedStyle(document.documentElement)), w));
}
function T(e, t) {
  const n = (e.ownerDocument.defaultView || window).getComputedStyle(e).getPropertyValue(t);
  return n ? parseFloat(n.replace("px", "")) : 0;
}
function Ee(e) {
  const t = T(e, "border-left-width"), r = T(e, "border-right-width");
  return e.clientWidth + t + r;
}
function Ce(e) {
  const t = T(e, "border-top-width"), r = T(e, "border-bottom-width");
  return e.clientHeight + t + r;
}
function N(e, t = {}) {
  const r = t.width || Ee(e), n = t.height || Ce(e);
  return { width: r, height: n };
}
function Re() {
  let e, t;
  try {
    t = process;
  } catch {
  }
  const r = t && t.env ? t.env.devicePixelRatio : null;
  return r && (e = parseInt(r, 10), Number.isNaN(e) && (e = 1)), e || window.devicePixelRatio || 1;
}
const f = 16384;
function Te(e) {
  (e.width > f || e.height > f) && (e.width > f && e.height > f ? e.width > e.height ? (e.height *= f / e.width, e.width = f) : (e.width *= f / e.height, e.height = f) : e.width > f ? (e.height *= f / e.width, e.width = f) : (e.width *= f / e.height, e.height = f));
}
function P(e) {
  return new Promise((t, r) => {
    const n = new Image();
    n.onload = () => {
      n.decode().then(() => {
        requestAnimationFrame(() => t(n));
      });
    }, n.onerror = r, n.crossOrigin = "anonymous", n.decoding = "async", n.src = e;
  });
}
async function Pe(e) {
  return Promise.resolve().then(() => new XMLSerializer().serializeToString(e)).then(encodeURIComponent).then((t) => `data:image/svg+xml;charset=utf-8,${t}`);
}
async function ve(e, t, r) {
  const n = "http://www.w3.org/2000/svg", s = document.createElementNS(n, "svg"), a = document.createElementNS(n, "foreignObject");
  return s.setAttribute("width", `${t}`), s.setAttribute("height", `${r}`), s.setAttribute("viewBox", `0 0 ${t} ${r}`), a.setAttribute("width", "100%"), a.setAttribute("height", "100%"), a.setAttribute("x", "0"), a.setAttribute("y", "0"), a.setAttribute("externalResourcesRequired", "true"), s.appendChild(a), a.appendChild(e), Pe(s);
}
const u = (e, t) => {
  if (e instanceof t)
    return !0;
  const r = Object.getPrototypeOf(e);
  return r === null ? !1 : r.constructor.name === t.name || u(r, t);
};
function Ie(e) {
  const t = e.getPropertyValue("content");
  return `${e.cssText} content: '${t.replace(/'|"/g, "")}';`;
}
function Le(e, t) {
  return G(t).map((r) => {
    const n = e.getPropertyValue(r), s = e.getPropertyPriority(r);
    return `${r}: ${n}${s ? " !important" : ""};`;
  }).join(" ");
}
function Fe(e, t, r, n) {
  const s = `.${e}:${t}`, a = r.cssText ? Ie(r) : Le(r, n);
  return document.createTextNode(`${s}{${a}}`);
}
function q(e, t, r, n) {
  const s = window.getComputedStyle(e, r), a = s.getPropertyValue("content");
  if (a === "" || a === "none")
    return;
  const o = xe();
  try {
    t.className = `${t.className} ${o}`;
  } catch {
    return;
  }
  const c = document.createElement("style");
  c.appendChild(Fe(o, r, s, n)), t.appendChild(c);
}
function $e(e, t, r) {
  q(e, t, ":before", r), q(e, t, ":after", r);
}
const V = "application/font-woff", W = "image/jpeg", Ae = {
  woff: V,
  woff2: V,
  ttf: "application/font-truetype",
  eot: "application/vnd.ms-fontobject",
  png: "image/png",
  jpg: W,
  jpeg: W,
  gif: "image/gif",
  tiff: "image/tiff",
  svg: "image/svg+xml",
  webp: "image/webp"
};
function je(e) {
  const t = /\.([^./]*?)$/g.exec(e);
  return t ? t[1] : "";
}
function H(e) {
  const t = je(e).toLowerCase();
  return Ae[t] || "";
}
function ke(e) {
  return e.split(/,/)[1];
}
function A(e) {
  return e.search(/^(data:)/) !== -1;
}
function Me(e, t) {
  return `data:${t};base64,${e}`;
}
async function X(e, t, r) {
  const n = await fetch(e, t);
  if (n.status === 404)
    throw new Error(`Resource "${n.url}" not found`);
  const s = await n.blob();
  return new Promise((a, o) => {
    const c = new FileReader();
    c.onerror = o, c.onloadend = () => {
      try {
        a(r({ res: n, result: c.result }));
      } catch (i) {
        o(i);
      }
    }, c.readAsDataURL(s);
  });
}
const $ = {};
function He(e, t, r) {
  let n = e.replace(/\?.*/, "");
  return r && (n = e), /ttf|otf|eot|woff2?/i.test(n) && (n = n.replace(/.*\//, "")), t ? `[${t}]${n}` : n;
}
async function U(e, t, r) {
  const n = He(e, t, r.includeQueryParams);
  if ($[n] != null)
    return $[n];
  r.cacheBust && (e += (/\?/.test(e) ? "&" : "?") + (/* @__PURE__ */ new Date()).getTime());
  let s;
  try {
    const a = await X(e, r.fetchRequestInit, ({ res: o, result: c }) => (t || (t = o.headers.get("Content-Type") || ""), ke(c)));
    s = Me(a, t);
  } catch (a) {
    s = r.imagePlaceholder || "";
    let o = `Failed to fetch resource: ${e}`;
    a && (o = typeof a == "string" ? a : a.message), o && console.warn(o);
  }
  return $[n] = s, s;
}
async function Ue(e) {
  const t = e.toDataURL();
  return t === "data:," ? e.cloneNode(!1) : P(t);
}
async function De(e, t) {
  if (e.currentSrc) {
    const a = document.createElement("canvas"), o = a.getContext("2d");
    a.width = e.clientWidth, a.height = e.clientHeight, o == null || o.drawImage(e, 0, 0, a.width, a.height);
    const c = a.toDataURL();
    return P(c);
  }
  const r = e.poster, n = H(r), s = await U(r, n, t);
  return P(s);
}
async function Oe(e, t) {
  var r;
  try {
    if (!((r = e == null ? void 0 : e.contentDocument) === null || r === void 0) && r.body)
      return await v(e.contentDocument.body, t, !0);
  } catch {
  }
  return e.cloneNode(!1);
}
async function _e(e, t) {
  return u(e, HTMLCanvasElement) ? Ue(e) : u(e, HTMLVideoElement) ? De(e, t) : u(e, HTMLIFrameElement) ? Oe(e, t) : e.cloneNode(J(e));
}
const qe = (e) => e.tagName != null && e.tagName.toUpperCase() === "SLOT", J = (e) => e.tagName != null && e.tagName.toUpperCase() === "SVG";
async function Ve(e, t, r) {
  var n, s;
  if (J(t))
    return t;
  let a = [];
  return qe(e) && e.assignedNodes ? a = g(e.assignedNodes()) : u(e, HTMLIFrameElement) && (!((n = e.contentDocument) === null || n === void 0) && n.body) ? a = g(e.contentDocument.body.childNodes) : a = g(((s = e.shadowRoot) !== null && s !== void 0 ? s : e).childNodes), a.length === 0 || u(e, HTMLVideoElement) || await a.reduce((o, c) => o.then(() => v(c, r)).then((i) => {
    i && t.appendChild(i);
  }), Promise.resolve()), t;
}
function We(e, t, r) {
  const n = t.style;
  if (!n)
    return;
  const s = window.getComputedStyle(e);
  s.cssText ? (n.cssText = s.cssText, n.transformOrigin = s.transformOrigin) : G(r).forEach((a) => {
    let o = s.getPropertyValue(a);
    a === "font-size" && o.endsWith("px") && (o = `${Math.floor(parseFloat(o.substring(0, o.length - 2))) - 0.1}px`), u(e, HTMLIFrameElement) && a === "display" && o === "inline" && (o = "block"), a === "d" && t.getAttribute("d") && (o = `path(${t.getAttribute("d")})`), n.setProperty(a, o, s.getPropertyPriority(a));
  });
}
function Be(e, t) {
  u(e, HTMLTextAreaElement) && (t.innerHTML = e.value), u(e, HTMLInputElement) && t.setAttribute("value", e.value);
}
function Ke(e, t) {
  if (u(e, HTMLSelectElement)) {
    const r = t, n = Array.from(r.children).find((s) => e.value === s.getAttribute("value"));
    n && n.setAttribute("selected", "");
  }
}
function Qe(e, t, r) {
  return u(t, Element) && (We(e, t, r), $e(e, t, r), Be(e, t), Ke(e, t)), t;
}
async function ze(e, t) {
  const r = e.querySelectorAll ? e.querySelectorAll("use") : [];
  if (r.length === 0)
    return e;
  const n = {};
  for (let a = 0; a < r.length; a++) {
    const c = r[a].getAttribute("xlink:href");
    if (c) {
      const i = e.querySelector(c), l = document.querySelector(c);
      !i && l && !n[c] && (n[c] = await v(l, t, !0));
    }
  }
  const s = Object.values(n);
  if (s.length) {
    const a = "http://www.w3.org/1999/xhtml", o = document.createElementNS(a, "svg");
    o.setAttribute("xmlns", a), o.style.position = "absolute", o.style.width = "0", o.style.height = "0", o.style.overflow = "hidden", o.style.display = "none";
    const c = document.createElementNS(a, "defs");
    o.appendChild(c);
    for (let i = 0; i < s.length; i++)
      c.appendChild(s[i]);
    e.appendChild(o);
  }
  return e;
}
async function v(e, t, r) {
  return !r && t.filter && !t.filter(e) ? null : Promise.resolve(e).then((n) => _e(n, t)).then((n) => Ve(e, n, t)).then((n) => Qe(e, n, t)).then((n) => ze(n, t));
}
const Y = /url\((['"]?)([^'"]+?)\1\)/g, Ge = /url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g, Ne = /src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;
function Xe(e) {
  const t = e.replace(/([.*+?^${}()|\[\]\/\\])/g, "\\$1");
  return new RegExp(`(url\\(['"]?)(${t})(['"]?\\))`, "g");
}
function Je(e) {
  const t = [];
  return e.replace(Y, (r, n, s) => (t.push(s), r)), t.filter((r) => !A(r));
}
async function Ye(e, t, r, n, s) {
  try {
    const a = r ? Se(t, r) : t, o = H(t);
    let c;
    return s || (c = await U(a, o, n)), e.replace(Xe(t), `$1${c}$3`);
  } catch {
  }
  return e;
}
function Ze(e, { preferredFontFormat: t }) {
  return t ? e.replace(Ne, (r) => {
    for (; ; ) {
      const [n, , s] = Ge.exec(r) || [];
      if (!s)
        return "";
      if (s === t)
        return `src: ${n};`;
    }
  }) : e;
}
function Z(e) {
  return e.search(Y) !== -1;
}
async function ee(e, t, r) {
  if (!Z(e))
    return e;
  const n = Ze(e, r);
  return Je(n).reduce((a, o) => a.then((c) => Ye(c, o, t, r)), Promise.resolve(n));
}
async function p(e, t, r) {
  var n;
  const s = (n = t.style) === null || n === void 0 ? void 0 : n.getPropertyValue(e);
  if (s) {
    const a = await ee(s, null, r);
    return t.style.setProperty(e, a, t.style.getPropertyPriority(e)), !0;
  }
  return !1;
}
async function et(e, t) {
  await p("background", e, t) || await p("background-image", e, t), await p("mask", e, t) || await p("-webkit-mask", e, t) || await p("mask-image", e, t) || await p("-webkit-mask-image", e, t);
}
async function tt(e, t) {
  const r = u(e, HTMLImageElement);
  if (!(r && !A(e.src)) && !(u(e, SVGImageElement) && !A(e.href.baseVal)))
    return;
  const n = r ? e.src : e.href.baseVal, s = await U(n, H(n), t);
  await new Promise((a, o) => {
    e.onload = a, e.onerror = t.onImageErrorHandler ? (...i) => {
      try {
        a(t.onImageErrorHandler(...i));
      } catch (l) {
        o(l);
      }
    } : o;
    const c = e;
    c.decode && (c.decode = a), c.loading === "lazy" && (c.loading = "eager"), r ? (e.srcset = "", e.src = s) : e.href.baseVal = s;
  });
}
async function rt(e, t) {
  const n = g(e.childNodes).map((s) => te(s, t));
  await Promise.all(n).then(() => e);
}
async function te(e, t) {
  u(e, Element) && (await et(e, t), await tt(e, t), await rt(e, t));
}
function nt(e, t) {
  const { style: r } = e;
  t.backgroundColor && (r.backgroundColor = t.backgroundColor), t.width && (r.width = `${t.width}px`), t.height && (r.height = `${t.height}px`);
  const n = t.style;
  return n != null && Object.keys(n).forEach((s) => {
    r[s] = n[s];
  }), e;
}
const B = {};
async function K(e) {
  let t = B[e];
  if (t != null)
    return t;
  const n = await (await fetch(e)).text();
  return t = { url: e, cssText: n }, B[e] = t, t;
}
async function Q(e, t) {
  let r = e.cssText;
  const n = /url\(["']?([^"')]+)["']?\)/g, a = (r.match(/url\([^)]+\)/g) || []).map(async (o) => {
    let c = o.replace(n, "$1");
    return c.startsWith("https://") || (c = new URL(c, e.url).href), X(c, t.fetchRequestInit, ({ result: i }) => (r = r.replace(o, `url(${i})`), [o, i]));
  });
  return Promise.all(a).then(() => r);
}
function z(e) {
  if (e == null)
    return [];
  const t = [], r = /(\/\*[\s\S]*?\*\/)/gi;
  let n = e.replace(r, "");
  const s = new RegExp("((@.*?keyframes [\\s\\S]*?){([\\s\\S]*?}\\s*?)})", "gi");
  for (; ; ) {
    const i = s.exec(n);
    if (i === null)
      break;
    t.push(i[0]);
  }
  n = n.replace(s, "");
  const a = /@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi, o = "((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})", c = new RegExp(o, "gi");
  for (; ; ) {
    let i = a.exec(n);
    if (i === null) {
      if (i = c.exec(n), i === null)
        break;
      a.lastIndex = c.lastIndex;
    } else
      c.lastIndex = a.lastIndex;
    t.push(i[0]);
  }
  return t;
}
async function st(e, t) {
  const r = [], n = [];
  return e.forEach((s) => {
    if ("cssRules" in s)
      try {
        g(s.cssRules || []).forEach((a, o) => {
          if (a.type === CSSRule.IMPORT_RULE) {
            let c = o + 1;
            const i = a.href, l = K(i).then((d) => Q(d, t)).then((d) => z(d).forEach((I) => {
              try {
                s.insertRule(I, I.startsWith("@import") ? c += 1 : s.cssRules.length);
              } catch (ne) {
                console.error("Error inserting rule from remote css", {
                  rule: I,
                  error: ne
                });
              }
            })).catch((d) => {
              console.error("Error loading remote css", d.toString());
            });
            n.push(l);
          }
        });
      } catch (a) {
        const o = e.find((c) => c.href == null) || document.styleSheets[0];
        s.href != null && n.push(K(s.href).then((c) => Q(c, t)).then((c) => z(c).forEach((i) => {
          o.insertRule(i, o.cssRules.length);
        })).catch((c) => {
          console.error("Error loading remote stylesheet", c);
        })), console.error("Error inlining remote css file", a);
      }
  }), Promise.all(n).then(() => (e.forEach((s) => {
    if ("cssRules" in s)
      try {
        g(s.cssRules || []).forEach((a) => {
          r.push(a);
        });
      } catch (a) {
        console.error(`Error while reading CSS rules from ${s.href}`, a);
      }
  }), r));
}
function at(e) {
  return e.filter((t) => t.type === CSSRule.FONT_FACE_RULE).filter((t) => Z(t.style.getPropertyValue("src")));
}
async function ot(e, t) {
  if (e.ownerDocument == null)
    throw new Error("Provided element is not within a Document");
  const r = g(e.ownerDocument.styleSheets), n = await st(r, t);
  return at(n);
}
function re(e) {
  return e.trim().replace(/["']/g, "");
}
function ct(e) {
  const t = /* @__PURE__ */ new Set();
  function r(n) {
    (n.style.fontFamily || getComputedStyle(n).fontFamily).split(",").forEach((a) => {
      t.add(re(a));
    }), Array.from(n.children).forEach((a) => {
      a instanceof HTMLElement && r(a);
    });
  }
  return r(e), t;
}
async function it(e, t) {
  const r = await ot(e, t), n = ct(e);
  return (await Promise.all(r.filter((a) => n.has(re(a.style.fontFamily))).map((a) => {
    const o = a.parentStyleSheet ? a.parentStyleSheet.href : null;
    return ee(a.cssText, o, t);
  }))).join(`
`);
}
async function lt(e, t) {
  const r = t.fontEmbedCSS != null ? t.fontEmbedCSS : t.skipFonts ? null : await it(e, t);
  if (r) {
    const n = document.createElement("style"), s = document.createTextNode(r);
    n.appendChild(s), e.firstChild ? e.insertBefore(n, e.firstChild) : e.appendChild(n);
  }
}
async function ut(e, t = {}) {
  const { width: r, height: n } = N(e, t), s = await v(e, t, !0);
  return await lt(s, t), await te(s, t), nt(s, t), await ve(s, r, n);
}
async function ft(e, t = {}) {
  const { width: r, height: n } = N(e, t), s = await ut(e, t), a = await P(s), o = document.createElement("canvas"), c = o.getContext("2d"), i = t.pixelRatio || Re(), l = t.canvasWidth || r, d = t.canvasHeight || n;
  return o.width = l * i, o.height = d * i, t.skipAutoScale || Te(o), o.style.width = `${l}`, o.style.height = `${d}`, t.backgroundColor && (c.fillStyle = t.backgroundColor, c.fillRect(0, 0, o.width, o.height)), c.drawImage(a, 0, 0, o.width, o.height), o;
}
async function ht(e, t = {}) {
  return (await ft(e, t)).toDataURL();
}
const yt = ["Sec", "Min", "Hrs"], wt = (e, t) => {
  switch (t) {
    case "Sec":
      return e;
    case "Min":
      return e * 60;
    case "Hrs":
      return e * 3600;
  }
}, pt = (e) => {
  if (e == null || e === 0)
    return { hours: "", mins: "", secs: "" };
  const t = Math.round(e), r = Math.floor(t / 3600), n = Math.floor(t % 3600 / 60), s = t % 60;
  return {
    hours: r > 0 ? r.toString() : "",
    mins: n > 0 || r > 0 ? n.toString().padStart(2, "0") : "",
    secs: s > 0 || n > 0 || r > 0 ? s.toString().padStart(2, "0") : ""
  };
}, bt = (e, t, r) => {
  const n = e === "" ? 0 : parseInt(e, 10), s = t === "" ? 0 : parseInt(t, 10), a = r === "" ? 0 : parseInt(r, 10);
  return isNaN(n) || isNaN(s) || isNaN(a) || n === 0 && s === 0 && a === 0 ? null : n * 3600 + s * 60 + a;
}, St = async (e, t) => {
  if (e.current)
    try {
      const r = await ht(e.current, {
        backgroundColor: "#ffffff",
        pixelRatio: 2
      }), n = document.createElement("a");
      n.download = `${t}-${(/* @__PURE__ */ new Date()).toISOString().split("T")[0]}.png`, n.href = r, n.click();
    } catch (r) {
      console.error("Failed to download chart:", r);
    }
}, xt = (e) => {
  if (e.length === 0) return;
  const t = `Flow Name,Owner ID,Time Saved Per Run (seconds),Total Time Saved (seconds),Project Name
`, r = e.map(
    (n) => `"${n.flowName}","${n.ownerId ?? ""}",${n.timeSavedPerRun ?? 0},${n.minutesSaved},"${n.projectName}"`
  ).join(`
`);
  me({
    obj: t + r,
    fileName: "flow-details",
    extension: "csv"
  });
};
export {
  M as A,
  yt as T,
  x as a,
  gt as b,
  wt as c,
  St as d,
  xt as e,
  bt as h,
  dt as p,
  pt as s
};
