import { c as lw, f0 as fw, f1 as Hc, f2 as Od, f3 as _d, f4 as dw, g as D, a6 as U, j as S, ax as ca, ay as la, i as vt, au as Kc, f5 as Gc, f6 as ur, f7 as Vc, C as vf, aA as fa, dt as hw, a9 as pw, h as We, ao as vw, f8 as yf, b6 as yw, aJ as Xc, bL as mw, bJ as gw, cd as Yc, f9 as Zc, cp as Vr, fa as Qc, D as pn, a3 as pr, a4 as vr, al as Sd, a5 as yr, aW as bw, aa as vn, ai as eb, aX as tb, ar as xw, fb as rb, ct as ww, co as Ow, at as _w, fc as Sw, c7 as Aw, cJ as mf, b1 as or, eQ as nb, bI as Pw, eN as Tw, d0 as jw, ah as Ew, fd as ii, fe as ce, ff as re, a1 as T, fg as Mw, cK as Cw, fh as Iw, cL as $w, fi as Nw, I as kw, d1 as Dw, as as Rw, fj as Lw, bC as qw, eX as Bw, L as Ka, dK as Fw, dB as zw, dC as Uw, cs as Ww, dD as Hw, dE as Kw, dF as Xr, ej as Gw, ek as Vw, el as Ad, fk as Xw, em as Pd } from "./mount-builder-CqIEWsZv.mjs";
import { c as Td, T as tt, a as Yw, s as Zw, h as Qw, e as Jw, b as eO, d as tO, A as rr, p as jd } from "./impact-utils-BRhn6NxM.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const rO = [
  ["path", { d: "M3 5h.01", key: "18ugdj" }],
  ["path", { d: "M3 12h.01", key: "nlz23k" }],
  ["path", { d: "M3 19h.01", key: "noohij" }],
  ["path", { d: "M8 5h13", key: "1pao27" }],
  ["path", { d: "M8 12h13", key: "1za7za" }],
  ["path", { d: "M8 19h13", key: "m83p4d" }]
], nO = lw("list", rO);
function iO(e, t) {
  t || (t = []);
  var r = e ? Math.min(t.length, e.length) : 0, n = t.slice(), i;
  return function(a) {
    for (i = 0; i < r; ++i) n[i] = e[i] * (1 - a) + t[i] * a;
    return n;
  };
}
function aO(e) {
  return ArrayBuffer.isView(e) && !(e instanceof DataView);
}
function oO(e, t) {
  var r = t ? t.length : 0, n = e ? Math.min(r, e.length) : 0, i = new Array(n), a = new Array(r), o;
  for (o = 0; o < n; ++o) i[o] = qr(e[o], t[o]);
  for (; o < r; ++o) a[o] = t[o];
  return function(u) {
    for (o = 0; o < n; ++o) a[o] = i[o](u);
    return a;
  };
}
function uO(e, t) {
  var r = /* @__PURE__ */ new Date();
  return e = +e, t = +t, function(n) {
    return r.setTime(e * (1 - n) + t * n), r;
  };
}
function sO(e, t) {
  var r = {}, n = {}, i;
  (e === null || typeof e != "object") && (e = {}), (t === null || typeof t != "object") && (t = {});
  for (i in t)
    i in e ? r[i] = qr(e[i], t[i]) : n[i] = t[i];
  return function(a) {
    for (i in r) n[i] = r[i](a);
    return n;
  };
}
function qr(e, t) {
  var r = typeof t, n;
  return t == null || r === "boolean" ? fw(t) : (r === "number" ? Hc : r === "string" ? (n = Od(t)) ? (t = n, _d) : dw : t instanceof Od ? _d : t instanceof Date ? uO : aO(t) ? iO : Array.isArray(t) ? oO : typeof t.valueOf != "function" && typeof t.toString != "function" || isNaN(t) ? sO : Hc)(e, t);
}
function gf(e, t) {
  return e = +e, t = +t, function(r) {
    return Math.round(e * (1 - r) + t * r);
  };
}
function cO(e, t) {
  t === void 0 && (t = e, e = qr);
  for (var r = 0, n = t.length - 1, i = t[0], a = new Array(n < 0 ? 0 : n); r < n; ) a[r] = e(i, i = t[++r]);
  return function(o) {
    var u = Math.max(0, Math.min(n - 1, Math.floor(o *= n)));
    return a[u](o - u);
  };
}
const Ed = 36, lO = 300;
function fO({
  projects: e,
  selectedProjectId: t,
  onProjectChange: r
}) {
  const [n, i] = D.useState(!1), o = [{ id: "all", displayName: U("All Projects") }, ...e], u = t ? e.find((l) => l.id === t) : null, s = (u == null ? void 0 : u.displayName) ?? U("All Projects"), c = (l) => {
    r(l), i(!1);
  }, f = Math.min(
    o.length * Ed,
    lO
  );
  return /* @__PURE__ */ S.jsxs(ca, { open: n, onOpenChange: i, children: [
    /* @__PURE__ */ S.jsx(la, { asChild: !0, children: /* @__PURE__ */ S.jsxs(
      vt,
      {
        variant: "outline",
        role: "combobox",
        "aria-expanded": n,
        className: "w-auto gap-2 font-normal h-8",
        children: [
          (u == null ? void 0 : u.type) === Kc.TEAM ? /* @__PURE__ */ S.jsx(
            Gc,
            {
              className: "size-4 shrink-0 flex items-center justify-center rounded-[4px] text-xs font-bold",
              style: {
                backgroundColor: ur[u.icon.color].color,
                color: ur[u.icon.color].textColor
              },
              children: /* @__PURE__ */ S.jsx("span", { className: "scale-75", children: u.displayName.charAt(0).toUpperCase() })
            }
          ) : /* @__PURE__ */ S.jsx(Vc, { className: "h-4 w-4" }),
          /* @__PURE__ */ S.jsx("span", { className: "max-w-[150px] truncate", children: s }),
          /* @__PURE__ */ S.jsx(vf, { className: "h-4 w-4 opacity-50" })
        ]
      }
    ) }),
    /* @__PURE__ */ S.jsx(fa, { className: "w-[250px] p-0", align: "end", children: /* @__PURE__ */ S.jsx("div", { style: { height: f }, children: /* @__PURE__ */ S.jsx(
      hw,
      {
        items: o,
        estimateSize: () => Ed,
        getItemKey: (l) => o[l].id,
        className: "h-full",
        overscan: 10,
        renderItem: (l) => {
          const d = l.id === "all" ? !t : l.id === t, p = l.id !== "all" ? l : null, y = (p == null ? void 0 : p.type) === Kc.TEAM;
          return /* @__PURE__ */ S.jsxs(
            "div",
            {
              onClick: () => c(l.id),
              className: We(
                "flex items-center gap-2 px-3 py-2 text-sm cursor-pointer hover:bg-accent",
                d && "bg-accent"
              ),
              children: [
                y && p ? /* @__PURE__ */ S.jsx(
                  Gc,
                  {
                    className: "size-5 shrink-0 flex items-center justify-center rounded-[4px] text-xs font-bold",
                    style: {
                      backgroundColor: ur[p.icon.color].color,
                      color: ur[p.icon.color].textColor
                    },
                    children: /* @__PURE__ */ S.jsx("span", { className: "scale-75", children: l.displayName.charAt(0).toUpperCase() })
                  }
                ) : /* @__PURE__ */ S.jsx(Vc, { className: "size-5 shrink-0 text-muted-foreground" }),
                /* @__PURE__ */ S.jsx("span", { className: "truncate flex-1", children: l.displayName }),
                /* @__PURE__ */ S.jsx(
                  pw,
                  {
                    className: We(
                      "h-4 w-4 shrink-0",
                      d ? "opacity-100" : "opacity-0"
                    )
                  }
                )
              ]
            }
          );
        }
      }
    ) }) })
  ] });
}
const Yr = {
  min: "",
  max: "",
  unitMin: "Sec",
  unitMax: "Sec"
};
function dO(e, t) {
  const [r, n] = D.useState(""), [i, a] = D.useState(!1), [o, u] = D.useState(
    Yr
  ), [s, c] = D.useState(
    Yr
  ), [f, l] = D.useState(!1), [d, p] = D.useState({
    selectedIds: [],
    searchQuery: "",
    popoverOpen: !1
  }), y = vw.getCurrentUserId(), v = (E) => {
    c((C) => ({ ...C, ...E }));
  }, h = (E) => {
    p((C) => ({ ...C, ...E }));
  }, w = () => {
    const E = tt.indexOf(s.unitMin), C = tt[(E + 1) % tt.length], I = tt.indexOf(C), N = tt.indexOf(s.unitMax);
    I > N ? v({ unitMin: C, unitMax: C }) : v({ unitMin: C });
  }, b = () => {
    const E = tt.indexOf(s.unitMax), C = tt[(E + 1) % tt.length], I = tt.indexOf(C), N = tt.indexOf(s.unitMin);
    I < N ? v({ unitMax: C, unitMin: C }) : v({ unitMax: C });
  }, x = (E) => {
    E && c(o), l(E);
  }, O = () => {
    u(s), l(!1);
  }, m = () => {
    c(Yr), u(Yr), l(!1);
  }, g = D.useMemo(() => {
    if (!o.min && !o.max) return null;
    const E = o.min ? `${o.min} ${o.unitMin}` : "0", C = o.max ? `${o.max} ${o.unitMax}` : "∞";
    return `${E} – ${C}`;
  }, [o]), _ = (E) => {
    p((C) => ({
      ...C,
      selectedIds: C.selectedIds.includes(E) ? C.selectedIds.filter((I) => I !== E) : [...C.selectedIds, E]
    }));
  }, A = D.useMemo(() => {
    if (!d.searchQuery.trim()) return t;
    const E = d.searchQuery.toLowerCase();
    return t.filter((C) => C.name.toLowerCase().includes(E));
  }, [t, d.searchQuery]), P = D.useMemo(
    () => t.filter((E) => d.selectedIds.includes(E.id)),
    [t, d.selectedIds]
  ), $ = r !== "" || o.min !== "" || o.max !== "" || d.selectedIds.length > 0, M = () => {
    n(""), u(Yr), h({ selectedIds: [] });
  }, j = D.useMemo(() => {
    if (!e) return [];
    let E = e;
    if (r.trim()) {
      const N = r.toLowerCase();
      E = E.filter(
        (R) => R.flowName.toLowerCase().includes(N)
      );
    }
    i && (E = E.filter((N) => N.ownerId === y)), d.selectedIds.length > 0 && (E = E.filter(
      (N) => N.ownerId && d.selectedIds.includes(N.ownerId)
    ));
    const C = o.min ? parseFloat(o.min) : null, I = o.max ? parseFloat(o.max) : null;
    return C !== null && (E = E.filter(
      (N) => N.minutesSaved >= Td(C, o.unitMin)
    )), I !== null && (E = E.filter(
      (N) => N.minutesSaved <= Td(I, o.unitMax)
    )), E.sort((N, R) => R.minutesSaved - N.minutesSaved);
  }, [
    e,
    r,
    i,
    y,
    d.selectedIds,
    o
  ]);
  return {
    searchQuery: r,
    setSearchQuery: n,
    showMyFlowsOnly: i,
    setShowMyFlowsOnly: a,
    draftTimeSaved: s,
    updateDraftTimeSaved: v,
    cycleDraftTimeUnitMin: w,
    cycleDraftTimeUnitMax: b,
    timeSavedPopoverOpen: f,
    handleTimeSavedPopoverOpen: x,
    applyTimeSavedFilter: O,
    clearTimeSavedFilter: m,
    timeSavedLabel: g,
    ownerFilter: d,
    updateOwnerFilter: h,
    toggleOwner: _,
    filteredOwners: A,
    selectedOwners: P,
    hasActiveFilters: $,
    clearAllFilters: M,
    filteredData: j
  };
}
function hO(e) {
  const { timeSavedPerRunOverrides: t, setTimeSavedPerRunOverride: r } = D.useContext(
    yf
  ), n = D.useMemo(() => e ? new Map(e.runs.map((u) => [u.flowId, u.runs ?? 0])) : /* @__PURE__ */ new Map(), [e]), i = D.useMemo(() => {
    if (e)
      return e.flows.map((u) => {
        const s = t[u.flowId], c = (s == null ? void 0 : s.value) ?? u.timeSavedPerRun, f = n.get(u.flowId) ?? 0;
        return {
          ...u,
          id: u.flowId,
          timeSavedPerRun: c,
          runs: f,
          minutesSaved: (c ?? 0) * f
        };
      });
  }, [e, t, n]), a = D.useMemo(() => {
    if (!i) return [];
    const u = /* @__PURE__ */ new Map();
    return i.forEach((s) => {
      s.ownerId && !u.has(s.ownerId) && u.set(s.ownerId, {
        id: s.ownerId,
        name: s.ownerId
      });
    }), Array.from(u.values());
  }, [i]), o = D.useMemo(() => i ? i.filter(
    (u) => u.timeSavedPerRun === null || u.timeSavedPerRun === 0
  ).length : 0, [i]);
  return {
    flowDetails: i,
    uniqueOwners: a,
    flowsMissingTimeSaved: o,
    timeSavedPerRunOverrides: t,
    setTimeSavedPerRunOverride: r
  };
}
function Md({
  flowId: e,
  currentValue: t,
  children: r
}) {
  const { setTimeSavedPerRunOverride: n } = D.useContext(yf), i = D.useRef(t), [a, o] = D.useState(!1), [u, s] = D.useState({ hours: "", mins: "", secs: "" }), c = D.useRef(null), f = D.useRef(null), l = (b) => {
    b && (s(Zw(t)), i.current = t), o(b);
  }, { mutate: d, isPending: p } = yw({
    mutationFn: async (b) => {
      await mw.update(e, {
        type: gw.UPDATE_MINUTES_SAVED,
        request: { timeSavedPerRun: b }
      }), await Yw.markAsOutdated();
    },
    onMutate: async (b) => {
      n(e, b), o(!1);
    },
    onSuccess: () => {
      const b = i.current !== null && i.current !== void 0 && i.current > 0;
      Xc.success(
        b ? U("Time saved updated successfully") : U("Time saved added successfully")
      );
    },
    onError: () => {
      n(e, i.current ?? null), Xc.error(U("Failed to update time saved"));
    }
  }), y = () => {
    d(Qw(u.hours, u.mins, u.secs));
  }, v = (b) => {
    b.key === "Enter" ? y() : b.key === "Escape" && o(!1);
  }, h = (b, x, O, m) => {
    var P, $, M, j;
    const g = b.replace(/\D/g, "");
    if (x === "hours") {
      const E = parseInt(g, 10);
      (g === "" || E >= 0 && E <= O) && s((C) => ({ ...C, hours: g }));
      return;
    }
    if (g === "") {
      s((E) => ({ ...E, [x]: "" }));
      return;
    }
    if (g.length === 1) {
      if (parseInt(g, 10) >= 6) {
        s((C) => ({ ...C, [x]: "0" + g })), (P = m == null ? void 0 : m.current) == null || P.focus(), ($ = m == null ? void 0 : m.current) == null || $.select();
        return;
      }
      s((C) => ({ ...C, [x]: g }));
      return;
    }
    const _ = g.slice(0, 2), A = parseInt(_, 10);
    A >= 0 && A <= O && (s((E) => ({ ...E, [x]: _ })), (M = m == null ? void 0 : m.current) == null || M.focus(), (j = m == null ? void 0 : m.current) == null || j.select());
  }, w = (b) => {
    s((x) => {
      const O = x[b];
      return O.length === 1 ? { ...x, [b]: "0" + O } : x;
    });
  };
  return /* @__PURE__ */ S.jsxs(ca, { open: a, onOpenChange: l, children: [
    /* @__PURE__ */ S.jsx(la, { asChild: !0, children: r }),
    /* @__PURE__ */ S.jsx(fa, { className: "w-[260px] p-4", align: "start", children: /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-4", children: [
      /* @__PURE__ */ S.jsx("div", { className: "text-sm font-semibold", children: U("Time Saved Per Run") }),
      /* @__PURE__ */ S.jsxs("div", { className: "flex items-center rounded-md border border-input bg-background px-3 py-1.5 gap-1 focus-within:ring-1 focus-within:ring-ring", children: [
        /* @__PURE__ */ S.jsx("div", { className: "flex flex-col items-center gap-0.5 flex-1", children: /* @__PURE__ */ S.jsx(
          "input",
          {
            type: "text",
            inputMode: "numeric",
            placeholder: "hh",
            value: u.hours,
            onChange: (b) => h(b.target.value, "hours", 1e3, c),
            onKeyDown: v,
            className: "w-full text-center text-sm bg-transparent outline-none placeholder:text-muted-foreground/50",
            maxLength: 4,
            autoFocus: !0
          }
        ) }),
        /* @__PURE__ */ S.jsx("span", { className: "text-muted-foreground font-medium", children: ":" }),
        /* @__PURE__ */ S.jsx("div", { className: "flex flex-col items-center gap-0.5 flex-1", children: /* @__PURE__ */ S.jsx(
          "input",
          {
            ref: c,
            type: "text",
            inputMode: "numeric",
            placeholder: "mm",
            value: u.mins,
            onChange: (b) => h(b.target.value, "mins", 59, f),
            onBlur: () => w("mins"),
            onKeyDown: v,
            className: "w-full text-center text-sm bg-transparent outline-none placeholder:text-muted-foreground/50",
            maxLength: 2
          }
        ) }),
        /* @__PURE__ */ S.jsx("span", { className: "text-muted-foreground font-medium", children: ":" }),
        /* @__PURE__ */ S.jsx("div", { className: "flex flex-col items-center gap-0.5 flex-1", children: /* @__PURE__ */ S.jsx(
          "input",
          {
            ref: f,
            type: "text",
            inputMode: "numeric",
            placeholder: "ss",
            value: u.secs,
            onChange: (b) => h(b.target.value, "secs", 59, null),
            onBlur: () => w("secs"),
            onKeyDown: v,
            className: "w-full text-center text-sm bg-transparent outline-none placeholder:text-muted-foreground/50",
            maxLength: 2
          }
        ) })
      ] }),
      /* @__PURE__ */ S.jsx("p", { className: "text-xs text-muted-foreground", children: U("How long this task takes without automation.") }),
      /* @__PURE__ */ S.jsxs("div", { className: "flex gap-2 justify-end", children: [
        /* @__PURE__ */ S.jsx(vt, { variant: "ghost", size: "sm", onClick: () => o(!1), children: U("Cancel") }),
        /* @__PURE__ */ S.jsx(vt, { size: "sm", onClick: y, loading: p, children: U("Save") })
      ] })
    ] }) })
  ] });
}
function pO({
  report: e,
  isLoading: t,
  projects: r
}) {
  const {
    flowDetails: n,
    uniqueOwners: i,
    flowsMissingTimeSaved: a,
    timeSavedPerRunOverrides: o
  } = hO(e), u = dO(n, i), s = D.useMemo(
    () => [
      {
        accessorKey: "flowName",
        header: ({ column: c }) => /* @__PURE__ */ S.jsx(Vr, { column: c, title: U("Flow Name") }),
        cell: ({ row: c }) => /* @__PURE__ */ S.jsxs(
          "div",
          {
            className: We(
              "flex items-center gap-3 flex-wrap",
              Zc
            ),
            children: [
              /* @__PURE__ */ S.jsx(Yc, { className: "size-4 mr-2 text-primary shrink-0" }),
              /* @__PURE__ */ S.jsx("span", { className: "truncate", children: c.original.flowName })
            ]
          }
        ),
        size: 300
      },
      {
        accessorKey: "ownerId",
        header: ({ column: c }) => /* @__PURE__ */ S.jsx(Vr, { column: c, title: U("Owner") }),
        cell: ({ row: c }) => /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ S.jsx(
            Qc,
            {
              id: c.original.ownerId ?? "",
              size: "small",
              includeAvatar: !0,
              includeName: !1
            }
          ),
          /* @__PURE__ */ S.jsx(Jc, { id: c.original.ownerId ?? "" })
        ] })
      },
      {
        accessorKey: "timeSavedPerRun",
        header: ({ column: c }) => /* @__PURE__ */ S.jsx(
          Vr,
          {
            column: c,
            title: U("Time Saved Per Run"),
            sortable: !0
          }
        ),
        cell: ({ row: c }) => {
          const f = o == null ? void 0 : o[c.original.flowId], l = (f == null ? void 0 : f.value) ?? c.original.timeSavedPerRun, d = l && l > 0, p = d ? pn.formatToHoursAndMinutes(l) : null;
          return (r == null ? void 0 : r.some(
            (v) => v.id === c.original.projectId
          )) ? d ? /* @__PURE__ */ S.jsxs("div", { className: "group/cell flex items-center gap-1.5", children: [
            /* @__PURE__ */ S.jsx("span", { children: p }),
            /* @__PURE__ */ S.jsx("span", { className: "inline-flex opacity-0 group-hover/cell:opacity-100 transition-opacity", children: /* @__PURE__ */ S.jsx(
              Md,
              {
                flowId: c.original.flowId,
                currentValue: l,
                children: /* @__PURE__ */ S.jsxs(vt, { variant: "link", size: "xs", children: [
                  /* @__PURE__ */ S.jsx(bw, { className: "size-3! mr-1" }),
                  /* @__PURE__ */ S.jsx("span", { children: U("Edit") })
                ] })
              }
            ) })
          ] }) : /* @__PURE__ */ S.jsx(
            Md,
            {
              flowId: c.original.flowId,
              currentValue: l,
              children: /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-1.5 cursor-pointer text-primary hover:underline", children: [
                /* @__PURE__ */ S.jsx(Sd, { className: "h-3.5 w-3.5" }),
                /* @__PURE__ */ S.jsx("span", { children: U("Add Estimated Time") })
              ] })
            }
          ) : /* @__PURE__ */ S.jsxs(pr, { children: [
            /* @__PURE__ */ S.jsx(vr, { asChild: !0, children: /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-1.5 text-muted-foreground cursor-not-allowed", children: [
              /* @__PURE__ */ S.jsx(Sd, { className: "h-3.5 w-3.5" }),
              /* @__PURE__ */ S.jsx("span", { children: U("Add Estimated Time") })
            ] }) }),
            /* @__PURE__ */ S.jsx(yr, { side: "top", children: U("You don't have permission to add") })
          ] });
        }
      },
      {
        accessorKey: "minutesSaved",
        header: ({ column: c }) => /* @__PURE__ */ S.jsx(
          Vr,
          {
            column: c,
            title: U("Total Time Saved"),
            sortable: !0
          }
        ),
        cell: ({ row: c }) => /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ S.jsx(vn, { className: "h-3.5 w-3.5" }),
          /* @__PURE__ */ S.jsx("span", { children: pn.formatToHoursAndMinutes(c.original.minutesSaved) })
        ] })
      },
      {
        accessorKey: "projectName",
        header: ({ column: c }) => /* @__PURE__ */ S.jsx(Vr, { column: c, title: U("Project Name") }),
        cell: ({ row: c }) => {
          const f = r == null ? void 0 : r.find(
            (y) => y.id === c.original.projectId
          ), l = !!f, d = (f == null ? void 0 : f.displayName) ?? c.original.projectName, p = (f == null ? void 0 : f.type) === Kc.TEAM ? /* @__PURE__ */ S.jsx(
            Gc,
            {
              className: "size-5 shrink-0 flex items-center justify-center rounded-[4px] text-xs font-bold",
              style: {
                backgroundColor: ur[f.icon.color].color,
                color: ur[f.icon.color].textColor
              },
              children: /* @__PURE__ */ S.jsx("span", { className: "scale-75", children: d.charAt(0).toUpperCase() })
            }
          ) : /* @__PURE__ */ S.jsx(Vc, { className: "h-4 w-4 shrink-0" });
          return l ? /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-1.5 text-foreground", children: [
            p,
            d
          ] }) : /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-1.5 text-muted-foreground", children: [
            p,
            d
          ] });
        }
      }
    ],
    [r, o]
  );
  return !n && !t ? null : /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-4", children: [
    /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-3 flex-wrap", children: [
      /* @__PURE__ */ S.jsxs("div", { className: "relative w-[200px]", children: [
        /* @__PURE__ */ S.jsx(eb, { className: "absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ S.jsx(
          tb,
          {
            placeholder: U("Search flows"),
            value: u.searchQuery,
            onChange: (c) => u.setSearchQuery(c.target.value),
            className: "pl-9 pr-8"
          }
        ),
        u.searchQuery && /* @__PURE__ */ S.jsx(
          "button",
          {
            onClick: () => u.setSearchQuery(""),
            className: "absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground",
            children: /* @__PURE__ */ S.jsx(xw, { className: "h-3.5 w-3.5" })
          }
        )
      ] }),
      /* @__PURE__ */ S.jsx(vO, { filters: u }),
      /* @__PURE__ */ S.jsx(yO, { filters: u }),
      /* @__PURE__ */ S.jsx("div", { className: "flex-1" }),
      /* @__PURE__ */ S.jsxs(pr, { children: [
        /* @__PURE__ */ S.jsx(vr, { asChild: !0, children: /* @__PURE__ */ S.jsxs(
          vt,
          {
            variant: "outline",
            size: "sm",
            onClick: () => Jw([...u.filteredData]),
            disabled: u.filteredData.length === 0,
            children: [
              /* @__PURE__ */ S.jsx(rb, { className: "h-4 w-4 mr-2" }),
              U("Download")
            ]
          }
        ) }),
        /* @__PURE__ */ S.jsx(yr, { children: U("Download flows details") })
      ] })
    ] }),
    a > 0 && /* @__PURE__ */ S.jsx("div", { className: "flex mx-3 items-start justify-between gap-3 p-4 rounded-lg border border-warning/50 bg-warning/10", children: /* @__PURE__ */ S.jsxs("div", { className: "flex items-start gap-3", children: [
      /* @__PURE__ */ S.jsx(ww, { className: "h-5 w-5 text-warning shrink-0 mt-0.5" }),
      /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-1", children: [
        /* @__PURE__ */ S.jsx("p", { className: "text-sm font-medium", children: U(
          "There are {count} flows missing their Estimated Time Per Run.",
          { count: a }
        ) }),
        /* @__PURE__ */ S.jsx("p", { className: "text-sm text-muted-foreground", children: U("This will cause inaccurate analytics and unreliable data.") })
      ] })
    ] }) }),
    /* @__PURE__ */ S.jsx(
      Ow,
      {
        columns: s,
        page: {
          data: u.filteredData,
          next: null,
          previous: null
        },
        isLoading: t,
        clientPagination: !0,
        initialSorting: [{ id: "minutesSaved", desc: !0 }],
        emptyStateTextTitle: U("No Flows Found"),
        emptyStateTextDescription: u.searchQuery ? U("Try adjusting your search") : U("Start running your flows to see time saved"),
        emptyStateIcon: /* @__PURE__ */ S.jsx(Yc, { className: "h-10 w-10 text-muted-foreground" })
      }
    )
  ] });
}
function vO({ filters: e }) {
  return /* @__PURE__ */ S.jsxs(
    ca,
    {
      open: e.timeSavedPopoverOpen,
      onOpenChange: e.handleTimeSavedPopoverOpen,
      children: [
        /* @__PURE__ */ S.jsx(la, { asChild: !0, children: /* @__PURE__ */ S.jsxs(vt, { variant: "outline", className: "gap-2 font-normal border-dashed", children: [
          /* @__PURE__ */ S.jsx(vn, { className: "h-4 w-4" }),
          /* @__PURE__ */ S.jsx("span", { children: U("Total Time Saved") }),
          e.timeSavedLabel && /* @__PURE__ */ S.jsx("span", { className: "rounded bg-accent px-1.5 py-0.5 text-xs font-medium", children: e.timeSavedLabel }),
          /* @__PURE__ */ S.jsx(vf, { className: "h-4 w-4 opacity-50" })
        ] }) }),
        /* @__PURE__ */ S.jsx(fa, { className: "w-[200px] p-4", align: "start", children: /* @__PURE__ */ S.jsx(
          eO,
          {
            draftMin: e.draftTimeSaved.min,
            onMinChange: (t) => e.updateDraftTimeSaved({ min: t }),
            unitMin: e.draftTimeSaved.unitMin,
            onCycleUnitMin: e.cycleDraftTimeUnitMin,
            draftMax: e.draftTimeSaved.max,
            onMaxChange: (t) => e.updateDraftTimeSaved({ max: t }),
            unitMax: e.draftTimeSaved.unitMax,
            onCycleUnitMax: e.cycleDraftTimeUnitMax,
            onApply: e.applyTimeSavedFilter
          }
        ) })
      ]
    }
  );
}
function yO({ filters: e }) {
  return /* @__PURE__ */ S.jsxs(
    ca,
    {
      open: e.ownerFilter.popoverOpen,
      onOpenChange: (t) => e.updateOwnerFilter({ popoverOpen: t }),
      children: [
        /* @__PURE__ */ S.jsx(la, { asChild: !0, children: /* @__PURE__ */ S.jsxs(vt, { variant: "outline", className: "gap-2 font-normal border-dashed", children: [
          /* @__PURE__ */ S.jsx(Sw, { className: "h-4 w-4" }),
          /* @__PURE__ */ S.jsx("span", { children: U("Owner") }),
          e.selectedOwners.length > 0 && /* @__PURE__ */ S.jsxs("span", { className: "flex items-center gap-1", children: [
            e.selectedOwners.slice(0, 2).map((t) => /* @__PURE__ */ S.jsxs(
              "span",
              {
                className: "flex items-center gap-1 rounded bg-accent px-1.5 py-0.5 text-xs font-medium",
                children: [
                  /* @__PURE__ */ S.jsx(Qc, { id: t.id, size: "xsmall", hideHover: !0 }),
                  /* @__PURE__ */ S.jsx(Jc, { id: t.id, maxWidth: "max-w-[80px]" })
                ]
              },
              t.id
            )),
            e.selectedOwners.length > 2 && /* @__PURE__ */ S.jsxs("span", { className: "rounded bg-accent px-1.5 py-0.5 text-xs font-medium", children: [
              "+",
              e.selectedOwners.length - 2
            ] })
          ] }),
          /* @__PURE__ */ S.jsx(vf, { className: "h-4 w-4 opacity-50" })
        ] }) }),
        /* @__PURE__ */ S.jsxs(fa, { className: "w-[240px] p-0", align: "start", children: [
          /* @__PURE__ */ S.jsx("div", { className: "p-2 border-b", children: /* @__PURE__ */ S.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ S.jsx(eb, { className: "absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
            /* @__PURE__ */ S.jsx(
              tb,
              {
                placeholder: U("Search owners..."),
                value: e.ownerFilter.searchQuery,
                onChange: (t) => e.updateOwnerFilter({ searchQuery: t.target.value }),
                className: "pl-8 h-8"
              }
            )
          ] }) }),
          /* @__PURE__ */ S.jsxs("div", { className: "max-h-[220px] overflow-auto", children: [
            e.filteredOwners.map((t) => /* @__PURE__ */ S.jsxs(
              "div",
              {
                onClick: () => e.toggleOwner(t.id),
                className: "flex items-center gap-2.5 px-3 py-2 text-sm cursor-pointer hover:bg-accent",
                children: [
                  /* @__PURE__ */ S.jsx(
                    Aw,
                    {
                      checked: e.ownerFilter.selectedIds.includes(t.id),
                      className: "pointer-events-none"
                    }
                  ),
                  /* @__PURE__ */ S.jsx(Qc, { id: t.id, size: "small", hideHover: !0 }),
                  /* @__PURE__ */ S.jsx(Jc, { id: t.id })
                ]
              },
              t.id
            )),
            e.filteredOwners.length === 0 && /* @__PURE__ */ S.jsx("div", { className: "py-6 text-center text-sm text-muted-foreground", children: U("No owners found") })
          ] }),
          e.ownerFilter.selectedIds.length > 0 && /* @__PURE__ */ S.jsx("div", { className: "p-2 border-t", children: /* @__PURE__ */ S.jsx(
            "button",
            {
              onClick: () => e.updateOwnerFilter({ selectedIds: [] }),
              className: "w-full text-center text-sm text-primary hover:underline",
              children: U("Clear all")
            }
          ) })
        ] })
      ]
    }
  );
}
function Jc({
  id: e,
  maxWidth: t = "max-w-[120px]"
}) {
  const { data: r } = _w.useUserById(e);
  return /* @__PURE__ */ S.jsx("span", { className: `truncate ${t}`, children: r ? `${r.firstName} ${r.lastName}`.trim() : e });
}
const yn = ({
  icon: e,
  title: t,
  value: r,
  description: n,
  subtitle: i,
  iconColor: a,
  iconBgColor: o
}) => /* @__PURE__ */ S.jsx(mf, { className: "p-5", children: /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-3", children: [
  /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ S.jsx("span", { className: "text-sm font-medium text-muted-foreground", children: t }),
    /* @__PURE__ */ S.jsxs(pr, { children: [
      /* @__PURE__ */ S.jsx(vr, { asChild: !0, children: /* @__PURE__ */ S.jsx(nb, { className: "h-3.5 w-3.5 text-muted-foreground/70 cursor-help" }) }),
      /* @__PURE__ */ S.jsx(yr, { className: "max-w-xs", children: n })
    ] }),
    /* @__PURE__ */ S.jsx(
      "div",
      {
        className: `size-8 rounded-full ${o} flex items-center justify-center shrink-0 ml-auto`,
        children: /* @__PURE__ */ S.jsx(e, { className: `size-4 ${a}` })
      }
    )
  ] }),
  /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-1", children: [
    /* @__PURE__ */ S.jsx("div", { className: "text-2xl font-semibold text-foreground", children: r }),
    i && /* @__PURE__ */ S.jsx("div", { className: "text-sm text-muted-foreground", children: i })
  ] })
] }) }), da = () => /* @__PURE__ */ S.jsx(mf, { className: "p-5", children: /* @__PURE__ */ S.jsxs("div", { className: "flex items-start justify-between", children: [
  /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-3", children: [
    /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-1.5", children: [
      /* @__PURE__ */ S.jsx(or, { className: "h-4 w-24" }),
      /* @__PURE__ */ S.jsx(or, { className: "h-3.5 w-3.5 rounded-full" })
    ] }),
    /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-1", children: [
      /* @__PURE__ */ S.jsx(or, { className: "h-8 w-28" }),
      /* @__PURE__ */ S.jsx(or, { className: "h-4 w-36" })
    ] })
  ] }),
  /* @__PURE__ */ S.jsx(or, { className: "size-9 rounded-full shrink-0" })
] }) }), mO = ({ report: e }) => {
  if (!e)
    return /* @__PURE__ */ S.jsx(da, {});
  const t = e.flows.filter(
    (n) => n.status === Pw.ENABLED
  ).length, r = e.flows.length;
  return /* @__PURE__ */ S.jsx(
    yn,
    {
      icon: Yc,
      title: U("Active Flows"),
      value: t.toLocaleString(),
      description: U("Number of currently active flows"),
      subtitle: U("{total} total flows created", {
        total: r.toLocaleString()
      }),
      iconColor: "text-purple-500",
      iconBgColor: "bg-purple-500/10"
    }
  );
}, gO = ({ report: e }) => {
  if (!e)
    return /* @__PURE__ */ S.jsx(da, {});
  const t = e.users.filter(
    (i) => i.status === Tw.ACTIVE
  ).length, r = e.users.length, n = r > 0 ? Math.round(t / r * 100) : 0;
  return /* @__PURE__ */ S.jsx(
    yn,
    {
      icon: jw,
      title: U("Active Users"),
      value: t.toLocaleString(),
      description: U("Users actively using the platform"),
      subtitle: U("{rate}% adoption rate ({total} total users)", {
        rate: n,
        total: r.toLocaleString()
      }),
      iconColor: "text-amber-500",
      iconBgColor: "bg-amber-500/10"
    }
  );
}, bO = ({ report: e }) => {
  if (!e)
    return /* @__PURE__ */ S.jsx(da, {});
  const t = e.flows.reduce(
    (r, n) => {
      var i;
      return r + (((i = e == null ? void 0 : e.runs.find((a) => a.flowId === n.flowId)) == null ? void 0 : i.runs) ?? 0);
    },
    0
  );
  return /* @__PURE__ */ S.jsx(
    yn,
    {
      icon: Ew,
      title: U("Automation Runs"),
      value: t.toLocaleString(),
      description: U("Total automation executions"),
      iconColor: "text-rose-500",
      iconBgColor: "bg-rose-500/10"
    }
  );
}, xO = ({
  report: e,
  isLoading: t
}) => {
  const n = ((e == null ? void 0 : e.flows) ?? []).filter(
    (s) => s.timeSavedPerRun !== null && s.timeSavedPerRun !== void 0 && s.timeSavedPerRun !== 0
  ), i = n.length > 0, a = i ? n.reduce((s, c) => {
    const f = (e == null ? void 0 : e.runs.filter((l) => l.flowId === c.flowId).reduce((l, d) => l + (d.runs ?? 0), 0)) ?? 0;
    return s + (c.timeSavedPerRun ?? 0) * f;
  }, 0) : 0, o = Math.round(a / 60), u = Math.round(a / 3600 / 8);
  return t ? /* @__PURE__ */ S.jsx(da, {}) : i ? /* @__PURE__ */ S.jsx(
    yn,
    {
      icon: vn,
      title: U("Time Saved"),
      value: `${pn.formatNumber(o)} mins`,
      description: U("Total time saved by automation"),
      subtitle: U("{days} workdays saved", {
        days: u.toLocaleString()
      }),
      iconColor: "text-success",
      iconBgColor: "bg-success/10"
    }
  ) : /* @__PURE__ */ S.jsx(
    yn,
    {
      icon: vn,
      title: U("Time Saved"),
      value: "N/A",
      description: U(
        "Estimated hours saved through automation in the last 3 months. Each automated task saves valuable employee time that can be redirected to high-impact work."
      ),
      subtitle: U("{days} workdays saved", {
        days: "N/A"
      }),
      iconColor: "text-emerald-500",
      iconBgColor: "bg-emerald-500/10"
    }
  );
};
function wO({ report: e }) {
  const t = !e;
  return /* @__PURE__ */ S.jsx("div", { children: /* @__PURE__ */ S.jsxs("div", { className: "mt-2 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4", children: [
    /* @__PURE__ */ S.jsx(xO, { isLoading: t, report: e }),
    /* @__PURE__ */ S.jsx(mO, { report: e }),
    /* @__PURE__ */ S.jsx(gO, { report: e }),
    /* @__PURE__ */ S.jsx(bO, { report: e })
  ] }) });
}
var Ga, Cd;
function ke() {
  if (Cd) return Ga;
  Cd = 1;
  var e = Array.isArray;
  return Ga = e, Ga;
}
var Va, Id;
function ib() {
  if (Id) return Va;
  Id = 1;
  var e = typeof ii == "object" && ii && ii.Object === Object && ii;
  return Va = e, Va;
}
var Xa, $d;
function ut() {
  if ($d) return Xa;
  $d = 1;
  var e = ib(), t = typeof self == "object" && self && self.Object === Object && self, r = e || t || Function("return this")();
  return Xa = r, Xa;
}
var Ya, Nd;
function Yn() {
  if (Nd) return Ya;
  Nd = 1;
  var e = ut(), t = e.Symbol;
  return Ya = t, Ya;
}
var Za, kd;
function OO() {
  if (kd) return Za;
  kd = 1;
  var e = Yn(), t = Object.prototype, r = t.hasOwnProperty, n = t.toString, i = e ? e.toStringTag : void 0;
  function a(o) {
    var u = r.call(o, i), s = o[i];
    try {
      o[i] = void 0;
      var c = !0;
    } catch {
    }
    var f = n.call(o);
    return c && (u ? o[i] = s : delete o[i]), f;
  }
  return Za = a, Za;
}
var Qa, Dd;
function _O() {
  if (Dd) return Qa;
  Dd = 1;
  var e = Object.prototype, t = e.toString;
  function r(n) {
    return t.call(n);
  }
  return Qa = r, Qa;
}
var Ja, Rd;
function xt() {
  if (Rd) return Ja;
  Rd = 1;
  var e = Yn(), t = OO(), r = _O(), n = "[object Null]", i = "[object Undefined]", a = e ? e.toStringTag : void 0;
  function o(u) {
    return u == null ? u === void 0 ? i : n : a && a in Object(u) ? t(u) : r(u);
  }
  return Ja = o, Ja;
}
var eo, Ld;
function wt() {
  if (Ld) return eo;
  Ld = 1;
  function e(t) {
    return t != null && typeof t == "object";
  }
  return eo = e, eo;
}
var to, qd;
function Br() {
  if (qd) return to;
  qd = 1;
  var e = xt(), t = wt(), r = "[object Symbol]";
  function n(i) {
    return typeof i == "symbol" || t(i) && e(i) == r;
  }
  return to = n, to;
}
var ro, Bd;
function bf() {
  if (Bd) return ro;
  Bd = 1;
  var e = ke(), t = Br(), r = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, n = /^\w*$/;
  function i(a, o) {
    if (e(a))
      return !1;
    var u = typeof a;
    return u == "number" || u == "symbol" || u == "boolean" || a == null || t(a) ? !0 : n.test(a) || !r.test(a) || o != null && a in Object(o);
  }
  return ro = i, ro;
}
var no, Fd;
function Ct() {
  if (Fd) return no;
  Fd = 1;
  function e(t) {
    var r = typeof t;
    return t != null && (r == "object" || r == "function");
  }
  return no = e, no;
}
var io, zd;
function xf() {
  if (zd) return io;
  zd = 1;
  var e = xt(), t = Ct(), r = "[object AsyncFunction]", n = "[object Function]", i = "[object GeneratorFunction]", a = "[object Proxy]";
  function o(u) {
    if (!t(u))
      return !1;
    var s = e(u);
    return s == n || s == i || s == r || s == a;
  }
  return io = o, io;
}
var ao, Ud;
function SO() {
  if (Ud) return ao;
  Ud = 1;
  var e = ut(), t = e["__core-js_shared__"];
  return ao = t, ao;
}
var oo, Wd;
function AO() {
  if (Wd) return oo;
  Wd = 1;
  var e = SO(), t = function() {
    var n = /[^.]+$/.exec(e && e.keys && e.keys.IE_PROTO || "");
    return n ? "Symbol(src)_1." + n : "";
  }();
  function r(n) {
    return !!t && t in n;
  }
  return oo = r, oo;
}
var uo, Hd;
function ab() {
  if (Hd) return uo;
  Hd = 1;
  var e = Function.prototype, t = e.toString;
  function r(n) {
    if (n != null) {
      try {
        return t.call(n);
      } catch {
      }
      try {
        return n + "";
      } catch {
      }
    }
    return "";
  }
  return uo = r, uo;
}
var so, Kd;
function PO() {
  if (Kd) return so;
  Kd = 1;
  var e = xf(), t = AO(), r = Ct(), n = ab(), i = /[\\^$.*+?()[\]{}|]/g, a = /^\[object .+?Constructor\]$/, o = Function.prototype, u = Object.prototype, s = o.toString, c = u.hasOwnProperty, f = RegExp(
    "^" + s.call(c).replace(i, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
  );
  function l(d) {
    if (!r(d) || t(d))
      return !1;
    var p = e(d) ? f : a;
    return p.test(n(d));
  }
  return so = l, so;
}
var co, Gd;
function TO() {
  if (Gd) return co;
  Gd = 1;
  function e(t, r) {
    return t == null ? void 0 : t[r];
  }
  return co = e, co;
}
var lo, Vd;
function Qt() {
  if (Vd) return lo;
  Vd = 1;
  var e = PO(), t = TO();
  function r(n, i) {
    var a = t(n, i);
    return e(a) ? a : void 0;
  }
  return lo = r, lo;
}
var fo, Xd;
function ha() {
  if (Xd) return fo;
  Xd = 1;
  var e = Qt(), t = e(Object, "create");
  return fo = t, fo;
}
var ho, Yd;
function jO() {
  if (Yd) return ho;
  Yd = 1;
  var e = ha();
  function t() {
    this.__data__ = e ? e(null) : {}, this.size = 0;
  }
  return ho = t, ho;
}
var po, Zd;
function EO() {
  if (Zd) return po;
  Zd = 1;
  function e(t) {
    var r = this.has(t) && delete this.__data__[t];
    return this.size -= r ? 1 : 0, r;
  }
  return po = e, po;
}
var vo, Qd;
function MO() {
  if (Qd) return vo;
  Qd = 1;
  var e = ha(), t = "__lodash_hash_undefined__", r = Object.prototype, n = r.hasOwnProperty;
  function i(a) {
    var o = this.__data__;
    if (e) {
      var u = o[a];
      return u === t ? void 0 : u;
    }
    return n.call(o, a) ? o[a] : void 0;
  }
  return vo = i, vo;
}
var yo, Jd;
function CO() {
  if (Jd) return yo;
  Jd = 1;
  var e = ha(), t = Object.prototype, r = t.hasOwnProperty;
  function n(i) {
    var a = this.__data__;
    return e ? a[i] !== void 0 : r.call(a, i);
  }
  return yo = n, yo;
}
var mo, eh;
function IO() {
  if (eh) return mo;
  eh = 1;
  var e = ha(), t = "__lodash_hash_undefined__";
  function r(n, i) {
    var a = this.__data__;
    return this.size += this.has(n) ? 0 : 1, a[n] = e && i === void 0 ? t : i, this;
  }
  return mo = r, mo;
}
var go, th;
function $O() {
  if (th) return go;
  th = 1;
  var e = jO(), t = EO(), r = MO(), n = CO(), i = IO();
  function a(o) {
    var u = -1, s = o == null ? 0 : o.length;
    for (this.clear(); ++u < s; ) {
      var c = o[u];
      this.set(c[0], c[1]);
    }
  }
  return a.prototype.clear = e, a.prototype.delete = t, a.prototype.get = r, a.prototype.has = n, a.prototype.set = i, go = a, go;
}
var bo, rh;
function NO() {
  if (rh) return bo;
  rh = 1;
  function e() {
    this.__data__ = [], this.size = 0;
  }
  return bo = e, bo;
}
var xo, nh;
function wf() {
  if (nh) return xo;
  nh = 1;
  function e(t, r) {
    return t === r || t !== t && r !== r;
  }
  return xo = e, xo;
}
var wo, ih;
function pa() {
  if (ih) return wo;
  ih = 1;
  var e = wf();
  function t(r, n) {
    for (var i = r.length; i--; )
      if (e(r[i][0], n))
        return i;
    return -1;
  }
  return wo = t, wo;
}
var Oo, ah;
function kO() {
  if (ah) return Oo;
  ah = 1;
  var e = pa(), t = Array.prototype, r = t.splice;
  function n(i) {
    var a = this.__data__, o = e(a, i);
    if (o < 0)
      return !1;
    var u = a.length - 1;
    return o == u ? a.pop() : r.call(a, o, 1), --this.size, !0;
  }
  return Oo = n, Oo;
}
var _o, oh;
function DO() {
  if (oh) return _o;
  oh = 1;
  var e = pa();
  function t(r) {
    var n = this.__data__, i = e(n, r);
    return i < 0 ? void 0 : n[i][1];
  }
  return _o = t, _o;
}
var So, uh;
function RO() {
  if (uh) return So;
  uh = 1;
  var e = pa();
  function t(r) {
    return e(this.__data__, r) > -1;
  }
  return So = t, So;
}
var Ao, sh;
function LO() {
  if (sh) return Ao;
  sh = 1;
  var e = pa();
  function t(r, n) {
    var i = this.__data__, a = e(i, r);
    return a < 0 ? (++this.size, i.push([r, n])) : i[a][1] = n, this;
  }
  return Ao = t, Ao;
}
var Po, ch;
function va() {
  if (ch) return Po;
  ch = 1;
  var e = NO(), t = kO(), r = DO(), n = RO(), i = LO();
  function a(o) {
    var u = -1, s = o == null ? 0 : o.length;
    for (this.clear(); ++u < s; ) {
      var c = o[u];
      this.set(c[0], c[1]);
    }
  }
  return a.prototype.clear = e, a.prototype.delete = t, a.prototype.get = r, a.prototype.has = n, a.prototype.set = i, Po = a, Po;
}
var To, lh;
function Of() {
  if (lh) return To;
  lh = 1;
  var e = Qt(), t = ut(), r = e(t, "Map");
  return To = r, To;
}
var jo, fh;
function qO() {
  if (fh) return jo;
  fh = 1;
  var e = $O(), t = va(), r = Of();
  function n() {
    this.size = 0, this.__data__ = {
      hash: new e(),
      map: new (r || t)(),
      string: new e()
    };
  }
  return jo = n, jo;
}
var Eo, dh;
function BO() {
  if (dh) return Eo;
  dh = 1;
  function e(t) {
    var r = typeof t;
    return r == "string" || r == "number" || r == "symbol" || r == "boolean" ? t !== "__proto__" : t === null;
  }
  return Eo = e, Eo;
}
var Mo, hh;
function ya() {
  if (hh) return Mo;
  hh = 1;
  var e = BO();
  function t(r, n) {
    var i = r.__data__;
    return e(n) ? i[typeof n == "string" ? "string" : "hash"] : i.map;
  }
  return Mo = t, Mo;
}
var Co, ph;
function FO() {
  if (ph) return Co;
  ph = 1;
  var e = ya();
  function t(r) {
    var n = e(this, r).delete(r);
    return this.size -= n ? 1 : 0, n;
  }
  return Co = t, Co;
}
var Io, vh;
function zO() {
  if (vh) return Io;
  vh = 1;
  var e = ya();
  function t(r) {
    return e(this, r).get(r);
  }
  return Io = t, Io;
}
var $o, yh;
function UO() {
  if (yh) return $o;
  yh = 1;
  var e = ya();
  function t(r) {
    return e(this, r).has(r);
  }
  return $o = t, $o;
}
var No, mh;
function WO() {
  if (mh) return No;
  mh = 1;
  var e = ya();
  function t(r, n) {
    var i = e(this, r), a = i.size;
    return i.set(r, n), this.size += i.size == a ? 0 : 1, this;
  }
  return No = t, No;
}
var ko, gh;
function _f() {
  if (gh) return ko;
  gh = 1;
  var e = qO(), t = FO(), r = zO(), n = UO(), i = WO();
  function a(o) {
    var u = -1, s = o == null ? 0 : o.length;
    for (this.clear(); ++u < s; ) {
      var c = o[u];
      this.set(c[0], c[1]);
    }
  }
  return a.prototype.clear = e, a.prototype.delete = t, a.prototype.get = r, a.prototype.has = n, a.prototype.set = i, ko = a, ko;
}
var Do, bh;
function ob() {
  if (bh) return Do;
  bh = 1;
  var e = _f(), t = "Expected a function";
  function r(n, i) {
    if (typeof n != "function" || i != null && typeof i != "function")
      throw new TypeError(t);
    var a = function() {
      var o = arguments, u = i ? i.apply(this, o) : o[0], s = a.cache;
      if (s.has(u))
        return s.get(u);
      var c = n.apply(this, o);
      return a.cache = s.set(u, c) || s, c;
    };
    return a.cache = new (r.Cache || e)(), a;
  }
  return r.Cache = e, Do = r, Do;
}
var Ro, xh;
function HO() {
  if (xh) return Ro;
  xh = 1;
  var e = ob(), t = 500;
  function r(n) {
    var i = e(n, function(o) {
      return a.size === t && a.clear(), o;
    }), a = i.cache;
    return i;
  }
  return Ro = r, Ro;
}
var Lo, wh;
function KO() {
  if (wh) return Lo;
  wh = 1;
  var e = HO(), t = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, r = /\\(\\)?/g, n = e(function(i) {
    var a = [];
    return i.charCodeAt(0) === 46 && a.push(""), i.replace(t, function(o, u, s, c) {
      a.push(s ? c.replace(r, "$1") : u || o);
    }), a;
  });
  return Lo = n, Lo;
}
var qo, Oh;
function Sf() {
  if (Oh) return qo;
  Oh = 1;
  function e(t, r) {
    for (var n = -1, i = t == null ? 0 : t.length, a = Array(i); ++n < i; )
      a[n] = r(t[n], n, t);
    return a;
  }
  return qo = e, qo;
}
var Bo, _h;
function GO() {
  if (_h) return Bo;
  _h = 1;
  var e = Yn(), t = Sf(), r = ke(), n = Br(), i = e ? e.prototype : void 0, a = i ? i.toString : void 0;
  function o(u) {
    if (typeof u == "string")
      return u;
    if (r(u))
      return t(u, o) + "";
    if (n(u))
      return a ? a.call(u) : "";
    var s = u + "";
    return s == "0" && 1 / u == -1 / 0 ? "-0" : s;
  }
  return Bo = o, Bo;
}
var Fo, Sh;
function ub() {
  if (Sh) return Fo;
  Sh = 1;
  var e = GO();
  function t(r) {
    return r == null ? "" : e(r);
  }
  return Fo = t, Fo;
}
var zo, Ah;
function sb() {
  if (Ah) return zo;
  Ah = 1;
  var e = ke(), t = bf(), r = KO(), n = ub();
  function i(a, o) {
    return e(a) ? a : t(a, o) ? [a] : r(n(a));
  }
  return zo = i, zo;
}
var Uo, Ph;
function ma() {
  if (Ph) return Uo;
  Ph = 1;
  var e = Br();
  function t(r) {
    if (typeof r == "string" || e(r))
      return r;
    var n = r + "";
    return n == "0" && 1 / r == -1 / 0 ? "-0" : n;
  }
  return Uo = t, Uo;
}
var Wo, Th;
function Af() {
  if (Th) return Wo;
  Th = 1;
  var e = sb(), t = ma();
  function r(n, i) {
    i = e(i, n);
    for (var a = 0, o = i.length; n != null && a < o; )
      n = n[t(i[a++])];
    return a && a == o ? n : void 0;
  }
  return Wo = r, Wo;
}
var Ho, jh;
function cb() {
  if (jh) return Ho;
  jh = 1;
  var e = Af();
  function t(r, n, i) {
    var a = r == null ? void 0 : e(r, n);
    return a === void 0 ? i : a;
  }
  return Ho = t, Ho;
}
var VO = cb();
const Ge = /* @__PURE__ */ ce(VO);
var Ko, Eh;
function XO() {
  if (Eh) return Ko;
  Eh = 1;
  function e(t) {
    return t == null;
  }
  return Ko = e, Ko;
}
var YO = XO();
const ee = /* @__PURE__ */ ce(YO);
var Go, Mh;
function ZO() {
  if (Mh) return Go;
  Mh = 1;
  var e = xt(), t = ke(), r = wt(), n = "[object String]";
  function i(a) {
    return typeof a == "string" || !t(a) && r(a) && e(a) == n;
  }
  return Go = i, Go;
}
var QO = ZO();
const Gt = /* @__PURE__ */ ce(QO);
var JO = xf();
const Z = /* @__PURE__ */ ce(JO);
var e1 = Ct();
const Fr = /* @__PURE__ */ ce(e1);
var Vo = { exports: {} }, ie = {};
/**
 * @license React
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Ch;
function t1() {
  if (Ch) return ie;
  Ch = 1;
  var e = Symbol.for("react.element"), t = Symbol.for("react.portal"), r = Symbol.for("react.fragment"), n = Symbol.for("react.strict_mode"), i = Symbol.for("react.profiler"), a = Symbol.for("react.provider"), o = Symbol.for("react.context"), u = Symbol.for("react.server_context"), s = Symbol.for("react.forward_ref"), c = Symbol.for("react.suspense"), f = Symbol.for("react.suspense_list"), l = Symbol.for("react.memo"), d = Symbol.for("react.lazy"), p = Symbol.for("react.offscreen"), y;
  y = Symbol.for("react.module.reference");
  function v(h) {
    if (typeof h == "object" && h !== null) {
      var w = h.$$typeof;
      switch (w) {
        case e:
          switch (h = h.type, h) {
            case r:
            case i:
            case n:
            case c:
            case f:
              return h;
            default:
              switch (h = h && h.$$typeof, h) {
                case u:
                case o:
                case s:
                case d:
                case l:
                case a:
                  return h;
                default:
                  return w;
              }
          }
        case t:
          return w;
      }
    }
  }
  return ie.ContextConsumer = o, ie.ContextProvider = a, ie.Element = e, ie.ForwardRef = s, ie.Fragment = r, ie.Lazy = d, ie.Memo = l, ie.Portal = t, ie.Profiler = i, ie.StrictMode = n, ie.Suspense = c, ie.SuspenseList = f, ie.isAsyncMode = function() {
    return !1;
  }, ie.isConcurrentMode = function() {
    return !1;
  }, ie.isContextConsumer = function(h) {
    return v(h) === o;
  }, ie.isContextProvider = function(h) {
    return v(h) === a;
  }, ie.isElement = function(h) {
    return typeof h == "object" && h !== null && h.$$typeof === e;
  }, ie.isForwardRef = function(h) {
    return v(h) === s;
  }, ie.isFragment = function(h) {
    return v(h) === r;
  }, ie.isLazy = function(h) {
    return v(h) === d;
  }, ie.isMemo = function(h) {
    return v(h) === l;
  }, ie.isPortal = function(h) {
    return v(h) === t;
  }, ie.isProfiler = function(h) {
    return v(h) === i;
  }, ie.isStrictMode = function(h) {
    return v(h) === n;
  }, ie.isSuspense = function(h) {
    return v(h) === c;
  }, ie.isSuspenseList = function(h) {
    return v(h) === f;
  }, ie.isValidElementType = function(h) {
    return typeof h == "string" || typeof h == "function" || h === r || h === i || h === n || h === c || h === f || h === p || typeof h == "object" && h !== null && (h.$$typeof === d || h.$$typeof === l || h.$$typeof === a || h.$$typeof === o || h.$$typeof === s || h.$$typeof === y || h.getModuleId !== void 0);
  }, ie.typeOf = v, ie;
}
var Ih;
function r1() {
  return Ih || (Ih = 1, Vo.exports = t1()), Vo.exports;
}
var n1 = r1(), Xo, $h;
function lb() {
  if ($h) return Xo;
  $h = 1;
  var e = xt(), t = wt(), r = "[object Number]";
  function n(i) {
    return typeof i == "number" || t(i) && e(i) == r;
  }
  return Xo = n, Xo;
}
var Yo, Nh;
function i1() {
  if (Nh) return Yo;
  Nh = 1;
  var e = lb();
  function t(r) {
    return e(r) && r != +r;
  }
  return Yo = t, Yo;
}
var a1 = i1();
const zr = /* @__PURE__ */ ce(a1);
var o1 = lb();
const u1 = /* @__PURE__ */ ce(o1);
var Qe = function(t) {
  return t === 0 ? 0 : t > 0 ? 1 : -1;
}, zt = function(t) {
  return Gt(t) && t.indexOf("%") === t.length - 1;
}, q = function(t) {
  return u1(t) && !zr(t);
}, s1 = function(t) {
  return ee(t);
}, _e = function(t) {
  return q(t) || Gt(t);
}, c1 = 0, Zn = function(t) {
  var r = ++c1;
  return "".concat(t || "").concat(r);
}, Vt = function(t, r) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0, i = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !1;
  if (!q(t) && !Gt(t))
    return n;
  var a;
  if (zt(t)) {
    var o = t.indexOf("%");
    a = r * parseFloat(t.slice(0, o)) / 100;
  } else
    a = +t;
  return zr(a) && (a = n), i && a > r && (a = r), a;
}, Pt = function(t) {
  if (!t)
    return null;
  var r = Object.keys(t);
  return r && r.length ? t[r[0]] : null;
}, l1 = function(t) {
  if (!Array.isArray(t))
    return !1;
  for (var r = t.length, n = {}, i = 0; i < r; i++)
    if (!n[t[i]])
      n[t[i]] = !0;
    else
      return !0;
  return !1;
}, He = function(t, r) {
  return q(t) && q(r) ? function(n) {
    return t + n * (r - t);
  } : function() {
    return r;
  };
};
function vi(e, t, r) {
  return !e || !e.length ? null : e.find(function(n) {
    return n && (typeof t == "function" ? t(n) : Ge(n, t)) === r;
  });
}
var f1 = function(t, r) {
  return q(t) && q(r) ? t - r : Gt(t) && Gt(r) ? t.localeCompare(r) : t instanceof Date && r instanceof Date ? t.getTime() - r.getTime() : String(t).localeCompare(String(r));
};
function fr(e, t) {
  for (var r in e)
    if ({}.hasOwnProperty.call(e, r) && (!{}.hasOwnProperty.call(t, r) || e[r] !== t[r]))
      return !1;
  for (var n in t)
    if ({}.hasOwnProperty.call(t, n) && !{}.hasOwnProperty.call(e, n))
      return !1;
  return !0;
}
function el(e) {
  "@babel/helpers - typeof";
  return el = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, el(e);
}
var d1 = ["viewBox", "children"], h1 = [
  "aria-activedescendant",
  "aria-atomic",
  "aria-autocomplete",
  "aria-busy",
  "aria-checked",
  "aria-colcount",
  "aria-colindex",
  "aria-colspan",
  "aria-controls",
  "aria-current",
  "aria-describedby",
  "aria-details",
  "aria-disabled",
  "aria-errormessage",
  "aria-expanded",
  "aria-flowto",
  "aria-haspopup",
  "aria-hidden",
  "aria-invalid",
  "aria-keyshortcuts",
  "aria-label",
  "aria-labelledby",
  "aria-level",
  "aria-live",
  "aria-modal",
  "aria-multiline",
  "aria-multiselectable",
  "aria-orientation",
  "aria-owns",
  "aria-placeholder",
  "aria-posinset",
  "aria-pressed",
  "aria-readonly",
  "aria-relevant",
  "aria-required",
  "aria-roledescription",
  "aria-rowcount",
  "aria-rowindex",
  "aria-rowspan",
  "aria-selected",
  "aria-setsize",
  "aria-sort",
  "aria-valuemax",
  "aria-valuemin",
  "aria-valuenow",
  "aria-valuetext",
  "className",
  "color",
  "height",
  "id",
  "lang",
  "max",
  "media",
  "method",
  "min",
  "name",
  "style",
  /*
   * removed 'type' SVGElementPropKey because we do not currently use any SVG elements
   * that can use it and it conflicts with the recharts prop 'type'
   * https://github.com/recharts/recharts/pull/3327
   * https://developer.mozilla.org/en-US/docs/Web/SVG/Attribute/type
   */
  // 'type',
  "target",
  "width",
  "role",
  "tabIndex",
  "accentHeight",
  "accumulate",
  "additive",
  "alignmentBaseline",
  "allowReorder",
  "alphabetic",
  "amplitude",
  "arabicForm",
  "ascent",
  "attributeName",
  "attributeType",
  "autoReverse",
  "azimuth",
  "baseFrequency",
  "baselineShift",
  "baseProfile",
  "bbox",
  "begin",
  "bias",
  "by",
  "calcMode",
  "capHeight",
  "clip",
  "clipPath",
  "clipPathUnits",
  "clipRule",
  "colorInterpolation",
  "colorInterpolationFilters",
  "colorProfile",
  "colorRendering",
  "contentScriptType",
  "contentStyleType",
  "cursor",
  "cx",
  "cy",
  "d",
  "decelerate",
  "descent",
  "diffuseConstant",
  "direction",
  "display",
  "divisor",
  "dominantBaseline",
  "dur",
  "dx",
  "dy",
  "edgeMode",
  "elevation",
  "enableBackground",
  "end",
  "exponent",
  "externalResourcesRequired",
  "fill",
  "fillOpacity",
  "fillRule",
  "filter",
  "filterRes",
  "filterUnits",
  "floodColor",
  "floodOpacity",
  "focusable",
  "fontFamily",
  "fontSize",
  "fontSizeAdjust",
  "fontStretch",
  "fontStyle",
  "fontVariant",
  "fontWeight",
  "format",
  "from",
  "fx",
  "fy",
  "g1",
  "g2",
  "glyphName",
  "glyphOrientationHorizontal",
  "glyphOrientationVertical",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "hanging",
  "horizAdvX",
  "horizOriginX",
  "href",
  "ideographic",
  "imageRendering",
  "in2",
  "in",
  "intercept",
  "k1",
  "k2",
  "k3",
  "k4",
  "k",
  "kernelMatrix",
  "kernelUnitLength",
  "kerning",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "letterSpacing",
  "lightingColor",
  "limitingConeAngle",
  "local",
  "markerEnd",
  "markerHeight",
  "markerMid",
  "markerStart",
  "markerUnits",
  "markerWidth",
  "mask",
  "maskContentUnits",
  "maskUnits",
  "mathematical",
  "mode",
  "numOctaves",
  "offset",
  "opacity",
  "operator",
  "order",
  "orient",
  "orientation",
  "origin",
  "overflow",
  "overlinePosition",
  "overlineThickness",
  "paintOrder",
  "panose1",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointerEvents",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "r",
  "radius",
  "refX",
  "refY",
  "renderingIntent",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "restart",
  "result",
  "rotate",
  "rx",
  "ry",
  "seed",
  "shapeRendering",
  "slope",
  "spacing",
  "specularConstant",
  "specularExponent",
  "speed",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stemh",
  "stemv",
  "stitchTiles",
  "stopColor",
  "stopOpacity",
  "strikethroughPosition",
  "strikethroughThickness",
  "string",
  "stroke",
  "strokeDasharray",
  "strokeDashoffset",
  "strokeLinecap",
  "strokeLinejoin",
  "strokeMiterlimit",
  "strokeOpacity",
  "strokeWidth",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textAnchor",
  "textDecoration",
  "textLength",
  "textRendering",
  "to",
  "transform",
  "u1",
  "u2",
  "underlinePosition",
  "underlineThickness",
  "unicode",
  "unicodeBidi",
  "unicodeRange",
  "unitsPerEm",
  "vAlphabetic",
  "values",
  "vectorEffect",
  "version",
  "vertAdvY",
  "vertOriginX",
  "vertOriginY",
  "vHanging",
  "vIdeographic",
  "viewTarget",
  "visibility",
  "vMathematical",
  "widths",
  "wordSpacing",
  "writingMode",
  "x1",
  "x2",
  "x",
  "xChannelSelector",
  "xHeight",
  "xlinkActuate",
  "xlinkArcrole",
  "xlinkHref",
  "xlinkRole",
  "xlinkShow",
  "xlinkTitle",
  "xlinkType",
  "xmlBase",
  "xmlLang",
  "xmlns",
  "xmlnsXlink",
  "xmlSpace",
  "y1",
  "y2",
  "y",
  "yChannelSelector",
  "z",
  "zoomAndPan",
  "ref",
  "key",
  "angle"
], kh = ["points", "pathLength"], Zo = {
  svg: d1,
  polygon: kh,
  polyline: kh
}, Pf = ["dangerouslySetInnerHTML", "onCopy", "onCopyCapture", "onCut", "onCutCapture", "onPaste", "onPasteCapture", "onCompositionEnd", "onCompositionEndCapture", "onCompositionStart", "onCompositionStartCapture", "onCompositionUpdate", "onCompositionUpdateCapture", "onFocus", "onFocusCapture", "onBlur", "onBlurCapture", "onChange", "onChangeCapture", "onBeforeInput", "onBeforeInputCapture", "onInput", "onInputCapture", "onReset", "onResetCapture", "onSubmit", "onSubmitCapture", "onInvalid", "onInvalidCapture", "onLoad", "onLoadCapture", "onError", "onErrorCapture", "onKeyDown", "onKeyDownCapture", "onKeyPress", "onKeyPressCapture", "onKeyUp", "onKeyUpCapture", "onAbort", "onAbortCapture", "onCanPlay", "onCanPlayCapture", "onCanPlayThrough", "onCanPlayThroughCapture", "onDurationChange", "onDurationChangeCapture", "onEmptied", "onEmptiedCapture", "onEncrypted", "onEncryptedCapture", "onEnded", "onEndedCapture", "onLoadedData", "onLoadedDataCapture", "onLoadedMetadata", "onLoadedMetadataCapture", "onLoadStart", "onLoadStartCapture", "onPause", "onPauseCapture", "onPlay", "onPlayCapture", "onPlaying", "onPlayingCapture", "onProgress", "onProgressCapture", "onRateChange", "onRateChangeCapture", "onSeeked", "onSeekedCapture", "onSeeking", "onSeekingCapture", "onStalled", "onStalledCapture", "onSuspend", "onSuspendCapture", "onTimeUpdate", "onTimeUpdateCapture", "onVolumeChange", "onVolumeChangeCapture", "onWaiting", "onWaitingCapture", "onAuxClick", "onAuxClickCapture", "onClick", "onClickCapture", "onContextMenu", "onContextMenuCapture", "onDoubleClick", "onDoubleClickCapture", "onDrag", "onDragCapture", "onDragEnd", "onDragEndCapture", "onDragEnter", "onDragEnterCapture", "onDragExit", "onDragExitCapture", "onDragLeave", "onDragLeaveCapture", "onDragOver", "onDragOverCapture", "onDragStart", "onDragStartCapture", "onDrop", "onDropCapture", "onMouseDown", "onMouseDownCapture", "onMouseEnter", "onMouseLeave", "onMouseMove", "onMouseMoveCapture", "onMouseOut", "onMouseOutCapture", "onMouseOver", "onMouseOverCapture", "onMouseUp", "onMouseUpCapture", "onSelect", "onSelectCapture", "onTouchCancel", "onTouchCancelCapture", "onTouchEnd", "onTouchEndCapture", "onTouchMove", "onTouchMoveCapture", "onTouchStart", "onTouchStartCapture", "onPointerDown", "onPointerDownCapture", "onPointerMove", "onPointerMoveCapture", "onPointerUp", "onPointerUpCapture", "onPointerCancel", "onPointerCancelCapture", "onPointerEnter", "onPointerEnterCapture", "onPointerLeave", "onPointerLeaveCapture", "onPointerOver", "onPointerOverCapture", "onPointerOut", "onPointerOutCapture", "onGotPointerCapture", "onGotPointerCaptureCapture", "onLostPointerCapture", "onLostPointerCaptureCapture", "onScroll", "onScrollCapture", "onWheel", "onWheelCapture", "onAnimationStart", "onAnimationStartCapture", "onAnimationEnd", "onAnimationEndCapture", "onAnimationIteration", "onAnimationIterationCapture", "onTransitionEnd", "onTransitionEndCapture"], yi = function(t, r) {
  if (!t || typeof t == "function" || typeof t == "boolean")
    return null;
  var n = t;
  if (/* @__PURE__ */ D.isValidElement(t) && (n = t.props), !Fr(n))
    return null;
  var i = {};
  return Object.keys(n).forEach(function(a) {
    Pf.includes(a) && (i[a] = r || function(o) {
      return n[a](n, o);
    });
  }), i;
}, p1 = function(t, r, n) {
  return function(i) {
    return t(r, n, i), null;
  };
}, mi = function(t, r, n) {
  if (!Fr(t) || el(t) !== "object")
    return null;
  var i = null;
  return Object.keys(t).forEach(function(a) {
    var o = t[a];
    Pf.includes(a) && typeof o == "function" && (i || (i = {}), i[a] = p1(o, r, n));
  }), i;
}, v1 = ["children"], y1 = ["children"];
function Dh(e, t) {
  if (e == null) return {};
  var r = m1(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function m1(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function tl(e) {
  "@babel/helpers - typeof";
  return tl = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, tl(e);
}
var Rh = {
  click: "onClick",
  mousedown: "onMouseDown",
  mouseup: "onMouseUp",
  mouseover: "onMouseOver",
  mousemove: "onMouseMove",
  mouseout: "onMouseOut",
  mouseenter: "onMouseEnter",
  mouseleave: "onMouseLeave",
  touchcancel: "onTouchCancel",
  touchend: "onTouchEnd",
  touchmove: "onTouchMove",
  touchstart: "onTouchStart",
  contextmenu: "onContextMenu",
  dblclick: "onDoubleClick"
}, dt = function(t) {
  return typeof t == "string" ? t : t ? t.displayName || t.name || "Component" : "";
}, Lh = null, Qo = null, Tf = function e(t) {
  if (t === Lh && Array.isArray(Qo))
    return Qo;
  var r = [];
  return D.Children.forEach(t, function(n) {
    ee(n) || (n1.isFragment(n) ? r = r.concat(e(n.props.children)) : r.push(n));
  }), Qo = r, Lh = t, r;
};
function Je(e, t) {
  var r = [], n = [];
  return Array.isArray(t) ? n = t.map(function(i) {
    return dt(i);
  }) : n = [dt(t)], Tf(e).forEach(function(i) {
    var a = Ge(i, "type.displayName") || Ge(i, "type.name");
    n.indexOf(a) !== -1 && r.push(i);
  }), r;
}
function Le(e, t) {
  var r = Je(e, t);
  return r && r[0];
}
var qh = function(t) {
  if (!t || !t.props)
    return !1;
  var r = t.props, n = r.width, i = r.height;
  return !(!q(n) || n <= 0 || !q(i) || i <= 0);
}, g1 = ["a", "altGlyph", "altGlyphDef", "altGlyphItem", "animate", "animateColor", "animateMotion", "animateTransform", "circle", "clipPath", "color-profile", "cursor", "defs", "desc", "ellipse", "feBlend", "feColormatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence", "filter", "font", "font-face", "font-face-format", "font-face-name", "font-face-url", "foreignObject", "g", "glyph", "glyphRef", "hkern", "image", "line", "lineGradient", "marker", "mask", "metadata", "missing-glyph", "mpath", "path", "pattern", "polygon", "polyline", "radialGradient", "rect", "script", "set", "stop", "style", "svg", "switch", "symbol", "text", "textPath", "title", "tref", "tspan", "use", "view", "vkern"], b1 = function(t) {
  return t && t.type && Gt(t.type) && g1.indexOf(t.type) >= 0;
}, x1 = function(t) {
  return t && tl(t) === "object" && "clipDot" in t;
}, w1 = function(t, r, n, i) {
  var a, o = (a = Zo == null ? void 0 : Zo[i]) !== null && a !== void 0 ? a : [];
  return r.startsWith("data-") || !Z(t) && (i && o.includes(r) || h1.includes(r)) || n && Pf.includes(r);
}, J = function(t, r, n) {
  if (!t || typeof t == "function" || typeof t == "boolean")
    return null;
  var i = t;
  if (/* @__PURE__ */ D.isValidElement(t) && (i = t.props), !Fr(i))
    return null;
  var a = {};
  return Object.keys(i).forEach(function(o) {
    var u;
    w1((u = i) === null || u === void 0 ? void 0 : u[o], o, r, n) && (a[o] = i[o]);
  }), a;
}, rl = function e(t, r) {
  if (t === r)
    return !0;
  var n = D.Children.count(t);
  if (n !== D.Children.count(r))
    return !1;
  if (n === 0)
    return !0;
  if (n === 1)
    return Bh(Array.isArray(t) ? t[0] : t, Array.isArray(r) ? r[0] : r);
  for (var i = 0; i < n; i++) {
    var a = t[i], o = r[i];
    if (Array.isArray(a) || Array.isArray(o)) {
      if (!e(a, o))
        return !1;
    } else if (!Bh(a, o))
      return !1;
  }
  return !0;
}, Bh = function(t, r) {
  if (ee(t) && ee(r))
    return !0;
  if (!ee(t) && !ee(r)) {
    var n = t.props || {}, i = n.children, a = Dh(n, v1), o = r.props || {}, u = o.children, s = Dh(o, y1);
    return i && u ? fr(a, s) && rl(i, u) : !i && !u ? fr(a, s) : !1;
  }
  return !1;
}, Fh = function(t, r) {
  var n = [], i = {};
  return Tf(t).forEach(function(a, o) {
    if (b1(a))
      n.push(a);
    else if (a) {
      var u = dt(a.type), s = r[u] || {}, c = s.handler, f = s.once;
      if (c && (!f || !i[u])) {
        var l = c(a, u, o);
        n.push(l), i[u] = !0;
      }
    }
  }), n;
}, O1 = function(t) {
  var r = t && t.type;
  return r && Rh[r] ? Rh[r] : null;
}, _1 = function(t, r) {
  return Tf(r).indexOf(t);
}, S1 = ["children", "width", "height", "viewBox", "className", "style", "title", "desc"];
function nl() {
  return nl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, nl.apply(this, arguments);
}
function A1(e, t) {
  if (e == null) return {};
  var r = P1(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function P1(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function il(e) {
  var t = e.children, r = e.width, n = e.height, i = e.viewBox, a = e.className, o = e.style, u = e.title, s = e.desc, c = A1(e, S1), f = i || {
    width: r,
    height: n,
    x: 0,
    y: 0
  }, l = re("recharts-surface", a);
  return /* @__PURE__ */ T.createElement("svg", nl({}, J(c, !0, "svg"), {
    className: l,
    width: r,
    height: n,
    style: o,
    viewBox: "".concat(f.x, " ").concat(f.y, " ").concat(f.width, " ").concat(f.height)
  }), /* @__PURE__ */ T.createElement("title", null, u), /* @__PURE__ */ T.createElement("desc", null, s), t);
}
var T1 = ["children", "className"];
function al() {
  return al = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, al.apply(this, arguments);
}
function j1(e, t) {
  if (e == null) return {};
  var r = E1(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function E1(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
var he = /* @__PURE__ */ T.forwardRef(function(e, t) {
  var r = e.children, n = e.className, i = j1(e, T1), a = re("recharts-layer", n);
  return /* @__PURE__ */ T.createElement("g", al({
    className: a
  }, J(i, !0), {
    ref: t
  }), r);
}), ht = function(t, r) {
  for (var n = arguments.length, i = new Array(n > 2 ? n - 2 : 0), a = 2; a < n; a++)
    i[a - 2] = arguments[a];
}, Jo, zh;
function M1() {
  if (zh) return Jo;
  zh = 1;
  function e(t, r, n) {
    var i = -1, a = t.length;
    r < 0 && (r = -r > a ? 0 : a + r), n = n > a ? a : n, n < 0 && (n += a), a = r > n ? 0 : n - r >>> 0, r >>>= 0;
    for (var o = Array(a); ++i < a; )
      o[i] = t[i + r];
    return o;
  }
  return Jo = e, Jo;
}
var eu, Uh;
function C1() {
  if (Uh) return eu;
  Uh = 1;
  var e = M1();
  function t(r, n, i) {
    var a = r.length;
    return i = i === void 0 ? a : i, !n && i >= a ? r : e(r, n, i);
  }
  return eu = t, eu;
}
var tu, Wh;
function fb() {
  if (Wh) return tu;
  Wh = 1;
  var e = "\\ud800-\\udfff", t = "\\u0300-\\u036f", r = "\\ufe20-\\ufe2f", n = "\\u20d0-\\u20ff", i = t + r + n, a = "\\ufe0e\\ufe0f", o = "\\u200d", u = RegExp("[" + o + e + i + a + "]");
  function s(c) {
    return u.test(c);
  }
  return tu = s, tu;
}
var ru, Hh;
function I1() {
  if (Hh) return ru;
  Hh = 1;
  function e(t) {
    return t.split("");
  }
  return ru = e, ru;
}
var nu, Kh;
function $1() {
  if (Kh) return nu;
  Kh = 1;
  var e = "\\ud800-\\udfff", t = "\\u0300-\\u036f", r = "\\ufe20-\\ufe2f", n = "\\u20d0-\\u20ff", i = t + r + n, a = "\\ufe0e\\ufe0f", o = "[" + e + "]", u = "[" + i + "]", s = "\\ud83c[\\udffb-\\udfff]", c = "(?:" + u + "|" + s + ")", f = "[^" + e + "]", l = "(?:\\ud83c[\\udde6-\\uddff]){2}", d = "[\\ud800-\\udbff][\\udc00-\\udfff]", p = "\\u200d", y = c + "?", v = "[" + a + "]?", h = "(?:" + p + "(?:" + [f, l, d].join("|") + ")" + v + y + ")*", w = v + y + h, b = "(?:" + [f + u + "?", u, l, d, o].join("|") + ")", x = RegExp(s + "(?=" + s + ")|" + b + w, "g");
  function O(m) {
    return m.match(x) || [];
  }
  return nu = O, nu;
}
var iu, Gh;
function N1() {
  if (Gh) return iu;
  Gh = 1;
  var e = I1(), t = fb(), r = $1();
  function n(i) {
    return t(i) ? r(i) : e(i);
  }
  return iu = n, iu;
}
var au, Vh;
function k1() {
  if (Vh) return au;
  Vh = 1;
  var e = C1(), t = fb(), r = N1(), n = ub();
  function i(a) {
    return function(o) {
      o = n(o);
      var u = t(o) ? r(o) : void 0, s = u ? u[0] : o.charAt(0), c = u ? e(u, 1).join("") : o.slice(1);
      return s[a]() + c;
    };
  }
  return au = i, au;
}
var ou, Xh;
function D1() {
  if (Xh) return ou;
  Xh = 1;
  var e = k1(), t = e("toUpperCase");
  return ou = t, ou;
}
var R1 = D1();
const ga = /* @__PURE__ */ ce(R1);
function se(e) {
  return function() {
    return e;
  };
}
const db = Math.cos, gi = Math.sin, et = Math.sqrt, bi = Math.PI, ba = 2 * bi, ol = Math.PI, ul = 2 * ol, Bt = 1e-6, L1 = ul - Bt;
function hb(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function q1(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return hb;
  const r = 10 ** t;
  return function(n) {
    this._ += n[0];
    for (let i = 1, a = n.length; i < a; ++i)
      this._ += Math.round(arguments[i] * r) / r + n[i];
  };
}
class B1 {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? hb : q1(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, n, i) {
    this._append`Q${+t},${+r},${this._x1 = +n},${this._y1 = +i}`;
  }
  bezierCurveTo(t, r, n, i, a, o) {
    this._append`C${+t},${+r},${+n},${+i},${this._x1 = +a},${this._y1 = +o}`;
  }
  arcTo(t, r, n, i, a) {
    if (t = +t, r = +r, n = +n, i = +i, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let o = this._x1, u = this._y1, s = n - t, c = i - r, f = o - t, l = u - r, d = f * f + l * l;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (d > Bt) if (!(Math.abs(l * s - c * f) > Bt) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let p = n - o, y = i - u, v = s * s + c * c, h = p * p + y * y, w = Math.sqrt(v), b = Math.sqrt(d), x = a * Math.tan((ol - Math.acos((v + d - h) / (2 * w * b))) / 2), O = x / b, m = x / w;
      Math.abs(O - 1) > Bt && this._append`L${t + O * f},${r + O * l}`, this._append`A${a},${a},0,0,${+(l * p > f * y)},${this._x1 = t + m * s},${this._y1 = r + m * c}`;
    }
  }
  arc(t, r, n, i, a, o) {
    if (t = +t, r = +r, n = +n, o = !!o, n < 0) throw new Error(`negative radius: ${n}`);
    let u = n * Math.cos(i), s = n * Math.sin(i), c = t + u, f = r + s, l = 1 ^ o, d = o ? i - a : a - i;
    this._x1 === null ? this._append`M${c},${f}` : (Math.abs(this._x1 - c) > Bt || Math.abs(this._y1 - f) > Bt) && this._append`L${c},${f}`, n && (d < 0 && (d = d % ul + ul), d > L1 ? this._append`A${n},${n},0,1,${l},${t - u},${r - s}A${n},${n},0,1,${l},${this._x1 = c},${this._y1 = f}` : d > Bt && this._append`A${n},${n},0,${+(d >= ol)},${l},${this._x1 = t + n * Math.cos(a)},${this._y1 = r + n * Math.sin(a)}`);
  }
  rect(t, r, n, i) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${n = +n}v${+i}h${-n}Z`;
  }
  toString() {
    return this._;
  }
}
function jf(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const n = Math.floor(r);
      if (!(n >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = n;
    }
    return e;
  }, () => new B1(t);
}
function Ef(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function pb(e) {
  this._context = e;
}
pb.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      // falls through
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function xa(e) {
  return new pb(e);
}
function vb(e) {
  return e[0];
}
function yb(e) {
  return e[1];
}
function mb(e, t) {
  var r = se(!0), n = null, i = xa, a = null, o = jf(u);
  e = typeof e == "function" ? e : e === void 0 ? vb : se(e), t = typeof t == "function" ? t : t === void 0 ? yb : se(t);
  function u(s) {
    var c, f = (s = Ef(s)).length, l, d = !1, p;
    for (n == null && (a = i(p = o())), c = 0; c <= f; ++c)
      !(c < f && r(l = s[c], c, s)) === d && ((d = !d) ? a.lineStart() : a.lineEnd()), d && a.point(+e(l, c, s), +t(l, c, s));
    if (p) return a = null, p + "" || null;
  }
  return u.x = function(s) {
    return arguments.length ? (e = typeof s == "function" ? s : se(+s), u) : e;
  }, u.y = function(s) {
    return arguments.length ? (t = typeof s == "function" ? s : se(+s), u) : t;
  }, u.defined = function(s) {
    return arguments.length ? (r = typeof s == "function" ? s : se(!!s), u) : r;
  }, u.curve = function(s) {
    return arguments.length ? (i = s, n != null && (a = i(n)), u) : i;
  }, u.context = function(s) {
    return arguments.length ? (s == null ? n = a = null : a = i(n = s), u) : n;
  }, u;
}
function ai(e, t, r) {
  var n = null, i = se(!0), a = null, o = xa, u = null, s = jf(c);
  e = typeof e == "function" ? e : e === void 0 ? vb : se(+e), t = typeof t == "function" ? t : se(t === void 0 ? 0 : +t), r = typeof r == "function" ? r : r === void 0 ? yb : se(+r);
  function c(l) {
    var d, p, y, v = (l = Ef(l)).length, h, w = !1, b, x = new Array(v), O = new Array(v);
    for (a == null && (u = o(b = s())), d = 0; d <= v; ++d) {
      if (!(d < v && i(h = l[d], d, l)) === w)
        if (w = !w)
          p = d, u.areaStart(), u.lineStart();
        else {
          for (u.lineEnd(), u.lineStart(), y = d - 1; y >= p; --y)
            u.point(x[y], O[y]);
          u.lineEnd(), u.areaEnd();
        }
      w && (x[d] = +e(h, d, l), O[d] = +t(h, d, l), u.point(n ? +n(h, d, l) : x[d], r ? +r(h, d, l) : O[d]));
    }
    if (b) return u = null, b + "" || null;
  }
  function f() {
    return mb().defined(i).curve(o).context(a);
  }
  return c.x = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : se(+l), n = null, c) : e;
  }, c.x0 = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : se(+l), c) : e;
  }, c.x1 = function(l) {
    return arguments.length ? (n = l == null ? null : typeof l == "function" ? l : se(+l), c) : n;
  }, c.y = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : se(+l), r = null, c) : t;
  }, c.y0 = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : se(+l), c) : t;
  }, c.y1 = function(l) {
    return arguments.length ? (r = l == null ? null : typeof l == "function" ? l : se(+l), c) : r;
  }, c.lineX0 = c.lineY0 = function() {
    return f().x(e).y(t);
  }, c.lineY1 = function() {
    return f().x(e).y(r);
  }, c.lineX1 = function() {
    return f().x(n).y(t);
  }, c.defined = function(l) {
    return arguments.length ? (i = typeof l == "function" ? l : se(!!l), c) : i;
  }, c.curve = function(l) {
    return arguments.length ? (o = l, a != null && (u = o(a)), c) : o;
  }, c.context = function(l) {
    return arguments.length ? (l == null ? a = u = null : u = o(a = l), c) : a;
  }, c;
}
class gb {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      // falls through
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function F1(e) {
  return new gb(e, !0);
}
function z1(e) {
  return new gb(e, !1);
}
const Mf = {
  draw(e, t) {
    const r = et(t / bi);
    e.moveTo(r, 0), e.arc(0, 0, r, 0, ba);
  }
}, U1 = {
  draw(e, t) {
    const r = et(t / 5) / 2;
    e.moveTo(-3 * r, -r), e.lineTo(-r, -r), e.lineTo(-r, -3 * r), e.lineTo(r, -3 * r), e.lineTo(r, -r), e.lineTo(3 * r, -r), e.lineTo(3 * r, r), e.lineTo(r, r), e.lineTo(r, 3 * r), e.lineTo(-r, 3 * r), e.lineTo(-r, r), e.lineTo(-3 * r, r), e.closePath();
  }
}, bb = et(1 / 3), W1 = bb * 2, H1 = {
  draw(e, t) {
    const r = et(t / W1), n = r * bb;
    e.moveTo(0, -r), e.lineTo(n, 0), e.lineTo(0, r), e.lineTo(-n, 0), e.closePath();
  }
}, K1 = {
  draw(e, t) {
    const r = et(t), n = -r / 2;
    e.rect(n, n, r, r);
  }
}, G1 = 0.8908130915292852, xb = gi(bi / 10) / gi(7 * bi / 10), V1 = gi(ba / 10) * xb, X1 = -db(ba / 10) * xb, Y1 = {
  draw(e, t) {
    const r = et(t * G1), n = V1 * r, i = X1 * r;
    e.moveTo(0, -r), e.lineTo(n, i);
    for (let a = 1; a < 5; ++a) {
      const o = ba * a / 5, u = db(o), s = gi(o);
      e.lineTo(s * r, -u * r), e.lineTo(u * n - s * i, s * n + u * i);
    }
    e.closePath();
  }
}, uu = et(3), Z1 = {
  draw(e, t) {
    const r = -et(t / (uu * 3));
    e.moveTo(0, r * 2), e.lineTo(-uu * r, -r), e.lineTo(uu * r, -r), e.closePath();
  }
}, Fe = -0.5, ze = et(3) / 2, sl = 1 / et(12), Q1 = (sl / 2 + 1) * 3, J1 = {
  draw(e, t) {
    const r = et(t / Q1), n = r / 2, i = r * sl, a = n, o = r * sl + r, u = -a, s = o;
    e.moveTo(n, i), e.lineTo(a, o), e.lineTo(u, s), e.lineTo(Fe * n - ze * i, ze * n + Fe * i), e.lineTo(Fe * a - ze * o, ze * a + Fe * o), e.lineTo(Fe * u - ze * s, ze * u + Fe * s), e.lineTo(Fe * n + ze * i, Fe * i - ze * n), e.lineTo(Fe * a + ze * o, Fe * o - ze * a), e.lineTo(Fe * u + ze * s, Fe * s - ze * u), e.closePath();
  }
};
function e_(e, t) {
  let r = null, n = jf(i);
  e = typeof e == "function" ? e : se(e || Mf), t = typeof t == "function" ? t : se(t === void 0 ? 64 : +t);
  function i() {
    let a;
    if (r || (r = a = n()), e.apply(this, arguments).draw(r, +t.apply(this, arguments)), a) return r = null, a + "" || null;
  }
  return i.type = function(a) {
    return arguments.length ? (e = typeof a == "function" ? a : se(a), i) : e;
  }, i.size = function(a) {
    return arguments.length ? (t = typeof a == "function" ? a : se(+a), i) : t;
  }, i.context = function(a) {
    return arguments.length ? (r = a ?? null, i) : r;
  }, i;
}
function xi() {
}
function wi(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function wb(e) {
  this._context = e;
}
wb.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        wi(this, this._x1, this._y1);
      // falls through
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      // falls through
      default:
        wi(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function t_(e) {
  return new wb(e);
}
function Ob(e) {
  this._context = e;
}
Ob.prototype = {
  areaStart: xi,
  areaEnd: xi,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        wi(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function r_(e) {
  return new Ob(e);
}
function _b(e) {
  this._context = e;
}
_b.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, n = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, n) : this._context.moveTo(r, n);
        break;
      case 3:
        this._point = 4;
      // falls through
      default:
        wi(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function n_(e) {
  return new _b(e);
}
function Sb(e) {
  this._context = e;
}
Sb.prototype = {
  areaStart: xi,
  areaEnd: xi,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function i_(e) {
  return new Sb(e);
}
function Yh(e) {
  return e < 0 ? -1 : 1;
}
function Zh(e, t, r) {
  var n = e._x1 - e._x0, i = t - e._x1, a = (e._y1 - e._y0) / (n || i < 0 && -0), o = (r - e._y1) / (i || n < 0 && -0), u = (a * i + o * n) / (n + i);
  return (Yh(a) + Yh(o)) * Math.min(Math.abs(a), Math.abs(o), 0.5 * Math.abs(u)) || 0;
}
function Qh(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function su(e, t, r) {
  var n = e._x0, i = e._y0, a = e._x1, o = e._y1, u = (a - n) / 3;
  e._context.bezierCurveTo(n + u, i + u * t, a - u, o - u * r, a, o);
}
function Oi(e) {
  this._context = e;
}
Oi.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        su(this, this._t0, Qh(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, su(this, Qh(this, r = Zh(this, e, t)), r);
          break;
        default:
          su(this, this._t0, r = Zh(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Ab(e) {
  this._context = new Pb(e);
}
(Ab.prototype = Object.create(Oi.prototype)).point = function(e, t) {
  Oi.prototype.point.call(this, t, e);
};
function Pb(e) {
  this._context = e;
}
Pb.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, n, i, a) {
    this._context.bezierCurveTo(t, e, n, r, a, i);
  }
};
function a_(e) {
  return new Oi(e);
}
function o_(e) {
  return new Ab(e);
}
function Tb(e) {
  this._context = e;
}
Tb.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var n = Jh(e), i = Jh(t), a = 0, o = 1; o < r; ++a, ++o)
          this._context.bezierCurveTo(n[0][a], i[0][a], n[1][a], i[1][a], e[o], t[o]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function Jh(e) {
  var t, r = e.length - 1, n, i = new Array(r), a = new Array(r), o = new Array(r);
  for (i[0] = 0, a[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) i[t] = 1, a[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
  for (i[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) n = i[t] / a[t - 1], a[t] -= n, o[t] -= n * o[t - 1];
  for (i[r - 1] = o[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) i[t] = (o[t] - i[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + i[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - i[t + 1];
  return [i, a];
}
function u_(e) {
  return new Tb(e);
}
function wa(e, t) {
  this._context = e, this._t = t;
}
wa.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      // falls through
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function s_(e) {
  return new wa(e, 0.5);
}
function c_(e) {
  return new wa(e, 0);
}
function l_(e) {
  return new wa(e, 1);
}
function mr(e, t) {
  if ((o = e.length) > 1)
    for (var r = 1, n, i, a = e[t[0]], o, u = a.length; r < o; ++r)
      for (i = a, a = e[t[r]], n = 0; n < u; ++n)
        a[n][1] += a[n][0] = isNaN(i[n][1]) ? i[n][0] : i[n][1];
}
function cl(e) {
  for (var t = e.length, r = new Array(t); --t >= 0; ) r[t] = t;
  return r;
}
function f_(e, t) {
  return e[t];
}
function d_(e) {
  const t = [];
  return t.key = e, t;
}
function h_() {
  var e = se([]), t = cl, r = mr, n = f_;
  function i(a) {
    var o = Array.from(e.apply(this, arguments), d_), u, s = o.length, c = -1, f;
    for (const l of a)
      for (u = 0, ++c; u < s; ++u)
        (o[u][c] = [0, +n(l, o[u].key, c, a)]).data = l;
    for (u = 0, f = Ef(t(o)); u < s; ++u)
      o[f[u]].index = u;
    return r(o, f), o;
  }
  return i.keys = function(a) {
    return arguments.length ? (e = typeof a == "function" ? a : se(Array.from(a)), i) : e;
  }, i.value = function(a) {
    return arguments.length ? (n = typeof a == "function" ? a : se(+a), i) : n;
  }, i.order = function(a) {
    return arguments.length ? (t = a == null ? cl : typeof a == "function" ? a : se(Array.from(a)), i) : t;
  }, i.offset = function(a) {
    return arguments.length ? (r = a ?? mr, i) : r;
  }, i;
}
function p_(e, t) {
  if ((n = e.length) > 0) {
    for (var r, n, i = 0, a = e[0].length, o; i < a; ++i) {
      for (o = r = 0; r < n; ++r) o += e[r][i][1] || 0;
      if (o) for (r = 0; r < n; ++r) e[r][i][1] /= o;
    }
    mr(e, t);
  }
}
function v_(e, t) {
  if ((i = e.length) > 0) {
    for (var r = 0, n = e[t[0]], i, a = n.length; r < a; ++r) {
      for (var o = 0, u = 0; o < i; ++o) u += e[o][r][1] || 0;
      n[r][1] += n[r][0] = -u / 2;
    }
    mr(e, t);
  }
}
function y_(e, t) {
  if (!(!((o = e.length) > 0) || !((a = (i = e[t[0]]).length) > 0))) {
    for (var r = 0, n = 1, i, a, o; n < a; ++n) {
      for (var u = 0, s = 0, c = 0; u < o; ++u) {
        for (var f = e[t[u]], l = f[n][1] || 0, d = f[n - 1][1] || 0, p = (l - d) / 2, y = 0; y < u; ++y) {
          var v = e[t[y]], h = v[n][1] || 0, w = v[n - 1][1] || 0;
          p += h - w;
        }
        s += l, c += p * l;
      }
      i[n - 1][1] += i[n - 1][0] = r, s && (r -= c / s);
    }
    i[n - 1][1] += i[n - 1][0] = r, mr(e, t);
  }
}
function mn(e) {
  "@babel/helpers - typeof";
  return mn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, mn(e);
}
var m_ = ["type", "size", "sizeType"];
function ll() {
  return ll = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, ll.apply(this, arguments);
}
function ep(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function tp(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? ep(Object(r), !0).forEach(function(n) {
      g_(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ep(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function g_(e, t, r) {
  return t = b_(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function b_(e) {
  var t = x_(e, "string");
  return mn(t) == "symbol" ? t : t + "";
}
function x_(e, t) {
  if (mn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (mn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function w_(e, t) {
  if (e == null) return {};
  var r = O_(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function O_(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
var jb = {
  symbolCircle: Mf,
  symbolCross: U1,
  symbolDiamond: H1,
  symbolSquare: K1,
  symbolStar: Y1,
  symbolTriangle: Z1,
  symbolWye: J1
}, __ = Math.PI / 180, S_ = function(t) {
  var r = "symbol".concat(ga(t));
  return jb[r] || Mf;
}, A_ = function(t, r, n) {
  if (r === "area")
    return t;
  switch (n) {
    case "cross":
      return 5 * t * t / 9;
    case "diamond":
      return 0.5 * t * t / Math.sqrt(3);
    case "square":
      return t * t;
    case "star": {
      var i = 18 * __;
      return 1.25 * t * t * (Math.tan(i) - Math.tan(i * 2) * Math.pow(Math.tan(i), 2));
    }
    case "triangle":
      return Math.sqrt(3) * t * t / 4;
    case "wye":
      return (21 - 10 * Math.sqrt(3)) * t * t / 8;
    default:
      return Math.PI * t * t / 4;
  }
}, P_ = function(t, r) {
  jb["symbol".concat(ga(t))] = r;
}, Cf = function(t) {
  var r = t.type, n = r === void 0 ? "circle" : r, i = t.size, a = i === void 0 ? 64 : i, o = t.sizeType, u = o === void 0 ? "area" : o, s = w_(t, m_), c = tp(tp({}, s), {}, {
    type: n,
    size: a,
    sizeType: u
  }), f = function() {
    var h = S_(n), w = e_().type(h).size(A_(a, u, n));
    return w();
  }, l = c.className, d = c.cx, p = c.cy, y = J(c, !0);
  return d === +d && p === +p && a === +a ? /* @__PURE__ */ T.createElement("path", ll({}, y, {
    className: re("recharts-symbols", l),
    transform: "translate(".concat(d, ", ").concat(p, ")"),
    d: f()
  })) : null;
};
Cf.registerSymbol = P_;
function gr(e) {
  "@babel/helpers - typeof";
  return gr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, gr(e);
}
function fl() {
  return fl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, fl.apply(this, arguments);
}
function rp(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function T_(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? rp(Object(r), !0).forEach(function(n) {
      gn(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : rp(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function j_(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function E_(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, Mb(n.key), n);
  }
}
function M_(e, t, r) {
  return t && E_(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function C_(e, t, r) {
  return t = _i(t), I_(e, Eb() ? Reflect.construct(t, r || [], _i(e).constructor) : t.apply(e, r));
}
function I_(e, t) {
  if (t && (gr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return $_(e);
}
function $_(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Eb() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Eb = function() {
    return !!e;
  })();
}
function _i(e) {
  return _i = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, _i(e);
}
function N_(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && dl(e, t);
}
function dl(e, t) {
  return dl = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, dl(e, t);
}
function gn(e, t, r) {
  return t = Mb(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Mb(e) {
  var t = k_(e, "string");
  return gr(t) == "symbol" ? t : t + "";
}
function k_(e, t) {
  if (gr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (gr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var Ue = 32, If = /* @__PURE__ */ function(e) {
  function t() {
    return j_(this, t), C_(this, t, arguments);
  }
  return N_(t, e), M_(t, [{
    key: "renderIcon",
    value: (
      /**
       * Render the path of icon
       * @param {Object} data Data of each legend item
       * @return {String} Path element
       */
      function(n) {
        var i = this.props.inactiveColor, a = Ue / 2, o = Ue / 6, u = Ue / 3, s = n.inactive ? i : n.color;
        if (n.type === "plainline")
          return /* @__PURE__ */ T.createElement("line", {
            strokeWidth: 4,
            fill: "none",
            stroke: s,
            strokeDasharray: n.payload.strokeDasharray,
            x1: 0,
            y1: a,
            x2: Ue,
            y2: a,
            className: "recharts-legend-icon"
          });
        if (n.type === "line")
          return /* @__PURE__ */ T.createElement("path", {
            strokeWidth: 4,
            fill: "none",
            stroke: s,
            d: "M0,".concat(a, "h").concat(u, `
            A`).concat(o, ",").concat(o, ",0,1,1,").concat(2 * u, ",").concat(a, `
            H`).concat(Ue, "M").concat(2 * u, ",").concat(a, `
            A`).concat(o, ",").concat(o, ",0,1,1,").concat(u, ",").concat(a),
            className: "recharts-legend-icon"
          });
        if (n.type === "rect")
          return /* @__PURE__ */ T.createElement("path", {
            stroke: "none",
            fill: s,
            d: "M0,".concat(Ue / 8, "h").concat(Ue, "v").concat(Ue * 3 / 4, "h").concat(-Ue, "z"),
            className: "recharts-legend-icon"
          });
        if (/* @__PURE__ */ T.isValidElement(n.legendIcon)) {
          var c = T_({}, n);
          return delete c.legendIcon, /* @__PURE__ */ T.cloneElement(n.legendIcon, c);
        }
        return /* @__PURE__ */ T.createElement(Cf, {
          fill: s,
          cx: a,
          cy: a,
          size: Ue,
          sizeType: "diameter",
          type: n.type
        });
      }
    )
    /**
     * Draw items of legend
     * @return {ReactElement} Items
     */
  }, {
    key: "renderItems",
    value: function() {
      var n = this, i = this.props, a = i.payload, o = i.iconSize, u = i.layout, s = i.formatter, c = i.inactiveColor, f = {
        x: 0,
        y: 0,
        width: Ue,
        height: Ue
      }, l = {
        display: u === "horizontal" ? "inline-block" : "block",
        marginRight: 10
      }, d = {
        display: "inline-block",
        verticalAlign: "middle",
        marginRight: 4
      };
      return a.map(function(p, y) {
        var v = p.formatter || s, h = re(gn(gn({
          "recharts-legend-item": !0
        }, "legend-item-".concat(y), !0), "inactive", p.inactive));
        if (p.type === "none")
          return null;
        var w = Z(p.value) ? null : p.value;
        ht(
          !Z(p.value),
          `The name property is also required when using a function for the dataKey of a chart's cartesian components. Ex: <Bar name="Name of my Data"/>`
          // eslint-disable-line max-len
        );
        var b = p.inactive ? c : p.color;
        return /* @__PURE__ */ T.createElement("li", fl({
          className: h,
          style: l,
          key: "legend-item-".concat(y)
        }, mi(n.props, p, y)), /* @__PURE__ */ T.createElement(il, {
          width: o,
          height: o,
          viewBox: f,
          style: d
        }, n.renderIcon(p)), /* @__PURE__ */ T.createElement("span", {
          className: "recharts-legend-item-text",
          style: {
            color: b
          }
        }, v ? v(w, p, y) : w));
      });
    }
  }, {
    key: "render",
    value: function() {
      var n = this.props, i = n.payload, a = n.layout, o = n.align;
      if (!i || !i.length)
        return null;
      var u = {
        padding: 0,
        margin: 0,
        textAlign: a === "horizontal" ? o : "left"
      };
      return /* @__PURE__ */ T.createElement("ul", {
        className: "recharts-default-legend",
        style: u
      }, this.renderItems());
    }
  }]);
}(D.PureComponent);
gn(If, "displayName", "Legend");
gn(If, "defaultProps", {
  iconSize: 14,
  layout: "horizontal",
  align: "center",
  verticalAlign: "middle",
  inactiveColor: "#ccc"
});
var cu, np;
function D_() {
  if (np) return cu;
  np = 1;
  var e = va();
  function t() {
    this.__data__ = new e(), this.size = 0;
  }
  return cu = t, cu;
}
var lu, ip;
function R_() {
  if (ip) return lu;
  ip = 1;
  function e(t) {
    var r = this.__data__, n = r.delete(t);
    return this.size = r.size, n;
  }
  return lu = e, lu;
}
var fu, ap;
function L_() {
  if (ap) return fu;
  ap = 1;
  function e(t) {
    return this.__data__.get(t);
  }
  return fu = e, fu;
}
var du, op;
function q_() {
  if (op) return du;
  op = 1;
  function e(t) {
    return this.__data__.has(t);
  }
  return du = e, du;
}
var hu, up;
function B_() {
  if (up) return hu;
  up = 1;
  var e = va(), t = Of(), r = _f(), n = 200;
  function i(a, o) {
    var u = this.__data__;
    if (u instanceof e) {
      var s = u.__data__;
      if (!t || s.length < n - 1)
        return s.push([a, o]), this.size = ++u.size, this;
      u = this.__data__ = new r(s);
    }
    return u.set(a, o), this.size = u.size, this;
  }
  return hu = i, hu;
}
var pu, sp;
function Cb() {
  if (sp) return pu;
  sp = 1;
  var e = va(), t = D_(), r = R_(), n = L_(), i = q_(), a = B_();
  function o(u) {
    var s = this.__data__ = new e(u);
    this.size = s.size;
  }
  return o.prototype.clear = t, o.prototype.delete = r, o.prototype.get = n, o.prototype.has = i, o.prototype.set = a, pu = o, pu;
}
var vu, cp;
function F_() {
  if (cp) return vu;
  cp = 1;
  var e = "__lodash_hash_undefined__";
  function t(r) {
    return this.__data__.set(r, e), this;
  }
  return vu = t, vu;
}
var yu, lp;
function z_() {
  if (lp) return yu;
  lp = 1;
  function e(t) {
    return this.__data__.has(t);
  }
  return yu = e, yu;
}
var mu, fp;
function Ib() {
  if (fp) return mu;
  fp = 1;
  var e = _f(), t = F_(), r = z_();
  function n(i) {
    var a = -1, o = i == null ? 0 : i.length;
    for (this.__data__ = new e(); ++a < o; )
      this.add(i[a]);
  }
  return n.prototype.add = n.prototype.push = t, n.prototype.has = r, mu = n, mu;
}
var gu, dp;
function $b() {
  if (dp) return gu;
  dp = 1;
  function e(t, r) {
    for (var n = -1, i = t == null ? 0 : t.length; ++n < i; )
      if (r(t[n], n, t))
        return !0;
    return !1;
  }
  return gu = e, gu;
}
var bu, hp;
function Nb() {
  if (hp) return bu;
  hp = 1;
  function e(t, r) {
    return t.has(r);
  }
  return bu = e, bu;
}
var xu, pp;
function kb() {
  if (pp) return xu;
  pp = 1;
  var e = Ib(), t = $b(), r = Nb(), n = 1, i = 2;
  function a(o, u, s, c, f, l) {
    var d = s & n, p = o.length, y = u.length;
    if (p != y && !(d && y > p))
      return !1;
    var v = l.get(o), h = l.get(u);
    if (v && h)
      return v == u && h == o;
    var w = -1, b = !0, x = s & i ? new e() : void 0;
    for (l.set(o, u), l.set(u, o); ++w < p; ) {
      var O = o[w], m = u[w];
      if (c)
        var g = d ? c(m, O, w, u, o, l) : c(O, m, w, o, u, l);
      if (g !== void 0) {
        if (g)
          continue;
        b = !1;
        break;
      }
      if (x) {
        if (!t(u, function(_, A) {
          if (!r(x, A) && (O === _ || f(O, _, s, c, l)))
            return x.push(A);
        })) {
          b = !1;
          break;
        }
      } else if (!(O === m || f(O, m, s, c, l))) {
        b = !1;
        break;
      }
    }
    return l.delete(o), l.delete(u), b;
  }
  return xu = a, xu;
}
var wu, vp;
function U_() {
  if (vp) return wu;
  vp = 1;
  var e = ut(), t = e.Uint8Array;
  return wu = t, wu;
}
var Ou, yp;
function W_() {
  if (yp) return Ou;
  yp = 1;
  function e(t) {
    var r = -1, n = Array(t.size);
    return t.forEach(function(i, a) {
      n[++r] = [a, i];
    }), n;
  }
  return Ou = e, Ou;
}
var _u, mp;
function $f() {
  if (mp) return _u;
  mp = 1;
  function e(t) {
    var r = -1, n = Array(t.size);
    return t.forEach(function(i) {
      n[++r] = i;
    }), n;
  }
  return _u = e, _u;
}
var Su, gp;
function H_() {
  if (gp) return Su;
  gp = 1;
  var e = Yn(), t = U_(), r = wf(), n = kb(), i = W_(), a = $f(), o = 1, u = 2, s = "[object Boolean]", c = "[object Date]", f = "[object Error]", l = "[object Map]", d = "[object Number]", p = "[object RegExp]", y = "[object Set]", v = "[object String]", h = "[object Symbol]", w = "[object ArrayBuffer]", b = "[object DataView]", x = e ? e.prototype : void 0, O = x ? x.valueOf : void 0;
  function m(g, _, A, P, $, M, j) {
    switch (A) {
      case b:
        if (g.byteLength != _.byteLength || g.byteOffset != _.byteOffset)
          return !1;
        g = g.buffer, _ = _.buffer;
      case w:
        return !(g.byteLength != _.byteLength || !M(new t(g), new t(_)));
      case s:
      case c:
      case d:
        return r(+g, +_);
      case f:
        return g.name == _.name && g.message == _.message;
      case p:
      case v:
        return g == _ + "";
      case l:
        var E = i;
      case y:
        var C = P & o;
        if (E || (E = a), g.size != _.size && !C)
          return !1;
        var I = j.get(g);
        if (I)
          return I == _;
        P |= u, j.set(g, _);
        var N = n(E(g), E(_), P, $, M, j);
        return j.delete(g), N;
      case h:
        if (O)
          return O.call(g) == O.call(_);
    }
    return !1;
  }
  return Su = m, Su;
}
var Au, bp;
function Db() {
  if (bp) return Au;
  bp = 1;
  function e(t, r) {
    for (var n = -1, i = r.length, a = t.length; ++n < i; )
      t[a + n] = r[n];
    return t;
  }
  return Au = e, Au;
}
var Pu, xp;
function K_() {
  if (xp) return Pu;
  xp = 1;
  var e = Db(), t = ke();
  function r(n, i, a) {
    var o = i(n);
    return t(n) ? o : e(o, a(n));
  }
  return Pu = r, Pu;
}
var Tu, wp;
function G_() {
  if (wp) return Tu;
  wp = 1;
  function e(t, r) {
    for (var n = -1, i = t == null ? 0 : t.length, a = 0, o = []; ++n < i; ) {
      var u = t[n];
      r(u, n, t) && (o[a++] = u);
    }
    return o;
  }
  return Tu = e, Tu;
}
var ju, Op;
function V_() {
  if (Op) return ju;
  Op = 1;
  function e() {
    return [];
  }
  return ju = e, ju;
}
var Eu, _p;
function X_() {
  if (_p) return Eu;
  _p = 1;
  var e = G_(), t = V_(), r = Object.prototype, n = r.propertyIsEnumerable, i = Object.getOwnPropertySymbols, a = i ? function(o) {
    return o == null ? [] : (o = Object(o), e(i(o), function(u) {
      return n.call(o, u);
    }));
  } : t;
  return Eu = a, Eu;
}
var Mu, Sp;
function Y_() {
  if (Sp) return Mu;
  Sp = 1;
  function e(t, r) {
    for (var n = -1, i = Array(t); ++n < t; )
      i[n] = r(n);
    return i;
  }
  return Mu = e, Mu;
}
var Cu, Ap;
function Z_() {
  if (Ap) return Cu;
  Ap = 1;
  var e = xt(), t = wt(), r = "[object Arguments]";
  function n(i) {
    return t(i) && e(i) == r;
  }
  return Cu = n, Cu;
}
var Iu, Pp;
function Nf() {
  if (Pp) return Iu;
  Pp = 1;
  var e = Z_(), t = wt(), r = Object.prototype, n = r.hasOwnProperty, i = r.propertyIsEnumerable, a = e(/* @__PURE__ */ function() {
    return arguments;
  }()) ? e : function(o) {
    return t(o) && n.call(o, "callee") && !i.call(o, "callee");
  };
  return Iu = a, Iu;
}
var on = { exports: {} }, $u, Tp;
function Q_() {
  if (Tp) return $u;
  Tp = 1;
  function e() {
    return !1;
  }
  return $u = e, $u;
}
on.exports;
var jp;
function Rb() {
  return jp || (jp = 1, function(e, t) {
    var r = ut(), n = Q_(), i = t && !t.nodeType && t, a = i && !0 && e && !e.nodeType && e, o = a && a.exports === i, u = o ? r.Buffer : void 0, s = u ? u.isBuffer : void 0, c = s || n;
    e.exports = c;
  }(on, on.exports)), on.exports;
}
var Nu, Ep;
function kf() {
  if (Ep) return Nu;
  Ep = 1;
  var e = 9007199254740991, t = /^(?:0|[1-9]\d*)$/;
  function r(n, i) {
    var a = typeof n;
    return i = i ?? e, !!i && (a == "number" || a != "symbol" && t.test(n)) && n > -1 && n % 1 == 0 && n < i;
  }
  return Nu = r, Nu;
}
var ku, Mp;
function Df() {
  if (Mp) return ku;
  Mp = 1;
  var e = 9007199254740991;
  function t(r) {
    return typeof r == "number" && r > -1 && r % 1 == 0 && r <= e;
  }
  return ku = t, ku;
}
var Du, Cp;
function J_() {
  if (Cp) return Du;
  Cp = 1;
  var e = xt(), t = Df(), r = wt(), n = "[object Arguments]", i = "[object Array]", a = "[object Boolean]", o = "[object Date]", u = "[object Error]", s = "[object Function]", c = "[object Map]", f = "[object Number]", l = "[object Object]", d = "[object RegExp]", p = "[object Set]", y = "[object String]", v = "[object WeakMap]", h = "[object ArrayBuffer]", w = "[object DataView]", b = "[object Float32Array]", x = "[object Float64Array]", O = "[object Int8Array]", m = "[object Int16Array]", g = "[object Int32Array]", _ = "[object Uint8Array]", A = "[object Uint8ClampedArray]", P = "[object Uint16Array]", $ = "[object Uint32Array]", M = {};
  M[b] = M[x] = M[O] = M[m] = M[g] = M[_] = M[A] = M[P] = M[$] = !0, M[n] = M[i] = M[h] = M[a] = M[w] = M[o] = M[u] = M[s] = M[c] = M[f] = M[l] = M[d] = M[p] = M[y] = M[v] = !1;
  function j(E) {
    return r(E) && t(E.length) && !!M[e(E)];
  }
  return Du = j, Du;
}
var Ru, Ip;
function Lb() {
  if (Ip) return Ru;
  Ip = 1;
  function e(t) {
    return function(r) {
      return t(r);
    };
  }
  return Ru = e, Ru;
}
var un = { exports: {} };
un.exports;
var $p;
function eS() {
  return $p || ($p = 1, function(e, t) {
    var r = ib(), n = t && !t.nodeType && t, i = n && !0 && e && !e.nodeType && e, a = i && i.exports === n, o = a && r.process, u = function() {
      try {
        var s = i && i.require && i.require("util").types;
        return s || o && o.binding && o.binding("util");
      } catch {
      }
    }();
    e.exports = u;
  }(un, un.exports)), un.exports;
}
var Lu, Np;
function qb() {
  if (Np) return Lu;
  Np = 1;
  var e = J_(), t = Lb(), r = eS(), n = r && r.isTypedArray, i = n ? t(n) : e;
  return Lu = i, Lu;
}
var qu, kp;
function tS() {
  if (kp) return qu;
  kp = 1;
  var e = Y_(), t = Nf(), r = ke(), n = Rb(), i = kf(), a = qb(), o = Object.prototype, u = o.hasOwnProperty;
  function s(c, f) {
    var l = r(c), d = !l && t(c), p = !l && !d && n(c), y = !l && !d && !p && a(c), v = l || d || p || y, h = v ? e(c.length, String) : [], w = h.length;
    for (var b in c)
      (f || u.call(c, b)) && !(v && // Safari 9 has enumerable `arguments.length` in strict mode.
      (b == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
      p && (b == "offset" || b == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
      y && (b == "buffer" || b == "byteLength" || b == "byteOffset") || // Skip index properties.
      i(b, w))) && h.push(b);
    return h;
  }
  return qu = s, qu;
}
var Bu, Dp;
function rS() {
  if (Dp) return Bu;
  Dp = 1;
  var e = Object.prototype;
  function t(r) {
    var n = r && r.constructor, i = typeof n == "function" && n.prototype || e;
    return r === i;
  }
  return Bu = t, Bu;
}
var Fu, Rp;
function Bb() {
  if (Rp) return Fu;
  Rp = 1;
  function e(t, r) {
    return function(n) {
      return t(r(n));
    };
  }
  return Fu = e, Fu;
}
var zu, Lp;
function nS() {
  if (Lp) return zu;
  Lp = 1;
  var e = Bb(), t = e(Object.keys, Object);
  return zu = t, zu;
}
var Uu, qp;
function iS() {
  if (qp) return Uu;
  qp = 1;
  var e = rS(), t = nS(), r = Object.prototype, n = r.hasOwnProperty;
  function i(a) {
    if (!e(a))
      return t(a);
    var o = [];
    for (var u in Object(a))
      n.call(a, u) && u != "constructor" && o.push(u);
    return o;
  }
  return Uu = i, Uu;
}
var Wu, Bp;
function Qn() {
  if (Bp) return Wu;
  Bp = 1;
  var e = xf(), t = Df();
  function r(n) {
    return n != null && t(n.length) && !e(n);
  }
  return Wu = r, Wu;
}
var Hu, Fp;
function Oa() {
  if (Fp) return Hu;
  Fp = 1;
  var e = tS(), t = iS(), r = Qn();
  function n(i) {
    return r(i) ? e(i) : t(i);
  }
  return Hu = n, Hu;
}
var Ku, zp;
function aS() {
  if (zp) return Ku;
  zp = 1;
  var e = K_(), t = X_(), r = Oa();
  function n(i) {
    return e(i, r, t);
  }
  return Ku = n, Ku;
}
var Gu, Up;
function oS() {
  if (Up) return Gu;
  Up = 1;
  var e = aS(), t = 1, r = Object.prototype, n = r.hasOwnProperty;
  function i(a, o, u, s, c, f) {
    var l = u & t, d = e(a), p = d.length, y = e(o), v = y.length;
    if (p != v && !l)
      return !1;
    for (var h = p; h--; ) {
      var w = d[h];
      if (!(l ? w in o : n.call(o, w)))
        return !1;
    }
    var b = f.get(a), x = f.get(o);
    if (b && x)
      return b == o && x == a;
    var O = !0;
    f.set(a, o), f.set(o, a);
    for (var m = l; ++h < p; ) {
      w = d[h];
      var g = a[w], _ = o[w];
      if (s)
        var A = l ? s(_, g, w, o, a, f) : s(g, _, w, a, o, f);
      if (!(A === void 0 ? g === _ || c(g, _, u, s, f) : A)) {
        O = !1;
        break;
      }
      m || (m = w == "constructor");
    }
    if (O && !m) {
      var P = a.constructor, $ = o.constructor;
      P != $ && "constructor" in a && "constructor" in o && !(typeof P == "function" && P instanceof P && typeof $ == "function" && $ instanceof $) && (O = !1);
    }
    return f.delete(a), f.delete(o), O;
  }
  return Gu = i, Gu;
}
var Vu, Wp;
function uS() {
  if (Wp) return Vu;
  Wp = 1;
  var e = Qt(), t = ut(), r = e(t, "DataView");
  return Vu = r, Vu;
}
var Xu, Hp;
function sS() {
  if (Hp) return Xu;
  Hp = 1;
  var e = Qt(), t = ut(), r = e(t, "Promise");
  return Xu = r, Xu;
}
var Yu, Kp;
function Fb() {
  if (Kp) return Yu;
  Kp = 1;
  var e = Qt(), t = ut(), r = e(t, "Set");
  return Yu = r, Yu;
}
var Zu, Gp;
function cS() {
  if (Gp) return Zu;
  Gp = 1;
  var e = Qt(), t = ut(), r = e(t, "WeakMap");
  return Zu = r, Zu;
}
var Qu, Vp;
function lS() {
  if (Vp) return Qu;
  Vp = 1;
  var e = uS(), t = Of(), r = sS(), n = Fb(), i = cS(), a = xt(), o = ab(), u = "[object Map]", s = "[object Object]", c = "[object Promise]", f = "[object Set]", l = "[object WeakMap]", d = "[object DataView]", p = o(e), y = o(t), v = o(r), h = o(n), w = o(i), b = a;
  return (e && b(new e(new ArrayBuffer(1))) != d || t && b(new t()) != u || r && b(r.resolve()) != c || n && b(new n()) != f || i && b(new i()) != l) && (b = function(x) {
    var O = a(x), m = O == s ? x.constructor : void 0, g = m ? o(m) : "";
    if (g)
      switch (g) {
        case p:
          return d;
        case y:
          return u;
        case v:
          return c;
        case h:
          return f;
        case w:
          return l;
      }
    return O;
  }), Qu = b, Qu;
}
var Ju, Xp;
function fS() {
  if (Xp) return Ju;
  Xp = 1;
  var e = Cb(), t = kb(), r = H_(), n = oS(), i = lS(), a = ke(), o = Rb(), u = qb(), s = 1, c = "[object Arguments]", f = "[object Array]", l = "[object Object]", d = Object.prototype, p = d.hasOwnProperty;
  function y(v, h, w, b, x, O) {
    var m = a(v), g = a(h), _ = m ? f : i(v), A = g ? f : i(h);
    _ = _ == c ? l : _, A = A == c ? l : A;
    var P = _ == l, $ = A == l, M = _ == A;
    if (M && o(v)) {
      if (!o(h))
        return !1;
      m = !0, P = !1;
    }
    if (M && !P)
      return O || (O = new e()), m || u(v) ? t(v, h, w, b, x, O) : r(v, h, _, w, b, x, O);
    if (!(w & s)) {
      var j = P && p.call(v, "__wrapped__"), E = $ && p.call(h, "__wrapped__");
      if (j || E) {
        var C = j ? v.value() : v, I = E ? h.value() : h;
        return O || (O = new e()), x(C, I, w, b, O);
      }
    }
    return M ? (O || (O = new e()), n(v, h, w, b, x, O)) : !1;
  }
  return Ju = y, Ju;
}
var es, Yp;
function Rf() {
  if (Yp) return es;
  Yp = 1;
  var e = fS(), t = wt();
  function r(n, i, a, o, u) {
    return n === i ? !0 : n == null || i == null || !t(n) && !t(i) ? n !== n && i !== i : e(n, i, a, o, r, u);
  }
  return es = r, es;
}
var ts, Zp;
function dS() {
  if (Zp) return ts;
  Zp = 1;
  var e = Cb(), t = Rf(), r = 1, n = 2;
  function i(a, o, u, s) {
    var c = u.length, f = c, l = !s;
    if (a == null)
      return !f;
    for (a = Object(a); c--; ) {
      var d = u[c];
      if (l && d[2] ? d[1] !== a[d[0]] : !(d[0] in a))
        return !1;
    }
    for (; ++c < f; ) {
      d = u[c];
      var p = d[0], y = a[p], v = d[1];
      if (l && d[2]) {
        if (y === void 0 && !(p in a))
          return !1;
      } else {
        var h = new e();
        if (s)
          var w = s(y, v, p, a, o, h);
        if (!(w === void 0 ? t(v, y, r | n, s, h) : w))
          return !1;
      }
    }
    return !0;
  }
  return ts = i, ts;
}
var rs, Qp;
function zb() {
  if (Qp) return rs;
  Qp = 1;
  var e = Ct();
  function t(r) {
    return r === r && !e(r);
  }
  return rs = t, rs;
}
var ns, Jp;
function hS() {
  if (Jp) return ns;
  Jp = 1;
  var e = zb(), t = Oa();
  function r(n) {
    for (var i = t(n), a = i.length; a--; ) {
      var o = i[a], u = n[o];
      i[a] = [o, u, e(u)];
    }
    return i;
  }
  return ns = r, ns;
}
var is, ev;
function Ub() {
  if (ev) return is;
  ev = 1;
  function e(t, r) {
    return function(n) {
      return n == null ? !1 : n[t] === r && (r !== void 0 || t in Object(n));
    };
  }
  return is = e, is;
}
var as, tv;
function pS() {
  if (tv) return as;
  tv = 1;
  var e = dS(), t = hS(), r = Ub();
  function n(i) {
    var a = t(i);
    return a.length == 1 && a[0][2] ? r(a[0][0], a[0][1]) : function(o) {
      return o === i || e(o, i, a);
    };
  }
  return as = n, as;
}
var os, rv;
function vS() {
  if (rv) return os;
  rv = 1;
  function e(t, r) {
    return t != null && r in Object(t);
  }
  return os = e, os;
}
var us, nv;
function yS() {
  if (nv) return us;
  nv = 1;
  var e = sb(), t = Nf(), r = ke(), n = kf(), i = Df(), a = ma();
  function o(u, s, c) {
    s = e(s, u);
    for (var f = -1, l = s.length, d = !1; ++f < l; ) {
      var p = a(s[f]);
      if (!(d = u != null && c(u, p)))
        break;
      u = u[p];
    }
    return d || ++f != l ? d : (l = u == null ? 0 : u.length, !!l && i(l) && n(p, l) && (r(u) || t(u)));
  }
  return us = o, us;
}
var ss, iv;
function mS() {
  if (iv) return ss;
  iv = 1;
  var e = vS(), t = yS();
  function r(n, i) {
    return n != null && t(n, i, e);
  }
  return ss = r, ss;
}
var cs, av;
function gS() {
  if (av) return cs;
  av = 1;
  var e = Rf(), t = cb(), r = mS(), n = bf(), i = zb(), a = Ub(), o = ma(), u = 1, s = 2;
  function c(f, l) {
    return n(f) && i(l) ? a(o(f), l) : function(d) {
      var p = t(d, f);
      return p === void 0 && p === l ? r(d, f) : e(l, p, u | s);
    };
  }
  return cs = c, cs;
}
var ls, ov;
function Ur() {
  if (ov) return ls;
  ov = 1;
  function e(t) {
    return t;
  }
  return ls = e, ls;
}
var fs, uv;
function bS() {
  if (uv) return fs;
  uv = 1;
  function e(t) {
    return function(r) {
      return r == null ? void 0 : r[t];
    };
  }
  return fs = e, fs;
}
var ds, sv;
function xS() {
  if (sv) return ds;
  sv = 1;
  var e = Af();
  function t(r) {
    return function(n) {
      return e(n, r);
    };
  }
  return ds = t, ds;
}
var hs, cv;
function wS() {
  if (cv) return hs;
  cv = 1;
  var e = bS(), t = xS(), r = bf(), n = ma();
  function i(a) {
    return r(a) ? e(n(a)) : t(a);
  }
  return hs = i, hs;
}
var ps, lv;
function It() {
  if (lv) return ps;
  lv = 1;
  var e = pS(), t = gS(), r = Ur(), n = ke(), i = wS();
  function a(o) {
    return typeof o == "function" ? o : o == null ? r : typeof o == "object" ? n(o) ? t(o[0], o[1]) : e(o) : i(o);
  }
  return ps = a, ps;
}
var vs, fv;
function Wb() {
  if (fv) return vs;
  fv = 1;
  function e(t, r, n, i) {
    for (var a = t.length, o = n + (i ? 1 : -1); i ? o-- : ++o < a; )
      if (r(t[o], o, t))
        return o;
    return -1;
  }
  return vs = e, vs;
}
var ys, dv;
function OS() {
  if (dv) return ys;
  dv = 1;
  function e(t) {
    return t !== t;
  }
  return ys = e, ys;
}
var ms, hv;
function _S() {
  if (hv) return ms;
  hv = 1;
  function e(t, r, n) {
    for (var i = n - 1, a = t.length; ++i < a; )
      if (t[i] === r)
        return i;
    return -1;
  }
  return ms = e, ms;
}
var gs, pv;
function SS() {
  if (pv) return gs;
  pv = 1;
  var e = Wb(), t = OS(), r = _S();
  function n(i, a, o) {
    return a === a ? r(i, a, o) : e(i, t, o);
  }
  return gs = n, gs;
}
var bs, vv;
function AS() {
  if (vv) return bs;
  vv = 1;
  var e = SS();
  function t(r, n) {
    var i = r == null ? 0 : r.length;
    return !!i && e(r, n, 0) > -1;
  }
  return bs = t, bs;
}
var xs, yv;
function PS() {
  if (yv) return xs;
  yv = 1;
  function e(t, r, n) {
    for (var i = -1, a = t == null ? 0 : t.length; ++i < a; )
      if (n(r, t[i]))
        return !0;
    return !1;
  }
  return xs = e, xs;
}
var ws, mv;
function TS() {
  if (mv) return ws;
  mv = 1;
  function e() {
  }
  return ws = e, ws;
}
var Os, gv;
function jS() {
  if (gv) return Os;
  gv = 1;
  var e = Fb(), t = TS(), r = $f(), n = 1 / 0, i = e && 1 / r(new e([, -0]))[1] == n ? function(a) {
    return new e(a);
  } : t;
  return Os = i, Os;
}
var _s, bv;
function ES() {
  if (bv) return _s;
  bv = 1;
  var e = Ib(), t = AS(), r = PS(), n = Nb(), i = jS(), a = $f(), o = 200;
  function u(s, c, f) {
    var l = -1, d = t, p = s.length, y = !0, v = [], h = v;
    if (f)
      y = !1, d = r;
    else if (p >= o) {
      var w = c ? null : i(s);
      if (w)
        return a(w);
      y = !1, d = n, h = new e();
    } else
      h = c ? [] : v;
    e:
      for (; ++l < p; ) {
        var b = s[l], x = c ? c(b) : b;
        if (b = f || b !== 0 ? b : 0, y && x === x) {
          for (var O = h.length; O--; )
            if (h[O] === x)
              continue e;
          c && h.push(x), v.push(b);
        } else d(h, x, f) || (h !== v && h.push(x), v.push(b));
      }
    return v;
  }
  return _s = u, _s;
}
var Ss, xv;
function MS() {
  if (xv) return Ss;
  xv = 1;
  var e = It(), t = ES();
  function r(n, i) {
    return n && n.length ? t(n, e(i, 2)) : [];
  }
  return Ss = r, Ss;
}
var CS = MS();
const wv = /* @__PURE__ */ ce(CS);
function Hb(e, t, r) {
  return t === !0 ? wv(e, r) : Z(t) ? wv(e, t) : e;
}
function br(e) {
  "@babel/helpers - typeof";
  return br = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, br(e);
}
var IS = ["ref"];
function Ov(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function st(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Ov(Object(r), !0).forEach(function(n) {
      _a(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Ov(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function $S(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function _v(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, Gb(n.key), n);
  }
}
function NS(e, t, r) {
  return t && _v(e.prototype, t), r && _v(e, r), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function kS(e, t, r) {
  return t = Si(t), DS(e, Kb() ? Reflect.construct(t, r || [], Si(e).constructor) : t.apply(e, r));
}
function DS(e, t) {
  if (t && (br(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return RS(e);
}
function RS(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Kb() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Kb = function() {
    return !!e;
  })();
}
function Si(e) {
  return Si = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, Si(e);
}
function LS(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && hl(e, t);
}
function hl(e, t) {
  return hl = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, hl(e, t);
}
function _a(e, t, r) {
  return t = Gb(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Gb(e) {
  var t = qS(e, "string");
  return br(t) == "symbol" ? t : t + "";
}
function qS(e, t) {
  if (br(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (br(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
function BS(e, t) {
  if (e == null) return {};
  var r = FS(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function FS(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function zS(e) {
  return e.value;
}
function US(e, t) {
  if (/* @__PURE__ */ T.isValidElement(e))
    return /* @__PURE__ */ T.cloneElement(e, t);
  if (typeof e == "function")
    return /* @__PURE__ */ T.createElement(e, t);
  t.ref;
  var r = BS(t, IS);
  return /* @__PURE__ */ T.createElement(If, r);
}
var Sv = 1, dr = /* @__PURE__ */ function(e) {
  function t() {
    var r;
    $S(this, t);
    for (var n = arguments.length, i = new Array(n), a = 0; a < n; a++)
      i[a] = arguments[a];
    return r = kS(this, t, [].concat(i)), _a(r, "lastBoundingBox", {
      width: -1,
      height: -1
    }), r;
  }
  return LS(t, e), NS(t, [{
    key: "componentDidMount",
    value: function() {
      this.updateBBox();
    }
  }, {
    key: "componentDidUpdate",
    value: function() {
      this.updateBBox();
    }
  }, {
    key: "getBBox",
    value: function() {
      if (this.wrapperNode && this.wrapperNode.getBoundingClientRect) {
        var n = this.wrapperNode.getBoundingClientRect();
        return n.height = this.wrapperNode.offsetHeight, n.width = this.wrapperNode.offsetWidth, n;
      }
      return null;
    }
  }, {
    key: "updateBBox",
    value: function() {
      var n = this.props.onBBoxUpdate, i = this.getBBox();
      i ? (Math.abs(i.width - this.lastBoundingBox.width) > Sv || Math.abs(i.height - this.lastBoundingBox.height) > Sv) && (this.lastBoundingBox.width = i.width, this.lastBoundingBox.height = i.height, n && n(i)) : (this.lastBoundingBox.width !== -1 || this.lastBoundingBox.height !== -1) && (this.lastBoundingBox.width = -1, this.lastBoundingBox.height = -1, n && n(null));
    }
  }, {
    key: "getBBoxSnapshot",
    value: function() {
      return this.lastBoundingBox.width >= 0 && this.lastBoundingBox.height >= 0 ? st({}, this.lastBoundingBox) : {
        width: 0,
        height: 0
      };
    }
  }, {
    key: "getDefaultPosition",
    value: function(n) {
      var i = this.props, a = i.layout, o = i.align, u = i.verticalAlign, s = i.margin, c = i.chartWidth, f = i.chartHeight, l, d;
      if (!n || (n.left === void 0 || n.left === null) && (n.right === void 0 || n.right === null))
        if (o === "center" && a === "vertical") {
          var p = this.getBBoxSnapshot();
          l = {
            left: ((c || 0) - p.width) / 2
          };
        } else
          l = o === "right" ? {
            right: s && s.right || 0
          } : {
            left: s && s.left || 0
          };
      if (!n || (n.top === void 0 || n.top === null) && (n.bottom === void 0 || n.bottom === null))
        if (u === "middle") {
          var y = this.getBBoxSnapshot();
          d = {
            top: ((f || 0) - y.height) / 2
          };
        } else
          d = u === "bottom" ? {
            bottom: s && s.bottom || 0
          } : {
            top: s && s.top || 0
          };
      return st(st({}, l), d);
    }
  }, {
    key: "render",
    value: function() {
      var n = this, i = this.props, a = i.content, o = i.width, u = i.height, s = i.wrapperStyle, c = i.payloadUniqBy, f = i.payload, l = st(st({
        position: "absolute",
        width: o || "auto",
        height: u || "auto"
      }, this.getDefaultPosition(s)), s);
      return /* @__PURE__ */ T.createElement("div", {
        className: "recharts-legend-wrapper",
        style: l,
        ref: function(p) {
          n.wrapperNode = p;
        }
      }, US(a, st(st({}, this.props), {}, {
        payload: Hb(f, c, zS)
      })));
    }
  }], [{
    key: "getWithHeight",
    value: function(n, i) {
      var a = st(st({}, this.defaultProps), n.props), o = a.layout;
      return o === "vertical" && q(n.props.height) ? {
        height: n.props.height
      } : o === "horizontal" ? {
        width: n.props.width || i
      } : null;
    }
  }]);
}(D.PureComponent);
_a(dr, "displayName", "Legend");
_a(dr, "defaultProps", {
  iconSize: 14,
  layout: "horizontal",
  align: "center",
  verticalAlign: "bottom"
});
var As, Av;
function WS() {
  if (Av) return As;
  Av = 1;
  var e = Yn(), t = Nf(), r = ke(), n = e ? e.isConcatSpreadable : void 0;
  function i(a) {
    return r(a) || t(a) || !!(n && a && a[n]);
  }
  return As = i, As;
}
var Ps, Pv;
function Vb() {
  if (Pv) return Ps;
  Pv = 1;
  var e = Db(), t = WS();
  function r(n, i, a, o, u) {
    var s = -1, c = n.length;
    for (a || (a = t), u || (u = []); ++s < c; ) {
      var f = n[s];
      i > 0 && a(f) ? i > 1 ? r(f, i - 1, a, o, u) : e(u, f) : o || (u[u.length] = f);
    }
    return u;
  }
  return Ps = r, Ps;
}
var Ts, Tv;
function HS() {
  if (Tv) return Ts;
  Tv = 1;
  function e(t) {
    return function(r, n, i) {
      for (var a = -1, o = Object(r), u = i(r), s = u.length; s--; ) {
        var c = u[t ? s : ++a];
        if (n(o[c], c, o) === !1)
          break;
      }
      return r;
    };
  }
  return Ts = e, Ts;
}
var js, jv;
function KS() {
  if (jv) return js;
  jv = 1;
  var e = HS(), t = e();
  return js = t, js;
}
var Es, Ev;
function Xb() {
  if (Ev) return Es;
  Ev = 1;
  var e = KS(), t = Oa();
  function r(n, i) {
    return n && e(n, i, t);
  }
  return Es = r, Es;
}
var Ms, Mv;
function GS() {
  if (Mv) return Ms;
  Mv = 1;
  var e = Qn();
  function t(r, n) {
    return function(i, a) {
      if (i == null)
        return i;
      if (!e(i))
        return r(i, a);
      for (var o = i.length, u = n ? o : -1, s = Object(i); (n ? u-- : ++u < o) && a(s[u], u, s) !== !1; )
        ;
      return i;
    };
  }
  return Ms = t, Ms;
}
var Cs, Cv;
function Lf() {
  if (Cv) return Cs;
  Cv = 1;
  var e = Xb(), t = GS(), r = t(e);
  return Cs = r, Cs;
}
var Is, Iv;
function Yb() {
  if (Iv) return Is;
  Iv = 1;
  var e = Lf(), t = Qn();
  function r(n, i) {
    var a = -1, o = t(n) ? Array(n.length) : [];
    return e(n, function(u, s, c) {
      o[++a] = i(u, s, c);
    }), o;
  }
  return Is = r, Is;
}
var $s, $v;
function VS() {
  if ($v) return $s;
  $v = 1;
  function e(t, r) {
    var n = t.length;
    for (t.sort(r); n--; )
      t[n] = t[n].value;
    return t;
  }
  return $s = e, $s;
}
var Ns, Nv;
function XS() {
  if (Nv) return Ns;
  Nv = 1;
  var e = Br();
  function t(r, n) {
    if (r !== n) {
      var i = r !== void 0, a = r === null, o = r === r, u = e(r), s = n !== void 0, c = n === null, f = n === n, l = e(n);
      if (!c && !l && !u && r > n || u && s && f && !c && !l || a && s && f || !i && f || !o)
        return 1;
      if (!a && !u && !l && r < n || l && i && o && !a && !u || c && i && o || !s && o || !f)
        return -1;
    }
    return 0;
  }
  return Ns = t, Ns;
}
var ks, kv;
function YS() {
  if (kv) return ks;
  kv = 1;
  var e = XS();
  function t(r, n, i) {
    for (var a = -1, o = r.criteria, u = n.criteria, s = o.length, c = i.length; ++a < s; ) {
      var f = e(o[a], u[a]);
      if (f) {
        if (a >= c)
          return f;
        var l = i[a];
        return f * (l == "desc" ? -1 : 1);
      }
    }
    return r.index - n.index;
  }
  return ks = t, ks;
}
var Ds, Dv;
function ZS() {
  if (Dv) return Ds;
  Dv = 1;
  var e = Sf(), t = Af(), r = It(), n = Yb(), i = VS(), a = Lb(), o = YS(), u = Ur(), s = ke();
  function c(f, l, d) {
    l.length ? l = e(l, function(v) {
      return s(v) ? function(h) {
        return t(h, v.length === 1 ? v[0] : v);
      } : v;
    }) : l = [u];
    var p = -1;
    l = e(l, a(r));
    var y = n(f, function(v, h, w) {
      var b = e(l, function(x) {
        return x(v);
      });
      return { criteria: b, index: ++p, value: v };
    });
    return i(y, function(v, h) {
      return o(v, h, d);
    });
  }
  return Ds = c, Ds;
}
var Rs, Rv;
function QS() {
  if (Rv) return Rs;
  Rv = 1;
  function e(t, r, n) {
    switch (n.length) {
      case 0:
        return t.call(r);
      case 1:
        return t.call(r, n[0]);
      case 2:
        return t.call(r, n[0], n[1]);
      case 3:
        return t.call(r, n[0], n[1], n[2]);
    }
    return t.apply(r, n);
  }
  return Rs = e, Rs;
}
var Ls, Lv;
function JS() {
  if (Lv) return Ls;
  Lv = 1;
  var e = QS(), t = Math.max;
  function r(n, i, a) {
    return i = t(i === void 0 ? n.length - 1 : i, 0), function() {
      for (var o = arguments, u = -1, s = t(o.length - i, 0), c = Array(s); ++u < s; )
        c[u] = o[i + u];
      u = -1;
      for (var f = Array(i + 1); ++u < i; )
        f[u] = o[u];
      return f[i] = a(c), e(n, this, f);
    };
  }
  return Ls = r, Ls;
}
var qs, qv;
function eA() {
  if (qv) return qs;
  qv = 1;
  function e(t) {
    return function() {
      return t;
    };
  }
  return qs = e, qs;
}
var Bs, Bv;
function Zb() {
  if (Bv) return Bs;
  Bv = 1;
  var e = Qt(), t = function() {
    try {
      var r = e(Object, "defineProperty");
      return r({}, "", {}), r;
    } catch {
    }
  }();
  return Bs = t, Bs;
}
var Fs, Fv;
function tA() {
  if (Fv) return Fs;
  Fv = 1;
  var e = eA(), t = Zb(), r = Ur(), n = t ? function(i, a) {
    return t(i, "toString", {
      configurable: !0,
      enumerable: !1,
      value: e(a),
      writable: !0
    });
  } : r;
  return Fs = n, Fs;
}
var zs, zv;
function rA() {
  if (zv) return zs;
  zv = 1;
  var e = 800, t = 16, r = Date.now;
  function n(i) {
    var a = 0, o = 0;
    return function() {
      var u = r(), s = t - (u - o);
      if (o = u, s > 0) {
        if (++a >= e)
          return arguments[0];
      } else
        a = 0;
      return i.apply(void 0, arguments);
    };
  }
  return zs = n, zs;
}
var Us, Uv;
function nA() {
  if (Uv) return Us;
  Uv = 1;
  var e = tA(), t = rA(), r = t(e);
  return Us = r, Us;
}
var Ws, Wv;
function iA() {
  if (Wv) return Ws;
  Wv = 1;
  var e = Ur(), t = JS(), r = nA();
  function n(i, a) {
    return r(t(i, a, e), i + "");
  }
  return Ws = n, Ws;
}
var Hs, Hv;
function Sa() {
  if (Hv) return Hs;
  Hv = 1;
  var e = wf(), t = Qn(), r = kf(), n = Ct();
  function i(a, o, u) {
    if (!n(u))
      return !1;
    var s = typeof o;
    return (s == "number" ? t(u) && r(o, u.length) : s == "string" && o in u) ? e(u[o], a) : !1;
  }
  return Hs = i, Hs;
}
var Ks, Kv;
function aA() {
  if (Kv) return Ks;
  Kv = 1;
  var e = Vb(), t = ZS(), r = iA(), n = Sa(), i = r(function(a, o) {
    if (a == null)
      return [];
    var u = o.length;
    return u > 1 && n(a, o[0], o[1]) ? o = [] : u > 2 && n(o[0], o[1], o[2]) && (o = [o[0]]), t(a, e(o, 1), []);
  });
  return Ks = i, Ks;
}
var oA = aA();
const qf = /* @__PURE__ */ ce(oA);
function bn(e) {
  "@babel/helpers - typeof";
  return bn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, bn(e);
}
function pl() {
  return pl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, pl.apply(this, arguments);
}
function uA(e, t) {
  return fA(e) || lA(e, t) || cA(e, t) || sA();
}
function sA() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function cA(e, t) {
  if (e) {
    if (typeof e == "string") return Gv(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Gv(e, t);
  }
}
function Gv(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function lA(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function fA(e) {
  if (Array.isArray(e)) return e;
}
function Vv(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Gs(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Vv(Object(r), !0).forEach(function(n) {
      dA(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Vv(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function dA(e, t, r) {
  return t = hA(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function hA(e) {
  var t = pA(e, "string");
  return bn(t) == "symbol" ? t : t + "";
}
function pA(e, t) {
  if (bn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (bn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function vA(e) {
  return Array.isArray(e) && _e(e[0]) && _e(e[1]) ? e.join(" ~ ") : e;
}
var yA = function(t) {
  var r = t.separator, n = r === void 0 ? " : " : r, i = t.contentStyle, a = i === void 0 ? {} : i, o = t.itemStyle, u = o === void 0 ? {} : o, s = t.labelStyle, c = s === void 0 ? {} : s, f = t.payload, l = t.formatter, d = t.itemSorter, p = t.wrapperClassName, y = t.labelClassName, v = t.label, h = t.labelFormatter, w = t.accessibilityLayer, b = w === void 0 ? !1 : w, x = function() {
    if (f && f.length) {
      var j = {
        padding: 0,
        margin: 0
      }, E = (d ? qf(f, d) : f).map(function(C, I) {
        if (C.type === "none")
          return null;
        var N = Gs({
          display: "block",
          paddingTop: 4,
          paddingBottom: 4,
          color: C.color || "#000"
        }, u), R = C.formatter || l || vA, B = C.value, F = C.name, K = B, V = F;
        if (R && K != null && V != null) {
          var W = R(B, F, C, I, f);
          if (Array.isArray(W)) {
            var X = uA(W, 2);
            K = X[0], V = X[1];
          } else
            K = W;
        }
        return (
          // eslint-disable-next-line react/no-array-index-key
          /* @__PURE__ */ T.createElement("li", {
            className: "recharts-tooltip-item",
            key: "tooltip-item-".concat(I),
            style: N
          }, _e(V) ? /* @__PURE__ */ T.createElement("span", {
            className: "recharts-tooltip-item-name"
          }, V) : null, _e(V) ? /* @__PURE__ */ T.createElement("span", {
            className: "recharts-tooltip-item-separator"
          }, n) : null, /* @__PURE__ */ T.createElement("span", {
            className: "recharts-tooltip-item-value"
          }, K), /* @__PURE__ */ T.createElement("span", {
            className: "recharts-tooltip-item-unit"
          }, C.unit || ""))
        );
      });
      return /* @__PURE__ */ T.createElement("ul", {
        className: "recharts-tooltip-item-list",
        style: j
      }, E);
    }
    return null;
  }, O = Gs({
    margin: 0,
    padding: 10,
    backgroundColor: "#fff",
    border: "1px solid #ccc",
    whiteSpace: "nowrap"
  }, a), m = Gs({
    margin: 0
  }, c), g = !ee(v), _ = g ? v : "", A = re("recharts-default-tooltip", p), P = re("recharts-tooltip-label", y);
  g && h && f !== void 0 && f !== null && (_ = h(v, f));
  var $ = b ? {
    role: "status",
    "aria-live": "assertive"
  } : {};
  return /* @__PURE__ */ T.createElement("div", pl({
    className: A,
    style: O
  }, $), /* @__PURE__ */ T.createElement("p", {
    className: P,
    style: m
  }, /* @__PURE__ */ T.isValidElement(_) ? _ : "".concat(_)), x());
};
function xn(e) {
  "@babel/helpers - typeof";
  return xn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, xn(e);
}
function oi(e, t, r) {
  return t = mA(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function mA(e) {
  var t = gA(e, "string");
  return xn(t) == "symbol" ? t : t + "";
}
function gA(e, t) {
  if (xn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (xn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Zr = "recharts-tooltip-wrapper", bA = {
  visibility: "hidden"
};
function xA(e) {
  var t = e.coordinate, r = e.translateX, n = e.translateY;
  return re(Zr, oi(oi(oi(oi({}, "".concat(Zr, "-right"), q(r) && t && q(t.x) && r >= t.x), "".concat(Zr, "-left"), q(r) && t && q(t.x) && r < t.x), "".concat(Zr, "-bottom"), q(n) && t && q(t.y) && n >= t.y), "".concat(Zr, "-top"), q(n) && t && q(t.y) && n < t.y));
}
function Xv(e) {
  var t = e.allowEscapeViewBox, r = e.coordinate, n = e.key, i = e.offsetTopLeft, a = e.position, o = e.reverseDirection, u = e.tooltipDimension, s = e.viewBox, c = e.viewBoxDimension;
  if (a && q(a[n]))
    return a[n];
  var f = r[n] - u - i, l = r[n] + i;
  if (t[n])
    return o[n] ? f : l;
  if (o[n]) {
    var d = f, p = s[n];
    return d < p ? Math.max(l, s[n]) : Math.max(f, s[n]);
  }
  var y = l + u, v = s[n] + c;
  return y > v ? Math.max(f, s[n]) : Math.max(l, s[n]);
}
function wA(e) {
  var t = e.translateX, r = e.translateY, n = e.useTranslate3d;
  return {
    transform: n ? "translate3d(".concat(t, "px, ").concat(r, "px, 0)") : "translate(".concat(t, "px, ").concat(r, "px)")
  };
}
function OA(e) {
  var t = e.allowEscapeViewBox, r = e.coordinate, n = e.offsetTopLeft, i = e.position, a = e.reverseDirection, o = e.tooltipBox, u = e.useTranslate3d, s = e.viewBox, c, f, l;
  return o.height > 0 && o.width > 0 && r ? (f = Xv({
    allowEscapeViewBox: t,
    coordinate: r,
    key: "x",
    offsetTopLeft: n,
    position: i,
    reverseDirection: a,
    tooltipDimension: o.width,
    viewBox: s,
    viewBoxDimension: s.width
  }), l = Xv({
    allowEscapeViewBox: t,
    coordinate: r,
    key: "y",
    offsetTopLeft: n,
    position: i,
    reverseDirection: a,
    tooltipDimension: o.height,
    viewBox: s,
    viewBoxDimension: s.height
  }), c = wA({
    translateX: f,
    translateY: l,
    useTranslate3d: u
  })) : c = bA, {
    cssProperties: c,
    cssClasses: xA({
      translateX: f,
      translateY: l,
      coordinate: r
    })
  };
}
function xr(e) {
  "@babel/helpers - typeof";
  return xr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, xr(e);
}
function Yv(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Zv(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Yv(Object(r), !0).forEach(function(n) {
      yl(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Yv(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function _A(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function SA(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, Jb(n.key), n);
  }
}
function AA(e, t, r) {
  return t && SA(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function PA(e, t, r) {
  return t = Ai(t), TA(e, Qb() ? Reflect.construct(t, r || [], Ai(e).constructor) : t.apply(e, r));
}
function TA(e, t) {
  if (t && (xr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return jA(e);
}
function jA(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Qb() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Qb = function() {
    return !!e;
  })();
}
function Ai(e) {
  return Ai = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, Ai(e);
}
function EA(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && vl(e, t);
}
function vl(e, t) {
  return vl = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, vl(e, t);
}
function yl(e, t, r) {
  return t = Jb(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Jb(e) {
  var t = MA(e, "string");
  return xr(t) == "symbol" ? t : t + "";
}
function MA(e, t) {
  if (xr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (xr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var Qv = 1, CA = /* @__PURE__ */ function(e) {
  function t() {
    var r;
    _A(this, t);
    for (var n = arguments.length, i = new Array(n), a = 0; a < n; a++)
      i[a] = arguments[a];
    return r = PA(this, t, [].concat(i)), yl(r, "state", {
      dismissed: !1,
      dismissedAtCoordinate: {
        x: 0,
        y: 0
      },
      lastBoundingBox: {
        width: -1,
        height: -1
      }
    }), yl(r, "handleKeyDown", function(o) {
      if (o.key === "Escape") {
        var u, s, c, f;
        r.setState({
          dismissed: !0,
          dismissedAtCoordinate: {
            x: (u = (s = r.props.coordinate) === null || s === void 0 ? void 0 : s.x) !== null && u !== void 0 ? u : 0,
            y: (c = (f = r.props.coordinate) === null || f === void 0 ? void 0 : f.y) !== null && c !== void 0 ? c : 0
          }
        });
      }
    }), r;
  }
  return EA(t, e), AA(t, [{
    key: "updateBBox",
    value: function() {
      if (this.wrapperNode && this.wrapperNode.getBoundingClientRect) {
        var n = this.wrapperNode.getBoundingClientRect();
        (Math.abs(n.width - this.state.lastBoundingBox.width) > Qv || Math.abs(n.height - this.state.lastBoundingBox.height) > Qv) && this.setState({
          lastBoundingBox: {
            width: n.width,
            height: n.height
          }
        });
      } else (this.state.lastBoundingBox.width !== -1 || this.state.lastBoundingBox.height !== -1) && this.setState({
        lastBoundingBox: {
          width: -1,
          height: -1
        }
      });
    }
  }, {
    key: "componentDidMount",
    value: function() {
      document.addEventListener("keydown", this.handleKeyDown), this.updateBBox();
    }
  }, {
    key: "componentWillUnmount",
    value: function() {
      document.removeEventListener("keydown", this.handleKeyDown);
    }
  }, {
    key: "componentDidUpdate",
    value: function() {
      var n, i;
      this.props.active && this.updateBBox(), this.state.dismissed && (((n = this.props.coordinate) === null || n === void 0 ? void 0 : n.x) !== this.state.dismissedAtCoordinate.x || ((i = this.props.coordinate) === null || i === void 0 ? void 0 : i.y) !== this.state.dismissedAtCoordinate.y) && (this.state.dismissed = !1);
    }
  }, {
    key: "render",
    value: function() {
      var n = this, i = this.props, a = i.active, o = i.allowEscapeViewBox, u = i.animationDuration, s = i.animationEasing, c = i.children, f = i.coordinate, l = i.hasPayload, d = i.isAnimationActive, p = i.offset, y = i.position, v = i.reverseDirection, h = i.useTranslate3d, w = i.viewBox, b = i.wrapperStyle, x = OA({
        allowEscapeViewBox: o,
        coordinate: f,
        offsetTopLeft: p,
        position: y,
        reverseDirection: v,
        tooltipBox: this.state.lastBoundingBox,
        useTranslate3d: h,
        viewBox: w
      }), O = x.cssClasses, m = x.cssProperties, g = Zv(Zv({
        transition: d && a ? "transform ".concat(u, "ms ").concat(s) : void 0
      }, m), {}, {
        pointerEvents: "none",
        visibility: !this.state.dismissed && a && l ? "visible" : "hidden",
        position: "absolute",
        top: 0,
        left: 0
      }, b);
      return (
        // This element allow listening to the `Escape` key.
        // See https://github.com/recharts/recharts/pull/2925
        /* @__PURE__ */ T.createElement("div", {
          tabIndex: -1,
          className: O,
          style: g,
          ref: function(A) {
            n.wrapperNode = A;
          }
        }, c)
      );
    }
  }]);
}(D.PureComponent), IA = function() {
  return !(typeof window < "u" && window.document && window.document.createElement && window.setTimeout);
}, Wr = {
  isSsr: IA()
};
function wr(e) {
  "@babel/helpers - typeof";
  return wr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, wr(e);
}
function Jv(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function ey(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Jv(Object(r), !0).forEach(function(n) {
      Bf(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Jv(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function $A(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function NA(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, t0(n.key), n);
  }
}
function kA(e, t, r) {
  return t && NA(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function DA(e, t, r) {
  return t = Pi(t), RA(e, e0() ? Reflect.construct(t, r || [], Pi(e).constructor) : t.apply(e, r));
}
function RA(e, t) {
  if (t && (wr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return LA(e);
}
function LA(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function e0() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (e0 = function() {
    return !!e;
  })();
}
function Pi(e) {
  return Pi = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, Pi(e);
}
function qA(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && ml(e, t);
}
function ml(e, t) {
  return ml = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, ml(e, t);
}
function Bf(e, t, r) {
  return t = t0(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function t0(e) {
  var t = BA(e, "string");
  return wr(t) == "symbol" ? t : t + "";
}
function BA(e, t) {
  if (wr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (wr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
function FA(e) {
  return e.dataKey;
}
function zA(e, t) {
  return /* @__PURE__ */ T.isValidElement(e) ? /* @__PURE__ */ T.cloneElement(e, t) : typeof e == "function" ? /* @__PURE__ */ T.createElement(e, t) : /* @__PURE__ */ T.createElement(yA, t);
}
var rt = /* @__PURE__ */ function(e) {
  function t() {
    return $A(this, t), DA(this, t, arguments);
  }
  return qA(t, e), kA(t, [{
    key: "render",
    value: function() {
      var n = this, i = this.props, a = i.active, o = i.allowEscapeViewBox, u = i.animationDuration, s = i.animationEasing, c = i.content, f = i.coordinate, l = i.filterNull, d = i.isAnimationActive, p = i.offset, y = i.payload, v = i.payloadUniqBy, h = i.position, w = i.reverseDirection, b = i.useTranslate3d, x = i.viewBox, O = i.wrapperStyle, m = y ?? [];
      l && m.length && (m = Hb(y.filter(function(_) {
        return _.value != null && (_.hide !== !0 || n.props.includeHidden);
      }), v, FA));
      var g = m.length > 0;
      return /* @__PURE__ */ T.createElement(CA, {
        allowEscapeViewBox: o,
        animationDuration: u,
        animationEasing: s,
        isAnimationActive: d,
        active: a,
        coordinate: f,
        hasPayload: g,
        offset: p,
        position: h,
        reverseDirection: w,
        useTranslate3d: b,
        viewBox: x,
        wrapperStyle: O
      }, zA(c, ey(ey({}, this.props), {}, {
        payload: m
      })));
    }
  }]);
}(D.PureComponent);
Bf(rt, "displayName", "Tooltip");
Bf(rt, "defaultProps", {
  accessibilityLayer: !1,
  allowEscapeViewBox: {
    x: !1,
    y: !1
  },
  animationDuration: 400,
  animationEasing: "ease",
  contentStyle: {},
  coordinate: {
    x: 0,
    y: 0
  },
  cursor: !0,
  cursorStyle: {},
  filterNull: !0,
  isAnimationActive: !Wr.isSsr,
  itemStyle: {},
  labelStyle: {},
  offset: 10,
  reverseDirection: {
    x: !1,
    y: !1
  },
  separator: " : ",
  trigger: "hover",
  useTranslate3d: !1,
  viewBox: {
    x: 0,
    y: 0,
    height: 0,
    width: 0
  },
  wrapperStyle: {}
});
var Vs, ty;
function UA() {
  if (ty) return Vs;
  ty = 1;
  var e = ut(), t = function() {
    return e.Date.now();
  };
  return Vs = t, Vs;
}
var Xs, ry;
function WA() {
  if (ry) return Xs;
  ry = 1;
  var e = /\s/;
  function t(r) {
    for (var n = r.length; n-- && e.test(r.charAt(n)); )
      ;
    return n;
  }
  return Xs = t, Xs;
}
var Ys, ny;
function HA() {
  if (ny) return Ys;
  ny = 1;
  var e = WA(), t = /^\s+/;
  function r(n) {
    return n && n.slice(0, e(n) + 1).replace(t, "");
  }
  return Ys = r, Ys;
}
var Zs, iy;
function r0() {
  if (iy) return Zs;
  iy = 1;
  var e = HA(), t = Ct(), r = Br(), n = NaN, i = /^[-+]0x[0-9a-f]+$/i, a = /^0b[01]+$/i, o = /^0o[0-7]+$/i, u = parseInt;
  function s(c) {
    if (typeof c == "number")
      return c;
    if (r(c))
      return n;
    if (t(c)) {
      var f = typeof c.valueOf == "function" ? c.valueOf() : c;
      c = t(f) ? f + "" : f;
    }
    if (typeof c != "string")
      return c === 0 ? c : +c;
    c = e(c);
    var l = a.test(c);
    return l || o.test(c) ? u(c.slice(2), l ? 2 : 8) : i.test(c) ? n : +c;
  }
  return Zs = s, Zs;
}
var Qs, ay;
function KA() {
  if (ay) return Qs;
  ay = 1;
  var e = Ct(), t = UA(), r = r0(), n = "Expected a function", i = Math.max, a = Math.min;
  function o(u, s, c) {
    var f, l, d, p, y, v, h = 0, w = !1, b = !1, x = !0;
    if (typeof u != "function")
      throw new TypeError(n);
    s = r(s) || 0, e(c) && (w = !!c.leading, b = "maxWait" in c, d = b ? i(r(c.maxWait) || 0, s) : d, x = "trailing" in c ? !!c.trailing : x);
    function O(E) {
      var C = f, I = l;
      return f = l = void 0, h = E, p = u.apply(I, C), p;
    }
    function m(E) {
      return h = E, y = setTimeout(A, s), w ? O(E) : p;
    }
    function g(E) {
      var C = E - v, I = E - h, N = s - C;
      return b ? a(N, d - I) : N;
    }
    function _(E) {
      var C = E - v, I = E - h;
      return v === void 0 || C >= s || C < 0 || b && I >= d;
    }
    function A() {
      var E = t();
      if (_(E))
        return P(E);
      y = setTimeout(A, g(E));
    }
    function P(E) {
      return y = void 0, x && f ? O(E) : (f = l = void 0, p);
    }
    function $() {
      y !== void 0 && clearTimeout(y), h = 0, f = v = l = y = void 0;
    }
    function M() {
      return y === void 0 ? p : P(t());
    }
    function j() {
      var E = t(), C = _(E);
      if (f = arguments, l = this, v = E, C) {
        if (y === void 0)
          return m(v);
        if (b)
          return clearTimeout(y), y = setTimeout(A, s), O(v);
      }
      return y === void 0 && (y = setTimeout(A, s)), p;
    }
    return j.cancel = $, j.flush = M, j;
  }
  return Qs = o, Qs;
}
var Js, oy;
function GA() {
  if (oy) return Js;
  oy = 1;
  var e = KA(), t = Ct(), r = "Expected a function";
  function n(i, a, o) {
    var u = !0, s = !0;
    if (typeof i != "function")
      throw new TypeError(r);
    return t(o) && (u = "leading" in o ? !!o.leading : u, s = "trailing" in o ? !!o.trailing : s), e(i, a, {
      leading: u,
      maxWait: a,
      trailing: s
    });
  }
  return Js = n, Js;
}
var VA = GA();
const n0 = /* @__PURE__ */ ce(VA);
function wn(e) {
  "@babel/helpers - typeof";
  return wn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, wn(e);
}
function uy(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function ui(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? uy(Object(r), !0).forEach(function(n) {
      XA(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : uy(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function XA(e, t, r) {
  return t = YA(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function YA(e) {
  var t = ZA(e, "string");
  return wn(t) == "symbol" ? t : t + "";
}
function ZA(e, t) {
  if (wn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (wn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function QA(e, t) {
  return rP(e) || tP(e, t) || eP(e, t) || JA();
}
function JA() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function eP(e, t) {
  if (e) {
    if (typeof e == "string") return sy(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return sy(e, t);
  }
}
function sy(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function tP(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function rP(e) {
  if (Array.isArray(e)) return e;
}
var nP = /* @__PURE__ */ D.forwardRef(function(e, t) {
  var r = e.aspect, n = e.initialDimension, i = n === void 0 ? {
    width: -1,
    height: -1
  } : n, a = e.width, o = a === void 0 ? "100%" : a, u = e.height, s = u === void 0 ? "100%" : u, c = e.minWidth, f = c === void 0 ? 0 : c, l = e.minHeight, d = e.maxHeight, p = e.children, y = e.debounce, v = y === void 0 ? 0 : y, h = e.id, w = e.className, b = e.onResize, x = e.style, O = x === void 0 ? {} : x, m = D.useRef(null), g = D.useRef();
  g.current = b, D.useImperativeHandle(t, function() {
    return Object.defineProperty(m.current, "current", {
      get: function() {
        return console.warn("The usage of ref.current.current is deprecated and will no longer be supported."), m.current;
      },
      configurable: !0
    });
  });
  var _ = D.useState({
    containerWidth: i.width,
    containerHeight: i.height
  }), A = QA(_, 2), P = A[0], $ = A[1], M = D.useCallback(function(E, C) {
    $(function(I) {
      var N = Math.round(E), R = Math.round(C);
      return I.containerWidth === N && I.containerHeight === R ? I : {
        containerWidth: N,
        containerHeight: R
      };
    });
  }, []);
  D.useEffect(function() {
    var E = function(F) {
      var K, V = F[0].contentRect, W = V.width, X = V.height;
      M(W, X), (K = g.current) === null || K === void 0 || K.call(g, W, X);
    };
    v > 0 && (E = n0(E, v, {
      trailing: !0,
      leading: !1
    }));
    var C = new ResizeObserver(E), I = m.current.getBoundingClientRect(), N = I.width, R = I.height;
    return M(N, R), C.observe(m.current), function() {
      C.disconnect();
    };
  }, [M, v]);
  var j = D.useMemo(function() {
    var E = P.containerWidth, C = P.containerHeight;
    if (E < 0 || C < 0)
      return null;
    ht(zt(o) || zt(s), `The width(%s) and height(%s) are both fixed numbers,
       maybe you don't need to use a ResponsiveContainer.`, o, s), ht(!r || r > 0, "The aspect(%s) must be greater than zero.", r);
    var I = zt(o) ? E : o, N = zt(s) ? C : s;
    r && r > 0 && (I ? N = I / r : N && (I = N * r), d && N > d && (N = d)), ht(I > 0 || N > 0, `The width(%s) and height(%s) of chart should be greater than 0,
       please check the style of container, or the props width(%s) and height(%s),
       or add a minWidth(%s) or minHeight(%s) or use aspect(%s) to control the
       height and width.`, I, N, o, s, f, l, r);
    var R = !Array.isArray(p) && dt(p.type).endsWith("Chart");
    return T.Children.map(p, function(B) {
      return /* @__PURE__ */ T.isValidElement(B) ? /* @__PURE__ */ D.cloneElement(B, ui({
        width: I,
        height: N
      }, R ? {
        style: ui({
          height: "100%",
          width: "100%",
          maxHeight: N,
          maxWidth: I
        }, B.props.style)
      } : {})) : B;
    });
  }, [r, p, s, d, l, f, P, o]);
  return /* @__PURE__ */ T.createElement("div", {
    id: h ? "".concat(h) : void 0,
    className: re("recharts-responsive-container", w),
    style: ui(ui({}, O), {}, {
      width: o,
      height: s,
      minWidth: f,
      minHeight: l,
      maxHeight: d
    }),
    ref: m
  }, j);
}), i0 = function(t) {
  return null;
};
i0.displayName = "Cell";
function On(e) {
  "@babel/helpers - typeof";
  return On = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, On(e);
}
function cy(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function gl(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? cy(Object(r), !0).forEach(function(n) {
      iP(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : cy(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function iP(e, t, r) {
  return t = aP(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function aP(e) {
  var t = oP(e, "string");
  return On(t) == "symbol" ? t : t + "";
}
function oP(e, t) {
  if (On(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (On(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var nr = {
  widthCache: {},
  cacheCount: 0
}, uP = 2e3, sP = {
  position: "absolute",
  top: "-20000px",
  left: 0,
  padding: 0,
  margin: 0,
  border: "none",
  whiteSpace: "pre"
}, ly = "recharts_measurement_span";
function cP(e) {
  var t = gl({}, e);
  return Object.keys(t).forEach(function(r) {
    t[r] || delete t[r];
  }), t;
}
var cn = function(t) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
  if (t == null || Wr.isSsr)
    return {
      width: 0,
      height: 0
    };
  var n = cP(r), i = JSON.stringify({
    text: t,
    copyStyle: n
  });
  if (nr.widthCache[i])
    return nr.widthCache[i];
  try {
    var a = document.getElementById(ly);
    a || (a = document.createElement("span"), a.setAttribute("id", ly), a.setAttribute("aria-hidden", "true"), document.body.appendChild(a));
    var o = gl(gl({}, sP), n);
    Object.assign(a.style, o), a.textContent = "".concat(t);
    var u = a.getBoundingClientRect(), s = {
      width: u.width,
      height: u.height
    };
    return nr.widthCache[i] = s, ++nr.cacheCount > uP && (nr.cacheCount = 0, nr.widthCache = {}), s;
  } catch {
    return {
      width: 0,
      height: 0
    };
  }
}, lP = function(t) {
  return {
    top: t.top + window.scrollY - document.documentElement.clientTop,
    left: t.left + window.scrollX - document.documentElement.clientLeft
  };
};
function _n(e) {
  "@babel/helpers - typeof";
  return _n = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, _n(e);
}
function Ti(e, t) {
  return pP(e) || hP(e, t) || dP(e, t) || fP();
}
function fP() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function dP(e, t) {
  if (e) {
    if (typeof e == "string") return fy(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return fy(e, t);
  }
}
function fy(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function hP(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t === 0) {
        if (Object(r) !== r) return;
        s = !1;
      } else for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function pP(e) {
  if (Array.isArray(e)) return e;
}
function vP(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function dy(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, mP(n.key), n);
  }
}
function yP(e, t, r) {
  return t && dy(e.prototype, t), r && dy(e, r), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function mP(e) {
  var t = gP(e, "string");
  return _n(t) == "symbol" ? t : t + "";
}
function gP(e, t) {
  if (_n(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (_n(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var hy = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([*/])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/, py = /(-?\d+(?:\.\d+)?[a-zA-Z%]*)([+-])(-?\d+(?:\.\d+)?[a-zA-Z%]*)/, bP = /^px|cm|vh|vw|em|rem|%|mm|in|pt|pc|ex|ch|vmin|vmax|Q$/, xP = /(-?\d+(?:\.\d+)?)([a-zA-Z%]+)?/, a0 = {
  cm: 96 / 2.54,
  mm: 96 / 25.4,
  pt: 96 / 72,
  pc: 96 / 6,
  in: 96,
  Q: 96 / (2.54 * 40),
  px: 1
}, wP = Object.keys(a0), sr = "NaN";
function OP(e, t) {
  return e * a0[t];
}
var si = /* @__PURE__ */ function() {
  function e(t, r) {
    vP(this, e), this.num = t, this.unit = r, this.num = t, this.unit = r, Number.isNaN(t) && (this.unit = ""), r !== "" && !bP.test(r) && (this.num = NaN, this.unit = ""), wP.includes(r) && (this.num = OP(t, r), this.unit = "px");
  }
  return yP(e, [{
    key: "add",
    value: function(r) {
      return this.unit !== r.unit ? new e(NaN, "") : new e(this.num + r.num, this.unit);
    }
  }, {
    key: "subtract",
    value: function(r) {
      return this.unit !== r.unit ? new e(NaN, "") : new e(this.num - r.num, this.unit);
    }
  }, {
    key: "multiply",
    value: function(r) {
      return this.unit !== "" && r.unit !== "" && this.unit !== r.unit ? new e(NaN, "") : new e(this.num * r.num, this.unit || r.unit);
    }
  }, {
    key: "divide",
    value: function(r) {
      return this.unit !== "" && r.unit !== "" && this.unit !== r.unit ? new e(NaN, "") : new e(this.num / r.num, this.unit || r.unit);
    }
  }, {
    key: "toString",
    value: function() {
      return "".concat(this.num).concat(this.unit);
    }
  }, {
    key: "isNaN",
    value: function() {
      return Number.isNaN(this.num);
    }
  }], [{
    key: "parse",
    value: function(r) {
      var n, i = (n = xP.exec(r)) !== null && n !== void 0 ? n : [], a = Ti(i, 3), o = a[1], u = a[2];
      return new e(parseFloat(o), u ?? "");
    }
  }]);
}();
function o0(e) {
  if (e.includes(sr))
    return sr;
  for (var t = e; t.includes("*") || t.includes("/"); ) {
    var r, n = (r = hy.exec(t)) !== null && r !== void 0 ? r : [], i = Ti(n, 4), a = i[1], o = i[2], u = i[3], s = si.parse(a ?? ""), c = si.parse(u ?? ""), f = o === "*" ? s.multiply(c) : s.divide(c);
    if (f.isNaN())
      return sr;
    t = t.replace(hy, f.toString());
  }
  for (; t.includes("+") || /.-\d+(?:\.\d+)?/.test(t); ) {
    var l, d = (l = py.exec(t)) !== null && l !== void 0 ? l : [], p = Ti(d, 4), y = p[1], v = p[2], h = p[3], w = si.parse(y ?? ""), b = si.parse(h ?? ""), x = v === "+" ? w.add(b) : w.subtract(b);
    if (x.isNaN())
      return sr;
    t = t.replace(py, x.toString());
  }
  return t;
}
var vy = /\(([^()]*)\)/;
function _P(e) {
  for (var t = e; t.includes("("); ) {
    var r = vy.exec(t), n = Ti(r, 2), i = n[1];
    t = t.replace(vy, o0(i));
  }
  return t;
}
function SP(e) {
  var t = e.replace(/\s+/g, "");
  return t = _P(t), t = o0(t), t;
}
function AP(e) {
  try {
    return SP(e);
  } catch {
    return sr;
  }
}
function ec(e) {
  var t = AP(e.slice(5, -1));
  return t === sr ? "" : t;
}
var PP = ["x", "y", "lineHeight", "capHeight", "scaleToFit", "textAnchor", "verticalAnchor", "fill"], TP = ["dx", "dy", "angle", "className", "breakAll"];
function bl() {
  return bl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, bl.apply(this, arguments);
}
function yy(e, t) {
  if (e == null) return {};
  var r = jP(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function jP(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function my(e, t) {
  return IP(e) || CP(e, t) || MP(e, t) || EP();
}
function EP() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function MP(e, t) {
  if (e) {
    if (typeof e == "string") return gy(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return gy(e, t);
  }
}
function gy(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function CP(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t === 0) {
        if (Object(r) !== r) return;
        s = !1;
      } else for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function IP(e) {
  if (Array.isArray(e)) return e;
}
var u0 = /[ \f\n\r\t\v\u2028\u2029]+/, s0 = function(t) {
  var r = t.children, n = t.breakAll, i = t.style;
  try {
    var a = [];
    ee(r) || (n ? a = r.toString().split("") : a = r.toString().split(u0));
    var o = a.map(function(s) {
      return {
        word: s,
        width: cn(s, i).width
      };
    }), u = n ? 0 : cn(" ", i).width;
    return {
      wordsWithComputedWidth: o,
      spaceWidth: u
    };
  } catch {
    return null;
  }
}, $P = function(t, r, n, i, a) {
  var o = t.maxLines, u = t.children, s = t.style, c = t.breakAll, f = q(o), l = u, d = function() {
    var I = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : [];
    return I.reduce(function(N, R) {
      var B = R.word, F = R.width, K = N[N.length - 1];
      if (K && (i == null || a || K.width + F + n < Number(i)))
        K.words.push(B), K.width += F + n;
      else {
        var V = {
          words: [B],
          width: F
        };
        N.push(V);
      }
      return N;
    }, []);
  }, p = d(r), y = function(I) {
    return I.reduce(function(N, R) {
      return N.width > R.width ? N : R;
    });
  };
  if (!f)
    return p;
  for (var v = "…", h = function(I) {
    var N = l.slice(0, I), R = s0({
      breakAll: c,
      style: s,
      children: N + v
    }).wordsWithComputedWidth, B = d(R), F = B.length > o || y(B).width > Number(i);
    return [F, B];
  }, w = 0, b = l.length - 1, x = 0, O; w <= b && x <= l.length - 1; ) {
    var m = Math.floor((w + b) / 2), g = m - 1, _ = h(g), A = my(_, 2), P = A[0], $ = A[1], M = h(m), j = my(M, 1), E = j[0];
    if (!P && !E && (w = m + 1), P && E && (b = m - 1), !P && E) {
      O = $;
      break;
    }
    x++;
  }
  return O || p;
}, by = function(t) {
  var r = ee(t) ? [] : t.toString().split(u0);
  return [{
    words: r
  }];
}, NP = function(t) {
  var r = t.width, n = t.scaleToFit, i = t.children, a = t.style, o = t.breakAll, u = t.maxLines;
  if ((r || n) && !Wr.isSsr) {
    var s, c, f = s0({
      breakAll: o,
      children: i,
      style: a
    });
    if (f) {
      var l = f.wordsWithComputedWidth, d = f.spaceWidth;
      s = l, c = d;
    } else
      return by(i);
    return $P({
      breakAll: o,
      children: i,
      maxLines: u,
      style: a
    }, s, c, r, n);
  }
  return by(i);
}, xy = "#808080", ji = function(t) {
  var r = t.x, n = r === void 0 ? 0 : r, i = t.y, a = i === void 0 ? 0 : i, o = t.lineHeight, u = o === void 0 ? "1em" : o, s = t.capHeight, c = s === void 0 ? "0.71em" : s, f = t.scaleToFit, l = f === void 0 ? !1 : f, d = t.textAnchor, p = d === void 0 ? "start" : d, y = t.verticalAnchor, v = y === void 0 ? "end" : y, h = t.fill, w = h === void 0 ? xy : h, b = yy(t, PP), x = D.useMemo(function() {
    return NP({
      breakAll: b.breakAll,
      children: b.children,
      maxLines: b.maxLines,
      scaleToFit: l,
      style: b.style,
      width: b.width
    });
  }, [b.breakAll, b.children, b.maxLines, l, b.style, b.width]), O = b.dx, m = b.dy, g = b.angle, _ = b.className, A = b.breakAll, P = yy(b, TP);
  if (!_e(n) || !_e(a))
    return null;
  var $ = n + (q(O) ? O : 0), M = a + (q(m) ? m : 0), j;
  switch (v) {
    case "start":
      j = ec("calc(".concat(c, ")"));
      break;
    case "middle":
      j = ec("calc(".concat((x.length - 1) / 2, " * -").concat(u, " + (").concat(c, " / 2))"));
      break;
    default:
      j = ec("calc(".concat(x.length - 1, " * -").concat(u, ")"));
      break;
  }
  var E = [];
  if (l) {
    var C = x[0].width, I = b.width;
    E.push("scale(".concat((q(I) ? I / C : 1) / C, ")"));
  }
  return g && E.push("rotate(".concat(g, ", ").concat($, ", ").concat(M, ")")), E.length && (P.transform = E.join(" ")), /* @__PURE__ */ T.createElement("text", bl({}, J(P, !0), {
    x: $,
    y: M,
    className: re("recharts-text", _),
    textAnchor: p,
    fill: w.includes("url") ? xy : w
  }), x.map(function(N, R) {
    var B = N.words.join(A ? "" : " ");
    return (
      // duplicate words will cause duplicate keys
      // eslint-disable-next-line react/no-array-index-key
      /* @__PURE__ */ T.createElement("tspan", {
        x: $,
        dy: R === 0 ? j : u,
        key: "".concat(B, "-").concat(R)
      }, B)
    );
  }));
};
function Et(e, t) {
  return e == null || t == null ? NaN : e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function kP(e, t) {
  return e == null || t == null ? NaN : t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN;
}
function Ff(e) {
  let t, r, n;
  e.length !== 2 ? (t = Et, r = (u, s) => Et(e(u), s), n = (u, s) => e(u) - s) : (t = e === Et || e === kP ? e : DP, r = e, n = e);
  function i(u, s, c = 0, f = u.length) {
    if (c < f) {
      if (t(s, s) !== 0) return f;
      do {
        const l = c + f >>> 1;
        r(u[l], s) < 0 ? c = l + 1 : f = l;
      } while (c < f);
    }
    return c;
  }
  function a(u, s, c = 0, f = u.length) {
    if (c < f) {
      if (t(s, s) !== 0) return f;
      do {
        const l = c + f >>> 1;
        r(u[l], s) <= 0 ? c = l + 1 : f = l;
      } while (c < f);
    }
    return c;
  }
  function o(u, s, c = 0, f = u.length) {
    const l = i(u, s, c, f - 1);
    return l > c && n(u[l - 1], s) > -n(u[l], s) ? l - 1 : l;
  }
  return { left: i, center: o, right: a };
}
function DP() {
  return 0;
}
function c0(e) {
  return e === null ? NaN : +e;
}
function* RP(e, t) {
  for (let r of e)
    r != null && (r = +r) >= r && (yield r);
}
const LP = Ff(Et), Jn = LP.right;
Ff(c0).center;
class wy extends Map {
  constructor(t, r = FP) {
    if (super(), Object.defineProperties(this, { _intern: { value: /* @__PURE__ */ new Map() }, _key: { value: r } }), t != null) for (const [n, i] of t) this.set(n, i);
  }
  get(t) {
    return super.get(Oy(this, t));
  }
  has(t) {
    return super.has(Oy(this, t));
  }
  set(t, r) {
    return super.set(qP(this, t), r);
  }
  delete(t) {
    return super.delete(BP(this, t));
  }
}
function Oy({ _intern: e, _key: t }, r) {
  const n = t(r);
  return e.has(n) ? e.get(n) : r;
}
function qP({ _intern: e, _key: t }, r) {
  const n = t(r);
  return e.has(n) ? e.get(n) : (e.set(n, r), r);
}
function BP({ _intern: e, _key: t }, r) {
  const n = t(r);
  return e.has(n) && (r = e.get(n), e.delete(n)), r;
}
function FP(e) {
  return e !== null && typeof e == "object" ? e.valueOf() : e;
}
function zP(e = Et) {
  if (e === Et) return l0;
  if (typeof e != "function") throw new TypeError("compare is not a function");
  return (t, r) => {
    const n = e(t, r);
    return n || n === 0 ? n : (e(r, r) === 0) - (e(t, t) === 0);
  };
}
function l0(e, t) {
  return (e == null || !(e >= e)) - (t == null || !(t >= t)) || (e < t ? -1 : e > t ? 1 : 0);
}
const UP = Math.sqrt(50), WP = Math.sqrt(10), HP = Math.sqrt(2);
function Ei(e, t, r) {
  const n = (t - e) / Math.max(0, r), i = Math.floor(Math.log10(n)), a = n / Math.pow(10, i), o = a >= UP ? 10 : a >= WP ? 5 : a >= HP ? 2 : 1;
  let u, s, c;
  return i < 0 ? (c = Math.pow(10, -i) / o, u = Math.round(e * c), s = Math.round(t * c), u / c < e && ++u, s / c > t && --s, c = -c) : (c = Math.pow(10, i) * o, u = Math.round(e / c), s = Math.round(t / c), u * c < e && ++u, s * c > t && --s), s < u && 0.5 <= r && r < 2 ? Ei(e, t, r * 2) : [u, s, c];
}
function xl(e, t, r) {
  if (t = +t, e = +e, r = +r, !(r > 0)) return [];
  if (e === t) return [e];
  const n = t < e, [i, a, o] = n ? Ei(t, e, r) : Ei(e, t, r);
  if (!(a >= i)) return [];
  const u = a - i + 1, s = new Array(u);
  if (n)
    if (o < 0) for (let c = 0; c < u; ++c) s[c] = (a - c) / -o;
    else for (let c = 0; c < u; ++c) s[c] = (a - c) * o;
  else if (o < 0) for (let c = 0; c < u; ++c) s[c] = (i + c) / -o;
  else for (let c = 0; c < u; ++c) s[c] = (i + c) * o;
  return s;
}
function wl(e, t, r) {
  return t = +t, e = +e, r = +r, Ei(e, t, r)[2];
}
function Ol(e, t, r) {
  t = +t, e = +e, r = +r;
  const n = t < e, i = n ? wl(t, e, r) : wl(e, t, r);
  return (n ? -1 : 1) * (i < 0 ? 1 / -i : i);
}
function _y(e, t) {
  let r;
  for (const n of e)
    n != null && (r < n || r === void 0 && n >= n) && (r = n);
  return r;
}
function Sy(e, t) {
  let r;
  for (const n of e)
    n != null && (r > n || r === void 0 && n >= n) && (r = n);
  return r;
}
function f0(e, t, r = 0, n = 1 / 0, i) {
  if (t = Math.floor(t), r = Math.floor(Math.max(0, r)), n = Math.floor(Math.min(e.length - 1, n)), !(r <= t && t <= n)) return e;
  for (i = i === void 0 ? l0 : zP(i); n > r; ) {
    if (n - r > 600) {
      const s = n - r + 1, c = t - r + 1, f = Math.log(s), l = 0.5 * Math.exp(2 * f / 3), d = 0.5 * Math.sqrt(f * l * (s - l) / s) * (c - s / 2 < 0 ? -1 : 1), p = Math.max(r, Math.floor(t - c * l / s + d)), y = Math.min(n, Math.floor(t + (s - c) * l / s + d));
      f0(e, t, p, y, i);
    }
    const a = e[t];
    let o = r, u = n;
    for (Qr(e, r, t), i(e[n], a) > 0 && Qr(e, r, n); o < u; ) {
      for (Qr(e, o, u), ++o, --u; i(e[o], a) < 0; ) ++o;
      for (; i(e[u], a) > 0; ) --u;
    }
    i(e[r], a) === 0 ? Qr(e, r, u) : (++u, Qr(e, u, n)), u <= t && (r = u + 1), t <= u && (n = u - 1);
  }
  return e;
}
function Qr(e, t, r) {
  const n = e[t];
  e[t] = e[r], e[r] = n;
}
function KP(e, t, r) {
  if (e = Float64Array.from(RP(e)), !(!(n = e.length) || isNaN(t = +t))) {
    if (t <= 0 || n < 2) return Sy(e);
    if (t >= 1) return _y(e);
    var n, i = (n - 1) * t, a = Math.floor(i), o = _y(f0(e, a).subarray(0, a + 1)), u = Sy(e.subarray(a + 1));
    return o + (u - o) * (i - a);
  }
}
function GP(e, t, r = c0) {
  if (!(!(n = e.length) || isNaN(t = +t))) {
    if (t <= 0 || n < 2) return +r(e[0], 0, e);
    if (t >= 1) return +r(e[n - 1], n - 1, e);
    var n, i = (n - 1) * t, a = Math.floor(i), o = +r(e[a], a, e), u = +r(e[a + 1], a + 1, e);
    return o + (u - o) * (i - a);
  }
}
function VP(e, t, r) {
  e = +e, t = +t, r = (i = arguments.length) < 2 ? (t = e, e = 0, 1) : i < 3 ? 1 : +r;
  for (var n = -1, i = Math.max(0, Math.ceil((t - e) / r)) | 0, a = new Array(i); ++n < i; )
    a[n] = e + n * r;
  return a;
}
function Xe(e, t) {
  switch (arguments.length) {
    case 0:
      break;
    case 1:
      this.range(e);
      break;
    default:
      this.range(t).domain(e);
      break;
  }
  return this;
}
function Ot(e, t) {
  switch (arguments.length) {
    case 0:
      break;
    case 1: {
      typeof e == "function" ? this.interpolator(e) : this.range(e);
      break;
    }
    default: {
      this.domain(e), typeof t == "function" ? this.interpolator(t) : this.range(t);
      break;
    }
  }
  return this;
}
const _l = Symbol("implicit");
function zf() {
  var e = new wy(), t = [], r = [], n = _l;
  function i(a) {
    let o = e.get(a);
    if (o === void 0) {
      if (n !== _l) return n;
      e.set(a, o = t.push(a) - 1);
    }
    return r[o % r.length];
  }
  return i.domain = function(a) {
    if (!arguments.length) return t.slice();
    t = [], e = new wy();
    for (const o of a)
      e.has(o) || e.set(o, t.push(o) - 1);
    return i;
  }, i.range = function(a) {
    return arguments.length ? (r = Array.from(a), i) : r.slice();
  }, i.unknown = function(a) {
    return arguments.length ? (n = a, i) : n;
  }, i.copy = function() {
    return zf(t, r).unknown(n);
  }, Xe.apply(i, arguments), i;
}
function Sn() {
  var e = zf().unknown(void 0), t = e.domain, r = e.range, n = 0, i = 1, a, o, u = !1, s = 0, c = 0, f = 0.5;
  delete e.unknown;
  function l() {
    var d = t().length, p = i < n, y = p ? i : n, v = p ? n : i;
    a = (v - y) / Math.max(1, d - s + c * 2), u && (a = Math.floor(a)), y += (v - y - a * (d - s)) * f, o = a * (1 - s), u && (y = Math.round(y), o = Math.round(o));
    var h = VP(d).map(function(w) {
      return y + a * w;
    });
    return r(p ? h.reverse() : h);
  }
  return e.domain = function(d) {
    return arguments.length ? (t(d), l()) : t();
  }, e.range = function(d) {
    return arguments.length ? ([n, i] = d, n = +n, i = +i, l()) : [n, i];
  }, e.rangeRound = function(d) {
    return [n, i] = d, n = +n, i = +i, u = !0, l();
  }, e.bandwidth = function() {
    return o;
  }, e.step = function() {
    return a;
  }, e.round = function(d) {
    return arguments.length ? (u = !!d, l()) : u;
  }, e.padding = function(d) {
    return arguments.length ? (s = Math.min(1, c = +d), l()) : s;
  }, e.paddingInner = function(d) {
    return arguments.length ? (s = Math.min(1, d), l()) : s;
  }, e.paddingOuter = function(d) {
    return arguments.length ? (c = +d, l()) : c;
  }, e.align = function(d) {
    return arguments.length ? (f = Math.max(0, Math.min(1, d)), l()) : f;
  }, e.copy = function() {
    return Sn(t(), [n, i]).round(u).paddingInner(s).paddingOuter(c).align(f);
  }, Xe.apply(l(), arguments);
}
function d0(e) {
  var t = e.copy;
  return e.padding = e.paddingOuter, delete e.paddingInner, delete e.paddingOuter, e.copy = function() {
    return d0(t());
  }, e;
}
function ln() {
  return d0(Sn.apply(null, arguments).paddingInner(1));
}
function XP(e) {
  return function() {
    return e;
  };
}
function Mi(e) {
  return +e;
}
var Ay = [0, 1];
function Ie(e) {
  return e;
}
function Sl(e, t) {
  return (t -= e = +e) ? function(r) {
    return (r - e) / t;
  } : XP(isNaN(t) ? NaN : 0.5);
}
function YP(e, t) {
  var r;
  return e > t && (r = e, e = t, t = r), function(n) {
    return Math.max(e, Math.min(t, n));
  };
}
function ZP(e, t, r) {
  var n = e[0], i = e[1], a = t[0], o = t[1];
  return i < n ? (n = Sl(i, n), a = r(o, a)) : (n = Sl(n, i), a = r(a, o)), function(u) {
    return a(n(u));
  };
}
function QP(e, t, r) {
  var n = Math.min(e.length, t.length) - 1, i = new Array(n), a = new Array(n), o = -1;
  for (e[n] < e[0] && (e = e.slice().reverse(), t = t.slice().reverse()); ++o < n; )
    i[o] = Sl(e[o], e[o + 1]), a[o] = r(t[o], t[o + 1]);
  return function(u) {
    var s = Jn(e, u, 1, n) - 1;
    return a[s](i[s](u));
  };
}
function ei(e, t) {
  return t.domain(e.domain()).range(e.range()).interpolate(e.interpolate()).clamp(e.clamp()).unknown(e.unknown());
}
function Aa() {
  var e = Ay, t = Ay, r = qr, n, i, a, o = Ie, u, s, c;
  function f() {
    var d = Math.min(e.length, t.length);
    return o !== Ie && (o = YP(e[0], e[d - 1])), u = d > 2 ? QP : ZP, s = c = null, l;
  }
  function l(d) {
    return d == null || isNaN(d = +d) ? a : (s || (s = u(e.map(n), t, r)))(n(o(d)));
  }
  return l.invert = function(d) {
    return o(i((c || (c = u(t, e.map(n), Hc)))(d)));
  }, l.domain = function(d) {
    return arguments.length ? (e = Array.from(d, Mi), f()) : e.slice();
  }, l.range = function(d) {
    return arguments.length ? (t = Array.from(d), f()) : t.slice();
  }, l.rangeRound = function(d) {
    return t = Array.from(d), r = gf, f();
  }, l.clamp = function(d) {
    return arguments.length ? (o = d ? !0 : Ie, f()) : o !== Ie;
  }, l.interpolate = function(d) {
    return arguments.length ? (r = d, f()) : r;
  }, l.unknown = function(d) {
    return arguments.length ? (a = d, l) : a;
  }, function(d, p) {
    return n = d, i = p, f();
  };
}
function Uf() {
  return Aa()(Ie, Ie);
}
function JP(e) {
  return Math.abs(e = Math.round(e)) >= 1e21 ? e.toLocaleString("en").replace(/,/g, "") : e.toString(10);
}
function Ci(e, t) {
  if (!isFinite(e) || e === 0) return null;
  var r = (e = t ? e.toExponential(t - 1) : e.toExponential()).indexOf("e"), n = e.slice(0, r);
  return [
    n.length > 1 ? n[0] + n.slice(2) : n,
    +e.slice(r + 1)
  ];
}
function Or(e) {
  return e = Ci(Math.abs(e)), e ? e[1] : NaN;
}
function eT(e, t) {
  return function(r, n) {
    for (var i = r.length, a = [], o = 0, u = e[0], s = 0; i > 0 && u > 0 && (s + u + 1 > n && (u = Math.max(1, n - s)), a.push(r.substring(i -= u, i + u)), !((s += u + 1) > n)); )
      u = e[o = (o + 1) % e.length];
    return a.reverse().join(t);
  };
}
function tT(e) {
  return function(t) {
    return t.replace(/[0-9]/g, function(r) {
      return e[+r];
    });
  };
}
var rT = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;
function An(e) {
  if (!(t = rT.exec(e))) throw new Error("invalid format: " + e);
  var t;
  return new Wf({
    fill: t[1],
    align: t[2],
    sign: t[3],
    symbol: t[4],
    zero: t[5],
    width: t[6],
    comma: t[7],
    precision: t[8] && t[8].slice(1),
    trim: t[9],
    type: t[10]
  });
}
An.prototype = Wf.prototype;
function Wf(e) {
  this.fill = e.fill === void 0 ? " " : e.fill + "", this.align = e.align === void 0 ? ">" : e.align + "", this.sign = e.sign === void 0 ? "-" : e.sign + "", this.symbol = e.symbol === void 0 ? "" : e.symbol + "", this.zero = !!e.zero, this.width = e.width === void 0 ? void 0 : +e.width, this.comma = !!e.comma, this.precision = e.precision === void 0 ? void 0 : +e.precision, this.trim = !!e.trim, this.type = e.type === void 0 ? "" : e.type + "";
}
Wf.prototype.toString = function() {
  return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (this.width === void 0 ? "" : Math.max(1, this.width | 0)) + (this.comma ? "," : "") + (this.precision === void 0 ? "" : "." + Math.max(0, this.precision | 0)) + (this.trim ? "~" : "") + this.type;
};
function nT(e) {
  e: for (var t = e.length, r = 1, n = -1, i; r < t; ++r)
    switch (e[r]) {
      case ".":
        n = i = r;
        break;
      case "0":
        n === 0 && (n = r), i = r;
        break;
      default:
        if (!+e[r]) break e;
        n > 0 && (n = 0);
        break;
    }
  return n > 0 ? e.slice(0, n) + e.slice(i + 1) : e;
}
var Ii;
function iT(e, t) {
  var r = Ci(e, t);
  if (!r) return Ii = void 0, e.toPrecision(t);
  var n = r[0], i = r[1], a = i - (Ii = Math.max(-8, Math.min(8, Math.floor(i / 3))) * 3) + 1, o = n.length;
  return a === o ? n : a > o ? n + new Array(a - o + 1).join("0") : a > 0 ? n.slice(0, a) + "." + n.slice(a) : "0." + new Array(1 - a).join("0") + Ci(e, Math.max(0, t + a - 1))[0];
}
function Py(e, t) {
  var r = Ci(e, t);
  if (!r) return e + "";
  var n = r[0], i = r[1];
  return i < 0 ? "0." + new Array(-i).join("0") + n : n.length > i + 1 ? n.slice(0, i + 1) + "." + n.slice(i + 1) : n + new Array(i - n.length + 2).join("0");
}
const Ty = {
  "%": (e, t) => (e * 100).toFixed(t),
  b: (e) => Math.round(e).toString(2),
  c: (e) => e + "",
  d: JP,
  e: (e, t) => e.toExponential(t),
  f: (e, t) => e.toFixed(t),
  g: (e, t) => e.toPrecision(t),
  o: (e) => Math.round(e).toString(8),
  p: (e, t) => Py(e * 100, t),
  r: Py,
  s: iT,
  X: (e) => Math.round(e).toString(16).toUpperCase(),
  x: (e) => Math.round(e).toString(16)
};
function jy(e) {
  return e;
}
var Ey = Array.prototype.map, My = ["y", "z", "a", "f", "p", "n", "µ", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
function aT(e) {
  var t = e.grouping === void 0 || e.thousands === void 0 ? jy : eT(Ey.call(e.grouping, Number), e.thousands + ""), r = e.currency === void 0 ? "" : e.currency[0] + "", n = e.currency === void 0 ? "" : e.currency[1] + "", i = e.decimal === void 0 ? "." : e.decimal + "", a = e.numerals === void 0 ? jy : tT(Ey.call(e.numerals, String)), o = e.percent === void 0 ? "%" : e.percent + "", u = e.minus === void 0 ? "−" : e.minus + "", s = e.nan === void 0 ? "NaN" : e.nan + "";
  function c(l, d) {
    l = An(l);
    var p = l.fill, y = l.align, v = l.sign, h = l.symbol, w = l.zero, b = l.width, x = l.comma, O = l.precision, m = l.trim, g = l.type;
    g === "n" ? (x = !0, g = "g") : Ty[g] || (O === void 0 && (O = 12), m = !0, g = "g"), (w || p === "0" && y === "=") && (w = !0, p = "0", y = "=");
    var _ = (d && d.prefix !== void 0 ? d.prefix : "") + (h === "$" ? r : h === "#" && /[boxX]/.test(g) ? "0" + g.toLowerCase() : ""), A = (h === "$" ? n : /[%p]/.test(g) ? o : "") + (d && d.suffix !== void 0 ? d.suffix : ""), P = Ty[g], $ = /[defgprs%]/.test(g);
    O = O === void 0 ? 6 : /[gprs]/.test(g) ? Math.max(1, Math.min(21, O)) : Math.max(0, Math.min(20, O));
    function M(j) {
      var E = _, C = A, I, N, R;
      if (g === "c")
        C = P(j) + C, j = "";
      else {
        j = +j;
        var B = j < 0 || 1 / j < 0;
        if (j = isNaN(j) ? s : P(Math.abs(j), O), m && (j = nT(j)), B && +j == 0 && v !== "+" && (B = !1), E = (B ? v === "(" ? v : u : v === "-" || v === "(" ? "" : v) + E, C = (g === "s" && !isNaN(j) && Ii !== void 0 ? My[8 + Ii / 3] : "") + C + (B && v === "(" ? ")" : ""), $) {
          for (I = -1, N = j.length; ++I < N; )
            if (R = j.charCodeAt(I), 48 > R || R > 57) {
              C = (R === 46 ? i + j.slice(I + 1) : j.slice(I)) + C, j = j.slice(0, I);
              break;
            }
        }
      }
      x && !w && (j = t(j, 1 / 0));
      var F = E.length + j.length + C.length, K = F < b ? new Array(b - F + 1).join(p) : "";
      switch (x && w && (j = t(K + j, K.length ? b - C.length : 1 / 0), K = ""), y) {
        case "<":
          j = E + j + C + K;
          break;
        case "=":
          j = E + K + j + C;
          break;
        case "^":
          j = K.slice(0, F = K.length >> 1) + E + j + C + K.slice(F);
          break;
        default:
          j = K + E + j + C;
          break;
      }
      return a(j);
    }
    return M.toString = function() {
      return l + "";
    }, M;
  }
  function f(l, d) {
    var p = Math.max(-8, Math.min(8, Math.floor(Or(d) / 3))) * 3, y = Math.pow(10, -p), v = c((l = An(l), l.type = "f", l), { suffix: My[8 + p / 3] });
    return function(h) {
      return v(y * h);
    };
  }
  return {
    format: c,
    formatPrefix: f
  };
}
var ci, Hf, h0;
oT({
  thousands: ",",
  grouping: [3],
  currency: ["$", ""]
});
function oT(e) {
  return ci = aT(e), Hf = ci.format, h0 = ci.formatPrefix, ci;
}
function uT(e) {
  return Math.max(0, -Or(Math.abs(e)));
}
function sT(e, t) {
  return Math.max(0, Math.max(-8, Math.min(8, Math.floor(Or(t) / 3))) * 3 - Or(Math.abs(e)));
}
function cT(e, t) {
  return e = Math.abs(e), t = Math.abs(t) - e, Math.max(0, Or(t) - Or(e)) + 1;
}
function p0(e, t, r, n) {
  var i = Ol(e, t, r), a;
  switch (n = An(n ?? ",f"), n.type) {
    case "s": {
      var o = Math.max(Math.abs(e), Math.abs(t));
      return n.precision == null && !isNaN(a = sT(i, o)) && (n.precision = a), h0(n, o);
    }
    case "":
    case "e":
    case "g":
    case "p":
    case "r": {
      n.precision == null && !isNaN(a = cT(i, Math.max(Math.abs(e), Math.abs(t)))) && (n.precision = a - (n.type === "e"));
      break;
    }
    case "f":
    case "%": {
      n.precision == null && !isNaN(a = uT(i)) && (n.precision = a - (n.type === "%") * 2);
      break;
    }
  }
  return Hf(n);
}
function $t(e) {
  var t = e.domain;
  return e.ticks = function(r) {
    var n = t();
    return xl(n[0], n[n.length - 1], r ?? 10);
  }, e.tickFormat = function(r, n) {
    var i = t();
    return p0(i[0], i[i.length - 1], r ?? 10, n);
  }, e.nice = function(r) {
    r == null && (r = 10);
    var n = t(), i = 0, a = n.length - 1, o = n[i], u = n[a], s, c, f = 10;
    for (u < o && (c = o, o = u, u = c, c = i, i = a, a = c); f-- > 0; ) {
      if (c = wl(o, u, r), c === s)
        return n[i] = o, n[a] = u, t(n);
      if (c > 0)
        o = Math.floor(o / c) * c, u = Math.ceil(u / c) * c;
      else if (c < 0)
        o = Math.ceil(o * c) / c, u = Math.floor(u * c) / c;
      else
        break;
      s = c;
    }
    return e;
  }, e;
}
function $i() {
  var e = Uf();
  return e.copy = function() {
    return ei(e, $i());
  }, Xe.apply(e, arguments), $t(e);
}
function v0(e) {
  var t;
  function r(n) {
    return n == null || isNaN(n = +n) ? t : n;
  }
  return r.invert = r, r.domain = r.range = function(n) {
    return arguments.length ? (e = Array.from(n, Mi), r) : e.slice();
  }, r.unknown = function(n) {
    return arguments.length ? (t = n, r) : t;
  }, r.copy = function() {
    return v0(e).unknown(t);
  }, e = arguments.length ? Array.from(e, Mi) : [0, 1], $t(r);
}
function y0(e, t) {
  e = e.slice();
  var r = 0, n = e.length - 1, i = e[r], a = e[n], o;
  return a < i && (o = r, r = n, n = o, o = i, i = a, a = o), e[r] = t.floor(i), e[n] = t.ceil(a), e;
}
function Cy(e) {
  return Math.log(e);
}
function Iy(e) {
  return Math.exp(e);
}
function lT(e) {
  return -Math.log(-e);
}
function fT(e) {
  return -Math.exp(-e);
}
function dT(e) {
  return isFinite(e) ? +("1e" + e) : e < 0 ? 0 : e;
}
function hT(e) {
  return e === 10 ? dT : e === Math.E ? Math.exp : (t) => Math.pow(e, t);
}
function pT(e) {
  return e === Math.E ? Math.log : e === 10 && Math.log10 || e === 2 && Math.log2 || (e = Math.log(e), (t) => Math.log(t) / e);
}
function $y(e) {
  return (t, r) => -e(-t, r);
}
function Kf(e) {
  const t = e(Cy, Iy), r = t.domain;
  let n = 10, i, a;
  function o() {
    return i = pT(n), a = hT(n), r()[0] < 0 ? (i = $y(i), a = $y(a), e(lT, fT)) : e(Cy, Iy), t;
  }
  return t.base = function(u) {
    return arguments.length ? (n = +u, o()) : n;
  }, t.domain = function(u) {
    return arguments.length ? (r(u), o()) : r();
  }, t.ticks = (u) => {
    const s = r();
    let c = s[0], f = s[s.length - 1];
    const l = f < c;
    l && ([c, f] = [f, c]);
    let d = i(c), p = i(f), y, v;
    const h = u == null ? 10 : +u;
    let w = [];
    if (!(n % 1) && p - d < h) {
      if (d = Math.floor(d), p = Math.ceil(p), c > 0) {
        for (; d <= p; ++d)
          for (y = 1; y < n; ++y)
            if (v = d < 0 ? y / a(-d) : y * a(d), !(v < c)) {
              if (v > f) break;
              w.push(v);
            }
      } else for (; d <= p; ++d)
        for (y = n - 1; y >= 1; --y)
          if (v = d > 0 ? y / a(-d) : y * a(d), !(v < c)) {
            if (v > f) break;
            w.push(v);
          }
      w.length * 2 < h && (w = xl(c, f, h));
    } else
      w = xl(d, p, Math.min(p - d, h)).map(a);
    return l ? w.reverse() : w;
  }, t.tickFormat = (u, s) => {
    if (u == null && (u = 10), s == null && (s = n === 10 ? "s" : ","), typeof s != "function" && (!(n % 1) && (s = An(s)).precision == null && (s.trim = !0), s = Hf(s)), u === 1 / 0) return s;
    const c = Math.max(1, n * u / t.ticks().length);
    return (f) => {
      let l = f / a(Math.round(i(f)));
      return l * n < n - 0.5 && (l *= n), l <= c ? s(f) : "";
    };
  }, t.nice = () => r(y0(r(), {
    floor: (u) => a(Math.floor(i(u))),
    ceil: (u) => a(Math.ceil(i(u)))
  })), t;
}
function m0() {
  const e = Kf(Aa()).domain([1, 10]);
  return e.copy = () => ei(e, m0()).base(e.base()), Xe.apply(e, arguments), e;
}
function Ny(e) {
  return function(t) {
    return Math.sign(t) * Math.log1p(Math.abs(t / e));
  };
}
function ky(e) {
  return function(t) {
    return Math.sign(t) * Math.expm1(Math.abs(t)) * e;
  };
}
function Gf(e) {
  var t = 1, r = e(Ny(t), ky(t));
  return r.constant = function(n) {
    return arguments.length ? e(Ny(t = +n), ky(t)) : t;
  }, $t(r);
}
function g0() {
  var e = Gf(Aa());
  return e.copy = function() {
    return ei(e, g0()).constant(e.constant());
  }, Xe.apply(e, arguments);
}
function Dy(e) {
  return function(t) {
    return t < 0 ? -Math.pow(-t, e) : Math.pow(t, e);
  };
}
function vT(e) {
  return e < 0 ? -Math.sqrt(-e) : Math.sqrt(e);
}
function yT(e) {
  return e < 0 ? -e * e : e * e;
}
function Vf(e) {
  var t = e(Ie, Ie), r = 1;
  function n() {
    return r === 1 ? e(Ie, Ie) : r === 0.5 ? e(vT, yT) : e(Dy(r), Dy(1 / r));
  }
  return t.exponent = function(i) {
    return arguments.length ? (r = +i, n()) : r;
  }, $t(t);
}
function Xf() {
  var e = Vf(Aa());
  return e.copy = function() {
    return ei(e, Xf()).exponent(e.exponent());
  }, Xe.apply(e, arguments), e;
}
function mT() {
  return Xf.apply(null, arguments).exponent(0.5);
}
function Ry(e) {
  return Math.sign(e) * e * e;
}
function gT(e) {
  return Math.sign(e) * Math.sqrt(Math.abs(e));
}
function b0() {
  var e = Uf(), t = [0, 1], r = !1, n;
  function i(a) {
    var o = gT(e(a));
    return isNaN(o) ? n : r ? Math.round(o) : o;
  }
  return i.invert = function(a) {
    return e.invert(Ry(a));
  }, i.domain = function(a) {
    return arguments.length ? (e.domain(a), i) : e.domain();
  }, i.range = function(a) {
    return arguments.length ? (e.range((t = Array.from(a, Mi)).map(Ry)), i) : t.slice();
  }, i.rangeRound = function(a) {
    return i.range(a).round(!0);
  }, i.round = function(a) {
    return arguments.length ? (r = !!a, i) : r;
  }, i.clamp = function(a) {
    return arguments.length ? (e.clamp(a), i) : e.clamp();
  }, i.unknown = function(a) {
    return arguments.length ? (n = a, i) : n;
  }, i.copy = function() {
    return b0(e.domain(), t).round(r).clamp(e.clamp()).unknown(n);
  }, Xe.apply(i, arguments), $t(i);
}
function x0() {
  var e = [], t = [], r = [], n;
  function i() {
    var o = 0, u = Math.max(1, t.length);
    for (r = new Array(u - 1); ++o < u; ) r[o - 1] = GP(e, o / u);
    return a;
  }
  function a(o) {
    return o == null || isNaN(o = +o) ? n : t[Jn(r, o)];
  }
  return a.invertExtent = function(o) {
    var u = t.indexOf(o);
    return u < 0 ? [NaN, NaN] : [
      u > 0 ? r[u - 1] : e[0],
      u < r.length ? r[u] : e[e.length - 1]
    ];
  }, a.domain = function(o) {
    if (!arguments.length) return e.slice();
    e = [];
    for (let u of o) u != null && !isNaN(u = +u) && e.push(u);
    return e.sort(Et), i();
  }, a.range = function(o) {
    return arguments.length ? (t = Array.from(o), i()) : t.slice();
  }, a.unknown = function(o) {
    return arguments.length ? (n = o, a) : n;
  }, a.quantiles = function() {
    return r.slice();
  }, a.copy = function() {
    return x0().domain(e).range(t).unknown(n);
  }, Xe.apply(a, arguments);
}
function w0() {
  var e = 0, t = 1, r = 1, n = [0.5], i = [0, 1], a;
  function o(s) {
    return s != null && s <= s ? i[Jn(n, s, 0, r)] : a;
  }
  function u() {
    var s = -1;
    for (n = new Array(r); ++s < r; ) n[s] = ((s + 1) * t - (s - r) * e) / (r + 1);
    return o;
  }
  return o.domain = function(s) {
    return arguments.length ? ([e, t] = s, e = +e, t = +t, u()) : [e, t];
  }, o.range = function(s) {
    return arguments.length ? (r = (i = Array.from(s)).length - 1, u()) : i.slice();
  }, o.invertExtent = function(s) {
    var c = i.indexOf(s);
    return c < 0 ? [NaN, NaN] : c < 1 ? [e, n[0]] : c >= r ? [n[r - 1], t] : [n[c - 1], n[c]];
  }, o.unknown = function(s) {
    return arguments.length && (a = s), o;
  }, o.thresholds = function() {
    return n.slice();
  }, o.copy = function() {
    return w0().domain([e, t]).range(i).unknown(a);
  }, Xe.apply($t(o), arguments);
}
function O0() {
  var e = [0.5], t = [0, 1], r, n = 1;
  function i(a) {
    return a != null && a <= a ? t[Jn(e, a, 0, n)] : r;
  }
  return i.domain = function(a) {
    return arguments.length ? (e = Array.from(a), n = Math.min(e.length, t.length - 1), i) : e.slice();
  }, i.range = function(a) {
    return arguments.length ? (t = Array.from(a), n = Math.min(e.length, t.length - 1), i) : t.slice();
  }, i.invertExtent = function(a) {
    var o = t.indexOf(a);
    return [e[o - 1], e[o]];
  }, i.unknown = function(a) {
    return arguments.length ? (r = a, i) : r;
  }, i.copy = function() {
    return O0().domain(e).range(t).unknown(r);
  }, Xe.apply(i, arguments);
}
const tc = /* @__PURE__ */ new Date(), rc = /* @__PURE__ */ new Date();
function Se(e, t, r, n) {
  function i(a) {
    return e(a = arguments.length === 0 ? /* @__PURE__ */ new Date() : /* @__PURE__ */ new Date(+a)), a;
  }
  return i.floor = (a) => (e(a = /* @__PURE__ */ new Date(+a)), a), i.ceil = (a) => (e(a = new Date(a - 1)), t(a, 1), e(a), a), i.round = (a) => {
    const o = i(a), u = i.ceil(a);
    return a - o < u - a ? o : u;
  }, i.offset = (a, o) => (t(a = /* @__PURE__ */ new Date(+a), o == null ? 1 : Math.floor(o)), a), i.range = (a, o, u) => {
    const s = [];
    if (a = i.ceil(a), u = u == null ? 1 : Math.floor(u), !(a < o) || !(u > 0)) return s;
    let c;
    do
      s.push(c = /* @__PURE__ */ new Date(+a)), t(a, u), e(a);
    while (c < a && a < o);
    return s;
  }, i.filter = (a) => Se((o) => {
    if (o >= o) for (; e(o), !a(o); ) o.setTime(o - 1);
  }, (o, u) => {
    if (o >= o)
      if (u < 0) for (; ++u <= 0; )
        for (; t(o, -1), !a(o); )
          ;
      else for (; --u >= 0; )
        for (; t(o, 1), !a(o); )
          ;
  }), r && (i.count = (a, o) => (tc.setTime(+a), rc.setTime(+o), e(tc), e(rc), Math.floor(r(tc, rc))), i.every = (a) => (a = Math.floor(a), !isFinite(a) || !(a > 0) ? null : a > 1 ? i.filter(n ? (o) => n(o) % a === 0 : (o) => i.count(0, o) % a === 0) : i)), i;
}
const Ni = Se(() => {
}, (e, t) => {
  e.setTime(+e + t);
}, (e, t) => t - e);
Ni.every = (e) => (e = Math.floor(e), !isFinite(e) || !(e > 0) ? null : e > 1 ? Se((t) => {
  t.setTime(Math.floor(t / e) * e);
}, (t, r) => {
  t.setTime(+t + r * e);
}, (t, r) => (r - t) / e) : Ni);
Ni.range;
const ct = 1e3, Ke = ct * 60, lt = Ke * 60, yt = lt * 24, Yf = yt * 7, Ly = yt * 30, nc = yt * 365, Ut = Se((e) => {
  e.setTime(e - e.getMilliseconds());
}, (e, t) => {
  e.setTime(+e + t * ct);
}, (e, t) => (t - e) / ct, (e) => e.getUTCSeconds());
Ut.range;
const Zf = Se((e) => {
  e.setTime(e - e.getMilliseconds() - e.getSeconds() * ct);
}, (e, t) => {
  e.setTime(+e + t * Ke);
}, (e, t) => (t - e) / Ke, (e) => e.getMinutes());
Zf.range;
const Qf = Se((e) => {
  e.setUTCSeconds(0, 0);
}, (e, t) => {
  e.setTime(+e + t * Ke);
}, (e, t) => (t - e) / Ke, (e) => e.getUTCMinutes());
Qf.range;
const Jf = Se((e) => {
  e.setTime(e - e.getMilliseconds() - e.getSeconds() * ct - e.getMinutes() * Ke);
}, (e, t) => {
  e.setTime(+e + t * lt);
}, (e, t) => (t - e) / lt, (e) => e.getHours());
Jf.range;
const ed = Se((e) => {
  e.setUTCMinutes(0, 0, 0);
}, (e, t) => {
  e.setTime(+e + t * lt);
}, (e, t) => (t - e) / lt, (e) => e.getUTCHours());
ed.range;
const ti = Se(
  (e) => e.setHours(0, 0, 0, 0),
  (e, t) => e.setDate(e.getDate() + t),
  (e, t) => (t - e - (t.getTimezoneOffset() - e.getTimezoneOffset()) * Ke) / yt,
  (e) => e.getDate() - 1
);
ti.range;
const Pa = Se((e) => {
  e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCDate(e.getUTCDate() + t);
}, (e, t) => (t - e) / yt, (e) => e.getUTCDate() - 1);
Pa.range;
const _0 = Se((e) => {
  e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCDate(e.getUTCDate() + t);
}, (e, t) => (t - e) / yt, (e) => Math.floor(e / yt));
_0.range;
function Jt(e) {
  return Se((t) => {
    t.setDate(t.getDate() - (t.getDay() + 7 - e) % 7), t.setHours(0, 0, 0, 0);
  }, (t, r) => {
    t.setDate(t.getDate() + r * 7);
  }, (t, r) => (r - t - (r.getTimezoneOffset() - t.getTimezoneOffset()) * Ke) / Yf);
}
const Ta = Jt(0), ki = Jt(1), bT = Jt(2), xT = Jt(3), _r = Jt(4), wT = Jt(5), OT = Jt(6);
Ta.range;
ki.range;
bT.range;
xT.range;
_r.range;
wT.range;
OT.range;
function er(e) {
  return Se((t) => {
    t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 7 - e) % 7), t.setUTCHours(0, 0, 0, 0);
  }, (t, r) => {
    t.setUTCDate(t.getUTCDate() + r * 7);
  }, (t, r) => (r - t) / Yf);
}
const ja = er(0), Di = er(1), _T = er(2), ST = er(3), Sr = er(4), AT = er(5), PT = er(6);
ja.range;
Di.range;
_T.range;
ST.range;
Sr.range;
AT.range;
PT.range;
const td = Se((e) => {
  e.setDate(1), e.setHours(0, 0, 0, 0);
}, (e, t) => {
  e.setMonth(e.getMonth() + t);
}, (e, t) => t.getMonth() - e.getMonth() + (t.getFullYear() - e.getFullYear()) * 12, (e) => e.getMonth());
td.range;
const rd = Se((e) => {
  e.setUTCDate(1), e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCMonth(e.getUTCMonth() + t);
}, (e, t) => t.getUTCMonth() - e.getUTCMonth() + (t.getUTCFullYear() - e.getUTCFullYear()) * 12, (e) => e.getUTCMonth());
rd.range;
const mt = Se((e) => {
  e.setMonth(0, 1), e.setHours(0, 0, 0, 0);
}, (e, t) => {
  e.setFullYear(e.getFullYear() + t);
}, (e, t) => t.getFullYear() - e.getFullYear(), (e) => e.getFullYear());
mt.every = (e) => !isFinite(e = Math.floor(e)) || !(e > 0) ? null : Se((t) => {
  t.setFullYear(Math.floor(t.getFullYear() / e) * e), t.setMonth(0, 1), t.setHours(0, 0, 0, 0);
}, (t, r) => {
  t.setFullYear(t.getFullYear() + r * e);
});
mt.range;
const gt = Se((e) => {
  e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0);
}, (e, t) => {
  e.setUTCFullYear(e.getUTCFullYear() + t);
}, (e, t) => t.getUTCFullYear() - e.getUTCFullYear(), (e) => e.getUTCFullYear());
gt.every = (e) => !isFinite(e = Math.floor(e)) || !(e > 0) ? null : Se((t) => {
  t.setUTCFullYear(Math.floor(t.getUTCFullYear() / e) * e), t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0);
}, (t, r) => {
  t.setUTCFullYear(t.getUTCFullYear() + r * e);
});
gt.range;
function S0(e, t, r, n, i, a) {
  const o = [
    [Ut, 1, ct],
    [Ut, 5, 5 * ct],
    [Ut, 15, 15 * ct],
    [Ut, 30, 30 * ct],
    [a, 1, Ke],
    [a, 5, 5 * Ke],
    [a, 15, 15 * Ke],
    [a, 30, 30 * Ke],
    [i, 1, lt],
    [i, 3, 3 * lt],
    [i, 6, 6 * lt],
    [i, 12, 12 * lt],
    [n, 1, yt],
    [n, 2, 2 * yt],
    [r, 1, Yf],
    [t, 1, Ly],
    [t, 3, 3 * Ly],
    [e, 1, nc]
  ];
  function u(c, f, l) {
    const d = f < c;
    d && ([c, f] = [f, c]);
    const p = l && typeof l.range == "function" ? l : s(c, f, l), y = p ? p.range(c, +f + 1) : [];
    return d ? y.reverse() : y;
  }
  function s(c, f, l) {
    const d = Math.abs(f - c) / l, p = Ff(([, , h]) => h).right(o, d);
    if (p === o.length) return e.every(Ol(c / nc, f / nc, l));
    if (p === 0) return Ni.every(Math.max(Ol(c, f, l), 1));
    const [y, v] = o[d / o[p - 1][2] < o[p][2] / d ? p - 1 : p];
    return y.every(v);
  }
  return [u, s];
}
const [TT, jT] = S0(gt, rd, ja, _0, ed, Qf), [ET, MT] = S0(mt, td, Ta, ti, Jf, Zf);
function ic(e) {
  if (0 <= e.y && e.y < 100) {
    var t = new Date(-1, e.m, e.d, e.H, e.M, e.S, e.L);
    return t.setFullYear(e.y), t;
  }
  return new Date(e.y, e.m, e.d, e.H, e.M, e.S, e.L);
}
function ac(e) {
  if (0 <= e.y && e.y < 100) {
    var t = new Date(Date.UTC(-1, e.m, e.d, e.H, e.M, e.S, e.L));
    return t.setUTCFullYear(e.y), t;
  }
  return new Date(Date.UTC(e.y, e.m, e.d, e.H, e.M, e.S, e.L));
}
function Jr(e, t, r) {
  return { y: e, m: t, d: r, H: 0, M: 0, S: 0, L: 0 };
}
function CT(e) {
  var t = e.dateTime, r = e.date, n = e.time, i = e.periods, a = e.days, o = e.shortDays, u = e.months, s = e.shortMonths, c = en(i), f = tn(i), l = en(a), d = tn(a), p = en(o), y = tn(o), v = en(u), h = tn(u), w = en(s), b = tn(s), x = {
    a: R,
    A: B,
    b: F,
    B: K,
    c: null,
    d: Wy,
    e: Wy,
    f: ej,
    g: lj,
    G: dj,
    H: ZT,
    I: QT,
    j: JT,
    L: A0,
    m: tj,
    M: rj,
    p: V,
    q: W,
    Q: Gy,
    s: Vy,
    S: nj,
    u: ij,
    U: aj,
    V: oj,
    w: uj,
    W: sj,
    x: null,
    X: null,
    y: cj,
    Y: fj,
    Z: hj,
    "%": Ky
  }, O = {
    a: X,
    A: le,
    b: ye,
    B: De,
    c: null,
    d: Hy,
    e: Hy,
    f: mj,
    g: Tj,
    G: Ej,
    H: pj,
    I: vj,
    j: yj,
    L: T0,
    m: gj,
    M: bj,
    p: Dt,
    q: $e,
    Q: Gy,
    s: Vy,
    S: xj,
    u: wj,
    U: Oj,
    V: _j,
    w: Sj,
    W: Aj,
    x: null,
    X: null,
    y: Pj,
    Y: jj,
    Z: Mj,
    "%": Ky
  }, m = {
    a: $,
    A: M,
    b: j,
    B: E,
    c: C,
    d: zy,
    e: zy,
    f: GT,
    g: Fy,
    G: By,
    H: Uy,
    I: Uy,
    j: UT,
    L: KT,
    m: zT,
    M: WT,
    p: P,
    q: FT,
    Q: XT,
    s: YT,
    S: HT,
    u: DT,
    U: RT,
    V: LT,
    w: kT,
    W: qT,
    x: I,
    X: N,
    y: Fy,
    Y: By,
    Z: BT,
    "%": VT
  };
  x.x = g(r, x), x.X = g(n, x), x.c = g(t, x), O.x = g(r, O), O.X = g(n, O), O.c = g(t, O);
  function g(z, Y) {
    return function(Q) {
      var L = [], pe = -1, te = 0, be = z.length, xe, Ne, _t;
      for (Q instanceof Date || (Q = /* @__PURE__ */ new Date(+Q)); ++pe < be; )
        z.charCodeAt(pe) === 37 && (L.push(z.slice(te, pe)), (Ne = qy[xe = z.charAt(++pe)]) != null ? xe = z.charAt(++pe) : Ne = xe === "e" ? " " : "0", (_t = Y[xe]) && (xe = _t(Q, Ne)), L.push(xe), te = pe + 1);
      return L.push(z.slice(te, pe)), L.join("");
    };
  }
  function _(z, Y) {
    return function(Q) {
      var L = Jr(1900, void 0, 1), pe = A(L, z, Q += "", 0), te, be;
      if (pe != Q.length) return null;
      if ("Q" in L) return new Date(L.Q);
      if ("s" in L) return new Date(L.s * 1e3 + ("L" in L ? L.L : 0));
      if (Y && !("Z" in L) && (L.Z = 0), "p" in L && (L.H = L.H % 12 + L.p * 12), L.m === void 0 && (L.m = "q" in L ? L.q : 0), "V" in L) {
        if (L.V < 1 || L.V > 53) return null;
        "w" in L || (L.w = 1), "Z" in L ? (te = ac(Jr(L.y, 0, 1)), be = te.getUTCDay(), te = be > 4 || be === 0 ? Di.ceil(te) : Di(te), te = Pa.offset(te, (L.V - 1) * 7), L.y = te.getUTCFullYear(), L.m = te.getUTCMonth(), L.d = te.getUTCDate() + (L.w + 6) % 7) : (te = ic(Jr(L.y, 0, 1)), be = te.getDay(), te = be > 4 || be === 0 ? ki.ceil(te) : ki(te), te = ti.offset(te, (L.V - 1) * 7), L.y = te.getFullYear(), L.m = te.getMonth(), L.d = te.getDate() + (L.w + 6) % 7);
      } else ("W" in L || "U" in L) && ("w" in L || (L.w = "u" in L ? L.u % 7 : "W" in L ? 1 : 0), be = "Z" in L ? ac(Jr(L.y, 0, 1)).getUTCDay() : ic(Jr(L.y, 0, 1)).getDay(), L.m = 0, L.d = "W" in L ? (L.w + 6) % 7 + L.W * 7 - (be + 5) % 7 : L.w + L.U * 7 - (be + 6) % 7);
      return "Z" in L ? (L.H += L.Z / 100 | 0, L.M += L.Z % 100, ac(L)) : ic(L);
    };
  }
  function A(z, Y, Q, L) {
    for (var pe = 0, te = Y.length, be = Q.length, xe, Ne; pe < te; ) {
      if (L >= be) return -1;
      if (xe = Y.charCodeAt(pe++), xe === 37) {
        if (xe = Y.charAt(pe++), Ne = m[xe in qy ? Y.charAt(pe++) : xe], !Ne || (L = Ne(z, Q, L)) < 0) return -1;
      } else if (xe != Q.charCodeAt(L++))
        return -1;
    }
    return L;
  }
  function P(z, Y, Q) {
    var L = c.exec(Y.slice(Q));
    return L ? (z.p = f.get(L[0].toLowerCase()), Q + L[0].length) : -1;
  }
  function $(z, Y, Q) {
    var L = p.exec(Y.slice(Q));
    return L ? (z.w = y.get(L[0].toLowerCase()), Q + L[0].length) : -1;
  }
  function M(z, Y, Q) {
    var L = l.exec(Y.slice(Q));
    return L ? (z.w = d.get(L[0].toLowerCase()), Q + L[0].length) : -1;
  }
  function j(z, Y, Q) {
    var L = w.exec(Y.slice(Q));
    return L ? (z.m = b.get(L[0].toLowerCase()), Q + L[0].length) : -1;
  }
  function E(z, Y, Q) {
    var L = v.exec(Y.slice(Q));
    return L ? (z.m = h.get(L[0].toLowerCase()), Q + L[0].length) : -1;
  }
  function C(z, Y, Q) {
    return A(z, t, Y, Q);
  }
  function I(z, Y, Q) {
    return A(z, r, Y, Q);
  }
  function N(z, Y, Q) {
    return A(z, n, Y, Q);
  }
  function R(z) {
    return o[z.getDay()];
  }
  function B(z) {
    return a[z.getDay()];
  }
  function F(z) {
    return s[z.getMonth()];
  }
  function K(z) {
    return u[z.getMonth()];
  }
  function V(z) {
    return i[+(z.getHours() >= 12)];
  }
  function W(z) {
    return 1 + ~~(z.getMonth() / 3);
  }
  function X(z) {
    return o[z.getUTCDay()];
  }
  function le(z) {
    return a[z.getUTCDay()];
  }
  function ye(z) {
    return s[z.getUTCMonth()];
  }
  function De(z) {
    return u[z.getUTCMonth()];
  }
  function Dt(z) {
    return i[+(z.getUTCHours() >= 12)];
  }
  function $e(z) {
    return 1 + ~~(z.getUTCMonth() / 3);
  }
  return {
    format: function(z) {
      var Y = g(z += "", x);
      return Y.toString = function() {
        return z;
      }, Y;
    },
    parse: function(z) {
      var Y = _(z += "", !1);
      return Y.toString = function() {
        return z;
      }, Y;
    },
    utcFormat: function(z) {
      var Y = g(z += "", O);
      return Y.toString = function() {
        return z;
      }, Y;
    },
    utcParse: function(z) {
      var Y = _(z += "", !0);
      return Y.toString = function() {
        return z;
      }, Y;
    }
  };
}
var qy = { "-": "", _: " ", 0: "0" }, Pe = /^\s*\d+/, IT = /^%/, $T = /[\\^$*+?|[\]().{}]/g;
function ne(e, t, r) {
  var n = e < 0 ? "-" : "", i = (n ? -e : e) + "", a = i.length;
  return n + (a < r ? new Array(r - a + 1).join(t) + i : i);
}
function NT(e) {
  return e.replace($T, "\\$&");
}
function en(e) {
  return new RegExp("^(?:" + e.map(NT).join("|") + ")", "i");
}
function tn(e) {
  return new Map(e.map((t, r) => [t.toLowerCase(), r]));
}
function kT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 1));
  return n ? (e.w = +n[0], r + n[0].length) : -1;
}
function DT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 1));
  return n ? (e.u = +n[0], r + n[0].length) : -1;
}
function RT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.U = +n[0], r + n[0].length) : -1;
}
function LT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.V = +n[0], r + n[0].length) : -1;
}
function qT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.W = +n[0], r + n[0].length) : -1;
}
function By(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 4));
  return n ? (e.y = +n[0], r + n[0].length) : -1;
}
function Fy(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.y = +n[0] + (+n[0] > 68 ? 1900 : 2e3), r + n[0].length) : -1;
}
function BT(e, t, r) {
  var n = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(t.slice(r, r + 6));
  return n ? (e.Z = n[1] ? 0 : -(n[2] + (n[3] || "00")), r + n[0].length) : -1;
}
function FT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 1));
  return n ? (e.q = n[0] * 3 - 3, r + n[0].length) : -1;
}
function zT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.m = n[0] - 1, r + n[0].length) : -1;
}
function zy(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.d = +n[0], r + n[0].length) : -1;
}
function UT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 3));
  return n ? (e.m = 0, e.d = +n[0], r + n[0].length) : -1;
}
function Uy(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.H = +n[0], r + n[0].length) : -1;
}
function WT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.M = +n[0], r + n[0].length) : -1;
}
function HT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 2));
  return n ? (e.S = +n[0], r + n[0].length) : -1;
}
function KT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 3));
  return n ? (e.L = +n[0], r + n[0].length) : -1;
}
function GT(e, t, r) {
  var n = Pe.exec(t.slice(r, r + 6));
  return n ? (e.L = Math.floor(n[0] / 1e3), r + n[0].length) : -1;
}
function VT(e, t, r) {
  var n = IT.exec(t.slice(r, r + 1));
  return n ? r + n[0].length : -1;
}
function XT(e, t, r) {
  var n = Pe.exec(t.slice(r));
  return n ? (e.Q = +n[0], r + n[0].length) : -1;
}
function YT(e, t, r) {
  var n = Pe.exec(t.slice(r));
  return n ? (e.s = +n[0], r + n[0].length) : -1;
}
function Wy(e, t) {
  return ne(e.getDate(), t, 2);
}
function ZT(e, t) {
  return ne(e.getHours(), t, 2);
}
function QT(e, t) {
  return ne(e.getHours() % 12 || 12, t, 2);
}
function JT(e, t) {
  return ne(1 + ti.count(mt(e), e), t, 3);
}
function A0(e, t) {
  return ne(e.getMilliseconds(), t, 3);
}
function ej(e, t) {
  return A0(e, t) + "000";
}
function tj(e, t) {
  return ne(e.getMonth() + 1, t, 2);
}
function rj(e, t) {
  return ne(e.getMinutes(), t, 2);
}
function nj(e, t) {
  return ne(e.getSeconds(), t, 2);
}
function ij(e) {
  var t = e.getDay();
  return t === 0 ? 7 : t;
}
function aj(e, t) {
  return ne(Ta.count(mt(e) - 1, e), t, 2);
}
function P0(e) {
  var t = e.getDay();
  return t >= 4 || t === 0 ? _r(e) : _r.ceil(e);
}
function oj(e, t) {
  return e = P0(e), ne(_r.count(mt(e), e) + (mt(e).getDay() === 4), t, 2);
}
function uj(e) {
  return e.getDay();
}
function sj(e, t) {
  return ne(ki.count(mt(e) - 1, e), t, 2);
}
function cj(e, t) {
  return ne(e.getFullYear() % 100, t, 2);
}
function lj(e, t) {
  return e = P0(e), ne(e.getFullYear() % 100, t, 2);
}
function fj(e, t) {
  return ne(e.getFullYear() % 1e4, t, 4);
}
function dj(e, t) {
  var r = e.getDay();
  return e = r >= 4 || r === 0 ? _r(e) : _r.ceil(e), ne(e.getFullYear() % 1e4, t, 4);
}
function hj(e) {
  var t = e.getTimezoneOffset();
  return (t > 0 ? "-" : (t *= -1, "+")) + ne(t / 60 | 0, "0", 2) + ne(t % 60, "0", 2);
}
function Hy(e, t) {
  return ne(e.getUTCDate(), t, 2);
}
function pj(e, t) {
  return ne(e.getUTCHours(), t, 2);
}
function vj(e, t) {
  return ne(e.getUTCHours() % 12 || 12, t, 2);
}
function yj(e, t) {
  return ne(1 + Pa.count(gt(e), e), t, 3);
}
function T0(e, t) {
  return ne(e.getUTCMilliseconds(), t, 3);
}
function mj(e, t) {
  return T0(e, t) + "000";
}
function gj(e, t) {
  return ne(e.getUTCMonth() + 1, t, 2);
}
function bj(e, t) {
  return ne(e.getUTCMinutes(), t, 2);
}
function xj(e, t) {
  return ne(e.getUTCSeconds(), t, 2);
}
function wj(e) {
  var t = e.getUTCDay();
  return t === 0 ? 7 : t;
}
function Oj(e, t) {
  return ne(ja.count(gt(e) - 1, e), t, 2);
}
function j0(e) {
  var t = e.getUTCDay();
  return t >= 4 || t === 0 ? Sr(e) : Sr.ceil(e);
}
function _j(e, t) {
  return e = j0(e), ne(Sr.count(gt(e), e) + (gt(e).getUTCDay() === 4), t, 2);
}
function Sj(e) {
  return e.getUTCDay();
}
function Aj(e, t) {
  return ne(Di.count(gt(e) - 1, e), t, 2);
}
function Pj(e, t) {
  return ne(e.getUTCFullYear() % 100, t, 2);
}
function Tj(e, t) {
  return e = j0(e), ne(e.getUTCFullYear() % 100, t, 2);
}
function jj(e, t) {
  return ne(e.getUTCFullYear() % 1e4, t, 4);
}
function Ej(e, t) {
  var r = e.getUTCDay();
  return e = r >= 4 || r === 0 ? Sr(e) : Sr.ceil(e), ne(e.getUTCFullYear() % 1e4, t, 4);
}
function Mj() {
  return "+0000";
}
function Ky() {
  return "%";
}
function Gy(e) {
  return +e;
}
function Vy(e) {
  return Math.floor(+e / 1e3);
}
var ir, E0, M0;
Cj({
  dateTime: "%x, %X",
  date: "%-m/%-d/%Y",
  time: "%-I:%M:%S %p",
  periods: ["AM", "PM"],
  days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
  shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
  months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
  shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
});
function Cj(e) {
  return ir = CT(e), E0 = ir.format, ir.parse, M0 = ir.utcFormat, ir.utcParse, ir;
}
function Ij(e) {
  return new Date(e);
}
function $j(e) {
  return e instanceof Date ? +e : +/* @__PURE__ */ new Date(+e);
}
function nd(e, t, r, n, i, a, o, u, s, c) {
  var f = Uf(), l = f.invert, d = f.domain, p = c(".%L"), y = c(":%S"), v = c("%I:%M"), h = c("%I %p"), w = c("%a %d"), b = c("%b %d"), x = c("%B"), O = c("%Y");
  function m(g) {
    return (s(g) < g ? p : u(g) < g ? y : o(g) < g ? v : a(g) < g ? h : n(g) < g ? i(g) < g ? w : b : r(g) < g ? x : O)(g);
  }
  return f.invert = function(g) {
    return new Date(l(g));
  }, f.domain = function(g) {
    return arguments.length ? d(Array.from(g, $j)) : d().map(Ij);
  }, f.ticks = function(g) {
    var _ = d();
    return e(_[0], _[_.length - 1], g ?? 10);
  }, f.tickFormat = function(g, _) {
    return _ == null ? m : c(_);
  }, f.nice = function(g) {
    var _ = d();
    return (!g || typeof g.range != "function") && (g = t(_[0], _[_.length - 1], g ?? 10)), g ? d(y0(_, g)) : f;
  }, f.copy = function() {
    return ei(f, nd(e, t, r, n, i, a, o, u, s, c));
  }, f;
}
function Nj() {
  return Xe.apply(nd(ET, MT, mt, td, Ta, ti, Jf, Zf, Ut, E0).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)]), arguments);
}
function kj() {
  return Xe.apply(nd(TT, jT, gt, rd, ja, Pa, ed, Qf, Ut, M0).domain([Date.UTC(2e3, 0, 1), Date.UTC(2e3, 0, 2)]), arguments);
}
function Ea() {
  var e = 0, t = 1, r, n, i, a, o = Ie, u = !1, s;
  function c(l) {
    return l == null || isNaN(l = +l) ? s : o(i === 0 ? 0.5 : (l = (a(l) - r) * i, u ? Math.max(0, Math.min(1, l)) : l));
  }
  c.domain = function(l) {
    return arguments.length ? ([e, t] = l, r = a(e = +e), n = a(t = +t), i = r === n ? 0 : 1 / (n - r), c) : [e, t];
  }, c.clamp = function(l) {
    return arguments.length ? (u = !!l, c) : u;
  }, c.interpolator = function(l) {
    return arguments.length ? (o = l, c) : o;
  };
  function f(l) {
    return function(d) {
      var p, y;
      return arguments.length ? ([p, y] = d, o = l(p, y), c) : [o(0), o(1)];
    };
  }
  return c.range = f(qr), c.rangeRound = f(gf), c.unknown = function(l) {
    return arguments.length ? (s = l, c) : s;
  }, function(l) {
    return a = l, r = l(e), n = l(t), i = r === n ? 0 : 1 / (n - r), c;
  };
}
function Nt(e, t) {
  return t.domain(e.domain()).interpolator(e.interpolator()).clamp(e.clamp()).unknown(e.unknown());
}
function C0() {
  var e = $t(Ea()(Ie));
  return e.copy = function() {
    return Nt(e, C0());
  }, Ot.apply(e, arguments);
}
function I0() {
  var e = Kf(Ea()).domain([1, 10]);
  return e.copy = function() {
    return Nt(e, I0()).base(e.base());
  }, Ot.apply(e, arguments);
}
function $0() {
  var e = Gf(Ea());
  return e.copy = function() {
    return Nt(e, $0()).constant(e.constant());
  }, Ot.apply(e, arguments);
}
function id() {
  var e = Vf(Ea());
  return e.copy = function() {
    return Nt(e, id()).exponent(e.exponent());
  }, Ot.apply(e, arguments);
}
function Dj() {
  return id.apply(null, arguments).exponent(0.5);
}
function N0() {
  var e = [], t = Ie;
  function r(n) {
    if (n != null && !isNaN(n = +n)) return t((Jn(e, n, 1) - 1) / (e.length - 1));
  }
  return r.domain = function(n) {
    if (!arguments.length) return e.slice();
    e = [];
    for (let i of n) i != null && !isNaN(i = +i) && e.push(i);
    return e.sort(Et), r;
  }, r.interpolator = function(n) {
    return arguments.length ? (t = n, r) : t;
  }, r.range = function() {
    return e.map((n, i) => t(i / (e.length - 1)));
  }, r.quantiles = function(n) {
    return Array.from({ length: n + 1 }, (i, a) => KP(e, a / n));
  }, r.copy = function() {
    return N0(t).domain(e);
  }, Ot.apply(r, arguments);
}
function Ma() {
  var e = 0, t = 0.5, r = 1, n = 1, i, a, o, u, s, c = Ie, f, l = !1, d;
  function p(v) {
    return isNaN(v = +v) ? d : (v = 0.5 + ((v = +f(v)) - a) * (n * v < n * a ? u : s), c(l ? Math.max(0, Math.min(1, v)) : v));
  }
  p.domain = function(v) {
    return arguments.length ? ([e, t, r] = v, i = f(e = +e), a = f(t = +t), o = f(r = +r), u = i === a ? 0 : 0.5 / (a - i), s = a === o ? 0 : 0.5 / (o - a), n = a < i ? -1 : 1, p) : [e, t, r];
  }, p.clamp = function(v) {
    return arguments.length ? (l = !!v, p) : l;
  }, p.interpolator = function(v) {
    return arguments.length ? (c = v, p) : c;
  };
  function y(v) {
    return function(h) {
      var w, b, x;
      return arguments.length ? ([w, b, x] = h, c = cO(v, [w, b, x]), p) : [c(0), c(0.5), c(1)];
    };
  }
  return p.range = y(qr), p.rangeRound = y(gf), p.unknown = function(v) {
    return arguments.length ? (d = v, p) : d;
  }, function(v) {
    return f = v, i = v(e), a = v(t), o = v(r), u = i === a ? 0 : 0.5 / (a - i), s = a === o ? 0 : 0.5 / (o - a), n = a < i ? -1 : 1, p;
  };
}
function k0() {
  var e = $t(Ma()(Ie));
  return e.copy = function() {
    return Nt(e, k0());
  }, Ot.apply(e, arguments);
}
function D0() {
  var e = Kf(Ma()).domain([0.1, 1, 10]);
  return e.copy = function() {
    return Nt(e, D0()).base(e.base());
  }, Ot.apply(e, arguments);
}
function R0() {
  var e = Gf(Ma());
  return e.copy = function() {
    return Nt(e, R0()).constant(e.constant());
  }, Ot.apply(e, arguments);
}
function ad() {
  var e = Vf(Ma());
  return e.copy = function() {
    return Nt(e, ad()).exponent(e.exponent());
  }, Ot.apply(e, arguments);
}
function Rj() {
  return ad.apply(null, arguments).exponent(0.5);
}
const Xy = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  scaleBand: Sn,
  scaleDiverging: k0,
  scaleDivergingLog: D0,
  scaleDivergingPow: ad,
  scaleDivergingSqrt: Rj,
  scaleDivergingSymlog: R0,
  scaleIdentity: v0,
  scaleImplicit: _l,
  scaleLinear: $i,
  scaleLog: m0,
  scaleOrdinal: zf,
  scalePoint: ln,
  scalePow: Xf,
  scaleQuantile: x0,
  scaleQuantize: w0,
  scaleRadial: b0,
  scaleSequential: C0,
  scaleSequentialLog: I0,
  scaleSequentialPow: id,
  scaleSequentialQuantile: N0,
  scaleSequentialSqrt: Dj,
  scaleSequentialSymlog: $0,
  scaleSqrt: mT,
  scaleSymlog: g0,
  scaleThreshold: O0,
  scaleTime: Nj,
  scaleUtc: kj,
  tickFormat: p0
}, Symbol.toStringTag, { value: "Module" }));
var oc, Yy;
function L0() {
  if (Yy) return oc;
  Yy = 1;
  var e = Br();
  function t(r, n, i) {
    for (var a = -1, o = r.length; ++a < o; ) {
      var u = r[a], s = n(u);
      if (s != null && (c === void 0 ? s === s && !e(s) : i(s, c)))
        var c = s, f = u;
    }
    return f;
  }
  return oc = t, oc;
}
var uc, Zy;
function Lj() {
  if (Zy) return uc;
  Zy = 1;
  function e(t, r) {
    return t > r;
  }
  return uc = e, uc;
}
var sc, Qy;
function qj() {
  if (Qy) return sc;
  Qy = 1;
  var e = L0(), t = Lj(), r = Ur();
  function n(i) {
    return i && i.length ? e(i, r, t) : void 0;
  }
  return sc = n, sc;
}
var Bj = qj();
const Tt = /* @__PURE__ */ ce(Bj);
var cc, Jy;
function Fj() {
  if (Jy) return cc;
  Jy = 1;
  function e(t, r) {
    return t < r;
  }
  return cc = e, cc;
}
var lc, em;
function zj() {
  if (em) return lc;
  em = 1;
  var e = L0(), t = Fj(), r = Ur();
  function n(i) {
    return i && i.length ? e(i, r, t) : void 0;
  }
  return lc = n, lc;
}
var Uj = zj();
const Ca = /* @__PURE__ */ ce(Uj);
var fc, tm;
function Wj() {
  if (tm) return fc;
  tm = 1;
  var e = Sf(), t = It(), r = Yb(), n = ke();
  function i(a, o) {
    var u = n(a) ? e : r;
    return u(a, t(o, 3));
  }
  return fc = i, fc;
}
var dc, rm;
function Hj() {
  if (rm) return dc;
  rm = 1;
  var e = Vb(), t = Wj();
  function r(n, i) {
    return e(t(n, i), 1);
  }
  return dc = r, dc;
}
var Kj = Hj();
const Gj = /* @__PURE__ */ ce(Kj);
var hc, nm;
function Vj() {
  if (nm) return hc;
  nm = 1;
  var e = Rf();
  function t(r, n) {
    return e(r, n);
  }
  return hc = t, hc;
}
var Xj = Vj();
const Pn = /* @__PURE__ */ ce(Xj);
var Hr = 1e9, Yj = {
  // These values must be integers within the stated ranges (inclusive).
  // Most of these values can be changed during run-time using `Decimal.config`.
  // The maximum number of significant digits of the result of a calculation or base conversion.
  // E.g. `Decimal.config({ precision: 20 });`
  precision: 20,
  // 1 to MAX_DIGITS
  // The rounding mode used by default by `toInteger`, `toDecimalPlaces`, `toExponential`,
  // `toFixed`, `toPrecision` and `toSignificantDigits`.
  //
  // ROUND_UP         0 Away from zero.
  // ROUND_DOWN       1 Towards zero.
  // ROUND_CEIL       2 Towards +Infinity.
  // ROUND_FLOOR      3 Towards -Infinity.
  // ROUND_HALF_UP    4 Towards nearest neighbour. If equidistant, up.
  // ROUND_HALF_DOWN  5 Towards nearest neighbour. If equidistant, down.
  // ROUND_HALF_EVEN  6 Towards nearest neighbour. If equidistant, towards even neighbour.
  // ROUND_HALF_CEIL  7 Towards nearest neighbour. If equidistant, towards +Infinity.
  // ROUND_HALF_FLOOR 8 Towards nearest neighbour. If equidistant, towards -Infinity.
  //
  // E.g.
  // `Decimal.rounding = 4;`
  // `Decimal.rounding = Decimal.ROUND_HALF_UP;`
  rounding: 4,
  // 0 to 8
  // The exponent value at and beneath which `toString` returns exponential notation.
  // JavaScript numbers: -7
  toExpNeg: -7,
  // 0 to -MAX_E
  // The exponent value at and above which `toString` returns exponential notation.
  // JavaScript numbers: 21
  toExpPos: 21,
  // 0 to MAX_E
  // The natural logarithm of 10.
  // 115 digits
  LN10: "2.302585092994045684017991454684364207601101488628772976033327900967572609677352480235997205089598298341967784042286"
}, ud, de = !0, Ve = "[DecimalError] ", Kt = Ve + "Invalid argument: ", od = Ve + "Exponent out of range: ", Kr = Math.floor, Ft = Math.pow, Zj = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i, qe, Ae = 1e7, fe = 7, q0 = 9007199254740991, Ri = Kr(q0 / fe), H = {};
H.absoluteValue = H.abs = function() {
  var e = new this.constructor(this);
  return e.s && (e.s = 1), e;
};
H.comparedTo = H.cmp = function(e) {
  var t, r, n, i, a = this;
  if (e = new a.constructor(e), a.s !== e.s) return a.s || -e.s;
  if (a.e !== e.e) return a.e > e.e ^ a.s < 0 ? 1 : -1;
  for (n = a.d.length, i = e.d.length, t = 0, r = n < i ? n : i; t < r; ++t)
    if (a.d[t] !== e.d[t]) return a.d[t] > e.d[t] ^ a.s < 0 ? 1 : -1;
  return n === i ? 0 : n > i ^ a.s < 0 ? 1 : -1;
};
H.decimalPlaces = H.dp = function() {
  var e = this, t = e.d.length - 1, r = (t - e.e) * fe;
  if (t = e.d[t], t) for (; t % 10 == 0; t /= 10) r--;
  return r < 0 ? 0 : r;
};
H.dividedBy = H.div = function(e) {
  return pt(this, new this.constructor(e));
};
H.dividedToIntegerBy = H.idiv = function(e) {
  var t = this, r = t.constructor;
  return ue(pt(t, new r(e), 0, 1), r.precision);
};
H.equals = H.eq = function(e) {
  return !this.cmp(e);
};
H.exponent = function() {
  return ge(this);
};
H.greaterThan = H.gt = function(e) {
  return this.cmp(e) > 0;
};
H.greaterThanOrEqualTo = H.gte = function(e) {
  return this.cmp(e) >= 0;
};
H.isInteger = H.isint = function() {
  return this.e > this.d.length - 2;
};
H.isNegative = H.isneg = function() {
  return this.s < 0;
};
H.isPositive = H.ispos = function() {
  return this.s > 0;
};
H.isZero = function() {
  return this.s === 0;
};
H.lessThan = H.lt = function(e) {
  return this.cmp(e) < 0;
};
H.lessThanOrEqualTo = H.lte = function(e) {
  return this.cmp(e) < 1;
};
H.logarithm = H.log = function(e) {
  var t, r = this, n = r.constructor, i = n.precision, a = i + 5;
  if (e === void 0)
    e = new n(10);
  else if (e = new n(e), e.s < 1 || e.eq(qe)) throw Error(Ve + "NaN");
  if (r.s < 1) throw Error(Ve + (r.s ? "NaN" : "-Infinity"));
  return r.eq(qe) ? new n(0) : (de = !1, t = pt(Tn(r, a), Tn(e, a), a), de = !0, ue(t, i));
};
H.minus = H.sub = function(e) {
  var t = this;
  return e = new t.constructor(e), t.s == e.s ? z0(t, e) : B0(t, (e.s = -e.s, e));
};
H.modulo = H.mod = function(e) {
  var t, r = this, n = r.constructor, i = n.precision;
  if (e = new n(e), !e.s) throw Error(Ve + "NaN");
  return r.s ? (de = !1, t = pt(r, e, 0, 1).times(e), de = !0, r.minus(t)) : ue(new n(r), i);
};
H.naturalExponential = H.exp = function() {
  return F0(this);
};
H.naturalLogarithm = H.ln = function() {
  return Tn(this);
};
H.negated = H.neg = function() {
  var e = new this.constructor(this);
  return e.s = -e.s || 0, e;
};
H.plus = H.add = function(e) {
  var t = this;
  return e = new t.constructor(e), t.s == e.s ? B0(t, e) : z0(t, (e.s = -e.s, e));
};
H.precision = H.sd = function(e) {
  var t, r, n, i = this;
  if (e !== void 0 && e !== !!e && e !== 1 && e !== 0) throw Error(Kt + e);
  if (t = ge(i) + 1, n = i.d.length - 1, r = n * fe + 1, n = i.d[n], n) {
    for (; n % 10 == 0; n /= 10) r--;
    for (n = i.d[0]; n >= 10; n /= 10) r++;
  }
  return e && t > r ? t : r;
};
H.squareRoot = H.sqrt = function() {
  var e, t, r, n, i, a, o, u = this, s = u.constructor;
  if (u.s < 1) {
    if (!u.s) return new s(0);
    throw Error(Ve + "NaN");
  }
  for (e = ge(u), de = !1, i = Math.sqrt(+u), i == 0 || i == 1 / 0 ? (t = nt(u.d), (t.length + e) % 2 == 0 && (t += "0"), i = Math.sqrt(t), e = Kr((e + 1) / 2) - (e < 0 || e % 2), i == 1 / 0 ? t = "5e" + e : (t = i.toExponential(), t = t.slice(0, t.indexOf("e") + 1) + e), n = new s(t)) : n = new s(i.toString()), r = s.precision, i = o = r + 3; ; )
    if (a = n, n = a.plus(pt(u, a, o + 2)).times(0.5), nt(a.d).slice(0, o) === (t = nt(n.d)).slice(0, o)) {
      if (t = t.slice(o - 3, o + 1), i == o && t == "4999") {
        if (ue(a, r + 1, 0), a.times(a).eq(u)) {
          n = a;
          break;
        }
      } else if (t != "9999")
        break;
      o += 4;
    }
  return de = !0, ue(n, r);
};
H.times = H.mul = function(e) {
  var t, r, n, i, a, o, u, s, c, f = this, l = f.constructor, d = f.d, p = (e = new l(e)).d;
  if (!f.s || !e.s) return new l(0);
  for (e.s *= f.s, r = f.e + e.e, s = d.length, c = p.length, s < c && (a = d, d = p, p = a, o = s, s = c, c = o), a = [], o = s + c, n = o; n--; ) a.push(0);
  for (n = c; --n >= 0; ) {
    for (t = 0, i = s + n; i > n; )
      u = a[i] + p[n] * d[i - n - 1] + t, a[i--] = u % Ae | 0, t = u / Ae | 0;
    a[i] = (a[i] + t) % Ae | 0;
  }
  for (; !a[--o]; ) a.pop();
  return t ? ++r : a.shift(), e.d = a, e.e = r, de ? ue(e, l.precision) : e;
};
H.toDecimalPlaces = H.todp = function(e, t) {
  var r = this, n = r.constructor;
  return r = new n(r), e === void 0 ? r : (ot(e, 0, Hr), t === void 0 ? t = n.rounding : ot(t, 0, 8), ue(r, e + ge(r) + 1, t));
};
H.toExponential = function(e, t) {
  var r, n = this, i = n.constructor;
  return e === void 0 ? r = Xt(n, !0) : (ot(e, 0, Hr), t === void 0 ? t = i.rounding : ot(t, 0, 8), n = ue(new i(n), e + 1, t), r = Xt(n, !0, e + 1)), r;
};
H.toFixed = function(e, t) {
  var r, n, i = this, a = i.constructor;
  return e === void 0 ? Xt(i) : (ot(e, 0, Hr), t === void 0 ? t = a.rounding : ot(t, 0, 8), n = ue(new a(i), e + ge(i) + 1, t), r = Xt(n.abs(), !1, e + ge(n) + 1), i.isneg() && !i.isZero() ? "-" + r : r);
};
H.toInteger = H.toint = function() {
  var e = this, t = e.constructor;
  return ue(new t(e), ge(e) + 1, t.rounding);
};
H.toNumber = function() {
  return +this;
};
H.toPower = H.pow = function(e) {
  var t, r, n, i, a, o, u = this, s = u.constructor, c = 12, f = +(e = new s(e));
  if (!e.s) return new s(qe);
  if (u = new s(u), !u.s) {
    if (e.s < 1) throw Error(Ve + "Infinity");
    return u;
  }
  if (u.eq(qe)) return u;
  if (n = s.precision, e.eq(qe)) return ue(u, n);
  if (t = e.e, r = e.d.length - 1, o = t >= r, a = u.s, o) {
    if ((r = f < 0 ? -f : f) <= q0) {
      for (i = new s(qe), t = Math.ceil(n / fe + 4), de = !1; r % 2 && (i = i.times(u), am(i.d, t)), r = Kr(r / 2), r !== 0; )
        u = u.times(u), am(u.d, t);
      return de = !0, e.s < 0 ? new s(qe).div(i) : ue(i, n);
    }
  } else if (a < 0) throw Error(Ve + "NaN");
  return a = a < 0 && e.d[Math.max(t, r)] & 1 ? -1 : 1, u.s = 1, de = !1, i = e.times(Tn(u, n + c)), de = !0, i = F0(i), i.s = a, i;
};
H.toPrecision = function(e, t) {
  var r, n, i = this, a = i.constructor;
  return e === void 0 ? (r = ge(i), n = Xt(i, r <= a.toExpNeg || r >= a.toExpPos)) : (ot(e, 1, Hr), t === void 0 ? t = a.rounding : ot(t, 0, 8), i = ue(new a(i), e, t), r = ge(i), n = Xt(i, e <= r || r <= a.toExpNeg, e)), n;
};
H.toSignificantDigits = H.tosd = function(e, t) {
  var r = this, n = r.constructor;
  return e === void 0 ? (e = n.precision, t = n.rounding) : (ot(e, 1, Hr), t === void 0 ? t = n.rounding : ot(t, 0, 8)), ue(new n(r), e, t);
};
H.toString = H.valueOf = H.val = H.toJSON = H[Symbol.for("nodejs.util.inspect.custom")] = function() {
  var e = this, t = ge(e), r = e.constructor;
  return Xt(e, t <= r.toExpNeg || t >= r.toExpPos);
};
function B0(e, t) {
  var r, n, i, a, o, u, s, c, f = e.constructor, l = f.precision;
  if (!e.s || !t.s)
    return t.s || (t = new f(e)), de ? ue(t, l) : t;
  if (s = e.d, c = t.d, o = e.e, i = t.e, s = s.slice(), a = o - i, a) {
    for (a < 0 ? (n = s, a = -a, u = c.length) : (n = c, i = o, u = s.length), o = Math.ceil(l / fe), u = o > u ? o + 1 : u + 1, a > u && (a = u, n.length = 1), n.reverse(); a--; ) n.push(0);
    n.reverse();
  }
  for (u = s.length, a = c.length, u - a < 0 && (a = u, n = c, c = s, s = n), r = 0; a; )
    r = (s[--a] = s[a] + c[a] + r) / Ae | 0, s[a] %= Ae;
  for (r && (s.unshift(r), ++i), u = s.length; s[--u] == 0; ) s.pop();
  return t.d = s, t.e = i, de ? ue(t, l) : t;
}
function ot(e, t, r) {
  if (e !== ~~e || e < t || e > r)
    throw Error(Kt + e);
}
function nt(e) {
  var t, r, n, i = e.length - 1, a = "", o = e[0];
  if (i > 0) {
    for (a += o, t = 1; t < i; t++)
      n = e[t] + "", r = fe - n.length, r && (a += At(r)), a += n;
    o = e[t], n = o + "", r = fe - n.length, r && (a += At(r));
  } else if (o === 0)
    return "0";
  for (; o % 10 === 0; ) o /= 10;
  return a + o;
}
var pt = /* @__PURE__ */ function() {
  function e(n, i) {
    var a, o = 0, u = n.length;
    for (n = n.slice(); u--; )
      a = n[u] * i + o, n[u] = a % Ae | 0, o = a / Ae | 0;
    return o && n.unshift(o), n;
  }
  function t(n, i, a, o) {
    var u, s;
    if (a != o)
      s = a > o ? 1 : -1;
    else
      for (u = s = 0; u < a; u++)
        if (n[u] != i[u]) {
          s = n[u] > i[u] ? 1 : -1;
          break;
        }
    return s;
  }
  function r(n, i, a) {
    for (var o = 0; a--; )
      n[a] -= o, o = n[a] < i[a] ? 1 : 0, n[a] = o * Ae + n[a] - i[a];
    for (; !n[0] && n.length > 1; ) n.shift();
  }
  return function(n, i, a, o) {
    var u, s, c, f, l, d, p, y, v, h, w, b, x, O, m, g, _, A, P = n.constructor, $ = n.s == i.s ? 1 : -1, M = n.d, j = i.d;
    if (!n.s) return new P(n);
    if (!i.s) throw Error(Ve + "Division by zero");
    for (s = n.e - i.e, _ = j.length, m = M.length, p = new P($), y = p.d = [], c = 0; j[c] == (M[c] || 0); ) ++c;
    if (j[c] > (M[c] || 0) && --s, a == null ? b = a = P.precision : o ? b = a + (ge(n) - ge(i)) + 1 : b = a, b < 0) return new P(0);
    if (b = b / fe + 2 | 0, c = 0, _ == 1)
      for (f = 0, j = j[0], b++; (c < m || f) && b--; c++)
        x = f * Ae + (M[c] || 0), y[c] = x / j | 0, f = x % j | 0;
    else {
      for (f = Ae / (j[0] + 1) | 0, f > 1 && (j = e(j, f), M = e(M, f), _ = j.length, m = M.length), O = _, v = M.slice(0, _), h = v.length; h < _; ) v[h++] = 0;
      A = j.slice(), A.unshift(0), g = j[0], j[1] >= Ae / 2 && ++g;
      do
        f = 0, u = t(j, v, _, h), u < 0 ? (w = v[0], _ != h && (w = w * Ae + (v[1] || 0)), f = w / g | 0, f > 1 ? (f >= Ae && (f = Ae - 1), l = e(j, f), d = l.length, h = v.length, u = t(l, v, d, h), u == 1 && (f--, r(l, _ < d ? A : j, d))) : (f == 0 && (u = f = 1), l = j.slice()), d = l.length, d < h && l.unshift(0), r(v, l, h), u == -1 && (h = v.length, u = t(j, v, _, h), u < 1 && (f++, r(v, _ < h ? A : j, h))), h = v.length) : u === 0 && (f++, v = [0]), y[c++] = f, u && v[0] ? v[h++] = M[O] || 0 : (v = [M[O]], h = 1);
      while ((O++ < m || v[0] !== void 0) && b--);
    }
    return y[0] || y.shift(), p.e = s, ue(p, o ? a + ge(p) + 1 : a);
  };
}();
function F0(e, t) {
  var r, n, i, a, o, u, s = 0, c = 0, f = e.constructor, l = f.precision;
  if (ge(e) > 16) throw Error(od + ge(e));
  if (!e.s) return new f(qe);
  for (de = !1, u = l, o = new f(0.03125); e.abs().gte(0.1); )
    e = e.times(o), c += 5;
  for (n = Math.log(Ft(2, c)) / Math.LN10 * 2 + 5 | 0, u += n, r = i = a = new f(qe), f.precision = u; ; ) {
    if (i = ue(i.times(e), u), r = r.times(++s), o = a.plus(pt(i, r, u)), nt(o.d).slice(0, u) === nt(a.d).slice(0, u)) {
      for (; c--; ) a = ue(a.times(a), u);
      return f.precision = l, t == null ? (de = !0, ue(a, l)) : a;
    }
    a = o;
  }
}
function ge(e) {
  for (var t = e.e * fe, r = e.d[0]; r >= 10; r /= 10) t++;
  return t;
}
function pc(e, t, r) {
  if (t > e.LN10.sd())
    throw de = !0, r && (e.precision = r), Error(Ve + "LN10 precision limit exceeded");
  return ue(new e(e.LN10), t);
}
function At(e) {
  for (var t = ""; e--; ) t += "0";
  return t;
}
function Tn(e, t) {
  var r, n, i, a, o, u, s, c, f, l = 1, d = 10, p = e, y = p.d, v = p.constructor, h = v.precision;
  if (p.s < 1) throw Error(Ve + (p.s ? "NaN" : "-Infinity"));
  if (p.eq(qe)) return new v(0);
  if (t == null ? (de = !1, c = h) : c = t, p.eq(10))
    return t == null && (de = !0), pc(v, c);
  if (c += d, v.precision = c, r = nt(y), n = r.charAt(0), a = ge(p), Math.abs(a) < 15e14) {
    for (; n < 7 && n != 1 || n == 1 && r.charAt(1) > 3; )
      p = p.times(e), r = nt(p.d), n = r.charAt(0), l++;
    a = ge(p), n > 1 ? (p = new v("0." + r), a++) : p = new v(n + "." + r.slice(1));
  } else
    return s = pc(v, c + 2, h).times(a + ""), p = Tn(new v(n + "." + r.slice(1)), c - d).plus(s), v.precision = h, t == null ? (de = !0, ue(p, h)) : p;
  for (u = o = p = pt(p.minus(qe), p.plus(qe), c), f = ue(p.times(p), c), i = 3; ; ) {
    if (o = ue(o.times(f), c), s = u.plus(pt(o, new v(i), c)), nt(s.d).slice(0, c) === nt(u.d).slice(0, c))
      return u = u.times(2), a !== 0 && (u = u.plus(pc(v, c + 2, h).times(a + ""))), u = pt(u, new v(l), c), v.precision = h, t == null ? (de = !0, ue(u, h)) : u;
    u = s, i += 2;
  }
}
function im(e, t) {
  var r, n, i;
  for ((r = t.indexOf(".")) > -1 && (t = t.replace(".", "")), (n = t.search(/e/i)) > 0 ? (r < 0 && (r = n), r += +t.slice(n + 1), t = t.substring(0, n)) : r < 0 && (r = t.length), n = 0; t.charCodeAt(n) === 48; ) ++n;
  for (i = t.length; t.charCodeAt(i - 1) === 48; ) --i;
  if (t = t.slice(n, i), t) {
    if (i -= n, r = r - n - 1, e.e = Kr(r / fe), e.d = [], n = (r + 1) % fe, r < 0 && (n += fe), n < i) {
      for (n && e.d.push(+t.slice(0, n)), i -= fe; n < i; ) e.d.push(+t.slice(n, n += fe));
      t = t.slice(n), n = fe - t.length;
    } else
      n -= i;
    for (; n--; ) t += "0";
    if (e.d.push(+t), de && (e.e > Ri || e.e < -Ri)) throw Error(od + r);
  } else
    e.s = 0, e.e = 0, e.d = [0];
  return e;
}
function ue(e, t, r) {
  var n, i, a, o, u, s, c, f, l = e.d;
  for (o = 1, a = l[0]; a >= 10; a /= 10) o++;
  if (n = t - o, n < 0)
    n += fe, i = t, c = l[f = 0];
  else {
    if (f = Math.ceil((n + 1) / fe), a = l.length, f >= a) return e;
    for (c = a = l[f], o = 1; a >= 10; a /= 10) o++;
    n %= fe, i = n - fe + o;
  }
  if (r !== void 0 && (a = Ft(10, o - i - 1), u = c / a % 10 | 0, s = t < 0 || l[f + 1] !== void 0 || c % a, s = r < 4 ? (u || s) && (r == 0 || r == (e.s < 0 ? 3 : 2)) : u > 5 || u == 5 && (r == 4 || s || r == 6 && // Check whether the digit to the left of the rounding digit is odd.
  (n > 0 ? i > 0 ? c / Ft(10, o - i) : 0 : l[f - 1]) % 10 & 1 || r == (e.s < 0 ? 8 : 7))), t < 1 || !l[0])
    return s ? (a = ge(e), l.length = 1, t = t - a - 1, l[0] = Ft(10, (fe - t % fe) % fe), e.e = Kr(-t / fe) || 0) : (l.length = 1, l[0] = e.e = e.s = 0), e;
  if (n == 0 ? (l.length = f, a = 1, f--) : (l.length = f + 1, a = Ft(10, fe - n), l[f] = i > 0 ? (c / Ft(10, o - i) % Ft(10, i) | 0) * a : 0), s)
    for (; ; )
      if (f == 0) {
        (l[0] += a) == Ae && (l[0] = 1, ++e.e);
        break;
      } else {
        if (l[f] += a, l[f] != Ae) break;
        l[f--] = 0, a = 1;
      }
  for (n = l.length; l[--n] === 0; ) l.pop();
  if (de && (e.e > Ri || e.e < -Ri))
    throw Error(od + ge(e));
  return e;
}
function z0(e, t) {
  var r, n, i, a, o, u, s, c, f, l, d = e.constructor, p = d.precision;
  if (!e.s || !t.s)
    return t.s ? t.s = -t.s : t = new d(e), de ? ue(t, p) : t;
  if (s = e.d, l = t.d, n = t.e, c = e.e, s = s.slice(), o = c - n, o) {
    for (f = o < 0, f ? (r = s, o = -o, u = l.length) : (r = l, n = c, u = s.length), i = Math.max(Math.ceil(p / fe), u) + 2, o > i && (o = i, r.length = 1), r.reverse(), i = o; i--; ) r.push(0);
    r.reverse();
  } else {
    for (i = s.length, u = l.length, f = i < u, f && (u = i), i = 0; i < u; i++)
      if (s[i] != l[i]) {
        f = s[i] < l[i];
        break;
      }
    o = 0;
  }
  for (f && (r = s, s = l, l = r, t.s = -t.s), u = s.length, i = l.length - u; i > 0; --i) s[u++] = 0;
  for (i = l.length; i > o; ) {
    if (s[--i] < l[i]) {
      for (a = i; a && s[--a] === 0; ) s[a] = Ae - 1;
      --s[a], s[i] += Ae;
    }
    s[i] -= l[i];
  }
  for (; s[--u] === 0; ) s.pop();
  for (; s[0] === 0; s.shift()) --n;
  return s[0] ? (t.d = s, t.e = n, de ? ue(t, p) : t) : new d(0);
}
function Xt(e, t, r) {
  var n, i = ge(e), a = nt(e.d), o = a.length;
  return t ? (r && (n = r - o) > 0 ? a = a.charAt(0) + "." + a.slice(1) + At(n) : o > 1 && (a = a.charAt(0) + "." + a.slice(1)), a = a + (i < 0 ? "e" : "e+") + i) : i < 0 ? (a = "0." + At(-i - 1) + a, r && (n = r - o) > 0 && (a += At(n))) : i >= o ? (a += At(i + 1 - o), r && (n = r - i - 1) > 0 && (a = a + "." + At(n))) : ((n = i + 1) < o && (a = a.slice(0, n) + "." + a.slice(n)), r && (n = r - o) > 0 && (i + 1 === o && (a += "."), a += At(n))), e.s < 0 ? "-" + a : a;
}
function am(e, t) {
  if (e.length > t)
    return e.length = t, !0;
}
function U0(e) {
  var t, r, n;
  function i(a) {
    var o = this;
    if (!(o instanceof i)) return new i(a);
    if (o.constructor = i, a instanceof i) {
      o.s = a.s, o.e = a.e, o.d = (a = a.d) ? a.slice() : a;
      return;
    }
    if (typeof a == "number") {
      if (a * 0 !== 0)
        throw Error(Kt + a);
      if (a > 0)
        o.s = 1;
      else if (a < 0)
        a = -a, o.s = -1;
      else {
        o.s = 0, o.e = 0, o.d = [0];
        return;
      }
      if (a === ~~a && a < 1e7) {
        o.e = 0, o.d = [a];
        return;
      }
      return im(o, a.toString());
    } else if (typeof a != "string")
      throw Error(Kt + a);
    if (a.charCodeAt(0) === 45 ? (a = a.slice(1), o.s = -1) : o.s = 1, Zj.test(a)) im(o, a);
    else throw Error(Kt + a);
  }
  if (i.prototype = H, i.ROUND_UP = 0, i.ROUND_DOWN = 1, i.ROUND_CEIL = 2, i.ROUND_FLOOR = 3, i.ROUND_HALF_UP = 4, i.ROUND_HALF_DOWN = 5, i.ROUND_HALF_EVEN = 6, i.ROUND_HALF_CEIL = 7, i.ROUND_HALF_FLOOR = 8, i.clone = U0, i.config = i.set = Qj, e === void 0 && (e = {}), e)
    for (n = ["precision", "rounding", "toExpNeg", "toExpPos", "LN10"], t = 0; t < n.length; ) e.hasOwnProperty(r = n[t++]) || (e[r] = this[r]);
  return i.config(e), i;
}
function Qj(e) {
  if (!e || typeof e != "object")
    throw Error(Ve + "Object expected");
  var t, r, n, i = [
    "precision",
    1,
    Hr,
    "rounding",
    0,
    8,
    "toExpNeg",
    -1 / 0,
    0,
    "toExpPos",
    0,
    1 / 0
  ];
  for (t = 0; t < i.length; t += 3)
    if ((n = e[r = i[t]]) !== void 0)
      if (Kr(n) === n && n >= i[t + 1] && n <= i[t + 2]) this[r] = n;
      else throw Error(Kt + r + ": " + n);
  if ((n = e[r = "LN10"]) !== void 0)
    if (n == Math.LN10) this[r] = new this(n);
    else throw Error(Kt + r + ": " + n);
  return this;
}
var ud = U0(Yj);
qe = new ud(1);
const oe = ud;
function Jj(e) {
  return nE(e) || rE(e) || tE(e) || eE();
}
function eE() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function tE(e, t) {
  if (e) {
    if (typeof e == "string") return Al(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Al(e, t);
  }
}
function rE(e) {
  if (typeof Symbol < "u" && Symbol.iterator in Object(e)) return Array.from(e);
}
function nE(e) {
  if (Array.isArray(e)) return Al(e);
}
function Al(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++)
    n[r] = e[r];
  return n;
}
var iE = function(t) {
  return t;
}, W0 = {}, H0 = function(t) {
  return t === W0;
}, om = function(t) {
  return function r() {
    return arguments.length === 0 || arguments.length === 1 && H0(arguments.length <= 0 ? void 0 : arguments[0]) ? r : t.apply(void 0, arguments);
  };
}, aE = function e(t, r) {
  return t === 1 ? r : om(function() {
    for (var n = arguments.length, i = new Array(n), a = 0; a < n; a++)
      i[a] = arguments[a];
    var o = i.filter(function(u) {
      return u !== W0;
    }).length;
    return o >= t ? r.apply(void 0, i) : e(t - o, om(function() {
      for (var u = arguments.length, s = new Array(u), c = 0; c < u; c++)
        s[c] = arguments[c];
      var f = i.map(function(l) {
        return H0(l) ? s.shift() : l;
      });
      return r.apply(void 0, Jj(f).concat(s));
    }));
  });
}, Ia = function(t) {
  return aE(t.length, t);
}, Pl = function(t, r) {
  for (var n = [], i = t; i < r; ++i)
    n[i - t] = i;
  return n;
}, oE = Ia(function(e, t) {
  return Array.isArray(t) ? t.map(e) : Object.keys(t).map(function(r) {
    return t[r];
  }).map(e);
}), uE = function() {
  for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
    r[n] = arguments[n];
  if (!r.length)
    return iE;
  var i = r.reverse(), a = i[0], o = i.slice(1);
  return function() {
    return o.reduce(function(u, s) {
      return s(u);
    }, a.apply(void 0, arguments));
  };
}, Tl = function(t) {
  return Array.isArray(t) ? t.reverse() : t.split("").reverse.join("");
}, K0 = function(t) {
  var r = null, n = null;
  return function() {
    for (var i = arguments.length, a = new Array(i), o = 0; o < i; o++)
      a[o] = arguments[o];
    return r && a.every(function(u, s) {
      return u === r[s];
    }) || (r = a, n = t.apply(void 0, a)), n;
  };
};
function sE(e) {
  var t;
  return e === 0 ? t = 1 : t = Math.floor(new oe(e).abs().log(10).toNumber()) + 1, t;
}
function cE(e, t, r) {
  for (var n = new oe(e), i = 0, a = []; n.lt(t) && i < 1e5; )
    a.push(n.toNumber()), n = n.add(r), i++;
  return a;
}
var lE = Ia(function(e, t, r) {
  var n = +e, i = +t;
  return n + r * (i - n);
}), fE = Ia(function(e, t, r) {
  var n = t - +e;
  return n = n || 1 / 0, (r - e) / n;
}), dE = Ia(function(e, t, r) {
  var n = t - +e;
  return n = n || 1 / 0, Math.max(0, Math.min(1, (r - e) / n));
});
const $a = {
  rangeStep: cE,
  getDigitCount: sE,
  interpolateNumber: lE,
  uninterpolateNumber: fE,
  uninterpolateTruncation: dE
};
function jl(e) {
  return vE(e) || pE(e) || G0(e) || hE();
}
function hE() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function pE(e) {
  if (typeof Symbol < "u" && Symbol.iterator in Object(e)) return Array.from(e);
}
function vE(e) {
  if (Array.isArray(e)) return El(e);
}
function jn(e, t) {
  return gE(e) || mE(e, t) || G0(e, t) || yE();
}
function yE() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function G0(e, t) {
  if (e) {
    if (typeof e == "string") return El(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return El(e, t);
  }
}
function El(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++)
    n[r] = e[r];
  return n;
}
function mE(e, t) {
  if (!(typeof Symbol > "u" || !(Symbol.iterator in Object(e)))) {
    var r = [], n = !0, i = !1, a = void 0;
    try {
      for (var o = e[Symbol.iterator](), u; !(n = (u = o.next()).done) && (r.push(u.value), !(t && r.length === t)); n = !0)
        ;
    } catch (s) {
      i = !0, a = s;
    } finally {
      try {
        !n && o.return != null && o.return();
      } finally {
        if (i) throw a;
      }
    }
    return r;
  }
}
function gE(e) {
  if (Array.isArray(e)) return e;
}
function V0(e) {
  var t = jn(e, 2), r = t[0], n = t[1], i = r, a = n;
  return r > n && (i = n, a = r), [i, a];
}
function X0(e, t, r) {
  if (e.lte(0))
    return new oe(0);
  var n = $a.getDigitCount(e.toNumber()), i = new oe(10).pow(n), a = e.div(i), o = n !== 1 ? 0.05 : 0.1, u = new oe(Math.ceil(a.div(o).toNumber())).add(r).mul(o), s = u.mul(i);
  return t ? s : new oe(Math.ceil(s));
}
function bE(e, t, r) {
  var n = 1, i = new oe(e);
  if (!i.isint() && r) {
    var a = Math.abs(e);
    a < 1 ? (n = new oe(10).pow($a.getDigitCount(e) - 1), i = new oe(Math.floor(i.div(n).toNumber())).mul(n)) : a > 1 && (i = new oe(Math.floor(e)));
  } else e === 0 ? i = new oe(Math.floor((t - 1) / 2)) : r || (i = new oe(Math.floor(e)));
  var o = Math.floor((t - 1) / 2), u = uE(oE(function(s) {
    return i.add(new oe(s - o).mul(n)).toNumber();
  }), Pl);
  return u(0, t);
}
function Y0(e, t, r, n) {
  var i = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : 0;
  if (!Number.isFinite((t - e) / (r - 1)))
    return {
      step: new oe(0),
      tickMin: new oe(0),
      tickMax: new oe(0)
    };
  var a = X0(new oe(t).sub(e).div(r - 1), n, i), o;
  e <= 0 && t >= 0 ? o = new oe(0) : (o = new oe(e).add(t).div(2), o = o.sub(new oe(o).mod(a)));
  var u = Math.ceil(o.sub(e).div(a).toNumber()), s = Math.ceil(new oe(t).sub(o).div(a).toNumber()), c = u + s + 1;
  return c > r ? Y0(e, t, r, n, i + 1) : (c < r && (s = t > 0 ? s + (r - c) : s, u = t > 0 ? u : u + (r - c)), {
    step: a,
    tickMin: o.sub(new oe(u).mul(a)),
    tickMax: o.add(new oe(s).mul(a))
  });
}
function xE(e) {
  var t = jn(e, 2), r = t[0], n = t[1], i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 6, a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, o = Math.max(i, 2), u = V0([r, n]), s = jn(u, 2), c = s[0], f = s[1];
  if (c === -1 / 0 || f === 1 / 0) {
    var l = f === 1 / 0 ? [c].concat(jl(Pl(0, i - 1).map(function() {
      return 1 / 0;
    }))) : [].concat(jl(Pl(0, i - 1).map(function() {
      return -1 / 0;
    })), [f]);
    return r > n ? Tl(l) : l;
  }
  if (c === f)
    return bE(c, i, a);
  var d = Y0(c, f, o, a), p = d.step, y = d.tickMin, v = d.tickMax, h = $a.rangeStep(y, v.add(new oe(0.1).mul(p)), p);
  return r > n ? Tl(h) : h;
}
function wE(e, t) {
  var r = jn(e, 2), n = r[0], i = r[1], a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0, o = V0([n, i]), u = jn(o, 2), s = u[0], c = u[1];
  if (s === -1 / 0 || c === 1 / 0)
    return [n, i];
  if (s === c)
    return [s];
  var f = Math.max(t, 2), l = X0(new oe(c).sub(s).div(f - 1), a, 0), d = [].concat(jl($a.rangeStep(new oe(s), new oe(c).sub(new oe(0.99).mul(l)), l)), [c]);
  return n > i ? Tl(d) : d;
}
var OE = K0(xE), _E = K0(wE), SE = "Invariant failed";
function Yt(e, t) {
  throw new Error(SE);
}
var AE = ["offset", "layout", "width", "dataKey", "data", "dataPointFormatter", "xAxis", "yAxis"];
function Ar(e) {
  "@babel/helpers - typeof";
  return Ar = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Ar(e);
}
function Li() {
  return Li = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Li.apply(this, arguments);
}
function PE(e, t) {
  return ME(e) || EE(e, t) || jE(e, t) || TE();
}
function TE() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function jE(e, t) {
  if (e) {
    if (typeof e == "string") return um(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return um(e, t);
  }
}
function um(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function EE(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function ME(e) {
  if (Array.isArray(e)) return e;
}
function CE(e, t) {
  if (e == null) return {};
  var r = IE(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function IE(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function $E(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function NE(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, J0(n.key), n);
  }
}
function kE(e, t, r) {
  return t && NE(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function DE(e, t, r) {
  return t = qi(t), RE(e, Z0() ? Reflect.construct(t, r || [], qi(e).constructor) : t.apply(e, r));
}
function RE(e, t) {
  if (t && (Ar(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return LE(e);
}
function LE(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Z0() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Z0 = function() {
    return !!e;
  })();
}
function qi(e) {
  return qi = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, qi(e);
}
function qE(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && Ml(e, t);
}
function Ml(e, t) {
  return Ml = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, Ml(e, t);
}
function Q0(e, t, r) {
  return t = J0(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function J0(e) {
  var t = BE(e, "string");
  return Ar(t) == "symbol" ? t : t + "";
}
function BE(e, t) {
  if (Ar(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Ar(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var Na = /* @__PURE__ */ function(e) {
  function t() {
    return $E(this, t), DE(this, t, arguments);
  }
  return qE(t, e), kE(t, [{
    key: "render",
    value: function() {
      var n = this.props, i = n.offset, a = n.layout, o = n.width, u = n.dataKey, s = n.data, c = n.dataPointFormatter, f = n.xAxis, l = n.yAxis, d = CE(n, AE), p = J(d, !1);
      this.props.direction === "x" && f.type !== "number" && Yt();
      var y = s.map(function(v) {
        var h = c(v, u), w = h.x, b = h.y, x = h.value, O = h.errorVal;
        if (!O)
          return null;
        var m = [], g, _;
        if (Array.isArray(O)) {
          var A = PE(O, 2);
          g = A[0], _ = A[1];
        } else
          g = _ = O;
        if (a === "vertical") {
          var P = f.scale, $ = b + i, M = $ + o, j = $ - o, E = P(x - g), C = P(x + _);
          m.push({
            x1: C,
            y1: M,
            x2: C,
            y2: j
          }), m.push({
            x1: E,
            y1: $,
            x2: C,
            y2: $
          }), m.push({
            x1: E,
            y1: M,
            x2: E,
            y2: j
          });
        } else if (a === "horizontal") {
          var I = l.scale, N = w + i, R = N - o, B = N + o, F = I(x - g), K = I(x + _);
          m.push({
            x1: R,
            y1: K,
            x2: B,
            y2: K
          }), m.push({
            x1: N,
            y1: F,
            x2: N,
            y2: K
          }), m.push({
            x1: R,
            y1: F,
            x2: B,
            y2: F
          });
        }
        return /* @__PURE__ */ T.createElement(he, Li({
          className: "recharts-errorBar",
          key: "bar-".concat(m.map(function(V) {
            return "".concat(V.x1, "-").concat(V.x2, "-").concat(V.y1, "-").concat(V.y2);
          }))
        }, p), m.map(function(V) {
          return /* @__PURE__ */ T.createElement("line", Li({}, V, {
            key: "line-".concat(V.x1, "-").concat(V.x2, "-").concat(V.y1, "-").concat(V.y2)
          }));
        }));
      });
      return /* @__PURE__ */ T.createElement(he, {
        className: "recharts-errorBars"
      }, y);
    }
  }]);
}(T.Component);
Q0(Na, "defaultProps", {
  stroke: "black",
  strokeWidth: 1.5,
  width: 5,
  offset: 0,
  layout: "horizontal"
});
Q0(Na, "displayName", "ErrorBar");
function En(e) {
  "@babel/helpers - typeof";
  return En = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, En(e);
}
function sm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function qt(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? sm(Object(r), !0).forEach(function(n) {
      FE(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : sm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function FE(e, t, r) {
  return t = zE(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function zE(e) {
  var t = UE(e, "string");
  return En(t) == "symbol" ? t : t + "";
}
function UE(e, t) {
  if (En(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (En(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var ex = function(t) {
  var r = t.children, n = t.formattedGraphicalItems, i = t.legendWidth, a = t.legendContent, o = Le(r, dr);
  if (!o)
    return null;
  var u = dr.defaultProps, s = u !== void 0 ? qt(qt({}, u), o.props) : {}, c;
  return o.props && o.props.payload ? c = o.props && o.props.payload : a === "children" ? c = (n || []).reduce(function(f, l) {
    var d = l.item, p = l.props, y = p.sectors || p.data || [];
    return f.concat(y.map(function(v) {
      return {
        type: o.props.iconType || d.props.legendType,
        value: v.name,
        color: v.fill,
        payload: v
      };
    }));
  }, []) : c = (n || []).map(function(f) {
    var l = f.item, d = l.type.defaultProps, p = d !== void 0 ? qt(qt({}, d), l.props) : {}, y = p.dataKey, v = p.name, h = p.legendType, w = p.hide;
    return {
      inactive: w,
      dataKey: y,
      type: s.iconType || h || "square",
      color: sd(l),
      value: v || y,
      // @ts-expect-error property strokeDasharray is required in Payload but optional in props
      payload: p
    };
  }), qt(qt(qt({}, s), dr.getWithHeight(o, i)), {}, {
    payload: c,
    item: o
  });
};
function Mn(e) {
  "@babel/helpers - typeof";
  return Mn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Mn(e);
}
function cm(e) {
  return GE(e) || KE(e) || HE(e) || WE();
}
function WE() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function HE(e, t) {
  if (e) {
    if (typeof e == "string") return Cl(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Cl(e, t);
  }
}
function KE(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function GE(e) {
  if (Array.isArray(e)) return Cl(e);
}
function Cl(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function lm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function ve(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? lm(Object(r), !0).forEach(function(n) {
      hr(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : lm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function hr(e, t, r) {
  return t = VE(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function VE(e) {
  var t = XE(e, "string");
  return Mn(t) == "symbol" ? t : t + "";
}
function XE(e, t) {
  if (Mn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Mn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Be(e, t, r) {
  return ee(e) || ee(t) ? r : _e(t) ? Ge(e, t, r) : Z(t) ? t(e) : r;
}
function fn(e, t, r, n) {
  var i = Gj(e, function(u) {
    return Be(u, t);
  });
  if (r === "number") {
    var a = i.filter(function(u) {
      return q(u) || parseFloat(u);
    });
    return a.length ? [Ca(a), Tt(a)] : [1 / 0, -1 / 0];
  }
  var o = n ? i.filter(function(u) {
    return !ee(u);
  }) : i;
  return o.map(function(u) {
    return _e(u) || u instanceof Date ? u : "";
  });
}
var YE = function(t) {
  var r, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [], i = arguments.length > 2 ? arguments[2] : void 0, a = arguments.length > 3 ? arguments[3] : void 0, o = -1, u = (r = n == null ? void 0 : n.length) !== null && r !== void 0 ? r : 0;
  if (u <= 1)
    return 0;
  if (a && a.axisType === "angleAxis" && Math.abs(Math.abs(a.range[1] - a.range[0]) - 360) <= 1e-6)
    for (var s = a.range, c = 0; c < u; c++) {
      var f = c > 0 ? i[c - 1].coordinate : i[u - 1].coordinate, l = i[c].coordinate, d = c >= u - 1 ? i[0].coordinate : i[c + 1].coordinate, p = void 0;
      if (Qe(l - f) !== Qe(d - l)) {
        var y = [];
        if (Qe(d - l) === Qe(s[1] - s[0])) {
          p = d;
          var v = l + s[1] - s[0];
          y[0] = Math.min(v, (v + f) / 2), y[1] = Math.max(v, (v + f) / 2);
        } else {
          p = f;
          var h = d + s[1] - s[0];
          y[0] = Math.min(l, (h + l) / 2), y[1] = Math.max(l, (h + l) / 2);
        }
        var w = [Math.min(l, (p + l) / 2), Math.max(l, (p + l) / 2)];
        if (t > w[0] && t <= w[1] || t >= y[0] && t <= y[1]) {
          o = i[c].index;
          break;
        }
      } else {
        var b = Math.min(f, d), x = Math.max(f, d);
        if (t > (b + l) / 2 && t <= (x + l) / 2) {
          o = i[c].index;
          break;
        }
      }
    }
  else
    for (var O = 0; O < u; O++)
      if (O === 0 && t <= (n[O].coordinate + n[O + 1].coordinate) / 2 || O > 0 && O < u - 1 && t > (n[O].coordinate + n[O - 1].coordinate) / 2 && t <= (n[O].coordinate + n[O + 1].coordinate) / 2 || O === u - 1 && t > (n[O].coordinate + n[O - 1].coordinate) / 2) {
        o = n[O].index;
        break;
      }
  return o;
}, sd = function(t) {
  var r, n = t, i = n.type.displayName, a = (r = t.type) !== null && r !== void 0 && r.defaultProps ? ve(ve({}, t.type.defaultProps), t.props) : t.props, o = a.stroke, u = a.fill, s;
  switch (i) {
    case "Line":
      s = o;
      break;
    case "Area":
    case "Radar":
      s = o && o !== "none" ? o : u;
      break;
    default:
      s = u;
      break;
  }
  return s;
}, ZE = function(t) {
  var r = t.barSize, n = t.totalSize, i = t.stackGroups, a = i === void 0 ? {} : i;
  if (!a)
    return {};
  for (var o = {}, u = Object.keys(a), s = 0, c = u.length; s < c; s++)
    for (var f = a[u[s]].stackGroups, l = Object.keys(f), d = 0, p = l.length; d < p; d++) {
      var y = f[l[d]], v = y.items, h = y.cateAxisId, w = v.filter(function(_) {
        return dt(_.type).indexOf("Bar") >= 0;
      });
      if (w && w.length) {
        var b = w[0].type.defaultProps, x = b !== void 0 ? ve(ve({}, b), w[0].props) : w[0].props, O = x.barSize, m = x[h];
        o[m] || (o[m] = []);
        var g = ee(O) ? r : O;
        o[m].push({
          item: w[0],
          stackList: w.slice(1),
          barSize: ee(g) ? void 0 : Vt(g, n, 0)
        });
      }
    }
  return o;
}, QE = function(t) {
  var r = t.barGap, n = t.barCategoryGap, i = t.bandSize, a = t.sizeList, o = a === void 0 ? [] : a, u = t.maxBarSize, s = o.length;
  if (s < 1) return null;
  var c = Vt(r, i, 0, !0), f, l = [];
  if (o[0].barSize === +o[0].barSize) {
    var d = !1, p = i / s, y = o.reduce(function(O, m) {
      return O + m.barSize || 0;
    }, 0);
    y += (s - 1) * c, y >= i && (y -= (s - 1) * c, c = 0), y >= i && p > 0 && (d = !0, p *= 0.9, y = s * p);
    var v = (i - y) / 2 >> 0, h = {
      offset: v - c,
      size: 0
    };
    f = o.reduce(function(O, m) {
      var g = {
        item: m.item,
        position: {
          offset: h.offset + h.size + c,
          // @ts-expect-error the type check above does not check for type number explicitly
          size: d ? p : m.barSize
        }
      }, _ = [].concat(cm(O), [g]);
      return h = _[_.length - 1].position, m.stackList && m.stackList.length && m.stackList.forEach(function(A) {
        _.push({
          item: A,
          position: h
        });
      }), _;
    }, l);
  } else {
    var w = Vt(n, i, 0, !0);
    i - 2 * w - (s - 1) * c <= 0 && (c = 0);
    var b = (i - 2 * w - (s - 1) * c) / s;
    b > 1 && (b >>= 0);
    var x = u === +u ? Math.min(b, u) : b;
    f = o.reduce(function(O, m, g) {
      var _ = [].concat(cm(O), [{
        item: m.item,
        position: {
          offset: w + (b + c) * g + (b - x) / 2,
          size: x
        }
      }]);
      return m.stackList && m.stackList.length && m.stackList.forEach(function(A) {
        _.push({
          item: A,
          position: _[_.length - 1].position
        });
      }), _;
    }, l);
  }
  return f;
}, JE = function(t, r, n, i) {
  var a = n.children, o = n.width, u = n.margin, s = o - (u.left || 0) - (u.right || 0), c = ex({
    children: a,
    legendWidth: s
  });
  if (c) {
    var f = i || {}, l = f.width, d = f.height, p = c.align, y = c.verticalAlign, v = c.layout;
    if ((v === "vertical" || v === "horizontal" && y === "middle") && p !== "center" && q(t[p]))
      return ve(ve({}, t), {}, hr({}, p, t[p] + (l || 0)));
    if ((v === "horizontal" || v === "vertical" && p === "center") && y !== "middle" && q(t[y]))
      return ve(ve({}, t), {}, hr({}, y, t[y] + (d || 0)));
  }
  return t;
}, eM = function(t, r, n) {
  return ee(r) ? !0 : t === "horizontal" ? r === "yAxis" : t === "vertical" || n === "x" ? r === "xAxis" : n === "y" ? r === "yAxis" : !0;
}, tx = function(t, r, n, i, a) {
  var o = r.props.children, u = Je(o, Na).filter(function(c) {
    return eM(i, a, c.props.direction);
  });
  if (u && u.length) {
    var s = u.map(function(c) {
      return c.props.dataKey;
    });
    return t.reduce(function(c, f) {
      var l = Be(f, n);
      if (ee(l)) return c;
      var d = Array.isArray(l) ? [Ca(l), Tt(l)] : [l, l], p = s.reduce(function(y, v) {
        var h = Be(f, v, 0), w = d[0] - Math.abs(Array.isArray(h) ? h[0] : h), b = d[1] + Math.abs(Array.isArray(h) ? h[1] : h);
        return [Math.min(w, y[0]), Math.max(b, y[1])];
      }, [1 / 0, -1 / 0]);
      return [Math.min(p[0], c[0]), Math.max(p[1], c[1])];
    }, [1 / 0, -1 / 0]);
  }
  return null;
}, tM = function(t, r, n, i, a) {
  var o = r.map(function(u) {
    return tx(t, u, n, a, i);
  }).filter(function(u) {
    return !ee(u);
  });
  return o && o.length ? o.reduce(function(u, s) {
    return [Math.min(u[0], s[0]), Math.max(u[1], s[1])];
  }, [1 / 0, -1 / 0]) : null;
}, rx = function(t, r, n, i, a) {
  var o = r.map(function(s) {
    var c = s.props.dataKey;
    return n === "number" && c && tx(t, s, c, i) || fn(t, c, n, a);
  });
  if (n === "number")
    return o.reduce(
      // @ts-expect-error if (type === number) means that the domain is numerical type
      // - but this link is missing in the type definition
      function(s, c) {
        return [Math.min(s[0], c[0]), Math.max(s[1], c[1])];
      },
      [1 / 0, -1 / 0]
    );
  var u = {};
  return o.reduce(function(s, c) {
    for (var f = 0, l = c.length; f < l; f++)
      u[c[f]] || (u[c[f]] = !0, s.push(c[f]));
    return s;
  }, []);
}, nx = function(t, r) {
  return t === "horizontal" && r === "xAxis" || t === "vertical" && r === "yAxis" || t === "centric" && r === "angleAxis" || t === "radial" && r === "radiusAxis";
}, ix = function(t, r, n, i) {
  if (i)
    return t.map(function(s) {
      return s.coordinate;
    });
  var a, o, u = t.map(function(s) {
    return s.coordinate === r && (a = !0), s.coordinate === n && (o = !0), s.coordinate;
  });
  return a || u.push(r), o || u.push(n), u;
}, ft = function(t, r, n) {
  if (!t) return null;
  var i = t.scale, a = t.duplicateDomain, o = t.type, u = t.range, s = t.realScaleType === "scaleBand" ? i.bandwidth() / 2 : 2, c = (r || n) && o === "category" && i.bandwidth ? i.bandwidth() / s : 0;
  if (c = t.axisType === "angleAxis" && (u == null ? void 0 : u.length) >= 2 ? Qe(u[0] - u[1]) * 2 * c : c, r && (t.ticks || t.niceTicks)) {
    var f = (t.ticks || t.niceTicks).map(function(l) {
      var d = a ? a.indexOf(l) : l;
      return {
        // If the scaleContent is not a number, the coordinate will be NaN.
        // That could be the case for example with a PointScale and a string as domain.
        coordinate: i(d) + c,
        value: l,
        offset: c
      };
    });
    return f.filter(function(l) {
      return !zr(l.coordinate);
    });
  }
  return t.isCategorical && t.categoricalDomain ? t.categoricalDomain.map(function(l, d) {
    return {
      coordinate: i(l) + c,
      value: l,
      index: d,
      offset: c
    };
  }) : i.ticks && !n ? i.ticks(t.tickCount).map(function(l) {
    return {
      coordinate: i(l) + c,
      value: l,
      offset: c
    };
  }) : i.domain().map(function(l, d) {
    return {
      coordinate: i(l) + c,
      value: a ? a[l] : l,
      index: d,
      offset: c
    };
  });
}, vc = /* @__PURE__ */ new WeakMap(), li = function(t, r) {
  if (typeof r != "function")
    return t;
  vc.has(t) || vc.set(t, /* @__PURE__ */ new WeakMap());
  var n = vc.get(t);
  if (n.has(r))
    return n.get(r);
  var i = function() {
    t.apply(void 0, arguments), r.apply(void 0, arguments);
  };
  return n.set(r, i), i;
}, rM = function(t, r, n) {
  var i = t.scale, a = t.type, o = t.layout, u = t.axisType;
  if (i === "auto")
    return o === "radial" && u === "radiusAxis" ? {
      scale: Sn(),
      realScaleType: "band"
    } : o === "radial" && u === "angleAxis" ? {
      scale: $i(),
      realScaleType: "linear"
    } : a === "category" && r && (r.indexOf("LineChart") >= 0 || r.indexOf("AreaChart") >= 0 || r.indexOf("ComposedChart") >= 0 && !n) ? {
      scale: ln(),
      realScaleType: "point"
    } : a === "category" ? {
      scale: Sn(),
      realScaleType: "band"
    } : {
      scale: $i(),
      realScaleType: "linear"
    };
  if (Gt(i)) {
    var s = "scale".concat(ga(i));
    return {
      scale: (Xy[s] || ln)(),
      realScaleType: Xy[s] ? s : "point"
    };
  }
  return Z(i) ? {
    scale: i
  } : {
    scale: ln(),
    realScaleType: "point"
  };
}, fm = 1e-4, nM = function(t) {
  var r = t.domain();
  if (!(!r || r.length <= 2)) {
    var n = r.length, i = t.range(), a = Math.min(i[0], i[1]) - fm, o = Math.max(i[0], i[1]) + fm, u = t(r[0]), s = t(r[n - 1]);
    (u < a || u > o || s < a || s > o) && t.domain([r[0], r[n - 1]]);
  }
}, iM = function(t, r) {
  if (!t)
    return null;
  for (var n = 0, i = t.length; n < i; n++)
    if (t[n].item === r)
      return t[n].position;
  return null;
}, aM = function(t, r) {
  if (!r || r.length !== 2 || !q(r[0]) || !q(r[1]))
    return t;
  var n = Math.min(r[0], r[1]), i = Math.max(r[0], r[1]), a = [t[0], t[1]];
  return (!q(t[0]) || t[0] < n) && (a[0] = n), (!q(t[1]) || t[1] > i) && (a[1] = i), a[0] > i && (a[0] = i), a[1] < n && (a[1] = n), a;
}, oM = function(t) {
  var r = t.length;
  if (!(r <= 0))
    for (var n = 0, i = t[0].length; n < i; ++n)
      for (var a = 0, o = 0, u = 0; u < r; ++u) {
        var s = zr(t[u][n][1]) ? t[u][n][0] : t[u][n][1];
        s >= 0 ? (t[u][n][0] = a, t[u][n][1] = a + s, a = t[u][n][1]) : (t[u][n][0] = o, t[u][n][1] = o + s, o = t[u][n][1]);
      }
}, uM = function(t) {
  var r = t.length;
  if (!(r <= 0))
    for (var n = 0, i = t[0].length; n < i; ++n)
      for (var a = 0, o = 0; o < r; ++o) {
        var u = zr(t[o][n][1]) ? t[o][n][0] : t[o][n][1];
        u >= 0 ? (t[o][n][0] = a, t[o][n][1] = a + u, a = t[o][n][1]) : (t[o][n][0] = 0, t[o][n][1] = 0);
      }
}, sM = {
  sign: oM,
  // @ts-expect-error definitelytyped types are incorrect
  expand: p_,
  // @ts-expect-error definitelytyped types are incorrect
  none: mr,
  // @ts-expect-error definitelytyped types are incorrect
  silhouette: v_,
  // @ts-expect-error definitelytyped types are incorrect
  wiggle: y_,
  positive: uM
}, cM = function(t, r, n) {
  var i = r.map(function(u) {
    return u.props.dataKey;
  }), a = sM[n], o = h_().keys(i).value(function(u, s) {
    return +Be(u, s, 0);
  }).order(cl).offset(a);
  return o(t);
}, lM = function(t, r, n, i, a, o) {
  if (!t)
    return null;
  var u = o ? r.reverse() : r, s = {}, c = u.reduce(function(l, d) {
    var p, y = (p = d.type) !== null && p !== void 0 && p.defaultProps ? ve(ve({}, d.type.defaultProps), d.props) : d.props, v = y.stackId, h = y.hide;
    if (h)
      return l;
    var w = y[n], b = l[w] || {
      hasStack: !1,
      stackGroups: {}
    };
    if (_e(v)) {
      var x = b.stackGroups[v] || {
        numericAxisId: n,
        cateAxisId: i,
        items: []
      };
      x.items.push(d), b.hasStack = !0, b.stackGroups[v] = x;
    } else
      b.stackGroups[Zn("_stackId_")] = {
        numericAxisId: n,
        cateAxisId: i,
        items: [d]
      };
    return ve(ve({}, l), {}, hr({}, w, b));
  }, s), f = {};
  return Object.keys(c).reduce(function(l, d) {
    var p = c[d];
    if (p.hasStack) {
      var y = {};
      p.stackGroups = Object.keys(p.stackGroups).reduce(function(v, h) {
        var w = p.stackGroups[h];
        return ve(ve({}, v), {}, hr({}, h, {
          numericAxisId: n,
          cateAxisId: i,
          items: w.items,
          stackedData: cM(t, w.items, a)
        }));
      }, y);
    }
    return ve(ve({}, l), {}, hr({}, d, p));
  }, f);
}, fM = function(t, r) {
  var n = r.realScaleType, i = r.type, a = r.tickCount, o = r.originalDomain, u = r.allowDecimals, s = n || r.scale;
  if (s !== "auto" && s !== "linear")
    return null;
  if (a && i === "number" && o && (o[0] === "auto" || o[1] === "auto")) {
    var c = t.domain();
    if (!c.length)
      return null;
    var f = OE(c, a, u);
    return t.domain([Ca(f), Tt(f)]), {
      niceTicks: f
    };
  }
  if (a && i === "number") {
    var l = t.domain(), d = _E(l, a, u);
    return {
      niceTicks: d
    };
  }
  return null;
};
function dm(e) {
  var t = e.axis, r = e.ticks, n = e.bandSize, i = e.entry, a = e.index, o = e.dataKey;
  if (t.type === "category") {
    if (!t.allowDuplicatedCategory && t.dataKey && !ee(i[t.dataKey])) {
      var u = vi(r, "value", i[t.dataKey]);
      if (u)
        return u.coordinate + n / 2;
    }
    return r[a] ? r[a].coordinate + n / 2 : null;
  }
  var s = Be(i, ee(o) ? t.dataKey : o);
  return ee(s) ? null : t.scale(s);
}
var hm = function(t) {
  var r = t.axis, n = t.ticks, i = t.offset, a = t.bandSize, o = t.entry, u = t.index;
  if (r.type === "category")
    return n[u] ? n[u].coordinate + i : null;
  var s = Be(o, r.dataKey, r.domain[u]);
  return ee(s) ? null : r.scale(s) - a / 2 + i;
}, dM = function(t) {
  var r = t.numericAxis, n = r.scale.domain();
  if (r.type === "number") {
    var i = Math.min(n[0], n[1]), a = Math.max(n[0], n[1]);
    return i <= 0 && a >= 0 ? 0 : a < 0 ? a : i;
  }
  return n[0];
}, hM = function(t, r) {
  var n, i = (n = t.type) !== null && n !== void 0 && n.defaultProps ? ve(ve({}, t.type.defaultProps), t.props) : t.props, a = i.stackId;
  if (_e(a)) {
    var o = r[a];
    if (o) {
      var u = o.items.indexOf(t);
      return u >= 0 ? o.stackedData[u] : null;
    }
  }
  return null;
}, pM = function(t) {
  return t.reduce(function(r, n) {
    return [Ca(n.concat([r[0]]).filter(q)), Tt(n.concat([r[1]]).filter(q))];
  }, [1 / 0, -1 / 0]);
}, ax = function(t, r, n) {
  return Object.keys(t).reduce(function(i, a) {
    var o = t[a], u = o.stackedData, s = u.reduce(function(c, f) {
      var l = pM(f.slice(r, n + 1));
      return [Math.min(c[0], l[0]), Math.max(c[1], l[1])];
    }, [1 / 0, -1 / 0]);
    return [Math.min(s[0], i[0]), Math.max(s[1], i[1])];
  }, [1 / 0, -1 / 0]).map(function(i) {
    return i === 1 / 0 || i === -1 / 0 ? 0 : i;
  });
}, pm = /^dataMin[\s]*-[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/, vm = /^dataMax[\s]*\+[\s]*([0-9]+([.]{1}[0-9]+){0,1})$/, Il = function(t, r, n) {
  if (Z(t))
    return t(r, n);
  if (!Array.isArray(t))
    return r;
  var i = [];
  if (q(t[0]))
    i[0] = n ? t[0] : Math.min(t[0], r[0]);
  else if (pm.test(t[0])) {
    var a = +pm.exec(t[0])[1];
    i[0] = r[0] - a;
  } else Z(t[0]) ? i[0] = t[0](r[0]) : i[0] = r[0];
  if (q(t[1]))
    i[1] = n ? t[1] : Math.max(t[1], r[1]);
  else if (vm.test(t[1])) {
    var o = +vm.exec(t[1])[1];
    i[1] = r[1] + o;
  } else Z(t[1]) ? i[1] = t[1](r[1]) : i[1] = r[1];
  return i;
}, Bi = function(t, r, n) {
  if (t && t.scale && t.scale.bandwidth) {
    var i = t.scale.bandwidth();
    if (!n || i > 0)
      return i;
  }
  if (t && r && r.length >= 2) {
    for (var a = qf(r, function(l) {
      return l.coordinate;
    }), o = 1 / 0, u = 1, s = a.length; u < s; u++) {
      var c = a[u], f = a[u - 1];
      o = Math.min((c.coordinate || 0) - (f.coordinate || 0), o);
    }
    return o === 1 / 0 ? 0 : o;
  }
  return n ? void 0 : 0;
}, ym = function(t, r, n) {
  return !t || !t.length || Pn(t, Ge(n, "type.defaultProps.domain")) ? r : t;
}, ox = function(t, r) {
  var n = t.type.defaultProps ? ve(ve({}, t.type.defaultProps), t.props) : t.props, i = n.dataKey, a = n.name, o = n.unit, u = n.formatter, s = n.tooltipType, c = n.chartType, f = n.hide;
  return ve(ve({}, J(t, !1)), {}, {
    dataKey: i,
    unit: o,
    formatter: u,
    name: a || i,
    color: sd(t),
    value: Be(r, i),
    type: s,
    payload: r,
    chartType: c,
    hide: f
  });
};
function Cn(e) {
  "@babel/helpers - typeof";
  return Cn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Cn(e);
}
function mm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function gm(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? mm(Object(r), !0).forEach(function(n) {
      vM(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : mm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function vM(e, t, r) {
  return t = yM(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function yM(e) {
  var t = mM(e, "string");
  return Cn(t) == "symbol" ? t : t + "";
}
function mM(e, t) {
  if (Cn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Cn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Fi = Math.PI / 180, gM = function(t) {
  return t * 180 / Math.PI;
}, je = function(t, r, n, i) {
  return {
    x: t + Math.cos(-Fi * i) * n,
    y: r + Math.sin(-Fi * i) * n
  };
}, bM = function(t, r) {
  var n = t.x, i = t.y, a = r.x, o = r.y;
  return Math.sqrt(Math.pow(n - a, 2) + Math.pow(i - o, 2));
}, xM = function(t, r) {
  var n = t.x, i = t.y, a = r.cx, o = r.cy, u = bM({
    x: n,
    y: i
  }, {
    x: a,
    y: o
  });
  if (u <= 0)
    return {
      radius: u
    };
  var s = (n - a) / u, c = Math.acos(s);
  return i > o && (c = 2 * Math.PI - c), {
    radius: u,
    angle: gM(c),
    angleInRadian: c
  };
}, wM = function(t) {
  var r = t.startAngle, n = t.endAngle, i = Math.floor(r / 360), a = Math.floor(n / 360), o = Math.min(i, a);
  return {
    startAngle: r - o * 360,
    endAngle: n - o * 360
  };
}, OM = function(t, r) {
  var n = r.startAngle, i = r.endAngle, a = Math.floor(n / 360), o = Math.floor(i / 360), u = Math.min(a, o);
  return t + u * 360;
}, bm = function(t, r) {
  var n = t.x, i = t.y, a = xM({
    x: n,
    y: i
  }, r), o = a.radius, u = a.angle, s = r.innerRadius, c = r.outerRadius;
  if (o < s || o > c)
    return !1;
  if (o === 0)
    return !0;
  var f = wM(r), l = f.startAngle, d = f.endAngle, p = u, y;
  if (l <= d) {
    for (; p > d; )
      p -= 360;
    for (; p < l; )
      p += 360;
    y = p >= l && p <= d;
  } else {
    for (; p > l; )
      p -= 360;
    for (; p < d; )
      p += 360;
    y = p >= d && p <= l;
  }
  return y ? gm(gm({}, r), {}, {
    radius: o,
    angle: OM(p, r)
  }) : null;
};
function In(e) {
  "@babel/helpers - typeof";
  return In = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, In(e);
}
var _M = ["offset"];
function SM(e) {
  return jM(e) || TM(e) || PM(e) || AM();
}
function AM() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function PM(e, t) {
  if (e) {
    if (typeof e == "string") return $l(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return $l(e, t);
  }
}
function TM(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function jM(e) {
  if (Array.isArray(e)) return $l(e);
}
function $l(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function EM(e, t) {
  if (e == null) return {};
  var r = MM(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function MM(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function xm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Oe(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? xm(Object(r), !0).forEach(function(n) {
      CM(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : xm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function CM(e, t, r) {
  return t = IM(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function IM(e) {
  var t = $M(e, "string");
  return In(t) == "symbol" ? t : t + "";
}
function $M(e, t) {
  if (In(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (In(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function $n() {
  return $n = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, $n.apply(this, arguments);
}
var NM = function(t) {
  var r = t.value, n = t.formatter, i = ee(t.children) ? r : t.children;
  return Z(n) ? n(i) : i;
}, kM = function(t, r) {
  var n = Qe(r - t), i = Math.min(Math.abs(r - t), 360);
  return n * i;
}, DM = function(t, r, n) {
  var i = t.position, a = t.viewBox, o = t.offset, u = t.className, s = a, c = s.cx, f = s.cy, l = s.innerRadius, d = s.outerRadius, p = s.startAngle, y = s.endAngle, v = s.clockWise, h = (l + d) / 2, w = kM(p, y), b = w >= 0 ? 1 : -1, x, O;
  i === "insideStart" ? (x = p + b * o, O = v) : i === "insideEnd" ? (x = y - b * o, O = !v) : i === "end" && (x = y + b * o, O = v), O = w <= 0 ? O : !O;
  var m = je(c, f, h, x), g = je(c, f, h, x + (O ? 1 : -1) * 359), _ = "M".concat(m.x, ",").concat(m.y, `
    A`).concat(h, ",").concat(h, ",0,1,").concat(O ? 0 : 1, `,
    `).concat(g.x, ",").concat(g.y), A = ee(t.id) ? Zn("recharts-radial-line-") : t.id;
  return /* @__PURE__ */ T.createElement("text", $n({}, n, {
    dominantBaseline: "central",
    className: re("recharts-radial-bar-label", u)
  }), /* @__PURE__ */ T.createElement("defs", null, /* @__PURE__ */ T.createElement("path", {
    id: A,
    d: _
  })), /* @__PURE__ */ T.createElement("textPath", {
    xlinkHref: "#".concat(A)
  }, r));
}, RM = function(t) {
  var r = t.viewBox, n = t.offset, i = t.position, a = r, o = a.cx, u = a.cy, s = a.innerRadius, c = a.outerRadius, f = a.startAngle, l = a.endAngle, d = (f + l) / 2;
  if (i === "outside") {
    var p = je(o, u, c + n, d), y = p.x, v = p.y;
    return {
      x: y,
      y: v,
      textAnchor: y >= o ? "start" : "end",
      verticalAnchor: "middle"
    };
  }
  if (i === "center")
    return {
      x: o,
      y: u,
      textAnchor: "middle",
      verticalAnchor: "middle"
    };
  if (i === "centerTop")
    return {
      x: o,
      y: u,
      textAnchor: "middle",
      verticalAnchor: "start"
    };
  if (i === "centerBottom")
    return {
      x: o,
      y: u,
      textAnchor: "middle",
      verticalAnchor: "end"
    };
  var h = (s + c) / 2, w = je(o, u, h, d), b = w.x, x = w.y;
  return {
    x: b,
    y: x,
    textAnchor: "middle",
    verticalAnchor: "middle"
  };
}, LM = function(t) {
  var r = t.viewBox, n = t.parentViewBox, i = t.offset, a = t.position, o = r, u = o.x, s = o.y, c = o.width, f = o.height, l = f >= 0 ? 1 : -1, d = l * i, p = l > 0 ? "end" : "start", y = l > 0 ? "start" : "end", v = c >= 0 ? 1 : -1, h = v * i, w = v > 0 ? "end" : "start", b = v > 0 ? "start" : "end";
  if (a === "top") {
    var x = {
      x: u + c / 2,
      y: s - l * i,
      textAnchor: "middle",
      verticalAnchor: p
    };
    return Oe(Oe({}, x), n ? {
      height: Math.max(s - n.y, 0),
      width: c
    } : {});
  }
  if (a === "bottom") {
    var O = {
      x: u + c / 2,
      y: s + f + d,
      textAnchor: "middle",
      verticalAnchor: y
    };
    return Oe(Oe({}, O), n ? {
      height: Math.max(n.y + n.height - (s + f), 0),
      width: c
    } : {});
  }
  if (a === "left") {
    var m = {
      x: u - h,
      y: s + f / 2,
      textAnchor: w,
      verticalAnchor: "middle"
    };
    return Oe(Oe({}, m), n ? {
      width: Math.max(m.x - n.x, 0),
      height: f
    } : {});
  }
  if (a === "right") {
    var g = {
      x: u + c + h,
      y: s + f / 2,
      textAnchor: b,
      verticalAnchor: "middle"
    };
    return Oe(Oe({}, g), n ? {
      width: Math.max(n.x + n.width - g.x, 0),
      height: f
    } : {});
  }
  var _ = n ? {
    width: c,
    height: f
  } : {};
  return a === "insideLeft" ? Oe({
    x: u + h,
    y: s + f / 2,
    textAnchor: b,
    verticalAnchor: "middle"
  }, _) : a === "insideRight" ? Oe({
    x: u + c - h,
    y: s + f / 2,
    textAnchor: w,
    verticalAnchor: "middle"
  }, _) : a === "insideTop" ? Oe({
    x: u + c / 2,
    y: s + d,
    textAnchor: "middle",
    verticalAnchor: y
  }, _) : a === "insideBottom" ? Oe({
    x: u + c / 2,
    y: s + f - d,
    textAnchor: "middle",
    verticalAnchor: p
  }, _) : a === "insideTopLeft" ? Oe({
    x: u + h,
    y: s + d,
    textAnchor: b,
    verticalAnchor: y
  }, _) : a === "insideTopRight" ? Oe({
    x: u + c - h,
    y: s + d,
    textAnchor: w,
    verticalAnchor: y
  }, _) : a === "insideBottomLeft" ? Oe({
    x: u + h,
    y: s + f - d,
    textAnchor: b,
    verticalAnchor: p
  }, _) : a === "insideBottomRight" ? Oe({
    x: u + c - h,
    y: s + f - d,
    textAnchor: w,
    verticalAnchor: p
  }, _) : Fr(a) && (q(a.x) || zt(a.x)) && (q(a.y) || zt(a.y)) ? Oe({
    x: u + Vt(a.x, c),
    y: s + Vt(a.y, f),
    textAnchor: "end",
    verticalAnchor: "end"
  }, _) : Oe({
    x: u + c / 2,
    y: s + f / 2,
    textAnchor: "middle",
    verticalAnchor: "middle"
  }, _);
}, qM = function(t) {
  return "cx" in t && q(t.cx);
};
function Me(e) {
  var t = e.offset, r = t === void 0 ? 5 : t, n = EM(e, _M), i = Oe({
    offset: r
  }, n), a = i.viewBox, o = i.position, u = i.value, s = i.children, c = i.content, f = i.className, l = f === void 0 ? "" : f, d = i.textBreakAll;
  if (!a || ee(u) && ee(s) && !/* @__PURE__ */ D.isValidElement(c) && !Z(c))
    return null;
  if (/* @__PURE__ */ D.isValidElement(c))
    return /* @__PURE__ */ D.cloneElement(c, i);
  var p;
  if (Z(c)) {
    if (p = /* @__PURE__ */ D.createElement(c, i), /* @__PURE__ */ D.isValidElement(p))
      return p;
  } else
    p = NM(i);
  var y = qM(a), v = J(i, !0);
  if (y && (o === "insideStart" || o === "insideEnd" || o === "end"))
    return DM(i, p, v);
  var h = y ? RM(i) : LM(i);
  return /* @__PURE__ */ T.createElement(ji, $n({
    className: re("recharts-label", l)
  }, v, h, {
    breakAll: d
  }), p);
}
Me.displayName = "Label";
var ux = function(t) {
  var r = t.cx, n = t.cy, i = t.angle, a = t.startAngle, o = t.endAngle, u = t.r, s = t.radius, c = t.innerRadius, f = t.outerRadius, l = t.x, d = t.y, p = t.top, y = t.left, v = t.width, h = t.height, w = t.clockWise, b = t.labelViewBox;
  if (b)
    return b;
  if (q(v) && q(h)) {
    if (q(l) && q(d))
      return {
        x: l,
        y: d,
        width: v,
        height: h
      };
    if (q(p) && q(y))
      return {
        x: p,
        y,
        width: v,
        height: h
      };
  }
  return q(l) && q(d) ? {
    x: l,
    y: d,
    width: 0,
    height: 0
  } : q(r) && q(n) ? {
    cx: r,
    cy: n,
    startAngle: a || i || 0,
    endAngle: o || i || 0,
    innerRadius: c || 0,
    outerRadius: f || s || u || 0,
    clockWise: w
  } : t.viewBox ? t.viewBox : {};
}, BM = function(t, r) {
  return t ? t === !0 ? /* @__PURE__ */ T.createElement(Me, {
    key: "label-implicit",
    viewBox: r
  }) : _e(t) ? /* @__PURE__ */ T.createElement(Me, {
    key: "label-implicit",
    viewBox: r,
    value: t
  }) : /* @__PURE__ */ D.isValidElement(t) ? t.type === Me ? /* @__PURE__ */ D.cloneElement(t, {
    key: "label-implicit",
    viewBox: r
  }) : /* @__PURE__ */ T.createElement(Me, {
    key: "label-implicit",
    content: t,
    viewBox: r
  }) : Z(t) ? /* @__PURE__ */ T.createElement(Me, {
    key: "label-implicit",
    content: t,
    viewBox: r
  }) : Fr(t) ? /* @__PURE__ */ T.createElement(Me, $n({
    viewBox: r
  }, t, {
    key: "label-implicit"
  })) : null : null;
}, FM = function(t, r) {
  var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
  if (!t || !t.children && n && !t.label)
    return null;
  var i = t.children, a = ux(t), o = Je(i, Me).map(function(s, c) {
    return /* @__PURE__ */ D.cloneElement(s, {
      viewBox: r || a,
      // eslint-disable-next-line react/no-array-index-key
      key: "label-".concat(c)
    });
  });
  if (!n)
    return o;
  var u = BM(t.label, r || a);
  return [u].concat(SM(o));
};
Me.parseViewBox = ux;
Me.renderCallByParent = FM;
var yc, wm;
function zM() {
  if (wm) return yc;
  wm = 1;
  function e(t) {
    var r = t == null ? 0 : t.length;
    return r ? t[r - 1] : void 0;
  }
  return yc = e, yc;
}
var UM = zM();
const WM = /* @__PURE__ */ ce(UM);
function Nn(e) {
  "@babel/helpers - typeof";
  return Nn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Nn(e);
}
var HM = ["valueAccessor"], KM = ["data", "dataKey", "clockWise", "id", "textBreakAll"];
function GM(e) {
  return ZM(e) || YM(e) || XM(e) || VM();
}
function VM() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function XM(e, t) {
  if (e) {
    if (typeof e == "string") return Nl(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Nl(e, t);
  }
}
function YM(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function ZM(e) {
  if (Array.isArray(e)) return Nl(e);
}
function Nl(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function zi() {
  return zi = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, zi.apply(this, arguments);
}
function Om(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function _m(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Om(Object(r), !0).forEach(function(n) {
      QM(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Om(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function QM(e, t, r) {
  return t = JM(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function JM(e) {
  var t = eC(e, "string");
  return Nn(t) == "symbol" ? t : t + "";
}
function eC(e, t) {
  if (Nn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Nn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Sm(e, t) {
  if (e == null) return {};
  var r = tC(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function tC(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
var rC = function(t) {
  return Array.isArray(t.value) ? WM(t.value) : t.value;
};
function Mt(e) {
  var t = e.valueAccessor, r = t === void 0 ? rC : t, n = Sm(e, HM), i = n.data, a = n.dataKey, o = n.clockWise, u = n.id, s = n.textBreakAll, c = Sm(n, KM);
  return !i || !i.length ? null : /* @__PURE__ */ T.createElement(he, {
    className: "recharts-label-list"
  }, i.map(function(f, l) {
    var d = ee(a) ? r(f, l) : Be(f && f.payload, a), p = ee(u) ? {} : {
      id: "".concat(u, "-").concat(l)
    };
    return /* @__PURE__ */ T.createElement(Me, zi({}, J(f, !0), c, p, {
      parentViewBox: f.parentViewBox,
      value: d,
      textBreakAll: s,
      viewBox: Me.parseViewBox(ee(o) ? f : _m(_m({}, f), {}, {
        clockWise: o
      })),
      key: "label-".concat(l),
      index: l
    }));
  }));
}
Mt.displayName = "LabelList";
function nC(e, t) {
  return e ? e === !0 ? /* @__PURE__ */ T.createElement(Mt, {
    key: "labelList-implicit",
    data: t
  }) : /* @__PURE__ */ T.isValidElement(e) || Z(e) ? /* @__PURE__ */ T.createElement(Mt, {
    key: "labelList-implicit",
    data: t,
    content: e
  }) : Fr(e) ? /* @__PURE__ */ T.createElement(Mt, zi({
    data: t
  }, e, {
    key: "labelList-implicit"
  })) : null : null;
}
function iC(e, t) {
  var r = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : !0;
  if (!e || !e.children && r && !e.label)
    return null;
  var n = e.children, i = Je(n, Mt).map(function(o, u) {
    return /* @__PURE__ */ D.cloneElement(o, {
      data: t,
      // eslint-disable-next-line react/no-array-index-key
      key: "labelList-".concat(u)
    });
  });
  if (!r)
    return i;
  var a = nC(e.label, t);
  return [a].concat(GM(i));
}
Mt.renderCallByParent = iC;
function kn(e) {
  "@babel/helpers - typeof";
  return kn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, kn(e);
}
function kl() {
  return kl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, kl.apply(this, arguments);
}
function Am(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Pm(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Am(Object(r), !0).forEach(function(n) {
      aC(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Am(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function aC(e, t, r) {
  return t = oC(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function oC(e) {
  var t = uC(e, "string");
  return kn(t) == "symbol" ? t : t + "";
}
function uC(e, t) {
  if (kn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (kn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var sC = function(t, r) {
  var n = Qe(r - t), i = Math.min(Math.abs(r - t), 359.999);
  return n * i;
}, fi = function(t) {
  var r = t.cx, n = t.cy, i = t.radius, a = t.angle, o = t.sign, u = t.isExternal, s = t.cornerRadius, c = t.cornerIsExternal, f = s * (u ? 1 : -1) + i, l = Math.asin(s / f) / Fi, d = c ? a : a + o * l, p = je(r, n, f, d), y = je(r, n, i, d), v = c ? a - o * l : a, h = je(r, n, f * Math.cos(l * Fi), v);
  return {
    center: p,
    circleTangency: y,
    lineTangency: h,
    theta: l
  };
}, sx = function(t) {
  var r = t.cx, n = t.cy, i = t.innerRadius, a = t.outerRadius, o = t.startAngle, u = t.endAngle, s = sC(o, u), c = o + s, f = je(r, n, a, o), l = je(r, n, a, c), d = "M ".concat(f.x, ",").concat(f.y, `
    A `).concat(a, ",").concat(a, `,0,
    `).concat(+(Math.abs(s) > 180), ",").concat(+(o > c), `,
    `).concat(l.x, ",").concat(l.y, `
  `);
  if (i > 0) {
    var p = je(r, n, i, o), y = je(r, n, i, c);
    d += "L ".concat(y.x, ",").concat(y.y, `
            A `).concat(i, ",").concat(i, `,0,
            `).concat(+(Math.abs(s) > 180), ",").concat(+(o <= c), `,
            `).concat(p.x, ",").concat(p.y, " Z");
  } else
    d += "L ".concat(r, ",").concat(n, " Z");
  return d;
}, cC = function(t) {
  var r = t.cx, n = t.cy, i = t.innerRadius, a = t.outerRadius, o = t.cornerRadius, u = t.forceCornerRadius, s = t.cornerIsExternal, c = t.startAngle, f = t.endAngle, l = Qe(f - c), d = fi({
    cx: r,
    cy: n,
    radius: a,
    angle: c,
    sign: l,
    cornerRadius: o,
    cornerIsExternal: s
  }), p = d.circleTangency, y = d.lineTangency, v = d.theta, h = fi({
    cx: r,
    cy: n,
    radius: a,
    angle: f,
    sign: -l,
    cornerRadius: o,
    cornerIsExternal: s
  }), w = h.circleTangency, b = h.lineTangency, x = h.theta, O = s ? Math.abs(c - f) : Math.abs(c - f) - v - x;
  if (O < 0)
    return u ? "M ".concat(y.x, ",").concat(y.y, `
        a`).concat(o, ",").concat(o, ",0,0,1,").concat(o * 2, `,0
        a`).concat(o, ",").concat(o, ",0,0,1,").concat(-o * 2, `,0
      `) : sx({
      cx: r,
      cy: n,
      innerRadius: i,
      outerRadius: a,
      startAngle: c,
      endAngle: f
    });
  var m = "M ".concat(y.x, ",").concat(y.y, `
    A`).concat(o, ",").concat(o, ",0,0,").concat(+(l < 0), ",").concat(p.x, ",").concat(p.y, `
    A`).concat(a, ",").concat(a, ",0,").concat(+(O > 180), ",").concat(+(l < 0), ",").concat(w.x, ",").concat(w.y, `
    A`).concat(o, ",").concat(o, ",0,0,").concat(+(l < 0), ",").concat(b.x, ",").concat(b.y, `
  `);
  if (i > 0) {
    var g = fi({
      cx: r,
      cy: n,
      radius: i,
      angle: c,
      sign: l,
      isExternal: !0,
      cornerRadius: o,
      cornerIsExternal: s
    }), _ = g.circleTangency, A = g.lineTangency, P = g.theta, $ = fi({
      cx: r,
      cy: n,
      radius: i,
      angle: f,
      sign: -l,
      isExternal: !0,
      cornerRadius: o,
      cornerIsExternal: s
    }), M = $.circleTangency, j = $.lineTangency, E = $.theta, C = s ? Math.abs(c - f) : Math.abs(c - f) - P - E;
    if (C < 0 && o === 0)
      return "".concat(m, "L").concat(r, ",").concat(n, "Z");
    m += "L".concat(j.x, ",").concat(j.y, `
      A`).concat(o, ",").concat(o, ",0,0,").concat(+(l < 0), ",").concat(M.x, ",").concat(M.y, `
      A`).concat(i, ",").concat(i, ",0,").concat(+(C > 180), ",").concat(+(l > 0), ",").concat(_.x, ",").concat(_.y, `
      A`).concat(o, ",").concat(o, ",0,0,").concat(+(l < 0), ",").concat(A.x, ",").concat(A.y, "Z");
  } else
    m += "L".concat(r, ",").concat(n, "Z");
  return m;
}, lC = {
  cx: 0,
  cy: 0,
  innerRadius: 0,
  outerRadius: 0,
  startAngle: 0,
  endAngle: 0,
  cornerRadius: 0,
  forceCornerRadius: !1,
  cornerIsExternal: !1
}, cx = function(t) {
  var r = Pm(Pm({}, lC), t), n = r.cx, i = r.cy, a = r.innerRadius, o = r.outerRadius, u = r.cornerRadius, s = r.forceCornerRadius, c = r.cornerIsExternal, f = r.startAngle, l = r.endAngle, d = r.className;
  if (o < a || f === l)
    return null;
  var p = re("recharts-sector", d), y = o - a, v = Vt(u, y, 0, !0), h;
  return v > 0 && Math.abs(f - l) < 360 ? h = cC({
    cx: n,
    cy: i,
    innerRadius: a,
    outerRadius: o,
    cornerRadius: Math.min(v, y / 2),
    forceCornerRadius: s,
    cornerIsExternal: c,
    startAngle: f,
    endAngle: l
  }) : h = sx({
    cx: n,
    cy: i,
    innerRadius: a,
    outerRadius: o,
    startAngle: f,
    endAngle: l
  }), /* @__PURE__ */ T.createElement("path", kl({}, J(r, !0), {
    className: p,
    d: h,
    role: "img"
  }));
};
function Dn(e) {
  "@babel/helpers - typeof";
  return Dn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Dn(e);
}
function Dl() {
  return Dl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Dl.apply(this, arguments);
}
function Tm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function jm(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Tm(Object(r), !0).forEach(function(n) {
      fC(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Tm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function fC(e, t, r) {
  return t = dC(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function dC(e) {
  var t = hC(e, "string");
  return Dn(t) == "symbol" ? t : t + "";
}
function hC(e, t) {
  if (Dn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Dn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Em = {
  curveBasisClosed: r_,
  curveBasisOpen: n_,
  curveBasis: t_,
  curveBumpX: F1,
  curveBumpY: z1,
  curveLinearClosed: i_,
  curveLinear: xa,
  curveMonotoneX: a_,
  curveMonotoneY: o_,
  curveNatural: u_,
  curveStep: s_,
  curveStepAfter: l_,
  curveStepBefore: c_
}, di = function(t) {
  return t.x === +t.x && t.y === +t.y;
}, rn = function(t) {
  return t.x;
}, nn = function(t) {
  return t.y;
}, pC = function(t, r) {
  if (Z(t))
    return t;
  var n = "curve".concat(ga(t));
  return (n === "curveMonotone" || n === "curveBump") && r ? Em["".concat(n).concat(r === "vertical" ? "Y" : "X")] : Em[n] || xa;
}, vC = function(t) {
  var r = t.type, n = r === void 0 ? "linear" : r, i = t.points, a = i === void 0 ? [] : i, o = t.baseLine, u = t.layout, s = t.connectNulls, c = s === void 0 ? !1 : s, f = pC(n, u), l = c ? a.filter(function(v) {
    return di(v);
  }) : a, d;
  if (Array.isArray(o)) {
    var p = c ? o.filter(function(v) {
      return di(v);
    }) : o, y = l.map(function(v, h) {
      return jm(jm({}, v), {}, {
        base: p[h]
      });
    });
    return u === "vertical" ? d = ai().y(nn).x1(rn).x0(function(v) {
      return v.base.x;
    }) : d = ai().x(rn).y1(nn).y0(function(v) {
      return v.base.y;
    }), d.defined(di).curve(f), d(y);
  }
  return u === "vertical" && q(o) ? d = ai().y(nn).x1(rn).x0(o) : q(o) ? d = ai().x(rn).y1(nn).y0(o) : d = mb().x(rn).y(nn), d.defined(di).curve(f), d(l);
}, dn = function(t) {
  var r = t.className, n = t.points, i = t.path, a = t.pathRef;
  if ((!n || !n.length) && !i)
    return null;
  var o = n && n.length ? vC(t) : i;
  return /* @__PURE__ */ D.createElement("path", Dl({}, J(t, !1), yi(t), {
    className: re("recharts-curve", r),
    d: o,
    ref: a
  }));
}, mc = { exports: {} }, gc, Mm;
function yC() {
  if (Mm) return gc;
  Mm = 1;
  var e = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
  return gc = e, gc;
}
var bc, Cm;
function mC() {
  if (Cm) return bc;
  Cm = 1;
  var e = /* @__PURE__ */ yC();
  function t() {
  }
  function r() {
  }
  return r.resetWarningCache = t, bc = function() {
    function n(o, u, s, c, f, l) {
      if (l !== e) {
        var d = new Error(
          "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
        );
        throw d.name = "Invariant Violation", d;
      }
    }
    n.isRequired = n;
    function i() {
      return n;
    }
    var a = {
      array: n,
      bigint: n,
      bool: n,
      func: n,
      number: n,
      object: n,
      string: n,
      symbol: n,
      any: n,
      arrayOf: i,
      element: n,
      elementType: n,
      instanceOf: i,
      node: n,
      objectOf: i,
      oneOf: i,
      oneOfType: i,
      shape: i,
      exact: i,
      checkPropTypes: r,
      resetWarningCache: t
    };
    return a.PropTypes = a, a;
  }, bc;
}
var Im;
function gC() {
  return Im || (Im = 1, mc.exports = /* @__PURE__ */ mC()()), mc.exports;
}
var bC = /* @__PURE__ */ gC();
const ae = /* @__PURE__ */ ce(bC);
function xC(e) {
  typeof requestAnimationFrame < "u" && requestAnimationFrame(e);
}
function $m(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, r = -1, n = function i(a) {
    r < 0 && (r = a), a - r > t ? (e(a), r = -1) : xC(i);
  };
  requestAnimationFrame(n);
}
function Rl(e) {
  "@babel/helpers - typeof";
  return Rl = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Rl(e);
}
function wC(e) {
  return AC(e) || SC(e) || _C(e) || OC();
}
function OC() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function _C(e, t) {
  if (e) {
    if (typeof e == "string") return Nm(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Nm(e, t);
  }
}
function Nm(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function SC(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function AC(e) {
  if (Array.isArray(e)) return e;
}
function PC() {
  var e = {}, t = function() {
    return null;
  }, r = !1, n = function i(a) {
    if (!r) {
      if (Array.isArray(a)) {
        if (!a.length)
          return;
        var o = a, u = wC(o), s = u[0], c = u.slice(1);
        if (typeof s == "number") {
          $m(i.bind(null, c), s);
          return;
        }
        i(s), $m(i.bind(null, c));
        return;
      }
      Rl(a) === "object" && (e = a, t(e)), typeof a == "function" && a();
    }
  };
  return {
    stop: function() {
      r = !0;
    },
    start: function(a) {
      r = !1, n(a);
    },
    subscribe: function(a) {
      return t = a, function() {
        t = function() {
          return null;
        };
      };
    }
  };
}
function Rn(e) {
  "@babel/helpers - typeof";
  return Rn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Rn(e);
}
function km(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Dm(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? km(Object(r), !0).forEach(function(n) {
      lx(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : km(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function lx(e, t, r) {
  return t = TC(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function TC(e) {
  var t = jC(e, "string");
  return Rn(t) === "symbol" ? t : String(t);
}
function jC(e, t) {
  if (Rn(e) !== "object" || e === null) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Rn(n) !== "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var EC = function(t, r) {
  return [Object.keys(t), Object.keys(r)].reduce(function(n, i) {
    return n.filter(function(a) {
      return i.includes(a);
    });
  });
}, MC = function(t) {
  return t;
}, CC = function(t) {
  return t.replace(/([A-Z])/g, function(r) {
    return "-".concat(r.toLowerCase());
  });
}, hn = function(t, r) {
  return Object.keys(r).reduce(function(n, i) {
    return Dm(Dm({}, n), {}, lx({}, i, t(i, r[i])));
  }, {});
}, Rm = function(t, r, n) {
  return t.map(function(i) {
    return "".concat(CC(i), " ").concat(r, "ms ").concat(n);
  }).join(",");
};
function IC(e, t) {
  return kC(e) || NC(e, t) || fx(e, t) || $C();
}
function $C() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function NC(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function kC(e) {
  if (Array.isArray(e)) return e;
}
function DC(e) {
  return qC(e) || LC(e) || fx(e) || RC();
}
function RC() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function fx(e, t) {
  if (e) {
    if (typeof e == "string") return Ll(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ll(e, t);
  }
}
function LC(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function qC(e) {
  if (Array.isArray(e)) return Ll(e);
}
function Ll(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
var Ui = 1e-4, dx = function(t, r) {
  return [0, 3 * t, 3 * r - 6 * t, 3 * t - 3 * r + 1];
}, hx = function(t, r) {
  return t.map(function(n, i) {
    return n * Math.pow(r, i);
  }).reduce(function(n, i) {
    return n + i;
  });
}, Lm = function(t, r) {
  return function(n) {
    var i = dx(t, r);
    return hx(i, n);
  };
}, BC = function(t, r) {
  return function(n) {
    var i = dx(t, r), a = [].concat(DC(i.map(function(o, u) {
      return o * u;
    }).slice(1)), [0]);
    return hx(a, n);
  };
}, qm = function() {
  for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
    r[n] = arguments[n];
  var i = r[0], a = r[1], o = r[2], u = r[3];
  if (r.length === 1)
    switch (r[0]) {
      case "linear":
        i = 0, a = 0, o = 1, u = 1;
        break;
      case "ease":
        i = 0.25, a = 0.1, o = 0.25, u = 1;
        break;
      case "ease-in":
        i = 0.42, a = 0, o = 1, u = 1;
        break;
      case "ease-out":
        i = 0.42, a = 0, o = 0.58, u = 1;
        break;
      case "ease-in-out":
        i = 0, a = 0, o = 0.58, u = 1;
        break;
      default: {
        var s = r[0].split("(");
        if (s[0] === "cubic-bezier" && s[1].split(")")[0].split(",").length === 4) {
          var c = s[1].split(")")[0].split(",").map(function(h) {
            return parseFloat(h);
          }), f = IC(c, 4);
          i = f[0], a = f[1], o = f[2], u = f[3];
        }
      }
    }
  var l = Lm(i, o), d = Lm(a, u), p = BC(i, o), y = function(w) {
    return w > 1 ? 1 : w < 0 ? 0 : w;
  }, v = function(w) {
    for (var b = w > 1 ? 1 : w, x = b, O = 0; O < 8; ++O) {
      var m = l(x) - b, g = p(x);
      if (Math.abs(m - b) < Ui || g < Ui)
        return d(x);
      x = y(x - m / g);
    }
    return d(x);
  };
  return v.isStepper = !1, v;
}, FC = function() {
  var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, r = t.stiff, n = r === void 0 ? 100 : r, i = t.damping, a = i === void 0 ? 8 : i, o = t.dt, u = o === void 0 ? 17 : o, s = function(f, l, d) {
    var p = -(f - l) * n, y = d * a, v = d + (p - y) * u / 1e3, h = d * u / 1e3 + f;
    return Math.abs(h - l) < Ui && Math.abs(v) < Ui ? [l, 0] : [h, v];
  };
  return s.isStepper = !0, s.dt = u, s;
}, zC = function() {
  for (var t = arguments.length, r = new Array(t), n = 0; n < t; n++)
    r[n] = arguments[n];
  var i = r[0];
  if (typeof i == "string")
    switch (i) {
      case "ease":
      case "ease-in-out":
      case "ease-out":
      case "ease-in":
      case "linear":
        return qm(i);
      case "spring":
        return FC();
      default:
        if (i.split("(")[0] === "cubic-bezier")
          return qm(i);
    }
  return typeof i == "function" ? i : null;
};
function Ln(e) {
  "@babel/helpers - typeof";
  return Ln = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Ln(e);
}
function Bm(e) {
  return HC(e) || WC(e) || px(e) || UC();
}
function UC() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function WC(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function HC(e) {
  if (Array.isArray(e)) return Bl(e);
}
function Fm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Te(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Fm(Object(r), !0).forEach(function(n) {
      ql(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Fm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function ql(e, t, r) {
  return t = KC(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function KC(e) {
  var t = GC(e, "string");
  return Ln(t) === "symbol" ? t : String(t);
}
function GC(e, t) {
  if (Ln(e) !== "object" || e === null) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Ln(n) !== "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function VC(e, t) {
  return ZC(e) || YC(e, t) || px(e, t) || XC();
}
function XC() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function px(e, t) {
  if (e) {
    if (typeof e == "string") return Bl(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Bl(e, t);
  }
}
function Bl(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function YC(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function ZC(e) {
  if (Array.isArray(e)) return e;
}
var Wi = function(t, r, n) {
  return t + (r - t) * n;
}, Fl = function(t) {
  var r = t.from, n = t.to;
  return r !== n;
}, QC = function e(t, r, n) {
  var i = hn(function(a, o) {
    if (Fl(o)) {
      var u = t(o.from, o.to, o.velocity), s = VC(u, 2), c = s[0], f = s[1];
      return Te(Te({}, o), {}, {
        from: c,
        velocity: f
      });
    }
    return o;
  }, r);
  return n < 1 ? hn(function(a, o) {
    return Fl(o) ? Te(Te({}, o), {}, {
      velocity: Wi(o.velocity, i[a].velocity, n),
      from: Wi(o.from, i[a].from, n)
    }) : o;
  }, r) : e(t, i, n - 1);
};
const JC = function(e, t, r, n, i) {
  var a = EC(e, t), o = a.reduce(function(h, w) {
    return Te(Te({}, h), {}, ql({}, w, [e[w], t[w]]));
  }, {}), u = a.reduce(function(h, w) {
    return Te(Te({}, h), {}, ql({}, w, {
      from: e[w],
      velocity: 0,
      to: t[w]
    }));
  }, {}), s = -1, c, f, l = function() {
    return null;
  }, d = function() {
    return hn(function(w, b) {
      return b.from;
    }, u);
  }, p = function() {
    return !Object.values(u).filter(Fl).length;
  }, y = function(w) {
    c || (c = w);
    var b = w - c, x = b / r.dt;
    u = QC(r, u, x), i(Te(Te(Te({}, e), t), d())), c = w, p() || (s = requestAnimationFrame(l));
  }, v = function(w) {
    f || (f = w);
    var b = (w - f) / n, x = hn(function(m, g) {
      return Wi.apply(void 0, Bm(g).concat([r(b)]));
    }, o);
    if (i(Te(Te(Te({}, e), t), x)), b < 1)
      s = requestAnimationFrame(l);
    else {
      var O = hn(function(m, g) {
        return Wi.apply(void 0, Bm(g).concat([r(1)]));
      }, o);
      i(Te(Te(Te({}, e), t), O));
    }
  };
  return l = r.isStepper ? y : v, function() {
    return requestAnimationFrame(l), function() {
      cancelAnimationFrame(s);
    };
  };
};
function Pr(e) {
  "@babel/helpers - typeof";
  return Pr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Pr(e);
}
var eI = ["children", "begin", "duration", "attributeName", "easing", "isActive", "steps", "from", "to", "canBegin", "onAnimationEnd", "shouldReAnimate", "onAnimationReStart"];
function tI(e, t) {
  if (e == null) return {};
  var r = rI(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function rI(e, t) {
  if (e == null) return {};
  var r = {}, n = Object.keys(e), i, a;
  for (a = 0; a < n.length; a++)
    i = n[a], !(t.indexOf(i) >= 0) && (r[i] = e[i]);
  return r;
}
function xc(e) {
  return oI(e) || aI(e) || iI(e) || nI();
}
function nI() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function iI(e, t) {
  if (e) {
    if (typeof e == "string") return zl(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return zl(e, t);
  }
}
function aI(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function oI(e) {
  if (Array.isArray(e)) return zl(e);
}
function zl(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function zm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ye(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? zm(Object(r), !0).forEach(function(n) {
      sn(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : zm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function sn(e, t, r) {
  return t = vx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function uI(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function sI(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, vx(n.key), n);
  }
}
function cI(e, t, r) {
  return t && sI(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function vx(e) {
  var t = lI(e, "string");
  return Pr(t) === "symbol" ? t : String(t);
}
function lI(e, t) {
  if (Pr(e) !== "object" || e === null) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Pr(n) !== "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function fI(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && Ul(e, t);
}
function Ul(e, t) {
  return Ul = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, Ul(e, t);
}
function dI(e) {
  var t = hI();
  return function() {
    var n = Hi(e), i;
    if (t) {
      var a = Hi(this).constructor;
      i = Reflect.construct(n, arguments, a);
    } else
      i = n.apply(this, arguments);
    return Wl(this, i);
  };
}
function Wl(e, t) {
  if (t && (Pr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return Hl(e);
}
function Hl(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function hI() {
  if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham) return !1;
  if (typeof Proxy == "function") return !0;
  try {
    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    })), !0;
  } catch {
    return !1;
  }
}
function Hi(e) {
  return Hi = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, Hi(e);
}
var bt = /* @__PURE__ */ function(e) {
  fI(r, e);
  var t = dI(r);
  function r(n, i) {
    var a;
    uI(this, r), a = t.call(this, n, i);
    var o = a.props, u = o.isActive, s = o.attributeName, c = o.from, f = o.to, l = o.steps, d = o.children, p = o.duration;
    if (a.handleStyleChange = a.handleStyleChange.bind(Hl(a)), a.changeStyle = a.changeStyle.bind(Hl(a)), !u || p <= 0)
      return a.state = {
        style: {}
      }, typeof d == "function" && (a.state = {
        style: f
      }), Wl(a);
    if (l && l.length)
      a.state = {
        style: l[0].style
      };
    else if (c) {
      if (typeof d == "function")
        return a.state = {
          style: c
        }, Wl(a);
      a.state = {
        style: s ? sn({}, s, c) : c
      };
    } else
      a.state = {
        style: {}
      };
    return a;
  }
  return cI(r, [{
    key: "componentDidMount",
    value: function() {
      var i = this.props, a = i.isActive, o = i.canBegin;
      this.mounted = !0, !(!a || !o) && this.runAnimation(this.props);
    }
  }, {
    key: "componentDidUpdate",
    value: function(i) {
      var a = this.props, o = a.isActive, u = a.canBegin, s = a.attributeName, c = a.shouldReAnimate, f = a.to, l = a.from, d = this.state.style;
      if (u) {
        if (!o) {
          var p = {
            style: s ? sn({}, s, f) : f
          };
          this.state && d && (s && d[s] !== f || !s && d !== f) && this.setState(p);
          return;
        }
        if (!(Mw(i.to, f) && i.canBegin && i.isActive)) {
          var y = !i.canBegin || !i.isActive;
          this.manager && this.manager.stop(), this.stopJSAnimation && this.stopJSAnimation();
          var v = y || c ? l : i.to;
          if (this.state && d) {
            var h = {
              style: s ? sn({}, s, v) : v
            };
            (s && d[s] !== v || !s && d !== v) && this.setState(h);
          }
          this.runAnimation(Ye(Ye({}, this.props), {}, {
            from: v,
            begin: 0
          }));
        }
      }
    }
  }, {
    key: "componentWillUnmount",
    value: function() {
      this.mounted = !1;
      var i = this.props.onAnimationEnd;
      this.unSubscribe && this.unSubscribe(), this.manager && (this.manager.stop(), this.manager = null), this.stopJSAnimation && this.stopJSAnimation(), i && i();
    }
  }, {
    key: "handleStyleChange",
    value: function(i) {
      this.changeStyle(i);
    }
  }, {
    key: "changeStyle",
    value: function(i) {
      this.mounted && this.setState({
        style: i
      });
    }
  }, {
    key: "runJSAnimation",
    value: function(i) {
      var a = this, o = i.from, u = i.to, s = i.duration, c = i.easing, f = i.begin, l = i.onAnimationEnd, d = i.onAnimationStart, p = JC(o, u, zC(c), s, this.changeStyle), y = function() {
        a.stopJSAnimation = p();
      };
      this.manager.start([d, f, y, s, l]);
    }
  }, {
    key: "runStepAnimation",
    value: function(i) {
      var a = this, o = i.steps, u = i.begin, s = i.onAnimationStart, c = o[0], f = c.style, l = c.duration, d = l === void 0 ? 0 : l, p = function(v, h, w) {
        if (w === 0)
          return v;
        var b = h.duration, x = h.easing, O = x === void 0 ? "ease" : x, m = h.style, g = h.properties, _ = h.onAnimationEnd, A = w > 0 ? o[w - 1] : h, P = g || Object.keys(m);
        if (typeof O == "function" || O === "spring")
          return [].concat(xc(v), [a.runJSAnimation.bind(a, {
            from: A.style,
            to: m,
            duration: b,
            easing: O
          }), b]);
        var $ = Rm(P, b, O), M = Ye(Ye(Ye({}, A.style), m), {}, {
          transition: $
        });
        return [].concat(xc(v), [M, b, _]).filter(MC);
      };
      return this.manager.start([s].concat(xc(o.reduce(p, [f, Math.max(d, u)])), [i.onAnimationEnd]));
    }
  }, {
    key: "runAnimation",
    value: function(i) {
      this.manager || (this.manager = PC());
      var a = i.begin, o = i.duration, u = i.attributeName, s = i.to, c = i.easing, f = i.onAnimationStart, l = i.onAnimationEnd, d = i.steps, p = i.children, y = this.manager;
      if (this.unSubscribe = y.subscribe(this.handleStyleChange), typeof c == "function" || typeof p == "function" || c === "spring") {
        this.runJSAnimation(i);
        return;
      }
      if (d.length > 1) {
        this.runStepAnimation(i);
        return;
      }
      var v = u ? sn({}, u, s) : s, h = Rm(Object.keys(v), o, c);
      y.start([f, a, Ye(Ye({}, v), {}, {
        transition: h
      }), o, l]);
    }
  }, {
    key: "render",
    value: function() {
      var i = this.props, a = i.children;
      i.begin;
      var o = i.duration;
      i.attributeName, i.easing;
      var u = i.isActive;
      i.steps, i.from, i.to, i.canBegin, i.onAnimationEnd, i.shouldReAnimate, i.onAnimationReStart;
      var s = tI(i, eI), c = D.Children.count(a), f = this.state.style;
      if (typeof a == "function")
        return a(f);
      if (!u || c === 0 || o <= 0)
        return a;
      var l = function(p) {
        var y = p.props, v = y.style, h = v === void 0 ? {} : v, w = y.className, b = /* @__PURE__ */ D.cloneElement(p, Ye(Ye({}, s), {}, {
          style: Ye(Ye({}, h), f),
          className: w
        }));
        return b;
      };
      return c === 1 ? l(D.Children.only(a)) : /* @__PURE__ */ T.createElement("div", null, D.Children.map(a, function(d) {
        return l(d);
      }));
    }
  }]), r;
}(D.PureComponent);
bt.displayName = "Animate";
bt.defaultProps = {
  begin: 0,
  duration: 1e3,
  from: "",
  to: "",
  attributeName: "",
  easing: "ease",
  isActive: !0,
  canBegin: !0,
  steps: [],
  onAnimationEnd: function() {
  },
  onAnimationStart: function() {
  }
};
bt.propTypes = {
  from: ae.oneOfType([ae.object, ae.string]),
  to: ae.oneOfType([ae.object, ae.string]),
  attributeName: ae.string,
  // animation duration
  duration: ae.number,
  begin: ae.number,
  easing: ae.oneOfType([ae.string, ae.func]),
  steps: ae.arrayOf(ae.shape({
    duration: ae.number.isRequired,
    style: ae.object.isRequired,
    easing: ae.oneOfType([ae.oneOf(["ease", "ease-in", "ease-out", "ease-in-out", "linear"]), ae.func]),
    // transition css properties(dash case), optional
    properties: ae.arrayOf("string"),
    onAnimationEnd: ae.func
  })),
  children: ae.oneOfType([ae.node, ae.func]),
  isActive: ae.bool,
  canBegin: ae.bool,
  onAnimationEnd: ae.func,
  // decide if it should reanimate with initial from style when props change
  shouldReAnimate: ae.bool,
  onAnimationStart: ae.func,
  onAnimationReStart: ae.func
};
function qn(e) {
  "@babel/helpers - typeof";
  return qn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, qn(e);
}
function Ki() {
  return Ki = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Ki.apply(this, arguments);
}
function pI(e, t) {
  return gI(e) || mI(e, t) || yI(e, t) || vI();
}
function vI() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function yI(e, t) {
  if (e) {
    if (typeof e == "string") return Um(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Um(e, t);
  }
}
function Um(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function mI(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function gI(e) {
  if (Array.isArray(e)) return e;
}
function Wm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Hm(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Wm(Object(r), !0).forEach(function(n) {
      bI(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Wm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function bI(e, t, r) {
  return t = xI(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function xI(e) {
  var t = wI(e, "string");
  return qn(t) == "symbol" ? t : t + "";
}
function wI(e, t) {
  if (qn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (qn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Km = function(t, r, n, i, a) {
  var o = Math.min(Math.abs(n) / 2, Math.abs(i) / 2), u = i >= 0 ? 1 : -1, s = n >= 0 ? 1 : -1, c = i >= 0 && n >= 0 || i < 0 && n < 0 ? 1 : 0, f;
  if (o > 0 && a instanceof Array) {
    for (var l = [0, 0, 0, 0], d = 0, p = 4; d < p; d++)
      l[d] = a[d] > o ? o : a[d];
    f = "M".concat(t, ",").concat(r + u * l[0]), l[0] > 0 && (f += "A ".concat(l[0], ",").concat(l[0], ",0,0,").concat(c, ",").concat(t + s * l[0], ",").concat(r)), f += "L ".concat(t + n - s * l[1], ",").concat(r), l[1] > 0 && (f += "A ".concat(l[1], ",").concat(l[1], ",0,0,").concat(c, `,
        `).concat(t + n, ",").concat(r + u * l[1])), f += "L ".concat(t + n, ",").concat(r + i - u * l[2]), l[2] > 0 && (f += "A ".concat(l[2], ",").concat(l[2], ",0,0,").concat(c, `,
        `).concat(t + n - s * l[2], ",").concat(r + i)), f += "L ".concat(t + s * l[3], ",").concat(r + i), l[3] > 0 && (f += "A ".concat(l[3], ",").concat(l[3], ",0,0,").concat(c, `,
        `).concat(t, ",").concat(r + i - u * l[3])), f += "Z";
  } else if (o > 0 && a === +a && a > 0) {
    var y = Math.min(o, a);
    f = "M ".concat(t, ",").concat(r + u * y, `
            A `).concat(y, ",").concat(y, ",0,0,").concat(c, ",").concat(t + s * y, ",").concat(r, `
            L `).concat(t + n - s * y, ",").concat(r, `
            A `).concat(y, ",").concat(y, ",0,0,").concat(c, ",").concat(t + n, ",").concat(r + u * y, `
            L `).concat(t + n, ",").concat(r + i - u * y, `
            A `).concat(y, ",").concat(y, ",0,0,").concat(c, ",").concat(t + n - s * y, ",").concat(r + i, `
            L `).concat(t + s * y, ",").concat(r + i, `
            A `).concat(y, ",").concat(y, ",0,0,").concat(c, ",").concat(t, ",").concat(r + i - u * y, " Z");
  } else
    f = "M ".concat(t, ",").concat(r, " h ").concat(n, " v ").concat(i, " h ").concat(-n, " Z");
  return f;
}, OI = function(t, r) {
  if (!t || !r)
    return !1;
  var n = t.x, i = t.y, a = r.x, o = r.y, u = r.width, s = r.height;
  if (Math.abs(u) > 0 && Math.abs(s) > 0) {
    var c = Math.min(a, a + u), f = Math.max(a, a + u), l = Math.min(o, o + s), d = Math.max(o, o + s);
    return n >= c && n <= f && i >= l && i <= d;
  }
  return !1;
}, _I = {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  // The radius of border
  // The radius of four corners when radius is a number
  // The radius of left-top, right-top, right-bottom, left-bottom when radius is an array
  radius: 0,
  isAnimationActive: !1,
  isUpdateAnimationActive: !1,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease"
}, cd = function(t) {
  var r = Hm(Hm({}, _I), t), n = D.useRef(), i = D.useState(-1), a = pI(i, 2), o = a[0], u = a[1];
  D.useEffect(function() {
    if (n.current && n.current.getTotalLength)
      try {
        var O = n.current.getTotalLength();
        O && u(O);
      } catch {
      }
  }, []);
  var s = r.x, c = r.y, f = r.width, l = r.height, d = r.radius, p = r.className, y = r.animationEasing, v = r.animationDuration, h = r.animationBegin, w = r.isAnimationActive, b = r.isUpdateAnimationActive;
  if (s !== +s || c !== +c || f !== +f || l !== +l || f === 0 || l === 0)
    return null;
  var x = re("recharts-rectangle", p);
  return b ? /* @__PURE__ */ T.createElement(bt, {
    canBegin: o > 0,
    from: {
      width: f,
      height: l,
      x: s,
      y: c
    },
    to: {
      width: f,
      height: l,
      x: s,
      y: c
    },
    duration: v,
    animationEasing: y,
    isActive: b
  }, function(O) {
    var m = O.width, g = O.height, _ = O.x, A = O.y;
    return /* @__PURE__ */ T.createElement(bt, {
      canBegin: o > 0,
      from: "0px ".concat(o === -1 ? 1 : o, "px"),
      to: "".concat(o, "px 0px"),
      attributeName: "strokeDasharray",
      begin: h,
      duration: v,
      isActive: w,
      easing: y
    }, /* @__PURE__ */ T.createElement("path", Ki({}, J(r, !0), {
      className: x,
      d: Km(_, A, m, g, d),
      ref: n
    })));
  }) : /* @__PURE__ */ T.createElement("path", Ki({}, J(r, !0), {
    className: x,
    d: Km(s, c, f, l, d)
  }));
};
function Kl() {
  return Kl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Kl.apply(this, arguments);
}
var ld = function(t) {
  var r = t.cx, n = t.cy, i = t.r, a = t.className, o = re("recharts-dot", a);
  return r === +r && n === +n && i === +i ? /* @__PURE__ */ D.createElement("circle", Kl({}, J(t, !1), yi(t), {
    className: o,
    cx: r,
    cy: n,
    r: i
  })) : null;
};
function Bn(e) {
  "@babel/helpers - typeof";
  return Bn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Bn(e);
}
var SI = ["x", "y", "top", "left", "width", "height", "className"];
function Gl() {
  return Gl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Gl.apply(this, arguments);
}
function Gm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function AI(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Gm(Object(r), !0).forEach(function(n) {
      PI(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Gm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function PI(e, t, r) {
  return t = TI(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function TI(e) {
  var t = jI(e, "string");
  return Bn(t) == "symbol" ? t : t + "";
}
function jI(e, t) {
  if (Bn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Bn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function EI(e, t) {
  if (e == null) return {};
  var r = MI(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function MI(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
var CI = function(t, r, n, i, a, o) {
  return "M".concat(t, ",").concat(a, "v").concat(i, "M").concat(o, ",").concat(r, "h").concat(n);
}, II = function(t) {
  var r = t.x, n = r === void 0 ? 0 : r, i = t.y, a = i === void 0 ? 0 : i, o = t.top, u = o === void 0 ? 0 : o, s = t.left, c = s === void 0 ? 0 : s, f = t.width, l = f === void 0 ? 0 : f, d = t.height, p = d === void 0 ? 0 : d, y = t.className, v = EI(t, SI), h = AI({
    x: n,
    y: a,
    top: u,
    left: c,
    width: l,
    height: p
  }, v);
  return !q(n) || !q(a) || !q(l) || !q(p) || !q(u) || !q(c) ? null : /* @__PURE__ */ T.createElement("path", Gl({}, J(h, !0), {
    className: re("recharts-cross", y),
    d: CI(n, a, l, p, u, c)
  }));
}, wc, Vm;
function $I() {
  if (Vm) return wc;
  Vm = 1;
  var e = Bb(), t = e(Object.getPrototypeOf, Object);
  return wc = t, wc;
}
var Oc, Xm;
function NI() {
  if (Xm) return Oc;
  Xm = 1;
  var e = xt(), t = $I(), r = wt(), n = "[object Object]", i = Function.prototype, a = Object.prototype, o = i.toString, u = a.hasOwnProperty, s = o.call(Object);
  function c(f) {
    if (!r(f) || e(f) != n)
      return !1;
    var l = t(f);
    if (l === null)
      return !0;
    var d = u.call(l, "constructor") && l.constructor;
    return typeof d == "function" && d instanceof d && o.call(d) == s;
  }
  return Oc = c, Oc;
}
var kI = NI();
const DI = /* @__PURE__ */ ce(kI);
var _c, Ym;
function RI() {
  if (Ym) return _c;
  Ym = 1;
  var e = xt(), t = wt(), r = "[object Boolean]";
  function n(i) {
    return i === !0 || i === !1 || t(i) && e(i) == r;
  }
  return _c = n, _c;
}
var LI = RI();
const qI = /* @__PURE__ */ ce(LI);
function Fn(e) {
  "@babel/helpers - typeof";
  return Fn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Fn(e);
}
function Gi() {
  return Gi = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Gi.apply(this, arguments);
}
function BI(e, t) {
  return WI(e) || UI(e, t) || zI(e, t) || FI();
}
function FI() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function zI(e, t) {
  if (e) {
    if (typeof e == "string") return Zm(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Zm(e, t);
  }
}
function Zm(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function UI(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function WI(e) {
  if (Array.isArray(e)) return e;
}
function Qm(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Jm(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Qm(Object(r), !0).forEach(function(n) {
      HI(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Qm(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function HI(e, t, r) {
  return t = KI(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function KI(e) {
  var t = GI(e, "string");
  return Fn(t) == "symbol" ? t : t + "";
}
function GI(e, t) {
  if (Fn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Fn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var eg = function(t, r, n, i, a) {
  var o = n - i, u;
  return u = "M ".concat(t, ",").concat(r), u += "L ".concat(t + n, ",").concat(r), u += "L ".concat(t + n - o / 2, ",").concat(r + a), u += "L ".concat(t + n - o / 2 - i, ",").concat(r + a), u += "L ".concat(t, ",").concat(r, " Z"), u;
}, VI = {
  x: 0,
  y: 0,
  upperWidth: 0,
  lowerWidth: 0,
  height: 0,
  isUpdateAnimationActive: !1,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease"
}, XI = function(t) {
  var r = Jm(Jm({}, VI), t), n = D.useRef(), i = D.useState(-1), a = BI(i, 2), o = a[0], u = a[1];
  D.useEffect(function() {
    if (n.current && n.current.getTotalLength)
      try {
        var x = n.current.getTotalLength();
        x && u(x);
      } catch {
      }
  }, []);
  var s = r.x, c = r.y, f = r.upperWidth, l = r.lowerWidth, d = r.height, p = r.className, y = r.animationEasing, v = r.animationDuration, h = r.animationBegin, w = r.isUpdateAnimationActive;
  if (s !== +s || c !== +c || f !== +f || l !== +l || d !== +d || f === 0 && l === 0 || d === 0)
    return null;
  var b = re("recharts-trapezoid", p);
  return w ? /* @__PURE__ */ T.createElement(bt, {
    canBegin: o > 0,
    from: {
      upperWidth: 0,
      lowerWidth: 0,
      height: d,
      x: s,
      y: c
    },
    to: {
      upperWidth: f,
      lowerWidth: l,
      height: d,
      x: s,
      y: c
    },
    duration: v,
    animationEasing: y,
    isActive: w
  }, function(x) {
    var O = x.upperWidth, m = x.lowerWidth, g = x.height, _ = x.x, A = x.y;
    return /* @__PURE__ */ T.createElement(bt, {
      canBegin: o > 0,
      from: "0px ".concat(o === -1 ? 1 : o, "px"),
      to: "".concat(o, "px 0px"),
      attributeName: "strokeDasharray",
      begin: h,
      duration: v,
      easing: y
    }, /* @__PURE__ */ T.createElement("path", Gi({}, J(r, !0), {
      className: b,
      d: eg(_, A, O, m, g),
      ref: n
    })));
  }) : /* @__PURE__ */ T.createElement("g", null, /* @__PURE__ */ T.createElement("path", Gi({}, J(r, !0), {
    className: b,
    d: eg(s, c, f, l, d)
  })));
}, YI = ["option", "shapeType", "propTransformer", "activeClassName", "isActive"];
function zn(e) {
  "@babel/helpers - typeof";
  return zn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, zn(e);
}
function ZI(e, t) {
  if (e == null) return {};
  var r = QI(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function QI(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function tg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Vi(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? tg(Object(r), !0).forEach(function(n) {
      JI(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : tg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function JI(e, t, r) {
  return t = e$(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function e$(e) {
  var t = t$(e, "string");
  return zn(t) == "symbol" ? t : t + "";
}
function t$(e, t) {
  if (zn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (zn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function r$(e, t) {
  return Vi(Vi({}, t), e);
}
function n$(e, t) {
  return e === "symbols";
}
function rg(e) {
  var t = e.shapeType, r = e.elementProps;
  switch (t) {
    case "rectangle":
      return /* @__PURE__ */ T.createElement(cd, r);
    case "trapezoid":
      return /* @__PURE__ */ T.createElement(XI, r);
    case "sector":
      return /* @__PURE__ */ T.createElement(cx, r);
    case "symbols":
      if (n$(t))
        return /* @__PURE__ */ T.createElement(Cf, r);
      break;
    default:
      return null;
  }
}
function i$(e) {
  return /* @__PURE__ */ D.isValidElement(e) ? e.props : e;
}
function a$(e) {
  var t = e.option, r = e.shapeType, n = e.propTransformer, i = n === void 0 ? r$ : n, a = e.activeClassName, o = a === void 0 ? "recharts-active-shape" : a, u = e.isActive, s = ZI(e, YI), c;
  if (/* @__PURE__ */ D.isValidElement(t))
    c = /* @__PURE__ */ D.cloneElement(t, Vi(Vi({}, s), i$(t)));
  else if (Z(t))
    c = t(s);
  else if (DI(t) && !qI(t)) {
    var f = i(t, s);
    c = /* @__PURE__ */ T.createElement(rg, {
      shapeType: r,
      elementProps: f
    });
  } else {
    var l = s;
    c = /* @__PURE__ */ T.createElement(rg, {
      shapeType: r,
      elementProps: l
    });
  }
  return u ? /* @__PURE__ */ T.createElement(he, {
    className: o
  }, c) : c;
}
function ka(e, t) {
  return t != null && "trapezoids" in e.props;
}
function Da(e, t) {
  return t != null && "sectors" in e.props;
}
function Un(e, t) {
  return t != null && "points" in e.props;
}
function o$(e, t) {
  var r, n, i = e.x === (t == null || (r = t.labelViewBox) === null || r === void 0 ? void 0 : r.x) || e.x === t.x, a = e.y === (t == null || (n = t.labelViewBox) === null || n === void 0 ? void 0 : n.y) || e.y === t.y;
  return i && a;
}
function u$(e, t) {
  var r = e.endAngle === t.endAngle, n = e.startAngle === t.startAngle;
  return r && n;
}
function s$(e, t) {
  var r = e.x === t.x, n = e.y === t.y, i = e.z === t.z;
  return r && n && i;
}
function c$(e, t) {
  var r;
  return ka(e, t) ? r = o$ : Da(e, t) ? r = u$ : Un(e, t) && (r = s$), r;
}
function l$(e, t) {
  var r;
  return ka(e, t) ? r = "trapezoids" : Da(e, t) ? r = "sectors" : Un(e, t) && (r = "points"), r;
}
function f$(e, t) {
  if (ka(e, t)) {
    var r;
    return (r = t.tooltipPayload) === null || r === void 0 || (r = r[0]) === null || r === void 0 || (r = r.payload) === null || r === void 0 ? void 0 : r.payload;
  }
  if (Da(e, t)) {
    var n;
    return (n = t.tooltipPayload) === null || n === void 0 || (n = n[0]) === null || n === void 0 || (n = n.payload) === null || n === void 0 ? void 0 : n.payload;
  }
  return Un(e, t) ? t.payload : {};
}
function d$(e) {
  var t = e.activeTooltipItem, r = e.graphicalItem, n = e.itemData, i = l$(r, t), a = f$(r, t), o = n.filter(function(s, c) {
    var f = Pn(a, s), l = r.props[i].filter(function(y) {
      var v = c$(r, t);
      return v(y, t);
    }), d = r.props[i].indexOf(l[l.length - 1]), p = c === d;
    return f && p;
  }), u = n.indexOf(o[o.length - 1]);
  return u;
}
var Sc, ng;
function h$() {
  if (ng) return Sc;
  ng = 1;
  var e = Math.ceil, t = Math.max;
  function r(n, i, a, o) {
    for (var u = -1, s = t(e((i - n) / (a || 1)), 0), c = Array(s); s--; )
      c[o ? s : ++u] = n, n += a;
    return c;
  }
  return Sc = r, Sc;
}
var Ac, ig;
function yx() {
  if (ig) return Ac;
  ig = 1;
  var e = r0(), t = 1 / 0, r = 17976931348623157e292;
  function n(i) {
    if (!i)
      return i === 0 ? i : 0;
    if (i = e(i), i === t || i === -t) {
      var a = i < 0 ? -1 : 1;
      return a * r;
    }
    return i === i ? i : 0;
  }
  return Ac = n, Ac;
}
var Pc, ag;
function p$() {
  if (ag) return Pc;
  ag = 1;
  var e = h$(), t = Sa(), r = yx();
  function n(i) {
    return function(a, o, u) {
      return u && typeof u != "number" && t(a, o, u) && (o = u = void 0), a = r(a), o === void 0 ? (o = a, a = 0) : o = r(o), u = u === void 0 ? a < o ? 1 : -1 : r(u), e(a, o, u, i);
    };
  }
  return Pc = n, Pc;
}
var Tc, og;
function v$() {
  if (og) return Tc;
  og = 1;
  var e = p$(), t = e();
  return Tc = t, Tc;
}
var y$ = v$();
const Xi = /* @__PURE__ */ ce(y$);
function Wn(e) {
  "@babel/helpers - typeof";
  return Wn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Wn(e);
}
function ug(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function sg(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? ug(Object(r), !0).forEach(function(n) {
      mx(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ug(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function mx(e, t, r) {
  return t = m$(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function m$(e) {
  var t = g$(e, "string");
  return Wn(t) == "symbol" ? t : t + "";
}
function g$(e, t) {
  if (Wn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Wn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var b$ = ["Webkit", "Moz", "O", "ms"], x$ = function(t, r) {
  var n = t.replace(/(\w)/, function(a) {
    return a.toUpperCase();
  }), i = b$.reduce(function(a, o) {
    return sg(sg({}, a), {}, mx({}, o + n, r));
  }, {});
  return i[t] = r, i;
};
function Tr(e) {
  "@babel/helpers - typeof";
  return Tr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Tr(e);
}
function Yi() {
  return Yi = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Yi.apply(this, arguments);
}
function cg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function jc(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? cg(Object(r), !0).forEach(function(n) {
      Re(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : cg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function w$(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function lg(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, bx(n.key), n);
  }
}
function O$(e, t, r) {
  return t && lg(e.prototype, t), r && lg(e, r), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function _$(e, t, r) {
  return t = Zi(t), S$(e, gx() ? Reflect.construct(t, r || [], Zi(e).constructor) : t.apply(e, r));
}
function S$(e, t) {
  if (t && (Tr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return A$(e);
}
function A$(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function gx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (gx = function() {
    return !!e;
  })();
}
function Zi(e) {
  return Zi = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, Zi(e);
}
function P$(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && Vl(e, t);
}
function Vl(e, t) {
  return Vl = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, Vl(e, t);
}
function Re(e, t, r) {
  return t = bx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function bx(e) {
  var t = T$(e, "string");
  return Tr(t) == "symbol" ? t : t + "";
}
function T$(e, t) {
  if (Tr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Tr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var j$ = function(t) {
  var r = t.data, n = t.startIndex, i = t.endIndex, a = t.x, o = t.width, u = t.travellerWidth;
  if (!r || !r.length)
    return {};
  var s = r.length, c = ln().domain(Xi(0, s)).range([a, a + o - u]), f = c.domain().map(function(l) {
    return c(l);
  });
  return {
    isTextActive: !1,
    isSlideMoving: !1,
    isTravellerMoving: !1,
    isTravellerFocused: !1,
    startX: c(n),
    endX: c(i),
    scale: c,
    scaleValues: f
  };
}, fg = function(t) {
  return t.changedTouches && !!t.changedTouches.length;
}, jr = /* @__PURE__ */ function(e) {
  function t(r) {
    var n;
    return w$(this, t), n = _$(this, t, [r]), Re(n, "handleDrag", function(i) {
      n.leaveTimer && (clearTimeout(n.leaveTimer), n.leaveTimer = null), n.state.isTravellerMoving ? n.handleTravellerMove(i) : n.state.isSlideMoving && n.handleSlideDrag(i);
    }), Re(n, "handleTouchMove", function(i) {
      i.changedTouches != null && i.changedTouches.length > 0 && n.handleDrag(i.changedTouches[0]);
    }), Re(n, "handleDragEnd", function() {
      n.setState({
        isTravellerMoving: !1,
        isSlideMoving: !1
      }, function() {
        var i = n.props, a = i.endIndex, o = i.onDragEnd, u = i.startIndex;
        o == null || o({
          endIndex: a,
          startIndex: u
        });
      }), n.detachDragEndListener();
    }), Re(n, "handleLeaveWrapper", function() {
      (n.state.isTravellerMoving || n.state.isSlideMoving) && (n.leaveTimer = window.setTimeout(n.handleDragEnd, n.props.leaveTimeOut));
    }), Re(n, "handleEnterSlideOrTraveller", function() {
      n.setState({
        isTextActive: !0
      });
    }), Re(n, "handleLeaveSlideOrTraveller", function() {
      n.setState({
        isTextActive: !1
      });
    }), Re(n, "handleSlideDragStart", function(i) {
      var a = fg(i) ? i.changedTouches[0] : i;
      n.setState({
        isTravellerMoving: !1,
        isSlideMoving: !0,
        slideMoveStartX: a.pageX
      }), n.attachDragEndListener();
    }), n.travellerDragStartHandlers = {
      startX: n.handleTravellerDragStart.bind(n, "startX"),
      endX: n.handleTravellerDragStart.bind(n, "endX")
    }, n.state = {}, n;
  }
  return P$(t, e), O$(t, [{
    key: "componentWillUnmount",
    value: function() {
      this.leaveTimer && (clearTimeout(this.leaveTimer), this.leaveTimer = null), this.detachDragEndListener();
    }
  }, {
    key: "getIndex",
    value: function(n) {
      var i = n.startX, a = n.endX, o = this.state.scaleValues, u = this.props, s = u.gap, c = u.data, f = c.length - 1, l = Math.min(i, a), d = Math.max(i, a), p = t.getIndexInRange(o, l), y = t.getIndexInRange(o, d);
      return {
        startIndex: p - p % s,
        endIndex: y === f ? f : y - y % s
      };
    }
  }, {
    key: "getTextOfTick",
    value: function(n) {
      var i = this.props, a = i.data, o = i.tickFormatter, u = i.dataKey, s = Be(a[n], u, n);
      return Z(o) ? o(s, n) : s;
    }
  }, {
    key: "attachDragEndListener",
    value: function() {
      window.addEventListener("mouseup", this.handleDragEnd, !0), window.addEventListener("touchend", this.handleDragEnd, !0), window.addEventListener("mousemove", this.handleDrag, !0);
    }
  }, {
    key: "detachDragEndListener",
    value: function() {
      window.removeEventListener("mouseup", this.handleDragEnd, !0), window.removeEventListener("touchend", this.handleDragEnd, !0), window.removeEventListener("mousemove", this.handleDrag, !0);
    }
  }, {
    key: "handleSlideDrag",
    value: function(n) {
      var i = this.state, a = i.slideMoveStartX, o = i.startX, u = i.endX, s = this.props, c = s.x, f = s.width, l = s.travellerWidth, d = s.startIndex, p = s.endIndex, y = s.onChange, v = n.pageX - a;
      v > 0 ? v = Math.min(v, c + f - l - u, c + f - l - o) : v < 0 && (v = Math.max(v, c - o, c - u));
      var h = this.getIndex({
        startX: o + v,
        endX: u + v
      });
      (h.startIndex !== d || h.endIndex !== p) && y && y(h), this.setState({
        startX: o + v,
        endX: u + v,
        slideMoveStartX: n.pageX
      });
    }
  }, {
    key: "handleTravellerDragStart",
    value: function(n, i) {
      var a = fg(i) ? i.changedTouches[0] : i;
      this.setState({
        isSlideMoving: !1,
        isTravellerMoving: !0,
        movingTravellerId: n,
        brushMoveStartX: a.pageX
      }), this.attachDragEndListener();
    }
  }, {
    key: "handleTravellerMove",
    value: function(n) {
      var i = this.state, a = i.brushMoveStartX, o = i.movingTravellerId, u = i.endX, s = i.startX, c = this.state[o], f = this.props, l = f.x, d = f.width, p = f.travellerWidth, y = f.onChange, v = f.gap, h = f.data, w = {
        startX: this.state.startX,
        endX: this.state.endX
      }, b = n.pageX - a;
      b > 0 ? b = Math.min(b, l + d - p - c) : b < 0 && (b = Math.max(b, l - c)), w[o] = c + b;
      var x = this.getIndex(w), O = x.startIndex, m = x.endIndex, g = function() {
        var A = h.length - 1;
        return o === "startX" && (u > s ? O % v === 0 : m % v === 0) || u < s && m === A || o === "endX" && (u > s ? m % v === 0 : O % v === 0) || u > s && m === A;
      };
      this.setState(Re(Re({}, o, c + b), "brushMoveStartX", n.pageX), function() {
        y && g() && y(x);
      });
    }
  }, {
    key: "handleTravellerMoveKeyboard",
    value: function(n, i) {
      var a = this, o = this.state, u = o.scaleValues, s = o.startX, c = o.endX, f = this.state[i], l = u.indexOf(f);
      if (l !== -1) {
        var d = l + n;
        if (!(d === -1 || d >= u.length)) {
          var p = u[d];
          i === "startX" && p >= c || i === "endX" && p <= s || this.setState(Re({}, i, p), function() {
            a.props.onChange(a.getIndex({
              startX: a.state.startX,
              endX: a.state.endX
            }));
          });
        }
      }
    }
  }, {
    key: "renderBackground",
    value: function() {
      var n = this.props, i = n.x, a = n.y, o = n.width, u = n.height, s = n.fill, c = n.stroke;
      return /* @__PURE__ */ T.createElement("rect", {
        stroke: c,
        fill: s,
        x: i,
        y: a,
        width: o,
        height: u
      });
    }
  }, {
    key: "renderPanorama",
    value: function() {
      var n = this.props, i = n.x, a = n.y, o = n.width, u = n.height, s = n.data, c = n.children, f = n.padding, l = D.Children.only(c);
      return l ? /* @__PURE__ */ T.cloneElement(l, {
        x: i,
        y: a,
        width: o,
        height: u,
        margin: f,
        compact: !0,
        data: s
      }) : null;
    }
  }, {
    key: "renderTravellerLayer",
    value: function(n, i) {
      var a, o, u = this, s = this.props, c = s.y, f = s.travellerWidth, l = s.height, d = s.traveller, p = s.ariaLabel, y = s.data, v = s.startIndex, h = s.endIndex, w = Math.max(n, this.props.x), b = jc(jc({}, J(this.props, !1)), {}, {
        x: w,
        y: c,
        width: f,
        height: l
      }), x = p || "Min value: ".concat((a = y[v]) === null || a === void 0 ? void 0 : a.name, ", Max value: ").concat((o = y[h]) === null || o === void 0 ? void 0 : o.name);
      return /* @__PURE__ */ T.createElement(he, {
        tabIndex: 0,
        role: "slider",
        "aria-label": x,
        "aria-valuenow": n,
        className: "recharts-brush-traveller",
        onMouseEnter: this.handleEnterSlideOrTraveller,
        onMouseLeave: this.handleLeaveSlideOrTraveller,
        onMouseDown: this.travellerDragStartHandlers[i],
        onTouchStart: this.travellerDragStartHandlers[i],
        onKeyDown: function(m) {
          ["ArrowLeft", "ArrowRight"].includes(m.key) && (m.preventDefault(), m.stopPropagation(), u.handleTravellerMoveKeyboard(m.key === "ArrowRight" ? 1 : -1, i));
        },
        onFocus: function() {
          u.setState({
            isTravellerFocused: !0
          });
        },
        onBlur: function() {
          u.setState({
            isTravellerFocused: !1
          });
        },
        style: {
          cursor: "col-resize"
        }
      }, t.renderTraveller(d, b));
    }
  }, {
    key: "renderSlide",
    value: function(n, i) {
      var a = this.props, o = a.y, u = a.height, s = a.stroke, c = a.travellerWidth, f = Math.min(n, i) + c, l = Math.max(Math.abs(i - n) - c, 0);
      return /* @__PURE__ */ T.createElement("rect", {
        className: "recharts-brush-slide",
        onMouseEnter: this.handleEnterSlideOrTraveller,
        onMouseLeave: this.handleLeaveSlideOrTraveller,
        onMouseDown: this.handleSlideDragStart,
        onTouchStart: this.handleSlideDragStart,
        style: {
          cursor: "move"
        },
        stroke: "none",
        fill: s,
        fillOpacity: 0.2,
        x: f,
        y: o,
        width: l,
        height: u
      });
    }
  }, {
    key: "renderText",
    value: function() {
      var n = this.props, i = n.startIndex, a = n.endIndex, o = n.y, u = n.height, s = n.travellerWidth, c = n.stroke, f = this.state, l = f.startX, d = f.endX, p = 5, y = {
        pointerEvents: "none",
        fill: c
      };
      return /* @__PURE__ */ T.createElement(he, {
        className: "recharts-brush-texts"
      }, /* @__PURE__ */ T.createElement(ji, Yi({
        textAnchor: "end",
        verticalAnchor: "middle",
        x: Math.min(l, d) - p,
        y: o + u / 2
      }, y), this.getTextOfTick(i)), /* @__PURE__ */ T.createElement(ji, Yi({
        textAnchor: "start",
        verticalAnchor: "middle",
        x: Math.max(l, d) + s + p,
        y: o + u / 2
      }, y), this.getTextOfTick(a)));
    }
  }, {
    key: "render",
    value: function() {
      var n = this.props, i = n.data, a = n.className, o = n.children, u = n.x, s = n.y, c = n.width, f = n.height, l = n.alwaysShowText, d = this.state, p = d.startX, y = d.endX, v = d.isTextActive, h = d.isSlideMoving, w = d.isTravellerMoving, b = d.isTravellerFocused;
      if (!i || !i.length || !q(u) || !q(s) || !q(c) || !q(f) || c <= 0 || f <= 0)
        return null;
      var x = re("recharts-brush", a), O = T.Children.count(o) === 1, m = x$("userSelect", "none");
      return /* @__PURE__ */ T.createElement(he, {
        className: x,
        onMouseLeave: this.handleLeaveWrapper,
        onTouchMove: this.handleTouchMove,
        style: m
      }, this.renderBackground(), O && this.renderPanorama(), this.renderSlide(p, y), this.renderTravellerLayer(p, "startX"), this.renderTravellerLayer(y, "endX"), (v || h || w || b || l) && this.renderText());
    }
  }], [{
    key: "renderDefaultTraveller",
    value: function(n) {
      var i = n.x, a = n.y, o = n.width, u = n.height, s = n.stroke, c = Math.floor(a + u / 2) - 1;
      return /* @__PURE__ */ T.createElement(T.Fragment, null, /* @__PURE__ */ T.createElement("rect", {
        x: i,
        y: a,
        width: o,
        height: u,
        fill: s,
        stroke: "none"
      }), /* @__PURE__ */ T.createElement("line", {
        x1: i + 1,
        y1: c,
        x2: i + o - 1,
        y2: c,
        fill: "none",
        stroke: "#fff"
      }), /* @__PURE__ */ T.createElement("line", {
        x1: i + 1,
        y1: c + 2,
        x2: i + o - 1,
        y2: c + 2,
        fill: "none",
        stroke: "#fff"
      }));
    }
  }, {
    key: "renderTraveller",
    value: function(n, i) {
      var a;
      return /* @__PURE__ */ T.isValidElement(n) ? a = /* @__PURE__ */ T.cloneElement(n, i) : Z(n) ? a = n(i) : a = t.renderDefaultTraveller(i), a;
    }
  }, {
    key: "getDerivedStateFromProps",
    value: function(n, i) {
      var a = n.data, o = n.width, u = n.x, s = n.travellerWidth, c = n.updateId, f = n.startIndex, l = n.endIndex;
      if (a !== i.prevData || c !== i.prevUpdateId)
        return jc({
          prevData: a,
          prevTravellerWidth: s,
          prevUpdateId: c,
          prevX: u,
          prevWidth: o
        }, a && a.length ? j$({
          data: a,
          width: o,
          x: u,
          travellerWidth: s,
          startIndex: f,
          endIndex: l
        }) : {
          scale: null,
          scaleValues: null
        });
      if (i.scale && (o !== i.prevWidth || u !== i.prevX || s !== i.prevTravellerWidth)) {
        i.scale.range([u, u + o - s]);
        var d = i.scale.domain().map(function(p) {
          return i.scale(p);
        });
        return {
          prevData: a,
          prevTravellerWidth: s,
          prevUpdateId: c,
          prevX: u,
          prevWidth: o,
          startX: i.scale(n.startIndex),
          endX: i.scale(n.endIndex),
          scaleValues: d
        };
      }
      return null;
    }
  }, {
    key: "getIndexInRange",
    value: function(n, i) {
      for (var a = n.length, o = 0, u = a - 1; u - o > 1; ) {
        var s = Math.floor((o + u) / 2);
        n[s] > i ? u = s : o = s;
      }
      return i >= n[u] ? u : o;
    }
  }]);
}(D.PureComponent);
Re(jr, "displayName", "Brush");
Re(jr, "defaultProps", {
  height: 40,
  travellerWidth: 5,
  gap: 1,
  fill: "#fff",
  stroke: "#666",
  padding: {
    top: 1,
    right: 1,
    bottom: 1,
    left: 1
  },
  leaveTimeOut: 1e3,
  alwaysShowText: !1
});
var Ec, dg;
function E$() {
  if (dg) return Ec;
  dg = 1;
  var e = Lf();
  function t(r, n) {
    var i;
    return e(r, function(a, o, u) {
      return i = n(a, o, u), !i;
    }), !!i;
  }
  return Ec = t, Ec;
}
var Mc, hg;
function M$() {
  if (hg) return Mc;
  hg = 1;
  var e = $b(), t = It(), r = E$(), n = ke(), i = Sa();
  function a(o, u, s) {
    var c = n(o) ? e : r;
    return s && i(o, u, s) && (u = void 0), c(o, t(u, 3));
  }
  return Mc = a, Mc;
}
var C$ = M$();
const I$ = /* @__PURE__ */ ce(C$);
var at = function(t, r) {
  var n = t.alwaysShow, i = t.ifOverflow;
  return n && (i = "extendDomain"), i === r;
}, Cc, pg;
function $$() {
  if (pg) return Cc;
  pg = 1;
  var e = Zb();
  function t(r, n, i) {
    n == "__proto__" && e ? e(r, n, {
      configurable: !0,
      enumerable: !0,
      value: i,
      writable: !0
    }) : r[n] = i;
  }
  return Cc = t, Cc;
}
var Ic, vg;
function N$() {
  if (vg) return Ic;
  vg = 1;
  var e = $$(), t = Xb(), r = It();
  function n(i, a) {
    var o = {};
    return a = r(a, 3), t(i, function(u, s, c) {
      e(o, s, a(u, s, c));
    }), o;
  }
  return Ic = n, Ic;
}
var k$ = N$();
const D$ = /* @__PURE__ */ ce(k$);
var $c, yg;
function R$() {
  if (yg) return $c;
  yg = 1;
  function e(t, r) {
    for (var n = -1, i = t == null ? 0 : t.length; ++n < i; )
      if (!r(t[n], n, t))
        return !1;
    return !0;
  }
  return $c = e, $c;
}
var Nc, mg;
function L$() {
  if (mg) return Nc;
  mg = 1;
  var e = Lf();
  function t(r, n) {
    var i = !0;
    return e(r, function(a, o, u) {
      return i = !!n(a, o, u), i;
    }), i;
  }
  return Nc = t, Nc;
}
var kc, gg;
function q$() {
  if (gg) return kc;
  gg = 1;
  var e = R$(), t = L$(), r = It(), n = ke(), i = Sa();
  function a(o, u, s) {
    var c = n(o) ? e : t;
    return s && i(o, u, s) && (u = void 0), c(o, r(u, 3));
  }
  return kc = a, kc;
}
var B$ = q$();
const xx = /* @__PURE__ */ ce(B$);
var F$ = ["x", "y"];
function Hn(e) {
  "@babel/helpers - typeof";
  return Hn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Hn(e);
}
function Xl() {
  return Xl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Xl.apply(this, arguments);
}
function bg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function an(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? bg(Object(r), !0).forEach(function(n) {
      z$(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : bg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function z$(e, t, r) {
  return t = U$(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function U$(e) {
  var t = W$(e, "string");
  return Hn(t) == "symbol" ? t : t + "";
}
function W$(e, t) {
  if (Hn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Hn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function H$(e, t) {
  if (e == null) return {};
  var r = K$(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function K$(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function G$(e, t) {
  var r = e.x, n = e.y, i = H$(e, F$), a = "".concat(r), o = parseInt(a, 10), u = "".concat(n), s = parseInt(u, 10), c = "".concat(t.height || i.height), f = parseInt(c, 10), l = "".concat(t.width || i.width), d = parseInt(l, 10);
  return an(an(an(an(an({}, t), i), o ? {
    x: o
  } : {}), s ? {
    y: s
  } : {}), {}, {
    height: f,
    width: d,
    name: t.name,
    radius: t.radius
  });
}
function xg(e) {
  return /* @__PURE__ */ T.createElement(a$, Xl({
    shapeType: "rectangle",
    propTransformer: G$,
    activeClassName: "recharts-active-bar"
  }, e));
}
var V$ = function(t) {
  var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
  return function(n, i) {
    if (typeof t == "number") return t;
    var a = q(n) || s1(n);
    return a ? t(n, i) : (a || Yt(), r);
  };
}, X$ = ["value", "background"], wx;
function Er(e) {
  "@babel/helpers - typeof";
  return Er = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Er(e);
}
function Y$(e, t) {
  if (e == null) return {};
  var r = Z$(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function Z$(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function Qi() {
  return Qi = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Qi.apply(this, arguments);
}
function wg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function me(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? wg(Object(r), !0).forEach(function(n) {
      jt(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : wg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Q$(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function Og(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, _x(n.key), n);
  }
}
function J$(e, t, r) {
  return t && Og(e.prototype, t), r && Og(e, r), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function eN(e, t, r) {
  return t = Ji(t), tN(e, Ox() ? Reflect.construct(t, r || [], Ji(e).constructor) : t.apply(e, r));
}
function tN(e, t) {
  if (t && (Er(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return rN(e);
}
function rN(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Ox() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Ox = function() {
    return !!e;
  })();
}
function Ji(e) {
  return Ji = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, Ji(e);
}
function nN(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && Yl(e, t);
}
function Yl(e, t) {
  return Yl = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, Yl(e, t);
}
function jt(e, t, r) {
  return t = _x(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function _x(e) {
  var t = iN(e, "string");
  return Er(t) == "symbol" ? t : t + "";
}
function iN(e, t) {
  if (Er(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Er(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var ri = /* @__PURE__ */ function(e) {
  function t() {
    var r;
    Q$(this, t);
    for (var n = arguments.length, i = new Array(n), a = 0; a < n; a++)
      i[a] = arguments[a];
    return r = eN(this, t, [].concat(i)), jt(r, "state", {
      isAnimationFinished: !1
    }), jt(r, "id", Zn("recharts-bar-")), jt(r, "handleAnimationEnd", function() {
      var o = r.props.onAnimationEnd;
      r.setState({
        isAnimationFinished: !0
      }), o && o();
    }), jt(r, "handleAnimationStart", function() {
      var o = r.props.onAnimationStart;
      r.setState({
        isAnimationFinished: !1
      }), o && o();
    }), r;
  }
  return nN(t, e), J$(t, [{
    key: "renderRectanglesStatically",
    value: function(n) {
      var i = this, a = this.props, o = a.shape, u = a.dataKey, s = a.activeIndex, c = a.activeBar, f = J(this.props, !1);
      return n && n.map(function(l, d) {
        var p = d === s, y = p ? c : o, v = me(me(me({}, f), l), {}, {
          isActive: p,
          option: y,
          index: d,
          dataKey: u,
          onAnimationStart: i.handleAnimationStart,
          onAnimationEnd: i.handleAnimationEnd
        });
        return /* @__PURE__ */ T.createElement(he, Qi({
          className: "recharts-bar-rectangle"
        }, mi(i.props, l, d), {
          // https://github.com/recharts/recharts/issues/5415
          // eslint-disable-next-line react/no-array-index-key
          key: "rectangle-".concat(l == null ? void 0 : l.x, "-").concat(l == null ? void 0 : l.y, "-").concat(l == null ? void 0 : l.value, "-").concat(d)
        }), /* @__PURE__ */ T.createElement(xg, v));
      });
    }
  }, {
    key: "renderRectanglesWithAnimation",
    value: function() {
      var n = this, i = this.props, a = i.data, o = i.layout, u = i.isAnimationActive, s = i.animationBegin, c = i.animationDuration, f = i.animationEasing, l = i.animationId, d = this.state.prevData;
      return /* @__PURE__ */ T.createElement(bt, {
        begin: s,
        duration: c,
        isActive: u,
        easing: f,
        from: {
          t: 0
        },
        to: {
          t: 1
        },
        key: "bar-".concat(l),
        onAnimationEnd: this.handleAnimationEnd,
        onAnimationStart: this.handleAnimationStart
      }, function(p) {
        var y = p.t, v = a.map(function(h, w) {
          var b = d && d[w];
          if (b) {
            var x = He(b.x, h.x), O = He(b.y, h.y), m = He(b.width, h.width), g = He(b.height, h.height);
            return me(me({}, h), {}, {
              x: x(y),
              y: O(y),
              width: m(y),
              height: g(y)
            });
          }
          if (o === "horizontal") {
            var _ = He(0, h.height), A = _(y);
            return me(me({}, h), {}, {
              y: h.y + h.height - A,
              height: A
            });
          }
          var P = He(0, h.width), $ = P(y);
          return me(me({}, h), {}, {
            width: $
          });
        });
        return /* @__PURE__ */ T.createElement(he, null, n.renderRectanglesStatically(v));
      });
    }
  }, {
    key: "renderRectangles",
    value: function() {
      var n = this.props, i = n.data, a = n.isAnimationActive, o = this.state.prevData;
      return a && i && i.length && (!o || !Pn(o, i)) ? this.renderRectanglesWithAnimation() : this.renderRectanglesStatically(i);
    }
  }, {
    key: "renderBackground",
    value: function() {
      var n = this, i = this.props, a = i.data, o = i.dataKey, u = i.activeIndex, s = J(this.props.background, !1);
      return a.map(function(c, f) {
        c.value;
        var l = c.background, d = Y$(c, X$);
        if (!l)
          return null;
        var p = me(me(me(me(me({}, d), {}, {
          fill: "#eee"
        }, l), s), mi(n.props, c, f)), {}, {
          onAnimationStart: n.handleAnimationStart,
          onAnimationEnd: n.handleAnimationEnd,
          dataKey: o,
          index: f,
          className: "recharts-bar-background-rectangle"
        });
        return /* @__PURE__ */ T.createElement(xg, Qi({
          key: "background-bar-".concat(f),
          option: n.props.background,
          isActive: f === u
        }, p));
      });
    }
  }, {
    key: "renderErrorBar",
    value: function(n, i) {
      if (this.props.isAnimationActive && !this.state.isAnimationFinished)
        return null;
      var a = this.props, o = a.data, u = a.xAxis, s = a.yAxis, c = a.layout, f = a.children, l = Je(f, Na);
      if (!l)
        return null;
      var d = c === "vertical" ? o[0].height / 2 : o[0].width / 2, p = function(h, w) {
        var b = Array.isArray(h.value) ? h.value[1] : h.value;
        return {
          x: h.x,
          y: h.y,
          value: b,
          errorVal: Be(h, w)
        };
      }, y = {
        clipPath: n ? "url(#clipPath-".concat(i, ")") : null
      };
      return /* @__PURE__ */ T.createElement(he, y, l.map(function(v) {
        return /* @__PURE__ */ T.cloneElement(v, {
          key: "error-bar-".concat(i, "-").concat(v.props.dataKey),
          data: o,
          xAxis: u,
          yAxis: s,
          layout: c,
          offset: d,
          dataPointFormatter: p
        });
      }));
    }
  }, {
    key: "render",
    value: function() {
      var n = this.props, i = n.hide, a = n.data, o = n.className, u = n.xAxis, s = n.yAxis, c = n.left, f = n.top, l = n.width, d = n.height, p = n.isAnimationActive, y = n.background, v = n.id;
      if (i || !a || !a.length)
        return null;
      var h = this.state.isAnimationFinished, w = re("recharts-bar", o), b = u && u.allowDataOverflow, x = s && s.allowDataOverflow, O = b || x, m = ee(v) ? this.id : v;
      return /* @__PURE__ */ T.createElement(he, {
        className: w
      }, b || x ? /* @__PURE__ */ T.createElement("defs", null, /* @__PURE__ */ T.createElement("clipPath", {
        id: "clipPath-".concat(m)
      }, /* @__PURE__ */ T.createElement("rect", {
        x: b ? c : c - l / 2,
        y: x ? f : f - d / 2,
        width: b ? l : l * 2,
        height: x ? d : d * 2
      }))) : null, /* @__PURE__ */ T.createElement(he, {
        className: "recharts-bar-rectangles",
        clipPath: O ? "url(#clipPath-".concat(m, ")") : null
      }, y ? this.renderBackground() : null, this.renderRectangles()), this.renderErrorBar(O, m), (!p || h) && Mt.renderCallByParent(this.props, a));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function(n, i) {
      return n.animationId !== i.prevAnimationId ? {
        prevAnimationId: n.animationId,
        curData: n.data,
        prevData: i.curData
      } : n.data !== i.curData ? {
        curData: n.data
      } : null;
    }
  }]);
}(D.PureComponent);
wx = ri;
jt(ri, "displayName", "Bar");
jt(ri, "defaultProps", {
  xAxisId: 0,
  yAxisId: 0,
  legendType: "rect",
  minPointSize: 0,
  hide: !1,
  data: [],
  layout: "vertical",
  activeBar: !1,
  isAnimationActive: !Wr.isSsr,
  animationBegin: 0,
  animationDuration: 400,
  animationEasing: "ease"
});
jt(ri, "getComposedData", function(e) {
  var t = e.props, r = e.item, n = e.barPosition, i = e.bandSize, a = e.xAxis, o = e.yAxis, u = e.xAxisTicks, s = e.yAxisTicks, c = e.stackedData, f = e.dataStartIndex, l = e.displayedData, d = e.offset, p = iM(n, r);
  if (!p)
    return null;
  var y = t.layout, v = r.type.defaultProps, h = v !== void 0 ? me(me({}, v), r.props) : r.props, w = h.dataKey, b = h.children, x = h.minPointSize, O = y === "horizontal" ? o : a, m = c ? O.scale.domain() : null, g = dM({
    numericAxis: O
  }), _ = Je(b, i0), A = l.map(function(P, $) {
    var M, j, E, C, I, N;
    c ? M = aM(c[f + $], m) : (M = Be(P, w), Array.isArray(M) || (M = [g, M]));
    var R = V$(x, wx.defaultProps.minPointSize)(M[1], $);
    if (y === "horizontal") {
      var B, F = [o.scale(M[0]), o.scale(M[1])], K = F[0], V = F[1];
      j = hm({
        axis: a,
        ticks: u,
        bandSize: i,
        offset: p.offset,
        entry: P,
        index: $
      }), E = (B = V ?? K) !== null && B !== void 0 ? B : void 0, C = p.size;
      var W = K - V;
      if (I = Number.isNaN(W) ? 0 : W, N = {
        x: j,
        y: o.y,
        width: C,
        height: o.height
      }, Math.abs(R) > 0 && Math.abs(I) < Math.abs(R)) {
        var X = Qe(I || R) * (Math.abs(R) - Math.abs(I));
        E -= X, I += X;
      }
    } else {
      var le = [a.scale(M[0]), a.scale(M[1])], ye = le[0], De = le[1];
      if (j = ye, E = hm({
        axis: o,
        ticks: s,
        bandSize: i,
        offset: p.offset,
        entry: P,
        index: $
      }), C = De - ye, I = p.size, N = {
        x: a.x,
        y: E,
        width: a.width,
        height: I
      }, Math.abs(R) > 0 && Math.abs(C) < Math.abs(R)) {
        var Dt = Qe(C || R) * (Math.abs(R) - Math.abs(C));
        C += Dt;
      }
    }
    return me(me(me({}, P), {}, {
      x: j,
      y: E,
      width: C,
      height: I,
      value: c ? M : M[1],
      payload: P,
      background: N
    }, _ && _[$] && _[$].props), {}, {
      tooltipPayload: [ox(r, P)],
      tooltipPosition: {
        x: j + C / 2,
        y: E + I / 2
      }
    });
  });
  return me({
    data: A,
    layout: y
  }, d);
});
function Kn(e) {
  "@babel/helpers - typeof";
  return Kn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Kn(e);
}
function aN(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function _g(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, Sx(n.key), n);
  }
}
function oN(e, t, r) {
  return t && _g(e.prototype, t), r && _g(e, r), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function Sg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ze(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Sg(Object(r), !0).forEach(function(n) {
      Ra(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Sg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Ra(e, t, r) {
  return t = Sx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Sx(e) {
  var t = uN(e, "string");
  return Kn(t) == "symbol" ? t : t + "";
}
function uN(e, t) {
  if (Kn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Kn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var sN = function(t, r, n, i, a) {
  var o = t.width, u = t.height, s = t.layout, c = t.children, f = Object.keys(r), l = {
    left: n.left,
    leftMirror: n.left,
    right: o - n.right,
    rightMirror: o - n.right,
    top: n.top,
    topMirror: n.top,
    bottom: u - n.bottom,
    bottomMirror: u - n.bottom
  }, d = !!Le(c, ri);
  return f.reduce(function(p, y) {
    var v = r[y], h = v.orientation, w = v.domain, b = v.padding, x = b === void 0 ? {} : b, O = v.mirror, m = v.reversed, g = "".concat(h).concat(O ? "Mirror" : ""), _, A, P, $, M;
    if (v.type === "number" && (v.padding === "gap" || v.padding === "no-gap")) {
      var j = w[1] - w[0], E = 1 / 0, C = v.categoricalDomain.sort(f1);
      if (C.forEach(function(le, ye) {
        ye > 0 && (E = Math.min((le || 0) - (C[ye - 1] || 0), E));
      }), Number.isFinite(E)) {
        var I = E / j, N = v.layout === "vertical" ? n.height : n.width;
        if (v.padding === "gap" && (_ = I * N / 2), v.padding === "no-gap") {
          var R = Vt(t.barCategoryGap, I * N), B = I * N / 2;
          _ = B - R - (B - R) / N * R;
        }
      }
    }
    i === "xAxis" ? A = [n.left + (x.left || 0) + (_ || 0), n.left + n.width - (x.right || 0) - (_ || 0)] : i === "yAxis" ? A = s === "horizontal" ? [n.top + n.height - (x.bottom || 0), n.top + (x.top || 0)] : [n.top + (x.top || 0) + (_ || 0), n.top + n.height - (x.bottom || 0) - (_ || 0)] : A = v.range, m && (A = [A[1], A[0]]);
    var F = rM(v, a, d), K = F.scale, V = F.realScaleType;
    K.domain(w).range(A), nM(K);
    var W = fM(K, Ze(Ze({}, v), {}, {
      realScaleType: V
    }));
    i === "xAxis" ? (M = h === "top" && !O || h === "bottom" && O, P = n.left, $ = l[g] - M * v.height) : i === "yAxis" && (M = h === "left" && !O || h === "right" && O, P = l[g] - M * v.width, $ = n.top);
    var X = Ze(Ze(Ze({}, v), W), {}, {
      realScaleType: V,
      x: P,
      y: $,
      scale: K,
      width: i === "xAxis" ? n.width : v.width,
      height: i === "yAxis" ? n.height : v.height
    });
    return X.bandSize = Bi(X, W), !v.hide && i === "xAxis" ? l[g] += (M ? -1 : 1) * X.height : v.hide || (l[g] += (M ? -1 : 1) * X.width), Ze(Ze({}, p), {}, Ra({}, y, X));
  }, {});
}, Ax = function(t, r) {
  var n = t.x, i = t.y, a = r.x, o = r.y;
  return {
    x: Math.min(n, a),
    y: Math.min(i, o),
    width: Math.abs(a - n),
    height: Math.abs(o - i)
  };
}, cN = function(t) {
  var r = t.x1, n = t.y1, i = t.x2, a = t.y2;
  return Ax({
    x: r,
    y: n
  }, {
    x: i,
    y: a
  });
}, Px = /* @__PURE__ */ function() {
  function e(t) {
    aN(this, e), this.scale = t;
  }
  return oN(e, [{
    key: "domain",
    get: function() {
      return this.scale.domain;
    }
  }, {
    key: "range",
    get: function() {
      return this.scale.range;
    }
  }, {
    key: "rangeMin",
    get: function() {
      return this.range()[0];
    }
  }, {
    key: "rangeMax",
    get: function() {
      return this.range()[1];
    }
  }, {
    key: "bandwidth",
    get: function() {
      return this.scale.bandwidth;
    }
  }, {
    key: "apply",
    value: function(r) {
      var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, i = n.bandAware, a = n.position;
      if (r !== void 0) {
        if (a)
          switch (a) {
            case "start":
              return this.scale(r);
            case "middle": {
              var o = this.bandwidth ? this.bandwidth() / 2 : 0;
              return this.scale(r) + o;
            }
            case "end": {
              var u = this.bandwidth ? this.bandwidth() : 0;
              return this.scale(r) + u;
            }
            default:
              return this.scale(r);
          }
        if (i) {
          var s = this.bandwidth ? this.bandwidth() / 2 : 0;
          return this.scale(r) + s;
        }
        return this.scale(r);
      }
    }
  }, {
    key: "isInRange",
    value: function(r) {
      var n = this.range(), i = n[0], a = n[n.length - 1];
      return i <= a ? r >= i && r <= a : r >= a && r <= i;
    }
  }], [{
    key: "create",
    value: function(r) {
      return new e(r);
    }
  }]);
}();
Ra(Px, "EPS", 1e-4);
var fd = function(t) {
  var r = Object.keys(t).reduce(function(n, i) {
    return Ze(Ze({}, n), {}, Ra({}, i, Px.create(t[i])));
  }, {});
  return Ze(Ze({}, r), {}, {
    apply: function(i) {
      var a = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, o = a.bandAware, u = a.position;
      return D$(i, function(s, c) {
        return r[c].apply(s, {
          bandAware: o,
          position: u
        });
      });
    },
    isInRange: function(i) {
      return xx(i, function(a, o) {
        return r[o].isInRange(a);
      });
    }
  });
};
function lN(e) {
  return (e % 180 + 180) % 180;
}
var fN = function(t) {
  var r = t.width, n = t.height, i = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0, a = lN(i), o = a * Math.PI / 180, u = Math.atan(n / r), s = o > u && o < Math.PI - u ? n / Math.sin(o) : r / Math.cos(o);
  return Math.abs(s);
}, Dc, Ag;
function dN() {
  if (Ag) return Dc;
  Ag = 1;
  var e = It(), t = Qn(), r = Oa();
  function n(i) {
    return function(a, o, u) {
      var s = Object(a);
      if (!t(a)) {
        var c = e(o, 3);
        a = r(a), o = function(l) {
          return c(s[l], l, s);
        };
      }
      var f = i(a, o, u);
      return f > -1 ? s[c ? a[f] : f] : void 0;
    };
  }
  return Dc = n, Dc;
}
var Rc, Pg;
function hN() {
  if (Pg) return Rc;
  Pg = 1;
  var e = yx();
  function t(r) {
    var n = e(r), i = n % 1;
    return n === n ? i ? n - i : n : 0;
  }
  return Rc = t, Rc;
}
var Lc, Tg;
function pN() {
  if (Tg) return Lc;
  Tg = 1;
  var e = Wb(), t = It(), r = hN(), n = Math.max;
  function i(a, o, u) {
    var s = a == null ? 0 : a.length;
    if (!s)
      return -1;
    var c = u == null ? 0 : r(u);
    return c < 0 && (c = n(s + c, 0)), e(a, t(o, 3), c);
  }
  return Lc = i, Lc;
}
var qc, jg;
function vN() {
  if (jg) return qc;
  jg = 1;
  var e = dN(), t = pN(), r = e(t);
  return qc = r, qc;
}
var yN = vN();
const mN = /* @__PURE__ */ ce(yN);
var gN = ob();
const bN = /* @__PURE__ */ ce(gN);
var xN = bN(function(e) {
  return {
    x: e.left,
    y: e.top,
    width: e.width,
    height: e.height
  };
}, function(e) {
  return ["l", e.left, "t", e.top, "w", e.width, "h", e.height].join("");
}), dd = /* @__PURE__ */ D.createContext(void 0), hd = /* @__PURE__ */ D.createContext(void 0), Tx = /* @__PURE__ */ D.createContext(void 0), jx = /* @__PURE__ */ D.createContext({}), Ex = /* @__PURE__ */ D.createContext(void 0), Mx = /* @__PURE__ */ D.createContext(0), Cx = /* @__PURE__ */ D.createContext(0), Eg = function(t) {
  var r = t.state, n = r.xAxisMap, i = r.yAxisMap, a = r.offset, o = t.clipPathId, u = t.children, s = t.width, c = t.height, f = xN(a);
  return /* @__PURE__ */ T.createElement(dd.Provider, {
    value: n
  }, /* @__PURE__ */ T.createElement(hd.Provider, {
    value: i
  }, /* @__PURE__ */ T.createElement(jx.Provider, {
    value: a
  }, /* @__PURE__ */ T.createElement(Tx.Provider, {
    value: f
  }, /* @__PURE__ */ T.createElement(Ex.Provider, {
    value: o
  }, /* @__PURE__ */ T.createElement(Mx.Provider, {
    value: c
  }, /* @__PURE__ */ T.createElement(Cx.Provider, {
    value: s
  }, u)))))));
}, wN = function() {
  return D.useContext(Ex);
}, Ix = function(t) {
  var r = D.useContext(dd);
  r == null && Yt();
  var n = r[t];
  return n == null && Yt(), n;
}, ON = function() {
  var t = D.useContext(dd);
  return Pt(t);
}, _N = function() {
  var t = D.useContext(hd), r = mN(t, function(n) {
    return xx(n.domain, Number.isFinite);
  });
  return r || Pt(t);
}, $x = function(t) {
  var r = D.useContext(hd);
  r == null && Yt();
  var n = r[t];
  return n == null && Yt(), n;
}, SN = function() {
  var t = D.useContext(Tx);
  return t;
}, AN = function() {
  return D.useContext(jx);
}, pd = function() {
  return D.useContext(Cx);
}, vd = function() {
  return D.useContext(Mx);
};
function Mr(e) {
  "@babel/helpers - typeof";
  return Mr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Mr(e);
}
function PN(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function TN(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, kx(n.key), n);
  }
}
function jN(e, t, r) {
  return t && TN(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function EN(e, t, r) {
  return t = ea(t), MN(e, Nx() ? Reflect.construct(t, r || [], ea(e).constructor) : t.apply(e, r));
}
function MN(e, t) {
  if (t && (Mr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return CN(e);
}
function CN(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Nx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Nx = function() {
    return !!e;
  })();
}
function ea(e) {
  return ea = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, ea(e);
}
function IN(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && Zl(e, t);
}
function Zl(e, t) {
  return Zl = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, Zl(e, t);
}
function Mg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Cg(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Mg(Object(r), !0).forEach(function(n) {
      yd(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Mg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function yd(e, t, r) {
  return t = kx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function kx(e) {
  var t = $N(e, "string");
  return Mr(t) == "symbol" ? t : t + "";
}
function $N(e, t) {
  if (Mr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Mr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
function NN(e, t) {
  return LN(e) || RN(e, t) || DN(e, t) || kN();
}
function kN() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function DN(e, t) {
  if (e) {
    if (typeof e == "string") return Ig(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return Ig(e, t);
  }
}
function Ig(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function RN(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function LN(e) {
  if (Array.isArray(e)) return e;
}
function Ql() {
  return Ql = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Ql.apply(this, arguments);
}
var qN = function(t, r) {
  var n;
  return /* @__PURE__ */ T.isValidElement(t) ? n = /* @__PURE__ */ T.cloneElement(t, r) : Z(t) ? n = t(r) : n = /* @__PURE__ */ T.createElement("line", Ql({}, r, {
    className: "recharts-reference-line-line"
  })), n;
}, BN = function(t, r, n, i, a, o, u, s, c) {
  var f = a.x, l = a.y, d = a.width, p = a.height;
  if (n) {
    var y = c.y, v = t.y.apply(y, {
      position: o
    });
    if (at(c, "discard") && !t.y.isInRange(v))
      return null;
    var h = [{
      x: f + d,
      y: v
    }, {
      x: f,
      y: v
    }];
    return s === "left" ? h.reverse() : h;
  }
  if (r) {
    var w = c.x, b = t.x.apply(w, {
      position: o
    });
    if (at(c, "discard") && !t.x.isInRange(b))
      return null;
    var x = [{
      x: b,
      y: l + p
    }, {
      x: b,
      y: l
    }];
    return u === "top" ? x.reverse() : x;
  }
  if (i) {
    var O = c.segment, m = O.map(function(g) {
      return t.apply(g, {
        position: o
      });
    });
    return at(c, "discard") && I$(m, function(g) {
      return !t.isInRange(g);
    }) ? null : m;
  }
  return null;
};
function FN(e) {
  var t = e.x, r = e.y, n = e.segment, i = e.xAxisId, a = e.yAxisId, o = e.shape, u = e.className, s = e.alwaysShow, c = wN(), f = Ix(i), l = $x(a), d = SN();
  if (!c || !d)
    return null;
  ht(s === void 0, 'The alwaysShow prop is deprecated. Please use ifOverflow="extendDomain" instead.');
  var p = fd({
    x: f.scale,
    y: l.scale
  }), y = _e(t), v = _e(r), h = n && n.length === 2, w = BN(p, y, v, h, d, e.position, f.orientation, l.orientation, e);
  if (!w)
    return null;
  var b = NN(w, 2), x = b[0], O = x.x, m = x.y, g = b[1], _ = g.x, A = g.y, P = at(e, "hidden") ? "url(#".concat(c, ")") : void 0, $ = Cg(Cg({
    clipPath: P
  }, J(e, !0)), {}, {
    x1: O,
    y1: m,
    x2: _,
    y2: A
  });
  return /* @__PURE__ */ T.createElement(he, {
    className: re("recharts-reference-line", u)
  }, qN(o, $), Me.renderCallByParent(e, cN({
    x1: O,
    y1: m,
    x2: _,
    y2: A
  })));
}
var md = /* @__PURE__ */ function(e) {
  function t() {
    return PN(this, t), EN(this, t, arguments);
  }
  return IN(t, e), jN(t, [{
    key: "render",
    value: function() {
      return /* @__PURE__ */ T.createElement(FN, this.props);
    }
  }]);
}(T.Component);
yd(md, "displayName", "ReferenceLine");
yd(md, "defaultProps", {
  isFront: !1,
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  fill: "none",
  stroke: "#ccc",
  fillOpacity: 1,
  strokeWidth: 1,
  position: "middle"
});
function Jl() {
  return Jl = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Jl.apply(this, arguments);
}
function Cr(e) {
  "@babel/helpers - typeof";
  return Cr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Cr(e);
}
function $g(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ng(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? $g(Object(r), !0).forEach(function(n) {
      La(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : $g(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function zN(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function UN(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, Rx(n.key), n);
  }
}
function WN(e, t, r) {
  return t && UN(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function HN(e, t, r) {
  return t = ta(t), KN(e, Dx() ? Reflect.construct(t, r || [], ta(e).constructor) : t.apply(e, r));
}
function KN(e, t) {
  if (t && (Cr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return GN(e);
}
function GN(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Dx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Dx = function() {
    return !!e;
  })();
}
function ta(e) {
  return ta = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, ta(e);
}
function VN(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && ef(e, t);
}
function ef(e, t) {
  return ef = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, ef(e, t);
}
function La(e, t, r) {
  return t = Rx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Rx(e) {
  var t = XN(e, "string");
  return Cr(t) == "symbol" ? t : t + "";
}
function XN(e, t) {
  if (Cr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Cr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var YN = function(t) {
  var r = t.x, n = t.y, i = t.xAxis, a = t.yAxis, o = fd({
    x: i.scale,
    y: a.scale
  }), u = o.apply({
    x: r,
    y: n
  }, {
    bandAware: !0
  });
  return at(t, "discard") && !o.isInRange(u) ? null : u;
}, qa = /* @__PURE__ */ function(e) {
  function t() {
    return zN(this, t), HN(this, t, arguments);
  }
  return VN(t, e), WN(t, [{
    key: "render",
    value: function() {
      var n = this.props, i = n.x, a = n.y, o = n.r, u = n.alwaysShow, s = n.clipPathId, c = _e(i), f = _e(a);
      if (ht(u === void 0, 'The alwaysShow prop is deprecated. Please use ifOverflow="extendDomain" instead.'), !c || !f)
        return null;
      var l = YN(this.props);
      if (!l)
        return null;
      var d = l.x, p = l.y, y = this.props, v = y.shape, h = y.className, w = at(this.props, "hidden") ? "url(#".concat(s, ")") : void 0, b = Ng(Ng({
        clipPath: w
      }, J(this.props, !0)), {}, {
        cx: d,
        cy: p
      });
      return /* @__PURE__ */ T.createElement(he, {
        className: re("recharts-reference-dot", h)
      }, t.renderDot(v, b), Me.renderCallByParent(this.props, {
        x: d - o,
        y: p - o,
        width: 2 * o,
        height: 2 * o
      }));
    }
  }]);
}(T.Component);
La(qa, "displayName", "ReferenceDot");
La(qa, "defaultProps", {
  isFront: !1,
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  r: 10,
  fill: "#fff",
  stroke: "#ccc",
  fillOpacity: 1,
  strokeWidth: 1
});
La(qa, "renderDot", function(e, t) {
  var r;
  return /* @__PURE__ */ T.isValidElement(e) ? r = /* @__PURE__ */ T.cloneElement(e, t) : Z(e) ? r = e(t) : r = /* @__PURE__ */ T.createElement(ld, Jl({}, t, {
    cx: t.cx,
    cy: t.cy,
    className: "recharts-reference-dot-dot"
  })), r;
});
function tf() {
  return tf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, tf.apply(this, arguments);
}
function Ir(e) {
  "@babel/helpers - typeof";
  return Ir = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Ir(e);
}
function kg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Dg(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? kg(Object(r), !0).forEach(function(n) {
      Ba(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : kg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function ZN(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function QN(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, qx(n.key), n);
  }
}
function JN(e, t, r) {
  return t && QN(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function ek(e, t, r) {
  return t = ra(t), tk(e, Lx() ? Reflect.construct(t, r || [], ra(e).constructor) : t.apply(e, r));
}
function tk(e, t) {
  if (t && (Ir(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return rk(e);
}
function rk(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Lx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Lx = function() {
    return !!e;
  })();
}
function ra(e) {
  return ra = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, ra(e);
}
function nk(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && rf(e, t);
}
function rf(e, t) {
  return rf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, rf(e, t);
}
function Ba(e, t, r) {
  return t = qx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function qx(e) {
  var t = ik(e, "string");
  return Ir(t) == "symbol" ? t : t + "";
}
function ik(e, t) {
  if (Ir(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Ir(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var ak = function(t, r, n, i, a) {
  var o = a.x1, u = a.x2, s = a.y1, c = a.y2, f = a.xAxis, l = a.yAxis;
  if (!f || !l) return null;
  var d = fd({
    x: f.scale,
    y: l.scale
  }), p = {
    x: t ? d.x.apply(o, {
      position: "start"
    }) : d.x.rangeMin,
    y: n ? d.y.apply(s, {
      position: "start"
    }) : d.y.rangeMin
  }, y = {
    x: r ? d.x.apply(u, {
      position: "end"
    }) : d.x.rangeMax,
    y: i ? d.y.apply(c, {
      position: "end"
    }) : d.y.rangeMax
  };
  return at(a, "discard") && (!d.isInRange(p) || !d.isInRange(y)) ? null : Ax(p, y);
}, Fa = /* @__PURE__ */ function(e) {
  function t() {
    return ZN(this, t), ek(this, t, arguments);
  }
  return nk(t, e), JN(t, [{
    key: "render",
    value: function() {
      var n = this.props, i = n.x1, a = n.x2, o = n.y1, u = n.y2, s = n.className, c = n.alwaysShow, f = n.clipPathId;
      ht(c === void 0, 'The alwaysShow prop is deprecated. Please use ifOverflow="extendDomain" instead.');
      var l = _e(i), d = _e(a), p = _e(o), y = _e(u), v = this.props.shape;
      if (!l && !d && !p && !y && !v)
        return null;
      var h = ak(l, d, p, y, this.props);
      if (!h && !v)
        return null;
      var w = at(this.props, "hidden") ? "url(#".concat(f, ")") : void 0;
      return /* @__PURE__ */ T.createElement(he, {
        className: re("recharts-reference-area", s)
      }, t.renderRect(v, Dg(Dg({
        clipPath: w
      }, J(this.props, !0)), h)), Me.renderCallByParent(this.props, h));
    }
  }]);
}(T.Component);
Ba(Fa, "displayName", "ReferenceArea");
Ba(Fa, "defaultProps", {
  isFront: !1,
  ifOverflow: "discard",
  xAxisId: 0,
  yAxisId: 0,
  r: 10,
  fill: "#ccc",
  fillOpacity: 0.5,
  stroke: "none",
  strokeWidth: 1
});
Ba(Fa, "renderRect", function(e, t) {
  var r;
  return /* @__PURE__ */ T.isValidElement(e) ? r = /* @__PURE__ */ T.cloneElement(e, t) : Z(e) ? r = e(t) : r = /* @__PURE__ */ T.createElement(cd, tf({}, t, {
    className: "recharts-reference-area-rect"
  })), r;
});
function Bx(e, t, r) {
  if (t < 1)
    return [];
  if (t === 1 && r === void 0)
    return e;
  for (var n = [], i = 0; i < e.length; i += t)
    n.push(e[i]);
  return n;
}
function ok(e, t, r) {
  var n = {
    width: e.width + t.width,
    height: e.height + t.height
  };
  return fN(n, r);
}
function uk(e, t, r) {
  var n = r === "width", i = e.x, a = e.y, o = e.width, u = e.height;
  return t === 1 ? {
    start: n ? i : a,
    end: n ? i + o : a + u
  } : {
    start: n ? i + o : a + u,
    end: n ? i : a
  };
}
function na(e, t, r, n, i) {
  if (e * t < e * n || e * t > e * i)
    return !1;
  var a = r();
  return e * (t - e * a / 2 - n) >= 0 && e * (t + e * a / 2 - i) <= 0;
}
function sk(e, t) {
  return Bx(e, t + 1);
}
function ck(e, t, r, n, i) {
  for (var a = (n || []).slice(), o = t.start, u = t.end, s = 0, c = 1, f = o, l = function() {
    var y = n == null ? void 0 : n[s];
    if (y === void 0)
      return {
        v: Bx(n, c)
      };
    var v = s, h, w = function() {
      return h === void 0 && (h = r(y, v)), h;
    }, b = y.coordinate, x = s === 0 || na(e, b, w, f, u);
    x || (s = 0, f = o, c += 1), x && (f = b + e * (w() / 2 + i), s += c);
  }, d; c <= a.length; )
    if (d = l(), d) return d.v;
  return [];
}
function Gn(e) {
  "@babel/helpers - typeof";
  return Gn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Gn(e);
}
function Rg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ee(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Rg(Object(r), !0).forEach(function(n) {
      lk(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Rg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function lk(e, t, r) {
  return t = fk(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function fk(e) {
  var t = dk(e, "string");
  return Gn(t) == "symbol" ? t : t + "";
}
function dk(e, t) {
  if (Gn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Gn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function hk(e, t, r, n, i) {
  for (var a = (n || []).slice(), o = a.length, u = t.start, s = t.end, c = function(d) {
    var p = a[d], y, v = function() {
      return y === void 0 && (y = r(p, d)), y;
    };
    if (d === o - 1) {
      var h = e * (p.coordinate + e * v() / 2 - s);
      a[d] = p = Ee(Ee({}, p), {}, {
        tickCoord: h > 0 ? p.coordinate - h * e : p.coordinate
      });
    } else
      a[d] = p = Ee(Ee({}, p), {}, {
        tickCoord: p.coordinate
      });
    var w = na(e, p.tickCoord, v, u, s);
    w && (s = p.tickCoord - e * (v() / 2 + i), a[d] = Ee(Ee({}, p), {}, {
      isShow: !0
    }));
  }, f = o - 1; f >= 0; f--)
    c(f);
  return a;
}
function pk(e, t, r, n, i, a) {
  var o = (n || []).slice(), u = o.length, s = t.start, c = t.end;
  if (a) {
    var f = n[u - 1], l = r(f, u - 1), d = e * (f.coordinate + e * l / 2 - c);
    o[u - 1] = f = Ee(Ee({}, f), {}, {
      tickCoord: d > 0 ? f.coordinate - d * e : f.coordinate
    });
    var p = na(e, f.tickCoord, function() {
      return l;
    }, s, c);
    p && (c = f.tickCoord - e * (l / 2 + i), o[u - 1] = Ee(Ee({}, f), {}, {
      isShow: !0
    }));
  }
  for (var y = a ? u - 1 : u, v = function(b) {
    var x = o[b], O, m = function() {
      return O === void 0 && (O = r(x, b)), O;
    };
    if (b === 0) {
      var g = e * (x.coordinate - e * m() / 2 - s);
      o[b] = x = Ee(Ee({}, x), {}, {
        tickCoord: g < 0 ? x.coordinate - g * e : x.coordinate
      });
    } else
      o[b] = x = Ee(Ee({}, x), {}, {
        tickCoord: x.coordinate
      });
    var _ = na(e, x.tickCoord, m, s, c);
    _ && (s = x.tickCoord + e * (m() / 2 + i), o[b] = Ee(Ee({}, x), {}, {
      isShow: !0
    }));
  }, h = 0; h < y; h++)
    v(h);
  return o;
}
function gd(e, t, r) {
  var n = e.tick, i = e.ticks, a = e.viewBox, o = e.minTickGap, u = e.orientation, s = e.interval, c = e.tickFormatter, f = e.unit, l = e.angle;
  if (!i || !i.length || !n)
    return [];
  if (q(s) || Wr.isSsr)
    return sk(i, typeof s == "number" && q(s) ? s : 0);
  var d = [], p = u === "top" || u === "bottom" ? "width" : "height", y = f && p === "width" ? cn(f, {
    fontSize: t,
    letterSpacing: r
  }) : {
    width: 0,
    height: 0
  }, v = function(x, O) {
    var m = Z(c) ? c(x.value, O) : x.value;
    return p === "width" ? ok(cn(m, {
      fontSize: t,
      letterSpacing: r
    }), y, l) : cn(m, {
      fontSize: t,
      letterSpacing: r
    })[p];
  }, h = i.length >= 2 ? Qe(i[1].coordinate - i[0].coordinate) : 1, w = uk(a, h, p);
  return s === "equidistantPreserveStart" ? ck(h, w, v, i, o) : (s === "preserveStart" || s === "preserveStartEnd" ? d = pk(h, w, v, i, o, s === "preserveStartEnd") : d = hk(h, w, v, i, o), d.filter(function(b) {
    return b.isShow;
  }));
}
var vk = ["viewBox"], yk = ["viewBox"], mk = ["ticks"];
function $r(e) {
  "@babel/helpers - typeof";
  return $r = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, $r(e);
}
function cr() {
  return cr = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, cr.apply(this, arguments);
}
function Lg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function we(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Lg(Object(r), !0).forEach(function(n) {
      bd(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Lg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Bc(e, t) {
  if (e == null) return {};
  var r = gk(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function gk(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function bk(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function qg(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, zx(n.key), n);
  }
}
function xk(e, t, r) {
  return t && qg(e.prototype, t), r && qg(e, r), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function wk(e, t, r) {
  return t = ia(t), Ok(e, Fx() ? Reflect.construct(t, r || [], ia(e).constructor) : t.apply(e, r));
}
function Ok(e, t) {
  if (t && ($r(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return _k(e);
}
function _k(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Fx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Fx = function() {
    return !!e;
  })();
}
function ia(e) {
  return ia = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, ia(e);
}
function Sk(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && nf(e, t);
}
function nf(e, t) {
  return nf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, nf(e, t);
}
function bd(e, t, r) {
  return t = zx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function zx(e) {
  var t = Ak(e, "string");
  return $r(t) == "symbol" ? t : t + "";
}
function Ak(e, t) {
  if ($r(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if ($r(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var Gr = /* @__PURE__ */ function(e) {
  function t(r) {
    var n;
    return bk(this, t), n = wk(this, t, [r]), n.state = {
      fontSize: "",
      letterSpacing: ""
    }, n;
  }
  return Sk(t, e), xk(t, [{
    key: "shouldComponentUpdate",
    value: function(n, i) {
      var a = n.viewBox, o = Bc(n, vk), u = this.props, s = u.viewBox, c = Bc(u, yk);
      return !fr(a, s) || !fr(o, c) || !fr(i, this.state);
    }
  }, {
    key: "componentDidMount",
    value: function() {
      var n = this.layerReference;
      if (n) {
        var i = n.getElementsByClassName("recharts-cartesian-axis-tick-value")[0];
        i && this.setState({
          fontSize: window.getComputedStyle(i).fontSize,
          letterSpacing: window.getComputedStyle(i).letterSpacing
        });
      }
    }
    /**
     * Calculate the coordinates of endpoints in ticks
     * @param  {Object} data The data of a simple tick
     * @return {Object} (x1, y1): The coordinate of endpoint close to tick text
     *  (x2, y2): The coordinate of endpoint close to axis
     */
  }, {
    key: "getTickLineCoord",
    value: function(n) {
      var i = this.props, a = i.x, o = i.y, u = i.width, s = i.height, c = i.orientation, f = i.tickSize, l = i.mirror, d = i.tickMargin, p, y, v, h, w, b, x = l ? -1 : 1, O = n.tickSize || f, m = q(n.tickCoord) ? n.tickCoord : n.coordinate;
      switch (c) {
        case "top":
          p = y = n.coordinate, h = o + +!l * s, v = h - x * O, b = v - x * d, w = m;
          break;
        case "left":
          v = h = n.coordinate, y = a + +!l * u, p = y - x * O, w = p - x * d, b = m;
          break;
        case "right":
          v = h = n.coordinate, y = a + +l * u, p = y + x * O, w = p + x * d, b = m;
          break;
        default:
          p = y = n.coordinate, h = o + +l * s, v = h + x * O, b = v + x * d, w = m;
          break;
      }
      return {
        line: {
          x1: p,
          y1: v,
          x2: y,
          y2: h
        },
        tick: {
          x: w,
          y: b
        }
      };
    }
  }, {
    key: "getTickTextAnchor",
    value: function() {
      var n = this.props, i = n.orientation, a = n.mirror, o;
      switch (i) {
        case "left":
          o = a ? "start" : "end";
          break;
        case "right":
          o = a ? "end" : "start";
          break;
        default:
          o = "middle";
          break;
      }
      return o;
    }
  }, {
    key: "getTickVerticalAnchor",
    value: function() {
      var n = this.props, i = n.orientation, a = n.mirror, o = "end";
      switch (i) {
        case "left":
        case "right":
          o = "middle";
          break;
        case "top":
          o = a ? "start" : "end";
          break;
        default:
          o = a ? "end" : "start";
          break;
      }
      return o;
    }
  }, {
    key: "renderAxisLine",
    value: function() {
      var n = this.props, i = n.x, a = n.y, o = n.width, u = n.height, s = n.orientation, c = n.mirror, f = n.axisLine, l = we(we(we({}, J(this.props, !1)), J(f, !1)), {}, {
        fill: "none"
      });
      if (s === "top" || s === "bottom") {
        var d = +(s === "top" && !c || s === "bottom" && c);
        l = we(we({}, l), {}, {
          x1: i,
          y1: a + d * u,
          x2: i + o,
          y2: a + d * u
        });
      } else {
        var p = +(s === "left" && !c || s === "right" && c);
        l = we(we({}, l), {}, {
          x1: i + p * o,
          y1: a,
          x2: i + p * o,
          y2: a + u
        });
      }
      return /* @__PURE__ */ T.createElement("line", cr({}, l, {
        className: re("recharts-cartesian-axis-line", Ge(f, "className"))
      }));
    }
  }, {
    key: "renderTicks",
    value: (
      /**
       * render the ticks
       * @param {Array} ticks The ticks to actually render (overrides what was passed in props)
       * @param {string} fontSize Fontsize to consider for tick spacing
       * @param {string} letterSpacing Letterspacing to consider for tick spacing
       * @return {ReactComponent} renderedTicks
       */
      function(n, i, a) {
        var o = this, u = this.props, s = u.tickLine, c = u.stroke, f = u.tick, l = u.tickFormatter, d = u.unit, p = gd(we(we({}, this.props), {}, {
          ticks: n
        }), i, a), y = this.getTickTextAnchor(), v = this.getTickVerticalAnchor(), h = J(this.props, !1), w = J(f, !1), b = we(we({}, h), {}, {
          fill: "none"
        }, J(s, !1)), x = p.map(function(O, m) {
          var g = o.getTickLineCoord(O), _ = g.line, A = g.tick, P = we(we(we(we({
            textAnchor: y,
            verticalAnchor: v
          }, h), {}, {
            stroke: "none",
            fill: c
          }, w), A), {}, {
            index: m,
            payload: O,
            visibleTicksCount: p.length,
            tickFormatter: l
          });
          return /* @__PURE__ */ T.createElement(he, cr({
            className: "recharts-cartesian-axis-tick",
            key: "tick-".concat(O.value, "-").concat(O.coordinate, "-").concat(O.tickCoord)
          }, mi(o.props, O, m)), s && /* @__PURE__ */ T.createElement("line", cr({}, b, _, {
            className: re("recharts-cartesian-axis-tick-line", Ge(s, "className"))
          })), f && t.renderTickItem(f, P, "".concat(Z(l) ? l(O.value, m) : O.value).concat(d || "")));
        });
        return /* @__PURE__ */ T.createElement("g", {
          className: "recharts-cartesian-axis-ticks"
        }, x);
      }
    )
  }, {
    key: "render",
    value: function() {
      var n = this, i = this.props, a = i.axisLine, o = i.width, u = i.height, s = i.ticksGenerator, c = i.className, f = i.hide;
      if (f)
        return null;
      var l = this.props, d = l.ticks, p = Bc(l, mk), y = d;
      return Z(s) && (y = d && d.length > 0 ? s(this.props) : s(p)), o <= 0 || u <= 0 || !y || !y.length ? null : /* @__PURE__ */ T.createElement(he, {
        className: re("recharts-cartesian-axis", c),
        ref: function(h) {
          n.layerReference = h;
        }
      }, a && this.renderAxisLine(), this.renderTicks(y, this.state.fontSize, this.state.letterSpacing), Me.renderCallByParent(this.props));
    }
  }], [{
    key: "renderTickItem",
    value: function(n, i, a) {
      var o, u = re(i.className, "recharts-cartesian-axis-tick-value");
      return /* @__PURE__ */ T.isValidElement(n) ? o = /* @__PURE__ */ T.cloneElement(n, we(we({}, i), {}, {
        className: u
      })) : Z(n) ? o = n(we(we({}, i), {}, {
        className: u
      })) : o = /* @__PURE__ */ T.createElement(ji, cr({}, i, {
        className: "recharts-cartesian-axis-tick-value"
      }), a), o;
    }
  }]);
}(D.Component);
bd(Gr, "displayName", "CartesianAxis");
bd(Gr, "defaultProps", {
  x: 0,
  y: 0,
  width: 0,
  height: 0,
  viewBox: {
    x: 0,
    y: 0,
    width: 0,
    height: 0
  },
  // The orientation of axis
  orientation: "bottom",
  // The ticks
  ticks: [],
  stroke: "#666",
  tickLine: !0,
  axisLine: !0,
  tick: !0,
  mirror: !1,
  minTickGap: 5,
  // The width or height of tick
  tickSize: 6,
  tickMargin: 2,
  interval: "preserveEnd"
});
var Pk = ["x1", "y1", "x2", "y2", "key"], Tk = ["offset"];
function Zt(e) {
  "@babel/helpers - typeof";
  return Zt = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Zt(e);
}
function Bg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function Ce(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Bg(Object(r), !0).forEach(function(n) {
      jk(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Bg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function jk(e, t, r) {
  return t = Ek(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Ek(e) {
  var t = Mk(e, "string");
  return Zt(t) == "symbol" ? t : t + "";
}
function Mk(e, t) {
  if (Zt(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Zt(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Wt() {
  return Wt = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Wt.apply(this, arguments);
}
function Fg(e, t) {
  if (e == null) return {};
  var r = Ck(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function Ck(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
var Ik = function(t) {
  var r = t.fill;
  if (!r || r === "none")
    return null;
  var n = t.fillOpacity, i = t.x, a = t.y, o = t.width, u = t.height, s = t.ry;
  return /* @__PURE__ */ T.createElement("rect", {
    x: i,
    y: a,
    ry: s,
    width: o,
    height: u,
    stroke: "none",
    fill: r,
    fillOpacity: n,
    className: "recharts-cartesian-grid-bg"
  });
};
function Ux(e, t) {
  var r;
  if (/* @__PURE__ */ T.isValidElement(e))
    r = /* @__PURE__ */ T.cloneElement(e, t);
  else if (Z(e))
    r = e(t);
  else {
    var n = t.x1, i = t.y1, a = t.x2, o = t.y2, u = t.key, s = Fg(t, Pk), c = J(s, !1);
    c.offset;
    var f = Fg(c, Tk);
    r = /* @__PURE__ */ T.createElement("line", Wt({}, f, {
      x1: n,
      y1: i,
      x2: a,
      y2: o,
      fill: "none",
      key: u
    }));
  }
  return r;
}
function $k(e) {
  var t = e.x, r = e.width, n = e.horizontal, i = n === void 0 ? !0 : n, a = e.horizontalPoints;
  if (!i || !a || !a.length)
    return null;
  var o = a.map(function(u, s) {
    var c = Ce(Ce({}, e), {}, {
      x1: t,
      y1: u,
      x2: t + r,
      y2: u,
      key: "line-".concat(s),
      index: s
    });
    return Ux(i, c);
  });
  return /* @__PURE__ */ T.createElement("g", {
    className: "recharts-cartesian-grid-horizontal"
  }, o);
}
function Nk(e) {
  var t = e.y, r = e.height, n = e.vertical, i = n === void 0 ? !0 : n, a = e.verticalPoints;
  if (!i || !a || !a.length)
    return null;
  var o = a.map(function(u, s) {
    var c = Ce(Ce({}, e), {}, {
      x1: u,
      y1: t,
      x2: u,
      y2: t + r,
      key: "line-".concat(s),
      index: s
    });
    return Ux(i, c);
  });
  return /* @__PURE__ */ T.createElement("g", {
    className: "recharts-cartesian-grid-vertical"
  }, o);
}
function kk(e) {
  var t = e.horizontalFill, r = e.fillOpacity, n = e.x, i = e.y, a = e.width, o = e.height, u = e.horizontalPoints, s = e.horizontal, c = s === void 0 ? !0 : s;
  if (!c || !t || !t.length)
    return null;
  var f = u.map(function(d) {
    return Math.round(d + i - i);
  }).sort(function(d, p) {
    return d - p;
  });
  i !== f[0] && f.unshift(0);
  var l = f.map(function(d, p) {
    var y = !f[p + 1], v = y ? i + o - d : f[p + 1] - d;
    if (v <= 0)
      return null;
    var h = p % t.length;
    return /* @__PURE__ */ T.createElement("rect", {
      key: "react-".concat(p),
      y: d,
      x: n,
      height: v,
      width: a,
      stroke: "none",
      fill: t[h],
      fillOpacity: r,
      className: "recharts-cartesian-grid-bg"
    });
  });
  return /* @__PURE__ */ T.createElement("g", {
    className: "recharts-cartesian-gridstripes-horizontal"
  }, l);
}
function Dk(e) {
  var t = e.vertical, r = t === void 0 ? !0 : t, n = e.verticalFill, i = e.fillOpacity, a = e.x, o = e.y, u = e.width, s = e.height, c = e.verticalPoints;
  if (!r || !n || !n.length)
    return null;
  var f = c.map(function(d) {
    return Math.round(d + a - a);
  }).sort(function(d, p) {
    return d - p;
  });
  a !== f[0] && f.unshift(0);
  var l = f.map(function(d, p) {
    var y = !f[p + 1], v = y ? a + u - d : f[p + 1] - d;
    if (v <= 0)
      return null;
    var h = p % n.length;
    return /* @__PURE__ */ T.createElement("rect", {
      key: "react-".concat(p),
      x: d,
      y: o,
      width: v,
      height: s,
      stroke: "none",
      fill: n[h],
      fillOpacity: i,
      className: "recharts-cartesian-grid-bg"
    });
  });
  return /* @__PURE__ */ T.createElement("g", {
    className: "recharts-cartesian-gridstripes-vertical"
  }, l);
}
var Rk = function(t, r) {
  var n = t.xAxis, i = t.width, a = t.height, o = t.offset;
  return ix(gd(Ce(Ce(Ce({}, Gr.defaultProps), n), {}, {
    ticks: ft(n, !0),
    viewBox: {
      x: 0,
      y: 0,
      width: i,
      height: a
    }
  })), o.left, o.left + o.width, r);
}, Lk = function(t, r) {
  var n = t.yAxis, i = t.width, a = t.height, o = t.offset;
  return ix(gd(Ce(Ce(Ce({}, Gr.defaultProps), n), {}, {
    ticks: ft(n, !0),
    viewBox: {
      x: 0,
      y: 0,
      width: i,
      height: a
    }
  })), o.top, o.top + o.height, r);
}, ar = {
  horizontal: !0,
  vertical: !0,
  stroke: "#ccc",
  fill: "none",
  // The fill of colors of grid lines
  verticalFill: [],
  horizontalFill: []
};
function Wx(e) {
  var t, r, n, i, a, o, u = pd(), s = vd(), c = AN(), f = Ce(Ce({}, e), {}, {
    stroke: (t = e.stroke) !== null && t !== void 0 ? t : ar.stroke,
    fill: (r = e.fill) !== null && r !== void 0 ? r : ar.fill,
    horizontal: (n = e.horizontal) !== null && n !== void 0 ? n : ar.horizontal,
    horizontalFill: (i = e.horizontalFill) !== null && i !== void 0 ? i : ar.horizontalFill,
    vertical: (a = e.vertical) !== null && a !== void 0 ? a : ar.vertical,
    verticalFill: (o = e.verticalFill) !== null && o !== void 0 ? o : ar.verticalFill,
    x: q(e.x) ? e.x : c.left,
    y: q(e.y) ? e.y : c.top,
    width: q(e.width) ? e.width : c.width,
    height: q(e.height) ? e.height : c.height
  }), l = f.x, d = f.y, p = f.width, y = f.height, v = f.syncWithTicks, h = f.horizontalValues, w = f.verticalValues, b = ON(), x = _N();
  if (!q(p) || p <= 0 || !q(y) || y <= 0 || !q(l) || l !== +l || !q(d) || d !== +d)
    return null;
  var O = f.verticalCoordinatesGenerator || Rk, m = f.horizontalCoordinatesGenerator || Lk, g = f.horizontalPoints, _ = f.verticalPoints;
  if ((!g || !g.length) && Z(m)) {
    var A = h && h.length, P = m({
      yAxis: x ? Ce(Ce({}, x), {}, {
        ticks: A ? h : x.ticks
      }) : void 0,
      width: u,
      height: s,
      offset: c
    }, A ? !0 : v);
    ht(Array.isArray(P), "horizontalCoordinatesGenerator should return Array but instead it returned [".concat(Zt(P), "]")), Array.isArray(P) && (g = P);
  }
  if ((!_ || !_.length) && Z(O)) {
    var $ = w && w.length, M = O({
      xAxis: b ? Ce(Ce({}, b), {}, {
        ticks: $ ? w : b.ticks
      }) : void 0,
      width: u,
      height: s,
      offset: c
    }, $ ? !0 : v);
    ht(Array.isArray(M), "verticalCoordinatesGenerator should return Array but instead it returned [".concat(Zt(M), "]")), Array.isArray(M) && (_ = M);
  }
  return /* @__PURE__ */ T.createElement("g", {
    className: "recharts-cartesian-grid"
  }, /* @__PURE__ */ T.createElement(Ik, {
    fill: f.fill,
    fillOpacity: f.fillOpacity,
    x: f.x,
    y: f.y,
    width: f.width,
    height: f.height,
    ry: f.ry
  }), /* @__PURE__ */ T.createElement($k, Wt({}, f, {
    offset: c,
    horizontalPoints: g,
    xAxis: b,
    yAxis: x
  })), /* @__PURE__ */ T.createElement(Nk, Wt({}, f, {
    offset: c,
    verticalPoints: _,
    xAxis: b,
    yAxis: x
  })), /* @__PURE__ */ T.createElement(kk, Wt({}, f, {
    horizontalPoints: g
  })), /* @__PURE__ */ T.createElement(Dk, Wt({}, f, {
    verticalPoints: _
  })));
}
Wx.displayName = "CartesianGrid";
var qk = ["layout", "type", "stroke", "connectNulls", "isRange", "ref"], Bk = ["key"], Hx;
function Nr(e) {
  "@babel/helpers - typeof";
  return Nr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Nr(e);
}
function Kx(e, t) {
  if (e == null) return {};
  var r = Fk(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function Fk(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function Ht() {
  return Ht = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, Ht.apply(this, arguments);
}
function zg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function St(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? zg(Object(r), !0).forEach(function(n) {
      it(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : zg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function zk(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function Ug(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, Vx(n.key), n);
  }
}
function Uk(e, t, r) {
  return t && Ug(e.prototype, t), r && Ug(e, r), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function Wk(e, t, r) {
  return t = aa(t), Hk(e, Gx() ? Reflect.construct(t, r || [], aa(e).constructor) : t.apply(e, r));
}
function Hk(e, t) {
  if (t && (Nr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return Kk(e);
}
function Kk(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Gx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Gx = function() {
    return !!e;
  })();
}
function aa(e) {
  return aa = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, aa(e);
}
function Gk(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && af(e, t);
}
function af(e, t) {
  return af = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, af(e, t);
}
function it(e, t, r) {
  return t = Vx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Vx(e) {
  var t = Vk(e, "string");
  return Nr(t) == "symbol" ? t : t + "";
}
function Vk(e, t) {
  if (Nr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Nr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var kt = /* @__PURE__ */ function(e) {
  function t() {
    var r;
    zk(this, t);
    for (var n = arguments.length, i = new Array(n), a = 0; a < n; a++)
      i[a] = arguments[a];
    return r = Wk(this, t, [].concat(i)), it(r, "state", {
      isAnimationFinished: !0
    }), it(r, "id", Zn("recharts-area-")), it(r, "handleAnimationEnd", function() {
      var o = r.props.onAnimationEnd;
      r.setState({
        isAnimationFinished: !0
      }), Z(o) && o();
    }), it(r, "handleAnimationStart", function() {
      var o = r.props.onAnimationStart;
      r.setState({
        isAnimationFinished: !1
      }), Z(o) && o();
    }), r;
  }
  return Gk(t, e), Uk(t, [{
    key: "renderDots",
    value: function(n, i, a) {
      var o = this.props.isAnimationActive, u = this.state.isAnimationFinished;
      if (o && !u)
        return null;
      var s = this.props, c = s.dot, f = s.points, l = s.dataKey, d = J(this.props, !1), p = J(c, !0), y = f.map(function(h, w) {
        var b = St(St(St({
          key: "dot-".concat(w),
          r: 3
        }, d), p), {}, {
          index: w,
          cx: h.x,
          cy: h.y,
          dataKey: l,
          value: h.value,
          payload: h.payload,
          points: f
        });
        return t.renderDotItem(c, b);
      }), v = {
        clipPath: n ? "url(#clipPath-".concat(i ? "" : "dots-").concat(a, ")") : null
      };
      return /* @__PURE__ */ T.createElement(he, Ht({
        className: "recharts-area-dots"
      }, v), y);
    }
  }, {
    key: "renderHorizontalRect",
    value: function(n) {
      var i = this.props, a = i.baseLine, o = i.points, u = i.strokeWidth, s = o[0].x, c = o[o.length - 1].x, f = n * Math.abs(s - c), l = Tt(o.map(function(d) {
        return d.y || 0;
      }));
      return q(a) && typeof a == "number" ? l = Math.max(a, l) : a && Array.isArray(a) && a.length && (l = Math.max(Tt(a.map(function(d) {
        return d.y || 0;
      })), l)), q(l) ? /* @__PURE__ */ T.createElement("rect", {
        x: s < c ? s : s - f,
        y: 0,
        width: f,
        height: Math.floor(l + (u ? parseInt("".concat(u), 10) : 1))
      }) : null;
    }
  }, {
    key: "renderVerticalRect",
    value: function(n) {
      var i = this.props, a = i.baseLine, o = i.points, u = i.strokeWidth, s = o[0].y, c = o[o.length - 1].y, f = n * Math.abs(s - c), l = Tt(o.map(function(d) {
        return d.x || 0;
      }));
      return q(a) && typeof a == "number" ? l = Math.max(a, l) : a && Array.isArray(a) && a.length && (l = Math.max(Tt(a.map(function(d) {
        return d.x || 0;
      })), l)), q(l) ? /* @__PURE__ */ T.createElement("rect", {
        x: 0,
        y: s < c ? s : s - f,
        width: l + (u ? parseInt("".concat(u), 10) : 1),
        height: Math.floor(f)
      }) : null;
    }
  }, {
    key: "renderClipRect",
    value: function(n) {
      var i = this.props.layout;
      return i === "vertical" ? this.renderVerticalRect(n) : this.renderHorizontalRect(n);
    }
  }, {
    key: "renderAreaStatically",
    value: function(n, i, a, o) {
      var u = this.props, s = u.layout, c = u.type, f = u.stroke, l = u.connectNulls, d = u.isRange;
      u.ref;
      var p = Kx(u, qk);
      return /* @__PURE__ */ T.createElement(he, {
        clipPath: a ? "url(#clipPath-".concat(o, ")") : null
      }, /* @__PURE__ */ T.createElement(dn, Ht({}, J(p, !0), {
        points: n,
        connectNulls: l,
        type: c,
        baseLine: i,
        layout: s,
        stroke: "none",
        className: "recharts-area-area"
      })), f !== "none" && /* @__PURE__ */ T.createElement(dn, Ht({}, J(this.props, !1), {
        className: "recharts-area-curve",
        layout: s,
        type: c,
        connectNulls: l,
        fill: "none",
        points: n
      })), f !== "none" && d && /* @__PURE__ */ T.createElement(dn, Ht({}, J(this.props, !1), {
        className: "recharts-area-curve",
        layout: s,
        type: c,
        connectNulls: l,
        fill: "none",
        points: i
      })));
    }
  }, {
    key: "renderAreaWithAnimation",
    value: function(n, i) {
      var a = this, o = this.props, u = o.points, s = o.baseLine, c = o.isAnimationActive, f = o.animationBegin, l = o.animationDuration, d = o.animationEasing, p = o.animationId, y = this.state, v = y.prevPoints, h = y.prevBaseLine;
      return /* @__PURE__ */ T.createElement(bt, {
        begin: f,
        duration: l,
        isActive: c,
        easing: d,
        from: {
          t: 0
        },
        to: {
          t: 1
        },
        key: "area-".concat(p),
        onAnimationEnd: this.handleAnimationEnd,
        onAnimationStart: this.handleAnimationStart
      }, function(w) {
        var b = w.t;
        if (v) {
          var x = v.length / u.length, O = u.map(function(A, P) {
            var $ = Math.floor(P * x);
            if (v[$]) {
              var M = v[$], j = He(M.x, A.x), E = He(M.y, A.y);
              return St(St({}, A), {}, {
                x: j(b),
                y: E(b)
              });
            }
            return A;
          }), m;
          if (q(s) && typeof s == "number") {
            var g = He(h, s);
            m = g(b);
          } else if (ee(s) || zr(s)) {
            var _ = He(h, 0);
            m = _(b);
          } else
            m = s.map(function(A, P) {
              var $ = Math.floor(P * x);
              if (h[$]) {
                var M = h[$], j = He(M.x, A.x), E = He(M.y, A.y);
                return St(St({}, A), {}, {
                  x: j(b),
                  y: E(b)
                });
              }
              return A;
            });
          return a.renderAreaStatically(O, m, n, i);
        }
        return /* @__PURE__ */ T.createElement(he, null, /* @__PURE__ */ T.createElement("defs", null, /* @__PURE__ */ T.createElement("clipPath", {
          id: "animationClipPath-".concat(i)
        }, a.renderClipRect(b))), /* @__PURE__ */ T.createElement(he, {
          clipPath: "url(#animationClipPath-".concat(i, ")")
        }, a.renderAreaStatically(u, s, n, i)));
      });
    }
  }, {
    key: "renderArea",
    value: function(n, i) {
      var a = this.props, o = a.points, u = a.baseLine, s = a.isAnimationActive, c = this.state, f = c.prevPoints, l = c.prevBaseLine, d = c.totalLength;
      return s && o && o.length && (!f && d > 0 || !Pn(f, o) || !Pn(l, u)) ? this.renderAreaWithAnimation(n, i) : this.renderAreaStatically(o, u, n, i);
    }
  }, {
    key: "render",
    value: function() {
      var n, i = this.props, a = i.hide, o = i.dot, u = i.points, s = i.className, c = i.top, f = i.left, l = i.xAxis, d = i.yAxis, p = i.width, y = i.height, v = i.isAnimationActive, h = i.id;
      if (a || !u || !u.length)
        return null;
      var w = this.state.isAnimationFinished, b = u.length === 1, x = re("recharts-area", s), O = l && l.allowDataOverflow, m = d && d.allowDataOverflow, g = O || m, _ = ee(h) ? this.id : h, A = (n = J(o, !1)) !== null && n !== void 0 ? n : {
        r: 3,
        strokeWidth: 2
      }, P = A.r, $ = P === void 0 ? 3 : P, M = A.strokeWidth, j = M === void 0 ? 2 : M, E = x1(o) ? o : {}, C = E.clipDot, I = C === void 0 ? !0 : C, N = $ * 2 + j;
      return /* @__PURE__ */ T.createElement(he, {
        className: x
      }, O || m ? /* @__PURE__ */ T.createElement("defs", null, /* @__PURE__ */ T.createElement("clipPath", {
        id: "clipPath-".concat(_)
      }, /* @__PURE__ */ T.createElement("rect", {
        x: O ? f : f - p / 2,
        y: m ? c : c - y / 2,
        width: O ? p : p * 2,
        height: m ? y : y * 2
      })), !I && /* @__PURE__ */ T.createElement("clipPath", {
        id: "clipPath-dots-".concat(_)
      }, /* @__PURE__ */ T.createElement("rect", {
        x: f - N / 2,
        y: c - N / 2,
        width: p + N,
        height: y + N
      }))) : null, b ? null : this.renderArea(g, _), (o || b) && this.renderDots(g, I, _), (!v || w) && Mt.renderCallByParent(this.props, u));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function(n, i) {
      return n.animationId !== i.prevAnimationId ? {
        prevAnimationId: n.animationId,
        curPoints: n.points,
        curBaseLine: n.baseLine,
        prevPoints: i.curPoints,
        prevBaseLine: i.curBaseLine
      } : n.points !== i.curPoints || n.baseLine !== i.curBaseLine ? {
        curPoints: n.points,
        curBaseLine: n.baseLine
      } : null;
    }
  }]);
}(D.PureComponent);
Hx = kt;
it(kt, "displayName", "Area");
it(kt, "defaultProps", {
  stroke: "#3182bd",
  fill: "#3182bd",
  fillOpacity: 0.6,
  xAxisId: 0,
  yAxisId: 0,
  legendType: "line",
  connectNulls: !1,
  // points of area
  points: [],
  dot: !1,
  activeDot: !0,
  hide: !1,
  isAnimationActive: !Wr.isSsr,
  animationBegin: 0,
  animationDuration: 1500,
  animationEasing: "ease"
});
it(kt, "getBaseValue", function(e, t, r, n) {
  var i = e.layout, a = e.baseValue, o = t.props.baseValue, u = o ?? a;
  if (q(u) && typeof u == "number")
    return u;
  var s = i === "horizontal" ? n : r, c = s.scale.domain();
  if (s.type === "number") {
    var f = Math.max(c[0], c[1]), l = Math.min(c[0], c[1]);
    return u === "dataMin" ? l : u === "dataMax" || f < 0 ? f : Math.max(Math.min(c[0], c[1]), 0);
  }
  return u === "dataMin" ? c[0] : u === "dataMax" ? c[1] : c[0];
});
it(kt, "getComposedData", function(e) {
  var t = e.props, r = e.item, n = e.xAxis, i = e.yAxis, a = e.xAxisTicks, o = e.yAxisTicks, u = e.bandSize, s = e.dataKey, c = e.stackedData, f = e.dataStartIndex, l = e.displayedData, d = e.offset, p = t.layout, y = c && c.length, v = Hx.getBaseValue(t, r, n, i), h = p === "horizontal", w = !1, b = l.map(function(O, m) {
    var g;
    y ? g = c[f + m] : (g = Be(O, s), Array.isArray(g) ? w = !0 : g = [v, g]);
    var _ = g[1] == null || y && Be(O, s) == null;
    return h ? {
      x: dm({
        axis: n,
        ticks: a,
        bandSize: u,
        entry: O,
        index: m
      }),
      y: _ ? null : i.scale(g[1]),
      value: g,
      payload: O
    } : {
      x: _ ? null : n.scale(g[1]),
      y: dm({
        axis: i,
        ticks: o,
        bandSize: u,
        entry: O,
        index: m
      }),
      value: g,
      payload: O
    };
  }), x;
  return y || w ? x = b.map(function(O) {
    var m = Array.isArray(O.value) ? O.value[0] : null;
    return h ? {
      x: O.x,
      y: m != null && O.y != null ? i.scale(m) : null
    } : {
      x: m != null ? n.scale(m) : null,
      y: O.y
    };
  }) : x = h ? i.scale(v) : n.scale(v), St({
    points: b,
    baseLine: x,
    layout: p,
    isRange: w
  }, d);
});
it(kt, "renderDotItem", function(e, t) {
  var r;
  if (/* @__PURE__ */ T.isValidElement(e))
    r = /* @__PURE__ */ T.cloneElement(e, t);
  else if (Z(e))
    r = e(t);
  else {
    var n = re("recharts-area-dot", typeof e != "boolean" ? e.className : ""), i = t.key, a = Kx(t, Bk);
    r = /* @__PURE__ */ T.createElement(ld, Ht({}, a, {
      key: i,
      className: n
    }));
  }
  return r;
});
function kr(e) {
  "@babel/helpers - typeof";
  return kr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, kr(e);
}
function Xk(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function Yk(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, Zx(n.key), n);
  }
}
function Zk(e, t, r) {
  return t && Yk(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function Qk(e, t, r) {
  return t = oa(t), Jk(e, Xx() ? Reflect.construct(t, r || [], oa(e).constructor) : t.apply(e, r));
}
function Jk(e, t) {
  if (t && (kr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return eD(e);
}
function eD(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Xx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Xx = function() {
    return !!e;
  })();
}
function oa(e) {
  return oa = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, oa(e);
}
function tD(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && of(e, t);
}
function of(e, t) {
  return of = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, of(e, t);
}
function Yx(e, t, r) {
  return t = Zx(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Zx(e) {
  var t = rD(e, "string");
  return kr(t) == "symbol" ? t : t + "";
}
function rD(e, t) {
  if (kr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (kr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
function uf() {
  return uf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, uf.apply(this, arguments);
}
function nD(e) {
  var t = e.xAxisId, r = pd(), n = vd(), i = Ix(t);
  return i == null ? null : (
    // @ts-expect-error the axisOptions type is not exactly what CartesianAxis is expecting.
    /* @__PURE__ */ D.createElement(Gr, uf({}, i, {
      className: re("recharts-".concat(i.axisType, " ").concat(i.axisType), i.className),
      viewBox: {
        x: 0,
        y: 0,
        width: r,
        height: n
      },
      ticksGenerator: function(o) {
        return ft(o, !0);
      }
    }))
  );
}
var za = /* @__PURE__ */ function(e) {
  function t() {
    return Xk(this, t), Qk(this, t, arguments);
  }
  return tD(t, e), Zk(t, [{
    key: "render",
    value: function() {
      return /* @__PURE__ */ D.createElement(nD, this.props);
    }
  }]);
}(D.Component);
Yx(za, "displayName", "XAxis");
Yx(za, "defaultProps", {
  allowDecimals: !0,
  hide: !1,
  orientation: "bottom",
  width: 0,
  height: 30,
  mirror: !1,
  xAxisId: 0,
  tickCount: 5,
  type: "category",
  padding: {
    left: 0,
    right: 0
  },
  allowDataOverflow: !1,
  scale: "auto",
  reversed: !1,
  allowDuplicatedCategory: !0
});
function Dr(e) {
  "@babel/helpers - typeof";
  return Dr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Dr(e);
}
function iD(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function aD(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, ew(n.key), n);
  }
}
function oD(e, t, r) {
  return t && aD(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function uD(e, t, r) {
  return t = ua(t), sD(e, Qx() ? Reflect.construct(t, r || [], ua(e).constructor) : t.apply(e, r));
}
function sD(e, t) {
  if (t && (Dr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return cD(e);
}
function cD(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function Qx() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (Qx = function() {
    return !!e;
  })();
}
function ua(e) {
  return ua = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, ua(e);
}
function lD(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && sf(e, t);
}
function sf(e, t) {
  return sf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, sf(e, t);
}
function Jx(e, t, r) {
  return t = ew(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function ew(e) {
  var t = fD(e, "string");
  return Dr(t) == "symbol" ? t : t + "";
}
function fD(e, t) {
  if (Dr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Dr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
function cf() {
  return cf = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, cf.apply(this, arguments);
}
var dD = function(t) {
  var r = t.yAxisId, n = pd(), i = vd(), a = $x(r);
  return a == null ? null : (
    // @ts-expect-error the axisOptions type is not exactly what CartesianAxis is expecting.
    /* @__PURE__ */ D.createElement(Gr, cf({}, a, {
      className: re("recharts-".concat(a.axisType, " ").concat(a.axisType), a.className),
      viewBox: {
        x: 0,
        y: 0,
        width: n,
        height: i
      },
      ticksGenerator: function(u) {
        return ft(u, !0);
      }
    }))
  );
}, Ua = /* @__PURE__ */ function(e) {
  function t() {
    return iD(this, t), uD(this, t, arguments);
  }
  return lD(t, e), oD(t, [{
    key: "render",
    value: function() {
      return /* @__PURE__ */ D.createElement(dD, this.props);
    }
  }]);
}(D.Component);
Jx(Ua, "displayName", "YAxis");
Jx(Ua, "defaultProps", {
  allowDuplicatedCategory: !0,
  allowDecimals: !0,
  hide: !1,
  orientation: "left",
  width: 60,
  height: 0,
  mirror: !1,
  yAxisId: 0,
  tickCount: 5,
  type: "number",
  padding: {
    top: 0,
    bottom: 0
  },
  allowDataOverflow: !1,
  scale: "auto",
  reversed: !1
});
function Wg(e) {
  return yD(e) || vD(e) || pD(e) || hD();
}
function hD() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function pD(e, t) {
  if (e) {
    if (typeof e == "string") return lf(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return lf(e, t);
  }
}
function vD(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function yD(e) {
  if (Array.isArray(e)) return lf(e);
}
function lf(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
var ff = function(t, r, n, i, a) {
  var o = Je(t, md), u = Je(t, qa), s = [].concat(Wg(o), Wg(u)), c = Je(t, Fa), f = "".concat(i, "Id"), l = i[0], d = r;
  if (s.length && (d = s.reduce(function(v, h) {
    if (h.props[f] === n && at(h.props, "extendDomain") && q(h.props[l])) {
      var w = h.props[l];
      return [Math.min(v[0], w), Math.max(v[1], w)];
    }
    return v;
  }, d)), c.length) {
    var p = "".concat(l, "1"), y = "".concat(l, "2");
    d = c.reduce(function(v, h) {
      if (h.props[f] === n && at(h.props, "extendDomain") && q(h.props[p]) && q(h.props[y])) {
        var w = h.props[p], b = h.props[y];
        return [Math.min(v[0], w, b), Math.max(v[1], w, b)];
      }
      return v;
    }, d);
  }
  return a && a.length && (d = a.reduce(function(v, h) {
    return q(h) ? [Math.min(v[0], h), Math.max(v[1], h)] : v;
  }, d)), d;
}, Fc = { exports: {} }, Hg;
function mD() {
  return Hg || (Hg = 1, function(e) {
    var t = Object.prototype.hasOwnProperty, r = "~";
    function n() {
    }
    Object.create && (n.prototype = /* @__PURE__ */ Object.create(null), new n().__proto__ || (r = !1));
    function i(s, c, f) {
      this.fn = s, this.context = c, this.once = f || !1;
    }
    function a(s, c, f, l, d) {
      if (typeof f != "function")
        throw new TypeError("The listener must be a function");
      var p = new i(f, l || s, d), y = r ? r + c : c;
      return s._events[y] ? s._events[y].fn ? s._events[y] = [s._events[y], p] : s._events[y].push(p) : (s._events[y] = p, s._eventsCount++), s;
    }
    function o(s, c) {
      --s._eventsCount === 0 ? s._events = new n() : delete s._events[c];
    }
    function u() {
      this._events = new n(), this._eventsCount = 0;
    }
    u.prototype.eventNames = function() {
      var c = [], f, l;
      if (this._eventsCount === 0) return c;
      for (l in f = this._events)
        t.call(f, l) && c.push(r ? l.slice(1) : l);
      return Object.getOwnPropertySymbols ? c.concat(Object.getOwnPropertySymbols(f)) : c;
    }, u.prototype.listeners = function(c) {
      var f = r ? r + c : c, l = this._events[f];
      if (!l) return [];
      if (l.fn) return [l.fn];
      for (var d = 0, p = l.length, y = new Array(p); d < p; d++)
        y[d] = l[d].fn;
      return y;
    }, u.prototype.listenerCount = function(c) {
      var f = r ? r + c : c, l = this._events[f];
      return l ? l.fn ? 1 : l.length : 0;
    }, u.prototype.emit = function(c, f, l, d, p, y) {
      var v = r ? r + c : c;
      if (!this._events[v]) return !1;
      var h = this._events[v], w = arguments.length, b, x;
      if (h.fn) {
        switch (h.once && this.removeListener(c, h.fn, void 0, !0), w) {
          case 1:
            return h.fn.call(h.context), !0;
          case 2:
            return h.fn.call(h.context, f), !0;
          case 3:
            return h.fn.call(h.context, f, l), !0;
          case 4:
            return h.fn.call(h.context, f, l, d), !0;
          case 5:
            return h.fn.call(h.context, f, l, d, p), !0;
          case 6:
            return h.fn.call(h.context, f, l, d, p, y), !0;
        }
        for (x = 1, b = new Array(w - 1); x < w; x++)
          b[x - 1] = arguments[x];
        h.fn.apply(h.context, b);
      } else {
        var O = h.length, m;
        for (x = 0; x < O; x++)
          switch (h[x].once && this.removeListener(c, h[x].fn, void 0, !0), w) {
            case 1:
              h[x].fn.call(h[x].context);
              break;
            case 2:
              h[x].fn.call(h[x].context, f);
              break;
            case 3:
              h[x].fn.call(h[x].context, f, l);
              break;
            case 4:
              h[x].fn.call(h[x].context, f, l, d);
              break;
            default:
              if (!b) for (m = 1, b = new Array(w - 1); m < w; m++)
                b[m - 1] = arguments[m];
              h[x].fn.apply(h[x].context, b);
          }
      }
      return !0;
    }, u.prototype.on = function(c, f, l) {
      return a(this, c, f, l, !1);
    }, u.prototype.once = function(c, f, l) {
      return a(this, c, f, l, !0);
    }, u.prototype.removeListener = function(c, f, l, d) {
      var p = r ? r + c : c;
      if (!this._events[p]) return this;
      if (!f)
        return o(this, p), this;
      var y = this._events[p];
      if (y.fn)
        y.fn === f && (!d || y.once) && (!l || y.context === l) && o(this, p);
      else {
        for (var v = 0, h = [], w = y.length; v < w; v++)
          (y[v].fn !== f || d && !y[v].once || l && y[v].context !== l) && h.push(y[v]);
        h.length ? this._events[p] = h.length === 1 ? h[0] : h : o(this, p);
      }
      return this;
    }, u.prototype.removeAllListeners = function(c) {
      var f;
      return c ? (f = r ? r + c : c, this._events[f] && o(this, f)) : (this._events = new n(), this._eventsCount = 0), this;
    }, u.prototype.off = u.prototype.removeListener, u.prototype.addListener = u.prototype.on, u.prefixed = r, u.EventEmitter = u, e.exports = u;
  }(Fc)), Fc.exports;
}
var gD = mD();
const bD = /* @__PURE__ */ ce(gD);
var zc = new bD(), Uc = "recharts.syncMouseEvents";
function Vn(e) {
  "@babel/helpers - typeof";
  return Vn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Vn(e);
}
function xD(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function wD(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, tw(n.key), n);
  }
}
function OD(e, t, r) {
  return t && wD(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function Wc(e, t, r) {
  return t = tw(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function tw(e) {
  var t = _D(e, "string");
  return Vn(t) == "symbol" ? t : t + "";
}
function _D(e, t) {
  if (Vn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Vn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return String(e);
}
var SD = /* @__PURE__ */ function() {
  function e() {
    xD(this, e), Wc(this, "activeIndex", 0), Wc(this, "coordinateList", []), Wc(this, "layout", "horizontal");
  }
  return OD(e, [{
    key: "setDetails",
    value: function(r) {
      var n, i = r.coordinateList, a = i === void 0 ? null : i, o = r.container, u = o === void 0 ? null : o, s = r.layout, c = s === void 0 ? null : s, f = r.offset, l = f === void 0 ? null : f, d = r.mouseHandlerCallback, p = d === void 0 ? null : d;
      this.coordinateList = (n = a ?? this.coordinateList) !== null && n !== void 0 ? n : [], this.container = u ?? this.container, this.layout = c ?? this.layout, this.offset = l ?? this.offset, this.mouseHandlerCallback = p ?? this.mouseHandlerCallback, this.activeIndex = Math.min(Math.max(this.activeIndex, 0), this.coordinateList.length - 1);
    }
  }, {
    key: "focus",
    value: function() {
      this.spoofMouse();
    }
  }, {
    key: "keyboardEvent",
    value: function(r) {
      if (this.coordinateList.length !== 0)
        switch (r.key) {
          case "ArrowRight": {
            if (this.layout !== "horizontal")
              return;
            this.activeIndex = Math.min(this.activeIndex + 1, this.coordinateList.length - 1), this.spoofMouse();
            break;
          }
          case "ArrowLeft": {
            if (this.layout !== "horizontal")
              return;
            this.activeIndex = Math.max(this.activeIndex - 1, 0), this.spoofMouse();
            break;
          }
        }
    }
  }, {
    key: "setIndex",
    value: function(r) {
      this.activeIndex = r;
    }
  }, {
    key: "spoofMouse",
    value: function() {
      var r, n;
      if (this.layout === "horizontal" && this.coordinateList.length !== 0) {
        var i = this.container.getBoundingClientRect(), a = i.x, o = i.y, u = i.height, s = this.coordinateList[this.activeIndex].coordinate, c = ((r = window) === null || r === void 0 ? void 0 : r.scrollX) || 0, f = ((n = window) === null || n === void 0 ? void 0 : n.scrollY) || 0, l = a + s + c, d = o + this.offset.top + u / 2 + f;
        this.mouseHandlerCallback({
          pageX: l,
          pageY: d
        });
      }
    }
  }]);
}();
function AD(e, t, r) {
  if (r === "number" && t === !0 && Array.isArray(e)) {
    var n = e == null ? void 0 : e[0], i = e == null ? void 0 : e[1];
    if (n && i && q(n) && q(i))
      return !0;
  }
  return !1;
}
function PD(e, t, r, n) {
  var i = n / 2;
  return {
    stroke: "none",
    fill: "#ccc",
    x: e === "horizontal" ? t.x - i : r.left + 0.5,
    y: e === "horizontal" ? r.top + 0.5 : t.y - i,
    width: e === "horizontal" ? n : r.width - 1,
    height: e === "horizontal" ? r.height - 1 : n
  };
}
function rw(e) {
  var t = e.cx, r = e.cy, n = e.radius, i = e.startAngle, a = e.endAngle, o = je(t, r, n, i), u = je(t, r, n, a);
  return {
    points: [o, u],
    cx: t,
    cy: r,
    radius: n,
    startAngle: i,
    endAngle: a
  };
}
function TD(e, t, r) {
  var n, i, a, o;
  if (e === "horizontal")
    n = t.x, a = n, i = r.top, o = r.top + r.height;
  else if (e === "vertical")
    i = t.y, o = i, n = r.left, a = r.left + r.width;
  else if (t.cx != null && t.cy != null)
    if (e === "centric") {
      var u = t.cx, s = t.cy, c = t.innerRadius, f = t.outerRadius, l = t.angle, d = je(u, s, c, l), p = je(u, s, f, l);
      n = d.x, i = d.y, a = p.x, o = p.y;
    } else
      return rw(t);
  return [{
    x: n,
    y: i
  }, {
    x: a,
    y: o
  }];
}
function Xn(e) {
  "@babel/helpers - typeof";
  return Xn = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Xn(e);
}
function Kg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function hi(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Kg(Object(r), !0).forEach(function(n) {
      jD(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Kg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function jD(e, t, r) {
  return t = ED(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function ED(e) {
  var t = MD(e, "string");
  return Xn(t) == "symbol" ? t : t + "";
}
function MD(e, t) {
  if (Xn(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Xn(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function CD(e) {
  var t, r, n = e.element, i = e.tooltipEventType, a = e.isActive, o = e.activeCoordinate, u = e.activePayload, s = e.offset, c = e.activeTooltipIndex, f = e.tooltipAxisBandSize, l = e.layout, d = e.chartName, p = (t = n.props.cursor) !== null && t !== void 0 ? t : (r = n.type.defaultProps) === null || r === void 0 ? void 0 : r.cursor;
  if (!n || !p || !a || !o || d !== "ScatterChart" && i !== "axis")
    return null;
  var y, v = dn;
  if (d === "ScatterChart")
    y = o, v = II;
  else if (d === "BarChart")
    y = PD(l, o, s, f), v = cd;
  else if (l === "radial") {
    var h = rw(o), w = h.cx, b = h.cy, x = h.radius, O = h.startAngle, m = h.endAngle;
    y = {
      cx: w,
      cy: b,
      startAngle: O,
      endAngle: m,
      innerRadius: x,
      outerRadius: x
    }, v = cx;
  } else
    y = {
      points: TD(l, o, s)
    }, v = dn;
  var g = hi(hi(hi(hi({
    stroke: "#ccc",
    pointerEvents: "none"
  }, s), y), J(p, !1)), {}, {
    payload: u,
    payloadIndex: c,
    className: re("recharts-tooltip-cursor", p.className)
  });
  return /* @__PURE__ */ D.isValidElement(p) ? /* @__PURE__ */ D.cloneElement(p, g) : /* @__PURE__ */ D.createElement(v, g);
}
var ID = ["item"], $D = ["children", "className", "width", "height", "style", "compact", "title", "desc"];
function Rr(e) {
  "@babel/helpers - typeof";
  return Rr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, Rr(e);
}
function lr() {
  return lr = Object.assign ? Object.assign.bind() : function(e) {
    for (var t = 1; t < arguments.length; t++) {
      var r = arguments[t];
      for (var n in r)
        Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
  }, lr.apply(this, arguments);
}
function Gg(e, t) {
  return DD(e) || kD(e, t) || iw(e, t) || ND();
}
function ND() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function kD(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, i, a, o, u = [], s = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(s = (n = a.call(r)).done) && (u.push(n.value), u.length !== t); s = !0) ;
    } catch (f) {
      c = !0, i = f;
    } finally {
      try {
        if (!s && r.return != null && (o = r.return(), Object(o) !== o)) return;
      } finally {
        if (c) throw i;
      }
    }
    return u;
  }
}
function DD(e) {
  if (Array.isArray(e)) return e;
}
function Vg(e, t) {
  if (e == null) return {};
  var r = RD(e, t), n, i;
  if (Object.getOwnPropertySymbols) {
    var a = Object.getOwnPropertySymbols(e);
    for (i = 0; i < a.length; i++)
      n = a[i], !(t.indexOf(n) >= 0) && Object.prototype.propertyIsEnumerable.call(e, n) && (r[n] = e[n]);
  }
  return r;
}
function RD(e, t) {
  if (e == null) return {};
  var r = {};
  for (var n in e)
    if (Object.prototype.hasOwnProperty.call(e, n)) {
      if (t.indexOf(n) >= 0) continue;
      r[n] = e[n];
    }
  return r;
}
function LD(e, t) {
  if (!(e instanceof t))
    throw new TypeError("Cannot call a class as a function");
}
function qD(e, t) {
  for (var r = 0; r < t.length; r++) {
    var n = t[r];
    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, aw(n.key), n);
  }
}
function BD(e, t, r) {
  return t && qD(e.prototype, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
}
function FD(e, t, r) {
  return t = sa(t), zD(e, nw() ? Reflect.construct(t, r || [], sa(e).constructor) : t.apply(e, r));
}
function zD(e, t) {
  if (t && (Rr(t) === "object" || typeof t == "function"))
    return t;
  if (t !== void 0)
    throw new TypeError("Derived constructors may only return object or undefined");
  return UD(e);
}
function UD(e) {
  if (e === void 0)
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function nw() {
  try {
    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    }));
  } catch {
  }
  return (nw = function() {
    return !!e;
  })();
}
function sa(e) {
  return sa = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(r) {
    return r.__proto__ || Object.getPrototypeOf(r);
  }, sa(e);
}
function WD(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Super expression must either be null or a function");
  e.prototype = Object.create(t && t.prototype, { constructor: { value: e, writable: !0, configurable: !0 } }), Object.defineProperty(e, "prototype", { writable: !1 }), t && df(e, t);
}
function df(e, t) {
  return df = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, i) {
    return n.__proto__ = i, n;
  }, df(e, t);
}
function Lr(e) {
  return GD(e) || KD(e) || iw(e) || HD();
}
function HD() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function iw(e, t) {
  if (e) {
    if (typeof e == "string") return hf(e, t);
    var r = Object.prototype.toString.call(e).slice(8, -1);
    if (r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set") return Array.from(e);
    if (r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return hf(e, t);
  }
}
function KD(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function GD(e) {
  if (Array.isArray(e)) return hf(e);
}
function hf(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function Xg(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(i) {
      return Object.getOwnPropertyDescriptor(e, i).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function k(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Xg(Object(r), !0).forEach(function(n) {
      G(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Xg(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function G(e, t, r) {
  return t = aw(t), t in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function aw(e) {
  var t = VD(e, "string");
  return Rr(t) == "symbol" ? t : t + "";
}
function VD(e, t) {
  if (Rr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (Rr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var XD = {
  xAxis: ["bottom", "top"],
  yAxis: ["left", "right"]
}, YD = {
  width: "100%",
  height: "100%"
}, ow = {
  x: 0,
  y: 0
};
function pi(e) {
  return e;
}
var ZD = function(t, r) {
  return r === "horizontal" ? t.x : r === "vertical" ? t.y : r === "centric" ? t.angle : t.radius;
}, QD = function(t, r, n, i) {
  var a = r.find(function(f) {
    return f && f.index === n;
  });
  if (a) {
    if (t === "horizontal")
      return {
        x: a.coordinate,
        y: i.y
      };
    if (t === "vertical")
      return {
        x: i.x,
        y: a.coordinate
      };
    if (t === "centric") {
      var o = a.coordinate, u = i.radius;
      return k(k(k({}, i), je(i.cx, i.cy, u, o)), {}, {
        angle: o,
        radius: u
      });
    }
    var s = a.coordinate, c = i.angle;
    return k(k(k({}, i), je(i.cx, i.cy, s, c)), {}, {
      angle: c,
      radius: s
    });
  }
  return ow;
}, Wa = function(t, r) {
  var n = r.graphicalItems, i = r.dataStartIndex, a = r.dataEndIndex, o = (n ?? []).reduce(function(u, s) {
    var c = s.props.data;
    return c && c.length ? [].concat(Lr(u), Lr(c)) : u;
  }, []);
  return o.length > 0 ? o : t && t.length && q(i) && q(a) ? t.slice(i, a + 1) : [];
};
function uw(e) {
  return e === "number" ? [0, "auto"] : void 0;
}
var pf = function(t, r, n, i) {
  var a = t.graphicalItems, o = t.tooltipAxis, u = Wa(r, t);
  return n < 0 || !a || !a.length || n >= u.length ? null : a.reduce(function(s, c) {
    var f, l = (f = c.props.data) !== null && f !== void 0 ? f : r;
    l && t.dataStartIndex + t.dataEndIndex !== 0 && // https://github.com/recharts/recharts/issues/4717
    // The data is sliced only when the active index is within the start/end index range.
    t.dataEndIndex - t.dataStartIndex >= n && (l = l.slice(t.dataStartIndex, t.dataEndIndex + 1));
    var d;
    if (o.dataKey && !o.allowDuplicatedCategory) {
      var p = l === void 0 ? u : l;
      d = vi(p, o.dataKey, i);
    } else
      d = l && l[n] || u[n];
    return d ? [].concat(Lr(s), [ox(c, d)]) : s;
  }, []);
}, Yg = function(t, r, n, i) {
  var a = i || {
    x: t.chartX,
    y: t.chartY
  }, o = ZD(a, n), u = t.orderedTooltipTicks, s = t.tooltipAxis, c = t.tooltipTicks, f = YE(o, u, c, s);
  if (f >= 0 && c) {
    var l = c[f] && c[f].value, d = pf(t, r, f, l), p = QD(n, u, f, a);
    return {
      activeTooltipIndex: f,
      activeLabel: l,
      activePayload: d,
      activeCoordinate: p
    };
  }
  return null;
}, JD = function(t, r) {
  var n = r.axes, i = r.graphicalItems, a = r.axisType, o = r.axisIdKey, u = r.stackGroups, s = r.dataStartIndex, c = r.dataEndIndex, f = t.layout, l = t.children, d = t.stackOffset, p = nx(f, a);
  return n.reduce(function(y, v) {
    var h, w = v.type.defaultProps !== void 0 ? k(k({}, v.type.defaultProps), v.props) : v.props, b = w.type, x = w.dataKey, O = w.allowDataOverflow, m = w.allowDuplicatedCategory, g = w.scale, _ = w.ticks, A = w.includeHidden, P = w[o];
    if (y[P])
      return y;
    var $ = Wa(t.data, {
      graphicalItems: i.filter(function(W) {
        var X, le = o in W.props ? W.props[o] : (X = W.type.defaultProps) === null || X === void 0 ? void 0 : X[o];
        return le === P;
      }),
      dataStartIndex: s,
      dataEndIndex: c
    }), M = $.length, j, E, C;
    AD(w.domain, O, b) && (j = Il(w.domain, null, O), p && (b === "number" || g !== "auto") && (C = fn($, x, "category")));
    var I = uw(b);
    if (!j || j.length === 0) {
      var N, R = (N = w.domain) !== null && N !== void 0 ? N : I;
      if (x) {
        if (j = fn($, x, b), b === "category" && p) {
          var B = l1(j);
          m && B ? (E = j, j = Xi(0, M)) : m || (j = ym(R, j, v).reduce(function(W, X) {
            return W.indexOf(X) >= 0 ? W : [].concat(Lr(W), [X]);
          }, []));
        } else if (b === "category")
          m ? j = j.filter(function(W) {
            return W !== "" && !ee(W);
          }) : j = ym(R, j, v).reduce(function(W, X) {
            return W.indexOf(X) >= 0 || X === "" || ee(X) ? W : [].concat(Lr(W), [X]);
          }, []);
        else if (b === "number") {
          var F = tM($, i.filter(function(W) {
            var X, le, ye = o in W.props ? W.props[o] : (X = W.type.defaultProps) === null || X === void 0 ? void 0 : X[o], De = "hide" in W.props ? W.props.hide : (le = W.type.defaultProps) === null || le === void 0 ? void 0 : le.hide;
            return ye === P && (A || !De);
          }), x, a, f);
          F && (j = F);
        }
        p && (b === "number" || g !== "auto") && (C = fn($, x, "category"));
      } else p ? j = Xi(0, M) : u && u[P] && u[P].hasStack && b === "number" ? j = d === "expand" ? [0, 1] : ax(u[P].stackGroups, s, c) : j = rx($, i.filter(function(W) {
        var X = o in W.props ? W.props[o] : W.type.defaultProps[o], le = "hide" in W.props ? W.props.hide : W.type.defaultProps.hide;
        return X === P && (A || !le);
      }), b, f, !0);
      if (b === "number")
        j = ff(l, j, P, a, _), R && (j = Il(R, j, O));
      else if (b === "category" && R) {
        var K = R, V = j.every(function(W) {
          return K.indexOf(W) >= 0;
        });
        V && (j = K);
      }
    }
    return k(k({}, y), {}, G({}, P, k(k({}, w), {}, {
      axisType: a,
      domain: j,
      categoricalDomain: C,
      duplicateDomain: E,
      originalDomain: (h = w.domain) !== null && h !== void 0 ? h : I,
      isCategorical: p,
      layout: f
    })));
  }, {});
}, eR = function(t, r) {
  var n = r.graphicalItems, i = r.Axis, a = r.axisType, o = r.axisIdKey, u = r.stackGroups, s = r.dataStartIndex, c = r.dataEndIndex, f = t.layout, l = t.children, d = Wa(t.data, {
    graphicalItems: n,
    dataStartIndex: s,
    dataEndIndex: c
  }), p = d.length, y = nx(f, a), v = -1;
  return n.reduce(function(h, w) {
    var b = w.type.defaultProps !== void 0 ? k(k({}, w.type.defaultProps), w.props) : w.props, x = b[o], O = uw("number");
    if (!h[x]) {
      v++;
      var m;
      return y ? m = Xi(0, p) : u && u[x] && u[x].hasStack ? (m = ax(u[x].stackGroups, s, c), m = ff(l, m, x, a)) : (m = Il(O, rx(d, n.filter(function(g) {
        var _, A, P = o in g.props ? g.props[o] : (_ = g.type.defaultProps) === null || _ === void 0 ? void 0 : _[o], $ = "hide" in g.props ? g.props.hide : (A = g.type.defaultProps) === null || A === void 0 ? void 0 : A.hide;
        return P === x && !$;
      }), "number", f), i.defaultProps.allowDataOverflow), m = ff(l, m, x, a)), k(k({}, h), {}, G({}, x, k(k({
        axisType: a
      }, i.defaultProps), {}, {
        hide: !0,
        orientation: Ge(XD, "".concat(a, ".").concat(v % 2), null),
        domain: m,
        originalDomain: O,
        isCategorical: y,
        layout: f
        // specify scale when no Axis
        // scale: isCategorical ? 'band' : 'linear',
      })));
    }
    return h;
  }, {});
}, tR = function(t, r) {
  var n = r.axisType, i = n === void 0 ? "xAxis" : n, a = r.AxisComp, o = r.graphicalItems, u = r.stackGroups, s = r.dataStartIndex, c = r.dataEndIndex, f = t.children, l = "".concat(i, "Id"), d = Je(f, a), p = {};
  return d && d.length ? p = JD(t, {
    axes: d,
    graphicalItems: o,
    axisType: i,
    axisIdKey: l,
    stackGroups: u,
    dataStartIndex: s,
    dataEndIndex: c
  }) : o && o.length && (p = eR(t, {
    Axis: a,
    graphicalItems: o,
    axisType: i,
    axisIdKey: l,
    stackGroups: u,
    dataStartIndex: s,
    dataEndIndex: c
  })), p;
}, rR = function(t) {
  var r = Pt(t), n = ft(r, !1, !0);
  return {
    tooltipTicks: n,
    orderedTooltipTicks: qf(n, function(i) {
      return i.coordinate;
    }),
    tooltipAxis: r,
    tooltipAxisBandSize: Bi(r, n)
  };
}, Zg = function(t) {
  var r = t.children, n = t.defaultShowTooltip, i = Le(r, jr), a = 0, o = 0;
  return t.data && t.data.length !== 0 && (o = t.data.length - 1), i && i.props && (i.props.startIndex >= 0 && (a = i.props.startIndex), i.props.endIndex >= 0 && (o = i.props.endIndex)), {
    chartX: 0,
    chartY: 0,
    dataStartIndex: a,
    dataEndIndex: o,
    activeTooltipIndex: -1,
    isTooltipActive: !!n
  };
}, nR = function(t) {
  return !t || !t.length ? !1 : t.some(function(r) {
    var n = dt(r && r.type);
    return n && n.indexOf("Bar") >= 0;
  });
}, Qg = function(t) {
  return t === "horizontal" ? {
    numericAxisName: "yAxis",
    cateAxisName: "xAxis"
  } : t === "vertical" ? {
    numericAxisName: "xAxis",
    cateAxisName: "yAxis"
  } : t === "centric" ? {
    numericAxisName: "radiusAxis",
    cateAxisName: "angleAxis"
  } : {
    numericAxisName: "angleAxis",
    cateAxisName: "radiusAxis"
  };
}, iR = function(t, r) {
  var n = t.props, i = t.graphicalItems, a = t.xAxisMap, o = a === void 0 ? {} : a, u = t.yAxisMap, s = u === void 0 ? {} : u, c = n.width, f = n.height, l = n.children, d = n.margin || {}, p = Le(l, jr), y = Le(l, dr), v = Object.keys(s).reduce(function(m, g) {
    var _ = s[g], A = _.orientation;
    return !_.mirror && !_.hide ? k(k({}, m), {}, G({}, A, m[A] + _.width)) : m;
  }, {
    left: d.left || 0,
    right: d.right || 0
  }), h = Object.keys(o).reduce(function(m, g) {
    var _ = o[g], A = _.orientation;
    return !_.mirror && !_.hide ? k(k({}, m), {}, G({}, A, Ge(m, "".concat(A)) + _.height)) : m;
  }, {
    top: d.top || 0,
    bottom: d.bottom || 0
  }), w = k(k({}, h), v), b = w.bottom;
  p && (w.bottom += p.props.height || jr.defaultProps.height), y && r && (w = JE(w, i, n, r));
  var x = c - w.left - w.right, O = f - w.top - w.bottom;
  return k(k({
    brushBottom: b
  }, w), {}, {
    // never return negative values for height and width
    width: Math.max(x, 0),
    height: Math.max(O, 0)
  });
}, aR = function(t, r) {
  if (r === "xAxis")
    return t[r].width;
  if (r === "yAxis")
    return t[r].height;
}, oR = function(t) {
  var r = t.chartName, n = t.GraphicalChild, i = t.defaultTooltipEventType, a = i === void 0 ? "axis" : i, o = t.validateTooltipEventTypes, u = o === void 0 ? ["axis"] : o, s = t.axisComponents, c = t.legendContent, f = t.formatAxisMap, l = t.defaultProps, d = function(w, b) {
    var x = b.graphicalItems, O = b.stackGroups, m = b.offset, g = b.updateId, _ = b.dataStartIndex, A = b.dataEndIndex, P = w.barSize, $ = w.layout, M = w.barGap, j = w.barCategoryGap, E = w.maxBarSize, C = Qg($), I = C.numericAxisName, N = C.cateAxisName, R = nR(x), B = [];
    return x.forEach(function(F, K) {
      var V = Wa(w.data, {
        graphicalItems: [F],
        dataStartIndex: _,
        dataEndIndex: A
      }), W = F.type.defaultProps !== void 0 ? k(k({}, F.type.defaultProps), F.props) : F.props, X = W.dataKey, le = W.maxBarSize, ye = W["".concat(I, "Id")], De = W["".concat(N, "Id")], Dt = {}, $e = s.reduce(function(Rt, Lt) {
        var Ha = b["".concat(Lt.axisType, "Map")], xd = W["".concat(Lt.axisType, "Id")];
        Ha && Ha[xd] || Lt.axisType === "zAxis" || Yt();
        var wd = Ha[xd];
        return k(k({}, Rt), {}, G(G({}, Lt.axisType, wd), "".concat(Lt.axisType, "Ticks"), ft(wd)));
      }, Dt), z = $e[N], Y = $e["".concat(N, "Ticks")], Q = O && O[ye] && O[ye].hasStack && hM(F, O[ye].stackGroups), L = dt(F.type).indexOf("Bar") >= 0, pe = Bi(z, Y), te = [], be = R && ZE({
        barSize: P,
        stackGroups: O,
        totalSize: aR($e, N)
      });
      if (L) {
        var xe, Ne, _t = ee(le) ? E : le, tr = (xe = (Ne = Bi(z, Y, !0)) !== null && Ne !== void 0 ? Ne : _t) !== null && xe !== void 0 ? xe : 0;
        te = QE({
          barGap: M,
          barCategoryGap: j,
          bandSize: tr !== pe ? tr : pe,
          sizeList: be[De],
          maxBarSize: _t
        }), tr !== pe && (te = te.map(function(Rt) {
          return k(k({}, Rt), {}, {
            position: k(k({}, Rt.position), {}, {
              offset: Rt.position.offset - tr / 2
            })
          });
        }));
      }
      var ni = F && F.type && F.type.getComposedData;
      ni && B.push({
        props: k(k({}, ni(k(k({}, $e), {}, {
          displayedData: V,
          props: w,
          dataKey: X,
          item: F,
          bandSize: pe,
          barPosition: te,
          offset: m,
          stackedData: Q,
          layout: $,
          dataStartIndex: _,
          dataEndIndex: A
        }))), {}, G(G(G({
          key: F.key || "item-".concat(K)
        }, I, $e[I]), N, $e[N]), "animationId", g)),
        childIndex: _1(F, w.children),
        item: F
      });
    }), B;
  }, p = function(w, b) {
    var x = w.props, O = w.dataStartIndex, m = w.dataEndIndex, g = w.updateId;
    if (!qh({
      props: x
    }))
      return null;
    var _ = x.children, A = x.layout, P = x.stackOffset, $ = x.data, M = x.reverseStackOrder, j = Qg(A), E = j.numericAxisName, C = j.cateAxisName, I = Je(_, n), N = lM($, I, "".concat(E, "Id"), "".concat(C, "Id"), P, M), R = s.reduce(function(W, X) {
      var le = "".concat(X.axisType, "Map");
      return k(k({}, W), {}, G({}, le, tR(x, k(k({}, X), {}, {
        graphicalItems: I,
        stackGroups: X.axisType === E && N,
        dataStartIndex: O,
        dataEndIndex: m
      }))));
    }, {}), B = iR(k(k({}, R), {}, {
      props: x,
      graphicalItems: I
    }), b == null ? void 0 : b.legendBBox);
    Object.keys(R).forEach(function(W) {
      R[W] = f(x, R[W], B, W.replace("Map", ""), r);
    });
    var F = R["".concat(C, "Map")], K = rR(F), V = d(x, k(k({}, R), {}, {
      dataStartIndex: O,
      dataEndIndex: m,
      updateId: g,
      graphicalItems: I,
      stackGroups: N,
      offset: B
    }));
    return k(k({
      formattedGraphicalItems: V,
      graphicalItems: I,
      offset: B,
      stackGroups: N
    }, K), R);
  }, y = /* @__PURE__ */ function(h) {
    function w(b) {
      var x, O, m;
      return LD(this, w), m = FD(this, w, [b]), G(m, "eventEmitterSymbol", Symbol("rechartsEventEmitter")), G(m, "accessibilityManager", new SD()), G(m, "handleLegendBBoxUpdate", function(g) {
        if (g) {
          var _ = m.state, A = _.dataStartIndex, P = _.dataEndIndex, $ = _.updateId;
          m.setState(k({
            legendBBox: g
          }, p({
            props: m.props,
            dataStartIndex: A,
            dataEndIndex: P,
            updateId: $
          }, k(k({}, m.state), {}, {
            legendBBox: g
          }))));
        }
      }), G(m, "handleReceiveSyncEvent", function(g, _, A) {
        if (m.props.syncId === g) {
          if (A === m.eventEmitterSymbol && typeof m.props.syncMethod != "function")
            return;
          m.applySyncEvent(_);
        }
      }), G(m, "handleBrushChange", function(g) {
        var _ = g.startIndex, A = g.endIndex;
        if (_ !== m.state.dataStartIndex || A !== m.state.dataEndIndex) {
          var P = m.state.updateId;
          m.setState(function() {
            return k({
              dataStartIndex: _,
              dataEndIndex: A
            }, p({
              props: m.props,
              dataStartIndex: _,
              dataEndIndex: A,
              updateId: P
            }, m.state));
          }), m.triggerSyncEvent({
            dataStartIndex: _,
            dataEndIndex: A
          });
        }
      }), G(m, "handleMouseEnter", function(g) {
        var _ = m.getMouseInfo(g);
        if (_) {
          var A = k(k({}, _), {}, {
            isTooltipActive: !0
          });
          m.setState(A), m.triggerSyncEvent(A);
          var P = m.props.onMouseEnter;
          Z(P) && P(A, g);
        }
      }), G(m, "triggeredAfterMouseMove", function(g) {
        var _ = m.getMouseInfo(g), A = _ ? k(k({}, _), {}, {
          isTooltipActive: !0
        }) : {
          isTooltipActive: !1
        };
        m.setState(A), m.triggerSyncEvent(A);
        var P = m.props.onMouseMove;
        Z(P) && P(A, g);
      }), G(m, "handleItemMouseEnter", function(g) {
        m.setState(function() {
          return {
            isTooltipActive: !0,
            activeItem: g,
            activePayload: g.tooltipPayload,
            activeCoordinate: g.tooltipPosition || {
              x: g.cx,
              y: g.cy
            }
          };
        });
      }), G(m, "handleItemMouseLeave", function() {
        m.setState(function() {
          return {
            isTooltipActive: !1
          };
        });
      }), G(m, "handleMouseMove", function(g) {
        g.persist(), m.throttleTriggeredAfterMouseMove(g);
      }), G(m, "handleMouseLeave", function(g) {
        m.throttleTriggeredAfterMouseMove.cancel();
        var _ = {
          isTooltipActive: !1
        };
        m.setState(_), m.triggerSyncEvent(_);
        var A = m.props.onMouseLeave;
        Z(A) && A(_, g);
      }), G(m, "handleOuterEvent", function(g) {
        var _ = O1(g), A = Ge(m.props, "".concat(_));
        if (_ && Z(A)) {
          var P, $;
          /.*touch.*/i.test(_) ? $ = m.getMouseInfo(g.changedTouches[0]) : $ = m.getMouseInfo(g), A((P = $) !== null && P !== void 0 ? P : {}, g);
        }
      }), G(m, "handleClick", function(g) {
        var _ = m.getMouseInfo(g);
        if (_) {
          var A = k(k({}, _), {}, {
            isTooltipActive: !0
          });
          m.setState(A), m.triggerSyncEvent(A);
          var P = m.props.onClick;
          Z(P) && P(A, g);
        }
      }), G(m, "handleMouseDown", function(g) {
        var _ = m.props.onMouseDown;
        if (Z(_)) {
          var A = m.getMouseInfo(g);
          _(A, g);
        }
      }), G(m, "handleMouseUp", function(g) {
        var _ = m.props.onMouseUp;
        if (Z(_)) {
          var A = m.getMouseInfo(g);
          _(A, g);
        }
      }), G(m, "handleTouchMove", function(g) {
        g.changedTouches != null && g.changedTouches.length > 0 && m.throttleTriggeredAfterMouseMove(g.changedTouches[0]);
      }), G(m, "handleTouchStart", function(g) {
        g.changedTouches != null && g.changedTouches.length > 0 && m.handleMouseDown(g.changedTouches[0]);
      }), G(m, "handleTouchEnd", function(g) {
        g.changedTouches != null && g.changedTouches.length > 0 && m.handleMouseUp(g.changedTouches[0]);
      }), G(m, "handleDoubleClick", function(g) {
        var _ = m.props.onDoubleClick;
        if (Z(_)) {
          var A = m.getMouseInfo(g);
          _(A, g);
        }
      }), G(m, "handleContextMenu", function(g) {
        var _ = m.props.onContextMenu;
        if (Z(_)) {
          var A = m.getMouseInfo(g);
          _(A, g);
        }
      }), G(m, "triggerSyncEvent", function(g) {
        m.props.syncId !== void 0 && zc.emit(Uc, m.props.syncId, g, m.eventEmitterSymbol);
      }), G(m, "applySyncEvent", function(g) {
        var _ = m.props, A = _.layout, P = _.syncMethod, $ = m.state.updateId, M = g.dataStartIndex, j = g.dataEndIndex;
        if (g.dataStartIndex !== void 0 || g.dataEndIndex !== void 0)
          m.setState(k({
            dataStartIndex: M,
            dataEndIndex: j
          }, p({
            props: m.props,
            dataStartIndex: M,
            dataEndIndex: j,
            updateId: $
          }, m.state)));
        else if (g.activeTooltipIndex !== void 0) {
          var E = g.chartX, C = g.chartY, I = g.activeTooltipIndex, N = m.state, R = N.offset, B = N.tooltipTicks;
          if (!R)
            return;
          if (typeof P == "function")
            I = P(B, g);
          else if (P === "value") {
            I = -1;
            for (var F = 0; F < B.length; F++)
              if (B[F].value === g.activeLabel) {
                I = F;
                break;
              }
          }
          var K = k(k({}, R), {}, {
            x: R.left,
            y: R.top
          }), V = Math.min(E, K.x + K.width), W = Math.min(C, K.y + K.height), X = B[I] && B[I].value, le = pf(m.state, m.props.data, I), ye = B[I] ? {
            x: A === "horizontal" ? B[I].coordinate : V,
            y: A === "horizontal" ? W : B[I].coordinate
          } : ow;
          m.setState(k(k({}, g), {}, {
            activeLabel: X,
            activeCoordinate: ye,
            activePayload: le,
            activeTooltipIndex: I
          }));
        } else
          m.setState(g);
      }), G(m, "renderCursor", function(g) {
        var _, A = m.state, P = A.isTooltipActive, $ = A.activeCoordinate, M = A.activePayload, j = A.offset, E = A.activeTooltipIndex, C = A.tooltipAxisBandSize, I = m.getTooltipEventType(), N = (_ = g.props.active) !== null && _ !== void 0 ? _ : P, R = m.props.layout, B = g.key || "_recharts-cursor";
        return /* @__PURE__ */ T.createElement(CD, {
          key: B,
          activeCoordinate: $,
          activePayload: M,
          activeTooltipIndex: E,
          chartName: r,
          element: g,
          isActive: N,
          layout: R,
          offset: j,
          tooltipAxisBandSize: C,
          tooltipEventType: I
        });
      }), G(m, "renderPolarAxis", function(g, _, A) {
        var P = Ge(g, "type.axisType"), $ = Ge(m.state, "".concat(P, "Map")), M = g.type.defaultProps, j = M !== void 0 ? k(k({}, M), g.props) : g.props, E = $ && $[j["".concat(P, "Id")]];
        return /* @__PURE__ */ D.cloneElement(g, k(k({}, E), {}, {
          className: re(P, E.className),
          key: g.key || "".concat(_, "-").concat(A),
          ticks: ft(E, !0)
        }));
      }), G(m, "renderPolarGrid", function(g) {
        var _ = g.props, A = _.radialLines, P = _.polarAngles, $ = _.polarRadius, M = m.state, j = M.radiusAxisMap, E = M.angleAxisMap, C = Pt(j), I = Pt(E), N = I.cx, R = I.cy, B = I.innerRadius, F = I.outerRadius;
        return /* @__PURE__ */ D.cloneElement(g, {
          polarAngles: Array.isArray(P) ? P : ft(I, !0).map(function(K) {
            return K.coordinate;
          }),
          polarRadius: Array.isArray($) ? $ : ft(C, !0).map(function(K) {
            return K.coordinate;
          }),
          cx: N,
          cy: R,
          innerRadius: B,
          outerRadius: F,
          key: g.key || "polar-grid",
          radialLines: A
        });
      }), G(m, "renderLegend", function() {
        var g = m.state.formattedGraphicalItems, _ = m.props, A = _.children, P = _.width, $ = _.height, M = m.props.margin || {}, j = P - (M.left || 0) - (M.right || 0), E = ex({
          children: A,
          formattedGraphicalItems: g,
          legendWidth: j,
          legendContent: c
        });
        if (!E)
          return null;
        var C = E.item, I = Vg(E, ID);
        return /* @__PURE__ */ D.cloneElement(C, k(k({}, I), {}, {
          chartWidth: P,
          chartHeight: $,
          margin: M,
          onBBoxUpdate: m.handleLegendBBoxUpdate
        }));
      }), G(m, "renderTooltip", function() {
        var g, _ = m.props, A = _.children, P = _.accessibilityLayer, $ = Le(A, rt);
        if (!$)
          return null;
        var M = m.state, j = M.isTooltipActive, E = M.activeCoordinate, C = M.activePayload, I = M.activeLabel, N = M.offset, R = (g = $.props.active) !== null && g !== void 0 ? g : j;
        return /* @__PURE__ */ D.cloneElement($, {
          viewBox: k(k({}, N), {}, {
            x: N.left,
            y: N.top
          }),
          active: R,
          label: I,
          payload: R ? C : [],
          coordinate: E,
          accessibilityLayer: P
        });
      }), G(m, "renderBrush", function(g) {
        var _ = m.props, A = _.margin, P = _.data, $ = m.state, M = $.offset, j = $.dataStartIndex, E = $.dataEndIndex, C = $.updateId;
        return /* @__PURE__ */ D.cloneElement(g, {
          key: g.key || "_recharts-brush",
          onChange: li(m.handleBrushChange, g.props.onChange),
          data: P,
          x: q(g.props.x) ? g.props.x : M.left,
          y: q(g.props.y) ? g.props.y : M.top + M.height + M.brushBottom - (A.bottom || 0),
          width: q(g.props.width) ? g.props.width : M.width,
          startIndex: j,
          endIndex: E,
          updateId: "brush-".concat(C)
        });
      }), G(m, "renderReferenceElement", function(g, _, A) {
        if (!g)
          return null;
        var P = m, $ = P.clipPathId, M = m.state, j = M.xAxisMap, E = M.yAxisMap, C = M.offset, I = g.type.defaultProps || {}, N = g.props, R = N.xAxisId, B = R === void 0 ? I.xAxisId : R, F = N.yAxisId, K = F === void 0 ? I.yAxisId : F;
        return /* @__PURE__ */ D.cloneElement(g, {
          key: g.key || "".concat(_, "-").concat(A),
          xAxis: j[B],
          yAxis: E[K],
          viewBox: {
            x: C.left,
            y: C.top,
            width: C.width,
            height: C.height
          },
          clipPathId: $
        });
      }), G(m, "renderActivePoints", function(g) {
        var _ = g.item, A = g.activePoint, P = g.basePoint, $ = g.childIndex, M = g.isRange, j = [], E = _.props.key, C = _.item.type.defaultProps !== void 0 ? k(k({}, _.item.type.defaultProps), _.item.props) : _.item.props, I = C.activeDot, N = C.dataKey, R = k(k({
          index: $,
          dataKey: N,
          cx: A.x,
          cy: A.y,
          r: 4,
          fill: sd(_.item),
          strokeWidth: 2,
          stroke: "#fff",
          payload: A.payload,
          value: A.value
        }, J(I, !1)), yi(I));
        return j.push(w.renderActiveDot(I, R, "".concat(E, "-activePoint-").concat($))), P ? j.push(w.renderActiveDot(I, k(k({}, R), {}, {
          cx: P.x,
          cy: P.y
        }), "".concat(E, "-basePoint-").concat($))) : M && j.push(null), j;
      }), G(m, "renderGraphicChild", function(g, _, A) {
        var P = m.filterFormatItem(g, _, A);
        if (!P)
          return null;
        var $ = m.getTooltipEventType(), M = m.state, j = M.isTooltipActive, E = M.tooltipAxis, C = M.activeTooltipIndex, I = M.activeLabel, N = m.props.children, R = Le(N, rt), B = P.props, F = B.points, K = B.isRange, V = B.baseLine, W = P.item.type.defaultProps !== void 0 ? k(k({}, P.item.type.defaultProps), P.item.props) : P.item.props, X = W.activeDot, le = W.hide, ye = W.activeBar, De = W.activeShape, Dt = !!(!le && j && R && (X || ye || De)), $e = {};
        $ !== "axis" && R && R.props.trigger === "click" ? $e = {
          onClick: li(m.handleItemMouseEnter, g.props.onClick)
        } : $ !== "axis" && ($e = {
          onMouseLeave: li(m.handleItemMouseLeave, g.props.onMouseLeave),
          onMouseEnter: li(m.handleItemMouseEnter, g.props.onMouseEnter)
        });
        var z = /* @__PURE__ */ D.cloneElement(g, k(k({}, P.props), $e));
        function Y(Lt) {
          return typeof E.dataKey == "function" ? E.dataKey(Lt.payload) : null;
        }
        if (Dt)
          if (C >= 0) {
            var Q, L;
            if (E.dataKey && !E.allowDuplicatedCategory) {
              var pe = typeof E.dataKey == "function" ? Y : "payload.".concat(E.dataKey.toString());
              Q = vi(F, pe, I), L = K && V && vi(V, pe, I);
            } else
              Q = F == null ? void 0 : F[C], L = K && V && V[C];
            if (De || ye) {
              var te = g.props.activeIndex !== void 0 ? g.props.activeIndex : C;
              return [/* @__PURE__ */ D.cloneElement(g, k(k(k({}, P.props), $e), {}, {
                activeIndex: te
              })), null, null];
            }
            if (!ee(Q))
              return [z].concat(Lr(m.renderActivePoints({
                item: P,
                activePoint: Q,
                basePoint: L,
                childIndex: C,
                isRange: K
              })));
          } else {
            var be, xe = (be = m.getItemByXY(m.state.activeCoordinate)) !== null && be !== void 0 ? be : {
              graphicalItem: z
            }, Ne = xe.graphicalItem, _t = Ne.item, tr = _t === void 0 ? g : _t, ni = Ne.childIndex, Rt = k(k(k({}, P.props), $e), {}, {
              activeIndex: ni
            });
            return [/* @__PURE__ */ D.cloneElement(tr, Rt), null, null];
          }
        return K ? [z, null, null] : [z, null];
      }), G(m, "renderCustomized", function(g, _, A) {
        return /* @__PURE__ */ D.cloneElement(g, k(k({
          key: "recharts-customized-".concat(A)
        }, m.props), m.state));
      }), G(m, "renderMap", {
        CartesianGrid: {
          handler: pi,
          once: !0
        },
        ReferenceArea: {
          handler: m.renderReferenceElement
        },
        ReferenceLine: {
          handler: pi
        },
        ReferenceDot: {
          handler: m.renderReferenceElement
        },
        XAxis: {
          handler: pi
        },
        YAxis: {
          handler: pi
        },
        Brush: {
          handler: m.renderBrush,
          once: !0
        },
        Bar: {
          handler: m.renderGraphicChild
        },
        Line: {
          handler: m.renderGraphicChild
        },
        Area: {
          handler: m.renderGraphicChild
        },
        Radar: {
          handler: m.renderGraphicChild
        },
        RadialBar: {
          handler: m.renderGraphicChild
        },
        Scatter: {
          handler: m.renderGraphicChild
        },
        Pie: {
          handler: m.renderGraphicChild
        },
        Funnel: {
          handler: m.renderGraphicChild
        },
        Tooltip: {
          handler: m.renderCursor,
          once: !0
        },
        PolarGrid: {
          handler: m.renderPolarGrid,
          once: !0
        },
        PolarAngleAxis: {
          handler: m.renderPolarAxis
        },
        PolarRadiusAxis: {
          handler: m.renderPolarAxis
        },
        Customized: {
          handler: m.renderCustomized
        }
      }), m.clipPathId = "".concat((x = b.id) !== null && x !== void 0 ? x : Zn("recharts"), "-clip"), m.throttleTriggeredAfterMouseMove = n0(m.triggeredAfterMouseMove, (O = b.throttleDelay) !== null && O !== void 0 ? O : 1e3 / 60), m.state = {}, m;
    }
    return WD(w, h), BD(w, [{
      key: "componentDidMount",
      value: function() {
        var x, O;
        this.addListener(), this.accessibilityManager.setDetails({
          container: this.container,
          offset: {
            left: (x = this.props.margin.left) !== null && x !== void 0 ? x : 0,
            top: (O = this.props.margin.top) !== null && O !== void 0 ? O : 0
          },
          coordinateList: this.state.tooltipTicks,
          mouseHandlerCallback: this.triggeredAfterMouseMove,
          layout: this.props.layout
        }), this.displayDefaultTooltip();
      }
    }, {
      key: "displayDefaultTooltip",
      value: function() {
        var x = this.props, O = x.children, m = x.data, g = x.height, _ = x.layout, A = Le(O, rt);
        if (A) {
          var P = A.props.defaultIndex;
          if (!(typeof P != "number" || P < 0 || P > this.state.tooltipTicks.length - 1)) {
            var $ = this.state.tooltipTicks[P] && this.state.tooltipTicks[P].value, M = pf(this.state, m, P, $), j = this.state.tooltipTicks[P].coordinate, E = (this.state.offset.top + g) / 2, C = _ === "horizontal", I = C ? {
              x: j,
              y: E
            } : {
              y: j,
              x: E
            }, N = this.state.formattedGraphicalItems.find(function(B) {
              var F = B.item;
              return F.type.name === "Scatter";
            });
            N && (I = k(k({}, I), N.props.points[P].tooltipPosition), M = N.props.points[P].tooltipPayload);
            var R = {
              activeTooltipIndex: P,
              isTooltipActive: !0,
              activeLabel: $,
              activePayload: M,
              activeCoordinate: I
            };
            this.setState(R), this.renderCursor(A), this.accessibilityManager.setIndex(P);
          }
        }
      }
    }, {
      key: "getSnapshotBeforeUpdate",
      value: function(x, O) {
        if (!this.props.accessibilityLayer)
          return null;
        if (this.state.tooltipTicks !== O.tooltipTicks && this.accessibilityManager.setDetails({
          coordinateList: this.state.tooltipTicks
        }), this.props.layout !== x.layout && this.accessibilityManager.setDetails({
          layout: this.props.layout
        }), this.props.margin !== x.margin) {
          var m, g;
          this.accessibilityManager.setDetails({
            offset: {
              left: (m = this.props.margin.left) !== null && m !== void 0 ? m : 0,
              top: (g = this.props.margin.top) !== null && g !== void 0 ? g : 0
            }
          });
        }
        return null;
      }
    }, {
      key: "componentDidUpdate",
      value: function(x) {
        rl([Le(x.children, rt)], [Le(this.props.children, rt)]) || this.displayDefaultTooltip();
      }
    }, {
      key: "componentWillUnmount",
      value: function() {
        this.removeListener(), this.throttleTriggeredAfterMouseMove.cancel();
      }
    }, {
      key: "getTooltipEventType",
      value: function() {
        var x = Le(this.props.children, rt);
        if (x && typeof x.props.shared == "boolean") {
          var O = x.props.shared ? "axis" : "item";
          return u.indexOf(O) >= 0 ? O : a;
        }
        return a;
      }
      /**
       * Get the information of mouse in chart, return null when the mouse is not in the chart
       * @param  {MousePointer} event    The event object
       * @return {Object}          Mouse data
       */
    }, {
      key: "getMouseInfo",
      value: function(x) {
        if (!this.container)
          return null;
        var O = this.container, m = O.getBoundingClientRect(), g = lP(m), _ = {
          chartX: Math.round(x.pageX - g.left),
          chartY: Math.round(x.pageY - g.top)
        }, A = m.width / O.offsetWidth || 1, P = this.inRange(_.chartX, _.chartY, A);
        if (!P)
          return null;
        var $ = this.state, M = $.xAxisMap, j = $.yAxisMap, E = this.getTooltipEventType(), C = Yg(this.state, this.props.data, this.props.layout, P);
        if (E !== "axis" && M && j) {
          var I = Pt(M).scale, N = Pt(j).scale, R = I && I.invert ? I.invert(_.chartX) : null, B = N && N.invert ? N.invert(_.chartY) : null;
          return k(k({}, _), {}, {
            xValue: R,
            yValue: B
          }, C);
        }
        return C ? k(k({}, _), C) : null;
      }
    }, {
      key: "inRange",
      value: function(x, O) {
        var m = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, g = this.props.layout, _ = x / m, A = O / m;
        if (g === "horizontal" || g === "vertical") {
          var P = this.state.offset, $ = _ >= P.left && _ <= P.left + P.width && A >= P.top && A <= P.top + P.height;
          return $ ? {
            x: _,
            y: A
          } : null;
        }
        var M = this.state, j = M.angleAxisMap, E = M.radiusAxisMap;
        if (j && E) {
          var C = Pt(j);
          return bm({
            x: _,
            y: A
          }, C);
        }
        return null;
      }
    }, {
      key: "parseEventsOfWrapper",
      value: function() {
        var x = this.props.children, O = this.getTooltipEventType(), m = Le(x, rt), g = {};
        m && O === "axis" && (m.props.trigger === "click" ? g = {
          onClick: this.handleClick
        } : g = {
          onMouseEnter: this.handleMouseEnter,
          onDoubleClick: this.handleDoubleClick,
          onMouseMove: this.handleMouseMove,
          onMouseLeave: this.handleMouseLeave,
          onTouchMove: this.handleTouchMove,
          onTouchStart: this.handleTouchStart,
          onTouchEnd: this.handleTouchEnd,
          onContextMenu: this.handleContextMenu
        });
        var _ = yi(this.props, this.handleOuterEvent);
        return k(k({}, _), g);
      }
    }, {
      key: "addListener",
      value: function() {
        zc.on(Uc, this.handleReceiveSyncEvent);
      }
    }, {
      key: "removeListener",
      value: function() {
        zc.removeListener(Uc, this.handleReceiveSyncEvent);
      }
    }, {
      key: "filterFormatItem",
      value: function(x, O, m) {
        for (var g = this.state.formattedGraphicalItems, _ = 0, A = g.length; _ < A; _++) {
          var P = g[_];
          if (P.item === x || P.props.key === x.key || O === dt(P.item.type) && m === P.childIndex)
            return P;
        }
        return null;
      }
    }, {
      key: "renderClipPath",
      value: function() {
        var x = this.clipPathId, O = this.state.offset, m = O.left, g = O.top, _ = O.height, A = O.width;
        return /* @__PURE__ */ T.createElement("defs", null, /* @__PURE__ */ T.createElement("clipPath", {
          id: x
        }, /* @__PURE__ */ T.createElement("rect", {
          x: m,
          y: g,
          height: _,
          width: A
        })));
      }
    }, {
      key: "getXScales",
      value: function() {
        var x = this.state.xAxisMap;
        return x ? Object.entries(x).reduce(function(O, m) {
          var g = Gg(m, 2), _ = g[0], A = g[1];
          return k(k({}, O), {}, G({}, _, A.scale));
        }, {}) : null;
      }
    }, {
      key: "getYScales",
      value: function() {
        var x = this.state.yAxisMap;
        return x ? Object.entries(x).reduce(function(O, m) {
          var g = Gg(m, 2), _ = g[0], A = g[1];
          return k(k({}, O), {}, G({}, _, A.scale));
        }, {}) : null;
      }
    }, {
      key: "getXScaleByAxisId",
      value: function(x) {
        var O;
        return (O = this.state.xAxisMap) === null || O === void 0 || (O = O[x]) === null || O === void 0 ? void 0 : O.scale;
      }
    }, {
      key: "getYScaleByAxisId",
      value: function(x) {
        var O;
        return (O = this.state.yAxisMap) === null || O === void 0 || (O = O[x]) === null || O === void 0 ? void 0 : O.scale;
      }
    }, {
      key: "getItemByXY",
      value: function(x) {
        var O = this.state, m = O.formattedGraphicalItems, g = O.activeItem;
        if (m && m.length)
          for (var _ = 0, A = m.length; _ < A; _++) {
            var P = m[_], $ = P.props, M = P.item, j = M.type.defaultProps !== void 0 ? k(k({}, M.type.defaultProps), M.props) : M.props, E = dt(M.type);
            if (E === "Bar") {
              var C = ($.data || []).find(function(B) {
                return OI(x, B);
              });
              if (C)
                return {
                  graphicalItem: P,
                  payload: C
                };
            } else if (E === "RadialBar") {
              var I = ($.data || []).find(function(B) {
                return bm(x, B);
              });
              if (I)
                return {
                  graphicalItem: P,
                  payload: I
                };
            } else if (ka(P, g) || Da(P, g) || Un(P, g)) {
              var N = d$({
                graphicalItem: P,
                activeTooltipItem: g,
                itemData: j.data
              }), R = j.activeIndex === void 0 ? N : j.activeIndex;
              return {
                graphicalItem: k(k({}, P), {}, {
                  childIndex: R
                }),
                payload: Un(P, g) ? j.data[N] : P.props.data[N]
              };
            }
          }
        return null;
      }
    }, {
      key: "render",
      value: function() {
        var x = this;
        if (!qh(this))
          return null;
        var O = this.props, m = O.children, g = O.className, _ = O.width, A = O.height, P = O.style, $ = O.compact, M = O.title, j = O.desc, E = Vg(O, $D), C = J(E, !1);
        if ($)
          return /* @__PURE__ */ T.createElement(Eg, {
            state: this.state,
            width: this.props.width,
            height: this.props.height,
            clipPathId: this.clipPathId
          }, /* @__PURE__ */ T.createElement(il, lr({}, C, {
            width: _,
            height: A,
            title: M,
            desc: j
          }), this.renderClipPath(), Fh(m, this.renderMap)));
        if (this.props.accessibilityLayer) {
          var I, N;
          C.tabIndex = (I = this.props.tabIndex) !== null && I !== void 0 ? I : 0, C.role = (N = this.props.role) !== null && N !== void 0 ? N : "application", C.onKeyDown = function(B) {
            x.accessibilityManager.keyboardEvent(B);
          }, C.onFocus = function() {
            x.accessibilityManager.focus();
          };
        }
        var R = this.parseEventsOfWrapper();
        return /* @__PURE__ */ T.createElement(Eg, {
          state: this.state,
          width: this.props.width,
          height: this.props.height,
          clipPathId: this.clipPathId
        }, /* @__PURE__ */ T.createElement("div", lr({
          className: re("recharts-wrapper", g),
          style: k({
            position: "relative",
            cursor: "default",
            width: _,
            height: A
          }, P)
        }, R, {
          ref: function(F) {
            x.container = F;
          }
        }), /* @__PURE__ */ T.createElement(il, lr({}, C, {
          width: _,
          height: A,
          title: M,
          desc: j,
          style: YD
        }), this.renderClipPath(), Fh(m, this.renderMap)), this.renderLegend(), this.renderTooltip()));
      }
    }]);
  }(D.Component);
  G(y, "displayName", r), G(y, "defaultProps", k({
    layout: "horizontal",
    stackOffset: "none",
    barCategoryGap: "10%",
    barGap: 4,
    margin: {
      top: 5,
      right: 5,
      bottom: 5,
      left: 5
    },
    reverseStackOrder: !1,
    syncMethod: "index"
  }, l)), G(y, "getDerivedStateFromProps", function(h, w) {
    var b = h.dataKey, x = h.data, O = h.children, m = h.width, g = h.height, _ = h.layout, A = h.stackOffset, P = h.margin, $ = w.dataStartIndex, M = w.dataEndIndex;
    if (w.updateId === void 0) {
      var j = Zg(h);
      return k(k(k({}, j), {}, {
        updateId: 0
      }, p(k(k({
        props: h
      }, j), {}, {
        updateId: 0
      }), w)), {}, {
        prevDataKey: b,
        prevData: x,
        prevWidth: m,
        prevHeight: g,
        prevLayout: _,
        prevStackOffset: A,
        prevMargin: P,
        prevChildren: O
      });
    }
    if (b !== w.prevDataKey || x !== w.prevData || m !== w.prevWidth || g !== w.prevHeight || _ !== w.prevLayout || A !== w.prevStackOffset || !fr(P, w.prevMargin)) {
      var E = Zg(h), C = {
        // (chartX, chartY) are (0,0) in default state, but we want to keep the last mouse position to avoid
        // any flickering
        chartX: w.chartX,
        chartY: w.chartY,
        // The tooltip should stay active when it was active in the previous render. If this is not
        // the case, the tooltip disappears and immediately re-appears, causing a flickering effect
        isTooltipActive: w.isTooltipActive
      }, I = k(k({}, Yg(w, x, _)), {}, {
        updateId: w.updateId + 1
      }), N = k(k(k({}, E), C), I);
      return k(k(k({}, N), p(k({
        props: h
      }, N), w)), {}, {
        prevDataKey: b,
        prevData: x,
        prevWidth: m,
        prevHeight: g,
        prevLayout: _,
        prevStackOffset: A,
        prevMargin: P,
        prevChildren: O
      });
    }
    if (!rl(O, w.prevChildren)) {
      var R, B, F, K, V = Le(O, jr), W = V && (R = (B = V.props) === null || B === void 0 ? void 0 : B.startIndex) !== null && R !== void 0 ? R : $, X = V && (F = (K = V.props) === null || K === void 0 ? void 0 : K.endIndex) !== null && F !== void 0 ? F : M, le = W !== $ || X !== M, ye = !ee(x), De = ye && !le ? w.updateId : w.updateId + 1;
      return k(k({
        updateId: De
      }, p(k(k({
        props: h
      }, w), {}, {
        updateId: De,
        dataStartIndex: W,
        dataEndIndex: X
      }), w)), {}, {
        prevChildren: O,
        dataStartIndex: W,
        dataEndIndex: X
      });
    }
    return null;
  }), G(y, "renderActiveDot", function(h, w, b) {
    var x;
    return /* @__PURE__ */ D.isValidElement(h) ? x = /* @__PURE__ */ D.cloneElement(h, w) : Z(h) ? x = h(w) : x = /* @__PURE__ */ T.createElement(ld, w), /* @__PURE__ */ T.createElement(he, {
      className: "recharts-active-dot",
      key: b
    }, x);
  });
  var v = /* @__PURE__ */ D.forwardRef(function(w, b) {
    return /* @__PURE__ */ T.createElement(y, lr({}, w, {
      ref: b
    }));
  });
  return v.displayName = y.displayName, v;
}, uR = oR({
  chartName: "AreaChart",
  GraphicalChild: kt,
  axisComponents: [{
    axisType: "xAxis",
    AxisComp: za
  }, {
    axisType: "yAxis",
    AxisComp: Ua
  }],
  formatAxisMap: sN
});
const sR = { light: "", dark: ".dark" }, sw = D.createContext(null);
function cR() {
  const e = D.useContext(sw);
  if (!e)
    throw new Error("useChart must be used within a <ChartContainer />");
  return e;
}
function lR({
  id: e,
  className: t,
  children: r,
  config: n,
  ...i
}) {
  const a = D.useId(), o = `chart-${e || a.replace(/:/g, "")}`;
  return /* @__PURE__ */ S.jsx(sw.Provider, { value: { config: n }, children: /* @__PURE__ */ S.jsxs(
    "div",
    {
      "data-slot": "chart",
      "data-chart": o,
      className: We(
        "flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-hidden [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector]:outline-hidden [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-surface]:outline-hidden",
        t
      ),
      ...i,
      children: [
        /* @__PURE__ */ S.jsx(fR, { id: o, config: n }),
        /* @__PURE__ */ S.jsx(nP, { children: r })
      ]
    }
  ) });
}
const fR = ({ id: e, config: t }) => {
  const r = Object.entries(t).filter(
    ([, n]) => n.theme || n.color
  );
  return r.length ? /* @__PURE__ */ S.jsx(
    "style",
    {
      dangerouslySetInnerHTML: {
        __html: Object.entries(sR).map(
          ([n, i]) => `
${i} [data-chart=${e}] {
${r.map(([a, o]) => {
            var s;
            const u = ((s = o.theme) == null ? void 0 : s[n]) || o.color;
            return u ? `  --color-${a}: ${u};` : null;
          }).join(`
`)}
}
`
        ).join(`
`)
      }
    }
  ) : null;
}, dR = rt;
function hR({
  active: e,
  payload: t,
  className: r,
  indicator: n = "dot",
  hideLabel: i = !1,
  hideIndicator: a = !1,
  label: o,
  labelFormatter: u,
  labelClassName: s,
  formatter: c,
  color: f,
  nameKey: l,
  labelKey: d
}) {
  const { config: p } = cR(), y = D.useMemo(() => {
    var O;
    if (i || !(t != null && t.length))
      return null;
    const [h] = t, w = `${d || (h == null ? void 0 : h.dataKey) || (h == null ? void 0 : h.name) || "value"}`, b = Jg(p, h, w), x = !d && typeof o == "string" ? ((O = p[o]) == null ? void 0 : O.label) || o : b == null ? void 0 : b.label;
    return u ? /* @__PURE__ */ S.jsx("div", { className: We("font-medium", s), children: u(x, t) }) : x ? /* @__PURE__ */ S.jsx("div", { className: We("font-medium", s), children: x }) : null;
  }, [
    o,
    u,
    t,
    i,
    s,
    p,
    d
  ]);
  if (!e || !(t != null && t.length))
    return null;
  const v = t.length === 1 && n !== "dot";
  return /* @__PURE__ */ S.jsxs(
    "div",
    {
      className: We(
        "grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl",
        r
      ),
      children: [
        v ? null : y,
        /* @__PURE__ */ S.jsx("div", { className: "grid gap-1.5", children: t.filter((h) => h.type !== "none").map((h, w) => {
          const b = `${l || h.name || h.dataKey || "value"}`, x = Jg(p, h, b), O = f || h.payload.fill || h.color;
          return /* @__PURE__ */ S.jsx(
            "div",
            {
              className: We(
                "flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground",
                n === "dot" && "items-center"
              ),
              children: c && (h == null ? void 0 : h.value) !== void 0 && h.name ? c(h.value, h.name, h, w, h.payload) : /* @__PURE__ */ S.jsxs(S.Fragment, { children: [
                x != null && x.icon ? /* @__PURE__ */ S.jsx(x.icon, {}) : !a && /* @__PURE__ */ S.jsx(
                  "div",
                  {
                    className: We(
                      "shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)",
                      {
                        "h-2.5 w-2.5": n === "dot",
                        "w-1": n === "line",
                        "w-0 border-[1.5px] border-dashed bg-transparent": n === "dashed",
                        "my-0.5": v && n === "dashed"
                      }
                    ),
                    style: {
                      "--color-bg": O,
                      "--color-border": O
                    }
                  }
                ),
                /* @__PURE__ */ S.jsxs(
                  "div",
                  {
                    className: We(
                      "flex flex-1 justify-between leading-none",
                      v ? "items-end" : "items-center"
                    ),
                    children: [
                      /* @__PURE__ */ S.jsxs("div", { className: "grid gap-1.5", children: [
                        v ? y : null,
                        /* @__PURE__ */ S.jsx("span", { className: "text-muted-foreground", children: (x == null ? void 0 : x.label) || h.name })
                      ] }),
                      h.value && /* @__PURE__ */ S.jsx("span", { className: "font-mono font-medium text-foreground tabular-nums", children: h.value.toLocaleString() })
                    ]
                  }
                )
              ] })
            },
            h.dataKey
          );
        }) })
      ]
    }
  );
}
function Jg(e, t, r) {
  if (typeof t != "object" || t === null)
    return;
  const n = "payload" in t && typeof t.payload == "object" && t.payload !== null ? t.payload : void 0;
  let i = r;
  return r in t && typeof t[r] == "string" ? i = t[r] : n && r in n && typeof n[r] == "string" && (i = n[r]), i in e ? e[i] : e[r];
}
function cw({
  title: e,
  subtitle: t,
  tooltipLabel: r,
  dataKey: n,
  color: i,
  gradientId: a,
  chartData: o,
  isLoading: u,
  emptyIcon: s,
  emptyText: c,
  downloadFilename: f,
  yAxisFormatter: l,
  tooltipFormatter: d
}) {
  const p = D.useRef(null), y = {
    [n]: { label: r, color: i }
  };
  return /* @__PURE__ */ S.jsxs(mf, { ref: p, children: [
    /* @__PURE__ */ S.jsx(Cw, { className: "space-y-0 pb-2", children: /* @__PURE__ */ S.jsxs("div", { className: "flex items-start justify-between", children: [
      /* @__PURE__ */ S.jsxs("div", { className: "space-y-0.5", children: [
        /* @__PURE__ */ S.jsx(Iw, { className: "text-base font-medium", children: e }),
        /* @__PURE__ */ S.jsx("p", { className: "text-sm text-muted-foreground", children: t })
      ] }),
      /* @__PURE__ */ S.jsxs(pr, { children: [
        /* @__PURE__ */ S.jsx(vr, { asChild: !0, children: /* @__PURE__ */ S.jsx(
          vt,
          {
            variant: "outline",
            size: "icon",
            className: "h-8 w-8 print:hidden",
            onClick: () => tO(p, f),
            children: /* @__PURE__ */ S.jsx(rb, { className: "h-4 w-4" })
          }
        ) }),
        /* @__PURE__ */ S.jsx(yr, { children: U("Download as PNG") })
      ] })
    ] }) }),
    /* @__PURE__ */ S.jsx($w, { className: "pt-4", children: u ? /* @__PURE__ */ S.jsx(or, { className: "h-[300px] w-full" }) : o.length === 0 ? /* @__PURE__ */ S.jsxs("div", { className: "flex h-[300px] w-full flex-col items-center justify-center gap-2", children: [
      s,
      /* @__PURE__ */ S.jsx("p", { className: "text-sm text-muted-foreground", children: c })
    ] }) : /* @__PURE__ */ S.jsx(
      lR,
      {
        config: y,
        className: "aspect-auto h-[300px] w-full",
        children: /* @__PURE__ */ S.jsxs(
          uR,
          {
            accessibilityLayer: !0,
            data: o,
            margin: { left: 0, right: 12, top: 12, bottom: 0 },
            children: [
              /* @__PURE__ */ S.jsx("defs", { children: /* @__PURE__ */ S.jsxs("linearGradient", { id: a, x1: "0", y1: "0", x2: "0", y2: "1", children: [
                /* @__PURE__ */ S.jsx("stop", { offset: "0%", stopColor: i, stopOpacity: 0.3 }),
                /* @__PURE__ */ S.jsx("stop", { offset: "100%", stopColor: i, stopOpacity: 0.05 })
              ] }) }),
              /* @__PURE__ */ S.jsx(
                Wx,
                {
                  vertical: !1,
                  strokeDasharray: "3 3",
                  stroke: "hsl(var(--border))"
                }
              ),
              /* @__PURE__ */ S.jsx(
                za,
                {
                  dataKey: "date",
                  tickLine: !1,
                  axisLine: !1,
                  tickMargin: 8,
                  minTickGap: 32,
                  tick: { fill: "hsl(var(--muted-foreground))", fontSize: 12 },
                  tickFormatter: (v) => new Date(v).toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric"
                  })
                }
              ),
              /* @__PURE__ */ S.jsx(
                Ua,
                {
                  tickLine: !1,
                  axisLine: !1,
                  tickMargin: 8,
                  tick: { fill: "hsl(var(--muted-foreground))", fontSize: 12 },
                  width: 40,
                  tickFormatter: l
                }
              ),
              /* @__PURE__ */ S.jsx(
                dR,
                {
                  content: /* @__PURE__ */ S.jsx(
                    hR,
                    {
                      className: "w-[150px]",
                      nameKey: n,
                      labelFormatter: (v) => new Date(v).toLocaleDateString("en-US", {
                        month: "short",
                        day: "numeric",
                        year: "numeric"
                      }),
                      formatter: d ? (v) => d(v) : void 0
                    }
                  )
                }
              ),
              /* @__PURE__ */ S.jsx(
                kt,
                {
                  dataKey: n,
                  type: "monotone",
                  stroke: i,
                  strokeWidth: 2,
                  fill: `url(#${a})`,
                  dot: !1,
                  activeDot: {
                    r: 5,
                    fill: i,
                    strokeWidth: 2,
                    stroke: "#fff"
                  }
                }
              )
            ]
          }
        )
      }
    ) })
  ] });
}
function pR({ report: e }) {
  const t = (e == null ? void 0 : e.runs.map((r) => ({ date: r.day, runs: r.runs })).sort(
    (r, n) => new Date(r.date).getTime() - new Date(n.date).getTime()
  )) ?? [];
  return /* @__PURE__ */ S.jsx(
    cw,
    {
      title: U("Flow Runs Over Time"),
      subtitle: U("Track your automation execution trends"),
      tooltipLabel: U("Runs"),
      dataKey: "runs",
      color: "#db0011",
      gradientId: "fillRuns",
      chartData: t,
      isLoading: !e,
      emptyIcon: /* @__PURE__ */ S.jsx(Nw, { className: "h-10 w-10 text-muted-foreground/50" }),
      emptyText: U(
        "No runs recorded yet. Data will appear here once your flows start running."
      ),
      downloadFilename: "flow-runs"
    }
  );
}
function vR({ report: e }) {
  const t = (e == null ? void 0 : e.runs.map((r) => {
    var n;
    return {
      date: r.day,
      minutesSaved: (((n = e == null ? void 0 : e.flows.find((i) => i.flowId === r.flowId)) == null ? void 0 : n.timeSavedPerRun) ?? 0) * r.runs
    };
  }).sort(
    (r, n) => new Date(r.date).getTime() - new Date(n.date).getTime()
  )) ?? [];
  return /* @__PURE__ */ S.jsx(
    cw,
    {
      title: U("Time Saved Over Time"),
      subtitle: U("Track how much time your automations are saving"),
      tooltipLabel: U("Time Saved"),
      dataKey: "minutesSaved",
      color: "#10b981",
      gradientId: "fillTimeSaved",
      chartData: t,
      isLoading: !e,
      emptyIcon: /* @__PURE__ */ S.jsx(vn, { className: "h-10 w-10 text-muted-foreground/50" }),
      emptyText: U(
        "No time saved yet. Data will appear here once your flows start running."
      ),
      downloadFilename: "time-saved",
      yAxisFormatter: (r) => pn.formatToHoursAndMinutes(r),
      tooltipFormatter: (r) => pn.formatToHoursAndMinutes(r)
    }
  );
}
function yR({ report: e }) {
  return /* @__PURE__ */ S.jsxs("div", { className: "space-y-6 mb-6", children: [
    /* @__PURE__ */ S.jsx(pR, { report: e }),
    /* @__PURE__ */ S.jsx(vR, { report: e })
  ] });
}
const mR = 1e3 * 60 * 60 * 24;
function xR() {
  const { platform: e } = kw.useCurrentPlatform(), [t, r] = Dw(), n = t.get("projectId") || void 0, i = t.get("timePeriod") || rr.LAST_MONTH, a = t.get("tab") || "analytics", { data: o } = Rw.useAll(), { data: u, isLoading: s } = jd.useAnalyticsTimeBased(
    i,
    n
  ), { mutate: c } = jd.useRefreshAnalytics(), { isRefreshing: f } = D.useContext(yf), l = (v) => {
    const h = new URLSearchParams(t);
    v === "all" ? h.delete("projectId") : h.set("projectId", v), r(h, { replace: !0 });
  }, d = (v) => {
    const h = new URLSearchParams(t);
    h.set("timePeriod", v), r(h, { replace: !0 });
  }, p = (v) => {
    const h = new URLSearchParams(t);
    v === "analytics" ? h.delete("tab") : h.set("tab", v), r(h, { replace: !0 });
  };
  Lw(() => {
    Ka(u == null ? void 0 : u.updated).add(mR, "ms").isBefore(Ka()) && !f && c();
  });
  const y = s ? void 0 : u ?? void 0;
  return /* @__PURE__ */ S.jsx(
    qw,
    {
      featureKey: "ANALYTICS",
      locked: !e.plan.analyticsEnabled,
      lockTitle: U("Unlock Impact Analytics"),
      lockDescription: U(
        "View impact analytics and metrics for the active flows across your platform"
      ),
      children: /* @__PURE__ */ S.jsxs("div", { className: "flex flex-col gap-4 w-full", children: [
        /* @__PURE__ */ S.jsx(
          Bw,
          {
            showSidebarToggle: !0,
            title: /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ S.jsx("span", { className: "text-sm font-medium", children: U("Impact") }),
              /* @__PURE__ */ S.jsxs(pr, { children: [
                /* @__PURE__ */ S.jsx(vr, { asChild: !0, children: /* @__PURE__ */ S.jsx(nb, { className: "h-4 w-4 text-muted-foreground cursor-help" }) }),
                /* @__PURE__ */ S.jsx(yr, { children: U("View impact analytics and metrics for the active flows.") })
              ] })
            ] }),
            rightContent: /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ S.jsxs("div", { className: "flex items-center gap-2 px-3 py-1.5 border border-dashed rounded-md text-sm text-muted-foreground", children: [
                /* @__PURE__ */ S.jsxs("span", { children: [
                  U("Updated"),
                  " ",
                  Ka(u == null ? void 0 : u.updated).format("MMM DD, hh:mm A"),
                  " —",
                  " ",
                  U("Refreshes daily")
                ] }),
                /* @__PURE__ */ S.jsxs(pr, { children: [
                  /* @__PURE__ */ S.jsx(vr, { asChild: !0, children: /* @__PURE__ */ S.jsx(
                    vt,
                    {
                      variant: "ghost",
                      size: "icon",
                      className: "h-6 w-6",
                      onClick: () => c(void 0, {
                        onSuccess: () => Xc.success(U("Data refreshed successfully"))
                      }),
                      disabled: f,
                      children: /* @__PURE__ */ S.jsx(
                        Fw,
                        {
                          className: `h-3.5 w-3.5 ${f ? "animate-spin" : ""}`
                        }
                      )
                    }
                  ) }),
                  /* @__PURE__ */ S.jsx(yr, { children: U("Refresh analytics") })
                ] })
              ] }),
              /* @__PURE__ */ S.jsxs(
                zw,
                {
                  value: i,
                  onValueChange: d,
                  children: [
                    /* @__PURE__ */ S.jsxs(Uw, { className: "w-auto gap-2 h-8", children: [
                      /* @__PURE__ */ S.jsx(Ww, { className: "h-4 w-4" }),
                      /* @__PURE__ */ S.jsx(Hw, {})
                    ] }),
                    /* @__PURE__ */ S.jsxs(Kw, { side: "bottom", align: "end", children: [
                      /* @__PURE__ */ S.jsx(Xr, { value: rr.LAST_WEEK, children: U("Last 7 days") }),
                      /* @__PURE__ */ S.jsx(Xr, { value: rr.LAST_MONTH, children: U("Last 30 days") }),
                      /* @__PURE__ */ S.jsx(Xr, { value: rr.LAST_THREE_MONTHS, children: U("Last 3 months") }),
                      /* @__PURE__ */ S.jsx(Xr, { value: rr.LAST_SIX_MONTHS, children: U("Last 6 months") }),
                      /* @__PURE__ */ S.jsx(Xr, { value: rr.LAST_YEAR, children: U("Last year") })
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ S.jsx(
                fO,
                {
                  projects: o ?? [],
                  selectedProjectId: n,
                  onProjectChange: l
                }
              )
            ] }),
            className: "min-w-full"
          }
        ),
        /* @__PURE__ */ S.jsxs(
          Gw,
          {
            value: a,
            onValueChange: p,
            className: "w-full ",
            children: [
              /* @__PURE__ */ S.jsxs(
                Vw,
                {
                  variant: "outline",
                  className: We("border-b w-full", Zc),
                  children: [
                    /* @__PURE__ */ S.jsxs(Ad, { variant: "outline", value: "analytics", children: [
                      /* @__PURE__ */ S.jsx(Xw, { className: "w-4 h-4 mr-2" }),
                      U("Analytics")
                    ] }),
                    /* @__PURE__ */ S.jsxs(Ad, { variant: "outline", value: "details", children: [
                      /* @__PURE__ */ S.jsx(nO, { className: "w-4 h-4 mr-2" }),
                      U("Details")
                    ] })
                  ]
                }
              ),
              /* @__PURE__ */ S.jsx(Pd, { value: "analytics", children: /* @__PURE__ */ S.jsxs(
                "div",
                {
                  className: We("flex flex-col gap-6", Zc),
                  children: [
                    /* @__PURE__ */ S.jsx(wO, { report: y ?? void 0 }),
                    /* @__PURE__ */ S.jsx(yR, { report: y ?? void 0 })
                  ]
                }
              ) }),
              /* @__PURE__ */ S.jsx(Pd, { value: "details", children: /* @__PURE__ */ S.jsx(
                pO,
                {
                  report: y,
                  isLoading: s,
                  projects: o
                }
              ) })
            ]
          }
        )
      ] })
    }
  );
}
export {
  xR as default
};
