import { c as oe, b6 as D, dR as L, g as O, c0 as z, c1 as R, dT as re, aJ as p, a6 as a, j as e, bs as B, b_ as se, i as m, bt as G, bu as W, bv as H, c2 as X, c3 as I, c4 as F, aX as ae, ar as le, al as de, c8 as b, by as P, o as M, a as ce, s as U, dU as w, h as v, dV as Q, aQ as y, cT as ie, cE as me, b3 as ue, cG as xe, be as he, bf as ge, dW as je, aI as $, dQ as pe, e as fe, cl as ne, ab as Se, d4 as J, I as ve, bC as be, bj as A, bk as N, bl as C, bm as E, bp as k, bB as K, bq as V, dX as De, bA as Y, cZ as ye, dY as we } from "./mount-builder-CqIEWsZv.mjs";
import { C as Ae } from "./centered-page-C5JGBrkC.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ne = [
  ["path", { d: "M21.54 15H17a2 2 0 0 0-2 2v4.54", key: "1djwo0" }],
  [
    "path",
    {
      d: "M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",
      key: "1tzkfa"
    }
  ],
  ["path", { d: "M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05", key: "14pb5j" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
], Ce = oe("earth", Ne), Z = {
  useUpdatePlatformSso: ({
    platformId: s,
    refetch: t,
    onSuccess: o
  }) => D({
    mutationFn: async (n) => {
      await L.update(n, s), await t();
    },
    onSuccess: () => {
      o && o();
    }
  })
}, Ee = M({
  allowedAuthDomains: ce(
    M({
      domain: U().min(1)
    })
  )
}), ke = ({
  platform: s,
  refetch: t
}) => {
  var x, h, d;
  const [o, n] = O.useState(!1), i = z({
    defaultValues: {
      allowedAuthDomains: ((s == null ? void 0 : s.allowedAuthDomains) ?? []).map(
        (c) => ({
          domain: c
        })
      )
    },
    resolver: R(Ee)
  }), { fields: r, append: l, remove: j } = re({
    control: i.control,
    name: "allowedAuthDomains"
  }), { mutate: f, isPending: u } = D({
    mutationFn: async (c) => {
      await L.update(c, s.id), await t();
    },
    onSuccess: () => {
      p.success(a("Allowed domains updated"), {
        duration: 3e3
      }), n(!1);
    }
  });
  return /* @__PURE__ */ e.jsxs(
    B,
    {
      open: o,
      onOpenChange: (c) => {
        c || i.reset(), n(c);
      },
      children: [
        /* @__PURE__ */ e.jsx(se, { asChild: !0, children: /* @__PURE__ */ e.jsx(m, { size: "sm", variant: "basic", onClick: () => n(!0), children: s.allowedAuthDomains.length > 0 ? a("Update") : a("Enable") }) }),
        /* @__PURE__ */ e.jsxs(G, { children: [
          /* @__PURE__ */ e.jsx(W, { children: /* @__PURE__ */ e.jsx(H, { children: a("Configure Allowed Domains") }) }),
          /* @__PURE__ */ e.jsx(X, { ...i, children: /* @__PURE__ */ e.jsxs(
            "form",
            {
              className: "grid space-y-4",
              onSubmit: i.handleSubmit((c) => {
                f({
                  allowedAuthDomains: c.allowedAuthDomains.map(
                    (S) => S.domain
                  ),
                  enforceAllowedAuthDomains: c.allowedAuthDomains.length !== 0
                });
              }),
              children: [
                /* @__PURE__ */ e.jsx("div", { className: "flex flex-col gap-1", children: /* @__PURE__ */ e.jsx("div", { className: "text-muted-foreground text-sm", children: a(
                  "Enter the allowed domains for the users to authenticate with. An empty list will allow all domains."
                ) }) }),
                r.map((c, S) => /* @__PURE__ */ e.jsx(
                  I,
                  {
                    name: `allowedAuthDomains.${S}.domain`,
                    render: ({ field: T }) => /* @__PURE__ */ e.jsx(F, { className: "grid space-y-4", children: /* @__PURE__ */ e.jsxs("div", { className: "flex space-x-2", children: [
                      /* @__PURE__ */ e.jsx(
                        ae,
                        {
                          ...T,
                          id: `allowedAuthDomains.${S}`,
                          placeholder: a("example.com"),
                          className: "rounded-sm"
                        }
                      ),
                      /* @__PURE__ */ e.jsx(
                        m,
                        {
                          type: "button",
                          onClick: () => j(S),
                          variant: "outline",
                          size: "sm",
                          className: "h-10",
                          children: /* @__PURE__ */ e.jsx(le, { className: "w-4 h-4" })
                        }
                      )
                    ] }) })
                  },
                  c.id
                )),
                /* @__PURE__ */ e.jsxs(
                  m,
                  {
                    type: "button",
                    onClick: () => l({ domain: "" }),
                    variant: "outline",
                    size: "sm",
                    children: [
                      /* @__PURE__ */ e.jsx(de, { className: "size-4" }),
                      a("Add Domain")
                    ]
                  }
                ),
                ((d = (h = (x = i == null ? void 0 : i.formState) == null ? void 0 : x.errors) == null ? void 0 : h.root) == null ? void 0 : d.serverError) && /* @__PURE__ */ e.jsx(b, { children: i.formState.errors.root.serverError.message }),
                /* @__PURE__ */ e.jsxs(P, { children: [
                  /* @__PURE__ */ e.jsx(
                    m,
                    {
                      variant: "outline",
                      onClick: () => n(!1),
                      type: "button",
                      children: a("Cancel")
                    }
                  ),
                  /* @__PURE__ */ e.jsx(
                    m,
                    {
                      loading: u,
                      disabled: !i.formState.isValid,
                      type: "submit",
                      children: a("Save")
                    }
                  )
                ] })
              ]
            }
          ) })
        ] })
      ]
    }
  );
}, Ve = ({
  platform: s,
  connected: t,
  refetch: o
}) => {
  const [n, i] = O.useState(!1);
  return /* @__PURE__ */ e.jsxs(B, { open: n, onOpenChange: i, children: [
    /* @__PURE__ */ e.jsx(se, { asChild: !0, children: /* @__PURE__ */ e.jsx(m, { size: "sm", variant: "basic", onClick: () => i(!0), children: t ? a("Edit") : a("Enable") }) }),
    /* @__PURE__ */ e.jsx(G, { children: n && /* @__PURE__ */ e.jsx(
      Ie,
      {
        platform: s,
        connected: t,
        refetch: o,
        onClose: () => i(!1)
      },
      n ? "open" : "closed"
    ) })
  ] });
}, Ie = ({
  platform: s,
  connected: t,
  refetch: o,
  onClose: n
}) => {
  var x;
  const i = ((x = s.ssoDomainVerification) == null ? void 0 : x.status) === w.VERIFIED, [r, l] = O.useState(
    t || !i ? "domain" : "saml"
  ), { mutate: j, isPending: f } = D({
    mutationFn: async () => {
      await L.update(
        { federatedAuthProviders: { saml: null } },
        s.id
      ), await o();
    },
    onSuccess: () => {
      p.success(a("Single sign-on settings updated"), { duration: 3e3 }), n();
    }
  }), u = t ? { onDisable: () => j(), isDisabling: f } : null;
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(W, { children: /* @__PURE__ */ e.jsx(H, { children: a("Configure SAML 2.0 SSO") }) }),
    /* @__PURE__ */ e.jsx(Fe, { step: r }),
    /* @__PURE__ */ e.jsx("div", { className: v(r !== "domain" && "hidden"), children: /* @__PURE__ */ e.jsx(
      Pe,
      {
        platform: s,
        refetch: o,
        onVerified: () => l("saml"),
        onNext: () => l("saml"),
        canProceed: i,
        disableAction: u
      }
    ) }),
    /* @__PURE__ */ e.jsx("div", { className: v(r !== "saml" && "hidden"), children: /* @__PURE__ */ e.jsx(
      Me,
      {
        platform: s,
        refetch: o,
        onBack: () => l("domain"),
        onClose: n,
        disableAction: u
      }
    ) })
  ] });
}, Fe = ({ step: s }) => /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-3 text-xs text-muted-foreground", children: [
  /* @__PURE__ */ e.jsxs(
    "div",
    {
      className: v(
        "flex items-center gap-2",
        s === "domain" && "text-foreground font-medium"
      ),
      children: [
        /* @__PURE__ */ e.jsx(
          "span",
          {
            className: v(
              "flex size-5 items-center justify-center rounded-full border text-xs",
              s === "domain" ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40"
            ),
            children: "1"
          }
        ),
        a("SSO Domain")
      ]
    }
  ),
  /* @__PURE__ */ e.jsx("div", { className: "h-px w-6 bg-muted-foreground/30" }),
  /* @__PURE__ */ e.jsxs(
    "div",
    {
      className: v(
        "flex items-center gap-2",
        s === "saml" && "text-foreground font-medium"
      ),
      children: [
        /* @__PURE__ */ e.jsx(
          "span",
          {
            className: v(
              "flex size-5 items-center justify-center rounded-full border text-xs",
              s === "saml" ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/40"
            ),
            children: "2"
          }
        ),
        a("SAML 2.0")
      ]
    }
  )
] }), Pe = ({
  platform: s,
  refetch: t,
  onVerified: o,
  onNext: n,
  canProceed: i,
  disableAction: r
}) => {
  var _;
  const l = z({
    resolver: R(Ue),
    defaultValues: { ssoDomain: s.ssoDomain ?? "" },
    mode: "onChange"
  }), j = s.ssoDomainVerification ?? null, u = l.watch("ssoDomain").trim().toLowerCase() !== (s.ssoDomain ?? ""), [x, h] = O.useState(!1), { mutate: d, isPending: c } = D({
    mutationFn: async (g) => {
      await Q.updateSsoDomain(g.ssoDomain.trim().toLowerCase()), await t();
    },
    onSuccess: () => {
      p.success(a("SSO domain saved")), h(!1);
    },
    onError: (g) => {
      l.setError("root.serverError", {
        type: "manual",
        message: ee(g, a("Couldn't save domain"))
      }), h(!1);
    }
  }), { mutate: S, isPending: T } = D({
    mutationFn: async () => {
      const g = await Q.verifySsoDomain();
      return await t(), g;
    },
    onSuccess: (g) => {
      var q;
      ((q = g.ssoDomainVerification) == null ? void 0 : q.status) === w.VERIFIED ? (p.success(a("Domain verified")), o()) : p.message(
        a("TXT record not found yet — DNS can take a few minutes.")
      );
    },
    onError: (g) => {
      p.error(
        ee(g, a("Couldn't verify domain"))
      );
    }
  }), te = (g) => {
    if (s.ssoDomain) {
      h(!0);
      return;
    }
    d(g);
  };
  return /* @__PURE__ */ e.jsxs(X, { ...l, children: [
    /* @__PURE__ */ e.jsxs(
      "form",
      {
        className: "grid space-y-4",
        onSubmit: l.handleSubmit(te),
        children: [
          /* @__PURE__ */ e.jsx(
            I,
            {
              name: "ssoDomain",
              render: ({ field: g }) => /* @__PURE__ */ e.jsxs(F, { className: "grid space-y-2", children: [
                /* @__PURE__ */ e.jsx(y, { htmlFor: "ssoDomain", children: a("Domain") }),
                /* @__PURE__ */ e.jsx(
                  ae,
                  {
                    ...g,
                    id: "ssoDomain",
                    placeholder: "acme.com",
                    className: "rounded-sm"
                  }
                ),
                /* @__PURE__ */ e.jsx(ie, { children: a(
                  "When a user enters this domain on the sign-in page, they will be redirected to your SAML identity provider."
                ) }),
                /* @__PURE__ */ e.jsx(b, {})
              ] })
            }
          ),
          j && !u && /* @__PURE__ */ e.jsx(
            Le,
            {
              verification: j,
              isVerifying: T,
              onVerify: () => S()
            }
          ),
          ((_ = l.formState.errors.root) == null ? void 0 : _.serverError) && /* @__PURE__ */ e.jsx(b, { children: l.formState.errors.root.serverError.message }),
          /* @__PURE__ */ e.jsxs(P, { children: [
            r && /* @__PURE__ */ e.jsx(
              m,
              {
                type: "button",
                variant: "basic",
                className: "text-destructive",
                loading: r.isDisabling,
                onClick: r.onDisable,
                children: a("Disable")
              }
            ),
            u ? /* @__PURE__ */ e.jsx(
              m,
              {
                type: "submit",
                loading: c,
                disabled: !l.formState.isValid,
                children: s.ssoDomain ? a("Update domain") : a("Save domain")
              }
            ) : /* @__PURE__ */ e.jsx(m, { type: "button", onClick: n, disabled: !i, children: a("Next") })
          ] })
        ]
      }
    ),
    /* @__PURE__ */ e.jsx(B, { open: x, onOpenChange: h, children: /* @__PURE__ */ e.jsxs(G, { children: [
      /* @__PURE__ */ e.jsx(W, { children: /* @__PURE__ */ e.jsx(H, { children: a("Update SSO domain?") }) }),
      /* @__PURE__ */ e.jsxs(me, { variant: "warning", children: [
        /* @__PURE__ */ e.jsx(ue, { className: "size-4" }),
        /* @__PURE__ */ e.jsx(xe, { children: a(
          "Users won't be able to sign in via SSO until you verify the new domain."
        ) })
      ] }),
      /* @__PURE__ */ e.jsxs(P, { children: [
        /* @__PURE__ */ e.jsx(
          m,
          {
            variant: "outline",
            type: "button",
            disabled: c,
            onClick: () => h(!1),
            children: a("Cancel")
          }
        ),
        /* @__PURE__ */ e.jsx(
          m,
          {
            type: "button",
            loading: c,
            onClick: () => d(l.getValues()),
            children: a("Update domain")
          }
        )
      ] })
    ] }) })
  ] });
}, Me = ({
  platform: s,
  refetch: t,
  onBack: o,
  onClose: n,
  disableAction: i
}) => {
  var u, x, h;
  const r = z({
    resolver: R(ze),
    defaultValues: { idpMetadata: "", idpCertificate: "" },
    mode: "onChange"
  }), { data: l } = he.useFlag(
    ge.SAML_AUTH_ACS_URL
  ), { mutate: j, isPending: f } = D({
    mutationFn: async (d) => {
      await L.update(d, s.id), await t();
    },
    onSuccess: () => {
      p.success(a("Single sign-on settings updated"), { duration: 3e3 }), n();
    }
  });
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    l && /* @__PURE__ */ e.jsx("div", { className: "mb-4", children: /* @__PURE__ */ e.jsx(
      je,
      {
        markdown: a(
          "\n**Setup Instructions**:\nPlease check the following documentation: [SAML SSO](https://activepieces.com/docs/security/sso)\n\n**Single sign-on URL**:\n```text\n{samlAcs}\n```\n**Audience URI (SP Entity ID)**:\n```text\nActivepieces\n```\n",
          { samlAcs: l ?? "" }
        )
      }
    ) }),
    /* @__PURE__ */ e.jsx(X, { ...r, children: /* @__PURE__ */ e.jsxs(
      "form",
      {
        className: "grid space-y-4",
        onSubmit: r.handleSubmit((d) => {
          j({ federatedAuthProviders: { saml: d } });
        }),
        children: [
          /* @__PURE__ */ e.jsx(
            I,
            {
              name: "idpMetadata",
              render: ({ field: d }) => /* @__PURE__ */ e.jsxs(F, { className: "grid space-y-2", children: [
                /* @__PURE__ */ e.jsx(y, { htmlFor: "idpMetadata", children: a("IDP Metadata") }),
                /* @__PURE__ */ e.jsx(
                  $,
                  {
                    ...d,
                    required: !0,
                    id: "idpMetadata",
                    rows: 6,
                    className: "rounded-sm font-mono text-xs"
                  }
                ),
                /* @__PURE__ */ e.jsx(ie, { children: a(
                  "Paste the metadata XML contents or the metadata URL provided by your identity provider."
                ) }),
                /* @__PURE__ */ e.jsx(b, {})
              ] })
            }
          ),
          /* @__PURE__ */ e.jsx(
            I,
            {
              name: "idpCertificate",
              render: ({ field: d }) => /* @__PURE__ */ e.jsxs(F, { className: "grid space-y-4", children: [
                /* @__PURE__ */ e.jsx(y, { htmlFor: "idpCertificate", children: a("IDP Certificate") }),
                /* @__PURE__ */ e.jsx(
                  $,
                  {
                    ...d,
                    required: !0,
                    id: "idpCertificate",
                    className: "rounded-sm"
                  }
                ),
                /* @__PURE__ */ e.jsx(b, {})
              ] })
            }
          ),
          ((h = (x = (u = r == null ? void 0 : r.formState) == null ? void 0 : u.errors) == null ? void 0 : x.root) == null ? void 0 : h.serverError) && /* @__PURE__ */ e.jsx(b, { children: r.formState.errors.root.serverError.message }),
          /* @__PURE__ */ e.jsxs(P, { children: [
            i && /* @__PURE__ */ e.jsx(
              m,
              {
                type: "button",
                variant: "basic",
                className: "text-destructive mr-auto",
                loading: i.isDisabling,
                onClick: i.onDisable,
                children: a("Disable")
              }
            ),
            /* @__PURE__ */ e.jsx(m, { variant: "outline", type: "button", onClick: o, children: a("Back") }),
            /* @__PURE__ */ e.jsx(
              m,
              {
                loading: f,
                disabled: !r.formState.isValid,
                type: "submit",
                children: a("Save")
              }
            )
          ] })
        ]
      }
    ) })
  ] });
}, Le = ({
  verification: s,
  isVerifying: t,
  onVerify: o
}) => {
  const n = s.status === w.VERIFIED;
  return /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-3", children: [
    /* @__PURE__ */ e.jsx(Oe, { status: s.status }),
    !n && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
      /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground", children: a(
        "Add this TXT record at your DNS provider. We'll detect it once it propagates — this usually takes a few minutes."
      ) }),
      /* @__PURE__ */ e.jsx(Te, { record: s.record }),
      /* @__PURE__ */ e.jsx("div", { children: /* @__PURE__ */ e.jsx(
        m,
        {
          type: "button",
          size: "sm",
          variant: "outline",
          loading: t,
          onClick: o,
          children: a("Verify DNS")
        }
      ) })
    ] })
  ] });
}, Oe = ({
  status: s
}) => s === w.VERIFIED ? /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 text-sm text-success-600", children: [
  /* @__PURE__ */ e.jsx(ne, { className: "size-4" }),
  a("DNS verified — domain is ready")
] }) : /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 text-sm text-warning", children: [
  /* @__PURE__ */ e.jsx(Se, { className: "size-4 animate-spin" }),
  a("Waiting for DNS")
] }), Te = ({
  record: s
}) => /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-2 rounded-md border p-4", children: [
  /* @__PURE__ */ e.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ e.jsx("span", { className: "text-xs font-mono px-1.5 py-0.5 rounded bg-muted", children: s.type }) }),
  /* @__PURE__ */ e.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1.5 min-w-0", children: [
      /* @__PURE__ */ e.jsx(y, { className: "text-xs text-muted-foreground", children: a("Name") }),
      /* @__PURE__ */ e.jsx(J, { textToCopy: s.name, useInput: !0 })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1.5 min-w-0", children: [
      /* @__PURE__ */ e.jsx(y, { className: "text-xs text-muted-foreground", children: a("Value") }),
      /* @__PURE__ */ e.jsx(J, { textToCopy: s.value, useInput: !0 })
    ] })
  ] })
] });
function ee(s, t) {
  var o;
  if (fe.isError(s)) {
    const n = (o = s.response) == null ? void 0 : o.data, i = n != null && n.params && "message" in n.params ? n.params.message : void 0;
    if (typeof i == "string" && i.length > 0)
      return i;
  }
  return s instanceof Error && s.message.length > 0 ? s.message : t;
}
const Ue = M({
  ssoDomain: pe("invalidSsoDomain").max(253, "invalidSsoDomain").refine((s) => s.includes("."), "invalidSsoDomain")
}), ze = M({
  idpMetadata: U().min(1),
  idpCertificate: U().min(1)
}), Re = () => {
  var u, x;
  const { platform: s, refetch: t } = ve.useCurrentPlatform(), o = !!((u = s.federatedAuthProviders) != null && u.saml), n = ((x = s.ssoDomainVerification) == null ? void 0 : x.status) === w.VERIFIED, i = s.emailAuthEnabled, { mutate: r, isPending: l } = Z.useUpdatePlatformSso({
    platformId: s.id,
    refetch: t,
    onSuccess: () => {
      p.success(a("Email authentication updated"), { duration: 3e3 });
    }
  }), { mutate: j, isPending: f } = Z.useUpdatePlatformSso({
    platformId: s.id,
    refetch: t,
    onSuccess: () => {
      p.success(a("Google authentication updated"), { duration: 3e3 });
    }
  });
  return /* @__PURE__ */ e.jsx(
    be,
    {
      featureKey: "SSO",
      locked: !s.plan.ssoEnabled,
      lockTitle: a("Enable Single Sign On"),
      lockDescription: a(
        "Let your users sign in with your current SSO provider or give them self serve sign up access"
      ),
      children: /* @__PURE__ */ e.jsx(
        Ae,
        {
          title: a("Single Sign On"),
          description: a("Manage single sign on providers"),
          children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-4", children: [
            /* @__PURE__ */ e.jsxs(A, { variant: "outline", children: [
              /* @__PURE__ */ e.jsx(N, { variant: "icon", children: /* @__PURE__ */ e.jsx(Ce, {}) }),
              /* @__PURE__ */ e.jsxs(C, { children: [
                /* @__PURE__ */ e.jsx(E, { children: a("Allowed Domains") }),
                /* @__PURE__ */ e.jsx(k, { children: a("Restrict authentication to specific email domains.") }),
                ((s == null ? void 0 : s.allowedAuthDomains) ?? []).length > 0 && /* @__PURE__ */ e.jsx("div", { className: "mt-1 gap-2 flex", children: ((s == null ? void 0 : s.allowedAuthDomains) ?? []).map((h, d) => /* @__PURE__ */ e.jsx(K, { variant: "outline", children: h }, d)) })
              ] }),
              /* @__PURE__ */ e.jsx(V, { children: /* @__PURE__ */ e.jsx(ke, { platform: s, refetch: t }) })
            ] }),
            /* @__PURE__ */ e.jsxs(A, { variant: "outline", children: [
              /* @__PURE__ */ e.jsx(N, { variant: "icon", children: /* @__PURE__ */ e.jsx("img", { className: "size-6", src: De, alt: "icon" }) }),
              /* @__PURE__ */ e.jsxs(C, { children: [
                /* @__PURE__ */ e.jsx(E, { children: "Google" }),
                /* @__PURE__ */ e.jsx(k, { children: a(
                  "Allow logins through google's single sign-on functionality."
                ) })
              ] }),
              /* @__PURE__ */ e.jsx(V, { children: /* @__PURE__ */ e.jsx(
                Y,
                {
                  checked: s.googleAuthEnabled,
                  onCheckedChange: () => j({
                    googleAuthEnabled: !s.googleAuthEnabled
                  }),
                  disabled: f
                }
              ) })
            ] }),
            /* @__PURE__ */ e.jsxs(A, { variant: "outline", children: [
              /* @__PURE__ */ e.jsx(N, { variant: "icon", children: /* @__PURE__ */ e.jsx(ye, {}) }),
              /* @__PURE__ */ e.jsxs(C, { children: [
                /* @__PURE__ */ e.jsx(E, { children: a("SAML 2.0") }),
                /* @__PURE__ */ e.jsx(k, { children: a(
                  "Allow logins through saml 2.0's single sign-on functionality."
                ) }),
                s.ssoDomain && /* @__PURE__ */ e.jsxs("div", { className: "mt-1 gap-2 flex items-center", children: [
                  /* @__PURE__ */ e.jsx(K, { variant: "outline", children: s.ssoDomain }),
                  n ? /* @__PURE__ */ e.jsxs("span", { className: "flex items-center gap-1 text-xs text-success-600", children: [
                    /* @__PURE__ */ e.jsx(ne, { className: "size-3" }),
                    a("Verified")
                  ] }) : /* @__PURE__ */ e.jsx("span", { className: "text-xs text-warning", children: a("Pending verification") })
                ] })
              ] }),
              /* @__PURE__ */ e.jsx(V, { children: /* @__PURE__ */ e.jsx(
                Ve,
                {
                  platform: s,
                  refetch: t,
                  connected: o
                }
              ) })
            ] }),
            /* @__PURE__ */ e.jsxs(A, { variant: "outline", children: [
              /* @__PURE__ */ e.jsx(N, { variant: "icon", children: /* @__PURE__ */ e.jsx(we, {}) }),
              /* @__PURE__ */ e.jsxs(C, { children: [
                /* @__PURE__ */ e.jsx(E, { children: a("Allowed Email Login") }),
                /* @__PURE__ */ e.jsx(k, { children: a("Allow logins through email and password.") })
              ] }),
              /* @__PURE__ */ e.jsx(V, { children: /* @__PURE__ */ e.jsx(
                Y,
                {
                  checked: i,
                  onCheckedChange: () => r({
                    emailAuthEnabled: !s.emailAuthEnabled
                  }),
                  disabled: l
                }
              ) })
            ] })
          ] })
        }
      )
    }
  );
};
Re.displayName = "SSOPage";
export {
  Re as SSOPage
};
