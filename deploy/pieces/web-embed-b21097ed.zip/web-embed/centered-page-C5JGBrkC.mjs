import { j as e, aU as r } from "./mount-builder-CqIEWsZv.mjs";
const x = ({
  title: a,
  description: t,
  actions: s,
  children: l
}) => /* @__PURE__ */ e.jsxs("div", { className: "w-full max-w-[40rem] mx-auto py-6", children: [
  /* @__PURE__ */ e.jsxs("div", { className: "flex items-start justify-between gap-4", children: [
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1", children: [
      /* @__PURE__ */ e.jsx("h1", { className: "text-xl font-medium", children: a }),
      /* @__PURE__ */ e.jsx("div", { className: "text-sm text-muted-foreground", children: t })
    ] }),
    s && /* @__PURE__ */ e.jsx("div", { className: "shrink-0", children: s })
  ] }),
  /* @__PURE__ */ e.jsx(r, { className: "my-4" }),
  l
] });
export {
  x as C
};
