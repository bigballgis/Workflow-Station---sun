import { j as t, a3 as a, a4 as i, a5 as r, a0 as p } from "./mount-builder-CqIEWsZv.mjs";
const l = ({
  text: o,
  title: s,
  children: e
}) => /* @__PURE__ */ t.jsxs(a, { children: [
  /* @__PURE__ */ t.jsx(i, { asChild: !0, children: e }),
  /* @__PURE__ */ t.jsx(r, { children: /* @__PURE__ */ t.jsxs("div", { className: "flex text-xs gap-2 items-center", children: [
    s,
    ": ",
    o || "-",
    " ",
    /* @__PURE__ */ t.jsx(
      p,
      {
        withoutTooltip: !0,
        variant: "ghost",
        className: "hover:text-background",
        textToCopy: o || ""
      }
    )
  ] }) })
] });
l.displayName = "CopyTextTooltip";
export {
  l as C
};
