import { b8 as S, g as o, bK as h, jw as g, j as t, j$ as j, bi as p, hj as w } from "./mount-builder-CqIEWsZv.mjs";
import { a as E, F as x } from "./flow-chat-Bcho-Rhf.mjs";
import { u as C } from "./useSearchParam-BZbdFdZp.mjs";
import { U as F } from "./ap-form-Bh-hHJgV.mjs";
function _() {
  const { flowId: s } = S(), i = C(F) === "true", [d, u] = o.useState([]), [a, r] = o.useState(null), { data: n, isLoading: c } = h.useGetFlow({
    flowId: s ?? ""
  });
  o.useEffect(() => {
    a || r(g());
  }, [a]);
  const f = (e) => {
    u((l) => [...l, e]);
  };
  if (!s)
    return /* @__PURE__ */ t.jsx(E, {});
  if (c)
    return /* @__PURE__ */ t.jsx(j, {});
  const m = i || n && p(n.publishedVersionId);
  return /* @__PURE__ */ t.jsx(
    x,
    {
      flowId: s,
      mode: m ? w.TEST_FLOW : null,
      onSendingMessage: () => {
      },
      onError: (e) => {
        console.error("Chat error:", e);
      },
      messages: d,
      chatSessionId: a,
      onAddMessage: f,
      onSetSessionId: r
    }
  );
}
export {
  _ as ChatPage
};
