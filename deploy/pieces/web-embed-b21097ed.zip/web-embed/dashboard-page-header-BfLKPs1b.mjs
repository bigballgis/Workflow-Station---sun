import { j as s, eX as t } from "./mount-builder-CqIEWsZv.mjs";
const n = ({
  title: e,
  children: a,
  description: r
}) => /* @__PURE__ */ s.jsx(
  t,
  {
    title: e,
    description: r,
    rightContent: a,
    className: "min-w-full"
  }
);
export {
  n as D
};
