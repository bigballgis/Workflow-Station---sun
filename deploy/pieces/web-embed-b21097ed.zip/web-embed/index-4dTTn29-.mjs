import { ao as H, cO as Q, cQ as X, g as i, gV as x, jb as _, ai as q, a6 as a, j as e, gX as g, cp as T, cY as J, b9 as Y, ba as $, i as f, ca as G, bb as U, bc as j, aW as Z, cX as ee, jc as se, b7 as k, cb as O, fz as ae, ck as te, co as ne, aJ as V } from "./mount-builder-CqIEWsZv.mjs";
import { V as z } from "./variable-dialog-lOfOYVtt.mjs";
import { o as E } from "./owner-column-hooks-B1fZKL15.mjs";
const ie = async (l) => {
  try {
    await navigator.clipboard.writeText(`{{variables['${l}']}}`), V.success(a("Reference copied to clipboard"));
  } catch {
    V.error(a("Could not copy reference"));
  }
};
function ce() {
  const l = H.getProjectId(), { checkAccess: P } = Q(), r = P(X.WRITE_VARIABLE), [M, w] = i.useState(!1), [b, d] = i.useState(void 0), [o, m] = i.useState(void 0), [c, v] = i.useState([]), [D, y] = i.useState(!1), { cursor: N, limit: C, name: S, ownerEmails: u } = x.useListSearchParams(), {
    data: n,
    isLoading: R,
    refetch: h
  } = x.useVariables({
    request: {
      projectId: l,
      cursor: N,
      limit: C,
      name: S
    },
    extraKeys: [
      "variables",
      N ?? "",
      String(C),
      S ?? "",
      l
    ],
    showErrorDialog: !0
  }), { mutateAsync: p } = _.useBulkDeleteVariables(h), { data: F } = x.useVariableOwners(l), I = i.useMemo(() => {
    if (n != null && n.data)
      return u.length === 0 ? n : {
        data: n.data.filter(
          (s) => s.owner && u.includes(s.owner.email)
        ),
        next: n.next,
        previous: n.previous
      };
  }, [n, u]), A = E.useOwnerColumnFilter(
    [
      {
        type: "input",
        title: a("Name"),
        accessorKey: "name",
        icon: q
      }
    ],
    1,
    F
  ), B = E.useOwnerColumn(
    [
      {
        accessorKey: "name",
        size: 280,
        header: ({ column: s }) => /* @__PURE__ */ e.jsx(
          T,
          {
            column: s,
            title: a("Name"),
            icon: g
          }
        ),
        cell: ({ row: s }) => /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 min-w-0", children: [
          /* @__PURE__ */ e.jsx("div", { className: "shrink-0 flex items-center justify-center w-8 h-8 rounded-md bg-primary/10 text-primary", children: /* @__PURE__ */ e.jsx(g, { className: "w-4 h-4" }) }),
          /* @__PURE__ */ e.jsx("span", { className: "font-mono text-sm truncate", children: s.original.name })
        ] })
      },
      {
        accessorKey: "updated",
        size: 180,
        header: ({ column: s }) => /* @__PURE__ */ e.jsx(T, { column: s, title: a("Last updated") }),
        cell: ({ row: s }) => /* @__PURE__ */ e.jsx(J, { date: new Date(s.original.updated) })
      },
      {
        id: "actions",
        size: 60,
        cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ e.jsxs(Y, { modal: !1, children: [
          /* @__PURE__ */ e.jsx($, { asChild: !0, children: /* @__PURE__ */ e.jsx(
            f,
            {
              variant: "ghost",
              size: "sm",
              "aria-label": a("Open menu"),
              onClick: (t) => t.stopPropagation(),
              children: /* @__PURE__ */ e.jsx(G, { className: "h-4 w-4" })
            }
          ) }),
          /* @__PURE__ */ e.jsxs(U, { align: "end", className: "w-48", children: [
            /* @__PURE__ */ e.jsxs(
              j,
              {
                disabled: !r,
                onSelect: (t) => {
                  t.preventDefault(), d(s.original);
                },
                children: [
                  /* @__PURE__ */ e.jsx(Z, { className: "h-4 w-4 mr-2" }),
                  a("Edit")
                ]
              }
            ),
            /* @__PURE__ */ e.jsxs(
              j,
              {
                onSelect: (t) => {
                  t.preventDefault(), ie(s.original.name);
                },
                children: [
                  /* @__PURE__ */ e.jsx(ee, { className: "h-4 w-4 mr-2" }),
                  a("Copy reference")
                ]
              }
            ),
            /* @__PURE__ */ e.jsx(se, {}),
            /* @__PURE__ */ e.jsxs(
              j,
              {
                disabled: !r,
                className: "text-destructive focus:text-destructive",
                onSelect: (t) => {
                  t.preventDefault(), m(s.original);
                },
                children: [
                  /* @__PURE__ */ e.jsx(k, { className: "h-4 w-4 mr-2" }),
                  a("Delete")
                ]
              }
            )
          ] })
        ] }) })
      }
    ],
    2
  ), L = i.useMemo(
    () => [
      {
        render: (s, t) => /* @__PURE__ */ e.jsx(e.Fragment, { children: c.length > 0 && /* @__PURE__ */ e.jsx(
          O,
          {
            title: a("Delete variables"),
            message: a(
              "This permanently deletes the selected variables. Flows that reference them will fail at runtime."
            ),
            entityName: a("variable"),
            buttonText: a("Delete"),
            isDanger: !0,
            showToast: !0,
            open: D,
            onOpenChange: y,
            mutationFn: async () => {
              await p(c.map((W) => W.id)), t(), v([]);
            },
            children: /* @__PURE__ */ e.jsxs(
              f,
              {
                variant: "ghost",
                size: "sm",
                className: "text-destructive hover:text-destructive",
                disabled: !r,
                onClick: () => y(!0),
                children: [
                  /* @__PURE__ */ e.jsx(k, { className: "h-4 w-4 mr-1" }),
                  a("Delete"),
                  " (",
                  c.length,
                  ")"
                ]
              }
            )
          }
        ) })
      }
    ],
    [c, D, r, p]
  ), K = [
    /* @__PURE__ */ e.jsx(ae, { hasPermission: r, children: /* @__PURE__ */ e.jsxs(
      f,
      {
        disabled: !r,
        size: "sm",
        onClick: () => w(!0),
        children: [
          /* @__PURE__ */ e.jsx(te, { size: 16, className: "mr-1" }),
          a("New variable")
        ]
      }
    ) }, "new")
  ];
  return /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col w-full", children: [
    /* @__PURE__ */ e.jsx(
      ne,
      {
        emptyStateTextTitle: a("No variables yet"),
        emptyStateTextDescription: a(
          "Create one to reference a value from any step input."
        ),
        emptyStateIcon: /* @__PURE__ */ e.jsx(g, { className: "size-14" }),
        columns: B,
        page: I,
        isLoading: R,
        filters: A,
        toolbarButtons: K,
        selectColumn: !0,
        onSelectedRowsChange: v,
        bulkActions: L
      }
    ),
    /* @__PURE__ */ e.jsx(
      z,
      {
        open: M,
        onOpenChange: w,
        onSaved: () => h()
      }
    ),
    /* @__PURE__ */ e.jsx(
      z,
      {
        open: !!b,
        existing: b,
        onOpenChange: (s) => {
          s || d(void 0);
        },
        onSaved: () => {
          h(), d(void 0);
        }
      }
    ),
    /* @__PURE__ */ e.jsx(
      O,
      {
        title: a("Delete variable"),
        message: a(
          "This permanently deletes the variable. Flows that reference it will fail at runtime."
        ),
        entityName: (o == null ? void 0 : o.name) ?? "",
        isDanger: !0,
        showToast: !0,
        open: !!o,
        onOpenChange: (s) => {
          s || m(void 0);
        },
        mutationFn: async () => {
          o && (await p([o.id]), m(void 0));
        }
      }
    )
  ] });
}
export {
  ce as VariablesPage
};
