import { o as t, df as T, B as N, b as R, s as a, bJ as o, dg as D, dh as F, di as A, dj as i, m as l, l as r, dk as q, n as U, N as s, dl as u, cz as w, dm as V, dn as O } from "./mount-builder-CqIEWsZv.mjs";
var $ = /* @__PURE__ */ ((e) => (e.RSA = "RSA", e))($ || {});
const b = t({
  ...N,
  platformId: T,
  publicKey: a(),
  displayName: a(),
  /* algorithm used to generate this key pair */
  algorithm: R($)
});
t({
  limit: F().optional(),
  cursor: a().optional(),
  action: D(a()),
  projectId: D(a()),
  userId: a().optional(),
  createdBefore: a().optional(),
  createdAfter: a().optional()
});
const _ = A.pick({ email: !0, id: !0, firstName: !0, lastName: !0 });
var L = /* @__PURE__ */ ((e) => (e.FLOW_CREATED = "flow.created", e.FLOW_DELETED = "flow.deleted", e.FLOW_UPDATED = "flow.updated", e.FLOW_PUBLISHED = "flow.published", e.FLOW_ACTIVATED = "flow.activated", e.FLOW_DEACTIVATED = "flow.deactivated", e.FLOW_RUN_RESUMED = "flow.run.resumed", e.FLOW_RUN_STARTED = "flow.run.started", e.FLOW_RUN_FINISHED = "flow.run.finished", e.FLOW_RUN_RETRIED = "flow.run.retried", e.FOLDER_CREATED = "folder.created", e.FOLDER_UPDATED = "folder.updated", e.FOLDER_DELETED = "folder.deleted", e.CONNECTION_UPSERTED = "connection.upserted", e.CONNECTION_DELETED = "connection.deleted", e.VARIABLE_UPSERTED = "variable.upserted", e.VARIABLE_DELETED = "variable.deleted", e.VARIABLE_VALUE_REVEALED = "variable.value.revealed", e.USER_SIGNED_UP = "user.signed.up", e.USER_SIGNED_IN = "user.signed.in", e.USER_PASSWORD_RESET = "user.password.reset", e.USER_EMAIL_VERIFIED = "user.email.verified", e.SIGNING_KEY_CREATED = "signing.key.created", e.PROJECT_ROLE_CREATED = "project.role.created", e.PROJECT_ROLE_DELETED = "project.role.deleted", e.PROJECT_ROLE_UPDATED = "project.role.updated", e.PROJECT_RELEASE_CREATED = "project.release.created", e))(L || {});
const d = {
  ...N,
  platformId: a(),
  projectId: a().optional(),
  projectDisplayName: a().optional(),
  userId: a().optional(),
  userEmail: a().optional(),
  ip: a().optional()
}, E = t({
  connection: t({
    displayName: a(),
    externalId: a(),
    pieceName: a(),
    status: a(),
    type: a(),
    id: a(),
    created: i,
    updated: i
  }),
  project: t({
    displayName: a()
  }).optional()
}), S = t({
  ...d,
  action: l([
    r(
      "connection.deleted"
      /* CONNECTION_DELETED */
    ),
    r(
      "connection.upserted"
      /* CONNECTION_UPSERTED */
    )
  ]),
  data: E
});
t({
  ...d,
  action: r(
    "connection.upserted"
    /* CONNECTION_UPSERTED */
  ),
  data: E
});
t({
  ...d,
  action: r(
    "connection.deleted"
    /* CONNECTION_DELETED */
  ),
  data: E
});
const n = t({
  variable: t({
    id: a(),
    name: a(),
    created: i,
    updated: i
  }),
  project: t({
    displayName: a()
  }).optional()
}), g = t({
  ...d,
  action: l([
    r(
      "variable.upserted"
      /* VARIABLE_UPSERTED */
    ),
    r(
      "variable.deleted"
      /* VARIABLE_DELETED */
    ),
    r(
      "variable.value.revealed"
      /* VARIABLE_VALUE_REVEALED */
    )
  ]),
  data: n
});
t({
  ...d,
  action: r(
    "variable.upserted"
    /* VARIABLE_UPSERTED */
  ),
  data: n
});
t({
  ...d,
  action: r(
    "variable.deleted"
    /* VARIABLE_DELETED */
  ),
  data: n
});
t({
  ...d,
  action: r(
    "variable.value.revealed"
    /* VARIABLE_VALUE_REVEALED */
  ),
  data: n
});
const c = t({
  folder: q.pick({ id: !0, displayName: !0, created: !0, updated: !0 }),
  project: t({
    displayName: a()
  }).optional()
}), h = t({
  ...d,
  action: l([
    r(
      "folder.updated"
      /* FOLDER_UPDATED */
    ),
    r(
      "folder.created"
      /* FOLDER_CREATED */
    ),
    r(
      "folder.deleted"
      /* FOLDER_DELETED */
    )
  ]),
  data: c
});
t({
  ...d,
  action: r(
    "folder.created"
    /* FOLDER_CREATED */
  ),
  data: c
});
t({
  ...d,
  action: r(
    "folder.updated"
    /* FOLDER_UPDATED */
  ),
  data: c
});
t({
  ...d,
  action: r(
    "folder.deleted"
    /* FOLDER_DELETED */
  ),
  data: c
});
const p = t({
  flowRun: t({
    id: a(),
    startTime: a().nullish(),
    finishTime: a().nullish(),
    duration: U().optional(),
    triggeredBy: a().optional(),
    environment: a(),
    flowId: a(),
    flowVersionId: a(),
    stepNameToTest: a().optional(),
    flowDisplayName: a().optional(),
    status: a()
  }),
  project: t({
    displayName: a()
  }).optional()
}), C = t({
  ...d,
  action: l([
    r(
      "flow.run.started"
      /* FLOW_RUN_STARTED */
    ),
    r(
      "flow.run.finished"
      /* FLOW_RUN_FINISHED */
    ),
    r(
      "flow.run.resumed"
      /* FLOW_RUN_RESUMED */
    ),
    r(
      "flow.run.retried"
      /* FLOW_RUN_RETRIED */
    )
  ]),
  data: p
});
t({
  ...d,
  action: r(
    "flow.run.started"
    /* FLOW_RUN_STARTED */
  ),
  data: p
});
t({
  ...d,
  action: r(
    "flow.run.finished"
    /* FLOW_RUN_FINISHED */
  ),
  data: p
});
t({
  ...d,
  action: r(
    "flow.run.retried"
    /* FLOW_RUN_RETRIED */
  ),
  data: p
});
const j = t({
  ...d,
  action: r(
    "flow.created"
    /* FLOW_CREATED */
  ),
  data: t({
    flow: u.pick({ id: !0, externalId: !0, created: !0, updated: !0 }),
    project: t({
      displayName: a(),
      externalId: s(a())
    }).optional()
  })
}), P = t({
  ...d,
  action: r(
    "flow.deleted"
    /* FLOW_DELETED */
  ),
  data: t({
    flow: u.pick({ id: !0, externalId: !0, created: !0, updated: !0 }),
    flowVersion: w.pick({
      id: !0,
      displayName: !0,
      flowId: !0,
      created: !0,
      updated: !0
    }),
    project: t({
      displayName: a(),
      externalId: s(a())
    }).optional()
  })
}), k = t({
  ...d,
  action: r(
    "flow.updated"
    /* FLOW_UPDATED */
  ),
  data: t({
    flow: u.pick({ id: !0, externalId: !0, created: !0, updated: !0 }),
    flowVersion: w.pick({
      id: !0,
      displayName: !0,
      flowId: !0,
      created: !0,
      updated: !0
    }),
    request: V,
    project: t({
      displayName: a(),
      externalId: s(a())
    }).optional()
  })
}), m = t({
  flow: u.pick({ id: !0, externalId: !0, created: !0, updated: !0 }),
  flowVersion: w.pick({
    id: !0,
    displayName: !0,
    flowId: !0,
    created: !0,
    updated: !0
  }),
  project: t({
    displayName: a(),
    externalId: s(a())
  }).optional()
}), x = t({
  ...d,
  action: r(
    "flow.published"
    /* FLOW_PUBLISHED */
  ),
  data: m
}), B = t({
  ...d,
  action: r(
    "flow.activated"
    /* FLOW_ACTIVATED */
  ),
  data: m
}), M = t({
  ...d,
  action: r(
    "flow.deactivated"
    /* FLOW_DEACTIVATED */
  ),
  data: m
}), f = t({
  user: _.optional()
}), W = t({
  ...d,
  action: l([
    r(
      "user.signed.in"
      /* USER_SIGNED_IN */
    ),
    r(
      "user.password.reset"
      /* USER_PASSWORD_RESET */
    ),
    r(
      "user.email.verified"
      /* USER_EMAIL_VERIFIED */
    )
  ]),
  data: f
});
t({
  ...d,
  action: r(
    "user.signed.in"
    /* USER_SIGNED_IN */
  ),
  data: f
});
t({
  ...d,
  action: r(
    "user.password.reset"
    /* USER_PASSWORD_RESET */
  ),
  data: f
});
t({
  ...d,
  action: r(
    "user.email.verified"
    /* USER_EMAIL_VERIFIED */
  ),
  data: f
});
const H = t({
  ...d,
  action: r(
    "user.signed.up"
    /* USER_SIGNED_UP */
  ),
  data: t({
    source: l([
      r("credentials"),
      r("sso"),
      r("managed")
    ]),
    user: _.optional()
  })
}), G = t({
  ...d,
  action: l([r(
    "signing.key.created"
    /* SIGNING_KEY_CREATED */
  )]),
  data: t({
    signingKey: b.pick({
      id: !0,
      created: !0,
      updated: !0,
      displayName: !0
    })
  })
}), K = t({
  ...d,
  action: l([
    r(
      "project.role.created"
      /* PROJECT_ROLE_CREATED */
    ),
    r(
      "project.role.updated"
      /* PROJECT_ROLE_UPDATED */
    ),
    r(
      "project.role.deleted"
      /* PROJECT_ROLE_DELETED */
    )
  ]),
  data: t({
    projectRole: O.pick({
      id: !0,
      created: !0,
      updated: !0,
      name: !0,
      permissions: !0,
      platformId: !0
    })
  })
}), J = t({
  ...d,
  action: r(
    "project.release.created"
    /* PROJECT_RELEASE_CREATED */
  ),
  data: t({
    release: t({
      name: a(),
      description: s(a()),
      type: a(),
      projectId: a(),
      importedByUser: t({
        id: a(),
        email: a(),
        firstName: a(),
        status: a(),
        externalId: s(a()),
        platformId: s(a()),
        platformRole: a(),
        lastName: a(),
        created: i,
        updated: i,
        lastActiveDate: s(a()),
        imageUrl: s(a())
      }).optional()
    })
  })
}), Y = l([
  S,
  g,
  j,
  P,
  k,
  x,
  B,
  M,
  C,
  W,
  h,
  H,
  G,
  K,
  J
]);
function X(e) {
  switch (e.action) {
    case "flow.updated":
      return z(e);
    case "flow.run.started":
      return `Flow run ${e.data.flowRun.id} is started`;
    case "flow.run.finished":
      return `Flow run ${e.data.flowRun.id} is finished`;
    case "flow.run.resumed":
      return `Flow run ${e.data.flowRun.id} is resumed`;
    case "flow.run.retried":
      return `Flow run ${e.data.flowRun.id} is retried from a failed step`;
    case "flow.created":
      return `Flow ${e.data.flow.id} is created`;
    case "flow.deleted":
      return `Flow ${e.data.flow.id} (${e.data.flowVersion.displayName}) is deleted`;
    case "flow.published":
      return `Flow "${e.data.flowVersion.displayName}" was published`;
    case "flow.activated":
      return `Flow "${e.data.flowVersion.displayName}" was activated`;
    case "flow.deactivated":
      return `Flow "${e.data.flowVersion.displayName}" was deactivated`;
    case "folder.created":
      return `${e.data.folder.displayName} is created`;
    case "folder.updated":
      return `${e.data.folder.displayName} is updated`;
    case "folder.deleted":
      return `${e.data.folder.displayName} is deleted`;
    case "connection.upserted":
      return `${e.data.connection.displayName} (${e.data.connection.externalId}) is updated`;
    case "connection.deleted":
      return `${e.data.connection.displayName} (${e.data.connection.externalId}) is deleted`;
    case "variable.upserted":
      return `Variable ${e.data.variable.name} is created or updated`;
    case "variable.deleted":
      return `Variable ${e.data.variable.name} is deleted`;
    case "variable.value.revealed":
      return `Variable ${e.data.variable.name} value was revealed`;
    case "user.signed.in":
      return `User ${e.userEmail} signed in`;
    case "user.password.reset":
      return `User ${e.userEmail} reset password`;
    case "user.email.verified":
      return `User ${e.userEmail} verified email`;
    case "user.signed.up":
      return `User ${e.userEmail} signed up using email from ${e.data.source}`;
    case "signing.key.created":
      return `${e.data.signingKey.displayName} is created`;
    case "project.role.created":
      return `${e.data.projectRole.name} is created`;
    case "project.role.updated":
      return `${e.data.projectRole.name} is updated`;
    case "project.role.deleted":
      return `${e.data.projectRole.name} is deleted`;
    case "project.release.created":
      return `${e.data.release.name} is created`;
  }
}
function z(e) {
  switch (e.data.request.type) {
    case o.ADD_ACTION:
      return `Added action "${e.data.request.request.action.displayName}" to "${e.data.flowVersion.displayName}" Flow.`;
    case o.UPDATE_ACTION:
      return `Updated action "${e.data.request.request.displayName}" in "${e.data.flowVersion.displayName}" Flow.`;
    case o.DELETE_ACTION:
      return `Deleted actions "${e.data.request.request.names.join(", ")}" from "${e.data.flowVersion.displayName}" Flow.`;
    case o.CHANGE_NAME:
      return `Renamed flow "${e.data.flowVersion.displayName}" to "${e.data.request.request.displayName}".`;
    case o.LOCK_AND_PUBLISH:
      return `Locked and published flow "${e.data.flowVersion.displayName}" Flow.`;
    case o.USE_AS_DRAFT:
      return `Unlocked and unpublished flow "${e.data.flowVersion.displayName}" Flow.`;
    case o.MOVE_ACTION:
      return `Moved action "${e.data.request.request.name}" to after "${e.data.request.request.newParentStep}".`;
    case o.LOCK_FLOW:
      return `Locked flow "${e.data.flowVersion.displayName}" Flow.`;
    case o.CHANGE_STATUS:
      return `Changed status of flow "${e.data.flowVersion.displayName}" Flow to "${e.data.request.request.status}".`;
    case o.DUPLICATE_ACTION:
      return `Duplicated action "${e.data.request.request.stepName}" in "${e.data.flowVersion.displayName}" Flow.`;
    case o.IMPORT_FLOW:
      return `Imported flow in "${e.data.request.request.displayName}" Flow.`;
    case o.UPDATE_TRIGGER:
      return `Updated trigger in "${e.data.flowVersion.displayName}" Flow to "${e.data.request.request.displayName}".`;
    case o.CHANGE_FOLDER:
      return `Moved flow "${e.data.flowVersion.displayName}" to folder id ${e.data.request.request.folderId}.`;
    case o.DELETE_BRANCH:
      return `Deleted branch number ${e.data.request.request.branchIndex + 1} in flow "${e.data.flowVersion.displayName}" for the step "${e.data.request.request.stepName}".`;
    case o.SAVE_SAMPLE_DATA:
      return `Saved sample data for step "${e.data.request.request.stepName}" in flow "${e.data.flowVersion.displayName}".`;
    case o.DUPLICATE_BRANCH:
      return `Duplicated branch number ${e.data.request.request.branchIndex + 1} in flow "${e.data.flowVersion.displayName}" for the step "${e.data.request.request.stepName}".`;
    case o.ADD_BRANCH:
      return `Added branch number ${e.data.request.request.branchIndex + 1} in flow "${e.data.flowVersion.displayName}" for the step "${e.data.request.request.stepName}".`;
    case o.SET_SKIP_ACTION:
      return `Updated actions "${e.data.request.request.names.join(", ")}" in "${e.data.flowVersion.displayName}" Flow to skip.`;
    case o.UPDATE_METADATA:
      return `Updated metadata for flow "${e.data.flowVersion.displayName}".`;
    case o.UPDATE_MINUTES_SAVED:
      return `Updated minutes saved for flow "${e.data.flowVersion.displayName}".`;
    case o.UPDATE_OWNER:
      return `Updated owner for flow "${e.data.flowVersion.displayName}" to "${e.data.request.request.ownerId}".`;
    case o.MOVE_BRANCH:
      return `Moved branch number ${e.data.request.request.sourceBranchIndex + 1} to ${e.data.request.request.targetBranchIndex + 1} in flow "${e.data.flowVersion.displayName}" for the step "${e.data.request.request.stepName}".`;
    case o.ADD_NOTE:
      return `Added note to flow "${e.data.flowVersion.displayName}".`;
    case o.UPDATE_NOTE:
      return `Updated note in flow "${e.data.flowVersion.displayName}".`;
    case o.DELETE_NOTE:
      return `Deleted note in flow "${e.data.flowVersion.displayName}".`;
    case o.UPDATE_SAMPLE_DATA_INFO:
      return `Updated sample data info for step "${e.data.request.request.stepName}" in flow "${e.data.flowVersion.displayName}".`;
  }
}
export {
  L as A,
  Y as a,
  X as s
};
