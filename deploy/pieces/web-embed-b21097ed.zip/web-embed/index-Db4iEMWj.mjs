import { c as R, e as C, H as ne, b6 as N, aJ as v, a6 as a, aj as re, ew as le, dR as _, g as h, j as e, bs as Q, b_ as G, bt as Y, bu as ce, bv as $, aQ as F, aX as I, by as J, i as j, ax as oe, ay as ue, aA as de, aB as me, ex as pe, aD as ge, c6 as he, aE as q, aF as O, c7 as xe, cb as fe, b7 as je, aU as ye, I as X, a3 as k, a4 as z, ey as Pe, d9 as ve, a5 as E, be as Te, bf as Ne, dK as Ce, c0 as Se, c1 as Ae, ez as Z, eA as L, bi as S, cZ as be, c2 as Oe, c3 as U, c4 as V, c8 as w, o as we, s as B, d1 as De, ae as Fe, af as Ie, bB as ke, cp as D, cq as ze, cr as Ee, eB as Me, eC as He, cI as Re, co as _e, a9 as qe, eD as Le, eE as Ue, cn as Ve, eF as K, eG as Be } from "./mount-builder-CqIEWsZv.mjs";
import { D as Ke } from "./dashboard-page-header-BfLKPs1b.mjs";
var W = /* @__PURE__ */ ((s) => (s.OFFICIAL_AUTO = "OFFICIAL_AUTO", s.NONE = "NONE", s))(W || {});
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Qe = [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 9.9-1", key: "1mm8w8" }]
], Ge = R("lock-open", Qe);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ye = [
  ["path", { d: "M12 17v5", key: "bb1du9" }],
  ["path", { d: "M15 9.34V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H7.89", key: "znwnzq" }],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }],
  [
    "path",
    {
      d: "M9 9v1.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h11",
      key: "c9qhm2"
    }
  ]
], $e = R("pin-off", Ye);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Je = [
  ["path", { d: "M12 17v5", key: "bb1du9" }],
  [
    "path",
    {
      d: "M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z",
      key: "1nkz8b"
    }
  ]
], Xe = R("pin", Je), A = {
  upsert(s) {
    return C.post("/v1/tags", s);
  },
  list(s) {
    return C.get("/v1/tags", s);
  },
  tagPieces(s) {
    return C.post("/v1/tags/pieces", s);
  },
  delete(s) {
    return C.delete("/v1/tags/" + s);
  }
}, ee = {
  all: ["tags"]
}, Ze = {
  useTags: () => ne({
    queryKey: ee.all,
    queryFn: async () => (await A.list({ limit: 100 })).data
  })
}, M = {
  useDeleteTag: ({ onSuccess: s }) => {
    const t = re();
    return N({
      mutationFn: (n) => A.delete(n),
      onSuccess: () => {
        v.success(a("Tag deleted")), t.invalidateQueries({ queryKey: ee.all }), t.invalidateQueries({ queryKey: ["pieces"] }), s();
      }
    });
  },
  useApplyTags: ({ onSuccess: s }) => N({
    mutationFn: async ({ piecesName: t, tags: n }) => {
      await A.tagPieces({ piecesName: t, tags: n });
    },
    onSuccess: () => {
      v(a("Tags applied."), {}), s();
    }
  }),
  useCreateTag: ({
    onTagCreated: s,
    setIsOpen: t
  }) => N({
    mutationFn: (n) => A.upsert({ name: n }),
    onSuccess: (n) => {
      v.success(a("Tag created"), {
        description: a(`Tag "${n.name}" has been created successfully.`)
      }), s(n), t(!1);
    }
  })
}, H = {
  useTogglePieceVisibility: ({
    platformId: s,
    filteredPieceNames: t,
    refetch: n
  }) => N({
    mutationFn: async (c) => {
      const d = t.includes(c) ? t.filter((l) => l !== c) : [...t, c];
      await _.update(
        { filteredPieceNames: d },
        s
      ), await n();
    },
    onSuccess: () => {
      v.success(a("Your changes have been saved."), { duration: 3e3 });
    }
  }),
  useTogglePiecePin: ({
    platformId: s,
    pinnedPieces: t,
    refetch: n
  }) => N({
    mutationFn: async (c) => {
      const d = t.includes(c) ? t.filter((l) => l !== c) : [...t, c];
      await _.update({ pinnedPieces: d }, s), await n();
    },
    onSuccess: () => {
      v.success(a("Your changes have been saved."), { duration: 3e3 });
    }
  }),
  useSyncPieces: () => N({
    mutationFn: async () => {
      await le.syncFromCloud();
    },
    onSuccess: () => {
      v.success(a("Pieces synced"), {
        description: a(
          "Pieces have been synced from the activepieces cloud."
        )
      });
    }
  })
};
function We({
  onTagCreated: s,
  children: t,
  isOpen: n,
  setIsOpen: c
}) {
  const [d, l] = h.useState(""), { mutate: u, isPending: m } = M.useCreateTag({
    onTagCreated: s,
    setIsOpen: c
  }), p = (i) => {
    i.preventDefault(), d.trim() && u(d.trim());
  };
  return /* @__PURE__ */ e.jsxs(Q, { open: n, onOpenChange: (i) => c(i), children: [
    /* @__PURE__ */ e.jsx(G, { asChild: !0, children: t }),
    /* @__PURE__ */ e.jsxs(Y, { children: [
      /* @__PURE__ */ e.jsx(ce, { children: /* @__PURE__ */ e.jsx($, { children: "Create New Tag" }) }),
      /* @__PURE__ */ e.jsxs("form", { onSubmit: p, children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-4", children: [
          /* @__PURE__ */ e.jsx(F, { htmlFor: "tagName", children: a("Tag") }),
          /* @__PURE__ */ e.jsx(
            I,
            {
              id: "tagName",
              value: d,
              onChange: (i) => l(i.target.value),
              className: "col-span-3"
            }
          )
        ] }),
        /* @__PURE__ */ e.jsx(J, { children: /* @__PURE__ */ e.jsx(j, { type: "submit", loading: m, children: a("Create") }) })
      ] })
    ] })
  ] });
}
const se = ({ selectedPieces: s, onApplyTags: t }) => {
  const { data: n = [] } = Ze.useTags(), [c, d] = h.useState(!1), [l, u] = h.useState(/* @__PURE__ */ new Set()), m = h.useRef(/* @__PURE__ */ new Set()), [p, i] = h.useState(!1);
  h.useEffect(() => {
    u(
      new Set(
        n.map((r) => r.name).filter(
          (r) => s.every((f) => {
            var o;
            return (o = f.tags) == null ? void 0 : o.includes(r);
          })
        )
      )
    );
  }, [s, n]);
  const { mutate: x } = M.useApplyTags({
    onSuccess: () => t()
  }), { mutate: b } = M.useDeleteTag({
    onSuccess: () => t()
  }), [y, T] = h.useState([]);
  return h.useEffect(() => {
    T(
      n.map((r) => ({
        id: r.id,
        label: r.name,
        value: r.name
      }))
    );
  }, [n]), /* @__PURE__ */ e.jsxs(
    oe,
    {
      open: c,
      onOpenChange: (r) => {
        d(r), m.current = /* @__PURE__ */ new Set();
      },
      children: [
        /* @__PURE__ */ e.jsx(ue, { asChild: !0, children: /* @__PURE__ */ e.jsx(
          j,
          {
            variant: "ghost",
            size: "sm",
            disabled: s.length === 0,
            children: a("Apply Tags")
          }
        ) }),
        /* @__PURE__ */ e.jsx(de, { className: "w-[200px] p-0", align: "start", children: /* @__PURE__ */ e.jsx(me, { children: /* @__PURE__ */ e.jsxs(pe, { children: [
          y.length === 0 ? /* @__PURE__ */ e.jsx(ge, { children: a("No tags created.") }) : /* @__PURE__ */ e.jsx(he, { viewPortClassName: "max-h-[200px]", children: /* @__PURE__ */ e.jsx(q, { children: y.map((r) => {
            const f = l.has(r.value), o = s.some(
              (g) => {
                var P;
                return (P = g.tags) == null ? void 0 : P.includes(r.value);
              }
            ) && !s.every(
              (g) => {
                var P;
                return (P = g.tags) == null ? void 0 : P.includes(r.value);
              }
            ) && !m.current.has(r.value);
            return /* @__PURE__ */ e.jsxs(
              O,
              {
                onSelect: () => {
                  m.current.add(r.value);
                  const g = new Set(l);
                  f && !o ? g.delete(r.value) : g.add(r.value), u(g);
                },
                children: [
                  /* @__PURE__ */ e.jsx(
                    xe,
                    {
                      checked: o ? "indeterminate" : f,
                      className: "mr-2"
                    }
                  ),
                  /* @__PURE__ */ e.jsx("span", { className: "flex-grow", children: r.label }),
                  /* @__PURE__ */ e.jsx(
                    fe,
                    {
                      title: a("Delete Tag"),
                      message: a(
                        'Are you sure you want to delete the tag "{tagName}"? It will be removed from all pieces.',
                        { tagName: r.label }
                      ),
                      entityName: r.label,
                      mutationFn: async () => {
                        b(r.id), T(
                          (g) => g.filter((P) => P.id !== r.id)
                        );
                      },
                      children: /* @__PURE__ */ e.jsx(
                        "button",
                        {
                          onClick: (g) => g.stopPropagation(),
                          className: "hover:text-destructive",
                          children: /* @__PURE__ */ e.jsx(je, { className: "size-4" })
                        }
                      )
                    }
                  )
                ]
              },
              r.value
            );
          }) }) }),
          /* @__PURE__ */ e.jsx(
            We,
            {
              onTagCreated: (r) => {
                y.some((f) => f.value === r.name) || T([
                  ...y,
                  { id: r.id, label: r.name, value: r.name }
                ]);
              },
              isOpen: p,
              setIsOpen: i,
              children: /* @__PURE__ */ e.jsxs(
                O,
                {
                  className: "justify-center text-center",
                  onSelect: () => {
                    i(!0);
                  },
                  children: [
                    "+ ",
                    a("New Tag")
                  ]
                }
              )
            }
          ),
          /* @__PURE__ */ e.jsx(ye, {}),
          /* @__PURE__ */ e.jsx(q, { children: /* @__PURE__ */ e.jsx(
            O,
            {
              className: "justify-center text-center text-primary",
              onSelect: () => {
                v(a("Applying Tags..."), {}), x({
                  piecesName: s.map((r) => r.name),
                  tags: Array.from(l)
                }), d(!1);
              },
              children: a("Apply Tags")
            }
          ) })
        ] }) }) })
      ]
    }
  );
};
se.displayName = "ApplyTags";
const ae = ({ pieceName: s, isEnabled: t }) => {
  const { platform: n, refetch: c } = X.useCurrentPlatform(), { mutate: d, isPending: l } = H.useTogglePieceVisibility({
    platformId: n.id,
    filteredPieceNames: n.filteredPieceNames,
    refetch: c
  }), { mutate: u, isPending: m } = H.useTogglePiecePin({
    platformId: n.id,
    pinnedPieces: n.pinnedPieces,
    refetch: c
  }), p = n.filteredPieceNames.includes(s), i = n.pinnedPieces.includes(s);
  return /* @__PURE__ */ e.jsxs("div", { className: "flex gap-2", children: [
    /* @__PURE__ */ e.jsxs(k, { children: [
      /* @__PURE__ */ e.jsx(z, { asChild: !0, children: /* @__PURE__ */ e.jsx(
        j,
        {
          variant: "ghost",
          size: "sm",
          loading: l,
          disabled: !t,
          onClick: (x) => {
            if (!t) {
              x.preventDefault();
              return;
            }
            d(s);
          },
          children: p ? /* @__PURE__ */ e.jsx(Pe, { className: "size-4" }) : /* @__PURE__ */ e.jsx(ve, { className: "size-4" })
        }
      ) }),
      /* @__PURE__ */ e.jsx(E, { children: p ? a("Hide this piece from all projects") : a("Show this piece for all projects") })
    ] }),
    /* @__PURE__ */ e.jsxs(k, { children: [
      /* @__PURE__ */ e.jsx(z, { asChild: !0, children: /* @__PURE__ */ e.jsx(
        j,
        {
          variant: "ghost",
          size: "sm",
          loading: m,
          disabled: !t,
          onClick: (x) => {
            if (!t) {
              x.preventDefault();
              return;
            }
            u(s);
          },
          children: i ? /* @__PURE__ */ e.jsx($e, { className: "size-4" }) : /* @__PURE__ */ e.jsx(Xe, { className: "size-4" })
        }
      ) }),
      /* @__PURE__ */ e.jsx(E, { children: i ? a("Unpin this piece") : a("Pin this piece") })
    ] })
  ] });
};
ae.displayName = "PieceActions";
const te = () => {
  const { data: s } = Te.useFlag(
    Ne.PIECES_SYNC_MODE
  ), { mutate: t, isPending: n } = H.useSyncPieces();
  return /* @__PURE__ */ e.jsx(e.Fragment, { children: s === W.OFFICIAL_AUTO && /* @__PURE__ */ e.jsxs(
    j,
    {
      variant: "outline",
      onClick: () => t(),
      loading: n,
      size: "sm",
      children: [
        /* @__PURE__ */ e.jsx(Ce, { className: "w-4 h-4 mr-2" }),
        " Sync from Cloud"
      ]
    }
  ) });
};
te.displayName = "SyncPiecesButton";
const es = we({
  clientId: B().min(1),
  clientSecret: B().min(1)
}), ie = h.forwardRef(({ pieceName: s, onConfigurationDone: t, isEnabled: n }, c) => {
  var T, r, f;
  const [d, l] = h.useState(!1), u = Se({
    resolver: Ae(es)
  }), { oauth2App: m, refetch: p } = Z.useOAuthAppConfigured(s), { mutate: i, isPending: x } = L.useDeleteOAuthApp(p, l), { mutate: b, isPending: y } = L.useUpsertOAuthApp(p, l, t);
  return /* @__PURE__ */ e.jsxs(
    Q,
    {
      open: d,
      onOpenChange: (o) => {
        o || u.reset(), l(o);
      },
      children: [
        /* @__PURE__ */ e.jsx(G, { asChild: !0, children: /* @__PURE__ */ e.jsxs(k, { children: [
          /* @__PURE__ */ e.jsx(z, { asChild: !0, children: /* @__PURE__ */ e.jsx(
            j,
            {
              ref: c,
              size: "sm",
              variant: "ghost",
              loading: y || x,
              disabled: !n,
              onClick: (o) => {
                if (!n) {
                  o.preventDefault();
                  return;
                }
                S(m) ? l(!0) : (i(m.id), t()), o.preventDefault(), o.stopPropagation();
              },
              children: S(m) ? /* @__PURE__ */ e.jsx(Ge, { className: "size-4" }) : /* @__PURE__ */ e.jsx(be, { className: "size-4 text-destructive" })
            }
          ) }),
          /* @__PURE__ */ e.jsx(E, { children: S(m) ? a("Configure OAuth2 App") : a("Delete OAuth2 App") })
        ] }) }),
        /* @__PURE__ */ e.jsxs(Y, { children: [
          /* @__PURE__ */ e.jsx($, { children: a("Configure OAuth2 App") }),
          /* @__PURE__ */ e.jsx(Oe, { ...u, children: /* @__PURE__ */ e.jsxs(
            "form",
            {
              className: "grid space-y-4 mt-4",
              onSubmit: u.handleSubmit((o) => {
                b({
                  clientId: o.clientId,
                  clientSecret: o.clientSecret,
                  pieceName: s
                });
              }),
              children: [
                /* @__PURE__ */ e.jsx(
                  U,
                  {
                    name: "clientId",
                    render: ({ field: o }) => /* @__PURE__ */ e.jsxs(V, { className: "grid space-y-4", children: [
                      /* @__PURE__ */ e.jsx(F, { htmlFor: "clientId", showRequiredIndicator: !0, children: a("Client ID") }),
                      /* @__PURE__ */ e.jsx(
                        I,
                        {
                          ...o,
                          required: !0,
                          id: "clientId",
                          className: "rounded-sm"
                        }
                      ),
                      /* @__PURE__ */ e.jsx(w, {})
                    ] })
                  }
                ),
                /* @__PURE__ */ e.jsx(
                  U,
                  {
                    name: "clientSecret",
                    render: ({ field: o }) => /* @__PURE__ */ e.jsxs(V, { className: "grid space-y-4", children: [
                      /* @__PURE__ */ e.jsx(F, { htmlFor: "clientSecret", showRequiredIndicator: !0, children: a("Client Secret") }),
                      /* @__PURE__ */ e.jsx(
                        I,
                        {
                          ...o,
                          required: !0,
                          id: "clientSecret",
                          className: "rounded-sm",
                          type: "password"
                        }
                      ),
                      /* @__PURE__ */ e.jsx(w, {})
                    ] })
                  }
                ),
                ((f = (r = (T = u == null ? void 0 : u.formState) == null ? void 0 : T.errors) == null ? void 0 : r.root) == null ? void 0 : f.serverError) && /* @__PURE__ */ e.jsx(w, { children: u.formState.errors.root.serverError.message }),
                /* @__PURE__ */ e.jsxs(J, { children: [
                  /* @__PURE__ */ e.jsx(j, { variant: "outline", onClick: () => l(!1), children: a("Cancel") }),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      loading: y,
                      disabled: !u.formState.isValid,
                      type: "submit",
                      children: a("Save")
                    }
                  )
                ] })
              ]
            }
          ) })
        ] })
      ]
    }
  );
});
ie.displayName = "ConfigurePieceOAuth2Dialog";
const ss = () => {
  const { platform: s } = X.useCurrentPlatform(), t = s.plan.managePiecesEnabled, [n] = De(), c = n.get("name") ?? "", {
    pieces: d,
    refetch: l,
    isLoading: u
  } = Fe.usePieces({
    searchQuery: c,
    includeTags: !0,
    includeHidden: !0,
    isTableQuery: !0
  }), { refetch: m } = Z.usePiecesOAuth2AppsMap(), p = h.useMemo(
    () => [
      {
        accessorKey: "displayName",
        size: 300,
        header: ({ column: i }) => /* @__PURE__ */ e.jsx(
          D,
          {
            column: i,
            title: a("Name"),
            icon: ze
          }
        ),
        cell: ({ row: i }) => /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ e.jsx(
            Ie,
            {
              size: "sm",
              border: !0,
              displayName: i.original.displayName,
              logoUrl: i.original.logoUrl,
              showTooltip: !1
            }
          ),
          /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-0.5", children: [
            /* @__PURE__ */ e.jsx("span", { children: i.original.displayName }),
            i.original.tags && i.original.tags.length > 0 && /* @__PURE__ */ e.jsx("div", { className: "flex gap-1", children: i.original.tags.map((x) => /* @__PURE__ */ e.jsx(
              ke,
              {
                variant: "outline",
                className: "text-xs py-0 px-1.5",
                children: x
              },
              x
            )) })
          ] })
        ] })
      },
      {
        accessorKey: "packageName",
        size: 250,
        header: ({ column: i }) => /* @__PURE__ */ e.jsx(
          D,
          {
            column: i,
            title: a("Package Name"),
            icon: Ee
          }
        ),
        cell: ({ row: i }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: i.original.name })
      },
      {
        accessorKey: "version",
        size: 80,
        header: ({ column: i }) => /* @__PURE__ */ e.jsx(
          D,
          {
            column: i,
            title: a("Version"),
            icon: Me
          }
        ),
        cell: ({ row: i }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: i.original.version })
      },
      {
        id: "actions",
        size: 80,
        cell: ({ row: i }) => /* @__PURE__ */ e.jsxs("div", { className: "flex justify-end", children: [
          as(i.original) && /* @__PURE__ */ e.jsx(
            ie,
            {
              pieceName: i.original.name,
              onConfigurationDone: () => {
                l(), m();
              },
              isEnabled: t
            }
          ),
          /* @__PURE__ */ e.jsx(
            ae,
            {
              pieceName: i.original.name,
              isEnabled: t
            }
          )
        ] })
      }
    ],
    []
  );
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(
      Ke,
      {
        description: a("Manage the pieces that are available to your users"),
        title: a("Pieces")
      }
    ),
    /* @__PURE__ */ e.jsxs("div", { className: "mx-auto w-full flex flex-col flex-1 min-h-0", children: [
      !t && /* @__PURE__ */ e.jsx(
        He,
        {
          title: a("Control Pieces"),
          description: a(
            "Show the pieces that matter most to your users and hide the ones you don't like."
          ),
          button: /* @__PURE__ */ e.jsx(
            Re,
            {
              featureKey: "ENTERPRISE_PIECES",
              buttonVariant: "basic"
            }
          )
        }
      ),
      /* @__PURE__ */ e.jsx(
        _e,
        {
          emptyStateTextTitle: a("No pieces found"),
          emptyStateTextDescription: a(
            "Start by installing pieces that you want to use in your automations"
          ),
          emptyStateIcon: /* @__PURE__ */ e.jsx(Ve, { className: "size-14" }),
          columns: p,
          filters: [
            {
              type: "input",
              title: a("Piece Name"),
              accessorKey: "name",
              icon: qe
            }
          ],
          page: {
            data: d ?? [],
            next: null,
            previous: null
          },
          isLoading: u,
          bulkActions: [
            {
              render: (i) => /* @__PURE__ */ e.jsx(
                se,
                {
                  selectedPieces: i,
                  onApplyTags: () => l()
                }
              )
            }
          ],
          toolbarButtons: [
            /* @__PURE__ */ e.jsx(te, {}, "sync"),
            /* @__PURE__ */ e.jsx(
              Le,
              {
                onInstallPiece: () => l(),
                scope: Ue.PLATFORM
              },
              "install"
            )
          ],
          selectColumn: !0,
          virtualizeRows: !0,
          hidePagination: !0
        }
      )
    ] })
  ] });
};
ss.displayName = "PlatformPiecesPage";
function as(s) {
  const t = Array.isArray(s.auth) ? s.auth.find((n) => n.type === K.OAUTH2) : s.auth;
  return !(S(t) || t.type !== K.OAUTH2 || t.grantType === Be.CLIENT_CREDENTIALS);
}
export {
  ss as PlatformPiecesPage
};
