import { a1 as b, g as c, ae as f, bi as w, j as e, an as N, bs as O, b_ as T, bt as S, bu as y, bv as P, a6 as i, aX as R, c6 as E, by as L, gO as k, i as D, a3 as F, a4 as A, am as B, a5 as H, eU as M } from "./mount-builder-CqIEWsZv.mjs";
const U = b.memo(
  ({
    onConnectionCreated: a,
    children: h,
    isGlobalConnection: d
  }) => {
    const [n, l] = c.useState(!1), [r, x] = c.useState(!1), [p, m] = c.useState(void 0), { pieces: o, isLoading: u } = f.usePieces({}), [j, C] = c.useState(""), g = o == null ? void 0 : o.filter((s) => !w(s.auth) && s.displayName.toLowerCase().includes(j.toLowerCase())), v = (s) => {
      l(!1), m(o == null ? void 0 : o.find((t) => t.name === s)), x(!0);
    };
    return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
      p && /* @__PURE__ */ e.jsx(
        N,
        {
          reconnectConnection: null,
          piece: p,
          open: r,
          isGlobalConnection: d,
          setOpen: (s, t) => {
            x(s), t && a(t);
          }
        },
        `CreateOrEditConnectionDialog-open-${r}`
      ),
      /* @__PURE__ */ e.jsxs(
        O,
        {
          open: n,
          onOpenChange: (s) => {
            l(s), C("");
          },
          children: [
            /* @__PURE__ */ e.jsx(T, { asChild: !0, children: h }),
            /* @__PURE__ */ e.jsxs(S, { className: "min-w-[700px] max-w-[700px] h-[680px] max-h-[680px] flex flex-col", children: [
              /* @__PURE__ */ e.jsx(y, { children: /* @__PURE__ */ e.jsx(P, { children: i("New Connection") }) }),
              /* @__PURE__ */ e.jsx("div", { className: "mb-4", children: /* @__PURE__ */ e.jsx(
                R,
                {
                  placeholder: i("Search"),
                  value: j,
                  onChange: (s) => C(s.target.value)
                }
              ) }),
              /* @__PURE__ */ e.jsx(E, { className: "grow overflow-y-auto ", children: /* @__PURE__ */ e.jsxs("div", { className: "grid grid-cols-4 gap-4", children: [
                (u || g && g.length === 0) && /* @__PURE__ */ e.jsx("div", { className: "text-center", children: i("No pieces found") }),
                !u && g && g.map((s, t) => /* @__PURE__ */ e.jsxs(
                  "div",
                  {
                    onClick: () => v(s.name),
                    className: "border p-2 h-[150px] w-[150px] flex flex-col items-center justify-center hover:bg-accent hover:text-accent-foreground cursor-pointer rounded-lg",
                    children: [
                      /* @__PURE__ */ e.jsx(
                        "img",
                        {
                          className: "w-[40px] h-[40px]",
                          src: s.logoUrl
                        }
                      ),
                      /* @__PURE__ */ e.jsx("div", { className: "mt-2 text-center text-md", children: s.displayName })
                    ]
                  },
                  t
                ))
              ] }) }),
              /* @__PURE__ */ e.jsx(L, { children: /* @__PURE__ */ e.jsx(k, { asChild: !0, children: /* @__PURE__ */ e.jsx(D, { type: "button", variant: "ghost", children: i("Close") }) }) })
            ] })
          ]
        }
      )
    ] });
  }
);
U.displayName = "NewConnectionDialog";
const G = ({
  connection: a,
  onConnectionCreated: h,
  hasPermission: d
}) => {
  const [n, l] = c.useState(!1), { pieceModel: r, isLoading: x } = f.usePiece({
    name: a.pieceName,
    version: a.pieceVersion,
    enabled: n
  });
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsxs(F, { children: [
      /* @__PURE__ */ e.jsx(A, { asChild: !0, children: /* @__PURE__ */ e.jsx(
        D,
        {
          onClick: () => l(!0),
          disabled: !d,
          variant: "ghost",
          children: /* @__PURE__ */ e.jsx(B, { className: "h-4 w-4" })
        }
      ) }),
      /* @__PURE__ */ e.jsx(H, { children: d ? /* @__PURE__ */ e.jsx("p", { children: i("Reconnect") }) : /* @__PURE__ */ e.jsx("p", { children: i("Permission needed") }) })
    ] }),
    n && !x && r && /* @__PURE__ */ e.jsx(
      N,
      {
        reconnectConnection: a,
        isGlobalConnection: a.scope === M.PLATFORM,
        piece: r,
        open: n,
        setOpen: (p, m) => {
          l(p), m && h();
        }
      },
      `CreateOrEditConnectionDialog-open-${n}`
    )
  ] });
};
export {
  U as N,
  G as R
};
