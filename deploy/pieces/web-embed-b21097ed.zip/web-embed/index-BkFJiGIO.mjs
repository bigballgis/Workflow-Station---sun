import { e as m, H as b, g as x, c0 as f, c1 as I, b6 as A, j as e, bs as N, b_ as v, bt as k, bu as C, bv as P, a6 as s, bw as D, d4 as K, by as h, i as d, c2 as w, c3 as F, c4 as T, c5 as z, aX as S, c8 as M, o as E, s as q, I as L, bC as R, ch as U, ci as H, bj as O, bk as V, bl as B, bm as G, bp as Q, D as j, bq as $, b9 as X, ba as _, az as J, bb as W, cb as Y, bc as Z, cc as ee, cP as se, cj as ae, ck as te } from "./mount-builder-CqIEWsZv.mjs";
import { C as ie } from "./centered-page-C5JGBrkC.mjs";
import { K as y } from "./key-m_VycdsK.mjs";
const u = {
  list() {
    return m.get("/v1/api-keys");
  },
  delete(i) {
    return m.delete(`/v1/api-keys/${i}`);
  },
  create(i) {
    return m.post("/v1/api-keys/", i);
  }
}, ne = {
  all: ["api-keys"]
}, re = {
  useApiKeys: () => b({
    queryKey: ne.all,
    gcTime: 0,
    staleTime: 0,
    queryFn: () => u.list()
  })
}, oe = E({
  displayName: q().min(1, s("Name is required"))
}), le = ({
  children: i,
  onCreate: o
}) => {
  const [l, r] = x.useState(!1), [a, t] = x.useState(
    void 0
  ), n = f({
    resolver: I(oe)
  }), { mutate: g, isPending: p } = A({
    mutationFn: () => u.create(n.getValues()),
    onSuccess: (c) => {
      t(c), o();
    }
  });
  return /* @__PURE__ */ e.jsxs(
    N,
    {
      open: l,
      onOpenChange: (c) => {
        r(c), n.reset();
      },
      children: [
        /* @__PURE__ */ e.jsx(v, { asChild: !0, children: i }),
        /* @__PURE__ */ e.jsxs(k, { children: [
          /* @__PURE__ */ e.jsxs(C, { children: [
            /* @__PURE__ */ e.jsx(P, { children: a ? s("API Key Created") : s("Create API Key") }),
            !a && /* @__PURE__ */ e.jsx(D, { children: s(
              "Create a new API key for programmatic access to the platform."
            ) })
          ] }),
          a && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
            /* @__PURE__ */ e.jsx("div", { className: "p-4", children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-start gap-2", children: [
              /* @__PURE__ */ e.jsxs("span", { className: "text-md", children: [
                s(
                  "Please save this secret key somewhere safe and accessible. For security reasons,"
                ),
                " ",
                /* @__PURE__ */ e.jsx("span", { className: "font-semibold", children: s(
                  "you won't be able to view it again after closing this dialog."
                ) })
              ] }),
              /* @__PURE__ */ e.jsx(
                K,
                {
                  useInput: !0,
                  textToCopy: a.value,
                  fileName: `${a.displayName}`
                }
              )
            ] }) }),
            /* @__PURE__ */ e.jsx(h, { children: /* @__PURE__ */ e.jsx(
              d,
              {
                variant: "accent",
                onClick: () => {
                  t(void 0), r(!1);
                },
                type: "button",
                children: s("Done")
              }
            ) })
          ] }),
          !a && /* @__PURE__ */ e.jsx(w, { ...n, children: /* @__PURE__ */ e.jsxs(
            "form",
            {
              className: "grid space-y-4",
              onSubmit: n.handleSubmit(() => g()),
              children: [
                /* @__PURE__ */ e.jsx(
                  F,
                  {
                    control: n.control,
                    name: "displayName",
                    render: ({ field: c }) => /* @__PURE__ */ e.jsxs(T, { className: "grid space-y-4", children: [
                      /* @__PURE__ */ e.jsx(z, { children: s("Name") }),
                      /* @__PURE__ */ e.jsx(
                        S,
                        {
                          ...c,
                          required: !0,
                          placeholder: s("API Key Name"),
                          className: "rounded-sm"
                        }
                      ),
                      /* @__PURE__ */ e.jsx(M, {})
                    ] })
                  }
                ),
                /* @__PURE__ */ e.jsxs(h, { children: [
                  /* @__PURE__ */ e.jsx(
                    d,
                    {
                      variant: "outline",
                      type: "button",
                      onClick: () => r(!1),
                      children: s("Cancel")
                    }
                  ),
                  /* @__PURE__ */ e.jsx(d, { disabled: p, loading: p, children: s("Create") })
                ] })
              ]
            }
          ) })
        ] })
      ]
    }
  );
}, ce = () => {
  const { platform: i } = L.useCurrentPlatform(), { data: o, isLoading: l, refetch: r } = re.useApiKeys(), a = (o == null ? void 0 : o.data) ?? [];
  return /* @__PURE__ */ e.jsx(
    R,
    {
      featureKey: "API",
      locked: !i.plan.apiKeysEnabled,
      lockTitle: s("Enable API Keys"),
      lockDescription: s(
        "Create and manage API keys to access Activepieces APIs."
      ),
      lockVideoUrl: "/ap-cdn/videos/showcase/api-keys.mp4",
      children: /* @__PURE__ */ e.jsxs(
        ie,
        {
          title: s("API Keys"),
          description: s("Manage API keys to access Activepieces APIs."),
          actions: /* @__PURE__ */ e.jsx(le, { onCreate: () => r(), children: /* @__PURE__ */ e.jsx(ae, { icon: te, iconSize: 16, size: "sm", children: s("New API Key") }) }),
          children: [
            l && /* @__PURE__ */ e.jsx(U, { numberOfItems: 3, className: "w-full h-[72px]" }),
            !l && a.length === 0 && /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col items-center gap-3 py-12 text-muted-foreground", children: [
              /* @__PURE__ */ e.jsx(y, { className: "size-10" }),
              /* @__PURE__ */ e.jsx("p", { className: "text-sm", children: s("No API keys yet. Create one to get started.") })
            ] }),
            !l && a.length > 0 && /* @__PURE__ */ e.jsx(H, { className: "gap-2", children: a.map((t) => /* @__PURE__ */ e.jsxs(O, { variant: "outline", size: "sm", children: [
              /* @__PURE__ */ e.jsx(V, { variant: "icon", children: /* @__PURE__ */ e.jsx(y, {}) }),
              /* @__PURE__ */ e.jsxs(B, { children: [
                /* @__PURE__ */ e.jsx(G, { children: t.displayName }),
                /* @__PURE__ */ e.jsxs(Q, { className: "text-xs", children: [
                  /* @__PURE__ */ e.jsxs("span", { className: "font-mono", children: [
                    "sk-...",
                    t.truncatedValue
                  ] }),
                  " · ",
                  s("Created"),
                  " ",
                  j.formatDateToAgo(new Date(t.created)),
                  t.lastUsedAt ? /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
                    " ",
                    "· ",
                    s("Last used"),
                    " ",
                    j.formatDateToAgo(
                      new Date(t.lastUsedAt)
                    )
                  ] }) : /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
                    " · ",
                    s("Never used")
                  ] })
                ] })
              ] }),
              /* @__PURE__ */ e.jsx($, { children: /* @__PURE__ */ e.jsxs(X, { modal: !0, children: [
                /* @__PURE__ */ e.jsx(_, { asChild: !0, children: /* @__PURE__ */ e.jsx(d, { variant: "ghost", size: "sm", className: "size-8 p-0", children: /* @__PURE__ */ e.jsx(J, { className: "size-4" }) }) }),
                /* @__PURE__ */ e.jsx(W, { align: "end", children: /* @__PURE__ */ e.jsx(
                  Y,
                  {
                    title: s("Revoke API Key"),
                    message: s(
                      "Revoking this API key will immediately break any integrations using it. This action cannot be undone."
                    ),
                    entityName: s("API Key"),
                    buttonText: s("Revoke"),
                    mutationFn: async () => {
                      await u.delete(t.id), r();
                    },
                    onError: () => se(),
                    children: /* @__PURE__ */ e.jsxs(
                      Z,
                      {
                        className: "text-destructive focus:text-destructive",
                        onSelect: (n) => n.preventDefault(),
                        children: [
                          /* @__PURE__ */ e.jsx(ee, { className: "size-4 mr-2 text-destructive" }),
                          s("Revoke API Key")
                        ]
                      }
                    )
                  }
                ) })
              ] }) })
            ] }, t.id)) })
          ]
        }
      )
    }
  );
};
ce.displayName = "ApiKeysPage";
export {
  ce as ApiKeysPage
};
