import { H as m, b8 as n, bi as i, j as s, j$ as u, k0 as f } from "./mount-builder-CqIEWsZv.mjs";
import { h, A as y, U as c } from "./ap-form-Bh-hHJgV.mjs";
import { u as p } from "./useSearchParam-BZbdFdZp.mjs";
const F = {
  form: (r) => ["form", r]
}, d = {
  useForm: (r, e, o) => m({
    queryKey: F.form(r),
    queryFn: () => h.getForm(r, e),
    enabled: o,
    retry: !1,
    staleTime: 1 / 0
  })
}, x = () => {
  const { flowId: r } = n(), e = p(c) === "true", {
    data: o,
    isLoading: t,
    isError: a
  } = d.useForm(r, e, !i(r));
  return /* @__PURE__ */ s.jsxs(s.Fragment, { children: [
    t && /* @__PURE__ */ s.jsx(u, {}),
    a && /* @__PURE__ */ s.jsx(
      f,
      {
        title: "Hmm... this form isn't here",
        description: "The form you're looking for isn't here or maybe hasn't been published by the owner yet"
      }
    ),
    o && !t && /* @__PURE__ */ s.jsx(y, { form: o, useDraft: e })
  ] });
};
export {
  x as FormPage
};
