import { c as Y, dZ as Z, j as e, bk as J, g as w, d_ as k, ax as Q, ay as X, aA as $, a6 as r, aQ as E, aX as g, dB as K, dC as G, dD as z, dE as V, dF as _, i as b, dT as ee, K as u, c3 as j, c4 as v, c5 as y, aW as O, c9 as A, c8 as p, cT as se, d$ as ae, al as re, ct as le, b7 as te, a3 as ne, a4 as oe, e0 as ie, a5 as ce, bs as de, e1 as M, c0 as ue, c1 as me, bi as R, b6 as he, e2 as xe, e3 as H, b_ as je, bt as pe, bu as ge, bv as ve, c2 as ye, c6 as Ae, dW as be, by as fe, o as S, e4 as Ne, e5 as Ie, l as F, s as I, e6 as Pe, e7 as Ce, e8 as Se, e9 as Ee, ea as we, eb as Fe, m as W, ec as Te, ed as De, ee as Ue, ef as ke, eg as Oe, eh as Re, bj as Me, bl as Ke, bm as Ge, bp as ze, bq as Ve, cb as _e, cc as qe, J as He, at as We, I as Be, ei as B, bC as Le, cS as Ye } from "./mount-builder-CqIEWsZv.mjs";
import { C as Ze } from "./centered-page-C5JGBrkC.mjs";
import { M as Je } from "./message-square-ukP9go3c.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Qe = [
  ["path", { d: "M21 5H3", key: "1fi0y6" }],
  ["path", { d: "M15 12H3", key: "6jk70r" }],
  ["path", { d: "M17 19H3", key: "z6ezky" }]
], Xe = Y("text-align-start", Qe);
function $e({ src: a, alt: l }) {
  const o = Z.useAverageColorInImage({
    imgUrl: a,
    transparency: 10
  });
  return /* @__PURE__ */ e.jsx(
    J,
    {
      variant: "icon",
      style: o ? { backgroundColor: o } : void 0,
      children: /* @__PURE__ */ e.jsx("img", { src: a, alt: l, className: "size-6" })
    }
  );
}
const es = [
  { label: "US East (N. Virginia) [us-east-1]", value: "us-east-1" },
  { label: "US East (Ohio) [us-east-2]", value: "us-east-2" },
  { label: "US West (Oregon) [us-west-2]", value: "us-west-2" },
  { label: "Asia Pacific (Hyderabad) [ap-south-2]", value: "ap-south-2" },
  { label: "Asia Pacific (Mumbai) [ap-south-1]", value: "ap-south-1" },
  { label: "Asia Pacific (Osaka) [ap-northeast-3]", value: "ap-northeast-3" },
  { label: "Asia Pacific (Seoul) [ap-northeast-2]", value: "ap-northeast-2" },
  {
    label: "Asia Pacific (Singapore) [ap-southeast-1]",
    value: "ap-southeast-1"
  },
  { label: "Asia Pacific (Sydney) [ap-southeast-2]", value: "ap-southeast-2" },
  { label: "Asia Pacific (Tokyo) [ap-northeast-1]", value: "ap-northeast-1" },
  { label: "Canada (Central) [ca-central-1]", value: "ca-central-1" },
  { label: "Europe (Frankfurt) [eu-central-1]", value: "eu-central-1" },
  { label: "Europe (Ireland) [eu-west-1]", value: "eu-west-1" },
  { label: "Europe (London) [eu-west-2]", value: "eu-west-2" },
  { label: "Europe (Milan) [eu-south-1]", value: "eu-south-1" },
  { label: "Europe (Paris) [eu-west-3]", value: "eu-west-3" },
  { label: "Europe (Spain) [eu-south-2]", value: "eu-south-2" },
  { label: "Europe (Stockholm) [eu-north-1]", value: "eu-north-1" },
  { label: "Europe (Zurich) [eu-central-2]", value: "eu-central-2" },
  { label: "South America (São Paulo) [sa-east-1]", value: "sa-east-1" }
], q = ({
  initialData: a,
  onSubmit: l,
  children: o
}) => {
  const [t, c] = w.useState(!1), d = {
    modelId: "",
    modelName: "",
    modelType: k.TEXT
  }, [n, m] = w.useState(
    a || d
  ), x = (i) => {
    i.preventDefault(), i.stopPropagation(), l(n), a || m(d), c(!1);
  };
  return /* @__PURE__ */ e.jsxs(Q, { open: t, onOpenChange: c, children: [
    /* @__PURE__ */ e.jsx(X, { asChild: !0, children: o }),
    /* @__PURE__ */ e.jsx($, { className: "w-80", children: /* @__PURE__ */ e.jsxs("div", { className: "grid gap-4", children: [
      /* @__PURE__ */ e.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ e.jsx("h4", { className: "font-medium leading-none", children: a ? r("Edit Model") : r("Add Model") }),
        /* @__PURE__ */ e.jsx("p", { className: "text-sm text-muted-foreground", children: r("Configure the model settings") })
      ] }),
      /* @__PURE__ */ e.jsxs("form", { onSubmit: x, className: "space-y-4", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ e.jsx(E, { htmlFor: "modelId", children: r("Model ID") }),
          /* @__PURE__ */ e.jsx(
            g,
            {
              id: "modelId",
              value: n.modelId,
              onChange: (i) => m({ ...n, modelId: i.target.value }),
              placeholder: "e.g., gpt-4",
              required: !0
            }
          )
        ] }),
        /* @__PURE__ */ e.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ e.jsx(E, { htmlFor: "modelName", children: r("Model Name") }),
          /* @__PURE__ */ e.jsx(
            g,
            {
              id: "modelName",
              value: n.modelName,
              onChange: (i) => m({ ...n, modelName: i.target.value }),
              placeholder: "e.g., GPT-4",
              required: !0
            }
          )
        ] }),
        /* @__PURE__ */ e.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ e.jsx(E, { htmlFor: "modelType", children: r("Model Type") }),
          /* @__PURE__ */ e.jsxs(
            K,
            {
              value: n.modelType,
              onValueChange: (i) => m({
                ...n,
                modelType: i
              }),
              children: [
                /* @__PURE__ */ e.jsx(G, { id: "modelType", children: /* @__PURE__ */ e.jsx(z, { placeholder: "Select model type" }) }),
                /* @__PURE__ */ e.jsx(V, { children: Object.values(k).map((i) => /* @__PURE__ */ e.jsx(_, { value: i, children: i }, i)) })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ e.jsxs("div", { className: "flex justify-end gap-2", children: [
          /* @__PURE__ */ e.jsx(
            b,
            {
              type: "button",
              variant: "outline",
              onClick: () => c(!1),
              children: r("Cancel")
            }
          ),
          /* @__PURE__ */ e.jsx(b, { type: "submit", children: a ? r("Update") : r("Add") })
        ] })
      ] })
    ] }) })
  ] });
};
q.displayName = "ModelFormPopover";
const ss = ({
  form: a,
  provider: l,
  apiKeyRequired: o = !0,
  isLoading: t,
  isEditMode: c = !1
}) => {
  const { fields: d, append: n, remove: m, update: x } = ee({
    control: a.control,
    name: "config.models"
  }), [i, f] = w.useState(!c), [N, D] = w.useState(
    !c
  );
  return /* @__PURE__ */ e.jsxs("div", { className: "grid space-y-4", children: [
    l !== u.BEDROCK && /* @__PURE__ */ e.jsx(
      j,
      {
        control: a.control,
        name: "auth.apiKey",
        render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
          /* @__PURE__ */ e.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "apiKey", children: l === u.CLOUDFLARE_GATEWAY ? r("AI Gateway Token") : r("API Key") }),
            !i && /* @__PURE__ */ e.jsxs(
              b,
              {
                type: "button",
                variant: "basic",
                size: "sm",
                onClick: () => f(!0),
                disabled: t,
                children: [
                  /* @__PURE__ */ e.jsx(O, { className: "h-4 w-4 mr-2" }),
                  r("Edit")
                ]
              }
            )
          ] }),
          i && /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
            g,
            {
              ...s,
              required: o,
              id: "apiKey",
              placeholder: "sk_************************",
              disabled: t
            }
          ) }),
          /* @__PURE__ */ e.jsx(p, {})
        ] })
      }
    ),
    l === u.AZURE && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.resourceName",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "resourceName", children: r("Resource Name") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                required: !0,
                id: "resourceName",
                placeholder: "your-resource-name",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.apiVersion",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "apiVersion", children: r("API Version") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                value: s.value ?? "",
                id: "apiVersion",
                placeholder: "2024-10-21",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(se, { children: r(
              "Optional. Leave empty to use the default. Some Azure resources require a different version, e.g. 2023-03-15-preview."
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      )
    ] }),
    l === u.CLOUDFLARE_GATEWAY && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.accountId",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "accountId", children: r("Account ID") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                required: !0,
                id: "accountId",
                placeholder: "your-account-id",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.gatewayId",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "gatewayId", children: r("Gateway ID") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                required: !0,
                id: "gatewayId",
                placeholder: "your-gateway-id",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.vertexRegion",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "vertexRegion", children: r("Google Vertex Project Region") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                id: "vertexRegion",
                placeholder: "global",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.vertexProject",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "vertexProjectId", children: r("Google Vertex Project ID") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                id: "vertexProjectId",
                placeholder: "project-1234",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      )
    ] }),
    l === u.BEDROCK && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
      !N && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ e.jsx(E, { className: "text-sm font-medium", children: r("AWS Credentials") }),
        /* @__PURE__ */ e.jsxs(
          b,
          {
            type: "button",
            variant: "basic",
            size: "sm",
            onClick: () => D(!0),
            disabled: t,
            children: [
              /* @__PURE__ */ e.jsx(O, { className: "h-4 w-4 mr-2" }),
              r("Edit")
            ]
          }
        )
      ] }),
      N && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
        /* @__PURE__ */ e.jsx(
          j,
          {
            control: a.control,
            name: "auth.accessKeyId",
            render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
              /* @__PURE__ */ e.jsx(y, { htmlFor: "accessKeyId", children: r("AWS Access Key ID") }),
              /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
                g,
                {
                  ...s,
                  required: o,
                  id: "accessKeyId",
                  placeholder: "AKIA************",
                  disabled: t
                }
              ) }),
              /* @__PURE__ */ e.jsx(p, {})
            ] })
          }
        ),
        /* @__PURE__ */ e.jsx(
          j,
          {
            control: a.control,
            name: "auth.secretAccessKey",
            render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
              /* @__PURE__ */ e.jsx(y, { htmlFor: "secretAccessKey", children: r("AWS Secret Access Key") }),
              /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
                g,
                {
                  ...s,
                  type: "password",
                  required: o,
                  id: "secretAccessKey",
                  placeholder: "****************************************",
                  disabled: t
                }
              ) }),
              /* @__PURE__ */ e.jsx(p, {})
            ] })
          }
        )
      ] }),
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.region",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "region", children: r("AWS Region") }),
            /* @__PURE__ */ e.jsxs(
              K,
              {
                value: s.value,
                onValueChange: s.onChange,
                disabled: t,
                children: [
                  /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(G, { id: "region", children: /* @__PURE__ */ e.jsx(z, { placeholder: r("Select a region") }) }) }),
                  /* @__PURE__ */ e.jsx(V, { children: es.map((h) => /* @__PURE__ */ e.jsx(_, { value: h.value, children: h.label }, h.value)) })
                ]
              }
            ),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      )
    ] }),
    l === u.CUSTOM && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.baseUrl",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "baseUrl", children: r("Base URL") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                required: !0,
                id: "baseUrl",
                placeholder: "your-base-url",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.apiKeyHeader",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { className: "grid space-y-3", children: [
            /* @__PURE__ */ e.jsx(y, { htmlFor: "apiKeyHeader", children: r("API Key Header") }),
            /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
              g,
              {
                ...s,
                required: !0,
                id: "apiKeyHeader",
                placeholder: "your-api-key-header",
                disabled: t
              }
            ) }),
            /* @__PURE__ */ e.jsx(p, {})
          ] })
        }
      ),
      /* @__PURE__ */ e.jsx(
        j,
        {
          control: a.control,
          name: "config.defaultHeaders",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs("div", { className: "space-y-3", children: [
            /* @__PURE__ */ e.jsx(E, { className: "text-sm font-medium", children: r("Custom Headers") }),
            /* @__PURE__ */ e.jsx(
              ae,
              {
                values: s.value,
                onChange: s.onChange,
                disabled: t,
                keyPlaceholder: r("Header name"),
                valuePlaceholder: r("Header value")
              }
            )
          ] })
        }
      )
    ] }),
    [u.CUSTOM, u.CLOUDFLARE_GATEWAY].includes(
      l
    ) && /* @__PURE__ */ e.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ e.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ e.jsx(E, { className: "text-base", children: r("Models Configuration") }),
        /* @__PURE__ */ e.jsx(q, { onSubmit: (s) => n(s), children: /* @__PURE__ */ e.jsxs(
          b,
          {
            type: "button",
            size: "sm",
            variant: "basic",
            disabled: t,
            children: [
              /* @__PURE__ */ e.jsx(re, { className: "h-4 w-4 mr-2" }),
              r("Add Model")
            ]
          }
        ) })
      ] }),
      d.length === 0 ? /* @__PURE__ */ e.jsxs("div", { className: "text-center py-8 border border-dashed rounded-lg flex flex-col items-center justify-center gap-2", children: [
        /* @__PURE__ */ e.jsx("span", { className: "mb-2 flex justify-center text-muted-foreground", children: /* @__PURE__ */ e.jsx(le, { className: "h-8 w-8 mx-auto" }) }),
        /* @__PURE__ */ e.jsx("p", { className: "text-sm text-muted-foreground", children: r(
          "This provider does not support listing models via API, please add models manually."
        ) })
      ] }) : /* @__PURE__ */ e.jsx("div", { className: "space-y-3", children: d.map((s, h) => /* @__PURE__ */ e.jsx(
        as,
        {
          model: s,
          isLoading: t,
          onUpdate: (C) => x(h, C),
          onRemove: () => m(h)
        },
        s.id
      )) })
    ] })
  ] });
}, as = ({
  model: a,
  isLoading: l,
  onUpdate: o,
  onRemove: t
}) => /* @__PURE__ */ e.jsxs("div", { className: "flex items-center justify-between p-4 border rounded-lg transition-colors", children: [
  /* @__PURE__ */ e.jsx("div", { className: "flex-1", children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ e.jsx(rs, { modelType: a.modelType }),
    /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-0", children: [
      /* @__PURE__ */ e.jsx("p", { className: "text-sm", children: a.modelName }),
      /* @__PURE__ */ e.jsx("p", { className: "text-sm text-muted-foreground", children: a.modelId })
    ] })
  ] }) }),
  /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ e.jsx(
      q,
      {
        initialData: a,
        onSubmit: (c) => o(c),
        children: /* @__PURE__ */ e.jsxs(
          b,
          {
            type: "button",
            variant: "ghost",
            size: "icon",
            disabled: l,
            children: [
              /* @__PURE__ */ e.jsx(O, { className: "h-4 w-4" }),
              /* @__PURE__ */ e.jsx("span", { className: "sr-only", children: r("Edit") })
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ e.jsxs(
      b,
      {
        type: "button",
        variant: "ghost",
        size: "icon",
        onClick: () => t(),
        disabled: l,
        children: [
          /* @__PURE__ */ e.jsx(te, { className: "h-4 w-4 text-destructive" }),
          /* @__PURE__ */ e.jsx("span", { className: "sr-only", children: r("Delete") })
        ]
      }
    )
  ] })
] }), rs = ({ modelType: a }) => /* @__PURE__ */ e.jsxs(ne, { children: [
  /* @__PURE__ */ e.jsx(oe, { asChild: !0, children: a === k.IMAGE ? /* @__PURE__ */ e.jsx(ie, { className: "size-8" }) : /* @__PURE__ */ e.jsx(Xe, { className: "size-8" }) }),
  /* @__PURE__ */ e.jsx(ce, { children: a === k.IMAGE ? r("Image Model") : r("Text Model") })
] }), ls = (a) => {
  const [l, o] = w.useState(!1);
  return /* @__PURE__ */ e.jsx(
    de,
    {
      open: l,
      onOpenChange: (t) => {
        o(t);
      },
      children: /* @__PURE__ */ e.jsx(
        ts,
        {
          ...a,
          setOpen: o
        },
        l ? "opened" : "closed"
      )
    }
  );
}, ts = ({
  children: a,
  onSave: l,
  config: o,
  provider: t,
  providerId: c,
  defaultDisplayName: d = "",
  setOpen: n
}) => {
  var D;
  const m = w.useMemo(
    () => M.find((s) => s.provider === t),
    [t]
  ), x = ue({
    resolver: (s, h, C) => {
      const U = me(
        ns(t, !R(c))
      );
      if (s.provider === u.CLOUDFLARE_GATEWAY && s.config.models.some(
        (P) => P.modelId.includes("google-vertex-ai")
      )) {
        const P = {};
        if ((R(s.config.vertexProject) || s.config.vertexProject.trim().length === 0) && (P.config = {
          vertexProject: {
            message: "Required when using Google Vertex AI models",
            type: "required"
          }
        }), (R(s.config.vertexRegion) || s.config.vertexRegion.trim().length === 0) && (P.config = {
          ...P.config,
          vertexRegion: {
            message: "Required when using Google Vertex AI models",
            type: "required"
          }
        }), Object.keys(P).length > 0)
          return {
            errors: P,
            values: {}
          };
      }
      return U(s, h, C);
    },
    defaultValues: {
      provider: t,
      displayName: d,
      config: o
    }
  }), { mutate: i, isPending: f } = he({
    mutationFn: (s) => {
      if (c) {
        const h = {
          displayName: s.displayName,
          config: s.config,
          ...xe(s.auth) ? { auth: s.auth } : {}
        };
        return H.update(c, h);
      } else
        return H.upsert(s);
    },
    onSuccess: () => {
      n(!1), l();
    },
    onError: (s) => {
      var C, U;
      const h = (C = s.response) == null ? void 0 : C.data;
      x.setError("root.serverError", {
        type: "manual",
        message: (h == null ? void 0 : h.message) ?? ((U = h == null ? void 0 : h.params) == null ? void 0 : U.message) ?? JSON.stringify(s)
      });
    }
  }), N = (s) => {
    i(s);
  };
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(je, { asChild: !0, children: a }),
    /* @__PURE__ */ e.jsxs(pe, { className: "max-w-2xl max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ e.jsx(ge, { children: /* @__PURE__ */ e.jsx(ve, { children: c ? r("Update AI Provider") : r("Add AI Provider") }) }),
      /* @__PURE__ */ e.jsx(ye, { ...x, children: /* @__PURE__ */ e.jsxs(
        "form",
        {
          className: "grid space-y-4",
          onSubmit: x.handleSubmit(N),
          children: [
            /* @__PURE__ */ e.jsx(Ae, { viewPortClassName: "max-h-[calc(70vh)] p-px", children: /* @__PURE__ */ e.jsxs("div", { className: "space-y-4", children: [
              /* @__PURE__ */ e.jsx(
                j,
                {
                  control: x.control,
                  name: "displayName",
                  render: ({ field: s }) => /* @__PURE__ */ e.jsxs(
                    v,
                    {
                      className: "space-y-3",
                      hidden: m.provider !== u.CUSTOM,
                      children: [
                        /* @__PURE__ */ e.jsx(y, { children: r("Display Name") }),
                        /* @__PURE__ */ e.jsx(A, { children: /* @__PURE__ */ e.jsx(
                          g,
                          {
                            ...s,
                            placeholder: "My Provider",
                            disabled: f
                          }
                        ) }),
                        /* @__PURE__ */ e.jsx(p, {})
                      ]
                    }
                  )
                }
              ),
              m.markdown && /* @__PURE__ */ e.jsx("div", { className: "text-sm text-muted-foreground", children: /* @__PURE__ */ e.jsx(
                be,
                {
                  markdown: m.markdown
                }
              ) }),
              /* @__PURE__ */ e.jsx(
                ss,
                {
                  form: x,
                  provider: t,
                  apiKeyRequired: !o,
                  isLoading: f,
                  isEditMode: !!c
                }
              ),
              ((D = x.formState.errors.root) == null ? void 0 : D.serverError) && /* @__PURE__ */ e.jsx(p, { children: x.formState.errors.root.serverError.message })
            ] }) }),
            /* @__PURE__ */ e.jsxs(fe, { children: [
              /* @__PURE__ */ e.jsx(
                b,
                {
                  variant: "outline",
                  type: "button",
                  onClick: (s) => {
                    s.stopPropagation(), s.preventDefault(), n(!1);
                  },
                  disabled: f,
                  children: r("Cancel")
                }
              ),
              /* @__PURE__ */ e.jsx(b, { disabled: f, loading: f, type: "submit", children: r("Save") })
            ] })
          ]
        }
      ) })
    ] })
  ] });
}, T = S({
  apiKey: I().optional(),
  accessKeyId: I().optional(),
  secretAccessKey: I().optional()
}).optional(), ns = (a, l) => {
  if (a === u.AZURE)
    return S({
      displayName: I().min(1),
      provider: F(u.AZURE),
      config: Ie,
      auth: l ? T : Ne
    });
  if (a === u.CLOUDFLARE_GATEWAY)
    return S({
      displayName: I().min(1),
      provider: F(u.CLOUDFLARE_GATEWAY),
      config: Ce,
      auth: l ? T : Pe
    });
  if (a === u.CUSTOM)
    return S({
      displayName: I().min(1),
      provider: F(u.CUSTOM),
      config: Ee,
      auth: l ? T : Se
    });
  if (a === u.BEDROCK)
    return S({
      displayName: I().min(1),
      provider: F(u.BEDROCK),
      config: Fe,
      auth: l ? T : we
    });
  const o = W([
    Te,
    De,
    Ue
  ]);
  return S({
    displayName: I().min(1),
    provider: F(a),
    auth: l ? T : o,
    config: W([
      ke,
      Oe,
      Re
    ])
  });
}, L = ({
  providerInfo: a,
  providerConfig: l,
  onDelete: o,
  onSave: t,
  allowWrite: c = !0
}) => {
  const d = a.logoUrl, n = (l == null ? void 0 : l.name) ?? a.name;
  return /* @__PURE__ */ e.jsxs(Me, { variant: "outline", children: [
    d && /* @__PURE__ */ e.jsx($e, { src: d, alt: a.name }),
    /* @__PURE__ */ e.jsxs(Ke, { children: [
      /* @__PURE__ */ e.jsx(Ge, { children: n }),
      c && /* @__PURE__ */ e.jsx(ze, { children: r("Configure credentials for {providerName} AI provider.", {
        providerName: a.name
      }) })
    ] }),
    c && /* @__PURE__ */ e.jsxs(Ve, { children: [
      /* @__PURE__ */ e.jsx(
        ls,
        {
          providerId: l == null ? void 0 : l.id,
          config: l == null ? void 0 : l.config,
          provider: a.provider,
          defaultDisplayName: n,
          onSave: t,
          children: l ? /* @__PURE__ */ e.jsx(b, { variant: "ghost", size: "sm", children: /* @__PURE__ */ e.jsx(O, { className: "size-4" }) }) : /* @__PURE__ */ e.jsx(b, { variant: "basic", size: "sm", children: r("Enable") })
        },
        (l == null ? void 0 : l.id) ?? a.provider
      ),
      l && /* @__PURE__ */ e.jsx(
        _e,
        {
          title: r("Delete AI Provider"),
          message: r("Are you sure you want to delete {providerName}?", {
            providerName: n
          }),
          warning: r(
            "All steps using this AI provider will fail after deletion."
          ),
          entityName: n,
          mutationFn: () => o(l.id),
          children: /* @__PURE__ */ e.jsx(b, { variant: "ghost", size: "sm", children: /* @__PURE__ */ e.jsx(qe, { className: "size-4 text-destructive" }) })
        }
      )
    ] })
  ] });
};
L.displayName = "AIProviderCard";
const os = "/ap-cdn/pieces/activepieces.png";
function ms() {
  const { data: a, refetch: l } = He.useAiProviders(), { data: o } = We.useCurrentUser(), { platform: t } = Be.useCurrentPlatform(), c = t.plan.aiProvidersEnabled, { mutateAsync: d } = B.useDeleteAiProvider({
    onSuccess: () => l()
  }), { mutateAsync: n } = B.useToggleChatProvider({
    onSuccess: () => l()
  }), m = a ?? [], x = a == null ? void 0 : a.find((i) => i.enabledForChat);
  return /* @__PURE__ */ e.jsx(
    Le,
    {
      featureKey: "UNIVERSAL_AI",
      locked: (o == null ? void 0 : o.platformRole) !== Ye.ADMIN,
      lockTitle: r("Unlock AI"),
      lockDescription: r(
        "Set your AI providers so your users enjoy a seamless building experience with our universal AI pieces"
      ),
      children: /* @__PURE__ */ e.jsxs(
        Ze,
        {
          title: r("AI Providers"),
          description: c ? r(
            "Set provider credentials that will be used by universal AI pieces, i.e Text AI."
          ) : r(
            "Available AI providers that will be used by universal AI pieces, i.e Text AI."
          ),
          children: [
            c && m.length > 0 && /* @__PURE__ */ e.jsx(
              is,
              {
                providers: m,
                providerInfos: M,
                selectedProviderId: (x == null ? void 0 : x.id) ?? null,
                onSelect: (i, f) => n({ providerId: i, displayName: f })
              }
            ),
            /* @__PURE__ */ e.jsx("div", { className: "flex flex-col gap-4", children: M.map((i) => {
              const f = a == null ? void 0 : a.find(
                (N) => N.provider === i.provider
              );
              return /* @__PURE__ */ e.jsx(
                L,
                {
                  providerInfo: i,
                  providerConfig: f,
                  onDelete: (N) => d(N),
                  onSave: () => l(),
                  allowWrite: c
                },
                i.provider
              );
            }) })
          ]
        }
      )
    }
  );
}
function is({
  providers: a,
  providerInfos: l,
  selectedProviderId: o,
  onSelect: t
}) {
  const c = (d) => {
    var n;
    return ((n = l.find((m) => m.provider === d)) == null ? void 0 : n.logoUrl) ?? (d === u.ACTIVEPIECES ? os : void 0);
  };
  return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-3 rounded-lg border bg-card p-4 mb-6", children: [
    /* @__PURE__ */ e.jsx("div", { className: "flex h-9 w-9 items-center justify-center rounded-lg bg-muted shrink-0", children: /* @__PURE__ */ e.jsx(Je, { className: "size-4 text-muted-foreground" }) }),
    /* @__PURE__ */ e.jsxs("div", { className: "flex-1 min-w-0", children: [
      /* @__PURE__ */ e.jsx("p", { className: "text-sm font-medium leading-none", children: r("Chat Provider") }),
      /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: r("Select which AI provider powers the chat feature") })
    ] }),
    /* @__PURE__ */ e.jsxs(
      K,
      {
        value: o ?? void 0,
        onValueChange: (d) => {
          const n = a.find((m) => m.id === d);
          n && t(n.id, n.name);
        },
        children: [
          /* @__PURE__ */ e.jsx(G, { className: "w-52", children: /* @__PURE__ */ e.jsx(z, { placeholder: r("Select provider") }) }),
          /* @__PURE__ */ e.jsx(V, { children: a.map((d) => {
            const n = c(d.provider);
            return /* @__PURE__ */ e.jsx(_, { value: d.id, children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
              n && /* @__PURE__ */ e.jsx(
                "img",
                {
                  src: n,
                  alt: d.provider,
                  className: "size-4 object-contain"
                }
              ),
              /* @__PURE__ */ e.jsx("span", { children: d.name })
            ] }) }, d.id);
          }) })
        ]
      }
    )
  ] });
}
export {
  ms as default
};
