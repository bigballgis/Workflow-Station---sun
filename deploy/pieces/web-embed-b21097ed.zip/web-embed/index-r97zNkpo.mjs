import { o as V, s as C, b as M, cS as I, eN as g, dh as H, c as w, g as N, c0 as $, c1 as B, b6 as q, eO as Q, j as e, bs as Y, b_ as G, bt as J, bu as W, bv as X, a6 as t, c2 as Z, c3 as k, c4 as A, aQ as R, eP as ee, c8 as E, aX as ae, by as te, i as D, b9 as se, ba as ne, ca as ie, bb as le, bc as b, aW as re, cb as oe, cc as ce, a3 as de, a4 as ue, eQ as xe, a5 as me, dY as pe, cr as he, cp as h, c$ as ge, dv as je, cY as P, aa as F, dJ as ve, d7 as O, eR as S, bC as fe, co as ye, eS as Ie, c_ as Ne, eT as De } from "./mount-builder-CqIEWsZv.mjs";
import { D as be } from "./dashboard-page-header-BfLKPs1b.mjs";
import { R as Se } from "./rotate-ccw-ClYM7DvH.mjs";
import { T as U } from "./truncated-column-text-value-Bg-cyJFo.mjs";
const Ue = V({
  status: M(g).optional(),
  platformRole: M(I).optional(),
  externalId: C().optional()
});
V({
  cursor: C().optional(),
  limit: H().optional(),
  externalId: C().optional()
});
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Ce = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M8 12h8", key: "1wcyev" }]
], Te = w("circle-minus", Ce);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Me = [
  ["path", { d: "M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4", key: "1nerag" }],
  ["path", { d: "M14 13.12c0 2.38 0 6.38-1 8.88", key: "o46ks0" }],
  ["path", { d: "M17.29 21.02c.12-.6.43-2.3.5-3.02", key: "ptglia" }],
  ["path", { d: "M2 12a10 10 0 0 1 18-6", key: "ydlgp0" }],
  ["path", { d: "M2 16h.01", key: "1gqxmh" }],
  ["path", { d: "M21.8 16c.2-2 .131-5.354 0-6", key: "drycrb" }],
  ["path", { d: "M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2", key: "1tidbn" }],
  ["path", { d: "M8.65 22c.21-.66.45-1.32.57-2", key: "13wd9y" }],
  ["path", { d: "M9 6.8a6 6 0 0 1 9 5.2v2", key: "1fr1j5" }]
], ke = w("fingerprint-pattern", Me), Ae = ({
  children: a,
  onUpdate: l,
  userId: i,
  role: r,
  externalId: c
}) => {
  var x, f, y;
  const [d, u] = N.useState(!1), n = $({
    defaultValues: {
      role: r,
      externalId: c
    },
    resolver: B(Ue)
  }), { mutate: o, isPending: p } = q(
    {
      mutationKey: ["update-user"],
      mutationFn: (s) => Q.update(i, s),
      onSuccess: (s) => {
        l(s.platformRole), u(!1);
      }
    }
  );
  return /* @__PURE__ */ e.jsxs(
    Y,
    {
      open: d,
      onOpenChange: (s) => {
        n.reset(), u(s);
      },
      children: [
        /* @__PURE__ */ e.jsx(G, { asChild: !0, children: a }),
        /* @__PURE__ */ e.jsxs(J, { children: [
          /* @__PURE__ */ e.jsx(W, { children: /* @__PURE__ */ e.jsx(X, { children: t("Update User Role") }) }),
          /* @__PURE__ */ e.jsx(Z, { ...n, children: /* @__PURE__ */ e.jsxs("form", { className: "grid space-y-4", onSubmit: (s) => s.preventDefault(), children: [
            /* @__PURE__ */ e.jsx(
              k,
              {
                name: "role",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(A, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(R, { htmlFor: "role", children: t("Role") }),
                  /* @__PURE__ */ e.jsx(
                    ee,
                    {
                      type: "platform",
                      value: s.value,
                      onValueChange: s.onChange
                    }
                  ),
                  /* @__PURE__ */ e.jsx(E, {})
                ] })
              }
            ),
            /* @__PURE__ */ e.jsx(
              k,
              {
                name: "externalId",
                render: ({ field: s }) => /* @__PURE__ */ e.jsxs(A, { className: "grid space-y-2", children: [
                  /* @__PURE__ */ e.jsx(R, { htmlFor: "externalId", children: t("External ID") }),
                  /* @__PURE__ */ e.jsx(
                    ae,
                    {
                      id: "externalId",
                      value: s.value,
                      onChange: s.onChange
                    }
                  )
                ] })
              }
            ),
            ((y = (f = (x = n == null ? void 0 : n.formState) == null ? void 0 : x.errors) == null ? void 0 : f.root) == null ? void 0 : y.serverError) && /* @__PURE__ */ e.jsx(E, { children: n.formState.errors.root.serverError.message })
          ] }) }),
          /* @__PURE__ */ e.jsxs(te, { children: [
            /* @__PURE__ */ e.jsx(
              D,
              {
                variant: "outline",
                onClick: (s) => {
                  s.stopPropagation(), s.preventDefault(), u(!1);
                },
                children: t("Cancel")
              }
            ),
            /* @__PURE__ */ e.jsx(
              D,
              {
                disabled: p,
                loading: p,
                onClick: (s) => {
                  s.stopPropagation(), s.preventDefault(), o({
                    platformRole: n.getValues().role,
                    externalId: n.getValues().externalId
                  });
                },
                children: t("Save")
              }
            )
          ] })
        ] })
      ]
    }
  );
}, Re = ({
  row: a,
  isUpdatingStatus: l,
  onDelete: i,
  onToggleStatus: r,
  onUpdate: c
}) => {
  const [d, u] = N.useState(!1), n = a.type === "invitation", o = !n && a.data.platformRole === I.ADMIN, p = !n && a.data.status === g.ACTIVE;
  return /* @__PURE__ */ e.jsx("div", { className: "flex justify-end", children: /* @__PURE__ */ e.jsxs(se, { modal: !0, open: d, onOpenChange: u, children: [
    /* @__PURE__ */ e.jsx(ne, { asChild: !0, children: /* @__PURE__ */ e.jsx(D, { variant: "ghost", className: "h-8 w-8 p-0", children: /* @__PURE__ */ e.jsx(ie, { className: "h-4 w-4" }) }) }),
    /* @__PURE__ */ e.jsxs(le, { children: [
      !n && /* @__PURE__ */ e.jsx(
        Ae,
        {
          userId: a.data.id,
          role: a.data.platformRole,
          externalId: a.data.externalId ?? void 0,
          onUpdate: c,
          children: /* @__PURE__ */ e.jsxs(b, { onSelect: (x) => x.preventDefault(), children: [
            /* @__PURE__ */ e.jsx(re, { className: "h-4 w-4" }),
            t("Edit")
          ] })
        }
      ),
      !n && /* @__PURE__ */ e.jsxs(
        b,
        {
          disabled: o || l,
          onSelect: () => {
            r(a.data.id, a.data.status), u(!1);
          },
          children: [
            p ? /* @__PURE__ */ e.jsx(Te, { className: "h-4 w-4" }) : /* @__PURE__ */ e.jsx(Se, { className: "h-4 w-4" }),
            p ? t("Deactivate") : t("Activate")
          ]
        }
      ),
      /* @__PURE__ */ e.jsx(
        oe,
        {
          title: n ? t("Delete Invitation") : t("Delete User"),
          message: n ? t("This invitation will be permanently deleted.") : t("This user and all their data will be permanently deleted."),
          entityName: `${n ? t("Invitation") : t("User")} ${a.data.email}`,
          mutationFn: async () => {
            i(n ? a.id : a.data.id, n);
          },
          children: /* @__PURE__ */ e.jsxs(
            b,
            {
              variant: "destructive",
              onSelect: (x) => x.preventDefault(),
              children: [
                /* @__PURE__ */ e.jsx(ce, { className: "h-4 w-4" }),
                t("Delete")
              ]
            }
          )
        }
      )
    ] })
  ] }) });
}, Ee = () => [
  {
    accessorKey: "identity",
    size: 320,
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      h,
      {
        column: a,
        title: t("Identity"),
        icon: ke
      }
    ),
    cell: ({ row: a }) => {
      const l = a.original.type === "invitation", i = a.original.type === "user" ? a.original.data.externalId : void 0, r = a.original.data.email, c = r == null ? void 0 : r.includes("@");
      return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
        l && /* @__PURE__ */ e.jsxs(de, { children: [
          /* @__PURE__ */ e.jsx(ue, { children: /* @__PURE__ */ e.jsx(xe, { className: "h-4 w-4 text-orange-700" }) }),
          /* @__PURE__ */ e.jsx(me, { children: /* @__PURE__ */ e.jsx("p", { children: t("Pending Invitation") }) })
        ] }),
        /* @__PURE__ */ e.jsxs(
          "div",
          {
            className: `flex flex-col gap-0.5 ${l ? "text-orange-700" : ""}`,
            children: [
              c && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ e.jsx(pe, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground" }),
                /* @__PURE__ */ e.jsx(
                  U,
                  {
                    value: r,
                    className: "max-w-[200px] 2xl:max-w-[280px]"
                  }
                )
              ] }),
              i && /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1.5", children: [
                /* @__PURE__ */ e.jsx(he, { className: "h-3.5 w-3.5 shrink-0 text-muted-foreground" }),
                /* @__PURE__ */ e.jsx(
                  U,
                  {
                    value: i,
                    className: "max-w-[200px] 2xl:max-w-[280px]"
                  }
                )
              ] }),
              !c && !i && /* @__PURE__ */ e.jsx("span", { className: "text-muted-foreground", children: "-" })
            ]
          }
        )
      ] });
    }
  },
  {
    accessorKey: "name",
    size: 210,
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(h, { column: a, title: t("Name"), icon: ge }),
    cell: ({ row: a }) => a.original.type === "invitation" ? /* @__PURE__ */ e.jsx("div", { className: "text-muted-foreground", children: "-" }) : /* @__PURE__ */ e.jsx(
      U,
      {
        value: a.original.data.firstName + " " + a.original.data.lastName,
        className: "max-w-[160px] 2xl:max-w-[200px]"
      }
    )
  },
  {
    accessorKey: "role",
    size: 90,
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(h, { column: a, title: t("Role"), icon: je }),
    cell: ({ row: a }) => {
      const l = a.original.data.platformRole;
      return /* @__PURE__ */ e.jsx("div", { className: "text-left", children: l === I.ADMIN ? t("Admin") : l === I.OPERATOR ? t("Operator") : t("Member") });
    }
  },
  {
    accessorKey: "createdAt",
    size: 130,
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      h,
      {
        column: a,
        title: t("Created"),
        icon: F
      }
    ),
    cell: ({ row: a }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(P, { date: new Date(a.original.data.created) }) })
  },
  {
    accessorKey: "lastActiveDate",
    size: 130,
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      h,
      {
        column: a,
        title: t("Last Active"),
        icon: F
      }
    ),
    cell: ({ row: a }) => a.original.type === "invitation" ? /* @__PURE__ */ e.jsx("div", { className: "text-muted-foreground", children: "-" }) : a.original.data.lastActiveDate ? /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(P, { date: new Date(a.original.data.lastActiveDate) }) }) : "-"
  },
  {
    accessorKey: "status",
    size: 100,
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      h,
      {
        column: a,
        title: t("Status"),
        icon: ve
      }
    ),
    cell: ({ row: a }) => a.original.type === "invitation" ? /* @__PURE__ */ e.jsx("div", { className: "text-left text-orange-700", children: t("Pending") }) : /* @__PURE__ */ e.jsx("div", { className: "text-left", children: a.original.data.status === g.ACTIVE ? t("Activated") : t("Deactivated") })
  }
];
function we() {
  const [a, l] = N.useState(!1), {
    data: i,
    isLoading: r,
    refetch: c
  } = O.useUsers(), {
    data: d,
    isLoading: u,
    refetch: n
  } = O.usePlatformInvitations(), o = () => {
    c(), n();
  }, p = N.useMemo(() => {
    var T;
    const m = ((T = i == null ? void 0 : i.data) == null ? void 0 : T.map((v) => ({
      id: v.id,
      type: "user",
      data: v
    }))) ?? [], j = (d == null ? void 0 : d.map((v) => ({
      id: v.id,
      type: "invitation",
      data: v
    }))) ?? [];
    return [...m, ...j];
  }, [i, d]), x = r || u, { mutate: f } = S.useDeleteUser({
    onSuccess: o
  }), { mutate: y } = S.useDeleteInvitation({ onSuccess: o }), { mutate: s, isPending: z } = S.useUpdateUserStatus({ onSuccess: o }), L = (m, j) => {
    j ? y(m) : f(m);
  }, K = (m, j) => {
    s({
      userId: m,
      status: j === g.ACTIVE ? g.INACTIVE : g.ACTIVE
    });
  }, _ = Ee();
  return /* @__PURE__ */ e.jsxs(
    fe,
    {
      featureKey: "USERS",
      locked: !1,
      lockTitle: t("Unlock Users"),
      lockDescription: t("Manage your users and their access to your projects"),
      children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col w-full", children: [
          /* @__PURE__ */ e.jsx(
            be,
            {
              title: t("Users"),
              description: t(
                "Manage, delete, activate and deactivate users on platform"
              )
            }
          ),
          /* @__PURE__ */ e.jsx(
            ye,
            {
              emptyStateTextTitle: t("No users found"),
              emptyStateTextDescription: t("Start inviting users to your project"),
              emptyStateIcon: /* @__PURE__ */ e.jsx(Ne, { className: "size-14" }),
              columns: _,
              page: {
                data: p,
                next: (i == null ? void 0 : i.next) || null,
                previous: (i == null ? void 0 : i.previous) || null
              },
              hidePagination: !0,
              isLoading: x,
              toolbarButtons: [
                /* @__PURE__ */ e.jsxs(
                  D,
                  {
                    className: "gap-2",
                    size: "sm",
                    onClick: () => l(!0),
                    children: [
                      /* @__PURE__ */ e.jsx(Ie, { size: 16 }),
                      /* @__PURE__ */ e.jsx("span", { className: "text-sm font-medium", children: t("Invite") })
                    ]
                  },
                  "invite"
                )
              ],
              actions: [
                (m) => /* @__PURE__ */ e.jsx(
                  Re,
                  {
                    row: m,
                    isUpdatingStatus: z,
                    onDelete: L,
                    onToggleStatus: K,
                    onUpdate: o
                  }
                )
              ]
            }
          )
        ] }),
        /* @__PURE__ */ e.jsx(
          De,
          {
            open: a,
            setOpen: l,
            onInviteSuccess: o
          }
        )
      ]
    }
  );
}
export {
  we as default
};
