import { c as bn, jg as ue, g as w, as as Fr, cO as Me, cQ as ze, fs as Hr, j as n, av as Lr, hD as Mr, a6 as K, b9 as Rn, ba as yn, i as Et, C as Sn, bb as vn, bc as Se, jc as et, hu as zr, fz as It, hq as Wr, fb as an, cb as cn, b7 as dn, gG as Dt, am as $r, cZ as Br, eX as Or, jh as Kr, fr as Ur, ji as jn, jj as un, jk as Gr, h as se, jl as _r, ax as kn, ay as En, aA as In, jm as Vr, jn as qr, D as Dn, jo as tt, jp as Xr, jq as Yr, jr as Jr, js as Zr, jt as Qr, ff as ae, aG as ot, c7 as Tn, be as Pn, bf as Nn, al as An, bi as es, ju as ts, a_ as ns, ao as rs, hZ as ss, jv as os, jw as ls } from "./mount-builder-CqIEWsZv.mjs";
import { B as is, a as as, b as fn, c as cs, d as ds, e as us, C as fs, A as hs, u as gs } from "./use-resource-lock-CfW3f2H9.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const xs = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  [
    "path",
    { d: "M10 12a1 1 0 0 0-1 1v1a1 1 0 0 1-1 1 1 1 0 0 1 1 1v1a1 1 0 0 0 1 1", key: "1oajmo" }
  ],
  [
    "path",
    { d: "M14 18a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1 1 1 0 0 1-1-1v-1a1 1 0 0 0-1-1", key: "mpwhp6" }
  ]
], ws = bn("file-braces", xs);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ms = [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ]
], ps = bn("pen", ms);
function Cs({
  onBack: e,
  lockedBy: t,
  takeOver: s
}) {
  const [
    r,
    o,
    c,
    f,
    h,
    m,
    p
  ] = ue((d) => [
    d.selectedRecords,
    d.setSelectedRecords,
    d.isSaving,
    d.records,
    d.table,
    d.renameTable,
    d.deleteRecords
  ]), [b, C] = w.useState(!1), [x, l] = w.useState(!1), { project: v } = Fr.useCurrentProject(), y = ue((d) => d.lockedByOtherUser), g = Me().checkAccess(
    ze.WRITE_TABLE
  ) && !y, N = Me().checkAccess(
    ze.WRITE_PROJECT_RELEASE
  ), T = Hr.useShowPushToGit(), j = async () => {
    const d = await Dt.getTemplate(h.id);
    Ur({
      obj: JSON.stringify(d, null, 2),
      fileName: d.name,
      extension: "json"
    });
  }, k = async () => {
    const d = await Dt.export(h.id);
    jn.exportTables([d]);
  }, P = /* @__PURE__ */ n.jsx(is, { children: /* @__PURE__ */ n.jsxs(as, { children: [
    /* @__PURE__ */ n.jsx(fn, { children: /* @__PURE__ */ n.jsx(cs, { onClick: e, className: "cursor-pointer", children: Lr(v) }) }),
    /* @__PURE__ */ n.jsx(ds, {}),
    /* @__PURE__ */ n.jsx(fn, { children: /* @__PURE__ */ n.jsx(us, { children: /* @__PURE__ */ n.jsxs("div", { className: "flex items-center gap-1", children: [
      /* @__PURE__ */ n.jsx(
        Mr,
        {
          className: "hover:cursor-text",
          value: (h == null ? void 0 : h.name) || K("Table Editor"),
          readonly: !g,
          onValueChange: (d) => {
            m(d);
          },
          isEditing: x,
          setIsEditing: l,
          tooltipContent: g ? K("Edit Table Name") : ""
        }
      ),
      /* @__PURE__ */ n.jsxs(Rn, { children: [
        /* @__PURE__ */ n.jsx(yn, { asChild: !0, children: /* @__PURE__ */ n.jsx(
          Et,
          {
            variant: "ghost",
            className: "size-6 flex items-center justify-center",
            children: /* @__PURE__ */ n.jsx(Sn, { className: "h-4 w-4 text-muted-foreground" })
          }
        ) }),
        /* @__PURE__ */ n.jsxs(vn, { align: "start", className: "w-48", children: [
          /* @__PURE__ */ n.jsxs(
            Se,
            {
              onSelect: () => {
                setTimeout(() => l(!0), 300);
              },
              disabled: !g,
              children: [
                /* @__PURE__ */ n.jsx(ps, { className: "mr-2 h-4 w-4" }),
                K("Rename")
              ]
            }
          ),
          /* @__PURE__ */ n.jsx(et, {}),
          /* @__PURE__ */ n.jsxs(
            Se,
            {
              onSelect: () => C(!0),
              disabled: !g,
              children: [
                /* @__PURE__ */ n.jsx(zr, { className: "mr-2 h-4 w-4" }),
                K("Import")
              ]
            }
          ),
          /* @__PURE__ */ n.jsxs(Se, { onSelect: j, children: [
            /* @__PURE__ */ n.jsx(ws, { className: "mr-2 h-4 w-4" }),
            K("Export Template")
          ] }),
          T && /* @__PURE__ */ n.jsxs(n.Fragment, { children: [
            /* @__PURE__ */ n.jsx(et, {}),
            /* @__PURE__ */ n.jsx(
              It,
              {
                hasPermission: N,
                children: /* @__PURE__ */ n.jsx(Wr, { type: "table", tables: [h], children: /* @__PURE__ */ n.jsxs(
                  Se,
                  {
                    disabled: !N,
                    onSelect: (d) => d.preventDefault(),
                    onClick: (d) => d.stopPropagation(),
                    children: [
                      /* @__PURE__ */ n.jsx(fs, { className: "mr-2 h-4 w-4" }),
                      K("Push to Git")
                    ]
                  }
                ) })
              }
            ),
            /* @__PURE__ */ n.jsx(et, {})
          ] }),
          !T && /* @__PURE__ */ n.jsx(et, {}),
          /* @__PURE__ */ n.jsxs(Se, { onSelect: k, children: [
            /* @__PURE__ */ n.jsx(an, { className: "mr-2 h-4 w-4" }),
            K("Download Data")
          ] }),
          /* @__PURE__ */ n.jsx(It, { hasPermission: g, children: /* @__PURE__ */ n.jsx(
            cn,
            {
              title: K("Delete Table"),
              message: K(
                "This will permanently delete the table and all its data."
              ),
              entityName: K("table"),
              buttonText: K("Delete"),
              mutationFn: async () => {
                await Dt.delete(h.id), e();
              },
              children: /* @__PURE__ */ n.jsxs(
                Se,
                {
                  disabled: !g,
                  onSelect: (d) => d.preventDefault(),
                  onClick: (d) => d.stopPropagation(),
                  className: "text-destructive focus:text-destructive",
                  children: [
                    /* @__PURE__ */ n.jsx(dn, { className: "mr-2 h-4 w-4" }),
                    K("Delete")
                  ]
                }
              )
            }
          ) })
        ] })
      ] })
    ] }) }) })
  ] }) }), u = /* @__PURE__ */ n.jsxs("div", { className: "flex items-center gap-2", children: [
    c && /* @__PURE__ */ n.jsxs("div", { className: "flex items-center gap-2 text-muted-foreground animate-in fade-in", children: [
      /* @__PURE__ */ n.jsx($r, { className: "h-4 w-4 animate-spin" }),
      /* @__PURE__ */ n.jsx("span", { className: "text-sm", children: K("Saving...") })
    ] }),
    t && /* @__PURE__ */ n.jsxs("div", { className: "flex items-center gap-1.5 border border-warning/50 rounded-md px-2.5 py-1 text-sm text-warning-700 dark:text-warning-300", children: [
      /* @__PURE__ */ n.jsx(Br, { className: "size-3.5 shrink-0" }),
      /* @__PURE__ */ n.jsx("span", { children: K("{name} is editing", { name: t.userDisplayName }) }),
      /* @__PURE__ */ n.jsx("span", { className: "text-warning/40", children: "|" }),
      /* @__PURE__ */ n.jsx("button", { className: "hover:underline font-medium", onClick: s, children: K("Take Over") })
    ] }),
    /* @__PURE__ */ n.jsx(hs, { resourceId: h.id }),
    r.size > 0 && /* @__PURE__ */ n.jsx(It, { hasPermission: g, children: /* @__PURE__ */ n.jsx(
      cn,
      {
        title: K("Delete Records"),
        message: K("The selected records will be permanently deleted."),
        entityName: r.size === 1 ? K("record") : K("records"),
        buttonText: K("Delete"),
        mutationFn: async () => {
          const d = Array.from(r).map(
            (I) => f.findIndex((A) => A.uuid === I)
          );
          p(d.map((I) => I.toString())), o(/* @__PURE__ */ new Set());
        },
        children: /* @__PURE__ */ n.jsxs(
          Et,
          {
            variant: "destructive",
            className: "flex gap-2 items-center",
            disabled: !g,
            children: [
              /* @__PURE__ */ n.jsx(dn, { className: "size-4" }),
              K("Delete Records"),
              " ",
              r.size > 0 ? `(${r.size})` : ""
            ]
          }
        )
      }
    ) })
  ] });
  return /* @__PURE__ */ n.jsxs(n.Fragment, { children: [
    /* @__PURE__ */ n.jsx(
      Or,
      {
        title: P,
        rightContent: u,
        className: "gap-1 justify-between px-4"
      }
    ),
    /* @__PURE__ */ n.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ n.jsxs(
        Et,
        {
          variant: "ghost",
          className: "flex gap-2 items-center",
          onClick: k,
          children: [
            /* @__PURE__ */ n.jsx(an, { className: "size-4" }),
            K("Download Data")
          ]
        }
      ),
      /* @__PURE__ */ n.jsx(
        Kr,
        {
          open: b,
          setIsOpen: C,
          tableId: h.id,
          allowedFileTypes: ["json", "csv"],
          onImportSuccess: () => window.location.reload()
        }
      )
    ] })
  ] });
}
function bs({ field: e }) {
  const [t, s] = w.useState(!1), [r, o] = w.useState(null), c = ue((p) => p.lockedByOtherUser), h = Me().checkAccess(
    ze.WRITE_TABLE
  ) && !c, m = h ? [un.RENAME, un.DELETE] : [];
  return /* @__PURE__ */ n.jsxs(
    Gr.Provider,
    {
      value: {
        setIsPopoverOpen: s,
        setPopoverContent: o,
        field: e,
        userHasTableWritePermission: h
      },
      children: [
        /* @__PURE__ */ n.jsxs(Rn, { children: [
          /* @__PURE__ */ n.jsx(yn, { asChild: !0, children: /* @__PURE__ */ n.jsxs(
            "div",
            {
              className: se(
                "h-full w-full flex items-center justify-between gap-2 py-2.5 px-3 bg-muted/50  font-normal",
                "hover:bg-muted cursor-pointer",
                "data-[state=open]:bg-muted"
              ),
              children: [
                /* @__PURE__ */ n.jsxs("div", { className: "flex items-center gap-2", children: [
                  jn.getColumnIcon(e.type),
                  /* @__PURE__ */ n.jsx("span", { className: "text-sm", children: e.name })
                ] }),
                m && m.length > 0 && /* @__PURE__ */ n.jsx(Sn, { className: "h-4 w-4" })
              ]
            }
          ) }),
          m && m.length > 0 && /* @__PURE__ */ n.jsx(
            vn,
            {
              noAnimationOnOut: !0,
              onCloseAutoFocus: (p) => p.preventDefault(),
              align: "start",
              className: "w-56 rounded-sm",
              children: m.map((p, b) => /* @__PURE__ */ n.jsx("div", { children: /* @__PURE__ */ n.jsx(_r, { action: p }) }, b))
            }
          )
        ] }),
        /* @__PURE__ */ n.jsxs(kn, { open: t, onOpenChange: s, children: [
          /* @__PURE__ */ n.jsx(En, { asChild: !0, children: /* @__PURE__ */ n.jsx("div", { className: "w-full h-full -mt-[40px] pointer-events-none" }) }),
          /* @__PURE__ */ n.jsx(In, { align: "start", className: "p-3", children: r })
        ] })
      ]
    }
  );
}
function nt(e) {
  return !isNaN(new Date(e).getTime());
}
function Tt(e) {
  return nt(e) ? Dn.formatDateOnly(new Date(e)) : "";
}
function Rs() {
  const { value: e, handleCellChange: t, setIsEditing: s, isEditing: r } = Vr(), [o, c] = w.useState(
    nt(e) ? new Date(e) : void 0
  ), [f, h] = w.useState(
    nt(e) ? new Date(e) : void 0
  ), [m, p] = w.useState(Tt(e)), b = (l) => {
    c(l), l && (p(Dn.formatDateOnly(l)), t(l.toISOString()), s(!1));
  }, C = w.useRef(null), x = w.useRef(null);
  return w.useEffect(() => {
    r ? requestAnimationFrame(() => {
      var l;
      (l = C.current) == null || l.focus();
    }) : p(Tt(e));
  }, [r]), /* @__PURE__ */ n.jsx("div", { className: "h-full w-full", ref: x, children: /* @__PURE__ */ n.jsxs(
    kn,
    {
      open: r,
      onOpenChange: (l) => {
        l || s(!1);
      },
      children: [
        /* @__PURE__ */ n.jsx(En, { asChild: !0, children: /* @__PURE__ */ n.jsxs(
          "button",
          {
            className: se(
              "w-full h-full flex items-center justify-between gap-2",
              "bg-background text-sm px-2",
              "focus:outline-hidden",
              {
                "border-2 border-primary": r,
                "border-transparent bg-transparent!": !r
              }
            ),
            children: [
              r && /* @__PURE__ */ n.jsx(
                "input",
                {
                  ref: C,
                  placeholder: K("mm/dd/yyy"),
                  value: m,
                  type: "text",
                  onClick: (l) => {
                    l.stopPropagation();
                  },
                  onChange: (l) => {
                    p(l.target.value), nt(l.target.value) ? (c(new Date(l.target.value)), h(new Date(l.target.value))) : c(void 0);
                  },
                  onBlur: (l) => {
                    var v;
                    (v = x.current) != null && v.contains(l.target) || t((o == null ? void 0 : o.toISOString()) ?? "");
                  },
                  onKeyDown: (l) => {
                    l.stopPropagation(), l.key === "Enter" && (t((o == null ? void 0 : o.toISOString()) ?? ""), l.preventDefault()), l.key === "Escape" && (s(!1), l.preventDefault());
                  },
                  className: se(
                    "flex-1 h-full min-w-0",
                    "border-none text-sm px-2",
                    "focus:outline-hidden",
                    "placeholder:text-muted-foreground",
                    {
                      "border-transparent bg-transparent!": !r
                    }
                  ),
                  autoComplete: "off"
                }
              ),
              !r && /* @__PURE__ */ n.jsx("div", { className: "flex grow h-full min-w-0", children: Tt(e) })
            ]
          }
        ) }),
        /* @__PURE__ */ n.jsx(In, { className: "w-auto p-0", align: "start", children: /* @__PURE__ */ n.jsx(
          qr,
          {
            mode: "single",
            selected: o,
            month: f,
            onMonthChange: h,
            onSelect: b
          }
        ) })
      ]
    }
  ) });
}
const ys = ({ fieldType: e }) => {
  switch (e) {
    case tt.DATE:
      return /* @__PURE__ */ n.jsx(Rs, {});
    case tt.NUMBER:
      return /* @__PURE__ */ n.jsx(Qr, {});
    case tt.STATIC_DROPDOWN:
      return /* @__PURE__ */ n.jsx(Zr, {});
    default:
      return /* @__PURE__ */ n.jsx(Jr, {});
  }
}, Ss = (e) => {
  const t = w.useRef(null);
  return w.useEffect(() => {
    requestAnimationFrame(() => {
      var s;
      e && ((s = t.current) == null || s.focus());
    });
  }, []), t;
};
function vs({
  field: e,
  column: t,
  rowIdx: s,
  onClick: r,
  locked: o = !1,
  value: c,
  disabled: f = !1
}) {
  const [h, m, p, b] = ue(
    (g) => [
      g.selectedCell,
      g.setSelectedCell,
      g.records,
      g.fields
    ]
  ), [C, x] = w.useState(!1), l = (h == null ? void 0 : h.rowIdx) === s && (h == null ? void 0 : h.columnIdx) === t.idx, v = Ss(l), y = (g) => {
    if ((g.key.length === 1 || g.key === "Enter") && !f && !C) {
      x(!0), m({ rowIdx: s, columnIdx: t.idx }), (g.key === "Enter" || g.key === " ") && (g.preventDefault(), g.stopPropagation());
      return;
    }
    switch (g.key) {
      case "ArrowUp": {
        s === 0 && (g.preventDefault(), g.stopPropagation());
        break;
      }
      case "ArrowDown": {
        s === p.length - 1 && (g.preventDefault(), g.stopPropagation());
        break;
      }
      case "ArrowLeft":
        t.idx === 1 && (g.preventDefault(), g.stopPropagation());
        break;
      case "ArrowRight":
        t.idx === b.length && (g.preventDefault(), g.stopPropagation());
    }
  }, R = e.type === tt.STATIC_DROPDOWN;
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      ref: v,
      id: `editable-cell-${s}-${t.idx}`,
      className: C ? "h-full w-full" : se(
        "h-full flex items-center justify-between gap-2  focus:outline-hidden  ",
        "group cursor-pointer border",
        l && !o ? "border-primary" : "border-transparent",
        o && "locked-row",
        !R && "pl-2 py-2"
      ),
      tabIndex: 0,
      onClick: () => {
        r == null || r(), m({ rowIdx: s, columnIdx: t.idx });
      },
      onFocus: () => {
        m({ rowIdx: s, columnIdx: t.idx });
      },
      onDoubleClick: () => {
        f || x(!0);
      },
      onKeyDown: y,
      children: /* @__PURE__ */ n.jsx(Xr, { fallback: /* @__PURE__ */ n.jsx("div", { children: "Error" }), children: /* @__PURE__ */ n.jsx(
        Yr,
        {
          rowIdx: s,
          columnIdx: t.idx - 1,
          fieldType: e.type,
          value: c ?? "",
          handleCellChange: () => {
          },
          containerRef: v,
          isEditing: C,
          setIsEditing: x,
          disabled: f,
          children: /* @__PURE__ */ n.jsx(ys, { fieldType: e.type })
        }
      ) })
    }
  );
}
function ee(e, t, s) {
  const r = typeof e.colSpan == "function" ? e.colSpan(s) : 1;
  if (Number.isInteger(r) && r > 1 && (!e.frozen || e.idx + r - 1 <= t))
    return r;
}
function js(e) {
  e.stopPropagation();
}
function rt(e) {
  e == null || e.scrollIntoView({
    inline: "nearest",
    block: "nearest"
  });
}
function Le(e) {
  let t = !1;
  const s = {
    ...e,
    preventGridDefault() {
      t = !0;
    },
    isGridDefaultPrevented() {
      return t;
    }
  };
  return Object.setPrototypeOf(s, Object.getPrototypeOf(e)), s;
}
const ks = /* @__PURE__ */ new Set(["Unidentified", "Alt", "AltGraph", "CapsLock", "Control", "Fn", "FnLock", "Meta", "NumLock", "ScrollLock", "Shift", "Tab", "ArrowDown", "ArrowLeft", "ArrowRight", "ArrowUp", "End", "Home", "PageDown", "PageUp", "Insert", "ContextMenu", "Escape", "Pause", "Play", "PrintScreen", "F1", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12"]);
function Ft(e) {
  return (e.ctrlKey || e.metaKey) && e.key !== "Control";
}
function Es(e) {
  return Ft(e) && e.keyCode !== 86 ? !1 : !ks.has(e.key);
}
function Is({
  key: e,
  target: t
}) {
  var s;
  return e === "Tab" && (t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement || t instanceof HTMLSelectElement) ? ((s = t.closest(".rdg-editor-container")) == null ? void 0 : s.querySelectorAll("input, textarea, select").length) === 1 : !1;
}
const Ds = "mlln6zg7-0-0-beta-47";
function Ts(e) {
  return e.map(({
    key: t,
    idx: s,
    minWidth: r,
    maxWidth: o
  }) => /* @__PURE__ */ n.jsx("div", {
    className: Ds,
    style: {
      gridColumnStart: s + 1,
      minWidth: r,
      maxWidth: o
    },
    "data-measuring-cell-key": t
  }, t));
}
function Ps({
  selectedPosition: e,
  columns: t,
  rows: s
}) {
  const r = t[e.idx], o = s[e.rowIdx];
  return Fn(r, o);
}
function Fn(e, t) {
  return e.renderEditCell != null && (typeof e.editable == "function" ? e.editable(t) : e.editable) !== !1;
}
function Ns({
  rows: e,
  topSummaryRows: t,
  bottomSummaryRows: s,
  rowIdx: r,
  mainHeaderRowIdx: o,
  lastFrozenColumnIndex: c,
  column: f
}) {
  const h = (t == null ? void 0 : t.length) ?? 0;
  if (r === o)
    return ee(f, c, {
      type: "HEADER"
    });
  if (t && r > o && r <= h + o)
    return ee(f, c, {
      type: "SUMMARY",
      row: t[r + h]
    });
  if (r >= 0 && r < e.length) {
    const m = e[r];
    return ee(f, c, {
      type: "ROW",
      row: m
    });
  }
  if (s)
    return ee(f, c, {
      type: "SUMMARY",
      row: s[r - e.length]
    });
}
function As({
  moveUp: e,
  moveNext: t,
  cellNavigationMode: s,
  columns: r,
  colSpanColumns: o,
  rows: c,
  topSummaryRows: f,
  bottomSummaryRows: h,
  minRowIdx: m,
  mainHeaderRowIdx: p,
  maxRowIdx: b,
  currentPosition: {
    idx: C,
    rowIdx: x
  },
  nextPosition: l,
  lastFrozenColumnIndex: v,
  isCellWithinBounds: y
}) {
  let {
    idx: R,
    rowIdx: g
  } = l;
  const N = r.length, T = (P) => {
    for (const u of o) {
      const d = u.idx;
      if (d > R) break;
      const I = Ns({
        rows: c,
        topSummaryRows: f,
        bottomSummaryRows: h,
        rowIdx: g,
        mainHeaderRowIdx: p,
        lastFrozenColumnIndex: v,
        column: u
      });
      if (I && R > d && R < I + d) {
        R = d + (P ? I : 0);
        break;
      }
    }
  }, j = (P) => P.level + p, k = () => {
    if (t) {
      let u = r[R].parent;
      for (; u !== void 0; ) {
        const d = j(u);
        if (g === d) {
          R = u.idx + u.colSpan;
          break;
        }
        u = u.parent;
      }
    } else if (e) {
      let u = r[R].parent, d = !1;
      for (; u !== void 0; ) {
        const I = j(u);
        if (g >= I) {
          R = u.idx, g = I, d = !0;
          break;
        }
        u = u.parent;
      }
      d || (R = C, g = x);
    }
  };
  if (y(l) && (T(t), g < p && k()), s === "CHANGE_ROW" && (R === N ? g === b || (R = 0, g += 1) : R === -1 && (g === m || (g -= 1, R = N - 1), T(!1))), g < p) {
    let u = r[R].parent;
    const d = g;
    for (g = p; u !== void 0; ) {
      const I = j(u);
      I >= d && (g = I, R = u.idx), u = u.parent;
    }
  }
  return {
    idx: R,
    rowIdx: g
  };
}
function Fs({
  maxColIdx: e,
  minRowIdx: t,
  maxRowIdx: s,
  selectedPosition: {
    rowIdx: r,
    idx: o
  },
  shiftKey: c
}) {
  return c ? o === 0 && r === t : o === e && r === s;
}
const Hs = "cj343x07-0-0-beta-47", Hn = `rdg-cell ${Hs}`, Ls = "csofj7r7-0-0-beta-47", Ms = `rdg-cell-frozen ${Ls}`;
function Ln(e) {
  return {
    "--rdg-grid-row-start": e
  };
}
function Mn(e, t, s) {
  const r = t + 1, o = `calc(${s - 1} * var(--rdg-header-row-height))`;
  return e.parent === void 0 ? {
    insetBlockStart: 0,
    gridRowStart: 1,
    gridRowEnd: r,
    paddingBlockStart: o
  } : {
    insetBlockStart: `calc(${t - s} * var(--rdg-header-row-height))`,
    gridRowStart: r - s,
    gridRowEnd: r,
    paddingBlockStart: o
  };
}
function $e(e, t = 1) {
  const s = e.idx + 1;
  return {
    gridColumnStart: s,
    gridColumnEnd: s + t,
    insetInlineStart: e.frozen ? `var(--rdg-frozen-left-${e.idx})` : void 0
  };
}
function it(e, ...t) {
  return ae(Hn, ...t, e.frozen && Ms);
}
const {
  min: We,
  max: lt,
  floor: hn,
  sign: zs,
  abs: Ws
} = Math;
function Pt(e) {
  if (typeof e != "function")
    throw new Error("Please specify the rowKeyGetter prop to use selection");
}
function zn(e, {
  minWidth: t,
  maxWidth: s
}) {
  return e = lt(e, t), typeof s == "number" && s >= t ? We(e, s) : e;
}
function Wn(e, t) {
  return e.parent === void 0 ? t : e.level - e.parent.level;
}
const $s = "c1bn88vv7-0-0-beta-47", Bs = `rdg-checkbox-input ${$s}`;
function Os({
  onChange: e,
  indeterminate: t,
  ...s
}) {
  function r(o) {
    e(o.target.checked, o.nativeEvent.shiftKey);
  }
  return /* @__PURE__ */ n.jsx("input", {
    ref: (o) => {
      o && (o.indeterminate = t === !0);
    },
    type: "checkbox",
    className: Bs,
    onChange: r,
    ...s
  });
}
function Ks(e) {
  try {
    return e.row[e.column.key];
  } catch {
    return null;
  }
}
const $n = /* @__PURE__ */ w.createContext(void 0), Us = $n.Provider;
function Bn() {
  return w.useContext($n);
}
const On = /* @__PURE__ */ w.createContext(void 0), Gs = On.Provider, Kn = /* @__PURE__ */ w.createContext(void 0), _s = Kn.Provider;
function Vs() {
  const e = w.useContext(On), t = w.useContext(Kn);
  if (e === void 0 || t === void 0)
    throw new Error("useRowSelection must be used within DataGrid cells");
  return {
    isRowSelectionDisabled: e.isRowSelectionDisabled,
    isRowSelected: e.isRowSelected,
    onRowSelectionChange: t
  };
}
const Un = /* @__PURE__ */ w.createContext(void 0), qs = Un.Provider, Gn = /* @__PURE__ */ w.createContext(void 0), Xs = Gn.Provider;
function Ys() {
  const e = w.useContext(Un), t = w.useContext(Gn);
  if (e === void 0 || t === void 0)
    throw new Error("useHeaderRowSelection must be used within DataGrid cells");
  return {
    isIndeterminate: e.isIndeterminate,
    isRowSelected: e.isRowSelected,
    onRowSelectionChange: t
  };
}
const gn = "rdg-select-column", Js = "auto", Zs = 50;
function Qs({
  rawColumns: e,
  defaultColumnOptions: t,
  getColumnWidth: s,
  viewportWidth: r,
  scrollLeft: o,
  enableVirtualization: c
}) {
  const f = (t == null ? void 0 : t.width) ?? Js, h = (t == null ? void 0 : t.minWidth) ?? Zs, m = (t == null ? void 0 : t.maxWidth) ?? void 0, p = (t == null ? void 0 : t.renderCell) ?? Ks, b = (t == null ? void 0 : t.sortable) ?? !1, C = (t == null ? void 0 : t.resizable) ?? !1, x = (t == null ? void 0 : t.draggable) ?? !1, {
    columns: l,
    colSpanColumns: v,
    lastFrozenColumnIndex: y,
    headerRowsCount: R
  } = w.useMemo(() => {
    let u = -1, d = 1;
    const I = [];
    A(e, 1);
    function A(L, H, q) {
      for (const $ of L) {
        if ("children" in $) {
          const ke = {
            name: $.name,
            parent: q,
            idx: -1,
            colSpan: 0,
            level: 0,
            headerCellClass: $.headerCellClass
          };
          A($.children, H + 1, ke);
          continue;
        }
        const te = $.frozen ?? !1, je = {
          ...$,
          parent: q,
          idx: 0,
          level: 0,
          frozen: te,
          width: $.width ?? f,
          minWidth: $.minWidth ?? h,
          maxWidth: $.maxWidth ?? m,
          sortable: $.sortable ?? b,
          resizable: $.resizable ?? C,
          draggable: $.draggable ?? x,
          renderCell: $.renderCell ?? p
        };
        I.push(je), te && u++, H > d && (d = H);
      }
    }
    I.sort(({
      key: L,
      frozen: H
    }, {
      key: q,
      frozen: $
    }) => L === gn ? -1 : q === gn ? 1 : H ? $ ? 0 : -1 : $ ? 1 : 0);
    const z = [];
    return I.forEach((L, H) => {
      L.idx = H, _n(L, H, 0), L.colSpan != null && z.push(L);
    }), {
      columns: I,
      colSpanColumns: z,
      lastFrozenColumnIndex: u,
      headerRowsCount: d
    };
  }, [e, f, h, m, p, C, b, x]), {
    templateColumns: g,
    layoutCssVars: N,
    totalFrozenColumnWidth: T,
    columnMetrics: j
  } = w.useMemo(() => {
    const u = /* @__PURE__ */ new Map();
    let d = 0, I = 0;
    const A = [];
    for (const L of l) {
      let H = s(L);
      typeof H == "number" ? H = zn(H, L) : H = L.minWidth, A.push(`${H}px`), u.set(L, {
        width: H,
        left: d
      }), d += H;
    }
    if (y !== -1) {
      const L = u.get(l[y]);
      I = L.left + L.width;
    }
    const z = {};
    for (let L = 0; L <= y; L++) {
      const H = l[L];
      z[`--rdg-frozen-left-${H.idx}`] = `${u.get(H).left}px`;
    }
    return {
      templateColumns: A,
      layoutCssVars: z,
      totalFrozenColumnWidth: I,
      columnMetrics: u
    };
  }, [s, l, y]), [k, P] = w.useMemo(() => {
    if (!c)
      return [0, l.length - 1];
    const u = o + T, d = o + r, I = l.length - 1, A = We(y + 1, I);
    if (u >= d)
      return [A, A];
    let z = A;
    for (; z < I; ) {
      const {
        left: $,
        width: te
      } = j.get(l[z]);
      if ($ + te > u)
        break;
      z++;
    }
    let L = z;
    for (; L < I; ) {
      const {
        left: $,
        width: te
      } = j.get(l[L]);
      if ($ + te >= d)
        break;
      L++;
    }
    const H = lt(A, z - 1), q = We(I, L + 1);
    return [H, q];
  }, [j, l, y, o, T, r, c]);
  return {
    columns: l,
    colSpanColumns: v,
    colOverscanStartIdx: k,
    colOverscanEndIdx: P,
    templateColumns: g,
    layoutCssVars: N,
    headerRowsCount: R,
    lastFrozenColumnIndex: y,
    totalFrozenColumnWidth: T
  };
}
function _n(e, t, s) {
  if (s < e.level && (e.level = s), e.parent !== void 0) {
    const {
      parent: r
    } = e;
    r.idx === -1 && (r.idx = t), r.colSpan += 1, _n(r, t, s - 1);
  }
}
const ve = typeof window > "u" ? w.useEffect : w.useLayoutEffect;
function eo(e, t, s, r, o, c, f, h, m, p) {
  const b = w.useRef(o), C = e.length === t.length, x = C && o !== b.current, l = [...s], v = [];
  for (const {
    key: N,
    idx: T,
    width: j
  } of t)
    typeof j == "string" && (x || !f.has(N)) && !c.has(N) && (l[T] = j, v.push(N));
  const y = l.join(" ");
  ve(() => {
    b.current = o, R(v);
  });
  function R(N) {
    N.length !== 0 && m((T) => {
      const j = new Map(T);
      let k = !1;
      for (const P of N) {
        const u = xn(r, P);
        k || (k = u !== T.get(P)), u === void 0 ? j.delete(P) : j.set(P, u);
      }
      return k ? j : T;
    });
  }
  function g(N, T) {
    const {
      key: j
    } = N, k = [...s], P = [];
    for (const {
      key: d,
      idx: I,
      width: A
    } of t)
      if (j === d) {
        const z = typeof T == "number" ? `${T}px` : T;
        k[I] = z;
      } else C && typeof A == "string" && !c.has(d) && (k[I] = A, P.push(d));
    r.current.style.gridTemplateColumns = k.join(" ");
    const u = typeof T == "number" ? T : xn(r, j);
    ot.flushSync(() => {
      h((d) => {
        const I = new Map(d);
        return I.set(j, u), I;
      }), R(P);
    }), p == null || p(N.idx, u);
  }
  return {
    gridTemplateColumns: y,
    handleColumnResize: g
  };
}
function xn(e, t) {
  var o;
  const s = `[data-measuring-cell-key="${CSS.escape(t)}"]`, r = (o = e.current) == null ? void 0 : o.querySelector(s);
  return r == null ? void 0 : r.getBoundingClientRect().width;
}
function to() {
  const e = w.useRef(null), [t, s] = w.useState(1), [r, o] = w.useState(1), [c, f] = w.useState(0);
  return ve(() => {
    const {
      ResizeObserver: h
    } = window;
    if (h == null) return;
    const {
      clientWidth: m,
      clientHeight: p,
      offsetWidth: b,
      offsetHeight: C
    } = e.current, {
      width: x,
      height: l
    } = e.current.getBoundingClientRect(), v = C - p, y = x - b + m, R = l - v;
    s(y), o(R), f(v);
    const g = new h((N) => {
      const T = N[0].contentBoxSize[0], {
        clientHeight: j,
        offsetHeight: k
      } = e.current;
      ot.flushSync(() => {
        s(T.inlineSize), o(T.blockSize), f(k - j);
      });
    });
    return g.observe(e.current), () => {
      g.disconnect();
    };
  }, []), [e, t, r, c];
}
function J(e) {
  const t = w.useRef(e);
  w.useEffect(() => {
    t.current = e;
  });
  const s = w.useCallback((...r) => {
    t.current(...r);
  }, []);
  return e && s;
}
function at(e) {
  const [t, s] = w.useState(!1);
  t && !e && s(!1);
  function r(c) {
    c.target !== c.currentTarget && s(!0);
  }
  return {
    tabIndex: e && !t ? 0 : -1,
    childTabIndex: e ? 0 : -1,
    onFocus: e ? r : void 0
  };
}
function no({
  columns: e,
  colSpanColumns: t,
  rows: s,
  topSummaryRows: r,
  bottomSummaryRows: o,
  colOverscanStartIdx: c,
  colOverscanEndIdx: f,
  lastFrozenColumnIndex: h,
  rowOverscanStartIdx: m,
  rowOverscanEndIdx: p
}) {
  const b = w.useMemo(() => {
    if (c === 0) return 0;
    let C = c;
    const x = (l, v) => v !== void 0 && l + v > c ? (C = l, !0) : !1;
    for (const l of t) {
      const v = l.idx;
      if (v >= C || x(v, ee(l, h, {
        type: "HEADER"
      })))
        break;
      for (let y = m; y <= p; y++) {
        const R = s[y];
        if (x(v, ee(l, h, {
          type: "ROW",
          row: R
        })))
          break;
      }
      if (r != null) {
        for (const y of r)
          if (x(v, ee(l, h, {
            type: "SUMMARY",
            row: y
          })))
            break;
      }
      if (o != null) {
        for (const y of o)
          if (x(v, ee(l, h, {
            type: "SUMMARY",
            row: y
          })))
            break;
      }
    }
    return C;
  }, [m, p, s, r, o, c, h, t]);
  return w.useMemo(() => {
    const C = [];
    for (let x = 0; x <= f; x++) {
      const l = e[x];
      x < b && !l.frozen || C.push(l);
    }
    return C;
  }, [b, f, e]);
}
function ro({
  rows: e,
  rowHeight: t,
  clientHeight: s,
  scrollTop: r,
  enableVirtualization: o
}) {
  const {
    totalRowHeight: c,
    gridTemplateRows: f,
    getRowTop: h,
    getRowHeight: m,
    findRowIdx: p
  } = w.useMemo(() => {
    if (typeof t == "number")
      return {
        totalRowHeight: t * e.length,
        gridTemplateRows: ` repeat(${e.length}, ${t}px)`,
        getRowTop: (R) => R * t,
        getRowHeight: () => t,
        findRowIdx: (R) => hn(R / t)
      };
    let x = 0, l = " ";
    const v = e.map((R) => {
      const g = t(R), N = {
        top: x,
        height: g
      };
      return l += `${g}px `, x += g, N;
    }), y = (R) => lt(0, We(e.length - 1, R));
    return {
      totalRowHeight: x,
      gridTemplateRows: l,
      getRowTop: (R) => v[y(R)].top,
      getRowHeight: (R) => v[y(R)].height,
      findRowIdx(R) {
        let g = 0, N = v.length - 1;
        for (; g <= N; ) {
          const T = g + hn((N - g) / 2), j = v[T].top;
          if (j === R) return T;
          if (j < R ? g = T + 1 : j > R && (N = T - 1), g > N) return N;
        }
        return 0;
      }
    };
  }, [t, e]);
  let b = 0, C = e.length - 1;
  if (o) {
    const l = p(r), v = p(r + s);
    b = lt(0, l - 4), C = We(e.length - 1, v + 4);
  }
  return {
    rowOverscanStartIdx: b,
    rowOverscanEndIdx: C,
    totalRowHeight: c,
    gridTemplateRows: f,
    getRowTop: h,
    getRowHeight: m,
    findRowIdx: p
  };
}
const so = "c1w9bbhr7-0-0-beta-47", oo = "c1creorc7-0-0-beta-47", lo = `rdg-cell-drag-handle ${so}`;
function io({
  gridRowStart: e,
  rows: t,
  column: s,
  columnWidth: r,
  maxColIdx: o,
  isLastRow: c,
  selectedPosition: f,
  latestDraggedOverRowIdx: h,
  isCellEditable: m,
  onRowsChange: p,
  onFill: b,
  onClick: C,
  setDragging: x,
  setDraggedOverRowIdx: l
}) {
  const {
    idx: v,
    rowIdx: y
  } = f;
  function R(k) {
    if (k.preventDefault(), k.buttons !== 1) return;
    x(!0), window.addEventListener("mouseover", P), window.addEventListener("mouseup", u);
    function P(d) {
      d.buttons !== 1 && u();
    }
    function u() {
      window.removeEventListener("mouseover", P), window.removeEventListener("mouseup", u), x(!1), g();
    }
  }
  function g() {
    const k = h.current;
    if (k === void 0) return;
    const P = y < k ? y + 1 : k, u = y < k ? k + 1 : y;
    T(P, u), l(void 0);
  }
  function N(k) {
    k.stopPropagation(), T(y + 1, t.length);
  }
  function T(k, P) {
    const u = t[y], d = [...t], I = [];
    for (let A = k; A < P; A++)
      if (m({
        rowIdx: A,
        idx: v
      })) {
        const z = b({
          columnKey: s.key,
          sourceRow: u,
          targetRow: t[A]
        });
        z !== t[A] && (d[A] = z, I.push(A));
      }
    I.length > 0 && (p == null || p(d, {
      indexes: I,
      column: s
    }));
  }
  function j() {
    var A;
    const k = ((A = s.colSpan) == null ? void 0 : A.call(s, {
      type: "ROW",
      row: t[y]
    })) ?? 1, {
      insetInlineStart: P,
      ...u
    } = $e(s, k), d = "calc(var(--rdg-drag-handle-size) * -0.5 + 1px)", I = s.idx + k - 1 === o;
    return {
      ...u,
      gridRowStart: e,
      marginInlineEnd: I ? void 0 : d,
      marginBlockEnd: c ? void 0 : d,
      insetInlineStart: P ? `calc(${P} + ${r}px + var(--rdg-drag-handle-size) * -0.5 - 1px)` : void 0
    };
  }
  return /* @__PURE__ */ n.jsx("div", {
    style: j(),
    className: ae(lo, s.frozen && oo),
    onClick: C,
    onMouseDown: R,
    onDoubleClick: N
  });
}
const ao = "cis5rrm7-0-0-beta-47";
function co({
  column: e,
  colSpan: t,
  row: s,
  rowIdx: r,
  onRowChange: o,
  closeEditor: c,
  onKeyDown: f,
  navigate: h
}) {
  var g, N, T;
  const m = w.useRef(void 0), p = ((g = e.editorOptions) == null ? void 0 : g.commitOnOutsideClick) !== !1, b = J(() => {
    l(!0, !1);
  });
  w.useEffect(() => {
    if (!p) return;
    function j() {
      m.current = requestAnimationFrame(b);
    }
    return addEventListener("mousedown", j, {
      capture: !0
    }), () => {
      removeEventListener("mousedown", j, {
        capture: !0
      }), C();
    };
  }, [p, b]);
  function C() {
    cancelAnimationFrame(m.current);
  }
  function x(j) {
    if (f) {
      const k = Le(j);
      if (f({
        mode: "EDIT",
        row: s,
        column: e,
        rowIdx: r,
        navigate() {
          h(j);
        },
        onClose: l
      }, k), k.isGridDefaultPrevented()) return;
    }
    j.key === "Escape" ? l() : j.key === "Enter" ? l(!0) : Is(j) && h(j);
  }
  function l(j = !1, k = !0) {
    j ? o(s, !0, k) : c(k);
  }
  function v(j, k = !1) {
    o(j, k, k);
  }
  const {
    cellClass: y
  } = e, R = it(e, "rdg-editor-container", typeof y == "function" ? y(s) : y, !((N = e.editorOptions) != null && N.displayCellContent) && ao);
  return /* @__PURE__ */ n.jsx("div", {
    role: "gridcell",
    "aria-colindex": e.idx + 1,
    "aria-colspan": t,
    "aria-selected": !0,
    className: R,
    style: $e(e, t),
    onKeyDown: x,
    onMouseDownCapture: C,
    children: e.renderEditCell != null && /* @__PURE__ */ n.jsxs(n.Fragment, {
      children: [e.renderEditCell({
        column: e,
        row: s,
        rowIdx: r,
        onRowChange: v,
        onClose: l
      }), ((T = e.editorOptions) == null ? void 0 : T.displayCellContent) && e.renderCell({
        column: e,
        row: s,
        rowIdx: r,
        isCellEditable: !0,
        tabIndex: -1,
        onRowChange: v
      })]
    })
  });
}
function uo({
  column: e,
  rowIdx: t,
  isCellSelected: s,
  selectCell: r
}) {
  const {
    tabIndex: o,
    onFocus: c
  } = at(s), {
    colSpan: f
  } = e, h = Wn(e, t), m = e.idx + 1;
  function p() {
    r({
      idx: e.idx,
      rowIdx: t
    });
  }
  return /* @__PURE__ */ n.jsx("div", {
    role: "columnheader",
    "aria-colindex": m,
    "aria-colspan": f,
    "aria-rowspan": h,
    "aria-selected": s,
    tabIndex: o,
    className: ae(Hn, e.headerCellClass),
    style: {
      ...Mn(e, t, h),
      gridColumnStart: m,
      gridColumnEnd: m + f
    },
    onFocus: c,
    onClick: p,
    children: e.name
  });
}
const fo = "h44jtk67-0-0-beta-47", ho = "hcgkhxz7-0-0-beta-47", go = `rdg-header-sort-name ${ho}`;
function xo({
  column: e,
  sortDirection: t,
  priority: s
}) {
  return e.sortable ? /* @__PURE__ */ n.jsx(wo, {
    sortDirection: t,
    priority: s,
    children: e.name
  }) : e.name;
}
function wo({
  sortDirection: e,
  priority: t,
  children: s
}) {
  const r = Bn().renderSortStatus;
  return /* @__PURE__ */ n.jsxs("span", {
    className: fo,
    children: [/* @__PURE__ */ n.jsx("span", {
      className: go,
      children: s
    }), /* @__PURE__ */ n.jsx("span", {
      children: r({
        sortDirection: e,
        priority: t
      })
    })]
  });
}
const mo = "c6l2wv17-0-0-beta-47", po = "c1kqdw7y7-0-0-beta-47", Co = `rdg-cell-resizable ${po}`, bo = "r1y6ywlx7-0-0-beta-47", Ro = "rdg-cell-draggable", yo = "c1bezg5o7-0-0-beta-47", So = `rdg-cell-dragging ${yo}`, vo = "c1vc96037-0-0-beta-47", jo = `rdg-cell-drag-over ${vo}`;
function ko({
  column: e,
  colSpan: t,
  rowIdx: s,
  isCellSelected: r,
  onColumnResize: o,
  onColumnsReorder: c,
  sortColumns: f,
  onSortColumnsChange: h,
  selectCell: m,
  shouldFocusGrid: p,
  direction: b,
  dragDropKey: C
}) {
  const [x, l] = w.useState(!1), [v, y] = w.useState(!1), R = b === "rtl", g = Wn(e, s), {
    tabIndex: N,
    childTabIndex: T,
    onFocus: j
  } = at(r), k = f == null ? void 0 : f.findIndex((F) => F.columnKey === e.key), P = k !== void 0 && k > -1 ? f[k] : void 0, u = P == null ? void 0 : P.direction, d = P !== void 0 && f.length > 1 ? k + 1 : void 0, I = u && !d ? u === "ASC" ? "ascending" : "descending" : void 0, {
    sortable: A,
    resizable: z,
    draggable: L
  } = e, H = it(e, e.headerCellClass, A && mo, z && Co, L && Ro, x && So, v && jo), q = e.renderHeaderCell ?? xo;
  function $(F) {
    if (F.pointerType === "mouse" && F.buttons !== 1)
      return;
    F.preventDefault();
    const {
      currentTarget: B,
      pointerId: Z
    } = F, re = B.parentElement, {
      right: Oe,
      left: Ke
    } = re.getBoundingClientRect(), Ee = R ? F.clientX - Ke : Oe - F.clientX;
    let fe = !1;
    function Ie(he) {
      const {
        width: ge,
        right: gt,
        left: De
      } = re.getBoundingClientRect();
      let xe = R ? gt + Ee - he.clientX : he.clientX + Ee - De;
      xe = zn(xe, e), ge > 0 && xe !== ge && o(e, xe);
    }
    function Ue() {
      fe = !0, o(e, "max-content");
    }
    function Ge(he) {
      fe || Ie(he), B.removeEventListener("pointermove", Ie), B.removeEventListener("dblclick", Ue), B.removeEventListener("lostpointercapture", Ge);
    }
    B.setPointerCapture(Z), B.addEventListener("pointermove", Ie), B.addEventListener("dblclick", Ue), B.addEventListener("lostpointercapture", Ge);
  }
  function te(F) {
    if (h == null) return;
    const {
      sortDescendingFirst: B
    } = e;
    if (P === void 0) {
      const Z = {
        columnKey: e.key,
        direction: B ? "DESC" : "ASC"
      };
      h(f && F ? [...f, Z] : [Z]);
    } else {
      let Z;
      if ((B === !0 && u === "DESC" || B !== !0 && u === "ASC") && (Z = {
        columnKey: e.key,
        direction: u === "ASC" ? "DESC" : "ASC"
      }), F) {
        const re = [...f];
        Z ? re[k] = Z : re.splice(k, 1), h(re);
      } else
        h(Z ? [Z] : []);
    }
  }
  function je(F) {
    m({
      idx: e.idx,
      rowIdx: s
    }), A && te(F.ctrlKey || F.metaKey);
  }
  function ke(F) {
    j == null || j(F), p && m({
      idx: 0,
      rowIdx: s
    });
  }
  function ct(F) {
    (F.key === " " || F.key === "Enter") && (F.preventDefault(), te(F.ctrlKey || F.metaKey));
  }
  function dt(F) {
    F.dataTransfer.setData(C, e.key), F.dataTransfer.dropEffect = "move", l(!0);
  }
  function ut() {
    l(!1);
  }
  function ft(F) {
    F.preventDefault(), F.dataTransfer.dropEffect = "move";
  }
  function ht(F) {
    if (y(!1), F.dataTransfer.types.includes(C.toLowerCase())) {
      const B = F.dataTransfer.getData(C.toLowerCase());
      B !== e.key && (F.preventDefault(), c == null || c(B, e.key));
    }
  }
  function _(F) {
    wn(F) && y(!0);
  }
  function Be(F) {
    wn(F) && y(!1);
  }
  let oe;
  return L && (oe = {
    draggable: !0,
    onDragStart: dt,
    onDragEnd: ut,
    onDragOver: ft,
    onDragEnter: _,
    onDragLeave: Be,
    onDrop: ht
  }), /* @__PURE__ */ n.jsxs("div", {
    role: "columnheader",
    "aria-colindex": e.idx + 1,
    "aria-colspan": t,
    "aria-rowspan": g,
    "aria-selected": r,
    "aria-sort": I,
    tabIndex: p ? 0 : N,
    className: H,
    style: {
      ...Mn(e, s, g),
      ...$e(e, t)
    },
    onFocus: ke,
    onClick: je,
    onKeyDown: A ? ct : void 0,
    ...oe,
    children: [q({
      column: e,
      sortDirection: u,
      priority: d,
      tabIndex: T
    }), z && /* @__PURE__ */ n.jsx("div", {
      className: bo,
      onClick: js,
      onPointerDown: $
    })]
  });
}
function wn(e) {
  const t = e.relatedTarget;
  return !e.currentTarget.contains(t);
}
const Eo = "r1upfr807-0-0-beta-47", Vn = `rdg-row ${Eo}`, Io = "r190mhd37-0-0-beta-47", Ht = "rdg-row-selected", Do = "r139qu9m7-0-0-beta-47", To = "rdg-top-summary-row", Po = "rdg-bottom-summary-row", No = "h10tskcx7-0-0-beta-47", qn = `rdg-header-row ${No}`;
function Ao({
  rowIdx: e,
  columns: t,
  onColumnResize: s,
  onColumnsReorder: r,
  sortColumns: o,
  onSortColumnsChange: c,
  lastFrozenColumnIndex: f,
  selectedCellIdx: h,
  selectCell: m,
  shouldFocusGrid: p,
  direction: b
}) {
  const C = w.useId(), x = [];
  for (let l = 0; l < t.length; l++) {
    const v = t[l], y = ee(v, f, {
      type: "HEADER"
    });
    y !== void 0 && (l += y - 1), x.push(/* @__PURE__ */ n.jsx(ko, {
      column: v,
      colSpan: y,
      rowIdx: e,
      isCellSelected: h === v.idx,
      onColumnResize: s,
      onColumnsReorder: r,
      onSortColumnsChange: c,
      sortColumns: o,
      selectCell: m,
      shouldFocusGrid: p && l === 0,
      direction: b,
      dragDropKey: C
    }, v.key));
  }
  return /* @__PURE__ */ n.jsx("div", {
    role: "row",
    "aria-rowindex": e,
    className: ae(qn, h === -1 && Ht),
    children: x
  });
}
const Fo = /* @__PURE__ */ w.memo(Ao);
function Ho({
  rowIdx: e,
  level: t,
  columns: s,
  selectedCellIdx: r,
  selectCell: o
}) {
  const c = [], f = /* @__PURE__ */ new Set();
  for (const h of s) {
    let {
      parent: m
    } = h;
    if (m !== void 0) {
      for (; m.level > t && m.parent !== void 0; )
        m = m.parent;
      if (m.level === t && !f.has(m)) {
        f.add(m);
        const {
          idx: p
        } = m;
        c.push(/* @__PURE__ */ n.jsx(uo, {
          column: m,
          rowIdx: e,
          isCellSelected: r === p,
          selectCell: o
        }, p));
      }
    }
  }
  return /* @__PURE__ */ n.jsx("div", {
    role: "row",
    "aria-rowindex": e,
    className: qn,
    children: c
  });
}
const Lo = /* @__PURE__ */ w.memo(Ho), Mo = "c6ra8a37-0-0-beta-47", zo = `rdg-cell-copied ${Mo}`, Wo = "cq910m07-0-0-beta-47", $o = `rdg-cell-dragged-over ${Wo}`;
function Bo({
  column: e,
  colSpan: t,
  isCellSelected: s,
  isCopied: r,
  isDraggedOver: o,
  row: c,
  rowIdx: f,
  onClick: h,
  onDoubleClick: m,
  onContextMenu: p,
  onRowChange: b,
  selectCell: C,
  ...x
}) {
  const {
    tabIndex: l,
    childTabIndex: v,
    onFocus: y
  } = at(s), {
    cellClass: R
  } = e, g = it(e, typeof R == "function" ? R(c) : R, r && zo, o && $o), N = Fn(e, c);
  function T(d) {
    C({
      rowIdx: f,
      idx: e.idx
    }, d);
  }
  function j(d) {
    if (h) {
      const I = Le(d);
      if (h({
        row: c,
        column: e,
        selectCell: T
      }, I), I.isGridDefaultPrevented()) return;
    }
    T();
  }
  function k(d) {
    if (p) {
      const I = Le(d);
      if (p({
        row: c,
        column: e,
        selectCell: T
      }, I), I.isGridDefaultPrevented()) return;
    }
    T();
  }
  function P(d) {
    if (m) {
      const I = Le(d);
      if (m({
        row: c,
        column: e,
        selectCell: T
      }, I), I.isGridDefaultPrevented()) return;
    }
    T(!0);
  }
  function u(d) {
    b(e, d);
  }
  return /* @__PURE__ */ n.jsx("div", {
    role: "gridcell",
    "aria-colindex": e.idx + 1,
    "aria-colspan": t,
    "aria-selected": s,
    "aria-readonly": !N || void 0,
    tabIndex: l,
    className: g,
    style: $e(e, t),
    onClick: j,
    onDoubleClick: P,
    onContextMenu: k,
    onFocus: y,
    ...x,
    children: e.renderCell({
      column: e,
      row: c,
      rowIdx: f,
      isCellEditable: N,
      tabIndex: v,
      onRowChange: u
    })
  });
}
const Oo = /* @__PURE__ */ w.memo(Bo);
function Ko({
  className: e,
  rowIdx: t,
  gridRowStart: s,
  selectedCellIdx: r,
  isRowSelectionDisabled: o,
  isRowSelected: c,
  copiedCellIdx: f,
  draggedOverCellIdx: h,
  lastFrozenColumnIndex: m,
  row: p,
  viewportColumns: b,
  selectedCellEditor: C,
  onCellClick: x,
  onCellDoubleClick: l,
  onCellContextMenu: v,
  rowClass: y,
  setDraggedOverRowIdx: R,
  onMouseEnter: g,
  onRowChange: N,
  selectCell: T,
  ...j
}, k) {
  const P = J((A, z) => {
    N(A, t, z);
  });
  function u(A) {
    R == null || R(t), g == null || g(A);
  }
  e = ae(Vn, `rdg-row-${t % 2 === 0 ? "even" : "odd"}`, y == null ? void 0 : y(p, t), e, r === -1 && Ht);
  const d = [];
  for (let A = 0; A < b.length; A++) {
    const z = b[A], {
      idx: L
    } = z, H = ee(z, m, {
      type: "ROW",
      row: p
    });
    H !== void 0 && (A += H - 1);
    const q = r === L;
    q && C ? d.push(C) : d.push(/* @__PURE__ */ n.jsx(Oo, {
      column: z,
      colSpan: H,
      row: p,
      rowIdx: t,
      isCopied: f === L,
      isDraggedOver: h === L,
      isCellSelected: q,
      onClick: x,
      onDoubleClick: l,
      onContextMenu: v,
      onRowChange: P,
      selectCell: T
    }, z.key));
  }
  const I = w.useMemo(() => ({
    isRowSelected: c,
    isRowSelectionDisabled: o
  }), [o, c]);
  return /* @__PURE__ */ n.jsx(Gs, {
    value: I,
    children: /* @__PURE__ */ n.jsx("div", {
      role: "row",
      ref: k,
      className: e,
      onMouseEnter: u,
      style: Ln(s),
      ...j,
      children: d
    })
  });
}
const Uo = /* @__PURE__ */ w.memo(/* @__PURE__ */ w.forwardRef(Ko));
function Go(e, t) {
  return /* @__PURE__ */ n.jsx(Uo, {
    ...t
  }, e);
}
function _o({
  scrollToPosition: {
    idx: e,
    rowIdx: t
  },
  gridElement: s,
  setScrollToCellPosition: r
}) {
  const o = w.useRef(null);
  return ve(() => {
    rt(o.current);
  }), ve(() => {
    function c() {
      r(null);
    }
    const f = new IntersectionObserver(c, {
      root: s,
      threshold: 1
    });
    return f.observe(o.current), () => {
      f.disconnect();
    };
  }, [s, r]), /* @__PURE__ */ n.jsx("div", {
    ref: o,
    style: {
      gridColumn: e === void 0 ? "1/-1" : e + 1,
      gridRow: t === void 0 ? "1/-1" : t + 2
    }
  });
}
const Vo = "a3ejtar7-0-0-beta-47", qo = `rdg-sort-arrow ${Vo}`;
function Xo({
  sortDirection: e,
  priority: t
}) {
  return /* @__PURE__ */ n.jsxs(n.Fragment, {
    children: [Yo({
      sortDirection: e
    }), Jo({
      priority: t
    })]
  });
}
function Yo({
  sortDirection: e
}) {
  return e === void 0 ? null : /* @__PURE__ */ n.jsx("svg", {
    viewBox: "0 0 12 8",
    width: "12",
    height: "8",
    className: qo,
    "aria-hidden": !0,
    children: /* @__PURE__ */ n.jsx("path", {
      d: e === "ASC" ? "M0 8 6 0 12 8" : "M0 0 6 8 12 0"
    })
  });
}
function Jo({
  priority: e
}) {
  return e;
}
const Zo = "rnvodz57-0-0-beta-47", Qo = `rdg ${Zo}`, el = "vlqv91k7-0-0-beta-47", tl = `rdg-viewport-dragging ${el}`, nl = "f1lsfrzw7-0-0-beta-47", rl = "f1cte0lg7-0-0-beta-47", sl = "s8wc6fl7-0-0-beta-47";
function ol({
  column: e,
  colSpan: t,
  row: s,
  rowIdx: r,
  isCellSelected: o,
  selectCell: c
}) {
  var x;
  const {
    tabIndex: f,
    childTabIndex: h,
    onFocus: m
  } = at(o), {
    summaryCellClass: p
  } = e, b = it(e, sl, typeof p == "function" ? p(s) : p);
  function C() {
    c({
      rowIdx: r,
      idx: e.idx
    });
  }
  return /* @__PURE__ */ n.jsx("div", {
    role: "gridcell",
    "aria-colindex": e.idx + 1,
    "aria-colspan": t,
    "aria-selected": o,
    tabIndex: f,
    className: b,
    style: $e(e, t),
    onClick: C,
    onFocus: m,
    children: (x = e.renderSummaryCell) == null ? void 0 : x.call(e, {
      column: e,
      row: s,
      tabIndex: h
    })
  });
}
const ll = /* @__PURE__ */ w.memo(ol), il = "skuhp557-0-0-beta-47", al = "tf8l5ub7-0-0-beta-47", cl = `rdg-summary-row ${il}`;
function dl({
  rowIdx: e,
  gridRowStart: t,
  row: s,
  viewportColumns: r,
  top: o,
  bottom: c,
  lastFrozenColumnIndex: f,
  selectedCellIdx: h,
  isTop: m,
  selectCell: p,
  "aria-rowindex": b
}) {
  const C = [];
  for (let x = 0; x < r.length; x++) {
    const l = r[x], v = ee(l, f, {
      type: "SUMMARY",
      row: s
    });
    v !== void 0 && (x += v - 1);
    const y = h === l.idx;
    C.push(/* @__PURE__ */ n.jsx(ll, {
      column: l,
      colSpan: v,
      row: s,
      rowIdx: e,
      isCellSelected: y,
      selectCell: p
    }, l.key));
  }
  return /* @__PURE__ */ n.jsx("div", {
    role: "row",
    "aria-rowindex": b,
    className: ae(Vn, `rdg-row-${e % 2 === 0 ? "even" : "odd"}`, cl, m ? `${To} ${al}` : Po, h === -1 && Ht),
    style: {
      ...Ln(t),
      "--rdg-summary-row-top": o !== void 0 ? `${o}px` : void 0,
      "--rdg-summary-row-bottom": c !== void 0 ? `${c}px` : void 0
    },
    children: C
  });
}
const mn = /* @__PURE__ */ w.memo(dl);
function ul(e, t) {
  const {
    columns: s,
    rows: r,
    topSummaryRows: o,
    bottomSummaryRows: c,
    rowKeyGetter: f,
    onRowsChange: h,
    rowHeight: m,
    headerRowHeight: p,
    summaryRowHeight: b,
    selectedRows: C,
    isRowSelectionDisabled: x,
    onSelectedRowsChange: l,
    sortColumns: v,
    onSortColumnsChange: y,
    defaultColumnOptions: R,
    onCellClick: g,
    onCellDoubleClick: N,
    onCellContextMenu: T,
    onCellKeyDown: j,
    onSelectedCellChange: k,
    onScroll: P,
    onColumnResize: u,
    onColumnsReorder: d,
    onFill: I,
    onCopy: A,
    onPaste: z,
    enableVirtualization: L,
    renderers: H,
    className: q,
    style: $,
    rowClass: te,
    direction: je,
    role: ke,
    "aria-label": ct,
    "aria-labelledby": dt,
    "aria-describedby": ut,
    "aria-rowcount": ft,
    "data-testid": ht
  } = e, _ = Bn(), Be = ke ?? "grid", oe = m ?? 35, F = p ?? (typeof oe == "number" ? oe : 35), B = b ?? (typeof oe == "number" ? oe : 35), Z = (H == null ? void 0 : H.renderRow) ?? (_ == null ? void 0 : _.renderRow) ?? Go, re = (H == null ? void 0 : H.renderSortStatus) ?? (_ == null ? void 0 : _.renderSortStatus) ?? Xo, Oe = (H == null ? void 0 : H.renderCheckbox) ?? (_ == null ? void 0 : _.renderCheckbox) ?? Os, Ke = (H == null ? void 0 : H.noRowsFallback) ?? (_ == null ? void 0 : _.noRowsFallback), Ee = L ?? !0, fe = je ?? "ltr", [Ie, Ue] = w.useState(0), [Ge, he] = w.useState(0), [ge, gt] = w.useState(() => /* @__PURE__ */ new Map()), [De, xe] = w.useState(() => /* @__PURE__ */ new Map()), [we, Lt] = w.useState(null), [Mt, Xn] = w.useState(!1), [Te, Yn] = w.useState(void 0), [le, zt] = w.useState(null), Wt = w.useCallback((i) => ge.get(i.key) ?? De.get(i.key) ?? i.width, [De, ge]), [me, $t, Bt, Jn] = to(), {
    columns: G,
    colSpanColumns: Ot,
    lastFrozenColumnIndex: Q,
    headerRowsCount: ce,
    colOverscanStartIdx: Zn,
    colOverscanEndIdx: Kt,
    templateColumns: Qn,
    layoutCssVars: er,
    totalFrozenColumnWidth: tr
  } = Qs({
    rawColumns: s,
    defaultColumnOptions: R,
    getColumnWidth: Wt,
    scrollLeft: Ge,
    viewportWidth: $t,
    enableVirtualization: Ee
  }), Pe = (o == null ? void 0 : o.length) ?? 0, pe = (c == null ? void 0 : c.length) ?? 0, Ut = Pe + pe, Ce = ce + Pe, xt = ce - 1, X = -Ce, _e = X + xt, de = r.length + pe - 1, [S, be] = w.useState(() => ({
    idx: -1,
    rowIdx: X - 1,
    mode: "SELECT"
  })), wt = w.useRef(S), Gt = w.useRef(Te), _t = w.useRef(-1), Ve = w.useRef(null), qe = w.useRef(!1), mt = Be === "treegrid", pt = ce * F, Vt = Ut * B, Xe = Bt - pt - Vt, Ct = C != null && l != null, qt = fe === "rtl", nr = qt ? "ArrowRight" : "ArrowLeft", Xt = qt ? "ArrowLeft" : "ArrowRight", Yt = ft ?? ce + r.length + Ut, rr = w.useMemo(() => ({
    renderCheckbox: Oe,
    renderSortStatus: re
  }), [Oe, re]), sr = w.useMemo(() => {
    let i = !1, a = !1;
    if (f != null && C != null && C.size > 0) {
      for (const E of r)
        if (C.has(f(E)) ? i = !0 : a = !0, i && a) break;
    }
    return {
      isRowSelected: i && !a,
      isIndeterminate: i && a
    };
  }, [r, C, f]), {
    rowOverscanStartIdx: Ne,
    rowOverscanEndIdx: Ae,
    totalRowHeight: bt,
    gridTemplateRows: or,
    getRowTop: Jt,
    getRowHeight: lr,
    findRowIdx: Zt
  } = ro({
    rows: r,
    rowHeight: oe,
    clientHeight: Xe,
    scrollTop: Ie,
    enableVirtualization: Ee
  }), ie = no({
    columns: G,
    colSpanColumns: Ot,
    colOverscanStartIdx: Zn,
    colOverscanEndIdx: Kt,
    lastFrozenColumnIndex: Q,
    rowOverscanStartIdx: Ne,
    rowOverscanEndIdx: Ae,
    rows: r,
    topSummaryRows: o,
    bottomSummaryRows: c
  }), {
    gridTemplateColumns: ir,
    handleColumnResize: ar
  } = eo(G, ie, Qn, me, $t, ge, De, gt, xe, u), cr = mt ? -1 : 0, Re = G.length - 1, Rt = vt(S), Ye = rn(S), dr = F + bt + Vt + Jn, ur = J(ar), fr = J(d), hr = J(y), gr = J(g), xr = J(N), wr = J(T), mr = J(br), pr = J(en), Cr = J(Je), yt = J(Fe), Qt = J(({
    idx: i,
    rowIdx: a
  }) => {
    Fe({
      rowIdx: X + a - 1,
      idx: i
    });
  });
  ve(() => {
    if (!Rt || Nt(S, wt.current)) {
      wt.current = S;
      return;
    }
    wt.current = S, S.idx === -1 && (Ve.current.focus({
      preventScroll: !0
    }), rt(Ve.current));
  }), ve(() => {
    qe.current && (qe.current = !1, on());
  }), w.useImperativeHandle(t, () => ({
    element: me.current,
    scrollToCell({
      idx: i,
      rowIdx: a
    }) {
      const E = i !== void 0 && i > Q && i < G.length ? i : void 0, D = a !== void 0 && ye(a) ? a : void 0;
      (E !== void 0 || D !== void 0) && zt({
        idx: E,
        rowIdx: D
      });
    },
    selectCell: Fe
  }));
  const St = w.useCallback((i) => {
    Yn(i), Gt.current = i;
  }, []);
  function br(i) {
    if (!l) return;
    Pt(f);
    const a = new Set(C);
    for (const E of r) {
      if ((x == null ? void 0 : x(E)) === !0) continue;
      const D = f(E);
      i.checked ? a.add(D) : a.delete(D);
    }
    l(a);
  }
  function en(i) {
    if (!l) return;
    Pt(f);
    const {
      row: a,
      checked: E,
      isShiftClick: D
    } = i;
    if ((x == null ? void 0 : x(a)) === !0) return;
    const M = new Set(C), W = f(a), O = _t.current, U = r.indexOf(a);
    if (_t.current = U, E ? M.add(W) : M.delete(W), D && O !== -1 && O !== U && O < r.length) {
      const Y = zs(U - O);
      for (let V = O + Y; V !== U; V += Y) {
        const ne = r[V];
        (x == null ? void 0 : x(ne)) !== !0 && (E ? M.add(f(ne)) : M.delete(f(ne)));
      }
    }
    l(M);
  }
  function Rr(i) {
    var U;
    const {
      idx: a,
      rowIdx: E,
      mode: D
    } = S;
    if (D === "EDIT") return;
    if (j && ye(E)) {
      const Y = r[E], V = Le(i);
      if (j({
        mode: "SELECT",
        row: Y,
        column: G[a],
        rowIdx: E,
        selectCell: Fe
      }, V), V.isGridDefaultPrevented()) return;
    }
    if (!(i.target instanceof Element)) return;
    const M = i.target.closest(".rdg-cell") !== null, W = mt && i.target === Ve.current;
    if (!M && !W) return;
    const {
      keyCode: O
    } = i;
    if (Ye && (z != null || A != null) && Ft(i)) {
      if (O === 67) {
        if (((U = window.getSelection()) == null ? void 0 : U.isCollapsed) === !1) return;
        Sr();
        return;
      }
      if (O === 86) {
        vr();
        return;
      }
    }
    switch (i.key) {
      case "Escape":
        Lt(null);
        return;
      case "ArrowUp":
      case "ArrowDown":
      case "ArrowLeft":
      case "ArrowRight":
      case "Tab":
      case "Home":
      case "End":
      case "PageUp":
      case "PageDown":
        sn(i);
        break;
      default:
        jr(i);
        break;
    }
  }
  function yr(i) {
    const {
      scrollTop: a,
      scrollLeft: E
    } = i.currentTarget;
    ot.flushSync(() => {
      Ue(a), he(Ws(E));
    }), P == null || P(i);
  }
  function Je(i, a, E) {
    if (typeof h != "function" || E === r[a]) return;
    const D = [...r];
    D[a] = E, h(D, {
      indexes: [a],
      column: i
    });
  }
  function tn() {
    S.mode === "EDIT" && Je(G[S.idx], S.rowIdx, S.row);
  }
  function Sr() {
    const {
      idx: i,
      rowIdx: a
    } = S, E = r[a], D = G[i].key;
    Lt({
      row: E,
      columnKey: D
    }), A == null || A({
      sourceRow: E,
      sourceColumnKey: D
    });
  }
  function vr() {
    if (!z || !h || we === null || !Ze(S))
      return;
    const {
      idx: i,
      rowIdx: a
    } = S, E = G[i], D = r[a], M = z({
      sourceRow: we.row,
      sourceColumnKey: we.columnKey,
      targetRow: D,
      targetColumnKey: E.key
    });
    Je(E, a, M);
  }
  function jr(i) {
    if (!Ye) return;
    const a = r[S.rowIdx], {
      key: E,
      shiftKey: D
    } = i;
    if (Ct && D && E === " ") {
      Pt(f);
      const M = f(a);
      en({
        row: a,
        checked: !C.has(M),
        isShiftClick: !1
      }), i.preventDefault();
      return;
    }
    Ze(S) && Es(i) && be(({
      idx: M,
      rowIdx: W
    }) => ({
      idx: M,
      rowIdx: W,
      mode: "EDIT",
      row: a,
      originalRow: a
    }));
  }
  function nn(i) {
    return i >= cr && i <= Re;
  }
  function ye(i) {
    return i >= 0 && i < r.length;
  }
  function vt({
    idx: i,
    rowIdx: a
  }) {
    return a >= X && a <= de && nn(i);
  }
  function kr({
    idx: i,
    rowIdx: a
  }) {
    return ye(a) && i >= 0 && i <= Re;
  }
  function rn({
    idx: i,
    rowIdx: a
  }) {
    return ye(a) && nn(i);
  }
  function Ze(i) {
    return kr(i) && Ps({
      columns: G,
      rows: r,
      selectedPosition: i
    });
  }
  function Fe(i, a) {
    if (!vt(i)) return;
    tn();
    const E = r[i.rowIdx], D = Nt(S, i);
    a && Ze(i) ? be({
      ...i,
      mode: "EDIT",
      row: E,
      originalRow: E
    }) : D ? rt(pn(me.current)) : (qe.current = !0, be({
      ...i,
      mode: "SELECT"
    })), k && !D && k({
      rowIdx: i.rowIdx,
      row: E,
      column: G[i.idx]
    });
  }
  function Er(i, a, E) {
    const {
      idx: D,
      rowIdx: M
    } = S, W = Rt && D === -1;
    switch (i) {
      case "ArrowUp":
        return {
          idx: D,
          rowIdx: M - 1
        };
      case "ArrowDown":
        return {
          idx: D,
          rowIdx: M + 1
        };
      case nr:
        return {
          idx: D - 1,
          rowIdx: M
        };
      case Xt:
        return {
          idx: D + 1,
          rowIdx: M
        };
      case "Tab":
        return {
          idx: D + (E ? -1 : 1),
          rowIdx: M
        };
      case "Home":
        return W ? {
          idx: D,
          rowIdx: X
        } : {
          idx: 0,
          rowIdx: a ? X : M
        };
      case "End":
        return W ? {
          idx: D,
          rowIdx: de
        } : {
          idx: Re,
          rowIdx: a ? de : M
        };
      case "PageUp": {
        if (S.rowIdx === X) return S;
        const O = Jt(M) + lr(M) - Xe;
        return {
          idx: D,
          rowIdx: O > 0 ? Zt(O) : 0
        };
      }
      case "PageDown": {
        if (S.rowIdx >= r.length) return S;
        const O = Jt(M) + Xe;
        return {
          idx: D,
          rowIdx: O < bt ? Zt(O) : r.length - 1
        };
      }
      default:
        return S;
    }
  }
  function sn(i) {
    const {
      key: a,
      shiftKey: E
    } = i;
    let D = "NONE";
    if (a === "Tab") {
      if (Fs({
        shiftKey: E,
        maxColIdx: Re,
        minRowIdx: X,
        maxRowIdx: de,
        selectedPosition: S
      })) {
        tn();
        return;
      }
      D = "CHANGE_ROW";
    }
    i.preventDefault();
    const M = Ft(i), W = Er(a, M, E);
    if (Nt(S, W)) return;
    const O = As({
      moveUp: a === "ArrowUp",
      moveNext: a === Xt || a === "Tab" && !E,
      columns: G,
      colSpanColumns: Ot,
      rows: r,
      topSummaryRows: o,
      bottomSummaryRows: c,
      minRowIdx: X,
      mainHeaderRowIdx: _e,
      maxRowIdx: de,
      lastFrozenColumnIndex: Q,
      cellNavigationMode: D,
      currentPosition: S,
      nextPosition: W,
      isCellWithinBounds: vt
    });
    Fe(O);
  }
  function Ir(i) {
    if (Te === void 0) return;
    const {
      rowIdx: a
    } = S;
    return (a < Te ? a < i && i <= Te : a > i && i >= Te) ? S.idx : void 0;
  }
  function on() {
    const i = pn(me.current);
    if (i === null) return;
    rt(i), (i.querySelector('[tabindex="0"]') ?? i).focus({
      preventScroll: !0
    });
  }
  function Dr() {
    if (I == null || S.mode === "EDIT" || !rn(S))
      return;
    const {
      idx: i,
      rowIdx: a
    } = S, E = G[i];
    if (E.renderEditCell == null || E.editable === !1)
      return;
    const D = Wt(E);
    return /* @__PURE__ */ n.jsx(io, {
      gridRowStart: Ce + a + 1,
      rows: r,
      column: E,
      columnWidth: D,
      maxColIdx: Re,
      isLastRow: a === de,
      selectedPosition: S,
      isCellEditable: Ze,
      latestDraggedOverRowIdx: Gt,
      onRowsChange: h,
      onClick: on,
      onFill: I,
      setDragging: Xn,
      setDraggedOverRowIdx: St
    });
  }
  function Tr(i) {
    if (S.rowIdx !== i || S.mode === "SELECT") return;
    const {
      idx: a,
      row: E
    } = S, D = G[a], M = ee(D, Q, {
      type: "ROW",
      row: E
    }), W = (U) => {
      qe.current = U, be(({
        idx: Y,
        rowIdx: V
      }) => ({
        idx: Y,
        rowIdx: V,
        mode: "SELECT"
      }));
    }, O = (U, Y, V) => {
      Y ? ot.flushSync(() => {
        Je(D, S.rowIdx, U), W(V);
      }) : be((ne) => ({
        ...ne,
        row: U
      }));
    };
    return r[S.rowIdx] !== S.originalRow && W(!1), /* @__PURE__ */ n.jsx(co, {
      column: D,
      colSpan: M,
      row: E,
      rowIdx: i,
      onRowChange: O,
      closeEditor: W,
      onKeyDown: j,
      navigate: sn
    }, D.key);
  }
  function He(i) {
    const a = S.idx === -1 ? void 0 : G[S.idx];
    return a !== void 0 && S.rowIdx === i && !ie.includes(a) ? S.idx > Kt ? [...ie, a] : [...ie.slice(0, Q + 1), a, ...ie.slice(Q + 1)] : ie;
  }
  function Pr() {
    const i = [], {
      idx: a,
      rowIdx: E
    } = S, D = Ye && E < Ne ? Ne - 1 : Ne, M = Ye && E > Ae ? Ae + 1 : Ae;
    for (let W = D; W <= M; W++) {
      const O = W === Ne - 1 || W === Ae + 1, U = O ? E : W;
      let Y = ie;
      const V = a === -1 ? void 0 : G[a];
      V !== void 0 && (O ? Y = [V] : Y = He(U));
      const ne = r[U], Nr = Ce + U + 1;
      let jt = U, kt = !1;
      typeof f == "function" && (jt = f(ne), kt = (C == null ? void 0 : C.has(jt)) ?? !1), i.push(Z(jt, {
        "aria-rowindex": Ce + U + 1,
        "aria-selected": Ct ? kt : void 0,
        rowIdx: U,
        row: ne,
        viewportColumns: Y,
        isRowSelectionDisabled: (x == null ? void 0 : x(ne)) ?? !1,
        isRowSelected: kt,
        onCellClick: gr,
        onCellDoubleClick: xr,
        onCellContextMenu: wr,
        rowClass: te,
        gridRowStart: Nr,
        copiedCellIdx: we !== null && we.row === ne ? G.findIndex((Ar) => Ar.key === we.columnKey) : void 0,
        selectedCellIdx: E === U ? a : void 0,
        draggedOverCellIdx: Ir(U),
        setDraggedOverRowIdx: Mt ? St : void 0,
        lastFrozenColumnIndex: Q,
        onRowChange: Cr,
        selectCell: yt,
        selectedCellEditor: Tr(U)
      }));
    }
    return i;
  }
  (S.idx > Re || S.rowIdx > de) && (be({
    idx: -1,
    rowIdx: X - 1,
    mode: "SELECT"
  }), St(void 0));
  let Qe = `repeat(${ce}, ${F}px)`;
  Pe > 0 && (Qe += ` repeat(${Pe}, ${B}px)`), r.length > 0 && (Qe += or), pe > 0 && (Qe += ` repeat(${pe}, ${B}px)`);
  const ln = S.idx === -1 && S.rowIdx !== X - 1;
  return /* @__PURE__ */ n.jsxs("div", {
    role: Be,
    "aria-label": ct,
    "aria-labelledby": dt,
    "aria-describedby": ut,
    "aria-multiselectable": Ct ? !0 : void 0,
    "aria-colcount": G.length,
    "aria-rowcount": Yt,
    className: ae(Qo, q, Mt && tl),
    style: {
      ...$,
      scrollPaddingInlineStart: S.idx > Q || (le == null ? void 0 : le.idx) !== void 0 ? `${tr}px` : void 0,
      scrollPaddingBlock: ye(S.rowIdx) || (le == null ? void 0 : le.rowIdx) !== void 0 ? `${pt + Pe * B}px ${pe * B}px` : void 0,
      gridTemplateColumns: ir,
      gridTemplateRows: Qe,
      "--rdg-header-row-height": `${F}px`,
      "--rdg-scroll-height": `${dr}px`,
      ...er
    },
    dir: fe,
    ref: me,
    onScroll: yr,
    onKeyDown: Rr,
    "data-testid": ht,
    children: [/* @__PURE__ */ n.jsxs(Us, {
      value: rr,
      children: [/* @__PURE__ */ n.jsx(Xs, {
        value: mr,
        children: /* @__PURE__ */ n.jsxs(qs, {
          value: sr,
          children: [Array.from({
            length: xt
          }, (i, a) => /* @__PURE__ */ n.jsx(Lo, {
            rowIdx: a + 1,
            level: -xt + a,
            columns: He(X + a),
            selectedCellIdx: S.rowIdx === X + a ? S.idx : void 0,
            selectCell: Qt
          }, a)), /* @__PURE__ */ n.jsx(Fo, {
            rowIdx: ce,
            columns: He(_e),
            onColumnResize: ur,
            onColumnsReorder: fr,
            sortColumns: v,
            onSortColumnsChange: hr,
            lastFrozenColumnIndex: Q,
            selectedCellIdx: S.rowIdx === _e ? S.idx : void 0,
            selectCell: Qt,
            shouldFocusGrid: !Rt,
            direction: fe
          })]
        })
      }), r.length === 0 && Ke ? Ke : /* @__PURE__ */ n.jsxs(n.Fragment, {
        children: [o == null ? void 0 : o.map((i, a) => {
          const E = ce + 1 + a, D = _e + 1 + a, M = S.rowIdx === D, W = pt + B * a;
          return /* @__PURE__ */ n.jsx(mn, {
            "aria-rowindex": E,
            rowIdx: D,
            gridRowStart: E,
            row: i,
            top: W,
            bottom: void 0,
            viewportColumns: He(D),
            lastFrozenColumnIndex: Q,
            selectedCellIdx: M ? S.idx : void 0,
            isTop: !0,
            selectCell: yt
          }, a);
        }), /* @__PURE__ */ n.jsx(_s, {
          value: pr,
          children: Pr()
        }), c == null ? void 0 : c.map((i, a) => {
          const E = Ce + r.length + a + 1, D = r.length + a, M = S.rowIdx === D, W = Xe > bt ? Bt - B * (c.length - a) : void 0, O = W === void 0 ? B * (c.length - 1 - a) : void 0;
          return /* @__PURE__ */ n.jsx(mn, {
            "aria-rowindex": Yt - pe + a + 1,
            rowIdx: D,
            gridRowStart: E,
            row: i,
            top: W,
            bottom: O,
            viewportColumns: He(D),
            lastFrozenColumnIndex: Q,
            selectedCellIdx: M ? S.idx : void 0,
            isTop: !1,
            selectCell: yt
          }, a);
        })]
      })]
    }), Dr(), Ts(ie), mt && /* @__PURE__ */ n.jsx("div", {
      ref: Ve,
      tabIndex: ln ? 0 : -1,
      className: ae(nl, ln && [Io, Q !== -1 && Do], !ye(S.rowIdx) && rl),
      style: {
        gridRowStart: S.rowIdx + Ce + 1
      }
    }), le !== null && /* @__PURE__ */ n.jsx(_o, {
      scrollToPosition: le,
      setScrollToCellPosition: zt,
      gridElement: me.current
    })]
  });
}
function pn(e) {
  return e.querySelector(':scope > [role="row"] > [tabindex="0"]');
}
function Nt(e, t) {
  return e.idx === t.idx && e.rowIdx === t.rowIdx;
}
const fl = /* @__PURE__ */ w.forwardRef(ul);
function hl() {
  const { isRowSelected: e, onRowSelectionChange: t } = Ys();
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      className: se(
        "flex items-center justify-start h-full pl-4",
        "bg-muted/50 hover:bg-muted",
        "data-[state=open]:bg-muted"
      ),
      children: /* @__PURE__ */ n.jsx(
        Tn,
        {
          "aria-label": "Select all rows",
          checked: !!e,
          onCheckedChange: (s) => {
            t({ checked: !!s });
          }
        }
      )
    }
  );
}
function gl({
  row: e,
  rowIndex: t,
  onClick: s
}) {
  const { isRowSelected: r, onRowSelectionChange: o } = Vs();
  return /* @__PURE__ */ n.jsxs(
    "div",
    {
      className: se("flex items-center justify-start h-full pl-4 group"),
      onClick: s,
      children: [
        /* @__PURE__ */ n.jsx(
          "div",
          {
            className: se("group-hover:block hidden", r && "!block"),
            children: /* @__PURE__ */ n.jsx(
              Tn,
              {
                "aria-label": "Select row",
                checked: !!r,
                onCheckedChange: (c) => {
                  o({
                    row: e,
                    checked: !!c,
                    isShiftClick: !1
                  });
                },
                onClick: (c) => c.stopPropagation()
              }
            )
          }
        ),
        /* @__PURE__ */ n.jsx(
          "div",
          {
            className: se(
              "group-hover:hidden block select-none",
              r && "!hidden"
            ),
            children: t
          }
        )
      ]
    }
  );
}
function xl(e) {
  const [t, s] = ue((b) => [
    b.fields,
    b.setSelectedAgentRunId
  ]), { data: r } = Pn.useFlag(
    Nn.MAX_FIELDS_PER_TABLE
  ), o = ue((b) => b.lockedByOtherUser), f = Me().checkAccess(
    ze.WRITE_TABLE
  ) && !o, h = f && r && t.length < r, m = {
    key: "new-field",
    minWidth: 67,
    maxWidth: 67,
    width: 67,
    name: "",
    renderHeaderCell: () => /* @__PURE__ */ n.jsx(ml, {}),
    renderCell: () => /* @__PURE__ */ n.jsx("div", { className: "empty-cell" })
  }, p = [
    {
      key: "select-row",
      name: "Select",
      width: 66,
      minWidth: 66,
      maxWidth: 66,
      resizable: !1,
      sortable: !1,
      frozen: !0,
      renderHeaderCell: () => /* @__PURE__ */ n.jsx(hl, {}),
      renderCell: (b) => /* @__PURE__ */ n.jsx(
        gl,
        {
          row: b.row,
          rowIndex: b.rowIdx + 1,
          onClick: () => {
            b.row.locked && b.row.agentRunId && s(b.row.agentRunId);
          }
        }
      ),
      renderSummaryCell: () => /* @__PURE__ */ n.jsx(
        Cn,
        {
          handleClick: e,
          icon: /* @__PURE__ */ n.jsx(An, { className: "size-4" })
        }
      )
    },
    ...t.map((b, C) => ({
      key: b.uuid,
      minWidth: 207,
      width: 207,
      minHeight: 37,
      resizable: !0,
      name: "",
      renderHeaderCell: () => /* @__PURE__ */ n.jsx(bs, { field: { ...b, index: C } }),
      renderCell: ({
        row: x,
        column: l,
        rowIdx: v
      }) => /* @__PURE__ */ n.jsx(
        vs,
        {
          field: b,
          value: x[b.uuid],
          row: x,
          column: l,
          rowIdx: v,
          disabled: !f,
          locked: x.locked,
          onClick: () => {
            x.locked && x.agentRunId && s(x.agentRunId);
          }
        },
        x.id + "_" + b.uuid
      ),
      renderSummaryCell: () => /* @__PURE__ */ n.jsx(Cn, { handleClick: e })
    })) ?? []
  ];
  return h && p.push(m), p;
}
function wl(e, t) {
  return !e || e.length === 0 ? [] : e.map((s) => {
    const r = {
      id: s.uuid,
      agentRunId: s.agentRunId ?? null,
      locked: !es(s.agentRunId)
    };
    return s.values.forEach((o) => {
      const c = t[o.fieldIndex];
      c && (r[c.uuid] = o.value);
    }), r;
  });
}
function Cn({ handleClick: e, icon: t }) {
  return /* @__PURE__ */ n.jsx(
    "div",
    {
      className: "w-full h-full border-t border-border  flex items-center justify-start cursor-pointer pl-4",
      onClick: e,
      children: t
    }
  );
}
function ml() {
  return /* @__PURE__ */ n.jsx(ts, { children: /* @__PURE__ */ n.jsx("div", { className: "w-full h-full flex items-center justify-center cursor-pointer new-field", children: /* @__PURE__ */ n.jsx(An, { className: "h-4 w-4" }) }) });
}
var st = /* @__PURE__ */ ((e) => (e.COMPACT = "compact", e.DEFAULT = "default", e.EXPANDED = "expanded", e))(st || {});
const At = {
  compact: 28,
  default: 42,
  expanded: 52
}, pl = () => {
  const e = ns(), t = rs.getProjectId(), [
    s,
    r,
    o,
    c,
    f,
    h,
    m,
    p,
    b
  ] = ue((u) => [
    u.selectedRecords,
    u.setSelectedRecords,
    u.selectedCell,
    u.setSelectedCell,
    u.createRecord,
    u.fields,
    u.records,
    u.table,
    u.setLockedByOtherUser
  ]), { lockedBy: C, takeOver: x } = gs({
    resourceId: p.id
  });
  w.useEffect(() => {
    b(!!C);
  }, [C, b]);
  const l = w.useRef(null), { theme: v } = ss(), { data: y } = Pn.useFlag(
    Nn.MAX_RECORDS_PER_TABLE
  ), g = Me().checkAccess(
    ze.WRITE_TABLE
  ) && !C, N = g && y && m.length < y, T = () => {
    f({
      uuid: ls(),
      agentRunId: null,
      values: []
    }), requestAnimationFrame(() => {
      var u;
      (u = l.current) == null || u.scrollToCell({
        rowIdx: m.length,
        idx: 0
      }), c({
        rowIdx: m.length,
        columnIdx: 1
      });
    });
  };
  w.useEffect(() => {
    const u = (d) => {
      o && !d.target.closest(
        `#editable-cell-${o.rowIdx}-${o.columnIdx}`
      ) && c(null);
    };
    return document.addEventListener("click", u), () => document.removeEventListener("click", u);
  }, [o]);
  const j = xl(T), k = wl(m, h), P = () => {
    e(`/projects/${t}/automations`);
  };
  return /* @__PURE__ */ n.jsxs("div", { className: "w-full flex flex-col justify-start items-start h-full", children: [
    /* @__PURE__ */ n.jsx("div", { className: "flex items-center justify-between w-full pr-4 border-b", children: /* @__PURE__ */ n.jsx(
      Cs,
      {
        onBack: P,
        lockedBy: C,
        takeOver: x
      }
    ) }),
    /* @__PURE__ */ n.jsx("div", { className: "flex w-full flex-col flex-1 min-h-0", children: /* @__PURE__ */ n.jsxs("div", { className: "flex-1 flex flex-col min-h-0", children: [
      /* @__PURE__ */ n.jsx("div", { className: "flex-1 min-h-0", children: /* @__PURE__ */ n.jsx(
        fl,
        {
          ref: l,
          columns: j,
          rows: k,
          rowKeyGetter: (u) => u.id,
          selectedRows: s,
          onSelectedRowsChange: r,
          className: se(
            "scroll-smooth w-full !h-full bg-muted/30 !border-0",
            v === "dark" ? "rdg-dark" : "rdg-light"
          ),
          bottomSummaryRows: g ? [{ id: "new-record" }] : [],
          rowHeight: At[st.DEFAULT],
          headerRowHeight: At[st.DEFAULT],
          summaryRowHeight: N ? At[st.DEFAULT] : 0
        }
      ) }),
      /* @__PURE__ */ n.jsx(
        os,
        {
          fieldsCount: h.length,
          recordsCount: m.length
        }
      )
    ] }) })
  ] });
};
pl.displayName = "ApTableEditorPage";
export {
  pl as ApTableEditorPage
};
