import { j as e, ce as x, h as a } from "./mount-builder-CqIEWsZv.mjs";
const r = ({
  value: t,
  className: s
}) => /* @__PURE__ */ e.jsx(x, { tooltipMessage: t, children: /* @__PURE__ */ e.jsx(
  "div",
  {
    className: a(
      "text-left truncate max-w-[120px] 2xl:max-w-[250px]",
      s
    ),
    children: t
  }
) });
export {
  r as T
};
