import { b8 as c, H as m, eY as i, j as a, bF as g, e$ as j, g3 as v, bL as x } from "./mount-builder-CqIEWsZv.mjs";
import { B as D, a as I } from "./builder-state-provider-DiNVbDPS.mjs";
const S = () => {
  var n, t;
  const { runId: s, projectId: r } = c(), { data: e, isLoading: l } = m({
    queryKey: ["run", s],
    queryFn: async () => {
      const o = await v.getPopulated(s), w = await x.get(o.flowId, {
        versionId: o.flowVersionId
      });
      return {
        run: o,
        flow: w
      };
    },
    enabled: s !== void 0,
    refetchInterval: 15e3
  }), { data: u, isLoading: d } = i.useSampleDataForFlow((n = e == null ? void 0 : e.flow) == null ? void 0 : n.version, r), { data: p, isLoading: f } = i.useSampleDataInputForFlow((t = e == null ? void 0 : e.flow) == null ? void 0 : t.version, r);
  return l || d || f ? /* @__PURE__ */ a.jsx("div", { className: "bg-background flex h-full w-full items-center justify-center ", children: /* @__PURE__ */ a.jsx(g, { isLarge: !0 }) }) : e && /* @__PURE__ */ a.jsx(j, { children: /* @__PURE__ */ a.jsx(
    D,
    {
      flow: e.flow,
      flowVersion: e.flow.version,
      readonly: !0,
      hideTestWidget: !1,
      run: e.run,
      outputSampleData: u ?? {},
      inputSampleData: p ?? {},
      children: /* @__PURE__ */ a.jsx(I, {})
    }
  ) });
};
export {
  S as FlowRunPage
};
