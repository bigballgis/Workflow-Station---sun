var kd = Object.defineProperty;
var La = (e) => {
  throw TypeError(e);
};
var Md = (e, n, s) => n in e ? kd(e, n, { enumerable: !0, configurable: !0, writable: !0, value: s }) : e[n] = s;
var Fa = (e, n, s) => Md(e, typeof n != "symbol" ? n + "" : n, s), za = (e, n, s) => n.has(e) || La("Cannot " + s);
var kn = (e, n, s) => (za(e, n, "read from private field"), s ? s.call(e) : n.get(e)), $a = (e, n, s) => n.has(e) ? La("Cannot add the same private member more than once") : n instanceof WeakSet ? n.add(e) : n.set(e, s), Va = (e, n, s, r) => (za(e, n, "write to private field"), r ? r.call(e, s) : n.set(e, s), s);
import { o as Je, w as ri, s as Te, a as _d, g4 as Ld, g5 as Ba, g6 as Fd, g7 as zd, g8 as $d, c as de, g as p, g9 as Vd, j as t, ga as Bd, gb as Ud, gc as Wd, gd as Mn, ge as ai, gf as Hd, gg as Gd, gh as qd, gi as Kd, gj as Yd, gk as Xd, gl as Jd, gm as Qd, gn as Zd, go as eu, gp as tu, gq as nu, gr as su, gs as ru, gt as au, gu as ou, H as Lr, ao as oe, gv as Fr, gw as Lt, gx as oi, b9 as Yn, ba as Xn, bb as Jn, bc as me, a6 as f, cd as zr, gy as ii, gz as $r, gA as Vr, gB as Br, a3 as te, a4 as ne, i as O, ar as Cn, a5 as Q, al as _e, e as dn, aj as Qn, b6 as Re, gC as Ur, bs as ut, gD as Ge, bt as ht, bu as ft, bv as mt, aQ as vn, fy as Ft, aJ as je, gE as iu, aX as Et, by as pt, gF as ot, gG as lu, gH as li, gI as cu, h as $, gJ as du, fV as En, b1 as ce, cq as uu, gK as Us, bK as Qe, gL as it, gM as Ws, c7 as hu, eM as fu, gN as mu, bS as ee, ai as Wr, c6 as Ze, gO as yn, bi as M, gP as rt, cr as pu, gQ as gu, ax as xu, ay as vu, aA as yu, dB as Zn, dC as es, dD as ts, dE as ns, dF as Xe, cJ as ju, cL as wu, gR as F, gS as Nu, fT as q, aS as Hr, ce as bu, C as Gr, af as ci, gT as lt, bY as Y, y as un, gU as di, cO as Ve, cQ as Ie, gV as Su, fq as ui, gW as hi, gX as fr, ej as qr, ek as Kr, el as wt, em as Nt, gY as fi, gZ as Tn, g_ as _t, g$ as W, h0 as mr, h1 as pr, aU as mi, h2 as Ps, h3 as Hn, h4 as Cu, h5 as Eu, bR as pi, h6 as Tu, aG as gi, h7 as Pu, h8 as Du, h9 as Ru, ha as Ou, hb as rn, hc as Iu, hd as Au, he as ku, hf as Mu, hg as _u, hh as Lu, hi as Fu, a1 as k, aH as xi, E as vi, aY as yi, hj as Yr, W as Ua, cu as zu, hk as ji, hl as ss, be as Me, aR as Ds, b4 as $u, hm as Vu, eq as Bu, I as wi, fS as Ni, fs as Uu, fx as Wu, hn as Hu, ho as bi, bL as _n, bJ as ae, fz as Fe, aW as zt, hp as Gu, hq as qu, hr as Ku, hs as Yu, c_ as Xu, bF as Gn, aq as Si, ht as Ju, hu as Qu, fb as Ci, hv as Zu, hw as eh, cb as th, b7 as nh, hx as sh, hy as rh, hz as Ei, hA as ah, d1 as oh, a_ as Xr, bf as ze, as as Ti, hB as Wa, hC as ih, av as lh, hD as Jr, hE as ye, bn as Pi, hF as ch, da as dh, eX as uh, hG as hh, hH as Di, hI as kt, hJ as Ri, hK as fh, cc as Qr, hL as mh, hM as Oi, hN as ph, hO as Ha, hP as gh, hQ as Ga, hR as xh, hS as vh, hT as yh, hU as jh, hV as wh, hW as hn, d9 as Rs, fv as Nh, fQ as jn, hX as Ii, hY as bh, hZ as Ai, h_ as Sh, dZ as Ch, h$ as Eh, i0 as Th, i1 as Ph, i2 as Dh, i3 as Rh, i4 as Oh, i5 as Ih, i6 as Ah, cZ as kh, eQ as $t, g2 as rs, D as qn, fZ as Ne, i7 as fn, b_ as ki, bw as Zr, i8 as Mi, du as Mh, cY as _i, ca as _h, i9 as Lh, ia as Li, f_ as Fh, fR as zh, g1 as qa, g0 as $h, ib as Vh, dt as Bh, g3 as Fi, ic as Pe, c3 as pe, c4 as we, c5 as bt, c9 as Ka, bA as gr, id as Ya, ie as zi, ig as Xa, ab as $i, ih as xr, ii as Uh, ij as Os, ik as Wh, cP as Vi, G as Hh, il as Gh, im as Is, io as ea, ip as qh, c0 as Pn, c2 as Dn, iq as vr, eF as It, d$ as As, ir as Kh, b as Ja, r as Qa, m as Yh, is as Za, it as qt, ae as Rn, a2 as ks, iu as Xh, iv as Jh, iw as wn, ix as Qs, cE as as, ct as Qh, cF as Bi, cG as os, ah as Zh, iy as st, c1 as Hs, iz as ef, dW as Ms, iA as Ui, iB as tf, iC as nf, iD as us, iE as sf, c8 as Nn, cT as rf, iF as af, iG as yr, iH as of, cn as lf, iI as cf, iJ as df, iK as uf, iL as hf, iM as eo, iN as _s, iO as ff, eU as hs, b2 as mf, iP as pf, an as gf, Y as to, iQ as xf, iR as vf, iS as no, iT as Wi, bV as ie, dT as ta, iU as yf, iV as Zs, iW as jf, bW as wf, iX as Nf, iY as bf, bX as so, cm as Bn, ew as Sf, b3 as Hi, aL as Gi, iZ as Cf, f as Ef, i_ as Tf, i$ as Pf, j0 as Df, j1 as Rf, j2 as Of, j3 as If } from "./mount-builder-CqIEWsZv.mjs";
import { C as Af, b as kf, a as Mf } from "./collapsible-CCnqobod.mjs";
import { V as _f } from "./variable-dialog-lOfOYVtt.mjs";
import { D as Lf } from "./database-DZzKBFIH.mjs";
import { F as Ff, j as zf, C as $f, u as Vf } from "./flow-chat-Bcho-Rhf.mjs";
import { S as Bf } from "./ap-form-Bh-hHJgV.mjs";
import { C as Uf, B as Wf, a as Hf, b as ro, c as Gf, d as qf, e as Kf, A as Yf, u as Xf } from "./use-resource-lock-CfW3f2H9.mjs";
import { t as an } from "./trigger-events-api-DEKnD3ub.mjs";
import { F as qi } from "./file-text-DULCzR4r.mjs";
import { K as Jf } from "./key-m_VycdsK.mjs";
var at = /* @__PURE__ */ ((e) => (e.TEXT = "Text", e.BOOLEAN = "Boolean", e.DATE = "Date", e.NUMBER = "Number", e.ARRAY = "Array", e.OBJECT = "Object", e))(at || {});
const Qf = Je({
  name: Te(),
  description: Te().optional(),
  type: Te(),
  required: ri()
});
Je({
  pieceName: Te(),
  triggerName: Te(),
  input: Je({
    toolName: Te(),
    toolDescription: Te(),
    inputSchema: _d(Qf),
    returnsResponse: ri()
  })
});
var Zf = class extends Ld {
  constructor(e, n) {
    super(e, n);
  }
  bindMethods() {
    super.bindMethods(), this.fetchNextPage = this.fetchNextPage.bind(this), this.fetchPreviousPage = this.fetchPreviousPage.bind(this);
  }
  setOptions(e, n) {
    super.setOptions(
      {
        ...e,
        behavior: Ba()
      },
      n
    );
  }
  getOptimisticResult(e) {
    return e.behavior = Ba(), super.getOptimisticResult(e);
  }
  fetchNextPage(e) {
    return this.fetch({
      ...e,
      meta: {
        fetchMore: { direction: "forward" }
      }
    });
  }
  fetchPreviousPage(e) {
    return this.fetch({
      ...e,
      meta: {
        fetchMore: { direction: "backward" }
      }
    });
  }
  createResult(e, n) {
    var v, g;
    const { state: s } = e, r = super.createResult(e, n), { isFetching: a, isRefetching: o, isError: i, isRefetchError: l } = r, c = (g = (v = s.fetchMeta) == null ? void 0 : v.fetchMore) == null ? void 0 : g.direction, u = i && c === "forward", d = a && c === "forward", h = i && c === "backward", m = a && c === "backward";
    return {
      ...r,
      fetchNextPage: this.fetchNextPage,
      fetchPreviousPage: this.fetchPreviousPage,
      hasNextPage: zd(n, s.data),
      hasPreviousPage: Fd(n, s.data),
      isFetchNextPageError: u,
      isFetchingNextPage: d,
      isFetchPreviousPageError: h,
      isFetchingPreviousPage: m,
      isRefetchError: l && !u && !h,
      isRefetching: o && !d && !m
    };
  }
};
function em(e, n) {
  return $d(
    e,
    Zf
  );
}
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const tm = [
  ["path", { d: "M8 3 4 7l4 4", key: "9rb6wj" }],
  ["path", { d: "M4 7h16", key: "6tx8e3" }],
  ["path", { d: "m16 21 4-4-4-4", key: "siv7j2" }],
  ["path", { d: "M20 17H4", key: "h6l3hr" }]
], nm = de("arrow-left-right", tm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const sm = [
  ["path", { d: "M7 7h10v10", key: "1tivn9" }],
  ["path", { d: "M7 17 17 7", key: "1vkiza" }]
], rm = de("arrow-up-right", sm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const am = [
  ["path", { d: "M11 14h10", key: "1w8e9d" }],
  ["path", { d: "M16 4h2a2 2 0 0 1 2 2v1.344", key: "1e62lh" }],
  ["path", { d: "m17 18 4-4-4-4", key: "z2g111" }],
  ["path", { d: "M8 4H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 1.793-1.113", key: "bjbb7m" }],
  ["rect", { x: "8", y: "2", width: "8", height: "4", rx: "1", key: "ublpy" }]
], ao = de("clipboard-paste", am);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const om = [
  ["rect", { width: "8", height: "4", x: "8", y: "2", rx: "1", ry: "1", key: "tgr4d6" }],
  [
    "path",
    {
      d: "M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2",
      key: "116196"
    }
  ],
  ["path", { d: "M9 14h6", key: "159ibu" }],
  ["path", { d: "M12 17v-6", key: "1y8rbf" }]
], oo = de("clipboard-plus", om);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const im = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M12 3v18", key: "108xh3" }]
], lm = de("columns-2", im);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const cm = [
  ["path", { d: "m15 15 6 6", key: "1s409w" }],
  ["path", { d: "m15 9 6-6", key: "ko1vev" }],
  ["path", { d: "M21 16v5h-5", key: "1ck2sf" }],
  ["path", { d: "M21 8V3h-5", key: "1qoq8a" }],
  ["path", { d: "M3 16v5h5", key: "1t08am" }],
  ["path", { d: "m3 21 6-6", key: "wwnumi" }],
  ["path", { d: "M3 8V3h5", key: "1ln10m" }],
  ["path", { d: "M9 9 3 3", key: "v551iv" }]
], dm = de("expand", cm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const um = [
  [
    "path",
    {
      d: "M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2",
      key: "18mbvz"
    }
  ],
  ["path", { d: "M6.453 15h11.094", key: "3shlmq" }],
  ["path", { d: "M8.5 2h7", key: "csnxdl" }]
], hm = de("flask-conical", um);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const fm = [
  ["path", { d: "M3 7V5a2 2 0 0 1 2-2h2", key: "aa7l1z" }],
  ["path", { d: "M17 3h2a2 2 0 0 1 2 2v2", key: "4qcy5o" }],
  ["path", { d: "M21 17v2a2 2 0 0 1-2 2h-2", key: "6vwrx8" }],
  ["path", { d: "M7 21H5a2 2 0 0 1-2-2v-2", key: "ioqczr" }],
  ["rect", { width: "10", height: "8", x: "7", y: "8", rx: "1", key: "vys8me" }]
], mm = de("fullscreen", fm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const pm = [
  ["path", { d: "M7 2h10", key: "nczekb" }],
  ["path", { d: "M5 6h14", key: "u2x4p" }],
  ["rect", { width: "18", height: "12", x: "3", y: "10", rx: "2", key: "l0tzu3" }]
], gm = de("gallery-vertical-end", pm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const xm = [
  ["path", { d: "m15 12-9.373 9.373a1 1 0 0 1-3.001-3L12 9", key: "1hayfq" }],
  ["path", { d: "m18 15 4-4", key: "16gjal" }],
  [
    "path",
    {
      d: "m21.5 11.5-1.914-1.914A2 2 0 0 1 19 8.172v-.344a2 2 0 0 0-.586-1.414l-1.657-1.657A6 6 0 0 0 12.516 3H9l1.243 1.243A6 6 0 0 1 12 8.485V10l2 2h1.172a2 2 0 0 1 1.414.586L18.5 14.5",
      key: "15ts47"
    }
  ]
], vm = de("hammer", xm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ym = [
  ["path", { d: "M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2", key: "1fvzgz" }],
  ["path", { d: "M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2", key: "1kc0my" }],
  ["path", { d: "M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8", key: "10h0bg" }],
  [
    "path",
    {
      d: "M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15",
      key: "1s1gnw"
    }
  ]
], jm = de("hand", ym);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const wm = [
  ["path", { d: "m12 15 4 4", key: "lnac28" }],
  [
    "path",
    {
      d: "M2.352 10.648a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.029-6.029a1 1 0 1 1 3 3l-6.029 6.029a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.365-6.367A1 1 0 0 0 8.716 4.282z",
      key: "nlhkjb"
    }
  ],
  ["path", { d: "m5 8 4 4", key: "j6kj7e" }]
], Nm = de("magnet", wm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const bm = [
  [
    "path",
    {
      d: "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",
      key: "169xi5"
    }
  ],
  ["path", { d: "M15 5.764v15", key: "1pn4in" }],
  ["path", { d: "M9 3.236v15", key: "1uimfh" }]
], Sm = de("map", bm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Cm = [
  ["path", { d: "M12.586 12.586 19 19", key: "ea5xo7" }],
  [
    "path",
    {
      d: "M3.688 3.037a.497.497 0 0 0-.651.651l6.5 15.999a.501.501 0 0 0 .947-.062l1.569-6.083a2 2 0 0 1 1.448-1.479l6.124-1.579a.5.5 0 0 0 .063-.947z",
      key: "277e5u"
    }
  ]
], Em = de("mouse-pointer", Cm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Tm = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M15 14v1", key: "ilsfch" }],
  ["path", { d: "M15 19v2", key: "1fst2f" }],
  ["path", { d: "M15 3v2", key: "z204g4" }],
  ["path", { d: "M15 9v1", key: "z2a8b1" }]
], Pm = de("panel-right-dashed", Tm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Dm = [
  ["path", { d: "m17 2 4 4-4 4", key: "nntrym" }],
  ["path", { d: "M3 11v-1a4 4 0 0 1 4-4h14", key: "84bu3i" }],
  ["path", { d: "m7 22-4-4 4-4", key: "1wqhfi" }],
  ["path", { d: "M21 13v1a4 4 0 0 1-4 4H3", key: "1rx37r" }]
], Rm = de("repeat", Dm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Om = [
  ["circle", { cx: "6", cy: "19", r: "3", key: "1kj8tv" }],
  ["path", { d: "M9 19h8.5a3.5 3.5 0 0 0 0-7h-11a3.5 3.5 0 0 1 0-7H15", key: "1d8sl" }],
  ["circle", { cx: "18", cy: "5", r: "3", key: "gq8acd" }]
], Im = de("route", Om);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Am = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 12h18", key: "1i2n21" }]
], km = de("rows-2", Am);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Mm = [
  ["path", { d: "M16 3h5v5", key: "1806ms" }],
  ["path", { d: "M8 3H3v5", key: "15dfkv" }],
  ["path", { d: "M12 22v-8.3a4 4 0 0 0-1.172-2.872L3 3", key: "1qrqzj" }],
  ["path", { d: "m15 9 6-6", key: "ko1vev" }]
], _m = de("split", Mm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const Lm = [
  [
    "path",
    { d: "M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344", key: "2acyp4" }
  ],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
], Fm = de("square-check-big", Lm);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const zm = [
  [
    "path",
    {
      d: "M21 9a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 15 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2z",
      key: "1dfntj"
    }
  ],
  ["path", { d: "M15 3v5a1 1 0 0 0 1 1h5", key: "6s6qgf" }]
], $m = de("sticky-note", zm);
var na = "ContextMenu", [Vm] = Zd(na, [
  ai
]), be = ai(), [Bm, Ki] = Vm(na), Yi = (e) => {
  const { __scopeContextMenu: n, children: s, onOpenChange: r, dir: a, modal: o = !0 } = e, [i, l] = p.useState(!1), c = be(n), u = Vd(r), d = p.useCallback(
    (h) => {
      l(h), u(h);
    },
    [u]
  );
  return /* @__PURE__ */ t.jsx(
    Bm,
    {
      scope: n,
      open: i,
      onOpenChange: d,
      modal: o,
      children: /* @__PURE__ */ t.jsx(
        Bd,
        {
          ...c,
          dir: a,
          open: i,
          onOpenChange: d,
          modal: o,
          children: s
        }
      )
    }
  );
};
Yi.displayName = na;
var Xi = "ContextMenuTrigger", Ji = p.forwardRef(
  (e, n) => {
    const { __scopeContextMenu: s, disabled: r = !1, ...a } = e, o = Ki(Xi, s), i = be(s), l = p.useRef({ x: 0, y: 0 }), c = p.useRef({
      getBoundingClientRect: () => DOMRect.fromRect({ width: 0, height: 0, ...l.current })
    }), u = p.useRef(0), d = p.useCallback(
      () => window.clearTimeout(u.current),
      []
    ), h = (m) => {
      l.current = { x: m.clientX, y: m.clientY }, o.onOpenChange(!0);
    };
    return p.useEffect(() => d, [d]), p.useEffect(() => void (r && d()), [r, d]), /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      /* @__PURE__ */ t.jsx(Ud, { ...i, virtualRef: c }),
      /* @__PURE__ */ t.jsx(
        Wd.span,
        {
          "data-state": o.open ? "open" : "closed",
          "data-disabled": r ? "" : void 0,
          ...a,
          ref: n,
          style: { WebkitTouchCallout: "none", ...e.style },
          onContextMenu: r ? e.onContextMenu : Mn(e.onContextMenu, (m) => {
            d(), h(m), m.preventDefault();
          }),
          onPointerDown: r ? e.onPointerDown : Mn(
            e.onPointerDown,
            fs((m) => {
              d(), u.current = window.setTimeout(() => h(m), 700);
            })
          ),
          onPointerMove: r ? e.onPointerMove : Mn(e.onPointerMove, fs(d)),
          onPointerCancel: r ? e.onPointerCancel : Mn(e.onPointerCancel, fs(d)),
          onPointerUp: r ? e.onPointerUp : Mn(e.onPointerUp, fs(d))
        }
      )
    ] });
  }
);
Ji.displayName = Xi;
var Um = "ContextMenuPortal", Qi = (e) => {
  const { __scopeContextMenu: n, ...s } = e, r = be(n);
  return /* @__PURE__ */ t.jsx(Hd, { ...r, ...s });
};
Qi.displayName = Um;
var Zi = "ContextMenuContent", el = p.forwardRef(
  (e, n) => {
    const { __scopeContextMenu: s, ...r } = e, a = Ki(Zi, s), o = be(s), i = p.useRef(!1);
    return /* @__PURE__ */ t.jsx(
      Gd,
      {
        ...o,
        ...r,
        ref: n,
        side: "right",
        sideOffset: 2,
        align: "start",
        onCloseAutoFocus: (l) => {
          var c;
          (c = e.onCloseAutoFocus) == null || c.call(e, l), !l.defaultPrevented && i.current && l.preventDefault(), i.current = !1;
        },
        onInteractOutside: (l) => {
          var c;
          (c = e.onInteractOutside) == null || c.call(e, l), !l.defaultPrevented && !a.modal && (i.current = !0);
        },
        style: {
          ...e.style,
          "--radix-context-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-context-menu-content-available-width": "var(--radix-popper-available-width)",
          "--radix-context-menu-content-available-height": "var(--radix-popper-available-height)",
          "--radix-context-menu-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-context-menu-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    );
  }
);
el.displayName = Zi;
var Wm = "ContextMenuGroup", Hm = p.forwardRef(
  (e, n) => {
    const { __scopeContextMenu: s, ...r } = e, a = be(s);
    return /* @__PURE__ */ t.jsx(eu, { ...a, ...r, ref: n });
  }
);
Hm.displayName = Wm;
var Gm = "ContextMenuLabel", qm = p.forwardRef(
  (e, n) => {
    const { __scopeContextMenu: s, ...r } = e, a = be(s);
    return /* @__PURE__ */ t.jsx(tu, { ...a, ...r, ref: n });
  }
);
qm.displayName = Gm;
var Km = "ContextMenuItem", tl = p.forwardRef(
  (e, n) => {
    const { __scopeContextMenu: s, ...r } = e, a = be(s);
    return /* @__PURE__ */ t.jsx(qd, { ...a, ...r, ref: n });
  }
);
tl.displayName = Km;
var Ym = "ContextMenuCheckboxItem", Xm = p.forwardRef((e, n) => {
  const { __scopeContextMenu: s, ...r } = e, a = be(s);
  return /* @__PURE__ */ t.jsx(nu, { ...a, ...r, ref: n });
});
Xm.displayName = Ym;
var Jm = "ContextMenuRadioGroup", Qm = p.forwardRef((e, n) => {
  const { __scopeContextMenu: s, ...r } = e, a = be(s);
  return /* @__PURE__ */ t.jsx(su, { ...a, ...r, ref: n });
});
Qm.displayName = Jm;
var Zm = "ContextMenuRadioItem", ep = p.forwardRef((e, n) => {
  const { __scopeContextMenu: s, ...r } = e, a = be(s);
  return /* @__PURE__ */ t.jsx(ru, { ...a, ...r, ref: n });
});
ep.displayName = Zm;
var tp = "ContextMenuItemIndicator", np = p.forwardRef((e, n) => {
  const { __scopeContextMenu: s, ...r } = e, a = be(s);
  return /* @__PURE__ */ t.jsx(au, { ...a, ...r, ref: n });
});
np.displayName = tp;
var sp = "ContextMenuSeparator", nl = p.forwardRef((e, n) => {
  const { __scopeContextMenu: s, ...r } = e, a = be(s);
  return /* @__PURE__ */ t.jsx(Kd, { ...a, ...r, ref: n });
});
nl.displayName = sp;
var rp = "ContextMenuArrow", ap = p.forwardRef(
  (e, n) => {
    const { __scopeContextMenu: s, ...r } = e, a = be(s);
    return /* @__PURE__ */ t.jsx(ou, { ...a, ...r, ref: n });
  }
);
ap.displayName = rp;
var sl = "ContextMenuSub", rl = (e) => {
  const { __scopeContextMenu: n, children: s, onOpenChange: r, open: a, defaultOpen: o } = e, i = be(n), [l, c] = Yd({
    prop: a,
    defaultProp: o ?? !1,
    onChange: r,
    caller: sl
  });
  return /* @__PURE__ */ t.jsx(Xd, { ...i, open: l, onOpenChange: c, children: s });
};
rl.displayName = sl;
var op = "ContextMenuSubTrigger", al = p.forwardRef((e, n) => {
  const { __scopeContextMenu: s, ...r } = e, a = be(s);
  return /* @__PURE__ */ t.jsx(Jd, { ...a, ...r, ref: n });
});
al.displayName = op;
var ip = "ContextMenuSubContent", ol = p.forwardRef((e, n) => {
  const { __scopeContextMenu: s, ...r } = e, a = be(s);
  return /* @__PURE__ */ t.jsx(
    Qd,
    {
      ...a,
      ...r,
      ref: n,
      style: {
        ...e.style,
        "--radix-context-menu-content-transform-origin": "var(--radix-popper-transform-origin)",
        "--radix-context-menu-content-available-width": "var(--radix-popper-available-width)",
        "--radix-context-menu-content-available-height": "var(--radix-popper-available-height)",
        "--radix-context-menu-trigger-width": "var(--radix-popper-anchor-width)",
        "--radix-context-menu-trigger-height": "var(--radix-popper-anchor-height)"
      }
    }
  );
});
ol.displayName = ip;
function fs(e) {
  return (n) => n.pointerType !== "mouse" ? e(n) : void 0;
}
var lp = Yi, cp = Ji, dp = Qi, up = el, hp = tl, fp = nl, mp = rl, pp = al, gp = ol;
const xp = {
  usePollResults: (e, n) => {
    const { data: s, refetch: r } = Lr({
      queryKey: ["triggerEvents", e],
      queryFn: () => an.list({
        projectId: oe.getProjectId(),
        flowId: n,
        limit: 5,
        cursor: void 0
      }),
      staleTime: 0
    });
    return { pollResults: s, refetch: r };
  }
}, io = ({
  disabled: e,
  children: n,
  align: s
}) => {
  const [r, a] = p.useState(!1), { setShowAddFlowDialog: o } = Fr(), { openAddPieceToolDialog: i } = Lt(), { setShowAddMcpDialog: l } = oi();
  return /* @__PURE__ */ t.jsxs(
    Yn,
    {
      modal: !1,
      open: r,
      onOpenChange: a,
      children: [
        /* @__PURE__ */ t.jsx(Xn, { disabled: e, asChild: !0, children: n }),
        /* @__PURE__ */ t.jsxs(Jn, { align: s, children: [
          /* @__PURE__ */ t.jsxs(
            me,
            {
              onSelect: () => i({ page: "pieces-list" }),
              children: [
                /* @__PURE__ */ t.jsx(vm, { className: "size-3.5 me-2" }),
                /* @__PURE__ */ t.jsx("span", { children: f("Piece tool") })
              ]
            }
          ),
          /* @__PURE__ */ t.jsxs(me, { onSelect: () => o(!0), children: [
            /* @__PURE__ */ t.jsx(zr, { className: "size-3.5 me-2" }),
            /* @__PURE__ */ t.jsx("span", { children: f("Flow tool") })
          ] }),
          /* @__PURE__ */ t.jsxs(me, { onSelect: () => l(!0), children: [
            /* @__PURE__ */ t.jsx(ii, { className: "size-3.5 me-2" }),
            /* @__PURE__ */ t.jsx("span", { children: f("Mcp server") })
          ] })
        ] })
      ]
    }
  );
}, vp = ({
  disabled: e,
  tools: n,
  removeTool: s
}) => {
  const { setShowAddFlowDialog: r } = Fr();
  return /* @__PURE__ */ t.jsxs($r, { value: "flows", className: "border-b last:border-0", children: [
    /* @__PURE__ */ t.jsx(Vr, { className: "px-4 py-3 hover:no-underline hover:bg-accent transition-all", children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ t.jsx("div", { className: "h-8 w-8 rounded-md bg-muted flex items-center justify-center", children: /* @__PURE__ */ t.jsx(zr, { className: "size-4 text-muted-foreground" }) }),
      /* @__PURE__ */ t.jsx("span", { className: "text-sm font-medium", children: f("Flows") })
    ] }) }),
    /* @__PURE__ */ t.jsxs(Br, { className: "px-4 py-2", children: [
      /* @__PURE__ */ t.jsx("div", { className: "flex flex-wrap gap-2", children: n.map((a) => /* @__PURE__ */ t.jsxs(
        "div",
        {
          className: `
                group flex items-center gap-2 px-3 py-1
                rounded-full border bg-muted/50
                ${e ? "opacity-50 pointer-events-none" : ""}
              `,
          children: [
            /* @__PURE__ */ t.jsx("span", { className: "text-xs font-medium max-w-40 truncate", children: a.flowDisplayName ?? a.toolName ?? f("Flow") }),
            /* @__PURE__ */ t.jsxs(te, { children: [
              /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
                O,
                {
                  disabled: e,
                  onClick: () => s(a.toolName),
                  variant: "ghost",
                  size: "icon",
                  className: `
                      size-5 p-0.5
                      text-muted-foreground
                      hover:text-destructive
                      hover:bg-destructive/10
                      transition
                    `,
                  children: /* @__PURE__ */ t.jsx(Cn, { className: "h-3 w-3" })
                }
              ) }),
              /* @__PURE__ */ t.jsx(Q, { children: f("Remove flow") })
            ] })
          ]
        },
        a.toolName
      )) }),
      /* @__PURE__ */ t.jsxs(
        O,
        {
          variant: "link",
          className: "mt-4",
          size: "xs",
          onClick: () => r(!0),
          children: [
            /* @__PURE__ */ t.jsx(_e, { className: "size-3 mr-1" }),
            f("Add Flow")
          ]
        }
      )
    ] })
  ] });
}, yp = ({
  disabled: e,
  tools: n,
  removeTool: s
}) => {
  const { setShowAddMcpDialog: r } = oi();
  return /* @__PURE__ */ t.jsxs($r, { value: "mcp", className: "border-b last:border-0", children: [
    /* @__PURE__ */ t.jsx(Vr, { className: "px-4 py-3 hover:no-underline hover:bg-accent transition-all", children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ t.jsx("div", { className: "h-8 w-8 rounded-md bg-muted flex items-center justify-center", children: /* @__PURE__ */ t.jsx(ii, { className: "size-3.5" }) }),
      /* @__PURE__ */ t.jsx("span", { className: "text-sm font-medium", children: f("MCP Servers") })
    ] }) }),
    /* @__PURE__ */ t.jsxs(Br, { className: "px-4 py-2", children: [
      /* @__PURE__ */ t.jsx("div", { className: "flex flex-wrap gap-2", children: n.map((a) => /* @__PURE__ */ t.jsxs(
        "div",
        {
          onClick: () => r(!0, a),
          className: `
                group flex items-center gap-2 px-3 py-1 cursor-pointer
                rounded-full border bg-muted/50
                ${e ? "opacity-50 pointer-events-none" : ""}
              `,
          children: [
            /* @__PURE__ */ t.jsx("span", { className: "text-xs font-medium max-w-40 truncate", children: a.toolName }),
            /* @__PURE__ */ t.jsxs(te, { children: [
              /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
                O,
                {
                  disabled: e,
                  onClick: (o) => {
                    o.stopPropagation(), s(a.toolName);
                  },
                  variant: "ghost",
                  size: "icon",
                  className: `
                      size-5 p-0.5
                      text-muted-foreground
                      hover:text-destructive
                      hover:bg-destructive/10
                      transition
                    `,
                  children: /* @__PURE__ */ t.jsx(Cn, { className: "h-3 w-3" })
                }
              ) }),
              /* @__PURE__ */ t.jsx(Q, { children: f("Remove MCP server") })
            ] })
          ]
        },
        a.toolName
      )) }),
      /* @__PURE__ */ t.jsxs(
        O,
        {
          variant: "link",
          className: "mt-4",
          size: "xs",
          onClick: () => r(!0),
          children: [
            /* @__PURE__ */ t.jsx(_e, { className: "size-3 mr-1" }),
            f("Add MCP Server")
          ]
        }
      )
    ] })
  ] });
}, sa = {
  list() {
    const e = oe.getProjectId();
    return dn.get("/v1/knowledge-base/files", {
      projectId: e
    });
  },
  upload(e) {
    const n = oe.getProjectId();
    return dn.any(
      `/v1/knowledge-base/files/upload?projectId=${encodeURIComponent(
        n
      )}`,
      {
        method: "POST",
        data: e
      }
    );
  },
  delete(e) {
    const n = oe.getProjectId();
    return dn.delete(`/v1/knowledge-base/files/${e}`, {
      projectId: n
    });
  }
}, jp = () => {
  const e = oe.getProjectId();
  return Lr({
    queryKey: ["knowledge-base-files", e],
    queryFn: () => sa.list()
  });
}, wp = () => {
  const e = Qn(), n = oe.getProjectId();
  return Re({
    mutationFn: (s) => sa.upload(s),
    onSuccess: () => {
      e.invalidateQueries({
        queryKey: ["knowledge-base-files", n]
      });
    }
  });
}, Np = () => {
  const e = Qn(), n = oe.getProjectId();
  return Re({
    mutationFn: (s) => sa.delete(s),
    onSuccess: () => {
      e.invalidateQueries({
        queryKey: ["knowledge-base-files", n]
      });
    }
  });
};
function bp({
  tools: e,
  onToolsUpdate: n
}) {
  const { showAddKbDialog: s, editingKbTool: r, initialSourceType: a, closeKbDialog: o } = Ur();
  return /* @__PURE__ */ t.jsx(ut, { open: s, onOpenChange: o, children: /* @__PURE__ */ t.jsx(
    Sp,
    {
      tools: e,
      onToolsUpdate: n,
      editingKbTool: r,
      initialSourceType: a,
      closeKbDialog: o
    },
    `kb-dialog-${s}-${(r == null ? void 0 : r.toolName) ?? "new"}`
  ) });
}
function Sp({
  tools: e,
  onToolsUpdate: n,
  editingKbTool: s,
  initialSourceType: r,
  closeKbDialog: a
}) {
  const o = (s == null ? void 0 : s.sourceType) ?? r ?? Ge.FILE, [i, l] = p.useState((s == null ? void 0 : s.toolName) ?? ""), [c, u] = p.useState((s == null ? void 0 : s.sourceId) ?? ""), [d, h] = p.useState((s == null ? void 0 : s.sourceName) ?? ""), m = p.useRef(null), y = wp(), v = Np(), { data: g, isLoading: j } = jp(), x = oe.getProjectId(), { data: N, isLoading: w } = Lr({
    queryKey: ["tables-for-kb", x],
    queryFn: () => lu.list({ projectId: x, limit: 1e3 }),
    enabled: o === Ge.TABLE
  }), b = (g ?? []).map((I) => ({
    value: I.id,
    label: I.displayName
  })), E = ((N == null ? void 0 : N.data) ?? []).map((I) => ({
    value: I.id,
    label: I.name
  })), R = (I, P) => {
    I && (u(I), h(P), s || l(Cp(P)));
  }, S = (I) => {
    var A;
    const P = (A = I.target.files) == null ? void 0 : A[0];
    if (!P) return;
    const D = new FormData();
    D.append("file", P), D.append("displayName", P.name), y.mutate(D, {
      onSuccess: (_) => {
        R(_.id, _.displayName), je(f("File uploaded successfully"));
      },
      onError: () => {
        je.error(f("Failed to upload file"));
      }
    }), m.current && (m.current.value = "");
  }, C = () => {
    if (!i.trim() || !c.trim()) {
      je.error(f("Please select a source and ensure tool name is filled"));
      return;
    }
    if (e.some(
      (D) => D.toolName === i.trim() && (!s || s.toolName !== i.trim())
    )) {
      je.error(f("A tool with this name already exists"));
      return;
    }
    const P = {
      type: ot.KNOWLEDGE_BASE,
      toolName: i.trim(),
      sourceType: o,
      sourceId: c.trim(),
      sourceName: d.trim()
    };
    if (s) {
      const D = e.map(
        (A) => A.type === ot.KNOWLEDGE_BASE && A.toolName === s.toolName ? P : A
      );
      n(D), je(f("Knowledge source updated successfully"));
    } else
      n([...e, P]), je(f("Knowledge source added successfully"));
    a();
  }, T = s ? f("Edit Knowledge Source") : o === Ge.FILE ? f("Add File Source") : f("Add Table Source");
  return /* @__PURE__ */ t.jsxs(ht, { className: "sm:max-w-md gap-3", children: [
    /* @__PURE__ */ t.jsx(ft, { children: /* @__PURE__ */ t.jsx(mt, { children: T }) }),
    /* @__PURE__ */ t.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ t.jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ t.jsx(vn, { children: o === Ge.FILE ? f("Knowledge Base File") : f("Table") }),
        o === Ge.FILE ? /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-2", children: [
          /* @__PURE__ */ t.jsx(
            Ft,
            {
              options: b,
              value: c || void 0,
              onChange: (I) => {
                const P = g == null ? void 0 : g.find((D) => D.id === I);
                R(I, (P == null ? void 0 : P.displayName) ?? "");
              },
              placeholder: f("Select a knowledge base file"),
              loading: j,
              onOptionDelete: (I) => {
                v.isPending || v.mutate(I, {
                  onSuccess: () => {
                    je(f("File deleted successfully")), c === I && (u(""), h(""), s || l(""));
                  },
                  onError: () => {
                    je.error(f("Failed to delete file"));
                  }
                });
              }
            }
          ),
          /* @__PURE__ */ t.jsx(
            "input",
            {
              ref: m,
              type: "file",
              accept: ".pdf,.txt,.csv,.docx",
              className: "hidden",
              onChange: S
            }
          ),
          /* @__PURE__ */ t.jsxs(
            O,
            {
              type: "button",
              variant: "outline",
              size: "sm",
              className: "self-start",
              onClick: () => {
                var I;
                return (I = m.current) == null ? void 0 : I.click();
              },
              disabled: y.isPending,
              children: [
                /* @__PURE__ */ t.jsx(iu, { className: "mr-2 h-4 w-4" }),
                y.isPending ? f("Uploading...") : f("Upload new file")
              ]
            }
          )
        ] }) : /* @__PURE__ */ t.jsx(
          Ft,
          {
            options: E,
            value: c || void 0,
            onChange: (I) => {
              var D;
              const P = (D = N == null ? void 0 : N.data) == null ? void 0 : D.find(
                (A) => A.id === I
              );
              R(I, (P == null ? void 0 : P.name) ?? "");
            },
            placeholder: f("Select a table"),
            loading: w
          }
        )
      ] }),
      /* @__PURE__ */ t.jsxs("div", { className: "space-y-1.5", children: [
        /* @__PURE__ */ t.jsx(vn, { children: o === Ge.FILE ? f("File Name") : f("Table Name") }),
        /* @__PURE__ */ t.jsx(
          Et,
          {
            value: i,
            onChange: (I) => l(I.target.value),
            placeholder: o === Ge.FILE ? f("e.g., company_docs") : f("e.g., products_catalog")
          }
        ),
        /* @__PURE__ */ t.jsx("p", { className: "text-xs text-muted-foreground", children: f(
          "A unique name for the agent to reference this knowledge source"
        ) })
      ] })
    ] }),
    /* @__PURE__ */ t.jsxs(pt, { children: [
      /* @__PURE__ */ t.jsx(O, { type: "button", variant: "outline", onClick: a, children: f("Cancel") }),
      /* @__PURE__ */ t.jsx(O, { onClick: C, children: s ? f("Update") : f("Add") })
    ] })
  ] });
}
function Cp(e) {
  return e.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
}
const lo = ({
  disabled: e
}) => {
  const [n, s] = p.useState(!1), { setShowAddKbDialog: r } = Ur();
  return /* @__PURE__ */ t.jsxs(Yn, { modal: !1, open: n, onOpenChange: s, children: [
    /* @__PURE__ */ t.jsx(Xn, { disabled: e, asChild: !0, children: /* @__PURE__ */ t.jsxs(O, { variant: "outline", size: "sm", children: [
      /* @__PURE__ */ t.jsx(_e, { className: "size-4 mr-2" }),
      f("Add")
    ] }) }),
    /* @__PURE__ */ t.jsxs(Jn, { align: "start", children: [
      /* @__PURE__ */ t.jsxs(
        me,
        {
          onSelect: () => r(!0, void 0, Ge.FILE),
          children: [
            /* @__PURE__ */ t.jsx(qi, { className: "size-3.5 me-2" }),
            /* @__PURE__ */ t.jsx("span", { children: f("Upload File") })
          ]
        }
      ),
      /* @__PURE__ */ t.jsxs(
        me,
        {
          onSelect: () => r(!0, void 0, Ge.TABLE),
          children: [
            /* @__PURE__ */ t.jsx(li, { className: "size-3.5 me-2" }),
            /* @__PURE__ */ t.jsx("span", { children: f("Connect Table") })
          ]
        }
      )
    ] })
  ] });
};
function Ep({
  tools: e,
  disabled: n,
  removeTool: s
}) {
  const { setShowAddKbDialog: r } = Ur();
  return /* @__PURE__ */ t.jsx("div", { className: "flex flex-wrap gap-2", children: e.map((a) => /* @__PURE__ */ t.jsxs(
    "div",
    {
      onClick: () => r(!0, a),
      className: $(
        "group flex items-center gap-2 px-3 py-1 cursor-pointer rounded-full border bg-muted/50",
        n && "opacity-50 pointer-events-none"
      ),
      children: [
        a.sourceType === Ge.FILE ? /* @__PURE__ */ t.jsx(qi, { className: "size-3.5 text-muted-foreground shrink-0" }) : /* @__PURE__ */ t.jsx(li, { className: "size-3.5 text-muted-foreground shrink-0" }),
        /* @__PURE__ */ t.jsx("span", { className: "text-xs font-medium max-w-40 truncate", children: a.sourceName }),
        /* @__PURE__ */ t.jsxs(te, { children: [
          /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
            O,
            {
              disabled: n,
              onClick: (o) => {
                o.stopPropagation(), s(a.toolName);
              },
              variant: "ghost",
              size: "icon",
              className: `
                  size-5 p-0.5
                  text-muted-foreground
                  hover:text-destructive
                  hover:bg-destructive/10
                  transition
                `,
              children: /* @__PURE__ */ t.jsx(Cn, { className: "h-3 w-3" })
            }
          ) }),
          /* @__PURE__ */ t.jsx(Q, { children: f("Remove knowledge source") })
        ] })
      ]
    },
    a.toolName
  )) });
}
const Tp = ({
  disabled: e,
  tools: n,
  allTools: s,
  removeTool: r,
  onToolsUpdate: a,
  selectedProvider: o
}) => {
  const l = !!(o ? du[o] : void 0);
  return /* @__PURE__ */ t.jsxs("div", { className: "mt-6", children: [
    /* @__PURE__ */ t.jsx("h2", { className: "text-sm font-medium", children: f("Knowledge Base") }),
    /* @__PURE__ */ t.jsx("div", { className: "mt-2", children: n.length > 0 ? /* @__PURE__ */ t.jsxs("div", { className: "border rounded-md overflow-hidden p-4", children: [
      /* @__PURE__ */ t.jsx(
        Ep,
        {
          tools: n,
          disabled: e,
          removeTool: r
        }
      ),
      l ? /* @__PURE__ */ t.jsx("div", { className: "mt-4", children: /* @__PURE__ */ t.jsx(lo, { disabled: e }) }) : /* @__PURE__ */ t.jsx("p", { className: "text-xs text-muted-foreground mt-3", children: f(
        "The selected provider does not support embeddings. Switch to a provider like OpenAI or Google for knowledge base to work."
      ) })
    ] }) : /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col items-center justify-center gap-4 rounded-xl border bg-card px-4 py-8 text-center", children: [
      /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-center h-10 w-10 rounded-full border bg-background", children: /* @__PURE__ */ t.jsx(cu, { className: "size-5" }) }),
      l ? /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
        /* @__PURE__ */ t.jsx("p", { className: "text-sm font-medium text-muted-foreground", children: f(
          "Add files or tables as knowledge sources for your agent."
        ) }),
        /* @__PURE__ */ t.jsx(lo, { disabled: e })
      ] }) : /* @__PURE__ */ t.jsx("p", { className: "text-sm text-muted-foreground", children: f(
        "Knowledge base requires a provider that supports embeddings, such as OpenAI or Google."
      ) })
    ] }) }),
    /* @__PURE__ */ t.jsx(
      bp,
      {
        tools: s,
        onToolsUpdate: a
      }
    )
  ] });
}, Pp = ({
  disabled: e,
  tools: n,
  removeTool: s
}) => {
  const { openAddPieceToolDialog: r } = Lt(), { metadata: a } = En.useAllStepsMetadata({
    searchQuery: "",
    type: "action"
  }), o = p.useMemo(() => a == null ? void 0 : a.filter(
    (c) => "suggestedActions" in c && "suggestedTriggers" in c
  ), [a]), i = o == null ? void 0 : o.find(
    (c) => c.pieceName === n[0].pieceMetadata.pieceName
  );
  if (!i)
    return /* @__PURE__ */ t.jsxs("div", { className: "flex  w-full items-center justify-between px-3 h-12  border-b last:border-0 py-2", children: [
      /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ t.jsx(ce, { className: "h-6 w-6 rounded-md" }),
        /* @__PURE__ */ t.jsx(ce, { className: "h-4 w-32" })
      ] }),
      /* @__PURE__ */ t.jsx(ce, { className: "h-4 w-4 rounded-sm" })
    ] });
  const l = (c) => {
    r({ page: "action-inputs", tool: c });
  };
  return /* @__PURE__ */ t.jsxs(
    $r,
    {
      value: i.pieceName,
      className: "border-b last:border-0",
      children: [
        /* @__PURE__ */ t.jsx(Vr, { className: "px-4 py-3 hover:no-underline hover:bg-accent transition-all", children: /* @__PURE__ */ t.jsx("div", { className: "flex w-full items-center justify-between", children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ t.jsx("div", { className: "h-8 w-8 rounded-md bg-muted flex items-center justify-center", children: i.logoUrl ? /* @__PURE__ */ t.jsx(
            "img",
            {
              src: i.logoUrl,
              alt: i.displayName,
              className: "h-5 w-5 object-contain"
            }
          ) : /* @__PURE__ */ t.jsx(uu, { className: "h-5 w-5 text-muted-foreground" }) }),
          /* @__PURE__ */ t.jsx("span", { className: "text-sm font-medium", children: i.displayName })
        ] }) }) }),
        /* @__PURE__ */ t.jsxs(Br, { className: "px-4 py-2", children: [
          /* @__PURE__ */ t.jsx("div", { className: "flex flex-wrap gap-2", children: n.map((c) => {
            var d, h;
            const u = (h = (d = i.suggestedActions) == null ? void 0 : d.find(
              (m) => Us.createPieceToolName(
                i.pieceName,
                m.name
              ) === c.toolName
            )) == null ? void 0 : h.displayName;
            return /* @__PURE__ */ t.jsxs(
              "div",
              {
                onClick: () => l(c),
                className: `
                  group flex items-center gap-2 px-3 py-1 cursor-pointer
                  rounded-full border bg-muted/50
                  ${e ? "opacity-50 pointer-events-none" : ""}
                `,
                children: [
                  /* @__PURE__ */ t.jsx("span", { className: "text-xs font-medium", children: u || c.toolName }),
                  /* @__PURE__ */ t.jsx("div", { className: "flex items-center gap-1", children: /* @__PURE__ */ t.jsxs(te, { children: [
                    /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
                      O,
                      {
                        disabled: e,
                        onClick: (m) => {
                          m.stopPropagation(), s(c.toolName);
                        },
                        variant: "ghost",
                        size: "icon",
                        className: `
                          size-5 p-0.5
                          text-muted-foreground
                          hover:text-destructive
                          hover:bg-destructive/10
                          transition
                        `,
                        children: /* @__PURE__ */ t.jsx(Cn, { className: "h-3 w-3" })
                      }
                    ) }),
                    /* @__PURE__ */ t.jsx(Q, { children: f("Remove tool") })
                  ] }) })
                ]
              },
              c.toolName
            );
          }) }),
          /* @__PURE__ */ t.jsxs(
            O,
            {
              variant: "link",
              className: "mt-4",
              size: "xs",
              onClick: () => r({
                page: "actions-list",
                piece: i
              }),
              children: [
                /* @__PURE__ */ t.jsx(_e, { className: "size-3 mr-1" }),
                f("Add Action")
              ]
            }
          )
        ] })
      ]
    }
  );
}, il = () => {
  const { mutate: e, isPending: n } = Qe.useCreateMcpFlow();
  return /* @__PURE__ */ t.jsx(
    O,
    {
      onClick: () => e(),
      variant: "outline",
      className: "mr-auto",
      children: n ? f("Creating...") : f("New MCP Flow")
    }
  );
}, Dp = (e) => e.version.state === it.LOCKED && e.status === "ENABLED", Rp = (e) => e.version.state !== it.LOCKED ? f("Flow must be published to be selected") : e.status !== "ENABLED" ? f("Flow must be enabled to be selected") : "", co = {
  isFlowSelectable: Dp,
  getFlowTooltip: Rp
}, Op = ({
  flows: e,
  selectedFlows: n,
  setSelectedFlows: s,
  searchQuery: r
}) => {
  const [a] = Ws(r, 300), o = p.useMemo(() => {
    if (!a) return e;
    const c = a.toLowerCase();
    return e.filter(
      (u) => u.version.displayName.toLowerCase().includes(c)
    );
  }, [e, a]), i = (c) => n.some((u) => u.externalFlowId === c.externalId), l = (c) => {
    s((u) => u.some(
      (h) => h.externalFlowId === c.externalId
    ) ? u.filter((h) => h.externalFlowId !== c.externalId) : [
      ...u,
      {
        externalFlowId: c.externalId,
        toolName: Us.createToolName(
          `${c.version.displayName}_${c.id}`
        ),
        flowDisplayName: c.version.displayName,
        type: ot.FLOW
      }
    ]);
  };
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsx("div", { className: "flex flex-col px-4 py-2", children: o.map((c, u) => {
      const d = co.getFlowTooltip(c), h = co.isFlowSelectable(c), m = i(c);
      return /* @__PURE__ */ t.jsxs("div", { children: [
        /* @__PURE__ */ t.jsxs(
          "div",
          {
            className: `
                  flex items-center gap-4 px-4 py-2 h-14 rounded-md cursor-pointer
                  hover:bg-accent hover:text-accent-foreground
                  ${m ? "bg-accent" : ""}
                  ${h ? "" : "opacity-50 cursor-not-allowed"}
                `,
            onClick: () => h && l(c),
            children: [
              /* @__PURE__ */ t.jsx(
                hu,
                {
                  checked: m,
                  disabled: !h,
                  onCheckedChange: () => h && l(c),
                  onClick: (y) => y.stopPropagation()
                }
              ),
              /* @__PURE__ */ t.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ t.jsx("div", { className: "truncate text-sm font-medium", children: c.version.displayName }),
                d && /* @__PURE__ */ t.jsx("div", { className: "text-xs text-muted-foreground truncate", children: d })
              ] }),
              /* @__PURE__ */ t.jsx(
                fu,
                {
                  trigger: c.version.trigger,
                  maxNumberOfIconsToShow: 3
                }
              )
            ]
          }
        ),
        u < o.length - 1 && /* @__PURE__ */ t.jsx("div", { className: "h-px bg-border my-1" })
      ] }, c.id);
    }) }),
    o.length === 0 && /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col items-center justify-center py-20 text-center", children: [
      /* @__PURE__ */ t.jsx("div", { className: "mb-5 flex size-14 items-center justify-center rounded-xl border bg-muted/40", children: /* @__PURE__ */ t.jsx(zr, { className: "size-7 text-muted-foreground" }) }),
      /* @__PURE__ */ t.jsx("div", { className: "text-base font-semibold text-foreground", children: f("No flows found") }),
      /* @__PURE__ */ t.jsx("div", { className: "mt-2 max-w-sm text-sm leading-relaxed text-muted-foreground", children: r ? f("Try adjusting your search or create a new flow.") : f("Create a flow to use it as a tool in your agent.") }),
      !r && /* @__PURE__ */ t.jsx("div", { className: "mt-6", children: /* @__PURE__ */ t.jsx(il, {}) })
    ] })
  ] });
};
function Ip({
  onToolsUpdate: e,
  tools: n
}) {
  const [s, r] = p.useState(
    n.filter((h) => h.type === ot.FLOW)
  ), {
    showAddFlowDialog: a,
    setShowAddFlowDialog: o,
    searchQuery: i,
    setSearchQuery: l
  } = Fr(), { data: c } = mu.useFlowsForAgent(), u = p.useMemo(() => c == null ? void 0 : c.data.filter(
    (h) => h.version.trigger.type === ee.PIECE && h.version.trigger.settings.pieceName === "@activepieces/piece-mcp"
  ), [c]), d = () => {
    const m = [...n.filter(
      (y) => y.type !== ot.FLOW
    ), ...s];
    o(!1), e(m), je("Changes to flow tools saved");
  };
  return /* @__PURE__ */ t.jsx(ut, { open: a, onOpenChange: o, children: /* @__PURE__ */ t.jsxs(ht, { className: "w-[90vw] max-w-[750px] h-[80vh] max-h-[800px] flex flex-col overflow-hidden p-0", children: [
    /* @__PURE__ */ t.jsx(ft, { className: "min-h-16 flex px-4 items-start justify-center mb-0 border-b", children: /* @__PURE__ */ t.jsx(mt, { children: f("Add Flow Tools") }) }),
    /* @__PURE__ */ t.jsx("div", { className: "px-4 py-3 border-b", children: /* @__PURE__ */ t.jsxs("div", { className: "relative border rounded-sm", children: [
      /* @__PURE__ */ t.jsx(Wr, { className: "absolute left-2 top-2.5 size-4 text-muted-foreground" }),
      /* @__PURE__ */ t.jsx(
        Et,
        {
          placeholder: f("Search"),
          value: i,
          onChange: (h) => l(h.target.value),
          className: "pl-9 shadow-none border-none"
        }
      )
    ] }) }),
    /* @__PURE__ */ t.jsx(Ze, { className: "grow overflow-y-auto", children: /* @__PURE__ */ t.jsx(
      Op,
      {
        flows: u || [],
        searchQuery: i,
        selectedFlows: s,
        setSelectedFlows: r
      }
    ) }),
    /* @__PURE__ */ t.jsxs(pt, { className: "border-t p-4 mt-auto", children: [
      /* @__PURE__ */ t.jsx(il, {}),
      /* @__PURE__ */ t.jsx(yn, { asChild: !0, children: /* @__PURE__ */ t.jsx(O, { type: "button", variant: "ghost", children: f("Close") }) }),
      /* @__PURE__ */ t.jsx(O, { type: "button", onClick: d, children: f("Save") })
    ] })
  ] }) });
}
function ct(e) {
  return Array.isArray ? Array.isArray(e) : dl(e) === "[object Array]";
}
function Ap(e) {
  if (typeof e == "string")
    return e;
  let n = e + "";
  return n == "0" && 1 / e == -1 / 0 ? "-0" : n;
}
function kp(e) {
  return e == null ? "" : Ap(e);
}
function Ke(e) {
  return typeof e == "string";
}
function ll(e) {
  return typeof e == "number";
}
function Mp(e) {
  return e === !0 || e === !1 || _p(e) && dl(e) == "[object Boolean]";
}
function cl(e) {
  return typeof e == "object";
}
function _p(e) {
  return cl(e) && e !== null;
}
function ke(e) {
  return e != null;
}
function er(e) {
  return !e.trim().length;
}
function dl(e) {
  return e == null ? e === void 0 ? "[object Undefined]" : "[object Null]" : Object.prototype.toString.call(e);
}
const Lp = "Incorrect 'index' type", Fp = (e) => `Invalid value for key ${e}`, zp = (e) => `Pattern length exceeds max of ${e}.`, $p = (e) => `Missing ${e} property in key`, Vp = (e) => `Property 'weight' in key '${e}' must be a positive integer`, uo = Object.prototype.hasOwnProperty;
class Bp {
  constructor(n) {
    this._keys = [], this._keyMap = {};
    let s = 0;
    n.forEach((r) => {
      let a = ul(r);
      this._keys.push(a), this._keyMap[a.id] = a, s += a.weight;
    }), this._keys.forEach((r) => {
      r.weight /= s;
    });
  }
  get(n) {
    return this._keyMap[n];
  }
  keys() {
    return this._keys;
  }
  toJSON() {
    return JSON.stringify(this._keys);
  }
}
function ul(e) {
  let n = null, s = null, r = null, a = 1, o = null;
  if (Ke(e) || ct(e))
    r = e, n = ho(e), s = jr(e);
  else {
    if (!uo.call(e, "name"))
      throw new Error($p("name"));
    const i = e.name;
    if (r = i, uo.call(e, "weight") && (a = e.weight, a <= 0))
      throw new Error(Vp(i));
    n = ho(i), s = jr(i), o = e.getFn;
  }
  return { path: n, id: s, weight: a, src: r, getFn: o };
}
function ho(e) {
  return ct(e) ? e : e.split(".");
}
function jr(e) {
  return ct(e) ? e.join(".") : e;
}
function Up(e, n) {
  let s = [], r = !1;
  const a = (o, i, l) => {
    if (ke(o))
      if (!i[l])
        s.push(o);
      else {
        let c = i[l];
        const u = o[c];
        if (!ke(u))
          return;
        if (l === i.length - 1 && (Ke(u) || ll(u) || Mp(u)))
          s.push(kp(u));
        else if (ct(u)) {
          r = !0;
          for (let d = 0, h = u.length; d < h; d += 1)
            a(u[d], i, l + 1);
        } else i.length && a(u, i, l + 1);
      }
  };
  return a(e, Ke(n) ? n.split(".") : n, 0), r ? s : s[0];
}
const Wp = {
  // Whether the matches should be included in the result set. When `true`, each record in the result
  // set will include the indices of the matched characters.
  // These can consequently be used for highlighting purposes.
  includeMatches: !1,
  // When `true`, the matching function will continue to the end of a search pattern even if
  // a perfect match has already been located in the string.
  findAllMatches: !1,
  // Minimum number of characters that must be matched before a result is considered a match
  minMatchCharLength: 1
}, Hp = {
  // When `true`, the algorithm continues searching to the end of the input even if a perfect
  // match is found before the end of the same input.
  isCaseSensitive: !1,
  // When true, the matching function will continue to the end of a search pattern even if
  includeScore: !1,
  // List of properties that will be searched. This also supports nested properties.
  keys: [],
  // Whether to sort the result list, by score
  shouldSort: !0,
  // Default sort function: sort by ascending score, ascending index
  sortFn: (e, n) => e.score === n.score ? e.idx < n.idx ? -1 : 1 : e.score < n.score ? -1 : 1
}, Gp = {
  // Approximately where in the text is the pattern expected to be found?
  location: 0,
  // At what point does the match algorithm give up. A threshold of '0.0' requires a perfect match
  // (of both letters and location), a threshold of '1.0' would match anything.
  threshold: 0.6,
  // Determines how close the match must be to the fuzzy location (specified above).
  // An exact letter match which is 'distance' characters away from the fuzzy location
  // would score as a complete mismatch. A distance of '0' requires the match be at
  // the exact location specified, a threshold of '1000' would require a perfect match
  // to be within 800 characters of the fuzzy location to be found using a 0.8 threshold.
  distance: 100
}, qp = {
  // When `true`, it enables the use of unix-like search commands
  useExtendedSearch: !1,
  // The get function to use when fetching an object's properties.
  // The default will search nested paths *ie foo.bar.baz*
  getFn: Up,
  // When `true`, search will ignore `location` and `distance`, so it won't matter
  // where in the string the pattern appears.
  // More info: https://fusejs.io/concepts/scoring-theory.html#fuzziness-score
  ignoreLocation: !1,
  // When `true`, the calculation for the relevance score (used for sorting) will
  // ignore the field-length norm.
  // More info: https://fusejs.io/concepts/scoring-theory.html#field-length-norm
  ignoreFieldNorm: !1,
  // The weight to determine how much field length norm effects scoring.
  fieldNormWeight: 1
};
var V = {
  ...Hp,
  ...Wp,
  ...Gp,
  ...qp
};
const Kp = /[^ ]+/g;
function Yp(e = 1, n = 3) {
  const s = /* @__PURE__ */ new Map(), r = Math.pow(10, n);
  return {
    get(a) {
      const o = a.match(Kp).length;
      if (s.has(o))
        return s.get(o);
      const i = 1 / Math.pow(o, 0.5 * e), l = parseFloat(Math.round(i * r) / r);
      return s.set(o, l), l;
    },
    clear() {
      s.clear();
    }
  };
}
class ra {
  constructor({
    getFn: n = V.getFn,
    fieldNormWeight: s = V.fieldNormWeight
  } = {}) {
    this.norm = Yp(s, 3), this.getFn = n, this.isCreated = !1, this.setIndexRecords();
  }
  setSources(n = []) {
    this.docs = n;
  }
  setIndexRecords(n = []) {
    this.records = n;
  }
  setKeys(n = []) {
    this.keys = n, this._keysMap = {}, n.forEach((s, r) => {
      this._keysMap[s.id] = r;
    });
  }
  create() {
    this.isCreated || !this.docs.length || (this.isCreated = !0, Ke(this.docs[0]) ? this.docs.forEach((n, s) => {
      this._addString(n, s);
    }) : this.docs.forEach((n, s) => {
      this._addObject(n, s);
    }), this.norm.clear());
  }
  // Adds a doc to the end of the index
  add(n) {
    const s = this.size();
    Ke(n) ? this._addString(n, s) : this._addObject(n, s);
  }
  // Removes the doc at the specified index of the index
  removeAt(n) {
    this.records.splice(n, 1);
    for (let s = n, r = this.size(); s < r; s += 1)
      this.records[s].i -= 1;
  }
  getValueForItemAtKeyId(n, s) {
    return n[this._keysMap[s]];
  }
  size() {
    return this.records.length;
  }
  _addString(n, s) {
    if (!ke(n) || er(n))
      return;
    let r = {
      v: n,
      i: s,
      n: this.norm.get(n)
    };
    this.records.push(r);
  }
  _addObject(n, s) {
    let r = { i: s, $: {} };
    this.keys.forEach((a, o) => {
      let i = a.getFn ? a.getFn(n) : this.getFn(n, a.path);
      if (ke(i)) {
        if (ct(i)) {
          let l = [];
          const c = [{ nestedArrIndex: -1, value: i }];
          for (; c.length; ) {
            const { nestedArrIndex: u, value: d } = c.pop();
            if (ke(d))
              if (Ke(d) && !er(d)) {
                let h = {
                  v: d,
                  i: u,
                  n: this.norm.get(d)
                };
                l.push(h);
              } else ct(d) && d.forEach((h, m) => {
                c.push({
                  nestedArrIndex: m,
                  value: h
                });
              });
          }
          r.$[o] = l;
        } else if (Ke(i) && !er(i)) {
          let l = {
            v: i,
            n: this.norm.get(i)
          };
          r.$[o] = l;
        }
      }
    }), this.records.push(r);
  }
  toJSON() {
    return {
      keys: this.keys,
      records: this.records
    };
  }
}
function hl(e, n, { getFn: s = V.getFn, fieldNormWeight: r = V.fieldNormWeight } = {}) {
  const a = new ra({ getFn: s, fieldNormWeight: r });
  return a.setKeys(e.map(ul)), a.setSources(n), a.create(), a;
}
function Xp(e, { getFn: n = V.getFn, fieldNormWeight: s = V.fieldNormWeight } = {}) {
  const { keys: r, records: a } = e, o = new ra({ getFn: n, fieldNormWeight: s });
  return o.setKeys(r), o.setIndexRecords(a), o;
}
function ms(e, {
  errors: n = 0,
  currentLocation: s = 0,
  expectedLocation: r = 0,
  distance: a = V.distance,
  ignoreLocation: o = V.ignoreLocation
} = {}) {
  const i = n / e.length;
  if (o)
    return i;
  const l = Math.abs(r - s);
  return a ? i + l / a : l ? 1 : i;
}
function Jp(e = [], n = V.minMatchCharLength) {
  let s = [], r = -1, a = -1, o = 0;
  for (let i = e.length; o < i; o += 1) {
    let l = e[o];
    l && r === -1 ? r = o : !l && r !== -1 && (a = o - 1, a - r + 1 >= n && s.push([r, a]), r = -1);
  }
  return e[o - 1] && o - r >= n && s.push([r, o - 1]), s;
}
const At = 32;
function Qp(e, n, s, {
  location: r = V.location,
  distance: a = V.distance,
  threshold: o = V.threshold,
  findAllMatches: i = V.findAllMatches,
  minMatchCharLength: l = V.minMatchCharLength,
  includeMatches: c = V.includeMatches,
  ignoreLocation: u = V.ignoreLocation
} = {}) {
  if (n.length > At)
    throw new Error(zp(At));
  const d = n.length, h = e.length, m = Math.max(0, Math.min(r, h));
  let y = o, v = m;
  const g = l > 1 || c, j = g ? Array(h) : [];
  let x;
  for (; (x = e.indexOf(n, v)) > -1; ) {
    let S = ms(n, {
      currentLocation: x,
      expectedLocation: m,
      distance: a,
      ignoreLocation: u
    });
    if (y = Math.min(S, y), v = x + d, g) {
      let C = 0;
      for (; C < d; )
        j[x + C] = 1, C += 1;
    }
  }
  v = -1;
  let N = [], w = 1, b = d + h;
  const E = 1 << d - 1;
  for (let S = 0; S < d; S += 1) {
    let C = 0, T = b;
    for (; C < T; )
      ms(n, {
        errors: S,
        currentLocation: m + T,
        expectedLocation: m,
        distance: a,
        ignoreLocation: u
      }) <= y ? C = T : b = T, T = Math.floor((b - C) / 2 + C);
    b = T;
    let I = Math.max(1, m - T + 1), P = i ? h : Math.min(m + T, h) + d, D = Array(P + 2);
    D[P + 1] = (1 << S) - 1;
    for (let _ = P; _ >= I; _ -= 1) {
      let L = _ - 1, H = s[e.charAt(L)];
      if (g && (j[L] = +!!H), D[_] = (D[_ + 1] << 1 | 1) & H, S && (D[_] |= (N[_ + 1] | N[_]) << 1 | 1 | N[_ + 1]), D[_] & E && (w = ms(n, {
        errors: S,
        currentLocation: L,
        expectedLocation: m,
        distance: a,
        ignoreLocation: u
      }), w <= y)) {
        if (y = w, v = L, v <= m)
          break;
        I = Math.max(1, 2 * m - v);
      }
    }
    if (ms(n, {
      errors: S + 1,
      currentLocation: m,
      expectedLocation: m,
      distance: a,
      ignoreLocation: u
    }) > y)
      break;
    N = D;
  }
  const R = {
    isMatch: v >= 0,
    // Count exact matches (those with a score of 0) to be "almost" exact
    score: Math.max(1e-3, w)
  };
  if (g) {
    const S = Jp(j, l);
    S.length ? c && (R.indices = S) : R.isMatch = !1;
  }
  return R;
}
function Zp(e) {
  let n = {};
  for (let s = 0, r = e.length; s < r; s += 1) {
    const a = e.charAt(s);
    n[a] = (n[a] || 0) | 1 << r - s - 1;
  }
  return n;
}
class fl {
  constructor(n, {
    location: s = V.location,
    threshold: r = V.threshold,
    distance: a = V.distance,
    includeMatches: o = V.includeMatches,
    findAllMatches: i = V.findAllMatches,
    minMatchCharLength: l = V.minMatchCharLength,
    isCaseSensitive: c = V.isCaseSensitive,
    ignoreLocation: u = V.ignoreLocation
  } = {}) {
    if (this.options = {
      location: s,
      threshold: r,
      distance: a,
      includeMatches: o,
      findAllMatches: i,
      minMatchCharLength: l,
      isCaseSensitive: c,
      ignoreLocation: u
    }, this.pattern = c ? n : n.toLowerCase(), this.chunks = [], !this.pattern.length)
      return;
    const d = (m, y) => {
      this.chunks.push({
        pattern: m,
        alphabet: Zp(m),
        startIndex: y
      });
    }, h = this.pattern.length;
    if (h > At) {
      let m = 0;
      const y = h % At, v = h - y;
      for (; m < v; )
        d(this.pattern.substr(m, At), m), m += At;
      if (y) {
        const g = h - At;
        d(this.pattern.substr(g), g);
      }
    } else
      d(this.pattern, 0);
  }
  searchIn(n) {
    const { isCaseSensitive: s, includeMatches: r } = this.options;
    if (s || (n = n.toLowerCase()), this.pattern === n) {
      let v = {
        isMatch: !0,
        score: 0
      };
      return r && (v.indices = [[0, n.length - 1]]), v;
    }
    const {
      location: a,
      distance: o,
      threshold: i,
      findAllMatches: l,
      minMatchCharLength: c,
      ignoreLocation: u
    } = this.options;
    let d = [], h = 0, m = !1;
    this.chunks.forEach(({ pattern: v, alphabet: g, startIndex: j }) => {
      const { isMatch: x, score: N, indices: w } = Qp(n, v, g, {
        location: a + j,
        distance: o,
        threshold: i,
        findAllMatches: l,
        minMatchCharLength: c,
        includeMatches: r,
        ignoreLocation: u
      });
      x && (m = !0), h += N, x && w && (d = [...d, ...w]);
    });
    let y = {
      isMatch: m,
      score: m ? h / this.chunks.length : 1
    };
    return m && r && (y.indices = d), y;
  }
}
class Tt {
  constructor(n) {
    this.pattern = n;
  }
  static isMultiMatch(n) {
    return fo(n, this.multiRegex);
  }
  static isSingleMatch(n) {
    return fo(n, this.singleRegex);
  }
  search() {
  }
}
function fo(e, n) {
  const s = e.match(n);
  return s ? s[1] : null;
}
class eg extends Tt {
  constructor(n) {
    super(n);
  }
  static get type() {
    return "exact";
  }
  static get multiRegex() {
    return /^="(.*)"$/;
  }
  static get singleRegex() {
    return /^=(.*)$/;
  }
  search(n) {
    const s = n === this.pattern;
    return {
      isMatch: s,
      score: s ? 0 : 1,
      indices: [0, this.pattern.length - 1]
    };
  }
}
class tg extends Tt {
  constructor(n) {
    super(n);
  }
  static get type() {
    return "inverse-exact";
  }
  static get multiRegex() {
    return /^!"(.*)"$/;
  }
  static get singleRegex() {
    return /^!(.*)$/;
  }
  search(n) {
    const r = n.indexOf(this.pattern) === -1;
    return {
      isMatch: r,
      score: r ? 0 : 1,
      indices: [0, n.length - 1]
    };
  }
}
class ng extends Tt {
  constructor(n) {
    super(n);
  }
  static get type() {
    return "prefix-exact";
  }
  static get multiRegex() {
    return /^\^"(.*)"$/;
  }
  static get singleRegex() {
    return /^\^(.*)$/;
  }
  search(n) {
    const s = n.startsWith(this.pattern);
    return {
      isMatch: s,
      score: s ? 0 : 1,
      indices: [0, this.pattern.length - 1]
    };
  }
}
class sg extends Tt {
  constructor(n) {
    super(n);
  }
  static get type() {
    return "inverse-prefix-exact";
  }
  static get multiRegex() {
    return /^!\^"(.*)"$/;
  }
  static get singleRegex() {
    return /^!\^(.*)$/;
  }
  search(n) {
    const s = !n.startsWith(this.pattern);
    return {
      isMatch: s,
      score: s ? 0 : 1,
      indices: [0, n.length - 1]
    };
  }
}
class rg extends Tt {
  constructor(n) {
    super(n);
  }
  static get type() {
    return "suffix-exact";
  }
  static get multiRegex() {
    return /^"(.*)"\$$/;
  }
  static get singleRegex() {
    return /^(.*)\$$/;
  }
  search(n) {
    const s = n.endsWith(this.pattern);
    return {
      isMatch: s,
      score: s ? 0 : 1,
      indices: [n.length - this.pattern.length, n.length - 1]
    };
  }
}
class ag extends Tt {
  constructor(n) {
    super(n);
  }
  static get type() {
    return "inverse-suffix-exact";
  }
  static get multiRegex() {
    return /^!"(.*)"\$$/;
  }
  static get singleRegex() {
    return /^!(.*)\$$/;
  }
  search(n) {
    const s = !n.endsWith(this.pattern);
    return {
      isMatch: s,
      score: s ? 0 : 1,
      indices: [0, n.length - 1]
    };
  }
}
class ml extends Tt {
  constructor(n, {
    location: s = V.location,
    threshold: r = V.threshold,
    distance: a = V.distance,
    includeMatches: o = V.includeMatches,
    findAllMatches: i = V.findAllMatches,
    minMatchCharLength: l = V.minMatchCharLength,
    isCaseSensitive: c = V.isCaseSensitive,
    ignoreLocation: u = V.ignoreLocation
  } = {}) {
    super(n), this._bitapSearch = new fl(n, {
      location: s,
      threshold: r,
      distance: a,
      includeMatches: o,
      findAllMatches: i,
      minMatchCharLength: l,
      isCaseSensitive: c,
      ignoreLocation: u
    });
  }
  static get type() {
    return "fuzzy";
  }
  static get multiRegex() {
    return /^"(.*)"$/;
  }
  static get singleRegex() {
    return /^(.*)$/;
  }
  search(n) {
    return this._bitapSearch.searchIn(n);
  }
}
class pl extends Tt {
  constructor(n) {
    super(n);
  }
  static get type() {
    return "include";
  }
  static get multiRegex() {
    return /^'"(.*)"$/;
  }
  static get singleRegex() {
    return /^'(.*)$/;
  }
  search(n) {
    let s = 0, r;
    const a = [], o = this.pattern.length;
    for (; (r = n.indexOf(this.pattern, s)) > -1; )
      s = r + o, a.push([r, s - 1]);
    const i = !!a.length;
    return {
      isMatch: i,
      score: i ? 0 : 1,
      indices: a
    };
  }
}
const wr = [
  eg,
  pl,
  ng,
  sg,
  ag,
  rg,
  tg,
  ml
], mo = wr.length, og = / +(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/, ig = "|";
function lg(e, n = {}) {
  return e.split(ig).map((s) => {
    let r = s.trim().split(og).filter((o) => o && !!o.trim()), a = [];
    for (let o = 0, i = r.length; o < i; o += 1) {
      const l = r[o];
      let c = !1, u = -1;
      for (; !c && ++u < mo; ) {
        const d = wr[u];
        let h = d.isMultiMatch(l);
        h && (a.push(new d(h, n)), c = !0);
      }
      if (!c)
        for (u = -1; ++u < mo; ) {
          const d = wr[u];
          let h = d.isSingleMatch(l);
          if (h) {
            a.push(new d(h, n));
            break;
          }
        }
    }
    return a;
  });
}
const cg = /* @__PURE__ */ new Set([ml.type, pl.type]);
class dg {
  constructor(n, {
    isCaseSensitive: s = V.isCaseSensitive,
    includeMatches: r = V.includeMatches,
    minMatchCharLength: a = V.minMatchCharLength,
    ignoreLocation: o = V.ignoreLocation,
    findAllMatches: i = V.findAllMatches,
    location: l = V.location,
    threshold: c = V.threshold,
    distance: u = V.distance
  } = {}) {
    this.query = null, this.options = {
      isCaseSensitive: s,
      includeMatches: r,
      minMatchCharLength: a,
      findAllMatches: i,
      ignoreLocation: o,
      location: l,
      threshold: c,
      distance: u
    }, this.pattern = s ? n : n.toLowerCase(), this.query = lg(this.pattern, this.options);
  }
  static condition(n, s) {
    return s.useExtendedSearch;
  }
  searchIn(n) {
    const s = this.query;
    if (!s)
      return {
        isMatch: !1,
        score: 1
      };
    const { includeMatches: r, isCaseSensitive: a } = this.options;
    n = a ? n : n.toLowerCase();
    let o = 0, i = [], l = 0;
    for (let c = 0, u = s.length; c < u; c += 1) {
      const d = s[c];
      i.length = 0, o = 0;
      for (let h = 0, m = d.length; h < m; h += 1) {
        const y = d[h], { isMatch: v, indices: g, score: j } = y.search(n);
        if (v) {
          if (o += 1, l += j, r) {
            const x = y.constructor.type;
            cg.has(x) ? i = [...i, ...g] : i.push(g);
          }
        } else {
          l = 0, o = 0, i.length = 0;
          break;
        }
      }
      if (o) {
        let h = {
          isMatch: !0,
          score: l / o
        };
        return r && (h.indices = i), h;
      }
    }
    return {
      isMatch: !1,
      score: 1
    };
  }
}
const Nr = [];
function ug(...e) {
  Nr.push(...e);
}
function br(e, n) {
  for (let s = 0, r = Nr.length; s < r; s += 1) {
    let a = Nr[s];
    if (a.condition(e, n))
      return new a(e, n);
  }
  return new fl(e, n);
}
const Ls = {
  AND: "$and",
  OR: "$or"
}, Sr = {
  PATH: "$path",
  PATTERN: "$val"
}, Cr = (e) => !!(e[Ls.AND] || e[Ls.OR]), hg = (e) => !!e[Sr.PATH], fg = (e) => !ct(e) && cl(e) && !Cr(e), po = (e) => ({
  [Ls.AND]: Object.keys(e).map((n) => ({
    [n]: e[n]
  }))
});
function gl(e, n, { auto: s = !0 } = {}) {
  const r = (a) => {
    let o = Object.keys(a);
    const i = hg(a);
    if (!i && o.length > 1 && !Cr(a))
      return r(po(a));
    if (fg(a)) {
      const c = i ? a[Sr.PATH] : o[0], u = i ? a[Sr.PATTERN] : a[c];
      if (!Ke(u))
        throw new Error(Fp(c));
      const d = {
        keyId: jr(c),
        pattern: u
      };
      return s && (d.searcher = br(u, n)), d;
    }
    let l = {
      children: [],
      operator: o[0]
    };
    return o.forEach((c) => {
      const u = a[c];
      ct(u) && u.forEach((d) => {
        l.children.push(r(d));
      });
    }), l;
  };
  return Cr(e) || (e = po(e)), r(e);
}
function mg(e, { ignoreFieldNorm: n = V.ignoreFieldNorm }) {
  e.forEach((s) => {
    let r = 1;
    s.matches.forEach(({ key: a, norm: o, score: i }) => {
      const l = a ? a.weight : null;
      r *= Math.pow(
        i === 0 && l ? Number.EPSILON : i,
        (l || 1) * (n ? 1 : o)
      );
    }), s.score = r;
  });
}
function pg(e, n) {
  const s = e.matches;
  n.matches = [], ke(s) && s.forEach((r) => {
    if (!ke(r.indices) || !r.indices.length)
      return;
    const { indices: a, value: o } = r;
    let i = {
      indices: a,
      value: o
    };
    r.key && (i.key = r.key.src), r.idx > -1 && (i.refIndex = r.idx), n.matches.push(i);
  });
}
function gg(e, n) {
  n.score = e.score;
}
function xg(e, n, {
  includeMatches: s = V.includeMatches,
  includeScore: r = V.includeScore
} = {}) {
  const a = [];
  return s && a.push(pg), r && a.push(gg), e.map((o) => {
    const { idx: i } = o, l = {
      item: n[i],
      refIndex: i
    };
    return a.length && a.forEach((c) => {
      c(o, l);
    }), l;
  });
}
class On {
  constructor(n, s = {}, r) {
    this.options = { ...V, ...s }, this.options.useExtendedSearch, this._keyStore = new Bp(this.options.keys), this.setCollection(n, r);
  }
  setCollection(n, s) {
    if (this._docs = n, s && !(s instanceof ra))
      throw new Error(Lp);
    this._myIndex = s || hl(this.options.keys, this._docs, {
      getFn: this.options.getFn,
      fieldNormWeight: this.options.fieldNormWeight
    });
  }
  add(n) {
    ke(n) && (this._docs.push(n), this._myIndex.add(n));
  }
  remove(n = () => !1) {
    const s = [];
    for (let r = 0, a = this._docs.length; r < a; r += 1) {
      const o = this._docs[r];
      n(o, r) && (this.removeAt(r), r -= 1, a -= 1, s.push(o));
    }
    return s;
  }
  removeAt(n) {
    this._docs.splice(n, 1), this._myIndex.removeAt(n);
  }
  getIndex() {
    return this._myIndex;
  }
  search(n, { limit: s = -1 } = {}) {
    const {
      includeMatches: r,
      includeScore: a,
      shouldSort: o,
      sortFn: i,
      ignoreFieldNorm: l
    } = this.options;
    let c = Ke(n) ? Ke(this._docs[0]) ? this._searchStringList(n) : this._searchObjectList(n) : this._searchLogical(n);
    return mg(c, { ignoreFieldNorm: l }), o && c.sort(i), ll(s) && s > -1 && (c = c.slice(0, s)), xg(c, this._docs, {
      includeMatches: r,
      includeScore: a
    });
  }
  _searchStringList(n) {
    const s = br(n, this.options), { records: r } = this._myIndex, a = [];
    return r.forEach(({ v: o, i, n: l }) => {
      if (!ke(o))
        return;
      const { isMatch: c, score: u, indices: d } = s.searchIn(o);
      c && a.push({
        item: o,
        idx: i,
        matches: [{ score: u, value: o, norm: l, indices: d }]
      });
    }), a;
  }
  _searchLogical(n) {
    const s = gl(n, this.options), r = (l, c, u) => {
      if (!l.children) {
        const { keyId: h, searcher: m } = l, y = this._findMatches({
          key: this._keyStore.get(h),
          value: this._myIndex.getValueForItemAtKeyId(c, h),
          searcher: m
        });
        return y && y.length ? [
          {
            idx: u,
            item: c,
            matches: y
          }
        ] : [];
      }
      const d = [];
      for (let h = 0, m = l.children.length; h < m; h += 1) {
        const y = l.children[h], v = r(y, c, u);
        if (v.length)
          d.push(...v);
        else if (l.operator === Ls.AND)
          return [];
      }
      return d;
    }, a = this._myIndex.records, o = {}, i = [];
    return a.forEach(({ $: l, i: c }) => {
      if (ke(l)) {
        let u = r(s, l, c);
        u.length && (o[c] || (o[c] = { idx: c, item: l, matches: [] }, i.push(o[c])), u.forEach(({ matches: d }) => {
          o[c].matches.push(...d);
        }));
      }
    }), i;
  }
  _searchObjectList(n) {
    const s = br(n, this.options), { keys: r, records: a } = this._myIndex, o = [];
    return a.forEach(({ $: i, i: l }) => {
      if (!ke(i))
        return;
      let c = [];
      r.forEach((u, d) => {
        c.push(
          ...this._findMatches({
            key: u,
            value: i[d],
            searcher: s
          })
        );
      }), c.length && o.push({
        idx: l,
        item: i,
        matches: c
      });
    }), o;
  }
  _findMatches({ key: n, value: s, searcher: r }) {
    if (!ke(s))
      return [];
    let a = [];
    if (ct(s))
      s.forEach(({ v: o, i, n: l }) => {
        if (!ke(o))
          return;
        const { isMatch: c, score: u, indices: d } = r.searchIn(o);
        c && a.push({
          score: u,
          key: n,
          value: o,
          idx: i,
          norm: l,
          indices: d
        });
      });
    else {
      const { v: o, n: i } = s, { isMatch: l, score: c, indices: u } = r.searchIn(o);
      l && a.push({ score: c, key: n, value: o, norm: i, indices: u });
    }
    return a;
  }
}
On.version = "7.0.0";
On.createIndex = hl;
On.parseIndex = Xp;
On.config = V;
On.parseQuery = gl;
ug(dg);
const vg = ({
  tools: e
}) => {
  const [n, s] = p.useState(""), [r] = Ws(n, 200), { handleActionSelect: a, selectedPiece: o } = Lt(), i = p.useMemo(
    () => new Set(e.map((u) => u.toolName)),
    [e]
  ), l = p.useMemo(() => M(o) || M(o.suggestedActions) ? null : new On(o.suggestedActions, {
    keys: [
      { name: "displayName", weight: 0.8 },
      { name: "description", weight: 0.2 }
    ],
    threshold: 0.35,
    ignoreLocation: !0
  }), [o == null ? void 0 : o.suggestedActions]), c = p.useMemo(() => !r.trim() || M(l) ? (o == null ? void 0 : o.suggestedActions) || [] : l.search(r).map((u) => u.item), [r, l, o == null ? void 0 : o.suggestedActions]);
  return M(o) ? /* @__PURE__ */ t.jsx("p", { children: f("No app is selected") }) : /* @__PURE__ */ t.jsxs(Ze, { className: "overflow-y-auto", children: [
    /* @__PURE__ */ t.jsx("div", { className: "px-4 py-3 border-b", children: /* @__PURE__ */ t.jsxs("div", { className: "relative border rounded-sm", children: [
      /* @__PURE__ */ t.jsx(Wr, { className: "absolute left-2 top-2.5 size-4 text-muted-foreground" }),
      /* @__PURE__ */ t.jsx(
        Et,
        {
          placeholder: f("Search"),
          value: n,
          onChange: (u) => s(u.target.value),
          className: "pl-9 shadow-none border-none"
        }
      )
    ] }) }),
    /* @__PURE__ */ t.jsxs("div", { className: "flex p-4 flex-col gap-2", children: [
      c.map((u) => {
        const d = i.has(
          Us.createPieceToolName(
            o.pieceName,
            u.name
          )
        );
        return /* @__PURE__ */ t.jsx(
          "div",
          {
            className: `
                p-2 flex items-center gap-x-2 rounded-lg transition
                ${d ? "opacity-50 cursor-not-allowed" : "hover:bg-accent cursor-pointer"}
              `,
            onClick: () => {
              d || a(u);
            },
            children: /* @__PURE__ */ t.jsxs("div", { className: "flex gap-2", children: [
              /* @__PURE__ */ t.jsx("div", { className: "size-9 flex items-center justify-center rounded-sm border bg-background", children: /* @__PURE__ */ t.jsx(
                "img",
                {
                  className: "size-6 object-contain",
                  src: o.logoUrl,
                  alt: o.displayName
                }
              ) }),
              /* @__PURE__ */ t.jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
                  /* @__PURE__ */ t.jsx("span", { className: "font-medium text-sm", children: u.displayName }),
                  d && /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground", children: f("(Already added)") })
                ] }),
                u.description && /* @__PURE__ */ t.jsx("div", { className: "text-xs text-muted-foreground mt-0.5 line-clamp-2", children: u.description })
              ] })
            ] })
          },
          u.name
        );
      }),
      c.length === 0 && /* @__PURE__ */ t.jsx("div", { className: "text-center text-muted-foreground py-8", children: f("No actions found") })
    ] })
  ] });
}, yg = ({
  isPiecesLoading: e,
  pieceMetadata: n
}) => {
  const { searchQuery: s, setSearchQuery: r, handlePieceSelect: a } = Lt(), o = !e && n.length === 0;
  return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col h-full", children: [
    /* @__PURE__ */ t.jsx("div", { className: "px-4 py-3 border-b", children: /* @__PURE__ */ t.jsxs("div", { className: "relative border rounded-sm", children: [
      /* @__PURE__ */ t.jsx(Wr, { className: "absolute left-2 top-2.5 size-4 text-muted-foreground" }),
      /* @__PURE__ */ t.jsx(
        Et,
        {
          placeholder: f("Search"),
          value: s,
          onChange: (i) => r(i.target.value),
          className: "pl-9 shadow-none border-none"
        }
      )
    ] }) }),
    /* @__PURE__ */ t.jsx(Ze, { className: "flex-1 min-h-0 px-4 py-2", children: e ? /* @__PURE__ */ t.jsx("div", { className: "grid grid-cols-3 gap-4", children: Array.from({ length: 22 }).map((i, l) => /* @__PURE__ */ t.jsx(ce, { className: "h-12 w-full rounded-lg" }, l)) }) : o ? /* @__PURE__ */ t.jsx("div", { className: "h-full flex items-center py-2 justify-center text-muted-foreground", children: f("No pieces found") }) : /* @__PURE__ */ t.jsx("div", { className: "grid grid-cols-3 gap-4", children: n.map((i, l) => /* @__PURE__ */ t.jsxs(
      "div",
      {
        onClick: () => a(i),
        className: "p-2 flex items-center gap-x-2 hover:bg-accent cursor-pointer rounded-lg",
        children: [
          /* @__PURE__ */ t.jsx("div", { className: "size-9 flex items-center justify-center rounded-sm aspect-square border bg-background", children: /* @__PURE__ */ t.jsx(
            "img",
            {
              className: "size-6 rounded object-contain",
              src: i.logoUrl,
              alt: i.displayName
            }
          ) }),
          /* @__PURE__ */ t.jsx("p", { className: "font-semibold text-sm", children: i.displayName })
        ]
      },
      l
    )) }) })
  ] });
}, Cs = ({
  type: e,
  className: n = "h-4 w-4"
}) => {
  switch (e) {
    case rt.TEXT:
      return /* @__PURE__ */ t.jsx(gu, { className: n });
    case rt.NUMBER:
      return /* @__PURE__ */ t.jsx(pu, { className: n });
    case rt.BOOLEAN:
      return /* @__PURE__ */ t.jsx(Fm, { className: n });
    default:
      return null;
  }
}, jg = ({
  onAddField: e,
  disabled: n
}) => {
  const [s, r] = p.useState(
    void 0
  ), [a, o] = p.useState(""), [i, l] = p.useState(""), [c, u] = p.useState(!1), d = () => {
    s && a.trim() && i.trim() && (e(s, a.trim(), i.trim()), r(void 0), o(""), l(""), u(!1));
  };
  return /* @__PURE__ */ t.jsxs(xu, { open: c, onOpenChange: u, children: [
    /* @__PURE__ */ t.jsx(vu, { asChild: !0, children: /* @__PURE__ */ t.jsxs(O, { variant: "outline", className: "w-full", disabled: n, children: [
      /* @__PURE__ */ t.jsx(_e, { className: "h-4 w-4 mr-2" }),
      f("Add Field")
    ] }) }),
    /* @__PURE__ */ t.jsx(
      yu,
      {
        className: "w-80",
        side: "bottom",
        align: "center",
        sideOffset: 10,
        children: /* @__PURE__ */ t.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ t.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ t.jsx("label", { className: "text-sm font-medium", children: "Field Type" }),
            /* @__PURE__ */ t.jsxs(
              Zn,
              {
                value: s,
                onValueChange: (h) => r(h),
                children: [
                  /* @__PURE__ */ t.jsx(es, { children: /* @__PURE__ */ t.jsx(ts, { placeholder: "Select type" }) }),
                  /* @__PURE__ */ t.jsxs(ns, { children: [
                    /* @__PURE__ */ t.jsx(Xe, { value: rt.TEXT, children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center", children: [
                      /* @__PURE__ */ t.jsx(
                        Cs,
                        {
                          type: rt.TEXT,
                          className: "h-4 w-4 mr-2 text-muted-foreground"
                        }
                      ),
                      /* @__PURE__ */ t.jsx("span", { children: "Text" })
                    ] }) }),
                    /* @__PURE__ */ t.jsx(Xe, { value: rt.NUMBER, children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center", children: [
                      /* @__PURE__ */ t.jsx(
                        Cs,
                        {
                          type: rt.NUMBER,
                          className: "h-4 w-4 mr-2 text-muted-foreground"
                        }
                      ),
                      /* @__PURE__ */ t.jsx("span", { children: "Number" })
                    ] }) }),
                    /* @__PURE__ */ t.jsx(Xe, { value: rt.BOOLEAN, children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center", children: [
                      /* @__PURE__ */ t.jsx(
                        Cs,
                        {
                          type: rt.BOOLEAN,
                          className: "h-4 w-4 mr-2 text-muted-foreground"
                        }
                      ),
                      /* @__PURE__ */ t.jsx("span", { children: "Yes/No" })
                    ] }) })
                  ] })
                ]
              }
            )
          ] }),
          /* @__PURE__ */ t.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ t.jsx("label", { className: "text-sm font-medium", children: "Field Name" }),
            /* @__PURE__ */ t.jsx(
              Et,
              {
                id: "field-name",
                placeholder: "Enter field name",
                value: a,
                onChange: (h) => o(h.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ t.jsxs("div", { className: "space-y-2", children: [
            /* @__PURE__ */ t.jsx("label", { className: "text-sm font-medium", children: "Field Description" }),
            /* @__PURE__ */ t.jsx(
              Et,
              {
                id: "field-description",
                placeholder: "Enter field description",
                value: i,
                onChange: (h) => l(h.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ t.jsx(
            O,
            {
              className: "w-full",
              onClick: d,
              variant: "default",
              disabled: !s || !a.trim() || !i.trim(),
              children: "Add"
            }
          )
        ] })
      }
    )
  ] });
}, wg = ({
  structuredOutputField: e,
  disabled: n
}) => {
  const s = e.value, r = Array.isArray(s) ? s : [], a = (i, l, c) => {
    const u = { displayName: l, description: c, type: i };
    e.onChange([...r ?? [], u]);
  }, o = (i) => {
    const l = r.filter((c) => c.displayName !== i);
    e.onChange(l);
  };
  return /* @__PURE__ */ t.jsxs("div", { children: [
    /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-between mb-2", children: /* @__PURE__ */ t.jsx("h2", { className: "text-sm font-medium", children: f("Structured Output") }) }),
    /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-2 mt-4", children: [
      r.length > 0 ? /* @__PURE__ */ t.jsx(ju, { children: /* @__PURE__ */ t.jsx(wu, { className: "px-2 py-2", children: /* @__PURE__ */ t.jsx("div", { className: "flex flex-col gap-3", children: r.map((i, l) => /* @__PURE__ */ t.jsx(
        "div",
        {
          className: "flex items-center justify-between",
          children: /* @__PURE__ */ t.jsxs("div", { className: "grid grid-cols-12 gap-2 w-full items-center", children: [
            /* @__PURE__ */ t.jsx("div", { className: "col-span-1 flex items-center justify-center h-full", children: /* @__PURE__ */ t.jsx(Cs, { type: i.type, className: "h-4 w-4" }) }),
            /* @__PURE__ */ t.jsxs("div", { className: "col-span-10 flex flex-col justify-center", children: [
              /* @__PURE__ */ t.jsx("span", { className: "font-medium text-sm", children: i.displayName }),
              i.description && /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground", children: i.description })
            ] }),
            /* @__PURE__ */ t.jsx("div", { className: "col-span-1 flex items-center justify-end", children: /* @__PURE__ */ t.jsx(
              O,
              {
                variant: "ghost",
                size: "icon",
                onClick: () => o(i.displayName),
                disabled: n,
                children: /* @__PURE__ */ t.jsx(Cn, { className: "h-4 w-4" })
              }
            ) })
          ] })
        },
        i.displayName + i.type + l
      )) }) }) }) : /* @__PURE__ */ t.jsx("div", { className: "text-muted-foreground text-sm", children: f("No structured output fields yet.") }),
      /* @__PURE__ */ t.jsx(jg, { disabled: n, onAddField: a })
    ] })
  ] });
}, Ng = 14, ps = 60, bg = (e) => {
  (e.key === "Enter" || e.key === " ") && (e.preventDefault(), e.target && e.target.click());
}, xl = ({
  node: e,
  expanded: n,
  setExpanded: s,
  depth: r
}) => {
  const a = F((b) => b.flowVersion), o = F((b) => b.insertMention), [i, l] = Nu(), c = r === 0 && e.data.type === "value" ? q.getStep(e.data.propertyPath, a.trigger) : r === 0 && e.data.type === "test" ? q.getStep(e.data.stepName, a.trigger) : void 0, u = !!e.children && e.children.length > 0, d = r === 0, h = d && !u, m = !u && e.data.type === "value" && !d, y = e.data.type === "value" && e.data.insertable && !e.isLoopStepNode, v = y, g = e.data.type === "value" && Array.isArray(e.data.value) ? e.data.value : null, j = u && g !== null, x = (b) => {
    if (u) {
      l(b), s(!n);
      return;
    }
    y && o && e.data.type === "value" && (l(b), o(e.data.propertyPath));
  }, N = (m || h) && y, w = N && e.data.type === "value" ? Cg(e.data.value) : "";
  return /* @__PURE__ */ t.jsx(
    "div",
    {
      tabIndex: 0,
      onKeyDown: bg,
      ref: i,
      onClick: x,
      className: $(
        "w-full max-w-full select-none focus:outline-hidden cursor-pointer group transition-colors",
        "hover:bg-accent/60 focus:bg-accent dark:hover:bg-accent/20"
      ),
      "data-depth": r,
      children: /* @__PURE__ */ t.jsxs(
        "div",
        {
          className: $(
            "flex items-center gap-1.5 pr-2 min-w-0",
            d ? "min-h-[40px] py-1.5" : "min-h-[32px]"
          ),
          style: { paddingLeft: r * Ng + 12 },
          children: [
            !d && u && /* @__PURE__ */ t.jsx(
              Hr,
              {
                className: $(
                  "size-3.5 shrink-0 text-muted-foreground transition-transform",
                  n && "rotate-90"
                )
              }
            ),
            !d && !u && /* @__PURE__ */ t.jsx("div", { className: "size-3.5 shrink-0", "aria-hidden": !0 }),
            d && c && /* @__PURE__ */ t.jsx(Sg, { step: c }),
            /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1.5 min-w-0 flex-1", children: [
              e.data.type !== "test" && /* @__PURE__ */ t.jsx(
                "span",
                {
                  className: $(
                    "truncate min-w-0 shrink-0 max-w-[40%]",
                    d ? "font-medium text-foreground text-sm" : "text-foreground text-sm"
                  ),
                  children: e.data.displayName
                }
              ),
              j && /* @__PURE__ */ t.jsx("span", { className: "shrink-0 text-xs text-muted-foreground", children: f("{count, plural, =1 {1 item} other {# items}}", {
                count: (g == null ? void 0 : g.length) ?? 0
              }) }),
              N && w !== "" && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
                /* @__PURE__ */ t.jsx("span", { className: "shrink-0 text-muted-foreground", children: ":" }),
                /* @__PURE__ */ t.jsx(bu, { tooltipMessage: String(w), children: /* @__PURE__ */ t.jsx("span", { className: "min-w-0 truncate text-primary text-sm flex-1", children: w }) })
              ] })
            ] }),
            v && /* @__PURE__ */ t.jsx(
              O,
              {
                variant: "basic",
                size: "sm",
                tabIndex: -1,
                onClick: (b) => {
                  b.stopPropagation(), o && e.data.type === "value" && o(e.data.propertyPath);
                },
                className: $(
                  "h-6 px-2 text-xs text-primary shrink-0 opacity-0 transition-opacity",
                  "group-hover:opacity-100 focus-visible:opacity-100"
                ),
                children: f("Insert")
              }
            ),
            d && u && /* @__PURE__ */ t.jsx(
              Gr,
              {
                className: $(
                  "size-4 shrink-0 text-muted-foreground transition-transform",
                  !n && "-rotate-90"
                )
              }
            )
          ]
        }
      )
    }
  );
}, Sg = ({ step: e }) => {
  const { stepMetadata: n } = En.useStepMetadata({ step: e });
  return n ? /* @__PURE__ */ t.jsx("div", { className: "shrink-0", children: /* @__PURE__ */ t.jsx(
    ci,
    {
      displayName: n.displayName,
      logoUrl: n.logoUrl,
      showTooltip: !1,
      border: !1,
      size: "xs"
    }
  ) }) : null;
}, Cg = (e) => {
  if (e == null) return "—";
  if (typeof e == "string") {
    const s = e.replace(/\s+/g, " ").trim();
    return s.length > ps ? `${s.slice(0, ps)}…` : s;
  }
  if (typeof e == "number" || typeof e == "boolean")
    return String(e);
  const n = JSON.stringify(e);
  return n.length > ps ? `${n.slice(0, ps)}…` : n;
};
xl.displayName = "DataSelectorNodeContent";
const Eg = ({ stepName: e }) => {
  const n = e === "trigger", s = F(
    (r) => r.selectStepByName
  );
  return /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between gap-2 mx-3 my-2 px-3 py-2 rounded-md bg-muted/50 border border-dashed border-border", children: [
    /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground leading-snug", children: n ? f("No sample data yet — load it from the trigger.") : f("No sample data yet — test this step first.") }),
    /* @__PURE__ */ t.jsxs(
      O,
      {
        onClick: () => s(e),
        variant: "ghost",
        size: "sm",
        className: "h-6 px-2 text-xs text-primary hover:text-primary hover:bg-primary/10 shrink-0",
        children: [
          n ? f("Go to trigger") : f("Go to step"),
          /* @__PURE__ */ t.jsx(rm, { className: "size-3" })
        ]
      }
    )
  ] });
}, Tg = 10, go = 32;
function Pg(e, n) {
  return {
    key: n,
    data: {
      type: "value",
      value: "",
      displayName: e,
      propertyPath: n,
      insertable: !1
    },
    children: [
      {
        data: {
          type: "test",
          stepName: n,
          parentDisplayName: e
        },
        key: `test_${n}`
      }
    ]
  };
}
function Dg(e, n) {
  return {
    key: e,
    data: {
      type: "chunk",
      displayName: e
    },
    children: n
  };
}
function vl(e, n) {
  var r, a;
  const s = { ...e };
  for (const [o, i] of Object.entries(n)) {
    const l = vl(
      ((r = s[o]) == null ? void 0 : r.properties) || {},
      i.properties
    );
    s[o] = {
      values: [...((a = s[o]) == null ? void 0 : a.values) || [], ...i.values],
      properties: l
    };
  }
  return s;
}
function Fs(e) {
  var s;
  let n = {};
  if (un(e))
    for (const [r, a] of Object.entries(e)) {
      const o = ((s = n[r]) == null ? void 0 : s.values) || [];
      if (Array.isArray(a)) {
        const l = a.filter(
          (c) => !un(c) && !Array.isArray(c)
        );
        o.push(...l);
      } else un(a) || o.push(a);
      const i = Fs(a);
      n[r] = {
        values: o,
        properties: i
      };
    }
  else if (Array.isArray(e))
    for (const r of e) {
      const a = Fs(r);
      n = vl(n, a);
    }
  return n;
}
function Er(e, n) {
  const s = [];
  for (const [r, a] of Object.entries(e)) {
    const o = n[0], i = [...n.slice(1), r], l = `flattenNestedKeys(${o}, ['${i.map((u) => String(u)).join("', '")}'])`, c = a.values.join(", ");
    s.push({
      key: r,
      data: {
        type: "value",
        value: c.length > go ? `${c.slice(0, go)}...` : c,
        displayName: r,
        propertyPath: l,
        insertable: !0
      },
      children: Object.keys(a.properties).length > 0 ? Er(a.properties, [...n, r]) : void 0
    });
  }
  return s;
}
function Rg(e) {
  return e.slice(1).reduce((s, r) => `${s}[${typeof r == "string" ? `'${Ig(String(r))}'` : r}]`, `${e[0]}`);
}
function en(e, n, s, r, a = !0) {
  const o = Array.isArray(s) && s.length === 0 || un(s) && Object.keys(s).length === 0, i = Rg(n);
  return {
    key: i,
    data: {
      type: "value",
      value: o ? "Empty List" : s,
      displayName: e,
      propertyPath: i,
      insertable: a
    },
    children: r
  };
}
function Og(e, n) {
  return Array.from(
    { length: Math.ceil(e.length / n) },
    (s, r) => ({
      items: e.slice(r * n, r * n + n),
      range: {
        start: r * n + 1,
        end: Math.min((r + 1) * n, e.length)
      }
    })
  );
}
function zs(e, n, s, r, a = !0) {
  if (Array.isArray(s)) {
    const o = s.some((i) => un(i));
    if (!r || !o) {
      const i = s.map(
        (u, d) => zs(
          `${e} [${d + 1}]`,
          [...n, d],
          u,
          r,
          a
        )
      ), l = Og(i, Tg);
      return l.length === 1 ? en(
        e,
        n,
        s,
        i,
        a
      ) : en(
        e,
        n,
        void 0,
        l.map(
          (u) => Dg(
            `${e} [${u.range.start}-${u.range.end}]`,
            u.items
          )
        ),
        a
      );
    } else
      return en(
        e,
        n,
        s,
        Er(Fs(s), n),
        a
      );
  } else if (un(s)) {
    const o = Object.entries(s).map(([i, l]) => r ? en(
      i,
      [...n, i],
      l,
      Er(Fs(l), [
        ...n,
        i
      ]),
      a
    ) : zs(
      i,
      [...n, i],
      l,
      r,
      a
    ));
    return en(
      e,
      n,
      s,
      o,
      a
    );
  } else
    return en(
      e,
      n,
      s,
      void 0,
      a
    );
}
function Ig(e) {
  return e.replaceAll(/[\\"'\n\r\t’]/g, (n) => `\\${n}`);
}
function Ag(e) {
  if (e.data.type === "test")
    return e.data.parentDisplayName;
  if (e.data.type === "chunk")
    return e.data.displayName;
  if (M(e.data.value)) {
    if (e.data.value === null)
      return "null";
  } else return JSON.stringify(e.data.value).toLowerCase();
  return "";
}
function kg(e, n, s) {
  var o;
  const r = `${e.dfsIndex + 1}. ${e.displayName}`;
  if (M((o = e.settings.sampleData) == null ? void 0 : o.lastTestDate) && (e.type !== ee.PIECE || !lt.isManualTrigger({
    pieceName: e.settings.pieceName,
    triggerName: e.settings.triggerName ?? ""
  })))
    return Pg(r, e.name);
  if (e.type === Y.LOOP_ON_ITEMS) {
    const i = JSON.parse(JSON.stringify(n[e.name]));
    delete i.iterations;
    const l = zs(
      r,
      [e.name],
      i,
      s,
      !0
    );
    return l.isLoopStepNode = !0, l;
  }
  return zs(
    r,
    [e.name],
    n[e.name],
    s,
    !0
  );
}
function yl(e, n) {
  return n ? e.map((r) => {
    const a = M(r.children) ? void 0 : yl(r.children, n);
    if (a && a.length)
      return {
        ...r,
        children: a
      };
    const o = Ag(r);
    return (r.data.type === "value" ? r.data.displayName.toLowerCase() : "").toLowerCase().includes(n.toLowerCase()) || o.toLowerCase().includes(n.toLowerCase()) ? r : null;
  }).filter(
    (r) => !M(r)
  ) : e;
}
const aa = {
  isTestStepNode: (e) => e.data.type === "test",
  traverseStep: kg,
  filterBy: yl
}, oa = ({
  node: e,
  depth: n,
  searchTerm: s
}) => {
  const [r, a] = p.useState(n === 0);
  return p.useEffect(() => {
    a(s ? !0 : n === 0);
  }, [s, n]), aa.isTestStepNode(e) ? /* @__PURE__ */ t.jsx(Eg, { stepName: e.data.stepName }) : /* @__PURE__ */ t.jsx(Af, { className: "w-full", open: r, onOpenChange: a, children: /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsx(kf, { asChild: !0, className: "w-full relative", children: /* @__PURE__ */ t.jsx(
      xl,
      {
        node: e,
        expanded: r,
        setExpanded: a,
        depth: n
      }
    ) }),
    /* @__PURE__ */ t.jsx(Mf, { className: "w-full", children: e.children && e.children.length > 0 && /* @__PURE__ */ t.jsx("div", { className: "flex flex-col ", children: e.children.map((i) => /* @__PURE__ */ t.jsx(
      oa,
      {
        depth: n + 1,
        node: i,
        searchTerm: s
      },
      i.key
    )) }) })
  ] }) });
};
oa.displayName = "DataSelectorNode";
var Vn = /* @__PURE__ */ ((e) => (e[e.EXPANDED = 0] = "EXPANDED", e[e.COLLAPSED = 1] = "COLLAPSED", e[e.DOCKED = 2] = "DOCKED", e))(Vn || {});
const Mg = ({
  state: e,
  setListSizeState: n
}) => {
  const s = (a) => {
    n(a);
  }, r = (a) => $("", {
    "text-outline": e === a,
    "text-outline opacity-50": e !== a
  });
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
        O,
        {
          size: "icon",
          className: r(
            0
            /* EXPANDED */
          ),
          onClick: () => s(
            0
            /* EXPANDED */
          ),
          variant: "basic",
          children: /* @__PURE__ */ t.jsx(dm, { className: "size-5" })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Q, { children: f("Expand") })
    ] }),
    /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
        O,
        {
          size: "icon",
          className: r(
            2
            /* DOCKED */
          ),
          onClick: () => s(
            2
            /* DOCKED */
          ),
          variant: "basic",
          children: /* @__PURE__ */ t.jsx(Pm, { className: "size-5" })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Q, { children: f("Dock") })
    ] }),
    /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
        O,
        {
          size: "icon",
          className: r(
            1
            /* COLLAPSED */
          ),
          onClick: () => s(
            1
            /* COLLAPSED */
          ),
          variant: "basic",
          children: /* @__PURE__ */ t.jsx(di, { className: "size-5" })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Q, { children: f("Minimize") })
    ] })
  ] });
}, jl = () => {
  const e = F((v) => v.insertMention), [n, s] = p.useState(""), [r] = Ws(n, 250), [a, o] = p.useState(!1), i = oe.getProjectId(), { checkAccess: l } = Ve(), c = l(Ie.READ_VARIABLE), u = l(Ie.WRITE_VARIABLE), { data: d, isLoading: h, refetch: m } = Su.useVariables({
    request: {
      projectId: i ?? "",
      limit: 50,
      name: r || void 0
    },
    extraKeys: ["data-selector-variables", i ?? "", r],
    enabled: !!i && c
  }), y = (d == null ? void 0 : d.data) ?? [];
  return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-2 h-full", children: [
    /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2 px-5", children: [
      /* @__PURE__ */ t.jsx(
        ui,
        {
          onChange: s,
          value: n,
          placeholder: f("Search variables")
        }
      ),
      u && /* @__PURE__ */ t.jsxs(
        O,
        {
          type: "button",
          size: "sm",
          variant: "outline",
          className: "shrink-0 gap-1.5",
          onClick: () => o(!0),
          children: [
            /* @__PURE__ */ t.jsx(_e, { className: "w-4 h-4" }),
            f("New")
          ]
        }
      )
    ] }),
    /* @__PURE__ */ t.jsxs(Ze, { className: "transition-all flex-1 w-full", children: [
      h && /* @__PURE__ */ t.jsx("div", { className: "text-center text-sm text-muted-foreground py-8", children: f("Loading…") }),
      !h && y.length === 0 && /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-center gap-2 mt-5 flex-col px-6", children: r ? /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
        /* @__PURE__ */ t.jsx(hi, { className: "w-[35px] h-[35px]" }),
        /* @__PURE__ */ t.jsx("div", { className: "text-center font-semibold text-md", children: f("No matching variables") }),
        /* @__PURE__ */ t.jsx("div", { className: "text-center text-sm text-muted-foreground", children: f("Try adjusting your search") })
      ] }) : /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
        /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary", children: /* @__PURE__ */ t.jsx(fr, { className: "w-5 h-5" }) }),
        /* @__PURE__ */ t.jsx("div", { className: "text-center font-semibold text-md", children: f("No variables yet") }),
        /* @__PURE__ */ t.jsx("div", { className: "text-center text-sm text-muted-foreground max-w-[280px]", children: f(
          "Create a variable to reference a value from any step input."
        ) }),
        u && /* @__PURE__ */ t.jsxs(
          O,
          {
            type: "button",
            size: "sm",
            className: "mt-2 gap-1.5",
            onClick: () => o(!0),
            children: [
              /* @__PURE__ */ t.jsx(_e, { className: "w-4 h-4" }),
              f("New variable")
            ]
          }
        )
      ] }) }),
      !h && y.length > 0 && /* @__PURE__ */ t.jsx("div", { className: "flex flex-col", children: y.map((v) => /* @__PURE__ */ t.jsxs(
        "div",
        {
          tabIndex: 0,
          onKeyDown: (g) => {
            (g.key === "Enter" || g.key === " ") && (g.preventDefault(), e && e(`variables['${v.name}']`));
          },
          onClick: () => {
            e && e(`variables['${v.name}']`);
          },
          className: $(
            "group w-full max-w-full select-none focus:outline-hidden",
            "hover:bg-accent dark:hover:bg-accent/20 focus:bg-accent focus:bg-opacity-75",
            "cursor-pointer flex items-center gap-3 px-5 py-3"
          ),
          children: [
            /* @__PURE__ */ t.jsx("div", { className: "shrink-0 flex items-center justify-center w-8 h-8 rounded-md bg-primary/10 text-primary", children: /* @__PURE__ */ t.jsx(fr, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ t.jsx("div", { className: "flex-1 min-w-0", children: /* @__PURE__ */ t.jsx("div", { className: "font-mono text-sm truncate", children: v.name }) })
          ]
        },
        v.id
      )) })
    ] }),
    /* @__PURE__ */ t.jsx(
      _f,
      {
        open: a,
        onOpenChange: o,
        onSaved: () => m()
      }
    )
  ] });
};
jl.displayName = "VariablesTab";
const _g = (e) => {
  const { selectedStep: n, flowVersion: s } = e;
  return !n || !s || !s.trigger ? [] : q.findPathToStep(
    s.trigger,
    n
  ).map((a) => {
    try {
      return aa.traverseStep(
        a,
        e.outputSampleData,
        e.isFocusInsideListMapperModeInput
      );
    } catch (o) {
      return console.error("Failed to traverse step:", o), {
        key: `error-${a.name}`,
        data: {
          type: "chunk",
          displayName: `Error loading ${a.name}`
        }
      };
    }
  });
}, wl = (e) => {
  if (M(e))
    return !1;
  if (e.classList.contains(fi.inputWithMentionsCssClass))
    return !0;
  const n = e.parentElement;
  return n ? n && wl(n) : !1;
}, Nl = ({ parentHeight: e, parentWidth: n }) => {
  const s = p.useRef(null), [r, a] = p.useState(Vn.DOCKED), [o, i] = p.useState(""), l = F(
    _g
  ), c = p.useMemo(
    () => aa.filterBy(l, o),
    [l, o]
  ), [u, d] = p.useState(!1), m = F(
    (v) => v.selectedStep === "trigger"
  ) ? "variables" : "data", y = p.useCallback(() => {
    const v = !M(s.current) && s.current.contains(document.activeElement) || wl(document.activeElement);
    d(v);
  }, []);
  return p.useEffect(() => (document.addEventListener("focusin", y), document.addEventListener("focusout", y), () => {
    document.removeEventListener("focusin", y), document.removeEventListener("focusout", y);
  }), [y]), /* @__PURE__ */ t.jsxs(
    "div",
    {
      ref: s,
      tabIndex: 0,
      className: $(
        "absolute bottom-0 mr-5 mb-5 right-0 z-50 transition-all  border border-solid border-outline overflow-x-hidden bg-background shadow-lg rounded-md",
        {
          "opacity-0 pointer-events-none": !u
        },
        fi.dataSelectorCssClassSelector
      ),
      children: [
        /* @__PURE__ */ t.jsxs("div", { className: "text-lg items-center px-3 py-2 flex gap-2", children: [
          f("Data Selector"),
          " ",
          /* @__PURE__ */ t.jsx("div", { className: "grow" }),
          " ",
          /* @__PURE__ */ t.jsx(
            Mg,
            {
              state: r,
              setListSizeState: a
            }
          )
        ] }),
        /* @__PURE__ */ t.jsx(
          "div",
          {
            style: {
              height: r === Vn.COLLAPSED ? "0px" : r === Vn.DOCKED ? "450px" : `${e - 100}px`,
              width: r !== Vn.EXPANDED ? "450px" : `${n - 40}px`
            },
            className: "transition-all overflow-hidden",
            children: /* @__PURE__ */ t.jsxs(
              qr,
              {
                defaultValue: m,
                className: "h-full flex flex-col gap-0",
                children: [
                  /* @__PURE__ */ t.jsxs(
                    Kr,
                    {
                      variant: "outline",
                      className: "px-3 shrink-0 gap-1 border-b border-border w-full justify-start",
                      children: [
                        /* @__PURE__ */ t.jsxs(
                          wt,
                          {
                            value: "data",
                            variant: "outline",
                            className: "gap-2 px-3 py-2 hover:text-foreground rounded-none",
                            children: [
                              /* @__PURE__ */ t.jsx(Lf, { className: "w-4 h-4" }),
                              f("Data")
                            ]
                          }
                        ),
                        /* @__PURE__ */ t.jsxs(
                          wt,
                          {
                            value: "variables",
                            variant: "outline",
                            className: "gap-2 px-3 py-2 hover:text-foreground rounded-none",
                            children: [
                              /* @__PURE__ */ t.jsx(fr, { className: "w-4 h-4" }),
                              f("Variables")
                            ]
                          }
                        )
                      ]
                    }
                  ),
                  /* @__PURE__ */ t.jsxs(
                    Nt,
                    {
                      value: "data",
                      className: "flex-1 min-h-0 flex flex-col gap-2 mt-2",
                      children: [
                        /* @__PURE__ */ t.jsx("div", { className: "flex items-center gap-2 px-5", children: /* @__PURE__ */ t.jsx(
                          ui,
                          {
                            onChange: (v) => i(v),
                            value: o
                          }
                        ) }),
                        /* @__PURE__ */ t.jsxs(Ze, { className: "transition-all flex-1 w-full ", children: [
                          c && c.map((v) => /* @__PURE__ */ t.jsx(
                            oa,
                            {
                              depth: 0,
                              node: v,
                              searchTerm: o
                            },
                            v.key
                          )),
                          c.length === 0 && /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-center gap-2 mt-5  flex-col", children: [
                            /* @__PURE__ */ t.jsx(hi, { className: "w-[35px] h-[35px]" }),
                            /* @__PURE__ */ t.jsx("div", { className: "text-center font-semibold text-md", children: f("No matching data") }),
                            /* @__PURE__ */ t.jsx("div", { className: "text-center ", children: f("Try adjusting your search") })
                          ] })
                        ] })
                      ]
                    }
                  ),
                  /* @__PURE__ */ t.jsx(Nt, { value: "variables", className: "flex-1 min-h-0 mt-2", children: /* @__PURE__ */ t.jsx(jl, {}) })
                ]
              },
              m
            )
          }
        )
      ]
    }
  );
};
Nl.displayName = "DataSelector";
const bl = 100, Lg = (e, n, s) => ({
  x: n.position.x + e / 2 - W.AP_NODE_SIZE.STEP.width * s / 2,
  y: n.position.y + W.AP_NODE_SIZE.GRAPH_END_WIDGET.height + bl * s
}), Fg = (e, n) => e.y > n.height || e.x > n.width || e.x < 0, zg = (e, n) => ({
  x: e.x > n.width ? -1 * (e.x - n.width + W.AP_NODE_SIZE.STEP.width * 2) : e.x < 0 ? -1 * e.x : 0,
  y: e.y > n.height ? e.y - n.height + W.AP_NODE_SIZE.STEP.height : 0
}), $g = ({
  canvasWidth: e,
  canvasHeight: n,
  hasCanvasBeenInitialised: s,
  selectedStep: r
}) => {
  const { zoomIn: a, zoomOut: o, setViewport: i, getNodes: l, getNode: c, getViewport: u } = Tn(), d = p.useCallback(() => {
    a({
      duration: 0
    });
  }, [a]), h = p.useCallback(() => {
    o({
      duration: 0
    });
  }, [o]), m = p.useCallback(
    (C) => {
      const T = l();
      if (T.length === 0) return;
      const I = _t.calculateGraphBoundingBox({
        nodes: T,
        edges: []
      }).height, P = Math.min(
        Math.max(n / I, 0.9),
        1.25
      );
      i(
        {
          x: e / 2 - W.AP_NODE_SIZE.STEP.width * P / 2,
          y: T[0].position.y + bl * P + W.AP_NODE_SIZE.STEP.height,
          zoom: P
        },
        {
          duration: C ? 0 : 500
        }
      );
    },
    [l, n, i, e]
  );
  p.useEffect(() => {
    s && (m(!0), r && y(r));
  }, [s]);
  const y = (C) => {
    const T = c(C);
    if (!T) return;
    const I = u(), P = {
      height: n / I.zoom,
      width: e / I.zoom
    }, D = Lg(
      e,
      T,
      I.zoom
    );
    if (Fg(D, P)) {
      const A = zg(
        D,
        P
      );
      i({
        x: I.x + A.x,
        y: I.y - A.y - W.AP_NODE_SIZE.STEP.height,
        zoom: I.zoom
      });
    }
  }, [v, g] = F(
    (C) => [C.noteDragOverlayMode, C.setDraggedNote]
  ), [j, x, N, w, b] = F((C) => [
    C.setPanningMode,
    C.panningMode,
    C.showMinimap,
    C.setShowMinimap,
    C.readonly
  ]), E = mr("Space"), R = mr("Shift"), S = (E || x === "grab") && !R;
  return /* @__PURE__ */ t.jsxs(
    "div",
    {
      id: "canvas-controls",
      className: "z-50 absolute bottom-2 left-0 flex items-center  w-full pointer-events-none ",
      children: [
        /* @__PURE__ */ t.jsx("div", { className: " absolute flex ml-2 items-center justify-center p-1.5 pointer-events-auto rounded-lg bg-background border border-sidebar-border", children: /* @__PURE__ */ t.jsx(
          Dt,
          {
            tooltip: f("Minimap" + (pr() ? " (⌘ + M)" : " (Ctrl + M)")),
            children: /* @__PURE__ */ t.jsx(
              O,
              {
                variant: N ? "default" : "ghost",
                size: "icon",
                onClick: () => {
                  w(!N);
                },
                children: /* @__PURE__ */ t.jsx(Sm, { className: "size-4" })
              }
            )
          }
        ) }),
        /* @__PURE__ */ t.jsx("div", { className: "grow" }),
        /* @__PURE__ */ t.jsxs("div", { className: "bg-background gap-2 flex items-center shadow-2xl justify-center border border-sidebar-border p-1.5 rounded-lg pointer-events-auto", children: [
          /* @__PURE__ */ t.jsx(Dt, { tooltip: f("Zoom in"), children: /* @__PURE__ */ t.jsx(O, { variant: "ghost", size: "icon", onClick: d, children: /* @__PURE__ */ t.jsx(_e, { className: "size-4" }) }) }),
          /* @__PURE__ */ t.jsx(Dt, { tooltip: f("Zoom out"), children: /* @__PURE__ */ t.jsx(O, { variant: "ghost", size: "icon", onClick: h, children: /* @__PURE__ */ t.jsx(di, { className: "size-4" }) }) }),
          /* @__PURE__ */ t.jsx(Dt, { tooltip: f("Fit to view"), children: /* @__PURE__ */ t.jsx(
            O,
            {
              variant: "ghost",
              size: "icon",
              onClick: () => m(!1),
              children: /* @__PURE__ */ t.jsx(mm, { className: "size-4" })
            }
          ) }),
          /* @__PURE__ */ t.jsx("div", { children: /* @__PURE__ */ t.jsx(mi, { orientation: "vertical", className: "h-5" }) }),
          /* @__PURE__ */ t.jsx(Dt, { tooltip: f("Grab mode"), children: /* @__PURE__ */ t.jsx(
            O,
            {
              variant: S ? "default" : "ghost",
              size: "icon",
              onClick: () => j("grab"),
              children: /* @__PURE__ */ t.jsx(jm, { className: "size-4" })
            }
          ) }),
          /* @__PURE__ */ t.jsx(Dt, { tooltip: f("Select mode"), children: /* @__PURE__ */ t.jsx(
            O,
            {
              variant: S ? "ghost" : "default",
              size: "icon",
              onClick: () => j("pan"),
              children: /* @__PURE__ */ t.jsx(Em, { className: "size-4" })
            }
          ) }),
          !b && /* @__PURE__ */ t.jsx(Dt, { tooltip: f("Add note"), children: /* @__PURE__ */ t.jsx(
            O,
            {
              variant: v === Ps.CREATE ? "default" : "ghost",
              size: "icon",
              onClick: () => {
                g(
                  {
                    id: "",
                    content: "",
                    createdAt: "",
                    updatedAt: "",
                    position: { x: 0, y: 0 },
                    size: {
                      width: W.NOTE_CREATION_OVERLAY_WIDTH,
                      height: W.NOTE_CREATION_OVERLAY_HEIGHT
                    },
                    color: W.DEFAULT_NOTE_COLOR
                  },
                  Ps.CREATE
                );
              },
              children: /* @__PURE__ */ t.jsx($m, { className: "size-4" })
            }
          ) })
        ] }),
        /* @__PURE__ */ t.jsx("div", { className: "grow" })
      ]
    }
  );
}, Dt = ({
  children: e,
  tooltip: n
}) => /* @__PURE__ */ t.jsxs(te, { children: [
  /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: e }),
  /* @__PURE__ */ t.jsx(Q, { children: n })
] }), Vg = "def.options.0.element", Bg = "shape.", Ug = (e) => e.split(".").map((n) => n === "" ? "" : isNaN(Number(n)) ? `${Bg}${n}` : Vg).join("."), Sl = p.createContext(
  void 0
), Wg = ({
  selectedStep: e,
  pieceModel: n,
  children: s
}) => {
  const [r, a] = p.useState(
    Je({})
  ), o = p.useRef(!1);
  if (!o.current && e) {
    const c = Hn.buildPieceSchema(
      e.type,
      e.settings.actionName ?? e.settings.triggerName,
      n ?? null
    );
    o.current = !0, a(c);
  }
  const i = p.useCallback(
    (c, u) => {
      a((d) => {
        const h = Cu.buildSchema(
          u,
          void 0
        ), m = Object.create(
          Object.getPrototypeOf(d),
          Object.getOwnPropertyDescriptors(d)
        ), y = Ug(c);
        return Eu(m, y, h), m;
      });
    },
    []
  ), l = (c, u, d) => {
    var h, m;
    (m = (h = e.settings) == null ? void 0 : h.propertySettings) != null && m[u] || d.setValue(
      `settings.propertySettings.${u}.type`,
      pi.MANUAL
    ), d.setValue(`settings.propertySettings.${u}.schema`, c);
  };
  return /* @__PURE__ */ t.jsx(
    Sl.Provider,
    {
      value: {
        selectedStep: e,
        pieceModel: n,
        formSchema: r,
        updateFormSchema: i,
        updatePropertySettingsSchema: l
      },
      children: s
    }
  );
}, ia = () => {
  const e = p.useContext(Sl);
  if (e === void 0)
    throw new Error(
      "useStepSettingsContext must be used within a PieceSettingsProvider"
    );
  return e;
};
function St(e, n, { checkForDefaultPrevented: s = !0 } = {}) {
  return function(a) {
    if (e == null || e(a), s === !1 || !a.defaultPrevented)
      return n == null ? void 0 : n(a);
  };
}
function Hg(e, n) {
  typeof e == "function" ? e(n) : e != null && (e.current = n);
}
function Cl(...e) {
  return (n) => e.forEach((s) => Hg(s, n));
}
function Kt(...e) {
  return p.useCallback(Cl(...e), e);
}
function Gg(e, n) {
  const s = p.createContext(n);
  function r(o) {
    const { children: i, ...l } = o, c = p.useMemo(() => l, Object.values(l));
    return /* @__PURE__ */ t.jsx(s.Provider, { value: c, children: i });
  }
  function a(o) {
    const i = p.useContext(s);
    if (i) return i;
    if (n !== void 0) return n;
    throw new Error(`\`${o}\` must be used within \`${e}\``);
  }
  return r.displayName = e + "Provider", [r, a];
}
function qg(e, n = []) {
  let s = [];
  function r(o, i) {
    const l = p.createContext(i), c = s.length;
    s = [...s, i];
    function u(h) {
      const { scope: m, children: y, ...v } = h, g = (m == null ? void 0 : m[e][c]) || l, j = p.useMemo(() => v, Object.values(v));
      return /* @__PURE__ */ t.jsx(g.Provider, { value: j, children: y });
    }
    function d(h, m) {
      const y = (m == null ? void 0 : m[e][c]) || l, v = p.useContext(y);
      if (v) return v;
      if (i !== void 0) return i;
      throw new Error(`\`${h}\` must be used within \`${o}\``);
    }
    return u.displayName = o + "Provider", [u, d];
  }
  const a = () => {
    const o = s.map((i) => p.createContext(i));
    return function(l) {
      const c = (l == null ? void 0 : l[e]) || o;
      return p.useMemo(
        () => ({ [`__scope${e}`]: { ...l, [e]: c } }),
        [l, c]
      );
    };
  };
  return a.scopeName = e, [r, Kg(a, ...n)];
}
function Kg(...e) {
  const n = e[0];
  if (e.length === 1) return n;
  const s = () => {
    const r = e.map((a) => ({
      useScope: a(),
      scopeName: a.scopeName
    }));
    return function(o) {
      const i = r.reduce((l, { useScope: c, scopeName: u }) => {
        const h = c(o)[`__scope${u}`];
        return { ...l, ...h };
      }, {});
      return p.useMemo(() => ({ [`__scope${n.scopeName}`]: i }), [i]);
    };
  };
  return s.scopeName = n.scopeName, s;
}
var $s = globalThis != null && globalThis.document ? p.useLayoutEffect : () => {
}, Yg = Tu.useId || (() => {
}), Xg = 0;
function tr(e) {
  const [n, s] = p.useState(Yg());
  return $s(() => {
    s((r) => r ?? String(Xg++));
  }, [e]), e || (n ? `radix-${n}` : "");
}
function Vt(e) {
  const n = p.useRef(e);
  return p.useEffect(() => {
    n.current = e;
  }), p.useMemo(() => (...s) => {
    var r;
    return (r = n.current) == null ? void 0 : r.call(n, ...s);
  }, []);
}
function Jg({
  prop: e,
  defaultProp: n,
  onChange: s = () => {
  }
}) {
  const [r, a] = Qg({ defaultProp: n, onChange: s }), o = e !== void 0, i = o ? e : r, l = Vt(s), c = p.useCallback(
    (u) => {
      if (o) {
        const h = typeof u == "function" ? u(e) : u;
        h !== e && l(h);
      } else
        a(u);
    },
    [o, e, a, l]
  );
  return [i, c];
}
function Qg({
  defaultProp: e,
  onChange: n
}) {
  const s = p.useState(e), [r] = s, a = p.useRef(r), o = Vt(n);
  return p.useEffect(() => {
    a.current !== r && (o(r), a.current = r);
  }, [r, a, o]), s;
}
var la = p.forwardRef((e, n) => {
  const { children: s, ...r } = e, a = p.Children.toArray(s), o = a.find(ex);
  if (o) {
    const i = o.props.children, l = a.map((c) => c === o ? p.Children.count(i) > 1 ? p.Children.only(null) : p.isValidElement(i) ? i.props.children : null : c);
    return /* @__PURE__ */ t.jsx(Tr, { ...r, ref: n, children: p.isValidElement(i) ? p.cloneElement(i, void 0, l) : null });
  }
  return /* @__PURE__ */ t.jsx(Tr, { ...r, ref: n, children: s });
});
la.displayName = "Slot";
var Tr = p.forwardRef((e, n) => {
  const { children: s, ...r } = e;
  if (p.isValidElement(s)) {
    const a = nx(s);
    return p.cloneElement(s, {
      ...tx(r, s.props),
      // @ts-ignore
      ref: n ? Cl(n, a) : a
    });
  }
  return p.Children.count(s) > 1 ? p.Children.only(null) : null;
});
Tr.displayName = "SlotClone";
var Zg = ({ children: e }) => /* @__PURE__ */ t.jsx(t.Fragment, { children: e });
function ex(e) {
  return p.isValidElement(e) && e.type === Zg;
}
function tx(e, n) {
  const s = { ...n };
  for (const r in n) {
    const a = e[r], o = n[r];
    /^on[A-Z]/.test(r) ? a && o ? s[r] = (...l) => {
      o(...l), a(...l);
    } : a && (s[r] = a) : r === "style" ? s[r] = { ...a, ...o } : r === "className" && (s[r] = [a, o].filter(Boolean).join(" "));
  }
  return { ...e, ...s };
}
function nx(e) {
  var r, a;
  let n = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, s = n && "isReactWarning" in n && n.isReactWarning;
  return s ? e.ref : (n = (a = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : a.get, s = n && "isReactWarning" in n && n.isReactWarning, s ? e.props.ref : e.props.ref || e.ref);
}
var sx = [
  "a",
  "button",
  "div",
  "form",
  "h2",
  "h3",
  "img",
  "input",
  "label",
  "li",
  "nav",
  "ol",
  "p",
  "span",
  "svg",
  "ul"
], gt = sx.reduce((e, n) => {
  const s = p.forwardRef((r, a) => {
    const { asChild: o, ...i } = r, l = o ? la : n;
    return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ t.jsx(l, { ...i, ref: a });
  });
  return s.displayName = `Primitive.${n}`, { ...e, [n]: s };
}, {});
function rx(e, n) {
  e && gi.flushSync(() => e.dispatchEvent(n));
}
function ax(e, n = globalThis == null ? void 0 : globalThis.document) {
  const s = Vt(e);
  p.useEffect(() => {
    const r = (a) => {
      a.key === "Escape" && s(a);
    };
    return n.addEventListener("keydown", r, { capture: !0 }), () => n.removeEventListener("keydown", r, { capture: !0 });
  }, [s, n]);
}
var ox = "DismissableLayer", Pr = "dismissableLayer.update", ix = "dismissableLayer.pointerDownOutside", lx = "dismissableLayer.focusOutside", xo, El = p.createContext({
  layers: /* @__PURE__ */ new Set(),
  layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
  branches: /* @__PURE__ */ new Set()
}), Tl = p.forwardRef(
  (e, n) => {
    const {
      disableOutsidePointerEvents: s = !1,
      onEscapeKeyDown: r,
      onPointerDownOutside: a,
      onFocusOutside: o,
      onInteractOutside: i,
      onDismiss: l,
      ...c
    } = e, u = p.useContext(El), [d, h] = p.useState(null), m = (d == null ? void 0 : d.ownerDocument) ?? (globalThis == null ? void 0 : globalThis.document), [, y] = p.useState({}), v = Kt(n, (S) => h(S)), g = Array.from(u.layers), [j] = [...u.layersWithOutsidePointerEventsDisabled].slice(-1), x = g.indexOf(j), N = d ? g.indexOf(d) : -1, w = u.layersWithOutsidePointerEventsDisabled.size > 0, b = N >= x, E = ux((S) => {
      const C = S.target, T = [...u.branches].some((I) => I.contains(C));
      !b || T || (a == null || a(S), i == null || i(S), S.defaultPrevented || l == null || l());
    }, m), R = hx((S) => {
      const C = S.target;
      [...u.branches].some((I) => I.contains(C)) || (o == null || o(S), i == null || i(S), S.defaultPrevented || l == null || l());
    }, m);
    return ax((S) => {
      N === u.layers.size - 1 && (r == null || r(S), !S.defaultPrevented && l && (S.preventDefault(), l()));
    }, m), p.useEffect(() => {
      if (d)
        return s && (u.layersWithOutsidePointerEventsDisabled.size === 0 && (xo = m.body.style.pointerEvents, m.body.style.pointerEvents = "none"), u.layersWithOutsidePointerEventsDisabled.add(d)), u.layers.add(d), vo(), () => {
          s && u.layersWithOutsidePointerEventsDisabled.size === 1 && (m.body.style.pointerEvents = xo);
        };
    }, [d, m, s, u]), p.useEffect(() => () => {
      d && (u.layers.delete(d), u.layersWithOutsidePointerEventsDisabled.delete(d), vo());
    }, [d, u]), p.useEffect(() => {
      const S = () => y({});
      return document.addEventListener(Pr, S), () => document.removeEventListener(Pr, S);
    }, []), /* @__PURE__ */ t.jsx(
      gt.div,
      {
        ...c,
        ref: v,
        style: {
          pointerEvents: w ? b ? "auto" : "none" : void 0,
          ...e.style
        },
        onFocusCapture: St(e.onFocusCapture, R.onFocusCapture),
        onBlurCapture: St(e.onBlurCapture, R.onBlurCapture),
        onPointerDownCapture: St(
          e.onPointerDownCapture,
          E.onPointerDownCapture
        )
      }
    );
  }
);
Tl.displayName = ox;
var cx = "DismissableLayerBranch", dx = p.forwardRef((e, n) => {
  const s = p.useContext(El), r = p.useRef(null), a = Kt(n, r);
  return p.useEffect(() => {
    const o = r.current;
    if (o)
      return s.branches.add(o), () => {
        s.branches.delete(o);
      };
  }, [s.branches]), /* @__PURE__ */ t.jsx(gt.div, { ...e, ref: a });
});
dx.displayName = cx;
function ux(e, n = globalThis == null ? void 0 : globalThis.document) {
  const s = Vt(e), r = p.useRef(!1), a = p.useRef(() => {
  });
  return p.useEffect(() => {
    const o = (l) => {
      if (l.target && !r.current) {
        let c = function() {
          Pl(
            ix,
            s,
            u,
            { discrete: !0 }
          );
        };
        const u = { originalEvent: l };
        l.pointerType === "touch" ? (n.removeEventListener("click", a.current), a.current = c, n.addEventListener("click", a.current, { once: !0 })) : c();
      } else
        n.removeEventListener("click", a.current);
      r.current = !1;
    }, i = window.setTimeout(() => {
      n.addEventListener("pointerdown", o);
    }, 0);
    return () => {
      window.clearTimeout(i), n.removeEventListener("pointerdown", o), n.removeEventListener("click", a.current);
    };
  }, [n, s]), {
    // ensures we check React component tree (not just DOM tree)
    onPointerDownCapture: () => r.current = !0
  };
}
function hx(e, n = globalThis == null ? void 0 : globalThis.document) {
  const s = Vt(e), r = p.useRef(!1);
  return p.useEffect(() => {
    const a = (o) => {
      o.target && !r.current && Pl(lx, s, { originalEvent: o }, {
        discrete: !1
      });
    };
    return n.addEventListener("focusin", a), () => n.removeEventListener("focusin", a);
  }, [n, s]), {
    onFocusCapture: () => r.current = !0,
    onBlurCapture: () => r.current = !1
  };
}
function vo() {
  const e = new CustomEvent(Pr);
  document.dispatchEvent(e);
}
function Pl(e, n, s, { discrete: r }) {
  const a = s.originalEvent.target, o = new CustomEvent(e, { bubbles: !1, cancelable: !0, detail: s });
  n && a.addEventListener(e, n, { once: !0 }), r ? rx(a, o) : a.dispatchEvent(o);
}
var nr = "focusScope.autoFocusOnMount", sr = "focusScope.autoFocusOnUnmount", yo = { bubbles: !1, cancelable: !0 }, fx = "FocusScope", Dl = p.forwardRef((e, n) => {
  const {
    loop: s = !1,
    trapped: r = !1,
    onMountAutoFocus: a,
    onUnmountAutoFocus: o,
    ...i
  } = e, [l, c] = p.useState(null), u = Vt(a), d = Vt(o), h = p.useRef(null), m = Kt(n, (g) => c(g)), y = p.useRef({
    paused: !1,
    pause() {
      this.paused = !0;
    },
    resume() {
      this.paused = !1;
    }
  }).current;
  p.useEffect(() => {
    if (r) {
      let g = function(w) {
        if (y.paused || !l) return;
        const b = w.target;
        l.contains(b) ? h.current = b : yt(h.current, { select: !0 });
      }, j = function(w) {
        if (y.paused || !l) return;
        const b = w.relatedTarget;
        b !== null && (l.contains(b) || yt(h.current, { select: !0 }));
      }, x = function(w) {
        if (document.activeElement === document.body)
          for (const E of w)
            E.removedNodes.length > 0 && yt(l);
      };
      document.addEventListener("focusin", g), document.addEventListener("focusout", j);
      const N = new MutationObserver(x);
      return l && N.observe(l, { childList: !0, subtree: !0 }), () => {
        document.removeEventListener("focusin", g), document.removeEventListener("focusout", j), N.disconnect();
      };
    }
  }, [r, l, y.paused]), p.useEffect(() => {
    if (l) {
      wo.add(y);
      const g = document.activeElement;
      if (!l.contains(g)) {
        const x = new CustomEvent(nr, yo);
        l.addEventListener(nr, u), l.dispatchEvent(x), x.defaultPrevented || (mx(yx(Rl(l)), { select: !0 }), document.activeElement === g && yt(l));
      }
      return () => {
        l.removeEventListener(nr, u), setTimeout(() => {
          const x = new CustomEvent(sr, yo);
          l.addEventListener(sr, d), l.dispatchEvent(x), x.defaultPrevented || yt(g ?? document.body, { select: !0 }), l.removeEventListener(sr, d), wo.remove(y);
        }, 0);
      };
    }
  }, [l, u, d, y]);
  const v = p.useCallback(
    (g) => {
      if (!s && !r || y.paused) return;
      const j = g.key === "Tab" && !g.altKey && !g.ctrlKey && !g.metaKey, x = document.activeElement;
      if (j && x) {
        const N = g.currentTarget, [w, b] = px(N);
        w && b ? !g.shiftKey && x === b ? (g.preventDefault(), s && yt(w, { select: !0 })) : g.shiftKey && x === w && (g.preventDefault(), s && yt(b, { select: !0 })) : x === N && g.preventDefault();
      }
    },
    [s, r, y.paused]
  );
  return /* @__PURE__ */ t.jsx(gt.div, { tabIndex: -1, ...i, ref: m, onKeyDown: v });
});
Dl.displayName = fx;
function mx(e, { select: n = !1 } = {}) {
  const s = document.activeElement;
  for (const r of e)
    if (yt(r, { select: n }), document.activeElement !== s) return;
}
function px(e) {
  const n = Rl(e), s = jo(n, e), r = jo(n.reverse(), e);
  return [s, r];
}
function Rl(e) {
  const n = [], s = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (r) => {
      const a = r.tagName === "INPUT" && r.type === "hidden";
      return r.disabled || r.hidden || a ? NodeFilter.FILTER_SKIP : r.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  for (; s.nextNode(); ) n.push(s.currentNode);
  return n;
}
function jo(e, n) {
  for (const s of e)
    if (!gx(s, { upTo: n })) return s;
}
function gx(e, { upTo: n }) {
  if (getComputedStyle(e).visibility === "hidden") return !0;
  for (; e; ) {
    if (n !== void 0 && e === n) return !1;
    if (getComputedStyle(e).display === "none") return !0;
    e = e.parentElement;
  }
  return !1;
}
function xx(e) {
  return e instanceof HTMLInputElement && "select" in e;
}
function yt(e, { select: n = !1 } = {}) {
  if (e && e.focus) {
    const s = document.activeElement;
    e.focus({ preventScroll: !0 }), e !== s && xx(e) && n && e.select();
  }
}
var wo = vx();
function vx() {
  let e = [];
  return {
    add(n) {
      const s = e[0];
      n !== s && (s == null || s.pause()), e = No(e, n), e.unshift(n);
    },
    remove(n) {
      var s;
      e = No(e, n), (s = e[0]) == null || s.resume();
    }
  };
}
function No(e, n) {
  const s = [...e], r = s.indexOf(n);
  return r !== -1 && s.splice(r, 1), s;
}
function yx(e) {
  return e.filter((n) => n.tagName !== "A");
}
var jx = "Portal", Ol = p.forwardRef((e, n) => {
  var l;
  const { container: s, ...r } = e, [a, o] = p.useState(!1);
  $s(() => o(!0), []);
  const i = s || a && ((l = globalThis == null ? void 0 : globalThis.document) == null ? void 0 : l.body);
  return i ? Pu.createPortal(/* @__PURE__ */ t.jsx(gt.div, { ...r, ref: n }), i) : null;
});
Ol.displayName = jx;
function wx(e, n) {
  return p.useReducer((s, r) => n[s][r] ?? s, e);
}
var Gs = (e) => {
  const { present: n, children: s } = e, r = Nx(n), a = typeof s == "function" ? s({ present: r.isPresent }) : p.Children.only(s), o = Kt(r.ref, bx(a));
  return typeof s == "function" || r.isPresent ? p.cloneElement(a, { ref: o }) : null;
};
Gs.displayName = "Presence";
function Nx(e) {
  const [n, s] = p.useState(), r = p.useRef({}), a = p.useRef(e), o = p.useRef("none"), i = e ? "mounted" : "unmounted", [l, c] = wx(i, {
    mounted: {
      UNMOUNT: "unmounted",
      ANIMATION_OUT: "unmountSuspended"
    },
    unmountSuspended: {
      MOUNT: "mounted",
      ANIMATION_END: "unmounted"
    },
    unmounted: {
      MOUNT: "mounted"
    }
  });
  return p.useEffect(() => {
    const u = gs(r.current);
    o.current = l === "mounted" ? u : "none";
  }, [l]), $s(() => {
    const u = r.current, d = a.current;
    if (d !== e) {
      const m = o.current, y = gs(u);
      e ? c("MOUNT") : y === "none" || (u == null ? void 0 : u.display) === "none" ? c("UNMOUNT") : c(d && m !== y ? "ANIMATION_OUT" : "UNMOUNT"), a.current = e;
    }
  }, [e, c]), $s(() => {
    if (n) {
      const u = (h) => {
        const y = gs(r.current).includes(h.animationName);
        h.target === n && y && gi.flushSync(() => c("ANIMATION_END"));
      }, d = (h) => {
        h.target === n && (o.current = gs(r.current));
      };
      return n.addEventListener("animationstart", d), n.addEventListener("animationcancel", u), n.addEventListener("animationend", u), () => {
        n.removeEventListener("animationstart", d), n.removeEventListener("animationcancel", u), n.removeEventListener("animationend", u);
      };
    } else
      c("ANIMATION_END");
  }, [n, c]), {
    isPresent: ["mounted", "unmountSuspended"].includes(l),
    ref: p.useCallback((u) => {
      u && (r.current = getComputedStyle(u)), s(u);
    }, [])
  };
}
function gs(e) {
  return (e == null ? void 0 : e.animationName) || "none";
}
function bx(e) {
  var r, a;
  let n = (r = Object.getOwnPropertyDescriptor(e.props, "ref")) == null ? void 0 : r.get, s = n && "isReactWarning" in n && n.isReactWarning;
  return s ? e.ref : (n = (a = Object.getOwnPropertyDescriptor(e, "ref")) == null ? void 0 : a.get, s = n && "isReactWarning" in n && n.isReactWarning, s ? e.props.ref : e.props.ref || e.ref);
}
var rr = 0;
function Sx() {
  p.useEffect(() => {
    const e = document.querySelectorAll("[data-radix-focus-guard]");
    return document.body.insertAdjacentElement("afterbegin", e[0] ?? bo()), document.body.insertAdjacentElement("beforeend", e[1] ?? bo()), rr++, () => {
      rr === 1 && document.querySelectorAll("[data-radix-focus-guard]").forEach((n) => n.remove()), rr--;
    };
  }, []);
}
function bo() {
  const e = document.createElement("span");
  return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.cssText = "outline: none; opacity: 0; position: fixed; pointer-events: none", e;
}
var Il = Du(), ar = function() {
}, qs = p.forwardRef(function(e, n) {
  var s = p.useRef(null), r = p.useState({
    onScrollCapture: ar,
    onWheelCapture: ar,
    onTouchMoveCapture: ar
  }), a = r[0], o = r[1], i = e.forwardProps, l = e.children, c = e.className, u = e.removeScrollBar, d = e.enabled, h = e.shards, m = e.sideCar, y = e.noIsolation, v = e.inert, g = e.allowPinchZoom, j = e.as, x = j === void 0 ? "div" : j, N = e.gapMode, w = Ru(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]), b = m, E = Ou([s, n]), R = rn(rn({}, w), a);
  return p.createElement(
    p.Fragment,
    null,
    d && p.createElement(b, { sideCar: Il, removeScrollBar: u, shards: h, noIsolation: y, inert: v, setCallbacks: o, allowPinchZoom: !!g, lockRef: s, gapMode: N }),
    i ? p.cloneElement(p.Children.only(l), rn(rn({}, R), { ref: E })) : p.createElement(x, rn({}, R, { className: c, ref: E }), l)
  );
});
qs.defaultProps = {
  enabled: !0,
  removeScrollBar: !0,
  inert: !1
};
qs.classNames = {
  fullWidth: Au,
  zeroRight: Iu
};
var Dr = !1;
if (typeof window < "u")
  try {
    var xs = Object.defineProperty({}, "passive", {
      get: function() {
        return Dr = !0, !0;
      }
    });
    window.addEventListener("test", xs, xs), window.removeEventListener("test", xs, xs);
  } catch {
    Dr = !1;
  }
var tn = Dr ? { passive: !1 } : !1, Cx = function(e) {
  return e.tagName === "TEXTAREA";
}, Al = function(e, n) {
  var s = window.getComputedStyle(e);
  return (
    // not-not-scrollable
    s[n] !== "hidden" && // contains scroll inside self
    !(s.overflowY === s.overflowX && !Cx(e) && s[n] === "visible")
  );
}, Ex = function(e) {
  return Al(e, "overflowY");
}, Tx = function(e) {
  return Al(e, "overflowX");
}, So = function(e, n) {
  var s = n.ownerDocument, r = n;
  do {
    typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host);
    var a = kl(e, r);
    if (a) {
      var o = Ml(e, r), i = o[1], l = o[2];
      if (i > l)
        return !0;
    }
    r = r.parentNode;
  } while (r && r !== s.body);
  return !1;
}, Px = function(e) {
  var n = e.scrollTop, s = e.scrollHeight, r = e.clientHeight;
  return [
    n,
    s,
    r
  ];
}, Dx = function(e) {
  var n = e.scrollLeft, s = e.scrollWidth, r = e.clientWidth;
  return [
    n,
    s,
    r
  ];
}, kl = function(e, n) {
  return e === "v" ? Ex(n) : Tx(n);
}, Ml = function(e, n) {
  return e === "v" ? Px(n) : Dx(n);
}, Rx = function(e, n) {
  return e === "h" && n === "rtl" ? -1 : 1;
}, Ox = function(e, n, s, r, a) {
  var o = Rx(e, window.getComputedStyle(n).direction), i = o * r, l = s.target, c = n.contains(l), u = !1, d = i > 0, h = 0, m = 0;
  do {
    var y = Ml(e, l), v = y[0], g = y[1], j = y[2], x = g - j - o * v;
    (v || x) && kl(e, l) && (h += x, m += v), l instanceof ShadowRoot ? l = l.host : l = l.parentNode;
  } while (
    // portaled content
    !c && l !== document.body || // self content
    c && (n.contains(l) || n === l)
  );
  return (d && Math.abs(h) < 1 || !d && Math.abs(m) < 1) && (u = !0), u;
}, vs = function(e) {
  return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, Co = function(e) {
  return [e.deltaX, e.deltaY];
}, Eo = function(e) {
  return e && "current" in e ? e.current : e;
}, Ix = function(e, n) {
  return e[0] === n[0] && e[1] === n[1];
}, Ax = function(e) {
  return `
  .block-interactivity-`.concat(e, ` {pointer-events: none;}
  .allow-interactivity-`).concat(e, ` {pointer-events: all;}
`);
}, kx = 0, nn = [];
function Mx(e) {
  var n = p.useRef([]), s = p.useRef([0, 0]), r = p.useRef(), a = p.useState(kx++)[0], o = p.useState(ku)[0], i = p.useRef(e);
  p.useEffect(function() {
    i.current = e;
  }, [e]), p.useEffect(function() {
    if (e.inert) {
      document.body.classList.add("block-interactivity-".concat(a));
      var g = Mu([e.lockRef.current], (e.shards || []).map(Eo), !0).filter(Boolean);
      return g.forEach(function(j) {
        return j.classList.add("allow-interactivity-".concat(a));
      }), function() {
        document.body.classList.remove("block-interactivity-".concat(a)), g.forEach(function(j) {
          return j.classList.remove("allow-interactivity-".concat(a));
        });
      };
    }
  }, [e.inert, e.lockRef.current, e.shards]);
  var l = p.useCallback(function(g, j) {
    if ("touches" in g && g.touches.length === 2)
      return !i.current.allowPinchZoom;
    var x = vs(g), N = s.current, w = "deltaX" in g ? g.deltaX : N[0] - x[0], b = "deltaY" in g ? g.deltaY : N[1] - x[1], E, R = g.target, S = Math.abs(w) > Math.abs(b) ? "h" : "v";
    if ("touches" in g && S === "h" && R.type === "range")
      return !1;
    var C = So(S, R);
    if (!C)
      return !0;
    if (C ? E = S : (E = S === "v" ? "h" : "v", C = So(S, R)), !C)
      return !1;
    if (!r.current && "changedTouches" in g && (w || b) && (r.current = E), !E)
      return !0;
    var T = r.current || E;
    return Ox(T, j, g, T === "h" ? w : b);
  }, []), c = p.useCallback(function(g) {
    var j = g;
    if (!(!nn.length || nn[nn.length - 1] !== o)) {
      var x = "deltaY" in j ? Co(j) : vs(j), N = n.current.filter(function(E) {
        return E.name === j.type && (E.target === j.target || j.target === E.shadowParent) && Ix(E.delta, x);
      })[0];
      if (N && N.should) {
        j.cancelable && j.preventDefault();
        return;
      }
      if (!N) {
        var w = (i.current.shards || []).map(Eo).filter(Boolean).filter(function(E) {
          return E.contains(j.target);
        }), b = w.length > 0 ? l(j, w[0]) : !i.current.noIsolation;
        b && j.cancelable && j.preventDefault();
      }
    }
  }, []), u = p.useCallback(function(g, j, x, N) {
    var w = { name: g, delta: j, target: x, should: N, shadowParent: _x(x) };
    n.current.push(w), setTimeout(function() {
      n.current = n.current.filter(function(b) {
        return b !== w;
      });
    }, 1);
  }, []), d = p.useCallback(function(g) {
    s.current = vs(g), r.current = void 0;
  }, []), h = p.useCallback(function(g) {
    u(g.type, Co(g), g.target, l(g, e.lockRef.current));
  }, []), m = p.useCallback(function(g) {
    u(g.type, vs(g), g.target, l(g, e.lockRef.current));
  }, []);
  p.useEffect(function() {
    return nn.push(o), e.setCallbacks({
      onScrollCapture: h,
      onWheelCapture: h,
      onTouchMoveCapture: m
    }), document.addEventListener("wheel", c, tn), document.addEventListener("touchmove", c, tn), document.addEventListener("touchstart", d, tn), function() {
      nn = nn.filter(function(g) {
        return g !== o;
      }), document.removeEventListener("wheel", c, tn), document.removeEventListener("touchmove", c, tn), document.removeEventListener("touchstart", d, tn);
    };
  }, []);
  var y = e.removeScrollBar, v = e.inert;
  return p.createElement(
    p.Fragment,
    null,
    v ? p.createElement(o, { styles: Ax(a) }) : null,
    y ? p.createElement(_u, { gapMode: e.gapMode }) : null
  );
}
function _x(e) {
  for (var n = null; e !== null; )
    e instanceof ShadowRoot && (n = e.host, e = e.host), e = e.parentNode;
  return n;
}
const Lx = Lu(Il, Mx);
var _l = p.forwardRef(function(e, n) {
  return p.createElement(qs, rn({}, e, { ref: n, sideCar: Lx }));
});
_l.classNames = qs.classNames;
var ca = "Dialog", [Ll] = qg(ca), [Fx, Be] = Ll(ca), Fl = (e) => {
  const {
    __scopeDialog: n,
    children: s,
    open: r,
    defaultOpen: a,
    onOpenChange: o,
    modal: i = !0
  } = e, l = p.useRef(null), c = p.useRef(null), [u = !1, d] = Jg({
    prop: r,
    defaultProp: a,
    onChange: o
  });
  return /* @__PURE__ */ t.jsx(
    Fx,
    {
      scope: n,
      triggerRef: l,
      contentRef: c,
      contentId: tr(),
      titleId: tr(),
      descriptionId: tr(),
      open: u,
      onOpenChange: d,
      onOpenToggle: p.useCallback(() => d((h) => !h), [d]),
      modal: i,
      children: s
    }
  );
};
Fl.displayName = ca;
var zl = "DialogTrigger", zx = p.forwardRef(
  (e, n) => {
    const { __scopeDialog: s, ...r } = e, a = Be(zl, s), o = Kt(n, a.triggerRef);
    return /* @__PURE__ */ t.jsx(
      gt.button,
      {
        type: "button",
        "aria-haspopup": "dialog",
        "aria-expanded": a.open,
        "aria-controls": a.contentId,
        "data-state": ha(a.open),
        ...r,
        ref: o,
        onClick: St(e.onClick, a.onOpenToggle)
      }
    );
  }
);
zx.displayName = zl;
var da = "DialogPortal", [$x, $l] = Ll(da, {
  forceMount: void 0
}), Vl = (e) => {
  const { __scopeDialog: n, forceMount: s, children: r, container: a } = e, o = Be(da, n);
  return /* @__PURE__ */ t.jsx($x, { scope: n, forceMount: s, children: p.Children.map(r, (i) => /* @__PURE__ */ t.jsx(Gs, { present: s || o.open, children: /* @__PURE__ */ t.jsx(Ol, { asChild: !0, container: a, children: i }) })) });
};
Vl.displayName = da;
var Vs = "DialogOverlay", Bl = p.forwardRef(
  (e, n) => {
    const s = $l(Vs, e.__scopeDialog), { forceMount: r = s.forceMount, ...a } = e, o = Be(Vs, e.__scopeDialog);
    return o.modal ? /* @__PURE__ */ t.jsx(Gs, { present: r || o.open, children: /* @__PURE__ */ t.jsx(Vx, { ...a, ref: n }) }) : null;
  }
);
Bl.displayName = Vs;
var Vx = p.forwardRef(
  (e, n) => {
    const { __scopeDialog: s, ...r } = e, a = Be(Vs, s);
    return (
      // Make sure `Content` is scrollable even when it doesn't live inside `RemoveScroll`
      // ie. when `Overlay` and `Content` are siblings
      /* @__PURE__ */ t.jsx(_l, { as: la, allowPinchZoom: !0, shards: [a.contentRef], children: /* @__PURE__ */ t.jsx(
        gt.div,
        {
          "data-state": ha(a.open),
          ...r,
          ref: n,
          style: { pointerEvents: "auto", ...r.style }
        }
      ) })
    );
  }
), Bt = "DialogContent", Ul = p.forwardRef(
  (e, n) => {
    const s = $l(Bt, e.__scopeDialog), { forceMount: r = s.forceMount, ...a } = e, o = Be(Bt, e.__scopeDialog);
    return /* @__PURE__ */ t.jsx(Gs, { present: r || o.open, children: o.modal ? /* @__PURE__ */ t.jsx(Bx, { ...a, ref: n }) : /* @__PURE__ */ t.jsx(Ux, { ...a, ref: n }) });
  }
);
Ul.displayName = Bt;
var Bx = p.forwardRef(
  (e, n) => {
    const s = Be(Bt, e.__scopeDialog), r = p.useRef(null), a = Kt(n, s.contentRef, r);
    return p.useEffect(() => {
      const o = r.current;
      if (o) return Fu(o);
    }, []), /* @__PURE__ */ t.jsx(
      Wl,
      {
        ...e,
        ref: a,
        trapFocus: s.open,
        disableOutsidePointerEvents: !0,
        onCloseAutoFocus: St(e.onCloseAutoFocus, (o) => {
          var i;
          o.preventDefault(), (i = s.triggerRef.current) == null || i.focus();
        }),
        onPointerDownOutside: St(e.onPointerDownOutside, (o) => {
          const i = o.detail.originalEvent, l = i.button === 0 && i.ctrlKey === !0;
          (i.button === 2 || l) && o.preventDefault();
        }),
        onFocusOutside: St(
          e.onFocusOutside,
          (o) => o.preventDefault()
        )
      }
    );
  }
), Ux = p.forwardRef(
  (e, n) => {
    const s = Be(Bt, e.__scopeDialog), r = p.useRef(!1), a = p.useRef(!1);
    return /* @__PURE__ */ t.jsx(
      Wl,
      {
        ...e,
        ref: n,
        trapFocus: !1,
        disableOutsidePointerEvents: !1,
        onCloseAutoFocus: (o) => {
          var i, l;
          (i = e.onCloseAutoFocus) == null || i.call(e, o), o.defaultPrevented || (r.current || (l = s.triggerRef.current) == null || l.focus(), o.preventDefault()), r.current = !1, a.current = !1;
        },
        onInteractOutside: (o) => {
          var c, u;
          (c = e.onInteractOutside) == null || c.call(e, o), o.defaultPrevented || (r.current = !0, o.detail.originalEvent.type === "pointerdown" && (a.current = !0));
          const i = o.target;
          ((u = s.triggerRef.current) == null ? void 0 : u.contains(i)) && o.preventDefault(), o.detail.originalEvent.type === "focusin" && a.current && o.preventDefault();
        }
      }
    );
  }
), Wl = p.forwardRef(
  (e, n) => {
    const { __scopeDialog: s, trapFocus: r, onOpenAutoFocus: a, onCloseAutoFocus: o, ...i } = e, l = Be(Bt, s), c = p.useRef(null), u = Kt(n, c);
    return Sx(), /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      /* @__PURE__ */ t.jsx(
        Dl,
        {
          asChild: !0,
          loop: !0,
          trapped: r,
          onMountAutoFocus: a,
          onUnmountAutoFocus: o,
          children: /* @__PURE__ */ t.jsx(
            Tl,
            {
              role: "dialog",
              id: l.contentId,
              "aria-describedby": l.descriptionId,
              "aria-labelledby": l.titleId,
              "data-state": ha(l.open),
              ...i,
              ref: u,
              onDismiss: () => l.onOpenChange(!1)
            }
          )
        }
      ),
      /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
        /* @__PURE__ */ t.jsx(Gx, { titleId: l.titleId }),
        /* @__PURE__ */ t.jsx(Kx, { contentRef: c, descriptionId: l.descriptionId })
      ] })
    ] });
  }
), ua = "DialogTitle", Hl = p.forwardRef(
  (e, n) => {
    const { __scopeDialog: s, ...r } = e, a = Be(ua, s);
    return /* @__PURE__ */ t.jsx(gt.h2, { id: a.titleId, ...r, ref: n });
  }
);
Hl.displayName = ua;
var Gl = "DialogDescription", Wx = p.forwardRef(
  (e, n) => {
    const { __scopeDialog: s, ...r } = e, a = Be(Gl, s);
    return /* @__PURE__ */ t.jsx(gt.p, { id: a.descriptionId, ...r, ref: n });
  }
);
Wx.displayName = Gl;
var ql = "DialogClose", Hx = p.forwardRef(
  (e, n) => {
    const { __scopeDialog: s, ...r } = e, a = Be(ql, s);
    return /* @__PURE__ */ t.jsx(
      gt.button,
      {
        type: "button",
        ...r,
        ref: n,
        onClick: St(e.onClick, () => a.onOpenChange(!1))
      }
    );
  }
);
Hx.displayName = ql;
function ha(e) {
  return e ? "open" : "closed";
}
var Kl = "DialogTitleWarning", [Mw, Yl] = Gg(Kl, {
  contentName: Bt,
  titleName: ua,
  docsSlug: "dialog"
}), Gx = ({ titleId: e }) => {
  const n = Yl(Kl), s = `\`${n.contentName}\` requires a \`${n.titleName}\` for the component to be accessible for screen reader users.

If you want to hide the \`${n.titleName}\`, you can wrap it with our VisuallyHidden component.

For more information, see https://radix-ui.com/primitives/docs/components/${n.docsSlug}`;
  return p.useEffect(() => {
    e && (document.getElementById(e) || console.error(s));
  }, [s, e]), null;
}, qx = "DialogDescriptionWarning", Kx = ({ contentRef: e, descriptionId: n }) => {
  const r = `Warning: Missing \`Description\` or \`aria-describedby={undefined}\` for {${Yl(qx).contentName}}.`;
  return p.useEffect(() => {
    var o;
    const a = (o = e.current) == null ? void 0 : o.getAttribute("aria-describedby");
    n && a && (document.getElementById(n) || console.warn(r));
  }, [r, e, n]), null;
}, Yx = Fl, Xx = Vl, Jx = Bl, Qx = Ul, Zx = Hl;
function ev(e) {
  if (typeof document > "u") return;
  let n = document.head || document.getElementsByTagName("head")[0], s = document.createElement("style");
  s.type = "text/css", n.appendChild(s), s.styleSheet ? s.styleSheet.cssText = e : s.appendChild(document.createTextNode(e));
}
const Xl = k.createContext({
  drawerRef: {
    current: null
  },
  overlayRef: {
    current: null
  },
  onPress: () => {
  },
  onRelease: () => {
  },
  onDrag: () => {
  },
  onNestedDrag: () => {
  },
  onNestedOpenChange: () => {
  },
  onNestedRelease: () => {
  },
  openProp: void 0,
  dismissible: !1,
  isOpen: !1,
  isDragging: !1,
  keyboardIsOpen: {
    current: !1
  },
  snapPointsOffset: null,
  snapPoints: null,
  handleOnly: !1,
  modal: !1,
  shouldFade: !1,
  activeSnapPoint: null,
  onOpenChange: () => {
  },
  setActiveSnapPoint: () => {
  },
  closeDrawer: () => {
  },
  direction: "bottom",
  shouldAnimate: {
    current: !0
  },
  shouldScaleBackground: !1,
  setBackgroundColorOnScale: !0,
  noBodyStyles: !1,
  container: null,
  autoFocus: !1
}), is = () => {
  const e = k.useContext(Xl);
  if (!e)
    throw new Error("useDrawerContext must be used within a Drawer.Root");
  return e;
};
ev(`[data-vaul-drawer]{touch-action:none;will-change:transform;transition:transform .5s cubic-bezier(.32, .72, 0, 1);animation-duration:.5s;animation-timing-function:cubic-bezier(0.32,0.72,0,1)}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=bottom][data-state=open]{animation-name:slideFromBottom}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=bottom][data-state=closed]{animation-name:slideToBottom}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=top][data-state=open]{animation-name:slideFromTop}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=top][data-state=closed]{animation-name:slideToTop}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=left][data-state=open]{animation-name:slideFromLeft}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=left][data-state=closed]{animation-name:slideToLeft}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=right][data-state=open]{animation-name:slideFromRight}[data-vaul-drawer][data-vaul-snap-points=false][data-vaul-drawer-direction=right][data-state=closed]{animation-name:slideToRight}[data-vaul-drawer][data-vaul-snap-points=true][data-vaul-drawer-direction=bottom]{transform:translate3d(0,var(--initial-transform,100%),0)}[data-vaul-drawer][data-vaul-snap-points=true][data-vaul-drawer-direction=top]{transform:translate3d(0,calc(var(--initial-transform,100%) * -1),0)}[data-vaul-drawer][data-vaul-snap-points=true][data-vaul-drawer-direction=left]{transform:translate3d(calc(var(--initial-transform,100%) * -1),0,0)}[data-vaul-drawer][data-vaul-snap-points=true][data-vaul-drawer-direction=right]{transform:translate3d(var(--initial-transform,100%),0,0)}[data-vaul-drawer][data-vaul-delayed-snap-points=true][data-vaul-drawer-direction=top]{transform:translate3d(0,var(--snap-point-height,0),0)}[data-vaul-drawer][data-vaul-delayed-snap-points=true][data-vaul-drawer-direction=bottom]{transform:translate3d(0,var(--snap-point-height,0),0)}[data-vaul-drawer][data-vaul-delayed-snap-points=true][data-vaul-drawer-direction=left]{transform:translate3d(var(--snap-point-height,0),0,0)}[data-vaul-drawer][data-vaul-delayed-snap-points=true][data-vaul-drawer-direction=right]{transform:translate3d(var(--snap-point-height,0),0,0)}[data-vaul-overlay][data-vaul-snap-points=false]{animation-duration:.5s;animation-timing-function:cubic-bezier(0.32,0.72,0,1)}[data-vaul-overlay][data-vaul-snap-points=false][data-state=open]{animation-name:fadeIn}[data-vaul-overlay][data-state=closed]{animation-name:fadeOut}[data-vaul-animate=false]{animation:none!important}[data-vaul-overlay][data-vaul-snap-points=true]{opacity:0;transition:opacity .5s cubic-bezier(.32, .72, 0, 1)}[data-vaul-overlay][data-vaul-snap-points=true]{opacity:1}[data-vaul-drawer]:not([data-vaul-custom-container=true])::after{content:'';position:absolute;background:inherit;background-color:inherit}[data-vaul-drawer][data-vaul-drawer-direction=top]::after{top:initial;bottom:100%;left:0;right:0;height:200%}[data-vaul-drawer][data-vaul-drawer-direction=bottom]::after{top:100%;bottom:initial;left:0;right:0;height:200%}[data-vaul-drawer][data-vaul-drawer-direction=left]::after{left:initial;right:100%;top:0;bottom:0;width:200%}[data-vaul-drawer][data-vaul-drawer-direction=right]::after{left:100%;right:initial;top:0;bottom:0;width:200%}[data-vaul-overlay][data-vaul-snap-points=true]:not([data-vaul-snap-points-overlay=true]):not(
[data-state=closed]
){opacity:0}[data-vaul-overlay][data-vaul-snap-points-overlay=true]{opacity:1}[data-vaul-handle]{display:block;position:relative;opacity:.7;background:#e2e2e4;margin-left:auto;margin-right:auto;height:5px;width:32px;border-radius:1rem;touch-action:pan-y}[data-vaul-handle]:active,[data-vaul-handle]:hover{opacity:1}[data-vaul-handle-hitarea]{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);width:max(100%,2.75rem);height:max(100%,2.75rem);touch-action:inherit}@media (hover:hover) and (pointer:fine){[data-vaul-drawer]{user-select:none}}@media (pointer:fine){[data-vaul-handle-hitarea]:{width:100%;height:100%}}@keyframes fadeIn{from{opacity:0}to{opacity:1}}@keyframes fadeOut{to{opacity:0}}@keyframes slideFromBottom{from{transform:translate3d(0,var(--initial-transform,100%),0)}to{transform:translate3d(0,0,0)}}@keyframes slideToBottom{to{transform:translate3d(0,var(--initial-transform,100%),0)}}@keyframes slideFromTop{from{transform:translate3d(0,calc(var(--initial-transform,100%) * -1),0)}to{transform:translate3d(0,0,0)}}@keyframes slideToTop{to{transform:translate3d(0,calc(var(--initial-transform,100%) * -1),0)}}@keyframes slideFromLeft{from{transform:translate3d(calc(var(--initial-transform,100%) * -1),0,0)}to{transform:translate3d(0,0,0)}}@keyframes slideToLeft{to{transform:translate3d(calc(var(--initial-transform,100%) * -1),0,0)}}@keyframes slideFromRight{from{transform:translate3d(var(--initial-transform,100%),0,0)}to{transform:translate3d(0,0,0)}}@keyframes slideToRight{to{transform:translate3d(var(--initial-transform,100%),0,0)}}`);
function tv() {
  const e = navigator.userAgent;
  return typeof window < "u" && (/Firefox/.test(e) && /Mobile/.test(e) || // Android Firefox
  /FxiOS/.test(e));
}
function nv() {
  return fa(/^Mac/);
}
function sv() {
  return fa(/^iPhone/);
}
function To() {
  return /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
}
function rv() {
  return fa(/^iPad/) || // iPadOS 13 lies and says it's a Mac, but we can distinguish by detecting touch support.
  nv() && navigator.maxTouchPoints > 1;
}
function Jl() {
  return sv() || rv();
}
function fa(e) {
  return typeof window < "u" && window.navigator != null ? e.test(window.navigator.platform) : void 0;
}
const av = 24, ov = typeof window < "u" ? p.useLayoutEffect : p.useEffect;
function Po(...e) {
  return (...n) => {
    for (let s of e)
      typeof s == "function" && s(...n);
  };
}
const or = typeof document < "u" && window.visualViewport;
function Do(e) {
  let n = window.getComputedStyle(e);
  return /(auto|scroll)/.test(n.overflow + n.overflowX + n.overflowY);
}
function Ql(e) {
  for (Do(e) && (e = e.parentElement); e && !Do(e); )
    e = e.parentElement;
  return e || document.scrollingElement || document.documentElement;
}
const iv = /* @__PURE__ */ new Set([
  "checkbox",
  "radio",
  "range",
  "color",
  "file",
  "image",
  "button",
  "submit",
  "reset"
]);
let ys = 0, ir;
function lv(e = {}) {
  let { isDisabled: n } = e;
  ov(() => {
    if (!n)
      return ys++, ys === 1 && Jl() && (ir = cv()), () => {
        ys--, ys === 0 && (ir == null || ir());
      };
  }, [
    n
  ]);
}
function cv() {
  let e, n = 0, s = (h) => {
    e = Ql(h.target), !(e === document.documentElement && e === document.body) && (n = h.changedTouches[0].pageY);
  }, r = (h) => {
    if (!e || e === document.documentElement || e === document.body) {
      h.preventDefault();
      return;
    }
    let m = h.changedTouches[0].pageY, y = e.scrollTop, v = e.scrollHeight - e.clientHeight;
    v !== 0 && ((y <= 0 && m > n || y >= v && m < n) && h.preventDefault(), n = m);
  }, a = (h) => {
    let m = h.target;
    Rr(m) && m !== document.activeElement && (h.preventDefault(), m.style.transform = "translateY(-2000px)", m.focus(), requestAnimationFrame(() => {
      m.style.transform = "";
    }));
  }, o = (h) => {
    let m = h.target;
    Rr(m) && (m.style.transform = "translateY(-2000px)", requestAnimationFrame(() => {
      m.style.transform = "", or && (or.height < window.innerHeight ? requestAnimationFrame(() => {
        Ro(m);
      }) : or.addEventListener("resize", () => Ro(m), {
        once: !0
      }));
    }));
  }, i = () => {
    window.scrollTo(0, 0);
  }, l = window.pageXOffset, c = window.pageYOffset, u = Po(dv(document.documentElement, "paddingRight", `${window.innerWidth - document.documentElement.clientWidth}px`));
  window.scrollTo(0, 0);
  let d = Po(Ln(document, "touchstart", s, {
    passive: !1,
    capture: !0
  }), Ln(document, "touchmove", r, {
    passive: !1,
    capture: !0
  }), Ln(document, "touchend", a, {
    passive: !1,
    capture: !0
  }), Ln(document, "focus", o, !0), Ln(window, "scroll", i));
  return () => {
    u(), d(), window.scrollTo(l, c);
  };
}
function dv(e, n, s) {
  let r = e.style[n];
  return e.style[n] = s, () => {
    e.style[n] = r;
  };
}
function Ln(e, n, s, r) {
  return e.addEventListener(n, s, r), () => {
    e.removeEventListener(n, s, r);
  };
}
function Ro(e) {
  let n = document.scrollingElement || document.documentElement;
  for (; e && e !== n; ) {
    let s = Ql(e);
    if (s !== document.documentElement && s !== document.body && s !== e) {
      let r = s.getBoundingClientRect().top, a = e.getBoundingClientRect().top, o = e.getBoundingClientRect().bottom;
      const i = s.getBoundingClientRect().bottom + av;
      o > i && (s.scrollTop += a - r);
    }
    e = s.parentElement;
  }
}
function Rr(e) {
  return e instanceof HTMLInputElement && !iv.has(e.type) || e instanceof HTMLTextAreaElement || e instanceof HTMLElement && e.isContentEditable;
}
function uv(e, n) {
  typeof e == "function" ? e(n) : e != null && (e.current = n);
}
function hv(...e) {
  return (n) => e.forEach((s) => uv(s, n));
}
function Zl(...e) {
  return p.useCallback(hv(...e), e);
}
const ec = /* @__PURE__ */ new WeakMap();
function xe(e, n, s = !1) {
  if (!e || !(e instanceof HTMLElement)) return;
  let r = {};
  Object.entries(n).forEach(([a, o]) => {
    if (a.startsWith("--")) {
      e.style.setProperty(a, o);
      return;
    }
    r[a] = e.style[a], e.style[a] = o;
  }), !s && ec.set(e, r);
}
function fv(e, n) {
  if (!e || !(e instanceof HTMLElement)) return;
  let s = ec.get(e);
  s && (e.style[n] = s[n]);
}
const fe = (e) => {
  switch (e) {
    case "top":
    case "bottom":
      return !0;
    case "left":
    case "right":
      return !1;
    default:
      return e;
  }
};
function js(e, n) {
  if (!e)
    return null;
  const s = window.getComputedStyle(e), r = (
    // @ts-ignore
    s.transform || s.webkitTransform || s.mozTransform
  );
  let a = r.match(/^matrix3d\((.+)\)$/);
  return a ? parseFloat(a[1].split(", ")[fe(n) ? 13 : 12]) : (a = r.match(/^matrix\((.+)\)$/), a ? parseFloat(a[1].split(", ")[fe(n) ? 5 : 4]) : null);
}
function mv(e) {
  return 8 * (Math.log(e + 1) - 2);
}
function lr(e, n) {
  if (!e) return () => {
  };
  const s = e.style.cssText;
  return Object.assign(e.style, n), () => {
    e.style.cssText = s;
  };
}
function pv(...e) {
  return (...n) => {
    for (const s of e)
      typeof s == "function" && s(...n);
  };
}
const re = {
  DURATION: 0.5,
  EASE: [
    0.32,
    0.72,
    0,
    1
  ]
}, tc = 0.4, gv = 0.25, xv = 100, nc = 8, Rt = 16, Or = 26, cr = "vaul-dragging";
function sc(e) {
  const n = k.useRef(e);
  return k.useEffect(() => {
    n.current = e;
  }), k.useMemo(() => (...s) => n.current == null ? void 0 : n.current.call(n, ...s), []);
}
function vv({ defaultProp: e, onChange: n }) {
  const s = k.useState(e), [r] = s, a = k.useRef(r), o = sc(n);
  return k.useEffect(() => {
    a.current !== r && (o(r), a.current = r);
  }, [
    r,
    a,
    o
  ]), s;
}
function rc({ prop: e, defaultProp: n, onChange: s = () => {
} }) {
  const [r, a] = vv({
    defaultProp: n,
    onChange: s
  }), o = e !== void 0, i = o ? e : r, l = sc(s), c = k.useCallback((u) => {
    if (o) {
      const h = typeof u == "function" ? u(e) : u;
      h !== e && l(h);
    } else
      a(u);
  }, [
    o,
    e,
    a,
    l
  ]);
  return [
    i,
    c
  ];
}
function yv({ activeSnapPointProp: e, setActiveSnapPointProp: n, snapPoints: s, drawerRef: r, overlayRef: a, fadeFromIndex: o, onSnapPointChange: i, direction: l = "bottom", container: c, snapToSequentialPoint: u }) {
  const [d, h] = rc({
    prop: e,
    defaultProp: s == null ? void 0 : s[0],
    onChange: n
  }), [m, y] = k.useState(typeof window < "u" ? {
    innerWidth: window.innerWidth,
    innerHeight: window.innerHeight
  } : void 0);
  k.useEffect(() => {
    function S() {
      y({
        innerWidth: window.innerWidth,
        innerHeight: window.innerHeight
      });
    }
    return window.addEventListener("resize", S), () => window.removeEventListener("resize", S);
  }, []);
  const v = k.useMemo(() => d === (s == null ? void 0 : s[s.length - 1]) || null, [
    s,
    d
  ]), g = k.useMemo(() => {
    var S;
    return (S = s == null ? void 0 : s.findIndex((C) => C === d)) != null ? S : null;
  }, [
    s,
    d
  ]), j = s && s.length > 0 && (o || o === 0) && !Number.isNaN(o) && s[o] === d || !s, x = k.useMemo(() => {
    const S = c ? {
      width: c.getBoundingClientRect().width,
      height: c.getBoundingClientRect().height
    } : typeof window < "u" ? {
      width: window.innerWidth,
      height: window.innerHeight
    } : {
      width: 0,
      height: 0
    };
    var C;
    return (C = s == null ? void 0 : s.map((T) => {
      const I = typeof T == "string";
      let P = 0;
      if (I && (P = parseInt(T, 10)), fe(l)) {
        const A = I ? P : m ? T * S.height : 0;
        return m ? l === "bottom" ? S.height - A : -S.height + A : A;
      }
      const D = I ? P : m ? T * S.width : 0;
      return m ? l === "right" ? S.width - D : -S.width + D : D;
    })) != null ? C : [];
  }, [
    s,
    m,
    c
  ]), N = k.useMemo(() => g !== null ? x == null ? void 0 : x[g] : null, [
    x,
    g
  ]), w = k.useCallback((S) => {
    var C;
    const T = (C = x == null ? void 0 : x.findIndex((I) => I === S)) != null ? C : null;
    i(T), xe(r.current, {
      transition: `transform ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`,
      transform: fe(l) ? `translate3d(0, ${S}px, 0)` : `translate3d(${S}px, 0, 0)`
    }), x && T !== x.length - 1 && o !== void 0 && T !== o && T < o ? xe(a.current, {
      transition: `opacity ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`,
      opacity: "0"
    }) : xe(a.current, {
      transition: `opacity ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`,
      opacity: "1"
    }), h(s == null ? void 0 : s[Math.max(T, 0)]);
  }, [
    r.current,
    s,
    x,
    o,
    a,
    h
  ]);
  k.useEffect(() => {
    if (d || e) {
      var S;
      const C = (S = s == null ? void 0 : s.findIndex((T) => T === e || T === d)) != null ? S : -1;
      x && C !== -1 && typeof x[C] == "number" && w(x[C]);
    }
  }, [
    d,
    e,
    s,
    x,
    w
  ]);
  function b({ draggedDistance: S, closeDrawer: C, velocity: T, dismissible: I }) {
    if (o === void 0) return;
    const P = l === "bottom" || l === "right" ? (N ?? 0) - S : (N ?? 0) + S, D = g === o - 1, A = g === 0, _ = S > 0;
    if (D && xe(a.current, {
      transition: `opacity ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`
    }), !u && T > 2 && !_) {
      I ? C() : w(x[0]);
      return;
    }
    if (!u && T > 2 && _ && x && s) {
      w(x[s.length - 1]);
      return;
    }
    const L = x == null ? void 0 : x.reduce((X, ue) => typeof X != "number" || typeof ue != "number" ? X : Math.abs(ue - P) < Math.abs(X - P) ? ue : X), H = fe(l) ? window.innerHeight : window.innerWidth;
    if (T > tc && Math.abs(S) < H * 0.4) {
      const X = _ ? 1 : -1;
      if (X > 0 && v && s) {
        w(x[s.length - 1]);
        return;
      }
      if (A && X < 0 && I && C(), g === null) return;
      w(x[g + X]);
      return;
    }
    w(L);
  }
  function E({ draggedDistance: S }) {
    if (N === null) return;
    const C = l === "bottom" || l === "right" ? N - S : N + S;
    (l === "bottom" || l === "right") && C < x[x.length - 1] || (l === "top" || l === "left") && C > x[x.length - 1] || xe(r.current, {
      transform: fe(l) ? `translate3d(0, ${C}px, 0)` : `translate3d(${C}px, 0, 0)`
    });
  }
  function R(S, C) {
    if (!s || typeof g != "number" || !x || o === void 0) return null;
    const T = g === o - 1;
    if (g >= o && C)
      return 0;
    if (T && !C) return 1;
    if (!j && !T) return null;
    const P = T ? g + 1 : g - 1, D = T ? x[P] - x[P - 1] : x[P + 1] - x[P], A = S / Math.abs(D);
    return T ? 1 - A : A;
  }
  return {
    isLastSnapPoint: v,
    activeSnapPoint: d,
    shouldFade: j,
    getPercentageDragged: R,
    setActiveSnapPoint: h,
    activeSnapPointIndex: g,
    onRelease: b,
    onDrag: E,
    snapPointsOffset: x
  };
}
const jv = () => () => {
};
function wv() {
  const { direction: e, isOpen: n, shouldScaleBackground: s, setBackgroundColorOnScale: r, noBodyStyles: a } = is(), o = k.useRef(null), i = p.useMemo(() => document.body.style.backgroundColor, []);
  function l() {
    return (window.innerWidth - Or) / window.innerWidth;
  }
  k.useEffect(() => {
    if (n && s) {
      o.current && clearTimeout(o.current);
      const c = document.querySelector("[data-vaul-drawer-wrapper]") || document.querySelector("[vaul-drawer-wrapper]");
      if (!c) return;
      pv(r && !a ? lr(document.body, {
        background: "black"
      }) : jv, lr(c, {
        transformOrigin: fe(e) ? "top" : "left",
        transitionProperty: "transform, border-radius",
        transitionDuration: `${re.DURATION}s`,
        transitionTimingFunction: `cubic-bezier(${re.EASE.join(",")})`
      }));
      const u = lr(c, {
        borderRadius: `${nc}px`,
        overflow: "hidden",
        ...fe(e) ? {
          transform: `scale(${l()}) translate3d(0, calc(env(safe-area-inset-top) + 14px), 0)`
        } : {
          transform: `scale(${l()}) translate3d(calc(env(safe-area-inset-top) + 14px), 0, 0)`
        }
      });
      return () => {
        u(), o.current = window.setTimeout(() => {
          i ? document.body.style.background = i : document.body.style.removeProperty("background");
        }, re.DURATION * 1e3);
      };
    }
  }, [
    n,
    s,
    i
  ]);
}
let Fn = null;
function Nv({ isOpen: e, modal: n, nested: s, hasBeenOpened: r, preventScrollRestoration: a, noBodyStyles: o }) {
  const [i, l] = k.useState(() => typeof window < "u" ? window.location.href : ""), c = k.useRef(0), u = k.useCallback(() => {
    if (To() && Fn === null && e && !o) {
      Fn = {
        position: document.body.style.position,
        top: document.body.style.top,
        left: document.body.style.left,
        height: document.body.style.height,
        right: "unset"
      };
      const { scrollX: h, innerHeight: m } = window;
      document.body.style.setProperty("position", "fixed", "important"), Object.assign(document.body.style, {
        top: `${-c.current}px`,
        left: `${-h}px`,
        right: "0px",
        height: "auto"
      }), window.setTimeout(() => window.requestAnimationFrame(() => {
        const y = m - window.innerHeight;
        y && c.current >= m && (document.body.style.top = `${-(c.current + y)}px`);
      }), 300);
    }
  }, [
    e
  ]), d = k.useCallback(() => {
    if (To() && Fn !== null && !o) {
      const h = -parseInt(document.body.style.top, 10), m = -parseInt(document.body.style.left, 10);
      Object.assign(document.body.style, Fn), window.requestAnimationFrame(() => {
        if (a && i !== window.location.href) {
          l(window.location.href);
          return;
        }
        window.scrollTo(m, h);
      }), Fn = null;
    }
  }, [
    i
  ]);
  return k.useEffect(() => {
    function h() {
      c.current = window.scrollY;
    }
    return h(), window.addEventListener("scroll", h), () => {
      window.removeEventListener("scroll", h);
    };
  }, []), k.useEffect(() => {
    if (n)
      return () => {
        typeof document > "u" || document.querySelector("[data-vaul-drawer]") || d();
      };
  }, [
    n,
    d
  ]), k.useEffect(() => {
    s || !r || (e ? (!window.matchMedia("(display-mode: standalone)").matches && u(), n || window.setTimeout(() => {
      d();
    }, 500)) : d());
  }, [
    e,
    r,
    i,
    n,
    s,
    u,
    d
  ]), {
    restorePositionSetting: d
  };
}
function bv({ open: e, onOpenChange: n, children: s, onDrag: r, onRelease: a, snapPoints: o, shouldScaleBackground: i = !1, setBackgroundColorOnScale: l = !0, closeThreshold: c = gv, scrollLockTimeout: u = xv, dismissible: d = !0, handleOnly: h = !1, fadeFromIndex: m = o && o.length - 1, activeSnapPoint: y, setActiveSnapPoint: v, fixed: g, modal: j = !0, onClose: x, nested: N, noBodyStyles: w = !1, direction: b = "bottom", defaultOpen: E = !1, disablePreventScroll: R = !0, snapToSequentialPoint: S = !1, preventScrollRestoration: C = !1, repositionInputs: T = !0, onAnimationEnd: I, container: P, autoFocus: D = !1 }) {
  var A, _;
  const [L = !1, H] = rc({
    defaultProp: E,
    prop: e,
    onChange: (z) => {
      n == null || n(z), !z && !N && Ed(), setTimeout(() => {
        I == null || I(z);
      }, re.DURATION * 1e3), z && !j && typeof window < "u" && window.requestAnimationFrame(() => {
        document.body.style.pointerEvents = "auto";
      }), z || (document.body.style.pointerEvents = "auto");
    }
  }), [X, ue] = k.useState(!1), [Se, G] = k.useState(!1), [Ue, et] = k.useState(!1), ve = k.useRef(null), ge = k.useRef(null), tt = k.useRef(null), he = k.useRef(null), B = k.useRef(null), nt = k.useRef(!1), Jt = k.useRef(null), Xs = k.useRef(0), Qt = k.useRef(!1), Pa = k.useRef(!E), Da = k.useRef(0), U = k.useRef(null), Ra = k.useRef(((A = U.current) == null ? void 0 : A.getBoundingClientRect().height) || 0), Oa = k.useRef(((_ = U.current) == null ? void 0 : _.getBoundingClientRect().width) || 0), Js = k.useRef(0), wd = k.useCallback((z) => {
    o && z === In.length - 1 && (ge.current = /* @__PURE__ */ new Date());
  }, []), { activeSnapPoint: Nd, activeSnapPointIndex: Zt, setActiveSnapPoint: Ia, onRelease: bd, snapPointsOffset: In, onDrag: Sd, shouldFade: Aa, getPercentageDragged: Cd } = yv({
    snapPoints: o,
    activeSnapPointProp: y,
    setActiveSnapPointProp: v,
    drawerRef: U,
    fadeFromIndex: m,
    overlayRef: ve,
    onSnapPointChange: wd,
    direction: b,
    container: P,
    snapToSequentialPoint: S
  });
  lv({
    isDisabled: !L || Se || !j || Ue || !X || !T || !R
  });
  const { restorePositionSetting: Ed } = Nv({
    isOpen: L,
    modal: j,
    nested: N ?? !1,
    hasBeenOpened: X,
    preventScrollRestoration: C,
    noBodyStyles: w
  });
  function cs() {
    return (window.innerWidth - Or) / window.innerWidth;
  }
  function Td(z) {
    var J, se;
    !d && !o || U.current && !U.current.contains(z.target) || (Ra.current = ((J = U.current) == null ? void 0 : J.getBoundingClientRect().height) || 0, Oa.current = ((se = U.current) == null ? void 0 : se.getBoundingClientRect().width) || 0, G(!0), tt.current = /* @__PURE__ */ new Date(), Jl() && window.addEventListener("touchend", () => nt.current = !1, {
      once: !0
    }), z.target.setPointerCapture(z.pointerId), Xs.current = fe(b) ? z.pageY : z.pageX);
  }
  function ka(z, J) {
    var se;
    let K = z;
    const le = (se = window.getSelection()) == null ? void 0 : se.toString(), De = U.current ? js(U.current, b) : null, Ce = /* @__PURE__ */ new Date();
    if (K.tagName === "SELECT" || K.hasAttribute("data-vaul-no-drag") || K.closest("[data-vaul-no-drag]"))
      return !1;
    if (b === "right" || b === "left")
      return !0;
    if (ge.current && Ce.getTime() - ge.current.getTime() < 500)
      return !1;
    if (De !== null && (b === "bottom" ? De > 0 : De < 0))
      return !0;
    if (le && le.length > 0)
      return !1;
    if (B.current && Ce.getTime() - B.current.getTime() < u && De === 0 || J)
      return B.current = Ce, !1;
    for (; K; ) {
      if (K.scrollHeight > K.clientHeight) {
        if (K.scrollTop !== 0)
          return B.current = /* @__PURE__ */ new Date(), !1;
        if (K.getAttribute("role") === "dialog")
          return !0;
      }
      K = K.parentNode;
    }
    return !0;
  }
  function Pd(z) {
    if (U.current && Se) {
      const J = b === "bottom" || b === "right" ? 1 : -1, se = (Xs.current - (fe(b) ? z.pageY : z.pageX)) * J, K = se > 0, le = o && !d && !K;
      if (le && Zt === 0) return;
      const De = Math.abs(se), Ce = document.querySelector("[data-vaul-drawer-wrapper]"), xt = b === "bottom" || b === "top" ? Ra.current : Oa.current;
      let Le = De / xt;
      const Pt = Cd(De, K);
      if (Pt !== null && (Le = Pt), le && Le >= 1 || !nt.current && !ka(z.target, K)) return;
      if (U.current.classList.add(cr), nt.current = !0, xe(U.current, {
        transition: "none"
      }), xe(ve.current, {
        transition: "none"
      }), o && Sd({
        draggedDistance: se
      }), K && !o) {
        const We = mv(se), ds = Math.min(We * -1, 0) * J;
        xe(U.current, {
          transform: fe(b) ? `translate3d(0, ${ds}px, 0)` : `translate3d(${ds}px, 0, 0)`
        });
        return;
      }
      const vt = 1 - Le;
      if ((Aa || m && Zt === m - 1) && (r == null || r(z, Le), xe(ve.current, {
        opacity: `${vt}`,
        transition: "none"
      }, !0)), Ce && ve.current && i) {
        const We = Math.min(cs() + Le * (1 - cs()), 1), ds = 8 - Le * 8, _a = Math.max(0, 14 - Le * 14);
        xe(Ce, {
          borderRadius: `${ds}px`,
          transform: fe(b) ? `scale(${We}) translate3d(0, ${_a}px, 0)` : `scale(${We}) translate3d(${_a}px, 0, 0)`,
          transition: "none"
        }, !0);
      }
      if (!o) {
        const We = De * J;
        xe(U.current, {
          transform: fe(b) ? `translate3d(0, ${We}px, 0)` : `translate3d(${We}px, 0, 0)`
        });
      }
    }
  }
  k.useEffect(() => {
    window.requestAnimationFrame(() => {
      Pa.current = !0;
    });
  }, []), k.useEffect(() => {
    var z;
    function J() {
      if (!U.current || !T) return;
      const se = document.activeElement;
      if (Rr(se) || Qt.current) {
        var K;
        const le = ((K = window.visualViewport) == null ? void 0 : K.height) || 0, De = window.innerHeight;
        let Ce = De - le;
        const xt = U.current.getBoundingClientRect().height || 0, Le = xt > De * 0.8;
        Js.current || (Js.current = xt);
        const Pt = U.current.getBoundingClientRect().top;
        if (Math.abs(Da.current - Ce) > 60 && (Qt.current = !Qt.current), o && o.length > 0 && In && Zt) {
          const vt = In[Zt] || 0;
          Ce += vt;
        }
        if (Da.current = Ce, xt > le || Qt.current) {
          const vt = U.current.getBoundingClientRect().height;
          let We = vt;
          vt > le && (We = le - (Le ? Pt : Or)), g ? U.current.style.height = `${vt - Math.max(Ce, 0)}px` : U.current.style.height = `${Math.max(We, le - Pt)}px`;
        } else tv() || (U.current.style.height = `${Js.current}px`);
        o && o.length > 0 && !Qt.current ? U.current.style.bottom = "0px" : U.current.style.bottom = `${Math.max(Ce, 0)}px`;
      }
    }
    return (z = window.visualViewport) == null || z.addEventListener("resize", J), () => {
      var se;
      return (se = window.visualViewport) == null ? void 0 : se.removeEventListener("resize", J);
    };
  }, [
    Zt,
    o,
    In
  ]);
  function An(z) {
    Dd(), x == null || x(), z || H(!1), setTimeout(() => {
      o && Ia(o[0]);
    }, re.DURATION * 1e3);
  }
  function Ma() {
    if (!U.current) return;
    const z = document.querySelector("[data-vaul-drawer-wrapper]"), J = js(U.current, b);
    xe(U.current, {
      transform: "translate3d(0, 0, 0)",
      transition: `transform ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`
    }), xe(ve.current, {
      transition: `opacity ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`,
      opacity: "1"
    }), i && J && J > 0 && L && xe(z, {
      borderRadius: `${nc}px`,
      overflow: "hidden",
      ...fe(b) ? {
        transform: `scale(${cs()}) translate3d(0, calc(env(safe-area-inset-top) + 14px), 0)`,
        transformOrigin: "top"
      } : {
        transform: `scale(${cs()}) translate3d(calc(env(safe-area-inset-top) + 14px), 0, 0)`,
        transformOrigin: "left"
      },
      transitionProperty: "transform, border-radius",
      transitionDuration: `${re.DURATION}s`,
      transitionTimingFunction: `cubic-bezier(${re.EASE.join(",")})`
    }, !0);
  }
  function Dd() {
    !Se || !U.current || (U.current.classList.remove(cr), nt.current = !1, G(!1), he.current = /* @__PURE__ */ new Date());
  }
  function Rd(z) {
    if (!Se || !U.current) return;
    U.current.classList.remove(cr), nt.current = !1, G(!1), he.current = /* @__PURE__ */ new Date();
    const J = js(U.current, b);
    if (!z || !ka(z.target, !1) || !J || Number.isNaN(J) || tt.current === null) return;
    const se = he.current.getTime() - tt.current.getTime(), K = Xs.current - (fe(b) ? z.pageY : z.pageX), le = Math.abs(K) / se;
    if (le > 0.05 && (et(!0), setTimeout(() => {
      et(!1);
    }, 200)), o) {
      bd({
        draggedDistance: K * (b === "bottom" || b === "right" ? 1 : -1),
        closeDrawer: An,
        velocity: le,
        dismissible: d
      }), a == null || a(z, !0);
      return;
    }
    if (b === "bottom" || b === "right" ? K > 0 : K < 0) {
      Ma(), a == null || a(z, !0);
      return;
    }
    if (le > tc) {
      An(), a == null || a(z, !1);
      return;
    }
    var De;
    const Ce = Math.min((De = U.current.getBoundingClientRect().height) != null ? De : 0, window.innerHeight);
    var xt;
    const Le = Math.min((xt = U.current.getBoundingClientRect().width) != null ? xt : 0, window.innerWidth), Pt = b === "left" || b === "right";
    if (Math.abs(J) >= (Pt ? Le : Ce) * c) {
      An(), a == null || a(z, !1);
      return;
    }
    a == null || a(z, !0), Ma();
  }
  k.useEffect(() => (L && (xe(document.documentElement, {
    scrollBehavior: "auto"
  }), ge.current = /* @__PURE__ */ new Date()), () => {
    fv(document.documentElement, "scrollBehavior");
  }), [
    L
  ]);
  function Od(z) {
    const J = z ? (window.innerWidth - Rt) / window.innerWidth : 1, se = z ? -Rt : 0;
    Jt.current && window.clearTimeout(Jt.current), xe(U.current, {
      transition: `transform ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`,
      transform: fe(b) ? `scale(${J}) translate3d(0, ${se}px, 0)` : `scale(${J}) translate3d(${se}px, 0, 0)`
    }), !z && U.current && (Jt.current = setTimeout(() => {
      const K = js(U.current, b);
      xe(U.current, {
        transition: "none",
        transform: fe(b) ? `translate3d(0, ${K}px, 0)` : `translate3d(${K}px, 0, 0)`
      });
    }, 500));
  }
  function Id(z, J) {
    if (J < 0) return;
    const se = (window.innerWidth - Rt) / window.innerWidth, K = se + J * (1 - se), le = -Rt + J * Rt;
    xe(U.current, {
      transform: fe(b) ? `scale(${K}) translate3d(0, ${le}px, 0)` : `scale(${K}) translate3d(${le}px, 0, 0)`,
      transition: "none"
    });
  }
  function Ad(z, J) {
    const se = fe(b) ? window.innerHeight : window.innerWidth, K = J ? (se - Rt) / se : 1, le = J ? -Rt : 0;
    J && xe(U.current, {
      transition: `transform ${re.DURATION}s cubic-bezier(${re.EASE.join(",")})`,
      transform: fe(b) ? `scale(${K}) translate3d(0, ${le}px, 0)` : `scale(${K}) translate3d(${le}px, 0, 0)`
    });
  }
  return k.useEffect(() => {
    j || window.requestAnimationFrame(() => {
      document.body.style.pointerEvents = "auto";
    });
  }, [
    j
  ]), /* @__PURE__ */ k.createElement(Yx, {
    defaultOpen: E,
    onOpenChange: (z) => {
      !d && !z || (z ? ue(!0) : An(!0), H(z));
    },
    open: L
  }, /* @__PURE__ */ k.createElement(Xl.Provider, {
    value: {
      activeSnapPoint: Nd,
      snapPoints: o,
      setActiveSnapPoint: Ia,
      drawerRef: U,
      overlayRef: ve,
      onOpenChange: n,
      onPress: Td,
      onRelease: Rd,
      onDrag: Pd,
      dismissible: d,
      shouldAnimate: Pa,
      handleOnly: h,
      isOpen: L,
      isDragging: Se,
      shouldFade: Aa,
      closeDrawer: An,
      onNestedDrag: Id,
      onNestedOpenChange: Od,
      onNestedRelease: Ad,
      keyboardIsOpen: Qt,
      modal: j,
      snapPointsOffset: In,
      activeSnapPointIndex: Zt,
      direction: b,
      shouldScaleBackground: i,
      setBackgroundColorOnScale: l,
      noBodyStyles: w,
      container: P,
      autoFocus: D
    }
  }, s));
}
const ac = /* @__PURE__ */ k.forwardRef(function({ ...e }, n) {
  const { overlayRef: s, snapPoints: r, onRelease: a, shouldFade: o, isOpen: i, modal: l, shouldAnimate: c } = is(), u = Zl(n, s), d = r && r.length > 0;
  if (!l)
    return null;
  const h = k.useCallback((m) => a(m), [
    a
  ]);
  return /* @__PURE__ */ k.createElement(Jx, {
    onMouseUp: h,
    ref: u,
    "data-vaul-overlay": "",
    "data-vaul-snap-points": i && d ? "true" : "false",
    "data-vaul-snap-points-overlay": i && o ? "true" : "false",
    "data-vaul-animate": c != null && c.current ? "true" : "false",
    ...e
  });
});
ac.displayName = "Drawer.Overlay";
const oc = /* @__PURE__ */ k.forwardRef(function({ onPointerDownOutside: e, style: n, onOpenAutoFocus: s, ...r }, a) {
  const { drawerRef: o, onPress: i, onRelease: l, onDrag: c, keyboardIsOpen: u, snapPointsOffset: d, activeSnapPointIndex: h, modal: m, isOpen: y, direction: v, snapPoints: g, container: j, handleOnly: x, shouldAnimate: N, autoFocus: w } = is(), [b, E] = k.useState(!1), R = Zl(a, o), S = k.useRef(null), C = k.useRef(null), T = k.useRef(!1), I = g && g.length > 0;
  wv();
  const P = (A, _, L = 0) => {
    if (T.current) return !0;
    const H = Math.abs(A.y), X = Math.abs(A.x), ue = X > H, Se = [
      "bottom",
      "right"
    ].includes(_) ? 1 : -1;
    if (_ === "left" || _ === "right") {
      if (!(A.x * Se < 0) && X >= 0 && X <= L)
        return ue;
    } else if (!(A.y * Se < 0) && H >= 0 && H <= L)
      return !ue;
    return T.current = !0, !0;
  };
  k.useEffect(() => {
    I && window.requestAnimationFrame(() => {
      E(!0);
    });
  }, []);
  function D(A) {
    S.current = null, T.current = !1, l(A);
  }
  return /* @__PURE__ */ k.createElement(Qx, {
    "data-vaul-drawer-direction": v,
    "data-vaul-drawer": "",
    "data-vaul-delayed-snap-points": b ? "true" : "false",
    "data-vaul-snap-points": y && I ? "true" : "false",
    "data-vaul-custom-container": j ? "true" : "false",
    "data-vaul-animate": N != null && N.current ? "true" : "false",
    ...r,
    ref: R,
    style: d && d.length > 0 ? {
      "--snap-point-height": `${d[h ?? 0]}px`,
      ...n
    } : n,
    onPointerDown: (A) => {
      x || (r.onPointerDown == null || r.onPointerDown.call(r, A), S.current = {
        x: A.pageX,
        y: A.pageY
      }, i(A));
    },
    onOpenAutoFocus: (A) => {
      s == null || s(A), w || A.preventDefault();
    },
    onPointerDownOutside: (A) => {
      if (e == null || e(A), !m || A.defaultPrevented) {
        A.preventDefault();
        return;
      }
      u.current && (u.current = !1);
    },
    onFocusOutside: (A) => {
      if (!m) {
        A.preventDefault();
        return;
      }
    },
    onPointerMove: (A) => {
      if (C.current = A, x || (r.onPointerMove == null || r.onPointerMove.call(r, A), !S.current)) return;
      const _ = A.pageY - S.current.y, L = A.pageX - S.current.x, H = A.pointerType === "touch" ? 10 : 2;
      P({
        x: L,
        y: _
      }, v, H) ? c(A) : (Math.abs(L) > H || Math.abs(_) > H) && (S.current = null);
    },
    onPointerUp: (A) => {
      r.onPointerUp == null || r.onPointerUp.call(r, A), S.current = null, T.current = !1, l(A);
    },
    onPointerOut: (A) => {
      r.onPointerOut == null || r.onPointerOut.call(r, A), D(C.current);
    },
    onContextMenu: (A) => {
      r.onContextMenu == null || r.onContextMenu.call(r, A), C.current && D(C.current);
    }
  });
});
oc.displayName = "Drawer.Content";
const Sv = 250, Cv = 120, Ev = /* @__PURE__ */ k.forwardRef(function({ preventCycle: e = !1, children: n, ...s }, r) {
  const { closeDrawer: a, isDragging: o, snapPoints: i, activeSnapPoint: l, setActiveSnapPoint: c, dismissible: u, handleOnly: d, isOpen: h, onPress: m, onDrag: y } = is(), v = k.useRef(null), g = k.useRef(!1);
  function j() {
    if (g.current) {
      w();
      return;
    }
    window.setTimeout(() => {
      x();
    }, Cv);
  }
  function x() {
    if (o || e || g.current) {
      w();
      return;
    }
    if (w(), !i || i.length === 0) {
      u || a();
      return;
    }
    if (l === i[i.length - 1] && u) {
      a();
      return;
    }
    const E = i.findIndex((S) => S === l);
    if (E === -1) return;
    const R = i[E + 1];
    c(R);
  }
  function N() {
    v.current = window.setTimeout(() => {
      g.current = !0;
    }, Sv);
  }
  function w() {
    v.current && window.clearTimeout(v.current), g.current = !1;
  }
  return /* @__PURE__ */ k.createElement("div", {
    onClick: j,
    onPointerCancel: w,
    onPointerDown: (b) => {
      d && m(b), N();
    },
    onPointerMove: (b) => {
      d && y(b);
    },
    // onPointerUp is already handled by the content component
    ref: r,
    "data-vaul-drawer-visible": h ? "true" : "false",
    "data-vaul-handle": "",
    "aria-hidden": "true",
    ...s
  }, /* @__PURE__ */ k.createElement("span", {
    "data-vaul-handle-hitarea": "",
    "aria-hidden": "true"
  }, n));
});
Ev.displayName = "Drawer.Handle";
function Tv(e) {
  const n = is(), { container: s = n.container, ...r } = e;
  return /* @__PURE__ */ k.createElement(Xx, {
    container: s,
    ...r
  });
}
const ls = {
  Root: bv,
  Content: oc,
  Overlay: ac,
  Portal: Tv,
  Title: Zx
};
function Pv({
  onOpenChange: e,
  open: n,
  closeOnEscape: s = !0,
  ...r
}) {
  return p.useEffect(() => {
    if (!n || !e || !s) return;
    const a = (o) => {
      o.key === "Escape" && s && e(!1);
    };
    return window.addEventListener("keydown", a), () => window.removeEventListener("keydown", a);
  }, [n, e, s]), /* @__PURE__ */ t.jsx(
    ls.Root,
    {
      "data-slot": "drawer",
      open: n,
      onOpenChange: e,
      ...r
    }
  );
}
function Dv({
  container: e,
  ...n
}) {
  return /* @__PURE__ */ t.jsx(
    ls.Portal,
    {
      "data-slot": "drawer-portal",
      container: e ?? xi.getPortalContainer(),
      ...n
    }
  );
}
function Rv({
  className: e,
  ...n
}) {
  return /* @__PURE__ */ t.jsx(
    ls.Overlay,
    {
      "data-slot": "drawer-overlay",
      className: $(
        "fixed inset-0 z-50 bg-black/50 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0",
        e
      ),
      ...n
    }
  );
}
function Ov({
  className: e,
  children: n,
  fullscreen: s = !1,
  ...r
}) {
  return /* @__PURE__ */ t.jsxs(Dv, { "data-slot": "drawer-portal", children: [
    /* @__PURE__ */ t.jsx(Rv, {}),
    s && /* @__PURE__ */ t.jsx("style", { children: `
            [data-vaul-drawer][data-vaul-drawer-direction="right"]::after {
              display: none !important;
            }
          ` }),
    /* @__PURE__ */ t.jsxs(
      ls.Content,
      {
        "data-slot": "drawer-content",
        className: $(
          "group/drawer-content bg-background fixed z-50 flex h-auto flex-col shadow-lg outline-hidden select-text",
          "data-[vaul-drawer-direction=top]:inset-x-0 data-[vaul-drawer-direction=top]:top-0 data-[vaul-drawer-direction=top]:mb-24 data-[vaul-drawer-direction=top]:max-h-[80vh] data-[vaul-drawer-direction=top]:rounded-b-lg data-[vaul-drawer-direction=top]:border-b",
          "data-[vaul-drawer-direction=bottom]:inset-x-0 data-[vaul-drawer-direction=bottom]:bottom-0 data-[vaul-drawer-direction=bottom]:mt-24 data-[vaul-drawer-direction=bottom]:max-h-[80vh] data-[vaul-drawer-direction=bottom]:rounded-t-lg data-[vaul-drawer-direction=bottom]:border-t",
          "data-[vaul-drawer-direction=right]:inset-y-0 data-[vaul-drawer-direction=right]:right-0 data-[vaul-drawer-direction=right]:shadow-[-10px_0_10px_-3px_rgba(0,0,0,0.1)]",
          "data-[vaul-drawer-direction=left]:inset-y-0 data-[vaul-drawer-direction=left]:left-0 data-[vaul-drawer-direction=left]:shadow-[10px_0_10px_-3px_rgba(0,0,0,0.1)]",
          s && "w-screen max-w-none",
          e
        ),
        ...r,
        children: [
          !s && /* @__PURE__ */ t.jsx("div", { className: "bg-muted mx-auto mt-4 hidden h-2 w-[100px] shrink-0 rounded-full group-data-[vaul-drawer-direction=bottom]/drawer-content:block" }),
          n
        ]
      }
    )
  ] });
}
function Iv({ className: e, ...n }) {
  return /* @__PURE__ */ t.jsx(
    "div",
    {
      "data-slot": "drawer-header",
      className: $(
        "flex flex-col border border-b gap-0.5 p-0 group-data-[vaul-drawer-direction=bottom]/drawer-content:text-center group-data-[vaul-drawer-direction=top]/drawer-content:text-center md:gap-1.5 md:text-left",
        e
      ),
      ...n
    }
  );
}
function Av({
  className: e,
  ...n
}) {
  return /* @__PURE__ */ t.jsx(
    ls.Title,
    {
      "data-slot": "drawer-title",
      className: $("text-foreground font-semibold", e),
      ...n
    }
  );
}
const kv = () => {
  const [
    e,
    n,
    s,
    r,
    a,
    o,
    i,
    l
  ] = F((h) => [
    h.chatSessionMessages,
    h.chatSessionId,
    h.addChatMessage,
    h.flowVersion,
    h.setChatSessionId,
    h.setRun,
    h.chatDrawerOpenSource,
    h.setChatDrawerOpenSource
  ]), c = vi(), u = p.useRef(!1), d = () => {
    u.current = !0;
    const h = (m) => {
      m.flowVersionId === r.id && m.environment === zu.TESTING && u.current && (o(m, r), u.current = !1, c.off(
        Ua.TEST_FLOW_RUN_STARTED,
        h
      ));
    };
    c.on(Ua.TEST_FLOW_RUN_STARTED, h);
  };
  return /* @__PURE__ */ t.jsx(
    Pv,
    {
      open: i !== null,
      onOpenChange: () => l(null),
      direction: "right",
      dismissible: !1,
      modal: !1,
      children: /* @__PURE__ */ t.jsxs(Ov, { className: "w-[500px] overflow-x-hidden", children: [
        /* @__PURE__ */ t.jsx(Iv, { children: /* @__PURE__ */ t.jsx("div", { className: "p-4", children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1", children: [
          /* @__PURE__ */ t.jsx(
            O,
            {
              variant: "basic",
              size: "icon",
              className: "text-foreground",
              onClick: () => l(null),
              children: /* @__PURE__ */ t.jsx(yi, { className: "h-5 w-5" })
            }
          ),
          /* @__PURE__ */ t.jsx(Av, { children: "Chat" })
        ] }) }) }),
        /* @__PURE__ */ t.jsx("div", { className: "flex-1 overflow-hidden", children: /* @__PURE__ */ t.jsx(
          Ff,
          {
            flowId: r.flowId,
            className: "h-full",
            mode: i,
            showWelcomeMessage: !0,
            onError: () => {
            },
            onSendingMessage: () => {
              i === Yr.TEST_FLOW && d();
            },
            closeChat: () => {
              l(null);
            },
            messages: e,
            chatSessionId: n,
            onAddMessage: s,
            onSetSessionId: a
          }
        ) })
      ] })
    }
  );
};
function Mv(e, n) {
  const s = getComputedStyle(e), r = parseFloat(s.fontSize);
  return n * r;
}
function _v(e, n) {
  const s = getComputedStyle(e.ownerDocument.body), r = parseFloat(s.fontSize);
  return n * r;
}
function Lv(e) {
  return e / 100 * window.innerHeight;
}
function Fv(e) {
  return e / 100 * window.innerWidth;
}
function zv(e) {
  switch (typeof e) {
    case "number":
      return [e, "px"];
    case "string": {
      const n = parseFloat(e);
      return e.endsWith("%") ? [n, "%"] : e.endsWith("px") ? [n, "px"] : e.endsWith("rem") ? [n, "rem"] : e.endsWith("em") ? [n, "em"] : e.endsWith("vh") ? [n, "vh"] : e.endsWith("vw") ? [n, "vw"] : [n, "%"];
    }
  }
}
function ws({
  groupSize: e,
  panelElement: n,
  styleProp: s
}) {
  let r;
  const [a, o] = zv(s);
  switch (o) {
    case "%": {
      r = a / 100 * e;
      break;
    }
    case "px": {
      r = a;
      break;
    }
    case "rem": {
      r = _v(n, a);
      break;
    }
    case "em": {
      r = Mv(n, a);
      break;
    }
    case "vh": {
      r = Lv(a);
      break;
    }
    case "vw": {
      r = Fv(a);
      break;
    }
  }
  return r;
}
function Oe(e) {
  return parseFloat(e.toFixed(3));
}
function bn({
  group: e
}) {
  const { orientation: n, panels: s } = e;
  return s.reduce((r, a) => (r += n === "horizontal" ? a.element.offsetWidth : a.element.offsetHeight, r), 0);
}
function Ir(e) {
  const { panels: n } = e, s = bn({ group: e });
  return s === 0 ? n.map((r) => ({
    groupResizeBehavior: r.panelConstraints.groupResizeBehavior,
    collapsedSize: 0,
    collapsible: r.panelConstraints.collapsible === !0,
    defaultSize: void 0,
    disabled: r.panelConstraints.disabled,
    minSize: 0,
    maxSize: 100,
    panelId: r.id
  })) : n.map((r) => {
    const { element: a, panelConstraints: o } = r;
    let i = 0;
    if (o.collapsedSize !== void 0) {
      const d = ws({
        groupSize: s,
        panelElement: a,
        styleProp: o.collapsedSize
      });
      i = Oe(d / s * 100);
    }
    let l;
    if (o.defaultSize !== void 0) {
      const d = ws({
        groupSize: s,
        panelElement: a,
        styleProp: o.defaultSize
      });
      l = Oe(d / s * 100);
    }
    let c = 0;
    if (o.minSize !== void 0) {
      const d = ws({
        groupSize: s,
        panelElement: a,
        styleProp: o.minSize
      });
      c = Oe(d / s * 100);
    }
    let u = 100;
    if (o.maxSize !== void 0) {
      const d = ws({
        groupSize: s,
        panelElement: a,
        styleProp: o.maxSize
      });
      u = Oe(d / s * 100);
    }
    return {
      groupResizeBehavior: o.groupResizeBehavior,
      collapsedSize: i,
      collapsible: o.collapsible === !0,
      defaultSize: l,
      disabled: o.disabled,
      minSize: c,
      maxSize: u,
      panelId: r.id
    };
  });
}
function Z(e, n = "Assertion error") {
  if (!e)
    throw Error(n);
}
function Ar(e, n) {
  return Array.from(n).sort(
    e === "horizontal" ? $v : Vv
  );
}
function $v(e, n) {
  const s = e.element.offsetLeft - n.element.offsetLeft;
  return s !== 0 ? s : e.element.offsetWidth - n.element.offsetWidth;
}
function Vv(e, n) {
  const s = e.element.offsetTop - n.element.offsetTop;
  return s !== 0 ? s : e.element.offsetHeight - n.element.offsetHeight;
}
function ic(e) {
  return e !== null && typeof e == "object" && "nodeType" in e && e.nodeType === Node.ELEMENT_NODE;
}
function lc(e, n) {
  return {
    x: e.x >= n.left && e.x <= n.right ? 0 : Math.min(
      Math.abs(e.x - n.left),
      Math.abs(e.x - n.right)
    ),
    y: e.y >= n.top && e.y <= n.bottom ? 0 : Math.min(
      Math.abs(e.y - n.top),
      Math.abs(e.y - n.bottom)
    )
  };
}
function Bv({
  orientation: e,
  rects: n,
  targetRect: s
}) {
  const r = {
    x: s.x + s.width / 2,
    y: s.y + s.height / 2
  };
  let a, o = Number.MAX_VALUE;
  for (const i of n) {
    const { x: l, y: c } = lc(r, i), u = e === "horizontal" ? l : c;
    u < o && (o = u, a = i);
  }
  return Z(a, "No rect found"), a;
}
let Ns;
function Uv() {
  return Ns === void 0 && (typeof matchMedia == "function" ? Ns = !!matchMedia("(pointer:coarse)").matches : Ns = !1), Ns;
}
function cc(e) {
  const { element: n, orientation: s, panels: r, separators: a } = e, o = Ar(
    s,
    Array.from(n.children).filter(ic).map((v) => ({ element: v }))
  ).map(({ element: v }) => v), i = [];
  let l = !1, c = !1, u = -1, d = -1, h = 0, m, y = [];
  {
    let v = -1;
    for (const g of o)
      g.hasAttribute("data-panel") && (v++, g.ariaDisabled === null && (h++, u === -1 && (u = v), d = v));
  }
  if (h > 1) {
    let v = -1;
    for (const g of o)
      if (g.hasAttribute("data-panel")) {
        v++;
        const j = r.find(
          (x) => x.element === g
        );
        if (j) {
          if (m) {
            const x = m.element.getBoundingClientRect(), N = g.getBoundingClientRect();
            let w;
            if (c) {
              const b = s === "horizontal" ? new DOMRect(
                x.right,
                x.top,
                0,
                x.height
              ) : new DOMRect(
                x.left,
                x.bottom,
                x.width,
                0
              ), E = s === "horizontal" ? new DOMRect(N.left, N.top, 0, N.height) : new DOMRect(N.left, N.top, N.width, 0);
              switch (y.length) {
                case 0: {
                  w = [
                    b,
                    E
                  ];
                  break;
                }
                case 1: {
                  const R = y[0], S = Bv({
                    orientation: s,
                    rects: [x, N],
                    targetRect: R.element.getBoundingClientRect()
                  });
                  w = [
                    R,
                    S === x ? E : b
                  ];
                  break;
                }
                default: {
                  w = y;
                  break;
                }
              }
            } else
              y.length ? w = y : w = [
                s === "horizontal" ? new DOMRect(
                  x.right,
                  N.top,
                  N.left - x.right,
                  N.height
                ) : new DOMRect(
                  N.left,
                  x.bottom,
                  N.width,
                  N.top - x.bottom
                )
              ];
            for (const b of w) {
              let E = "width" in b ? b : b.element.getBoundingClientRect();
              const R = Uv() ? e.resizeTargetMinimumSize.coarse : e.resizeTargetMinimumSize.fine;
              if (E.width < R) {
                const C = R - E.width;
                E = new DOMRect(
                  E.x - C / 2,
                  E.y,
                  E.width + C,
                  E.height
                );
              }
              if (E.height < R) {
                const C = R - E.height;
                E = new DOMRect(
                  E.x,
                  E.y - C / 2,
                  E.width,
                  E.height + C
                );
              }
              const S = v <= u || v > d;
              !l && !S && i.push({
                group: e,
                groupSize: bn({ group: e }),
                panels: [m, j],
                separator: "width" in b ? void 0 : b,
                rect: E
              }), l = !1;
            }
          }
          c = !1, m = j, y = [];
        }
      } else if (g.hasAttribute("data-separator")) {
        g.ariaDisabled !== null && (l = !0);
        const j = a.find(
          (x) => x.element === g
        );
        j ? y.push(j) : (m = void 0, y = []);
      } else
        c = !0;
  }
  return i;
}
var jt;
class dc {
  constructor() {
    $a(this, jt, {});
  }
  addListener(n, s) {
    const r = kn(this, jt)[n];
    return r === void 0 ? kn(this, jt)[n] = [s] : r.includes(s) || r.push(s), () => {
      this.removeListener(n, s);
    };
  }
  emit(n, s) {
    const r = kn(this, jt)[n];
    if (r !== void 0)
      if (r.length === 1)
        r[0].call(null, s);
      else {
        let a = !1, o = null;
        const i = Array.from(r);
        for (let l = 0; l < i.length; l++) {
          const c = i[l];
          try {
            c.call(null, s);
          } catch (u) {
            o === null && (a = !0, o = u);
          }
        }
        if (a)
          throw o;
      }
  }
  removeAllListeners() {
    Va(this, jt, {});
  }
  removeListener(n, s) {
    const r = kn(this, jt)[n];
    if (r !== void 0) {
      const a = r.indexOf(s);
      a >= 0 && r.splice(a, 1);
    }
  }
}
jt = new WeakMap();
let Ye = /* @__PURE__ */ new Map();
const uc = new dc();
function Wv(e) {
  Ye = new Map(Ye), Ye.delete(e);
}
function Oo(e, n) {
  for (const [s] of Ye)
    if (s.id === e)
      return s;
}
function Ct(e, n) {
  for (const [s, r] of Ye)
    if (s.id === e)
      return r;
  if (n)
    throw Error(`Could not find data for Group with id ${e}`);
}
function Yt() {
  return Ye;
}
function ma(e, n) {
  return uc.addListener("groupChange", (s) => {
    s.group.id === e && n(s);
  });
}
function dt(e, n) {
  const s = Ye.get(e);
  Ye = new Map(Ye), Ye.set(e, n), uc.emit("groupChange", {
    group: e,
    prev: s,
    next: n
  });
}
function Hv(e, n, s) {
  let r, a = {
    x: 1 / 0,
    y: 1 / 0
  };
  for (const o of n) {
    const i = lc(s, o.rect);
    switch (e) {
      case "horizontal": {
        i.x <= a.x && (r = o, a = i);
        break;
      }
      case "vertical": {
        i.y <= a.y && (r = o, a = i);
        break;
      }
    }
  }
  return r ? {
    distance: a,
    hitRegion: r
  } : void 0;
}
function Gv(e) {
  return e !== null && typeof e == "object" && "nodeType" in e && e.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
}
function qv(e, n) {
  if (e === n) throw new Error("Cannot compare node with itself");
  const s = {
    a: ko(e),
    b: ko(n)
  };
  let r;
  for (; s.a.at(-1) === s.b.at(-1); )
    r = s.a.pop(), s.b.pop();
  Z(
    r,
    "Stacking order can only be calculated for elements with a common ancestor"
  );
  const a = {
    a: Ao(Io(s.a)),
    b: Ao(Io(s.b))
  };
  if (a.a === a.b) {
    const o = r.childNodes, i = {
      a: s.a.at(-1),
      b: s.b.at(-1)
    };
    let l = o.length;
    for (; l--; ) {
      const c = o[l];
      if (c === i.a) return 1;
      if (c === i.b) return -1;
    }
  }
  return Math.sign(a.a - a.b);
}
const Kv = /\b(?:position|zIndex|opacity|transform|webkitTransform|mixBlendMode|filter|webkitFilter|isolation)\b/;
function Yv(e) {
  const n = getComputedStyle(hc(e) ?? e).display;
  return n === "flex" || n === "inline-flex";
}
function Xv(e) {
  const n = getComputedStyle(e);
  return !!(n.position === "fixed" || n.zIndex !== "auto" && (n.position !== "static" || Yv(e)) || +n.opacity < 1 || "transform" in n && n.transform !== "none" || "webkitTransform" in n && n.webkitTransform !== "none" || "mixBlendMode" in n && n.mixBlendMode !== "normal" || "filter" in n && n.filter !== "none" || "webkitFilter" in n && n.webkitFilter !== "none" || "isolation" in n && n.isolation === "isolate" || Kv.test(n.willChange) || n.webkitOverflowScrolling === "touch");
}
function Io(e) {
  let n = e.length;
  for (; n--; ) {
    const s = e[n];
    if (Z(s, "Missing node"), Xv(s)) return s;
  }
  return null;
}
function Ao(e) {
  return e && Number(getComputedStyle(e).zIndex) || 0;
}
function ko(e) {
  const n = [];
  for (; e; )
    n.push(e), e = hc(e);
  return n;
}
function hc(e) {
  const { parentNode: n } = e;
  return Gv(n) ? n.host : n;
}
function Jv(e, n) {
  return e.x < n.x + n.width && e.x + e.width > n.x && e.y < n.y + n.height && e.y + e.height > n.y;
}
function Qv({
  groupElement: e,
  hitRegion: n,
  pointerEventTarget: s
}) {
  if (!ic(s) || s.contains(e) || e.contains(s))
    return !0;
  if (qv(s, e) > 0) {
    let r = s;
    for (; r; ) {
      if (r.contains(e))
        return !0;
      if (Jv(r.getBoundingClientRect(), n))
        return !1;
      r = r.parentElement;
    }
  }
  return !0;
}
function pa(e, n) {
  const s = [];
  return n.forEach((r, a) => {
    if (a.disabled)
      return;
    const o = cc(a), i = Hv(a.orientation, o, {
      x: e.clientX,
      y: e.clientY
    });
    i && i.distance.x <= 0 && i.distance.y <= 0 && Qv({
      groupElement: a.element,
      hitRegion: i.hitRegion.rect,
      pointerEventTarget: e.target
    }) && s.push(i.hitRegion);
  }), s;
}
function Zv(e, n) {
  if (e.length !== n.length)
    return !1;
  for (let s = 0; s < e.length; s++)
    if (e[s] != n[s])
      return !1;
  return !0;
}
function Ee(e, n, s = 0) {
  return Math.abs(Oe(e) - Oe(n)) <= s;
}
function qe(e, n) {
  return Ee(e, n) ? 0 : e > n ? 1 : -1;
}
function ln({
  overrideDisabledPanels: e,
  panelConstraints: n,
  prevSize: s,
  size: r
}) {
  const {
    collapsedSize: a = 0,
    collapsible: o,
    disabled: i,
    maxSize: l = 100,
    minSize: c = 0
  } = n;
  if (i && !e)
    return s;
  if (qe(r, c) < 0)
    if (o) {
      const u = (a + c) / 2;
      qe(r, u) < 0 ? r = a : r = c;
    } else
      r = c;
  return r = Math.min(l, r), r = Oe(r), r;
}
function Kn({
  delta: e,
  initialLayout: n,
  panelConstraints: s,
  pivotIndices: r,
  prevLayout: a,
  trigger: o
}) {
  if (Ee(e, 0))
    return n;
  const i = o === "imperative-api", l = Object.values(n), c = Object.values(a), u = [...l], [d, h] = r;
  Z(d != null, "Invalid first pivot index"), Z(h != null, "Invalid second pivot index");
  let m = 0;
  switch (o) {
    case "keyboard": {
      {
        const g = e < 0 ? h : d, j = s[g];
        Z(
          j,
          `Panel constraints not found for index ${g}`
        );
        const {
          collapsedSize: x = 0,
          collapsible: N,
          minSize: w = 0
        } = j;
        if (N) {
          const b = l[g];
          if (Z(
            b != null,
            `Previous layout not found for panel index ${g}`
          ), Ee(b, x)) {
            const E = w - b;
            qe(E, Math.abs(e)) > 0 && (e = e < 0 ? 0 - E : E);
          }
        }
      }
      {
        const g = e < 0 ? d : h, j = s[g];
        Z(
          j,
          `No panel constraints found for index ${g}`
        );
        const {
          collapsedSize: x = 0,
          collapsible: N,
          minSize: w = 0
        } = j;
        if (N) {
          const b = l[g];
          if (Z(
            b != null,
            `Previous layout not found for panel index ${g}`
          ), Ee(b, w)) {
            const E = b - x;
            qe(E, Math.abs(e)) > 0 && (e = e < 0 ? 0 - E : E);
          }
        }
      }
      break;
    }
    default: {
      const g = e < 0 ? h : d, j = s[g];
      Z(
        j,
        `Panel constraints not found for index ${g}`
      );
      const x = l[g], { collapsible: N, collapsedSize: w, minSize: b } = j;
      if (N && qe(x, b) < 0)
        if (e > 0) {
          const E = b - w, R = E / 2, S = x + e;
          qe(S, b) < 0 && (e = qe(e, R) <= 0 ? 0 : E);
        } else {
          const E = b - w, R = 100 - E / 2, S = x - e;
          qe(S, b) < 0 && (e = qe(100 + e, R) > 0 ? 0 : -E);
        }
      break;
    }
  }
  {
    const g = e < 0 ? 1 : -1;
    let j = e < 0 ? h : d, x = 0;
    for (; ; ) {
      const w = l[j];
      Z(
        w != null,
        `Previous layout not found for panel index ${j}`
      );
      const b = ln({
        overrideDisabledPanels: i,
        panelConstraints: s[j],
        prevSize: w,
        size: 100
      }) - w;
      if (x += b, j += g, j < 0 || j >= s.length)
        break;
    }
    const N = Math.min(Math.abs(e), Math.abs(x));
    e = e < 0 ? 0 - N : N;
  }
  {
    let g = e < 0 ? d : h;
    for (; g >= 0 && g < s.length; ) {
      const j = Math.abs(e) - Math.abs(m), x = l[g];
      Z(
        x != null,
        `Previous layout not found for panel index ${g}`
      );
      const N = x - j, w = ln({
        overrideDisabledPanels: i,
        panelConstraints: s[g],
        prevSize: x,
        size: N
      });
      if (!Ee(x, w) && (m += x - w, u[g] = w, m.toFixed(3).localeCompare(Math.abs(e).toFixed(3), void 0, {
        numeric: !0
      }) >= 0))
        break;
      e < 0 ? g-- : g++;
    }
  }
  if (Zv(c, u))
    return a;
  {
    const g = e < 0 ? h : d, j = l[g];
    Z(
      j != null,
      `Previous layout not found for panel index ${g}`
    );
    const x = j + m, N = ln({
      overrideDisabledPanels: i,
      panelConstraints: s[g],
      prevSize: j,
      size: x
    });
    if (u[g] = N, !Ee(N, x)) {
      let w = x - N, b = e < 0 ? h : d;
      for (; b >= 0 && b < s.length; ) {
        const E = u[b];
        Z(
          E != null,
          `Previous layout not found for panel index ${b}`
        );
        const R = E + w, S = ln({
          overrideDisabledPanels: i,
          panelConstraints: s[b],
          prevSize: E,
          size: R
        });
        if (Ee(E, S) || (w -= S - E, u[b] = S), Ee(w, 0))
          break;
        e > 0 ? b-- : b++;
      }
    }
  }
  const y = Object.values(u).reduce(
    (g, j) => j + g,
    0
  );
  if (!Ee(y, 100, 0.1))
    return a;
  const v = Object.keys(a);
  return u.reduce((g, j, x) => (g[v[x]] = j, g), {});
}
function Ut(e, n) {
  if (Object.keys(e).length !== Object.keys(n).length)
    return !1;
  for (const s in e)
    if (n[s] === void 0 || qe(e[s], n[s]) !== 0)
      return !1;
  return !0;
}
function Wt({
  layout: e,
  panelConstraints: n
}) {
  const s = Object.values(e), r = [...s], a = r.reduce(
    (l, c) => l + c,
    0
  );
  if (r.length !== n.length)
    throw Error(
      `Invalid ${n.length} panel layout: ${r.map((l) => `${l}%`).join(", ")}`
    );
  if (!Ee(a, 100) && r.length > 0)
    for (let l = 0; l < n.length; l++) {
      const c = r[l];
      Z(c != null, `No layout data found for index ${l}`);
      const u = 100 / a * c;
      r[l] = u;
    }
  let o = 0;
  for (let l = 0; l < n.length; l++) {
    const c = s[l];
    Z(c != null, `No layout data found for index ${l}`);
    const u = r[l];
    Z(u != null, `No layout data found for index ${l}`);
    const d = ln({
      overrideDisabledPanels: !0,
      panelConstraints: n[l],
      prevSize: c,
      size: u
    });
    u != d && (o += u - d, r[l] = d);
  }
  if (!Ee(o, 0))
    for (let l = 0; l < n.length; l++) {
      const c = r[l];
      Z(c != null, `No layout data found for index ${l}`);
      const u = c + o, d = ln({
        overrideDisabledPanels: !0,
        panelConstraints: n[l],
        prevSize: c,
        size: u
      });
      if (c !== d && (o -= d - c, r[l] = d, Ee(o, 0)))
        break;
    }
  const i = Object.keys(e);
  return r.reduce((l, c, u) => (l[i[u]] = c, l), {});
}
function fc({
  groupId: e,
  panelId: n
}) {
  const s = () => {
    const l = Yt();
    for (const [
      c,
      {
        defaultLayoutDeferred: u,
        derivedPanelConstraints: d,
        layout: h,
        groupSize: m,
        separatorToPanels: y
      }
    ] of l)
      if (c.id === e)
        return {
          defaultLayoutDeferred: u,
          derivedPanelConstraints: d,
          group: c,
          groupSize: m,
          layout: h,
          separatorToPanels: y
        };
    throw Error(`Group ${e} not found`);
  }, r = () => {
    const l = s().derivedPanelConstraints.find(
      (c) => c.panelId === n
    );
    if (l !== void 0)
      return l;
    throw Error(`Panel constraints not found for Panel ${n}`);
  }, a = () => {
    const l = s().group.panels.find((c) => c.id === n);
    if (l !== void 0)
      return l;
    throw Error(`Layout not found for Panel ${n}`);
  }, o = () => {
    const l = s().layout[n];
    if (l !== void 0)
      return l;
    throw Error(`Layout not found for Panel ${n}`);
  }, i = (l) => {
    const c = o();
    if (l === c)
      return;
    const {
      defaultLayoutDeferred: u,
      derivedPanelConstraints: d,
      group: h,
      groupSize: m,
      layout: y,
      separatorToPanels: v
    } = s(), g = h.panels.findIndex((w) => w.id === n), j = g === h.panels.length - 1, x = Kn({
      delta: j ? c - l : l - c,
      initialLayout: y,
      panelConstraints: d,
      pivotIndices: j ? [g - 1, g] : [g, g + 1],
      prevLayout: y,
      trigger: "imperative-api"
    }), N = Wt({
      layout: x,
      panelConstraints: d
    });
    Ut(y, N) || dt(h, {
      defaultLayoutDeferred: u,
      derivedPanelConstraints: d,
      groupSize: m,
      layout: N,
      separatorToPanels: v
    });
  };
  return {
    collapse: () => {
      const { collapsible: l, collapsedSize: c } = r(), { mutableValues: u } = a(), d = o();
      l && d !== c && (u.expandToSize = d, i(c));
    },
    expand: () => {
      const { collapsible: l, collapsedSize: c, minSize: u } = r(), { mutableValues: d } = a(), h = o();
      if (l && h === c) {
        let m = d.expandToSize ?? u;
        m === 0 && (m = 1), i(m);
      }
    },
    getSize: () => {
      const { group: l } = s(), c = o(), { element: u } = a(), d = l.orientation === "horizontal" ? u.offsetWidth : u.offsetHeight;
      return {
        asPercentage: c,
        inPixels: d
      };
    },
    isCollapsed: () => {
      const { collapsible: l, collapsedSize: c } = r(), u = o();
      return l && Ee(c, u);
    },
    resize: (l) => {
      if (o() !== l) {
        let c;
        switch (typeof l) {
          case "number": {
            const { group: u } = s(), d = bn({ group: u });
            c = Oe(l / d * 100);
            break;
          }
          case "string": {
            c = parseFloat(l);
            break;
          }
        }
        i(c);
      }
    }
  };
}
function Mo(e) {
  if (e.defaultPrevented)
    return;
  const n = Yt();
  pa(e, n).forEach((s) => {
    if (s.separator) {
      const r = s.panels.find(
        (a) => a.panelConstraints.defaultSize !== void 0
      );
      if (r) {
        const a = r.panelConstraints.defaultSize, o = fc({
          groupId: s.group.id,
          panelId: r.id
        });
        o && a !== void 0 && (o.resize(a), e.preventDefault());
      }
    }
  });
}
function Es(e) {
  const n = Yt();
  for (const [s] of n)
    if (s.separators.some(
      (r) => r.element === e
    ))
      return s;
  throw Error("Could not find parent Group for separator element");
}
function mc({
  groupId: e
}) {
  const n = () => {
    const s = Yt();
    for (const [r, a] of s)
      if (r.id === e)
        return { group: r, ...a };
    throw Error(`Could not find Group with id "${e}"`);
  };
  return {
    getLayout() {
      const { defaultLayoutDeferred: s, layout: r } = n();
      return s ? {} : r;
    },
    setLayout(s) {
      const {
        defaultLayoutDeferred: r,
        derivedPanelConstraints: a,
        group: o,
        groupSize: i,
        layout: l,
        separatorToPanels: c
      } = n(), u = Wt({
        layout: s,
        panelConstraints: a
      });
      return r ? l : (Ut(l, u) || dt(o, {
        defaultLayoutDeferred: r,
        derivedPanelConstraints: a,
        groupSize: i,
        layout: u,
        separatorToPanels: c
      }), u);
    }
  };
}
function Ot(e, n) {
  const s = Es(e), r = Ct(s.id, !0), a = s.separators.find(
    (d) => d.element === e
  );
  Z(a, "Matching separator not found");
  const o = r.separatorToPanels.get(a);
  Z(o, "Matching panels not found");
  const i = o.map((d) => s.panels.indexOf(d)), l = mc({ groupId: s.id }).getLayout(), c = Kn({
    delta: n,
    initialLayout: l,
    panelConstraints: r.derivedPanelConstraints,
    pivotIndices: i,
    prevLayout: l,
    trigger: "keyboard"
  }), u = Wt({
    layout: c,
    panelConstraints: r.derivedPanelConstraints
  });
  Ut(l, u) || dt(s, {
    defaultLayoutDeferred: r.defaultLayoutDeferred,
    derivedPanelConstraints: r.derivedPanelConstraints,
    groupSize: r.groupSize,
    layout: u,
    separatorToPanels: r.separatorToPanels
  });
}
function _o(e) {
  if (e.defaultPrevented)
    return;
  const n = e.currentTarget, s = Es(n);
  if (!s.disabled)
    switch (e.key) {
      case "ArrowDown": {
        e.preventDefault(), s.orientation === "vertical" && Ot(n, 5);
        break;
      }
      case "ArrowLeft": {
        e.preventDefault(), s.orientation === "horizontal" && Ot(n, -5);
        break;
      }
      case "ArrowRight": {
        e.preventDefault(), s.orientation === "horizontal" && Ot(n, 5);
        break;
      }
      case "ArrowUp": {
        e.preventDefault(), s.orientation === "vertical" && Ot(n, -5);
        break;
      }
      case "End": {
        e.preventDefault(), Ot(n, 100);
        break;
      }
      case "Enter": {
        e.preventDefault();
        const r = Es(n), a = Ct(r.id, !0), { derivedPanelConstraints: o, layout: i, separatorToPanels: l } = a, c = r.separators.find(
          (m) => m.element === n
        );
        Z(c, "Matching separator not found");
        const u = l.get(c);
        Z(u, "Matching panels not found");
        const d = u[0], h = o.find(
          (m) => m.panelId === d.id
        );
        if (Z(h, "Panel metadata not found"), h.collapsible) {
          const m = i[d.id], y = h.collapsedSize === m ? r.mutableState.expandedPanelSizes[d.id] ?? h.minSize : h.collapsedSize;
          Ot(n, y - m);
        }
        break;
      }
      case "F6": {
        e.preventDefault();
        const r = Es(n).separators.map(
          (i) => i.element
        ), a = Array.from(r).findIndex(
          (i) => i === e.currentTarget
        );
        Z(a !== null, "Index not found");
        const o = e.shiftKey ? a > 0 ? a - 1 : r.length - 1 : a + 1 < r.length ? a + 1 : 0;
        r[o].focus();
        break;
      }
      case "Home": {
        e.preventDefault(), Ot(n, -100);
        break;
      }
    }
}
let mn = {
  cursorFlags: 0,
  state: "inactive"
};
const ga = new dc();
function Ht() {
  return mn;
}
function ey(e) {
  return ga.addListener("change", e);
}
function ty(e) {
  const n = mn, s = { ...mn };
  s.cursorFlags = e, mn = s, ga.emit("change", {
    prev: n,
    next: s
  });
}
function pn(e) {
  const n = mn;
  mn = e, ga.emit("change", {
    prev: n,
    next: e
  });
}
function Lo(e) {
  if (e.defaultPrevented || e.pointerType === "mouse" && e.button > 0)
    return;
  const n = Yt(), s = pa(e, n), r = /* @__PURE__ */ new Map();
  let a = !1;
  s.forEach((o) => {
    o.separator && (a || (a = !0, o.separator.element.focus()));
    const i = n.get(o.group);
    i && r.set(o.group, i.layout);
  }), pn({
    cursorFlags: 0,
    hitRegions: s,
    initialLayoutMap: r,
    pointerDownAtPoint: { x: e.clientX, y: e.clientY },
    state: "active"
  }), s.length && e.preventDefault();
}
const ny = (e) => e, dr = () => {
}, pc = 1, gc = 2, xc = 4, vc = 8, Fo = 3, zo = 12;
let bs;
function $o() {
  return bs === void 0 && (bs = !1, typeof window < "u" && (window.navigator.userAgent.includes("Chrome") || window.navigator.userAgent.includes("Firefox")) && (bs = !0)), bs;
}
function sy({
  cursorFlags: e,
  groups: n,
  state: s
}) {
  let r = 0, a = 0;
  switch (s) {
    case "active":
    case "hover":
      n.forEach((o) => {
        if (!o.mutableState.disableCursor)
          switch (o.orientation) {
            case "horizontal": {
              r++;
              break;
            }
            case "vertical": {
              a++;
              break;
            }
          }
      });
  }
  if (!(r === 0 && a === 0)) {
    switch (s) {
      case "active": {
        if (e && $o()) {
          const o = (e & pc) !== 0, i = (e & gc) !== 0, l = (e & xc) !== 0, c = (e & vc) !== 0;
          if (o)
            return l ? "se-resize" : c ? "ne-resize" : "e-resize";
          if (i)
            return l ? "sw-resize" : c ? "nw-resize" : "w-resize";
          if (l)
            return "s-resize";
          if (c)
            return "n-resize";
        }
        break;
      }
    }
    return $o() ? r > 0 && a > 0 ? "move" : r > 0 ? "ew-resize" : "ns-resize" : r > 0 && a > 0 ? "grab" : r > 0 ? "col-resize" : "row-resize";
  }
}
const Vo = /* @__PURE__ */ new WeakMap();
function xa(e) {
  if (e.defaultView === null || e.defaultView === void 0)
    return;
  let { prevStyle: n, styleSheet: s } = Vo.get(e) ?? {};
  s === void 0 && (s = new e.defaultView.CSSStyleSheet(), e.adoptedStyleSheets && e.adoptedStyleSheets.push(s));
  const r = Ht();
  switch (r.state) {
    case "active":
    case "hover": {
      const a = sy({
        cursorFlags: r.cursorFlags,
        groups: r.hitRegions.map((i) => i.group),
        state: r.state
      }), o = `*, *:hover {cursor: ${a} !important; }`;
      if (n === o)
        return;
      n = o, a ? s.cssRules.length === 0 ? s.insertRule(o) : s.replaceSync(o) : s.cssRules.length === 1 && s.deleteRule(0);
      break;
    }
    case "inactive": {
      n = void 0, s.cssRules.length === 1 && s.deleteRule(0);
      break;
    }
  }
  Vo.set(e, {
    prevStyle: n,
    styleSheet: s
  });
}
function yc({
  document: e,
  event: n,
  hitRegions: s,
  initialLayoutMap: r,
  mountedGroups: a,
  pointerDownAtPoint: o,
  prevCursorFlags: i
}) {
  let l = 0;
  s.forEach((u) => {
    const { group: d, groupSize: h } = u, { orientation: m, panels: y } = d, { disableCursor: v } = d.mutableState;
    let g = 0;
    o ? m === "horizontal" ? g = (n.clientX - o.x) / h * 100 : g = (n.clientY - o.y) / h * 100 : m === "horizontal" ? g = n.clientX < 0 ? -100 : 100 : g = n.clientY < 0 ? -100 : 100;
    const j = r.get(d), x = a.get(d);
    if (!j || !x)
      return;
    const {
      defaultLayoutDeferred: N,
      derivedPanelConstraints: w,
      groupSize: b,
      layout: E,
      separatorToPanels: R
    } = x;
    if (w && E && R) {
      const S = Kn({
        delta: g,
        initialLayout: j,
        panelConstraints: w,
        pivotIndices: u.panels.map((C) => y.indexOf(C)),
        prevLayout: E,
        trigger: "mouse-or-touch"
      });
      if (Ut(S, E)) {
        if (g !== 0 && !v)
          switch (m) {
            case "horizontal": {
              l |= g < 0 ? pc : gc;
              break;
            }
            case "vertical": {
              l |= g < 0 ? xc : vc;
              break;
            }
          }
      } else
        dt(u.group, {
          defaultLayoutDeferred: N,
          derivedPanelConstraints: w,
          groupSize: b,
          layout: S,
          separatorToPanels: R
        });
    }
  });
  let c = 0;
  n.movementX === 0 ? c |= i & Fo : c |= l & Fo, n.movementY === 0 ? c |= i & zo : c |= l & zo, ty(c), xa(e);
}
function Bo(e) {
  const n = Yt(), s = Ht();
  switch (s.state) {
    case "active":
      yc({
        document: e.currentTarget,
        event: e,
        hitRegions: s.hitRegions,
        initialLayoutMap: s.initialLayoutMap,
        mountedGroups: n,
        prevCursorFlags: s.cursorFlags
      });
  }
}
function Uo(e) {
  if (e.defaultPrevented)
    return;
  const n = Ht(), s = Yt();
  switch (n.state) {
    case "active": {
      if (
        // Skip this check for "pointerleave" events, else Firefox triggers a false positive (see #514)
        e.buttons === 0
      ) {
        pn({
          cursorFlags: 0,
          state: "inactive"
        }), n.hitRegions.forEach((r) => {
          const a = Ct(r.group.id, !0);
          dt(r.group, a);
        });
        return;
      }
      yc({
        document: e.currentTarget,
        event: e,
        hitRegions: n.hitRegions,
        initialLayoutMap: n.initialLayoutMap,
        mountedGroups: s,
        pointerDownAtPoint: n.pointerDownAtPoint,
        prevCursorFlags: n.cursorFlags
      });
      break;
    }
    default: {
      const r = pa(e, s);
      r.length === 0 ? n.state !== "inactive" && pn({
        cursorFlags: 0,
        state: "inactive"
      }) : pn({
        cursorFlags: 0,
        hitRegions: r,
        state: "hover"
      }), xa(e.currentTarget);
      break;
    }
  }
}
function Wo(e) {
  if (e.relatedTarget instanceof HTMLIFrameElement)
    switch (Ht().state) {
      case "hover":
        pn({
          cursorFlags: 0,
          state: "inactive"
        });
    }
}
function Ho(e) {
  if (e.defaultPrevented || e.pointerType === "mouse" && e.button > 0)
    return;
  const n = Ht();
  switch (n.state) {
    case "active":
      pn({
        cursorFlags: 0,
        state: "inactive"
      }), n.hitRegions.length > 0 && (xa(e.currentTarget), n.hitRegions.forEach((s) => {
        const r = Ct(s.group.id, !0);
        dt(s.group, r);
      }), e.preventDefault());
  }
}
function Go(e) {
  let n = 0, s = 0;
  const r = {};
  for (const o of e)
    if (o.defaultSize !== void 0) {
      n++;
      const i = Oe(o.defaultSize);
      s += i, r[o.panelId] = i;
    } else
      r[o.panelId] = void 0;
  const a = e.length - n;
  if (a !== 0) {
    const o = Oe((100 - s) / a);
    for (const i of e)
      i.defaultSize === void 0 && (r[i.panelId] = o);
  }
  return r;
}
function ry(e, n, s) {
  if (!s[0])
    return;
  const r = e.panels.find((c) => c.element === n);
  if (!r || !r.onResize)
    return;
  const a = bn({ group: e }), o = e.orientation === "horizontal" ? r.element.offsetWidth : r.element.offsetHeight, i = r.mutableValues.prevSize, l = {
    asPercentage: Oe(o / a * 100),
    inPixels: o
  };
  r.mutableValues.prevSize = l, r.onResize(l, r.id, i);
}
function ay(e, n) {
  if (Object.keys(e).length !== Object.keys(n).length)
    return !1;
  for (const s in e)
    if (e[s] !== n[s])
      return !1;
  return !0;
}
function oy({
  group: e,
  nextGroupSize: n,
  prevGroupSize: s,
  prevLayout: r
}) {
  if (s <= 0 || n <= 0 || s === n)
    return r;
  let a = 0, o = 0, i = !1;
  const l = /* @__PURE__ */ new Map(), c = [];
  for (const h of e.panels) {
    const m = r[h.id] ?? 0;
    switch (h.panelConstraints.groupResizeBehavior) {
      case "preserve-pixel-size": {
        i = !0;
        const y = m / 100 * s, v = Oe(
          y / n * 100
        );
        l.set(h.id, v), a += v;
        break;
      }
      case "preserve-relative-size":
      default: {
        c.push(h.id), o += m;
        break;
      }
    }
  }
  if (!i || c.length === 0)
    return r;
  const u = 100 - a, d = { ...r };
  if (l.forEach((h, m) => {
    d[m] = h;
  }), o > 0)
    for (const h of c) {
      const m = r[h] ?? 0;
      d[h] = Oe(
        m / o * u
      );
    }
  else {
    const h = Oe(
      u / c.length
    );
    for (const m of c)
      d[m] = h;
  }
  return d;
}
function iy(e, n) {
  const s = e.map((a) => a.id), r = Object.keys(n);
  if (s.length !== r.length)
    return !1;
  for (const a of s)
    if (!r.includes(a))
      return !1;
  return !0;
}
const sn = /* @__PURE__ */ new Map();
function ly(e) {
  let n = !0;
  Z(
    e.element.ownerDocument.defaultView,
    "Cannot register an unmounted Group"
  );
  const s = e.element.ownerDocument.defaultView.ResizeObserver, r = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set(), o = new s((v) => {
    for (const g of v) {
      const { borderBoxSize: j, target: x } = g;
      if (x === e.element) {
        if (n) {
          const N = bn({ group: e });
          if (N === 0)
            return;
          const w = Ct(e.id);
          if (!w)
            return;
          const b = Ir(e), E = w.defaultLayoutDeferred ? Go(b) : w.layout, R = oy({
            group: e,
            nextGroupSize: N,
            prevGroupSize: w.groupSize,
            prevLayout: E
          }), S = Wt({
            layout: R,
            panelConstraints: b
          });
          if (!w.defaultLayoutDeferred && Ut(w.layout, S) && ay(
            w.derivedPanelConstraints,
            b
          ) && w.groupSize === N)
            return;
          dt(e, {
            defaultLayoutDeferred: !1,
            derivedPanelConstraints: b,
            groupSize: N,
            layout: S,
            separatorToPanels: w.separatorToPanels
          });
        }
      } else
        ry(e, x, j);
    }
  });
  o.observe(e.element), e.panels.forEach((v) => {
    Z(
      !r.has(v.id),
      `Panel ids must be unique; id "${v.id}" was used more than once`
    ), r.add(v.id), v.onResize && o.observe(v.element);
  });
  const i = bn({ group: e }), l = Ir(e), c = e.panels.map(({ id: v }) => v).join(",");
  let u = e.mutableState.defaultLayout;
  u && (iy(e.panels, u) || (u = void 0));
  const d = e.mutableState.layouts[c] ?? u ?? Go(l), h = Wt({
    layout: d,
    panelConstraints: l
  }), m = e.element.ownerDocument;
  sn.set(
    m,
    (sn.get(m) ?? 0) + 1
  );
  const y = /* @__PURE__ */ new Map();
  return cc(e).forEach((v) => {
    v.separator && y.set(v.separator, v.panels);
  }), dt(e, {
    defaultLayoutDeferred: i === 0,
    derivedPanelConstraints: l,
    groupSize: i,
    layout: h,
    separatorToPanels: y
  }), e.separators.forEach((v) => {
    Z(
      !a.has(v.id),
      `Separator ids must be unique; id "${v.id}" was used more than once`
    ), a.add(v.id), v.element.addEventListener("keydown", _o);
  }), sn.get(m) === 1 && (m.addEventListener("dblclick", Mo, !0), m.addEventListener("pointerdown", Lo, !0), m.addEventListener("pointerleave", Bo), m.addEventListener("pointermove", Uo), m.addEventListener("pointerout", Wo), m.addEventListener("pointerup", Ho, !0)), function() {
    n = !1, sn.set(
      m,
      Math.max(0, (sn.get(m) ?? 0) - 1)
    ), Wv(e), e.separators.forEach((v) => {
      v.element.removeEventListener("keydown", _o);
    }), sn.get(m) || (m.removeEventListener(
      "dblclick",
      Mo,
      !0
    ), m.removeEventListener(
      "pointerdown",
      Lo,
      !0
    ), m.removeEventListener("pointerleave", Bo), m.removeEventListener("pointermove", Uo), m.removeEventListener("pointerout", Wo), m.removeEventListener("pointerup", Ho, !0)), o.disconnect();
  };
}
function cy() {
  const [e, n] = p.useState({}), s = p.useCallback(() => n({}), []);
  return [e, s];
}
function va(e) {
  const n = p.useId();
  return `${e ?? n}`;
}
const Xt = typeof window < "u" ? p.useLayoutEffect : p.useEffect;
function Un(e) {
  const n = p.useRef(e);
  return Xt(() => {
    n.current = e;
  }, [e]), p.useCallback(
    (...s) => {
      var r;
      return (r = n.current) == null ? void 0 : r.call(n, ...s);
    },
    [n]
  );
}
function ya(...e) {
  return Un((n) => {
    e.forEach((s) => {
      if (s)
        switch (typeof s) {
          case "function": {
            s(n);
            break;
          }
          case "object": {
            s.current = n;
            break;
          }
        }
    });
  });
}
function ja(e) {
  const n = p.useRef({ ...e });
  return Xt(() => {
    for (const s in e)
      n.current[s] = e[s];
  }, [e]), n.current;
}
const jc = p.createContext(null);
function dy(e, n) {
  const s = p.useRef({
    getLayout: () => ({}),
    setLayout: ny
  });
  p.useImperativeHandle(n, () => s.current, []), Xt(() => {
    Object.assign(
      s.current,
      mc({ groupId: e })
    );
  });
}
function wc({
  children: e,
  className: n,
  defaultLayout: s,
  disableCursor: r,
  disabled: a,
  elementRef: o,
  groupRef: i,
  id: l,
  onLayoutChange: c,
  onLayoutChanged: u,
  orientation: d = "horizontal",
  resizeTargetMinimumSize: h = {
    coarse: 20,
    fine: 10
  },
  style: m,
  ...y
}) {
  const v = p.useRef({
    onLayoutChange: {},
    onLayoutChanged: {}
  }), g = Un((P) => {
    Ut(v.current.onLayoutChange, P) || (v.current.onLayoutChange = P, c == null || c(P));
  }), j = Un((P) => {
    Ut(v.current.onLayoutChanged, P) || (v.current.onLayoutChanged = P, u == null || u(P));
  }), x = va(l), N = p.useRef(null), [w, b] = cy(), E = p.useRef({
    lastExpandedPanelSizes: {},
    layouts: {},
    panels: [],
    resizeTargetMinimumSize: h,
    separators: []
  }), R = ya(N, o);
  dy(x, i);
  const S = Un(
    (P, D) => {
      const A = Ht(), _ = Oo(P), L = Ct(P);
      if (L) {
        let H = !1;
        switch (A.state) {
          case "active": {
            H = A.hitRegions.some(
              (X) => X.group === _
            );
            break;
          }
        }
        return {
          flexGrow: L.layout[D] ?? 1,
          pointerEvents: H ? "none" : void 0
        };
      }
      return {
        flexGrow: (s == null ? void 0 : s[D]) ?? 1
      };
    }
  ), C = ja({
    defaultLayout: s,
    disableCursor: r
  }), T = p.useMemo(
    () => ({
      get disableCursor() {
        return !!C.disableCursor;
      },
      getPanelStyles: S,
      id: x,
      orientation: d,
      registerPanel: (P) => {
        const D = E.current;
        return D.panels = Ar(d, [
          ...D.panels,
          P
        ]), b(), () => {
          D.panels = D.panels.filter(
            (A) => A !== P
          ), b();
        };
      },
      registerSeparator: (P) => {
        const D = E.current;
        return D.separators = Ar(d, [
          ...D.separators,
          P
        ]), b(), () => {
          D.separators = D.separators.filter(
            (A) => A !== P
          ), b();
        };
      },
      togglePanelDisabled: (P, D) => {
        const A = E.current.panels.find(
          (H) => H.id === P
        );
        A && (A.panelConstraints.disabled = D);
        const _ = Oo(x), L = Ct(x);
        _ && L && dt(_, {
          ...L,
          derivedPanelConstraints: Ir(_)
        });
      },
      toggleSeparatorDisabled: (P, D) => {
        const A = E.current.separators.find(
          (_) => _.id === P
        );
        A && (A.disabled = D);
      }
    }),
    [S, x, b, d, C]
  ), I = p.useRef(null);
  return Xt(() => {
    const P = N.current;
    if (P === null)
      return;
    const D = E.current;
    let A;
    if (C.defaultLayout !== void 0 && Object.keys(C.defaultLayout).length === D.panels.length) {
      A = {};
      for (const G of D.panels) {
        const Ue = C.defaultLayout[G.id];
        Ue !== void 0 && (A[G.id] = Ue);
      }
    }
    const _ = {
      disabled: !!a,
      element: P,
      id: x,
      mutableState: {
        defaultLayout: A,
        disableCursor: !!C.disableCursor,
        expandedPanelSizes: E.current.lastExpandedPanelSizes,
        layouts: E.current.layouts
      },
      orientation: d,
      panels: D.panels,
      resizeTargetMinimumSize: D.resizeTargetMinimumSize,
      separators: D.separators
    };
    I.current = _;
    const L = ly(_), { defaultLayoutDeferred: H, derivedPanelConstraints: X, layout: ue } = Ct(_.id, !0);
    !H && X.length > 0 && (g(ue), j(ue));
    const Se = ma(x, (G) => {
      const { defaultLayoutDeferred: Ue, derivedPanelConstraints: et, layout: ve } = G.next;
      if (Ue || et.length === 0)
        return;
      const ge = _.panels.map(({ id: he }) => he).join(",");
      _.mutableState.layouts[ge] = ve, et.forEach((he) => {
        if (he.collapsible) {
          const { layout: B } = G.prev ?? {};
          if (B) {
            const nt = Ee(
              he.collapsedSize,
              ve[he.panelId]
            ), Jt = Ee(
              he.collapsedSize,
              B[he.panelId]
            );
            nt && !Jt && (_.mutableState.expandedPanelSizes[he.panelId] = B[he.panelId]);
          }
        }
      });
      const tt = Ht().state !== "active";
      g(ve), tt && j(ve);
    });
    return () => {
      I.current = null, L(), Se();
    };
  }, [
    a,
    x,
    j,
    g,
    d,
    w,
    C
  ]), p.useEffect(() => {
    const P = I.current;
    P && (P.mutableState.defaultLayout = s, P.mutableState.disableCursor = !!r);
  }), /* @__PURE__ */ t.jsx(jc.Provider, { value: T, children: /* @__PURE__ */ t.jsx(
    "div",
    {
      ...y,
      className: n,
      "data-group": !0,
      "data-testid": x,
      id: x,
      ref: R,
      style: {
        height: "100%",
        width: "100%",
        overflow: "hidden",
        ...m,
        display: "flex",
        flexDirection: d === "horizontal" ? "row" : "column",
        flexWrap: "nowrap",
        // Inform the browser that the library is handling touch events for this element
        // but still allow users to scroll content within panels in the non-resizing direction
        // NOTE This is not an inherited style
        // See github.com/bvaughn/react-resizable-panels/issues/662
        touchAction: d === "horizontal" ? "pan-y" : "pan-x"
      },
      children: e
    }
  ) });
}
wc.displayName = "Group";
function wa() {
  const e = p.useContext(jc);
  return Z(
    e,
    "Group Context not found; did you render a Panel or Separator outside of a Group?"
  ), e;
}
function uy(e, n) {
  const { id: s } = wa(), r = p.useRef({
    collapse: dr,
    expand: dr,
    getSize: () => ({
      asPercentage: 0,
      inPixels: 0
    }),
    isCollapsed: () => !1,
    resize: dr
  });
  p.useImperativeHandle(n, () => r.current, []), Xt(() => {
    Object.assign(
      r.current,
      fc({ groupId: s, panelId: e })
    );
  });
}
function Nc({
  children: e,
  className: n,
  collapsedSize: s = "0%",
  collapsible: r = !1,
  defaultSize: a,
  disabled: o,
  elementRef: i,
  groupResizeBehavior: l = "preserve-relative-size",
  id: c,
  maxSize: u = "100%",
  minSize: d = "0%",
  onResize: h,
  panelRef: m,
  style: y,
  ...v
}) {
  const g = !!c, j = va(c), x = ja({
    disabled: o
  }), N = p.useRef(null), w = ya(N, i), {
    getPanelStyles: b,
    id: E,
    orientation: R,
    registerPanel: S,
    togglePanelDisabled: C
  } = wa(), T = h !== null, I = Un(
    (D, A, _) => {
      h == null || h(D, c, _);
    }
  );
  Xt(() => {
    const D = N.current;
    if (D !== null) {
      const A = {
        element: D,
        id: j,
        idIsStable: g,
        mutableValues: {
          expandToSize: void 0,
          prevSize: void 0
        },
        onResize: T ? I : void 0,
        panelConstraints: {
          groupResizeBehavior: l,
          collapsedSize: s,
          collapsible: r,
          defaultSize: a,
          disabled: x.disabled,
          maxSize: u,
          minSize: d
        }
      };
      return S(A);
    }
  }, [
    l,
    s,
    r,
    a,
    T,
    j,
    g,
    u,
    d,
    I,
    S,
    x
  ]), p.useEffect(() => {
    C(j, !!o);
  }, [o, j, C]), uy(j, m);
  const P = p.useSyncExternalStore(
    (D) => ma(E, D),
    // useSyncExternalStore does not support a custom equality check
    // stringify avoids re-rendering when the style value hasn't changed
    () => JSON.stringify(b(E, j)),
    () => JSON.stringify(b(E, j))
  );
  return /* @__PURE__ */ t.jsx(
    "div",
    {
      ...v,
      "aria-disabled": o || void 0,
      "data-panel": !0,
      "data-testid": j,
      id: j,
      ref: w,
      style: {
        ...hy,
        display: "flex",
        flexBasis: 0,
        flexShrink: 1,
        // Prevent Panel content from interfering with panel size
        overflow: "hidden",
        ...JSON.parse(P)
      },
      children: /* @__PURE__ */ t.jsx(
        "div",
        {
          className: n,
          style: {
            maxHeight: "100%",
            maxWidth: "100%",
            flexGrow: 1,
            ...y,
            // Inform the browser that the library is handling touch events for this element
            // but still allow users to scroll content within panels in the non-resizing direction
            // NOTE This is not an inherited style
            // See github.com/bvaughn/react-resizable-panels/issues/662
            touchAction: R === "horizontal" ? "pan-y" : "pan-x"
          },
          children: e
        }
      )
    }
  );
}
Nc.displayName = "Panel";
const hy = {
  minHeight: 0,
  maxHeight: "100%",
  height: "auto",
  minWidth: 0,
  maxWidth: "100%",
  width: "auto",
  border: "none",
  borderWidth: 0,
  padding: 0,
  margin: 0
};
function fy({
  layout: e,
  panelConstraints: n,
  panelId: s,
  panelIndex: r
}) {
  let a, o;
  const i = e[s], l = n.find(
    (c) => c.panelId === s
  );
  if (l) {
    const c = l.maxSize, u = l.collapsible ? l.collapsedSize : l.minSize, d = [r, r + 1];
    o = Wt({
      layout: Kn({
        delta: u - i,
        initialLayout: e,
        panelConstraints: n,
        pivotIndices: d,
        prevLayout: e
      }),
      panelConstraints: n
    })[s], a = Wt({
      layout: Kn({
        delta: c - i,
        initialLayout: e,
        panelConstraints: n,
        pivotIndices: d,
        prevLayout: e
      }),
      panelConstraints: n
    })[s];
  }
  return {
    valueControls: s,
    valueMax: a,
    valueMin: o,
    valueNow: i
  };
}
function bc({
  children: e,
  className: n,
  disabled: s,
  elementRef: r,
  id: a,
  style: o,
  ...i
}) {
  const l = va(a), c = ja({
    disabled: s
  }), [u, d] = p.useState({}), [h, m] = p.useState("inactive"), y = p.useRef(null), v = ya(y, r), {
    disableCursor: g,
    id: j,
    orientation: x,
    registerSeparator: N,
    toggleSeparatorDisabled: w
  } = wa(), b = x === "horizontal" ? "vertical" : "horizontal";
  Xt(() => {
    const R = y.current;
    if (R !== null) {
      const S = {
        disabled: c.disabled,
        element: R,
        id: l
      }, C = N(S), T = ey(
        (P) => {
          m(
            P.next.state !== "inactive" && P.next.hitRegions.some(
              (D) => D.separator === S
            ) ? P.next.state : "inactive"
          );
        }
      ), I = ma(
        j,
        (P) => {
          const { derivedPanelConstraints: D, layout: A, separatorToPanels: _ } = P.next, L = _.get(S);
          if (L) {
            const H = L[0], X = L.indexOf(H);
            d(
              fy({
                layout: A,
                panelConstraints: D,
                panelId: H.id,
                panelIndex: X
              })
            );
          }
        }
      );
      return () => {
        T(), I(), C();
      };
    }
  }, [j, l, N, c]), p.useEffect(() => {
    w(l, !!s);
  }, [s, l, w]);
  let E;
  return s && !g && (E = "not-allowed"), /* @__PURE__ */ t.jsx(
    "div",
    {
      ...i,
      "aria-controls": u.valueControls,
      "aria-disabled": s || void 0,
      "aria-orientation": b,
      "aria-valuemax": u.valueMax,
      "aria-valuemin": u.valueMin,
      "aria-valuenow": u.valueNow,
      children: e,
      className: n,
      "data-separator": s ? "disabled" : h,
      "data-testid": l,
      id: l,
      ref: v,
      role: "separator",
      style: {
        flexBasis: "auto",
        cursor: E,
        ...o,
        flexGrow: 0,
        flexShrink: 0,
        // Inform the browser that the library is handling touch events for this element
        // See github.com/bvaughn/react-resizable-panels/issues/662
        touchAction: "none"
      },
      tabIndex: s ? void 0 : 0
    }
  );
}
bc.displayName = "Separator";
function my({
  className: e,
  ...n
}) {
  return /* @__PURE__ */ t.jsx(
    wc,
    {
      "data-slot": "resizable-panel-group",
      className: $(
        "flex h-full w-full aria-[orientation=vertical]:flex-col",
        e
      ),
      ...n
    }
  );
}
function qo({ ...e }) {
  return /* @__PURE__ */ t.jsx(Nc, { "data-slot": "resizable-panel", ...e });
}
function py({
  withHandle: e,
  className: n,
  ...s
}) {
  return /* @__PURE__ */ t.jsx(
    bc,
    {
      "data-slot": "resizable-handle",
      className: $(
        "bg-border z-40 relative flex w-px items-center justify-center outline-none after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:outline-hidden aria-[orientation=horizontal]:h-px aria-[orientation=horizontal]:w-full aria-[orientation=horizontal]:after:left-0 aria-[orientation=horizontal]:after:h-1 aria-[orientation=horizontal]:after:w-full aria-[orientation=horizontal]:after:translate-x-0 aria-[orientation=horizontal]:after:-translate-y-1/2 [&[aria-orientation=horizontal]>div]:rotate-90",
        n
      ),
      ...s,
      children: e && /* @__PURE__ */ t.jsx("div", { className: "z-10 flex h-4 w-3 items-center justify-center rounded-xs border bg-border", children: /* @__PURE__ */ t.jsx(ji, { className: "size-2.5 hover:fill-primary" }) })
    }
  );
}
const gy = ({ children: e }) => {
  const { embedState: n } = ss();
  if (n.emitHomeButtonClickedEvent) {
    const s = () => {
      window.parent.postMessage(
        {
          type: Vu.CLIENT_BUILDER_HOME_BUTTON_CLICKED,
          data: {
            route: "/flows"
          }
        },
        "*"
      );
    };
    return /* @__PURE__ */ t.jsx("div", { onClick: s, children: e });
  }
  return /* @__PURE__ */ t.jsx($u, { to: oe.appendProjectRoutePrefix("/flows"), children: e });
}, Sc = () => {
  const { embedState: e } = ss(), n = Me.useWebsiteBranding(), s = e.homeButtonIcon === "back";
  return /* @__PURE__ */ t.jsx(t.Fragment, { children: !e.hideHomeButtonInBuilder && /* @__PURE__ */ t.jsxs(te, { children: [
    /* @__PURE__ */ t.jsx(gy, { children: /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsxs(
      O,
      {
        variant: "ghost",
        size: "icon",
        className: s ? "size-8" : "size-10",
        children: [
          !s && /* @__PURE__ */ t.jsx(
            "img",
            {
              className: "h-5 w-5 object-contain",
              src: n.logos.logoIconUrl,
              alt: n.websiteName
            }
          ),
          s && /* @__PURE__ */ t.jsx(Ds, { className: "h-4 w-4" })
        ]
      }
    ) }) }),
    !s && /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Go to Dashboard") })
  ] }) });
};
Sc.displayName = "HomeButton";
const xy = ({
  flow: e,
  flowVersion: n,
  children: s,
  readonly: r,
  onRename: a,
  onMoveTo: o,
  onDuplicate: i,
  onDelete: l,
  onOwnerChange: c,
  onVersionsListClick: u,
  insideBuilder: d
}) => {
  const h = Bu().pathname.includes("/runs"), { platform: m } = wi.useCurrentPlatform(), y = Ni(), { gitSync: v } = Uu.useGitSync(
    oe.getProjectId(),
    m.plan.environmentsEnabled
  ), { checkAccess: g } = Ve(), j = g(Ie.WRITE_FOLDER), x = g(Ie.WRITE_FLOW), N = g(
    Ie.WRITE_PROJECT_RELEASE
  ), { embedState: w } = ss(), b = v && v.branchType === Wu.DEVELOPMENT, [E, R] = p.useState(!1), S = e.publishedVersionId !== null && e.version.state === it.LOCKED, { projectMembers: C } = Hu.useProjectMembers(), T = C && C.length > 0, [I, P] = p.useState(!1), [D, A] = p.useState(n.displayName), [_, L] = p.useState(!1), [H, X] = p.useState(""), { folders: ue } = bi.useFolders(), { mutate: Se, isPending: G } = Re({
    mutationFn: async () => _n.update(e.id, {
      type: ae.CHANGE_NAME,
      request: { displayName: D }
    }),
    onSuccess: () => {
      P(!1), a(), je.success(f("Flow has been renamed."));
    }
  }), { mutate: Ue, isPending: et } = Re({
    mutationFn: async () => _n.update(e.id, {
      type: ae.CHANGE_FOLDER,
      request: { folderId: H }
    }),
    onSuccess: () => {
      L(!1), o(H), je.success(f("Moved flow successfully"));
    }
  }), { mutate: ve, isPending: ge } = Re({
    mutationFn: async () => {
      const B = {
        ...n,
        displayName: `${n.displayName} - Copy`
      }, nt = await _n.create({
        displayName: B.displayName,
        projectId: oe.getProjectId(),
        folderId: e.folderId ?? void 0
      });
      return await _n.update(nt.id, {
        type: ae.IMPORT_FLOW,
        request: {
          displayName: B.displayName,
          trigger: B.trigger,
          schemaVersion: B.schemaVersion,
          notes: B.notes
        }
      });
    },
    onSuccess: (B) => {
      y(`/flows/${B.id}`), i();
    }
  }), { mutate: tt, isPending: he } = Qe.useExportFlows();
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsxs(Yn, { open: E, onOpenChange: R, children: [
      /* @__PURE__ */ t.jsx(Xn, { asChild: !0, children: s }),
      /* @__PURE__ */ t.jsxs(
        Jn,
        {
          noAnimationOnOut: !0,
          onCloseAutoFocus: (B) => B.preventDefault(),
          children: [
            !r && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
              d && /* @__PURE__ */ t.jsx(
                Fe,
                {
                  hasPermission: x,
                  children: /* @__PURE__ */ t.jsx(
                    me,
                    {
                      onSelect: (B) => {
                        B.preventDefault(), B.stopPropagation(), R(!1), a();
                      },
                      disabled: !x,
                      children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer flex-row gap-2 items-center", children: [
                        /* @__PURE__ */ t.jsx(zt, { className: "h-4 w-4" }),
                        /* @__PURE__ */ t.jsx("span", { children: f("Rename") })
                      ] })
                    }
                  )
                }
              ),
              !d && /* @__PURE__ */ t.jsx(
                me,
                {
                  onSelect: (B) => {
                    B.preventDefault(), B.stopPropagation(), R(!1), A(n.displayName), P(!0);
                  },
                  disabled: !x,
                  children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer flex-row gap-2 items-center", children: [
                    /* @__PURE__ */ t.jsx(zt, { className: "h-4 w-4" }),
                    /* @__PURE__ */ t.jsx("span", { children: f("Rename") })
                  ] })
                }
              )
            ] }),
            /* @__PURE__ */ t.jsx(Fe, { hasPermission: N, children: /* @__PURE__ */ t.jsx(Gu, { allowPush: S, children: /* @__PURE__ */ t.jsx(qu, { type: "flow", flows: [e], children: /* @__PURE__ */ t.jsx(
              me,
              {
                disabled: !N || !S,
                onSelect: (B) => B.preventDefault(),
                onClick: (B) => B.stopPropagation(),
                children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
                  /* @__PURE__ */ t.jsx(Uf, { className: "h-4 w-4" }),
                  /* @__PURE__ */ t.jsx("span", { children: f("Push to Git") })
                ] })
              }
            ) }) }) }),
            !w.hideFolders && /* @__PURE__ */ t.jsx(
              Fe,
              {
                hasPermission: x || j,
                children: /* @__PURE__ */ t.jsx(
                  me,
                  {
                    disabled: !x || !j,
                    onSelect: (B) => {
                      B.preventDefault(), B.stopPropagation(), R(!1), L(!0);
                    },
                    children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
                      /* @__PURE__ */ t.jsx(Ku, { className: "h-4 w-4" }),
                      /* @__PURE__ */ t.jsx("span", { children: f("Move To") })
                    ] })
                  }
                )
              }
            ),
            !r && T && !w.isEmbedded && /* @__PURE__ */ t.jsx(
              Fe,
              {
                hasPermission: x,
                children: /* @__PURE__ */ t.jsx(
                  Yu,
                  {
                    flow: e,
                    onOwnerChange: c || (() => {
                    }),
                    children: /* @__PURE__ */ t.jsx(
                      me,
                      {
                        disabled: !x,
                        onSelect: (B) => B.preventDefault(),
                        onClick: (B) => B.stopPropagation(),
                        children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
                          /* @__PURE__ */ t.jsx(Xu, { className: "h-4 w-4" }),
                          /* @__PURE__ */ t.jsx("span", { children: f("Change Owner") })
                        ] })
                      }
                    )
                  }
                )
              }
            ),
            !w.hideDuplicateFlow && /* @__PURE__ */ t.jsx(
              Fe,
              {
                hasPermission: x,
                children: /* @__PURE__ */ t.jsx(
                  me,
                  {
                    disabled: !x,
                    onClick: () => ve(),
                    children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
                      ge ? /* @__PURE__ */ t.jsx(Gn, {}) : /* @__PURE__ */ t.jsx(Si, { className: "h-4 w-4" }),
                      /* @__PURE__ */ t.jsx("span", { children: ge ? f("Duplicating") : f("Duplicate") })
                    ] })
                  }
                )
              }
            ),
            d && !h && /* @__PURE__ */ t.jsx(me, { onClick: u, children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
              /* @__PURE__ */ t.jsx(gm, { className: "h-4 w-4" }),
              /* @__PURE__ */ t.jsx("span", { children: f("Versions") })
            ] }) }),
            !r && d && !w.hideExportAndImportFlow && /* @__PURE__ */ t.jsx(
              Fe,
              {
                hasPermission: x,
                children: /* @__PURE__ */ t.jsx(Ju, { insideBuilder: !0, flowId: e.id, children: /* @__PURE__ */ t.jsx(
                  me,
                  {
                    disabled: !x,
                    onSelect: (B) => B.preventDefault(),
                    children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer flex-row gap-2 items-center", children: [
                      /* @__PURE__ */ t.jsx(Qu, { className: "w-4 h-4" }),
                      f("Import")
                    ] })
                  }
                ) })
              }
            ),
            !w.hideExportAndImportFlow && /* @__PURE__ */ t.jsx(me, { onClick: () => tt([e]), children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
              he ? /* @__PURE__ */ t.jsx(Gn, {}) : /* @__PURE__ */ t.jsx(Ci, { className: "h-4 w-4" }),
              /* @__PURE__ */ t.jsx("span", { children: he ? f("Exporting") : f("Export") })
            ] }) }),
            !w.isEmbedded && /* @__PURE__ */ t.jsx(
              Zu,
              {
                flowId: e.id,
                flowVersionId: n.id,
                children: /* @__PURE__ */ t.jsx(me, { onSelect: (B) => B.preventDefault(), children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
                  /* @__PURE__ */ t.jsx(eh, { className: "h-4 w-4" }),
                  /* @__PURE__ */ t.jsx("span", { children: f("Share") })
                ] }) })
              }
            ),
            !r && (!w.isEmbedded || !w.disableNavigationInBuilder || !d) && /* @__PURE__ */ t.jsx(
              Fe,
              {
                hasPermission: x,
                children: /* @__PURE__ */ t.jsx(
                  th,
                  {
                    title: f("Delete Flow"),
                    message: /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
                      /* @__PURE__ */ t.jsx("div", { children: f(
                        "This will permanently delete the flow, all its data, and any background runs."
                      ) }),
                      b && /* @__PURE__ */ t.jsx("div", { className: "font-bold mt-2", children: f(
                        "You are on a development branch, this will also delete the flow from the remote repository."
                      ) })
                    ] }),
                    mutationFn: async () => {
                      await _n.delete(e.id), l();
                    },
                    entityName: f("flow"),
                    buttonText: f("Delete"),
                    children: /* @__PURE__ */ t.jsx(
                      me,
                      {
                        disabled: !x,
                        onSelect: (B) => B.preventDefault(),
                        onClick: (B) => B.stopPropagation(),
                        children: /* @__PURE__ */ t.jsxs("div", { className: "flex cursor-pointer  flex-row gap-2 items-center", children: [
                          /* @__PURE__ */ t.jsx(nh, { className: "h-4 w-4 text-destructive" }),
                          /* @__PURE__ */ t.jsx("span", { className: "text-destructive", children: f("Delete") })
                        ] })
                      }
                    )
                  }
                )
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ t.jsx(
      sh,
      {
        open: I,
        onOpenChange: P,
        value: D,
        onChange: A,
        onConfirm: () => Se(),
        isRenaming: G
      }
    ),
    /* @__PURE__ */ t.jsx(
      rh,
      {
        open: _,
        onOpenChange: L,
        folders: ue,
        selectedFolderId: H,
        onFolderChange: X,
        onConfirm: () => Ue(),
        isMoving: et
      }
    )
  ] });
}, Cc = k.memo(() => {
  const [e, n] = F((s) => [
    s.flowVersion,
    s.flow
  ]);
  return /* @__PURE__ */ t.jsxs("div", { className: "flex items-center space-x-2", children: [
    /* @__PURE__ */ t.jsx(
      Ei,
      {
        state: e.state,
        versionId: e.id,
        publishedVersionId: n.publishedVersionId
      }
    ),
    (n.publishedVersionId === e.id || e.state === it.DRAFT && !M(n.publishedVersionId)) && /* @__PURE__ */ t.jsx(ah, { flow: n })
  ] });
});
Cc.displayName = "BuilderFlowStatusSection";
const vy = () => {
  const [e] = oh(), n = Xr(), s = Qn(), r = Ni(), { data: a } = Me.useFlag(
    ze.SHOW_COMMUNITY
  ), o = Ve().checkAccess(
    Ie.READ_FLOW
  ), [
    i,
    l,
    c,
    u,
    d
  ] = F((E) => [
    E.flow,
    E.flowVersion,
    E.moveToFolderClientSide,
    E.applyOperation,
    E.setRightSidebar
  ]), { embedState: h } = ss(), { project: m } = Ti.useCurrentProject(), { data: y } = bi.useFolder(
    i.folderId ?? Wa
  ), v = l.state === it.DRAFT || l.id === i.publishedVersionId, [g, j] = p.useState(!1);
  p.useEffect(() => {
    j(e.get(ih) === "true");
  }, []);
  const x = () => {
    n({
      pathname: oe.appendProjectRoutePrefix("/automations"),
      search: hh({
        folderId: (y == null ? void 0 : y.id) ?? Wa
      }).toString()
    });
  }, N = /* @__PURE__ */ t.jsx("div", { className: "flex items-center gap-2 px-4", children: /* @__PURE__ */ t.jsx(Wf, { children: /* @__PURE__ */ t.jsxs(Hf, { children: [
    !h.disableNavigationInBuilder && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      /* @__PURE__ */ t.jsx(ro, { children: /* @__PURE__ */ t.jsx(
        Gf,
        {
          onClick: x,
          className: "cursor-pointer text-sm",
          children: lh(m)
        }
      ) }),
      /* @__PURE__ */ t.jsx(qf, {})
    ] }),
    !h.hideFlowNameInBuilder && /* @__PURE__ */ t.jsx(ro, { children: /* @__PURE__ */ t.jsx(Kf, { children: /* @__PURE__ */ t.jsxs(
      "div",
      {
        className: $("flex items-center gap-1 text-sm", {
          "max-w-[500px]": !g
        }),
        children: [
          /* @__PURE__ */ t.jsx(
            Jr,
            {
              className: "hover:cursor-text",
              value: l.displayName,
              readonly: !v,
              onValueChange: (E) => {
                u(
                  {
                    type: ae.CHANGE_NAME,
                    request: {
                      displayName: E
                    }
                  },
                  () => {
                    Qe.invalidateFlowsQuery(s);
                  }
                );
              },
              isEditing: g,
              setIsEditing: j,
              tooltipContent: ""
            }
          ),
          /* @__PURE__ */ t.jsx(
            xy,
            {
              onVersionsListClick: () => {
                d(ye.VERSIONS);
              },
              insideBuilder: !0,
              flow: i,
              flowVersion: l,
              readonly: !v,
              onDelete: x,
              onRename: () => {
                j(!0);
              },
              onMoveTo: (E) => c(E),
              onDuplicate: () => {
              },
              children: /* @__PURE__ */ t.jsx(
                O,
                {
                  variant: "ghost",
                  className: "size-6 flex items-center justify-center",
                  children: /* @__PURE__ */ t.jsx(Gr, { className: "h-4 w-4 text-muted-foreground" })
                }
              )
            }
          )
        ]
      }
    ) }) })
  ] }) }) }), w = /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-center gap-4", children: [
    a && /* @__PURE__ */ t.jsxs(
      O,
      {
        variant: "ghost",
        className: "gap-2 px-2",
        onClick: () => r(ch),
        children: [
          /* @__PURE__ */ t.jsx(Pi, { className: "w-4 h-4" }),
          f("Support")
        ]
      }
    ),
    /* @__PURE__ */ t.jsx(Yf, { resourceId: i.id }),
    o && /* @__PURE__ */ t.jsxs(
      O,
      {
        variant: "ghost",
        onClick: () => d(ye.RUNS),
        className: "gap-2 px-2",
        children: [
          /* @__PURE__ */ t.jsx(dh, { className: "w-4 h-4" }),
          f("Runs")
        ]
      }
    ),
    /* @__PURE__ */ t.jsx(Cc, {})
  ] }), b = h.isEmbedded ? /* @__PURE__ */ t.jsx(Sc, {}) : null;
  return /* @__PURE__ */ t.jsx(
    "div",
    {
      style: {
        height: `$${W.BUILDER_HEADER_HEIGHT}px`
      },
      children: /* @__PURE__ */ t.jsx(
        uh,
        {
          title: N,
          rightContent: w,
          leftContent: b,
          className: "select-none border-b"
        }
      )
    }
  );
};
function Ec({
  selectedNodes: e,
  flowVersion: n
}) {
  const r = {
    type: "COPY_ACTIONS",
    actions: Di.getActionsForCopy(
      e,
      n
    )
  };
  navigator.clipboard.writeText(JSON.stringify(r));
}
function Tc({
  selectedNodes: e,
  applyOperation: n,
  selectedStep: s,
  exitStepSettings: r
}) {
  n({
    type: ae.DELETE_ACTION,
    request: {
      names: e
    }
  }), s && e.includes(s) && r();
}
async function Pc() {
  try {
    const e = await navigator.clipboard.readText(), n = JSON.parse(e);
    if (n && n.type === "COPY_ACTIONS")
      return n.actions;
  } catch (e) {
    return console.error("Error getting actions in clipboard", e), [];
  }
  return [];
}
async function on(e, n, s) {
  const r = await Pc(), a = Di.getOperationsForPaste(
    r,
    e,
    n
  );
  a.forEach((o) => {
    s(o);
  }), a.length === 0 && je(f("No Steps Pasted"), {
    description: f(
      "Please make sure you have copied a step(s) and allowed permission to your clipboard"
    )
  });
}
function yy(e) {
  const n = [
    e.trigger,
    ...q.getAllNextActionsWithoutChildren(e.trigger)
  ];
  return {
    parentStepName: n[n.length - 1].name,
    stepLocationRelativeToParent: kt.AFTER
  };
}
function Dc({
  selectedNodes: e,
  flowVersion: n,
  applyOperation: s
}) {
  const r = e.map(
    (o) => q.getStepOrThrow(o, n.trigger)
  ), a = r.every((o) => !!o.skip);
  s({
    type: ae.SET_SKIP_ACTION,
    request: {
      names: r.map((o) => o.name),
      skip: !a
    }
  });
}
const zn = {
  copySelectedNodes: Ec,
  deleteSelectedNodes: Tc,
  getActionsInClipboard: Pc,
  pasteNodes: on,
  toggleSkipSelectedNodes: Dc
}, jy = () => {
  const [
    e,
    n,
    s,
    r,
    a,
    o,
    i,
    l,
    c,
    u
  ] = F((h) => [
    h.selectedNodes,
    h.flowVersion,
    h.selectedStep,
    h.exitStepSettings,
    h.applyOperation,
    h.readonly,
    h.setShowMinimap,
    h.showMinimap,
    h.setDraggedNote,
    h.setActiveDraggingStep
  ]), d = p.useCallback(
    (h) => {
      const m = h.target instanceof HTMLElement && h.target.classList.contains(
        W.NODE_SELECTION_RECT_CLASS_NAME
      ), y = h.target instanceof HTMLElement && h.target.closest(
        `[data-${W.STEP_CONTEXT_MENU_ATTRIBUTE}]`
      ), v = h.target === document.body, g = e.filter(
        (j) => j !== n.trigger.name
      );
      wy(h, {
        Minimap: () => {
          i(!l);
        },
        Copy: () => {
          var j;
          g.length > 0 && ((j = document.getSelection()) == null ? void 0 : j.toString()) === "" && (h.stopPropagation(), h.preventDefault(), zn.copySelectedNodes({
            selectedNodes: g,
            flowVersion: n
          }));
        },
        Delete: () => {
          o || e.length > 0 && (h.stopPropagation(), h.preventDefault(), zn.deleteSelectedNodes({
            exitStepSettings: r,
            selectedStep: s,
            selectedNodes: e,
            applyOperation: a
          }));
        },
        Skip: () => {
          o || g.length > 0 && zn.toggleSkipSelectedNodes({
            selectedNodes: g,
            flowVersion: n,
            applyOperation: a
          });
        },
        ExitDrag: () => {
          c(null, null), u(null);
        },
        Paste: () => {
          o || !m && !y && !v || (h.stopPropagation(), h.preventDefault(), zn.getActionsInClipboard().then((j) => {
            if (j.length > 0) {
              const x = [
                n.trigger,
                ...q.getAllNextActionsWithoutChildren(
                  n.trigger
                )
              ].at(-1).name, N = e.length === 1 ? e[0] : null;
              zn.pasteNodes(
                n,
                {
                  parentStepName: N ?? x,
                  stepLocationRelativeToParent: kt.AFTER
                },
                a
              );
            }
          }));
        }
      });
    },
    [
      e,
      n,
      a,
      s,
      r,
      o,
      i,
      l,
      c,
      u
    ]
  );
  p.useEffect(() => (document.addEventListener("keydown", d), () => document.removeEventListener("keydown", d)), [d]);
}, wy = (e, n) => {
  const s = Object.entries(Ts).find(
    ([r, a]) => {
      var o;
      return ((o = a.shortcutKey) == null ? void 0 : o.toLowerCase()) === e.key.toLowerCase() && (a.withCtrl === e.ctrlKey || a.withCtrl === e.metaKey) && !!a.withShift === e.shiftKey;
    }
  );
  s && n[s[0]]();
}, Ts = {
  ExitDrag: {
    withCtrl: !1,
    withShift: !1,
    shortcutKey: "Escape"
  },
  Minimap: {
    withCtrl: !0,
    withShift: !1,
    shortcutKey: "m"
  },
  Paste: {
    withCtrl: !0,
    withShift: !1,
    shortcutKey: "v"
  },
  Delete: {
    withCtrl: !1,
    withShift: !0,
    shortcutKey: "Delete"
  },
  Copy: {
    withCtrl: !0,
    withShift: !1,
    shortcutKey: "c"
  },
  Skip: {
    withCtrl: !0,
    withShift: !1,
    shortcutKey: "e"
  }
}, Rc = p.createContext({
  cursorPosition: { x: 0, y: 0 },
  setCursorPosition: () => {
  }
}), Oc = () => p.useContext(Rc), Ny = ({
  children: e
}) => {
  const n = p.useRef({ x: 0, y: 0 }), s = (r) => {
    n.current = r;
  };
  return /* @__PURE__ */ t.jsx(
    Rc.Provider,
    {
      value: { cursorPosition: n.current, setCursorPosition: s },
      children: e
    }
  );
}, by = (e) => {
  p.useEffect(() => {
    const n = (s) => {
      e({ x: s.clientX, y: s.clientY });
    };
    return window.addEventListener("pointermove", n), () => {
      window.removeEventListener("pointermove", n);
    };
  }, []);
};
function Sy({
  ...e
}) {
  return /* @__PURE__ */ t.jsx(lp, { "data-slot": "context-menu", ...e });
}
function Cy({
  ...e
}) {
  return /* @__PURE__ */ t.jsx(cp, { "data-slot": "context-menu-trigger", ...e });
}
function Ey({
  ...e
}) {
  return /* @__PURE__ */ t.jsx(mp, { "data-slot": "context-menu-sub", ...e });
}
function Ty({
  className: e,
  inset: n,
  children: s,
  ...r
}) {
  return /* @__PURE__ */ t.jsxs(
    pp,
    {
      "data-slot": "context-menu-sub-trigger",
      "data-inset": n,
      className: $(
        "flex cursor-default items-center rounded-sm px-2 py-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground data-[inset]:pl-8 data-[state=open]:bg-accent data-[state=open]:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        e
      ),
      ...r,
      children: [
        s,
        /* @__PURE__ */ t.jsx(Hr, { className: "ml-auto" })
      ]
    }
  );
}
function Py({
  className: e,
  ...n
}) {
  return /* @__PURE__ */ t.jsx(
    gp,
    {
      "data-slot": "context-menu-sub-content",
      className: $(
        "z-50 min-w-[8rem] origin-(--radix-context-menu-content-transform-origin) overflow-hidden rounded-md border bg-popover p-1 text-popover-foreground shadow-lg data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95",
        e
      ),
      ...n
    }
  );
}
function Dy({
  className: e,
  ...n
}) {
  return /* @__PURE__ */ t.jsx(dp, { container: xi.getPortalContainer(), children: /* @__PURE__ */ t.jsx(
    up,
    {
      "data-slot": "context-menu-content",
      className: $(
        "z-50 max-h-(--radix-context-menu-content-available-height) min-w-[8rem] origin-(--radix-context-menu-content-transform-origin) overflow-x-hidden overflow-y-auto rounded-md border bg-popover p-1 text-popover-foreground shadow-md data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95",
        e
      ),
      ...n
    }
  ) });
}
function He({
  className: e,
  inset: n,
  variant: s = "default",
  ...r
}) {
  return /* @__PURE__ */ t.jsx(
    hp,
    {
      "data-slot": "context-menu-item",
      "data-inset": n,
      "data-variant": s,
      className: $(
        "relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50 data-[inset]:pl-8 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 data-[variant=destructive]:focus:text-destructive dark:data-[variant=destructive]:focus:bg-destructive/20 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4  data-[variant=destructive]:*:[svg]:text-destructive!",
        e
      ),
      ...r
    }
  );
}
function Ko({
  className: e,
  ...n
}) {
  return /* @__PURE__ */ t.jsx(
    fp,
    {
      "data-slot": "context-menu-separator",
      className: $("-mx-1 my-1 h-px bg-border", e),
      ...n
    }
  );
}
const ur = ({
  children: e,
  shortcut: n
}) => /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between gap-4 grow", children: [
  /* @__PURE__ */ t.jsx("div", { className: "flex gap-2 items-center", children: e }),
  /* @__PURE__ */ t.jsx(mh, { ...n, className: "text-end" })
] }), Ry = ({
  contextMenuType: e
}) => {
  const [
    n,
    s,
    r,
    a,
    o,
    i,
    l
  ] = F((C) => [
    C.selectedNodes,
    C.applyOperation,
    C.selectedStep,
    C.flowVersion,
    C.exitStepSettings,
    C.readonly,
    C.setOpenedPieceSelectorStepNameOrAddButtonId
  ]), c = n.length === 0, u = n.every(
    (C) => {
      var T;
      return !!((T = q.getStep(C, a.trigger)) != null && T.skip);
    }
  ), d = n.some(
    (C) => C === a.trigger.name
  ), h = q.getStep(
    n[0],
    a.trigger
  ), m = !i && e === Ae.CANVAS, y = n.length === 1 && (h == null ? void 0 : h.type) === Y.LOOP_ON_ITEMS && !i && e === Ae.STEP, v = n.length === 1 && (h == null ? void 0 : h.type) === Y.ROUTER && !i && e === Ae.STEP, g = n.length === 1 && !i && e === Ae.STEP, j = n.length === 1 && !i && e === Ae.STEP, x = !d && e === Ae.STEP, N = n.length === 1 && !d && e === Ae.STEP && !i, w = !d && e === Ae.STEP && !i, b = n.length === 1 && d, E = !i && e === Ae.STEP && !b, R = () => {
    s({
      type: ae.DUPLICATE_ACTION,
      request: {
        stepName: n[0]
      }
    });
  };
  return j || x || N || w || y || v || g || m || E ? /* @__PURE__ */ t.jsxs(Dy, { children: [
    j && /* @__PURE__ */ t.jsxs(
      He,
      {
        disabled: c,
        onClick: () => {
          l(n[0]);
        },
        className: "flex items-center gap-2",
        children: [
          /* @__PURE__ */ t.jsx(nm, { className: "w-4 h-4" }),
          " ",
          f("Replace")
        ]
      }
    ),
    x && /* @__PURE__ */ t.jsx(
      He,
      {
        disabled: c,
        onClick: () => {
          Ec({ selectedNodes: n, flowVersion: a });
        },
        children: /* @__PURE__ */ t.jsxs(ur, { shortcut: Ts.Copy, children: [
          /* @__PURE__ */ t.jsx(Si, { className: "w-4 h-4" }),
          " ",
          f("Copy")
        ] })
      }
    ),
    /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      N && /* @__PURE__ */ t.jsxs(
        He,
        {
          disabled: c,
          onClick: R,
          className: "flex items-center gap-2",
          children: [
            /* @__PURE__ */ t.jsx(Ri, { className: "w-4 h-4" }),
            " ",
            f("Duplicate")
          ]
        }
      ),
      w && /* @__PURE__ */ t.jsx(
        He,
        {
          disabled: c,
          onClick: () => {
            Dc({
              selectedNodes: n,
              flowVersion: a,
              applyOperation: s
            });
          },
          children: /* @__PURE__ */ t.jsxs(ur, { shortcut: Ts.Skip, children: [
            u ? /* @__PURE__ */ t.jsx(Im, { className: "h-4 w-4" }) : /* @__PURE__ */ t.jsx(fh, { className: "h-4 w-4" }),
            u ? f("Unskip") : f("Skip")
          ] })
        }
      ),
      (y || v || g) && /* @__PURE__ */ t.jsx(Ko, {}),
      m && /* @__PURE__ */ t.jsxs(
        He,
        {
          onClick: () => {
            const C = yy(a);
            C && on(a, C, s);
          },
          className: "flex items-center gap-2",
          children: [
            /* @__PURE__ */ t.jsx(oo, { className: "w-4 h-4" }),
            " ",
            f("Paste After Last Step")
          ]
        }
      ),
      y && /* @__PURE__ */ t.jsxs(
        He,
        {
          onClick: () => {
            on(
              a,
              {
                parentStepName: n[0],
                stepLocationRelativeToParent: kt.INSIDE_LOOP
              },
              s
            );
          },
          className: "flex items-center gap-2",
          children: [
            /* @__PURE__ */ t.jsx(ao, { className: "w-4 h-4" }),
            " ",
            f("Paste Inside Loop")
          ]
        }
      ),
      g && /* @__PURE__ */ t.jsxs(
        He,
        {
          onClick: () => {
            on(
              a,
              {
                parentStepName: n[0],
                stepLocationRelativeToParent: kt.AFTER
              },
              s
            );
          },
          className: "flex items-center gap-2",
          children: [
            /* @__PURE__ */ t.jsx(oo, { className: "w-4 h-4" }),
            " ",
            f("Paste After")
          ]
        }
      ),
      v && /* @__PURE__ */ t.jsxs(Ey, { children: [
        /* @__PURE__ */ t.jsxs(Ty, { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ t.jsx(ao, { className: "w-4 h-4" }),
          " ",
          f("Paste Inside...")
        ] }),
        /* @__PURE__ */ t.jsxs(Py, { children: [
          h && h.settings.branches.map(
            (C, T) => /* @__PURE__ */ t.jsx(
              He,
              {
                onClick: () => {
                  on(
                    a,
                    {
                      parentStepName: n[0],
                      stepLocationRelativeToParent: kt.INSIDE_BRANCH,
                      branchIndex: T
                    },
                    s
                  );
                },
                children: C.branchName
              },
              C.branchName
            )
          ),
          /* @__PURE__ */ t.jsxs(
            He,
            {
              onClick: () => {
                s({
                  type: ae.ADD_BRANCH,
                  request: {
                    stepName: h.name,
                    branchIndex: h.settings.branches.length - 1,
                    branchName: `Branch ${h.settings.branches.length}`
                  }
                }), on(
                  a,
                  {
                    parentStepName: h.name,
                    stepLocationRelativeToParent: kt.INSIDE_BRANCH,
                    branchIndex: h.settings.branches.length - 1
                  },
                  s
                );
              },
              children: [
                "+ ",
                f("New Branch")
              ]
            }
          )
        ] })
      ] }),
      E && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
        /* @__PURE__ */ t.jsx(Ko, {}),
        /* @__PURE__ */ t.jsx(
          He,
          {
            disabled: c,
            onClick: () => {
              Tc({
                selectedNodes: n,
                applyOperation: s,
                selectedStep: r,
                exitStepSettings: o
              });
            },
            children: /* @__PURE__ */ t.jsxs(ur, { shortcut: Ts.Delete, children: [
              /* @__PURE__ */ t.jsx(Qr, { className: "w-4 stroke-destructive h-4" }),
              " ",
              /* @__PURE__ */ t.jsx("div", { className: "text-destructive", children: f("Delete") })
            ] })
          }
        )
      ] })
    ] })
  ] }) : null;
};
var Ae = /* @__PURE__ */ ((e) => (e.CANVAS = "CANVAS", e.STEP = "STEP", e))(Ae || {});
const Oy = ({
  contextMenuType: e,
  children: n
}) => /* @__PURE__ */ t.jsxs(Sy, { children: [
  /* @__PURE__ */ t.jsx(Cy, { asChild: !0, children: n }),
  /* @__PURE__ */ t.jsx(
    Ry,
    {
      contextMenuType: e
    }
  )
] }), Iy = p.createContext({
  cursorPosition: { x: 0, y: 0 },
  setCursorPosition: () => {
  }
}), Ay = () => p.useContext(Iy), ky = (e) => {
  p.useEffect(() => {
    const n = (s) => {
      e({ x: s.clientX, y: s.clientY });
    };
    return window.addEventListener("pointermove", n), () => {
      window.removeEventListener("pointermove", n);
    };
  }, [e]);
}, My = () => {
  const { cursorPosition: e } = Ay(), [n, s] = p.useState(e), r = document.getElementById(Oi), [a, o, i, l] = F((x) => [
    x.draggedNote,
    x.noteDragOverlayMode,
    x.addNote,
    x.draggedNoteOffset
  ]), c = Tn(), u = p.useRef(null), d = (r == null ? void 0 : r.clientWidth) ?? 0, h = {
    width: ((a == null ? void 0 : a.size.width) ?? 0) * c.getZoom(),
    height: ((a == null ? void 0 : a.size.height) ?? 0) * c.getZoom()
  }, m = l ? l.x : h.width / 2, y = l ? l.y : h.height / 2, v = `${n.x - m - d}px`, g = `${n.y - y - W.BUILDER_HEADER_HEIGHT}px`;
  return ky((x) => {
    s(x);
  }), M(a) || M(o) ? null : /* @__PURE__ */ t.jsx(
    "div",
    {
      className: "absolute !cursor-grabbing note-drag-overlay",
      ref: u,
      onClick: () => {
        var x;
        if (o === Ps.CREATE) {
          const N = (x = u.current) == null ? void 0 : x.getBoundingClientRect();
          if (N) {
            const w = c.screenToFlowPosition({
              x: N.left,
              y: N.top
            });
            i({
              content: W.DEFAULT_NOTE_CONTENT,
              position: w,
              size: a.size,
              color: W.DEFAULT_NOTE_COLOR
            });
          }
        }
      },
      style: {
        left: v,
        top: g,
        height: `${a.size.height}px`,
        width: `${a.size.width}px`,
        transform: `scale(${c.getZoom()})`,
        transformOrigin: "0 0"
      },
      children: /* @__PURE__ */ t.jsx(
        ph,
        {
          isDragging: !0,
          note: {
            ...a
          }
        }
      )
    }
  );
}, _y = ({ step: e }) => {
  var u;
  const { cursorPosition: n } = Oc(), [s, r] = p.useState(n), a = document.getElementById(Oi), o = (a == null ? void 0 : a.clientWidth) ?? 0, i = `${s.x - W.STEP_DRAG_OVERLAY_WIDTH / 2 - o}px`, l = `${s.y - W.STEP_DRAG_OVERLAY_HEIGHT - 20}px`, { stepMetadata: c } = En.useStepMetadata({
    step: e
  });
  return by((d) => {
    r(d);
  }), /* @__PURE__ */ t.jsx(
    "div",
    {
      className: "p-4 absolute left-0 top-0 cursor-grabbing z-50  opacity-75  flex items-center justify-center rounded-2xl border border-solid border bg-background cursor-grabbing",
      style: {
        left: i,
        top: l,
        height: `${W.STEP_DRAG_OVERLAY_HEIGHT}px`,
        width: `${W.STEP_DRAG_OVERLAY_WIDTH}px`,
        zIndex: 99999
      },
      id: "dragged-step-overlay",
      children: /* @__PURE__ */ t.jsx(
        "img",
        {
          id: f("logo"),
          className: "object-contain left-0 right-0 static !cursor-grabbing",
          src: ((u = e == null ? void 0 : e.settings) == null ? void 0 : u.customLogoUrl) ?? (c == null ? void 0 : c.logoUrl),
          alt: f("Step Icon")
        }
      )
    }
  );
}, Ly = ({ children: e }) => {
  const n = Tn(), s = p.useRef({ x: 0, y: 0, zoom: 1 }), [r, a] = p.useState({ x: 0, y: 0 }), [
    o,
    i,
    l,
    c,
    u,
    d,
    h
  ] = F((N) => [
    N.setActiveDraggingStep,
    N.applyOperation,
    N.flowVersion,
    N.activeDraggingStep,
    N.setDraggedNote,
    N.getNoteById,
    N.moveNote
  ]), m = p.useCallback(
    (N) => {
      if (!N.pointerCoordinates)
        return Ha(N);
      const { x: w, y: b } = N.pointerCoordinates, { width: E, height: R } = N.collisionRect, S = n.getViewport(), C = s.current, T = {
        x: C.x - S.x,
        y: C.y - S.y
      }, I = {
        ...N,
        // The collision rectangle is broken when using snapCenterToCursor. Reset
        // the collision rectangle based on pointer location and overlay size.
        collisionRect: {
          width: E,
          height: R,
          bottom: b + R / 2 + T.y,
          left: w - E / 2 + T.x,
          right: w + E / 2 + T.x,
          top: b - R / 2 + T.y
        }
      };
      return Ha(I);
    },
    [n]
  ), y = c ? q.getStep(c, l.trigger) : void 0, v = (N) => {
    var w, b;
    if (((w = N.active.data.current) == null ? void 0 : w.type) === W.DRAGGED_STEP_TAG && o(N.active.id.toString()), ((b = N.active.data.current) == null ? void 0 : b.type) === W.DRAGGED_NOTE_TAG) {
      const E = d(N.active.id.toString());
      if (E) {
        const R = document.getElementById(N.active.id.toString());
        let S;
        if (R) {
          const C = R.getBoundingClientRect();
          S = {
            x: r.x - C.left,
            y: r.y - C.top
          };
        }
        u(E, Ps.MOVE, S);
      }
    }
    s.current = n.getViewport();
  }, g = p.useCallback(() => {
    o(null), u(null, null);
  }, [o, u]), j = (N) => {
    o(null), u(null, null), Fy({ e: N, applyOperation: i, activeDraggingStep: c, flowVersion: l }), zy({ e: N, getNoteById: d, moveNote: h, reactFlow: n });
  }, x = gh(
    Ga(Ic, {
      activationConstraint: {
        distance: 10
      },
      onActivation: ({ event: N }) => {
        N instanceof PointerEvent && a({ x: N.clientX, y: N.clientY });
      }
    }),
    Ga(xh)
  );
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsxs(
      vh,
      {
        onDragStart: v,
        onDragEnd: j,
        onDragCancel: g,
        sensors: x,
        collisionDetection: m,
        children: [
          e,
          /* @__PURE__ */ t.jsx(yh, { dropAnimation: { duration: 0 } })
        ]
      }
    ),
    y && /* @__PURE__ */ t.jsx(_y, { step: y }),
    /* @__PURE__ */ t.jsx(My, {})
  ] });
};
function Fy({
  e,
  applyOperation: n,
  activeDraggingStep: s,
  flowVersion: r
}) {
  var i, l, c, u, d;
  const a = s ? q.getStep(s, r.trigger) : void 0;
  if (!M((l = (i = e.over) == null ? void 0 : i.data) == null ? void 0 : l.current) && e.over.data.current.accepts === ((u = (c = e.active.data) == null ? void 0 : c.current) == null ? void 0 : u.type)) {
    const h = (d = e.over) == null ? void 0 : d.data.current;
    if (h != null && h.parentStepName && a && a.name !== h.parentStepName) {
      if (q.isChildOf(
        a,
        h.parentStepName
      )) {
        je(f("Invalid Move"), {
          description: f(
            "The destination location is a child of the dragged step"
          ),
          duration: 3e3
        });
        return;
      }
      n({
        type: ae.MOVE_ACTION,
        request: {
          name: a.name,
          newParentStep: h.parentStepName,
          stepLocationRelativeToNewParent: h.stepLocationRelativeToParent,
          branchIndex: h.stepLocationRelativeToParent === kt.INSIDE_BRANCH ? h.branchIndex : void 0
        }
      });
    }
  }
}
function zy({
  e,
  getNoteById: n,
  moveNote: s,
  reactFlow: r
}) {
  var a;
  if (((a = e.active.data.current) == null ? void 0 : a.type) === W.DRAGGED_NOTE_TAG) {
    const o = n(e.active.id.toString());
    if (o) {
      const i = document.getElementById(e.active.id.toString());
      if (i) {
        const l = r.screenToFlowPosition({
          x: i.getBoundingClientRect().left,
          y: i.getBoundingClientRect().top
        });
        s(o.id, l);
      }
    }
  }
}
class Ic extends jh {
}
Fa(Ic, "activators", [
  {
    eventName: "onPointerDown",
    handler: ({ nativeEvent: n }, { onActivation: s }) => {
      const r = n.target;
      return r != null && r.closest('[contenteditable="true"]') || !n.isPrimary || n.button !== 0 || $y(n.target) ? !1 : (s == null || s({ event: n }), !0);
    }
  }
]);
function $y(e) {
  const n = [
    "button",
    "input",
    "textarea",
    "select",
    "option"
  ];
  return !!(e != null && e.tagName && n.includes(e.tagName.toLowerCase()));
}
const Ac = ({
  flowVersion: e,
  selectStepByName: n
}) => {
  const s = p.useMemo(
    () => q.getAllSteps(e.trigger).filter(Yo).length,
    [e]
  ), { fitView: r } = Tn();
  function a() {
    const o = q.getAllSteps(e.trigger).filter(Yo);
    o.length > 0 && (n(o[0].name), r(
      _t.createFocusStepInGraphParams(o[0].name)
    ));
  }
  return !e.valid && /* @__PURE__ */ t.jsx(
    O,
    {
      variant: "ghost",
      className: "h-[28px] hover:bg-amber-50 p-2 dark:hover:bg-amber-950 dark:bg-amber-950 bg-amber-50 border border-solid border-amber-500 hover:border-amber-700 dark:hover:border-amber-600  dark:border-amber-900 dark:text-amber-600 text-amber-700 hover:text-amber-700 dark:hover:text-amber-600   animate-fade",
      onClick: (o) => {
        a(), o.stopPropagation(), o.preventDefault();
      },
      children: f("incompleteSteps", { invalidSteps: s })
    },
    "complete-flow-button"
  );
};
Ac.displayName = "IncompleteSettingsButton";
function Yo(e) {
  return e.skip ? !1 : !e.valid;
}
const Bs = ({
  onClick: e,
  text: n,
  disable: s = !1,
  loading: r = !1,
  showKeyboardShortcut: a = !0,
  shortCutIsEscape: o = !1,
  showPrimaryBg: i = !0
}) => {
  const l = pr();
  return p.useEffect(() => {
    const c = (u) => {
      const d = u.key === "Escape" && o, h = l && u.metaKey && u.key.toLocaleLowerCase() === "d" || !l && u.ctrlKey && u.key.toLocaleLowerCase() === "d";
      (d || h) && (u.preventDefault(), u.stopPropagation(), !r && !s && e());
    };
    return window.addEventListener("keydown", c, { capture: !0 }), () => {
      window.removeEventListener("keydown", c, { capture: !0 });
    };
  }, [pr, r, e]), /* @__PURE__ */ t.jsxs(te, { children: [
    /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx("div", { className: "bg-builder-background", children: /* @__PURE__ */ t.jsx(
      O,
      {
        variant: "ghost",
        className: $(
          "h-8 bg-background border-input hover:border-border  border p-2.5 border-solid rounded-lg animate-fade",
          {
            "bg-primary-100/50! dark:text-primary-foreground  text-primary hover:text-primary disabled:pointer-events-auto hover:border-primary!  border-primary/50": i
          }
        ),
        loading: r,
        disabled: s,
        onClick: e,
        children: /* @__PURE__ */ t.jsxs("div", { className: "flex justify-center items-center gap-2", children: [
          n,
          a && /* @__PURE__ */ t.jsx(
            "span",
            {
              className: $(
                "text-[10px] bg-muted h-[20px] flex items-center justify-center px-1 rounded-sm tracking-widest whitespace-nowrap text-muted-foreground",
                {
                  "bg-primary/13 text-primary": i
                }
              ),
              children: o ? "Esc" : l ? "⌘ + D" : "Ctrl + D"
            }
          )
        ] })
      }
    ) }) }),
    s && /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Please test the trigger first") })
  ] });
};
Bs.displayName = "AboveTriggerButton";
const Ks = ({ onCanvas: e }) => {
  const n = wh(), s = Xr(), { checkAccess: r } = Ve(), { switchToDraft: a, isSwitchingToDraftPending: o } = hn.useSwitchToDraft(), [i, l, c, u] = F(
    (g) => [g.flowVersion, g.flow.id, g.readonly, g.run]
  ), d = i.state === it.DRAFT, h = r(Ie.WRITE_FLOW);
  if (!c || d && !u)
    return null;
  const m = () => {
    var g;
    (g = n.pathname) != null && g.includes("/runs") ? s(`/flows/${l}`) : a();
  }, { text: y, icon: v } = Vy({
    hasPermissionToEditFlow: h
  });
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    e && /* @__PURE__ */ t.jsx(
      Bs,
      {
        shortCutIsEscape: !0,
        showPrimaryBg: !1,
        onClick: m,
        text: y
      }
    ),
    !e && /* @__PURE__ */ t.jsxs(
      O,
      {
        size: "sm",
        variant: "basic",
        loading: o,
        className: "gap-2",
        onClick: () => {
          var g;
          (g = n.pathname) != null && g.includes("/runs") ? s(`/flows/${l}`) : a();
        },
        children: [
          v,
          y
        ]
      }
    )
  ] });
};
Ks.displayName = "EditFlowOrViewDraftButton";
function Vy({
  hasPermissionToEditFlow: e
}) {
  const n = e ? f("Edit flow") : f("View draft");
  return e ? {
    icon: /* @__PURE__ */ t.jsx(zt, { className: "size-4" }),
    text: n
  } : {
    icon: /* @__PURE__ */ t.jsx(Rs, { className: "size-4" }),
    text: n
  };
}
const kc = () => {
  var y;
  const [
    e,
    n,
    s,
    r,
    a,
    o,
    i
  ] = F((v) => [
    v.setChatDrawerOpenSource,
    v.flowVersion,
    v.readonly,
    v.hideTestWidget,
    v.run,
    v.setRun,
    v.flow.publishedVersionId
  ]), l = p.useRef(a);
  l.current = a;
  const c = n.trigger.type === ee.PIECE && !M((y = n.trigger.settings.sampleData) == null ? void 0 : y.lastTestDate), u = lt.isChatTrigger(
    n.trigger.settings.pieceName,
    n.trigger.settings.triggerName
  ), d = lt.isManualTrigger({
    pieceName: n.trigger.settings.pieceName,
    triggerName: n.trigger.settings.triggerName
  }), { mutate: h, isPending: m } = Qe.useTestFlowOrStartManualTrigger({
    flowVersionId: n.id,
    isForManualTrigger: d,
    onUpdateRun: (v) => {
      var x, N, w, b, E;
      Nh(v.flowRun, "flowRun");
      const g = ((x = l.current) == null ? void 0 : x.steps) ?? {}, j = v.flowRun.startTime ?? ((N = l.current) == null ? void 0 : N.startTime);
      if (!M(v.step)) {
        const R = jn.updateRunSteps(
          g,
          (w = v.step) == null ? void 0 : w.name,
          (b = v.step) == null ? void 0 : b.path,
          (E = v.step) == null ? void 0 : E.output
        );
        o(
          { ...v.flowRun, startTime: j, steps: R },
          n
        );
      }
      o({ ...v.flowRun, startTime: j, steps: g }, n);
    }
  });
  return !n.valid || r || d && (i !== n.id || M(i)) ? null : s ? /* @__PURE__ */ t.jsx(Ks, { onCanvas: !0 }) : u ? /* @__PURE__ */ t.jsx(
    Bs,
    {
      onClick: () => {
        e(Yr.TEST_FLOW);
      },
      text: f("Open Chat"),
      loading: m
    }
  ) : /* @__PURE__ */ t.jsx(
    Bs,
    {
      onClick: () => {
        h();
      },
      text: d ? f("Run Flow") : f("Test Flow"),
      disable: !c && !d,
      loading: m
    }
  );
};
kc.displayName = "TestFlowWidget";
const Mc = k.memo(() => {
  const [e, n, s] = F(
    (r) => [r.flowVersion, r.selectStepByName, r.readonly]
  );
  return /* @__PURE__ */ t.jsx(Ii, { children: /* @__PURE__ */ t.jsx(_c, { children: /* @__PURE__ */ t.jsx(
    "div",
    {
      style: {
        transform: `translate(0px,-${W.AP_NODE_SIZE.STEP.height}px )`,
        position: "absolute",
        pointerEvents: "auto"
      },
      children: /* @__PURE__ */ t.jsxs("div", { className: "justify-center items-center flex w-[260px]", children: [
        /* @__PURE__ */ t.jsx(kc, {}),
        !s && /* @__PURE__ */ t.jsx(
          Ac,
          {
            flowVersion: e,
            selectStepByName: n
          }
        )
      ] })
    }
  ) }) });
});
Mc.displayName = "AboveFlowWidgets";
const By = k.memo(() => /* @__PURE__ */ t.jsx(Ii, { children: /* @__PURE__ */ t.jsx(_c, { children: /* @__PURE__ */ t.jsx(
  "div",
  {
    style: {
      pointerEvents: "auto"
    },
    children: /* @__PURE__ */ t.jsx(
      "div",
      {
        className: "flex items-center justify-center gap-2",
        style: { width: W.AP_NODE_SIZE.STEP.width + "px" },
        children: /* @__PURE__ */ t.jsx(bh, {})
      }
    )
  }
) }) })), _c = ({ children: e }) => /* @__PURE__ */ t.jsx(
  "div",
  {
    style: { width: W.AP_NODE_SIZE.STEP.width + "px" },
    className: "flex items-center justify-center",
    children: e
  }
);
By.displayName = "BelowFlowWidget";
const Uy = () => {
  const [e] = F((r) => [r.showMinimap]), { theme: n } = Ai(), s = n === "dark" ? 0.8 : 0.055;
  return /* @__PURE__ */ t.jsx(t.Fragment, { children: e && /* @__PURE__ */ t.jsx(
    Sh,
    {
      position: "bottom-left",
      className: "!rounded-md border border-border !left-0 !ml-2 overflow-hidden !bottom-[45px] animate-in fade-in duration-300",
      zoomable: !0,
      pannable: !0,
      zoomStep: 0.3,
      bgColor: "var(--background)",
      maskColor: `rgba(0, 0, 0, ${s})`,
      nodeComponent: (r) => /* @__PURE__ */ t.jsx(Gy, { node: r })
    }
  ) });
}, Wy = ({
  stepMetadata: e,
  node: n
}) => {
  const s = Ch.useAverageColorInImage({
    imgUrl: e.logoUrl ?? "",
    transparency: 50
  });
  return /* @__PURE__ */ t.jsx(
    "rect",
    {
      width: n.width,
      height: n.height,
      x: n.x,
      y: n.y,
      fill: s ?? "oklch(92.8% 0.006 264.531)"
    },
    n.id
  );
}, Hy = ({
  step: e,
  node: n
}) => {
  const { stepMetadata: s } = En.useStepMetadata({
    step: e
  });
  return M(s) ? null : /* @__PURE__ */ t.jsx(Wy, { stepMetadata: s, node: n });
}, Gy = ({ node: e }) => {
  const [n] = F((r) => [
    r.flowVersion.trigger
  ]), s = q.getStep(e.id, n);
  return M(s) ? null : /* @__PURE__ */ t.jsx(Hy, { step: s, node: e });
}, qy = (e) => {
  const n = document.createElement("div");
  e.appendChild(n);
  const s = Eh.createRoot(n);
  return s.render(
    /* @__PURE__ */ t.jsx(
      O,
      {
        variant: "outline",
        size: "icon",
        className: "absolute top-[10px] -left-10 z-50",
        [`data-${W.SELECTION_RECT_CHEVRON_ATTRIBUTE}`]: !0,
        onClick: (r) => {
          const a = new MouseEvent("contextmenu", {
            bubbles: !0,
            cancelable: !0,
            view: window,
            button: 2,
            clientX: r.clientX,
            clientY: r.clientY
          });
          r.target.dispatchEvent(a);
        },
        children: /* @__PURE__ */ t.jsx(Gr, { className: "w-4 h-4" })
      }
    )
  ), s;
}, Ky = () => {
  p.useEffect(() => {
    let e = null;
    const n = new MutationObserver((s) => {
      s.forEach((r) => {
        r.addedNodes.forEach((a) => {
          a instanceof HTMLElement && a.children.length > 0 && a.children[0].classList.contains(
            W.NODE_SELECTION_RECT_CLASS_NAME
          ) && (e = qy(a.children[0]));
        }), r.removedNodes.forEach((a) => {
          a instanceof HTMLElement && a.children.length > 0 && a.children[0].classList.contains(
            W.NODE_SELECTION_RECT_CLASS_NAME
          ) && e && (e.unmount(), e = null);
        });
      });
    });
    return n.observe(document.body, {
      childList: !0,
      subtree: !0
    }), () => {
      n.disconnect(), e && e.unmount();
    };
  }, []);
}, Lc = k.memo(
  ({
    setHasCanvasBeenInitialised: e
  }) => {
    const [
      n,
      s,
      r,
      a,
      o,
      i,
      l,
      c
    ] = F((R) => [
      R.flowVersion,
      R.setSelectedNodes,
      R.selectedNodes,
      R.selectedStep,
      R.panningMode,
      R.selectStepByName,
      R.rightSidebar,
      R.flowVersion.notes
    ]), u = p.useRef(null);
    Ky(), hn.useFocusOnStep(), jy(), hn.useResizeCanvas(u, e);
    const d = Th(), m = !mr("Shift") && o === "grab", y = p.useCallback(
      (R) => {
        const S = R.nodes.map((C) => C.id);
        S.length === 0 && a && S.push(a), s(S);
      },
      [s, a]
    ), v = Xy(n, c, a ?? ""), g = p.useMemo(() => _t.createFlowGraph(n, c), [v]), [j, x] = p.useState(
      Ae.CANVAS
    ), N = p.useCallback(
      (R) => {
        var S;
        if (R.target instanceof HTMLElement || R.target instanceof SVGElement) {
          const C = R.target.closest(
            `[data-${W.STEP_CONTEXT_MENU_ATTRIBUTE}]`
          ), T = C == null ? void 0 : C.getAttribute(
            `data-${W.STEP_CONTEXT_MENU_ATTRIBUTE}`
          );
          C && T && (i(T), d.getState().addSelectedNodes([T]));
          const I = R.target.closest(
            `[data-${W.SELECTION_RECT_CHEVRON_ATTRIBUTE}]`
          ), P = R.target.classList.contains(
            W.NODE_SELECTION_RECT_CLASS_NAME
          );
          x(C || P || I ? Ae.STEP : Ae.CANVAS), !P && !I && ((S = document.querySelector(
            `.${W.NODE_SELECTION_RECT_CLASS_NAME}`
          )) == null || S.remove());
        }
      },
      [s, r, l]
    ), w = p.useCallback(() => {
      if (document.querySelector(
        `.${W.NODE_SELECTION_RECT_CLASS_NAME}`
      ) !== null) {
        d.getState().addSelectedNodes([]);
        return;
      }
      const S = r.map((T) => q.getStep(T, n.trigger)).filter((T) => !M(T));
      S.forEach((T) => {
        if (T.type === Y.LOOP_ON_ITEMS || T.type === Y.ROUTER) {
          const I = q.getAllChildSteps(T).filter((P) => M(r.find((D) => D === P.name)));
          S.push(...I);
        }
      });
      const C = a ? q.getStep(a, n.trigger) : null;
      r.length === 0 && C && S.push(C), d.getState().addSelectedNodes(S.map((T) => T.name));
    }, [r, d, a]), { setCursorPosition: b } = Oc(), E = p.useMemo(() => {
      const R = window.innerWidth, S = window.innerHeight + 100, C = g.nodes, T = Ph(C), I = {
        x: T.x - R,
        y: T.y - S
      }, P = {
        x: T.x + T.width + R,
        y: T.y + T.height + S
      };
      return [
        [I.x, I.y],
        [P.x, P.y]
      ];
    }, [v]);
    return /* @__PURE__ */ t.jsx(
      "div",
      {
        ref: u,
        className: "size-full relative overflow-hidden z-30 bg-builder-background",
        onMouseMove: (R) => {
          const S = { x: R.clientX, y: R.clientY };
          b(S);
        },
        children: /* @__PURE__ */ t.jsx(Ly, { children: /* @__PURE__ */ t.jsx(Oy, { contextMenuType: j, children: /* @__PURE__ */ t.jsxs(
          Dh,
          {
            className: "bg-builder-background",
            onContextMenu: N,
            onPaneClick: () => {
              d.getState().unselectNodesAndEdges();
            },
            translateExtent: E,
            nodeTypes: W.nodeTypes,
            nodes: g.nodes,
            edgeTypes: W.edgeTypes,
            edges: g.edges,
            draggable: !1,
            edgesFocusable: !1,
            elevateEdgesOnSelect: !1,
            maxZoom: 1.5,
            minZoom: 0.5,
            panOnDrag: m ? [0, 1] : [1],
            zoomOnDoubleClick: !1,
            panOnScroll: !0,
            panOnScrollMode: Oh.Free,
            fitView: !1,
            nodesConnectable: !1,
            elementsSelectable: !0,
            nodesDraggable: !1,
            nodesFocusable: !1,
            selectionKeyCode: m ? "Shift" : null,
            multiSelectionKeyCode: m ? "Shift" : null,
            selectionOnDrag: !m,
            selectNodesOnDrag: !0,
            selectionMode: Rh.Partial,
            onSelectionChange: y,
            onSelectionEnd: w,
            children: [
              /* @__PURE__ */ t.jsx(Mc, {}),
              /* @__PURE__ */ t.jsx(
                Ih,
                {
                  gap: 10,
                  size: 1,
                  variant: Ah.Dots,
                  bgColor: "var(--builder-background)",
                  color: "var(--builder-background-pattern)"
                }
              ),
              /* @__PURE__ */ t.jsx(Uy, {}, v)
            ]
          }
        ) }) })
      }
    );
  }
);
Lc.displayName = "FlowCanvas";
const Yy = (e) => {
  switch (e.type) {
    case Y.LOOP_ON_ITEMS:
      return e.firstLoopAction ? e.firstLoopAction.name : "";
    case Y.ROUTER:
      return e.children.reduce((n, s) => {
        const r = s ? q.getAllSteps(s).reduce(
          (a, o) => `${a}-${o.name}`,
          ""
        ) : "null";
        return `${n}-${r}`;
      }, "");
    case Y.CODE:
    case Y.PIECE:
      return "";
  }
}, Xy = (e, n, s) => {
  const r = q.getAllSteps(e.trigger).reduce((o, i) => {
    const l = i.type === Y.ROUTER ? i.settings.branches.map((u) => u.branchName).join("-") : "0", c = Yy(i);
    return `${o}-${i.displayName}-${i.type}-${i.nextAction ? i.nextAction.name : ""}-${i.type === Y.PIECE || i.type === ee.PIECE ? `${i.settings.pieceName}-${i.settings.pieceVersion}` : ""}-${l}-${c}}`;
  }, ""), a = n.map((o) => `${o.id}-${o.position.x}-${o.position.y}`).join("-");
  return `${e.id}-${r}-${a}-${s}`;
};
function Fc({
  lockedBy: e,
  takeOver: n,
  resourceLabel: s
}) {
  return /* @__PURE__ */ t.jsx("div", { className: "absolute top-[12px] z-40 w-full px-2 flex justify-center", children: /* @__PURE__ */ t.jsxs("div", { className: "py-1.5 px-3.5 border min-h-11.5 border-border bg-background z-40 w-full animate animate-fade duration-300 rounded-md flex items-center justify-between", children: [
    /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ t.jsx(kh, { className: "size-5" }),
      /* @__PURE__ */ t.jsx("span", { children: f(
        "{name} is editing this {resource}. Only one person can edit at a time.",
        {
          name: e.userDisplayName,
          resource: s
        }
      ) })
    ] }),
    /* @__PURE__ */ t.jsx(O, { variant: "ghost", size: "sm", onClick: n, children: f("Take Over") })
  ] }) });
}
Fc.displayName = "ResourceLockWidget";
const Ys = ({
  children: e,
  containerClassName: n
}) => /* @__PURE__ */ t.jsx("div", { className: "absolute top-[12px] z-40 w-full px-2 flex justify-center", children: /* @__PURE__ */ t.jsx(
  "div",
  {
    className: $(
      "py-1.5 px-3.5 border min-h-11.5  border border-border  bg-background z-40  w-full animate animate-fade duration-300 rounded-md  flex items-center justify-between",
      n
    ),
    children: e
  }
) });
Ys.displayName = "LargeWidgetWrapper";
const zc = () => {
  const [
    e,
    n,
    s,
    r,
    a,
    o,
    i,
    l,
    c,
    u
  ] = F((x) => [
    x.saving,
    x.isPublishing,
    x.setIsPublishing,
    x.flowVersion.valid,
    x.flow,
    x.setFlow,
    x.setVersion,
    x.setRightSidebar,
    x.flowVersion,
    x.run
  ]), d = Jy({
    flowVersion: c,
    isPublishing: n,
    run: u,
    isSaving: e
  }), { mutate: h, isPending: m } = Re(
    {
      mutationFn: async () => {
        a.publishedVersionId && (await v({
          flowId: a.id,
          versionId: a.publishedVersionId
        }), await y());
      }
    }
  ), { mutateAsync: y } = Qe.useChangeFlowStatus({
    flowId: a.id,
    change: "publish",
    onSuccess: (x) => {
      o(x), i(x.version);
    },
    setIsPublishing: s
  }), { mutateAsync: v } = Qe.useOverWriteDraftWithVersion({
    onSuccess: (x) => {
      i(x.version), l(ye.NONE);
    }
  });
  if (!d)
    return null;
  const g = n || m || e, j = Qy({
    isDiscardingChanges: m,
    isPublishing: n,
    isSaving: e
  });
  return /* @__PURE__ */ t.jsxs(Ys, { children: [
    /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ t.jsx($t, { className: "size-5" }),
      g ? j : f("You have unpublished changes")
    ] }),
    g ? /* @__PURE__ */ t.jsx(Gn, { className: "size-5 stroke-foreground" }) : /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
      !M(a.publishedVersionId) && !e && /* @__PURE__ */ t.jsx(
        O,
        {
          size: "sm",
          variant: "ghost",
          className: "hover:bg-gray-300/10 text-foreground",
          onClick: () => h(),
          children: f("Discard changes")
        }
      ),
      /* @__PURE__ */ t.jsxs(te, { children: [
        /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx("div", { className: "tooltip-wrapper", children: /* @__PURE__ */ t.jsx(
          O,
          {
            size: "sm",
            variant: "default",
            className: "z-50",
            loading: e,
            name: "Publish",
            onClick: () => y(),
            disabled: !r,
            children: f("Publish")
          }
        ) }) }),
        e && /* @__PURE__ */ t.jsx(Q, { children: f("Saving...") }),
        !r && /* @__PURE__ */ t.jsx(Q, { children: f("You have incomplete steps") })
      ] })
    ] })
  ] });
};
zc.displayName = "PublishFlowReminderWidget";
const Jy = ({
  flowVersion: e,
  isPublishing: n,
  run: s,
  isSaving: r
}) => {
  const { checkAccess: a } = Ve(), o = a(Ie.WRITE_FLOW), i = e.state === it.DRAFT;
  return (o && i || n || r) && M(s);
};
function Qy({
  isDiscardingChanges: e,
  isPublishing: n,
  isSaving: s
}) {
  return s ? f("Saving...") : e ? f("Discarding changes...") : n ? f("Publishing...") : "";
}
function Zy({
  status: e,
  timeout: n,
  memoryLimit: s,
  logSizeLimit: r
}) {
  switch (e) {
    case Ne.SUCCEEDED:
      return f("Run Succeeded");
    case Ne.FAILED:
      return f("Run Failed");
    case Ne.PAUSED:
      return f("Run Paused");
    case Ne.QUOTA_EXCEEDED:
      return f("Quota Exceeded");
    case Ne.LOG_SIZE_EXCEEDED:
      return f(
        "Run failed due to output of steps exceeding the log size limit of {logSizeLimit} MB",
        { logSizeLimit: r }
      );
    case Ne.MEMORY_LIMIT_EXCEEDED:
      return f(
        "Run failed due to exceeding the memory limit of {memoryLimit} MB",
        {
          memoryLimit: Math.floor(s / 1024)
        }
      );
    case Ne.QUEUED:
      return f("Queued");
    case Ne.RUNNING:
      return f("Running");
    case Ne.TIMEOUT:
      return f("Run exceeded {timeout} seconds, try to optimize your steps.", {
        timeout: n
      });
    case Ne.INTERNAL_ERROR:
      return f("Run failed for an unknown reason, contact support.");
    case Ne.CANCELED:
      return f("Run Cancelled");
  }
}
const $c = () => {
  const e = F((l) => l.run), { variant: n, Icon: s } = e ? jn.getStatusIcon(e.status) : { variant: "default", Icon: Pi }, { data: r } = Me.useFlag(
    ze.FLOW_RUN_TIME_SECONDS
  ), { data: a } = Me.useFlag(
    ze.FLOW_RUN_MEMORY_LIMIT_KB
  ), { data: o } = Me.useFlag(
    ze.FLOW_RUN_LOG_SIZE_LIMIT_MB
  );
  if (!e)
    return null;
  const i = rs({
    status: e.status,
    ignoreInternalError: !1
  });
  return /* @__PURE__ */ t.jsx(
    Ys,
    {
      containerClassName: $(
        jn.getStatusContainerClassName(n),
        "bg-background border border-border dark:bg-background dark:border-border"
      ),
      children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between w-full flex-wrap", children: [
        /* @__PURE__ */ t.jsxs("div", { className: "flex items-center text-sm shrink-0", children: [
          /* @__PURE__ */ t.jsx(s, { className: "size-5 mr-2" }),
          /* @__PURE__ */ t.jsx("span", { className: "text-foreground dark:text-foreground font-medium", children: Zy({
            status: e.status,
            timeout: r ?? -1,
            memoryLimit: a ?? -1,
            logSizeLimit: o ?? -1
          }) }),
          /* @__PURE__ */ t.jsx("div", { className: "shrink-0 text-foreground dark:text-foreground", children: i && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
            " - ",
            e.startTime && /* @__PURE__ */ t.jsx(
              Xo,
              {
                text: f("Started"),
                dateOrDuration: qn.formatDateWithTime(
                  new Date(e.startTime),
                  !0
                )
              }
            ),
            ", ",
            e.finishTime && e.startTime && /* @__PURE__ */ t.jsx(
              Xo,
              {
                text: f("Took"),
                dateOrDuration: qn.formatDuration(
                  new Date(e.finishTime).getTime() - new Date(e.startTime).getTime()
                )
              }
            )
          ] }) })
        ] }),
        /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ t.jsx(ej, { isRunTerminal: i }),
          e.failedStep && /* @__PURE__ */ t.jsx(tj, { failedStepName: e.failedStep.name }),
          /* @__PURE__ */ t.jsx(
            Ks,
            {
              onCanvas: !1
            }
          )
        ] })
      ] })
    },
    e.id + e.status
  );
};
$c.displayName = "RunInfoWidget";
const Xo = ({
  text: e,
  dateOrDuration: n
}) => /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
  /* @__PURE__ */ t.jsx("span", { children: `${e}: ` }),
  /* @__PURE__ */ t.jsx("span", { children: `${n}` })
] }), ej = ({
  isRunTerminal: e
}) => {
  const [n, s] = F((r) => [
    r.userManuallySelectedStepDuringRun,
    r.resumeLiveFollow
  ]);
  return e || !n ? null : /* @__PURE__ */ t.jsxs(O, { variant: "ghost", size: "sm", onClick: s, children: [
    /* @__PURE__ */ t.jsx(Nm, { className: "size-4" }),
    f("Follow run updates")
  ] });
}, tj = ({
  failedStepName: e
}) => {
  const [n, s, r, a] = F((c) => [
    c.selectedStep,
    c.selectFailedStep,
    c.run,
    c.loopsIndexes
  ]), { fitView: o } = Tn(), i = r && n ? jn.extractStepOutput(
    n,
    a,
    r.steps ?? {}
  ) : null;
  if (n === e && (i == null ? void 0 : i.status) === fn.FAILED)
    return null;
  const l = () => {
    s(), o(_t.createFocusStepInGraphParams(e));
  };
  return /* @__PURE__ */ t.jsxs(
    O,
    {
      variant: "ghost",
      size: "sm",
      onClick: l,
      className: "text-destructive-700 hover:text-destructive-700 dark:text-destructive-200 dark:hover:text-destructive-200",
      children: [
        /* @__PURE__ */ t.jsx(yi, { className: "size-4" }),
        f("See error")
      ]
    }
  );
};
function nj() {
  const [e, n, s] = F((i) => [
    i.readonly,
    i.flow.id,
    i.setReadOnly
  ]), r = p.useRef(!1), { lockedBy: a, takeOver: o } = Xf({
    resourceId: n
  });
  return p.useEffect(() => {
    a && !e && (r.current = !0, s(!0)), !a && r.current && (r.current = !1, s(!1));
  }, [a, e, s]), { lockedBy: a, takeOver: o };
}
const Vc = ({
  onConfirm: e,
  children: n,
  versionId: s,
  versionNumber: r
}) => {
  const { checkAccess: a } = Ve(), [o, i, l] = F(
    (y) => [y.setVersion, y.setRightSidebar, y.flow]
  ), { mutate: c, isPending: u } = Qe.useOverWriteDraftWithVersion({
    onSuccess: (y) => {
      o(y.version), i(ye.NONE);
    }
  }), d = a(Ie.WRITE_FLOW), [h, m] = p.useState(!1);
  return /* @__PURE__ */ t.jsxs(ut, { open: h, onOpenChange: m, children: [
    /* @__PURE__ */ t.jsx(
      ki,
      {
        disabled: !d,
        className: "w-full",
        children: /* @__PURE__ */ t.jsx(Fe, { hasPermission: d, children: n })
      }
    ),
    /* @__PURE__ */ t.jsxs(ht, { children: [
      /* @__PURE__ */ t.jsxs(ft, { children: [
        /* @__PURE__ */ t.jsx(mt, { children: f("Overwrite Draft") }),
        /* @__PURE__ */ t.jsxs(Zr, { children: [
          f("Your current draft will be replaced with"),
          " ",
          /* @__PURE__ */ t.jsx("span", { className: "font-semibold", children: f("version #{versionNumber}", { versionNumber: r }) }),
          ". ",
          f("This cannot be undone.")
        ] })
      ] }),
      /* @__PURE__ */ t.jsxs(pt, { className: "justify-end", children: [
        /* @__PURE__ */ t.jsx(yn, { asChild: !0, children: /* @__PURE__ */ t.jsx(O, { variant: "outline", children: f("Cancel") }) }),
        /* @__PURE__ */ t.jsx(yn, { asChild: !0, children: /* @__PURE__ */ t.jsx(
          O,
          {
            loading: u,
            onClick: () => {
              c({
                flowId: l.id,
                versionId: s
              }), e == null || e();
            },
            children: f("Overwrite")
          }
        ) })
      ] })
    ] })
  ] });
}, sj = () => {
  const [e, n, s, r] = F(
    (l) => [
      l.run,
      l.readonly,
      l.flowVersion,
      l.isPublishing
    ]
  ), a = Qe.useGetFlowVersionNumber({ flowId: s.flowId, versionId: s.id }).toString(), { checkAccess: o } = Ve(), i = o(Ie.WRITE_FLOW);
  return !M(e) || !n || r ? null : /* @__PURE__ */ t.jsx(Ys, { children: /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ t.jsx($t, { className: "size-5" }),
      /* @__PURE__ */ t.jsxs("span", { children: [
        f("Viewing version"),
        " #",
        a
      ] })
    ] }),
    /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
      i && /* @__PURE__ */ t.jsx(
        Vc,
        {
          versionId: s.id,
          versionNumber: a,
          onConfirm: void 0,
          children: /* @__PURE__ */ t.jsx(O, { variant: "ghost", size: "sm", children: f("Use as Draft") })
        }
      ),
      /* @__PURE__ */ t.jsx(
        Ks,
        {
          onCanvas: !1
        }
      )
    ] })
  ] }) });
}, Bc = () => {
  const { lockedBy: e, takeOver: n } = nj(), s = F((r) => r.run);
  return e ? /* @__PURE__ */ t.jsx(
    Fc,
    {
      lockedBy: e,
      takeOver: n,
      resourceLabel: "flow"
    }
  ) : M(s) ? /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsx(sj, {}),
    /* @__PURE__ */ t.jsx(zc, {})
  ] }) : /* @__PURE__ */ t.jsx($c, {});
};
Bc.displayName = "BuilderBanner";
const Na = ({
  children: e,
  onClose: n,
  leadingIcon: s,
  actions: r
}) => /* @__PURE__ */ t.jsxs("div", { className: "flex px-3 py-2 w-full gap-2 text-base items-center min-h-[44px]", children: [
  s && /* @__PURE__ */ t.jsx("div", { className: "shrink-0", children: s }),
  /* @__PURE__ */ t.jsx("div", { className: "flex items-center gap-2 min-w-0 grow", children: e }),
  r,
  /* @__PURE__ */ t.jsx(
    O,
    {
      variant: "ghost",
      size: "sm",
      onClick: (a) => {
        a.stopPropagation(), n();
      },
      "aria-label": f("Close"),
      children: /* @__PURE__ */ t.jsx(Cn, { size: 16 })
    }
  )
] }), Uc = k.memo(
  ({
    flowVersion: e,
    selected: n,
    publishedVersionId: s,
    flowVersionNumber: r
  }) => {
    const { checkAccess: a } = Ve(), o = a(Ie.WRITE_FLOW), [i, l] = F((y) => [
      y.setVersion,
      y.setReadOnly
    ]), [c, u] = p.useState(!1), { mutate: d, isPending: h } = Qe.useFetchFlowVersion({
      onSuccess: (y) => {
        i(y), l(
          y.state === it.LOCKED || !o
        );
      }
    }), m = !ss().embedState.isEmbedded;
    return /* @__PURE__ */ t.jsxs(Mi, { interactive: !1, className: "px-4", children: [
      m && e.updatedByUser && /* @__PURE__ */ t.jsx(
        Mh,
        {
          size: 45,
          withoutBorder: !0,
          name: e.updatedByUser.firstName + " " + e.updatedByUser.lastName,
          email: e.updatedByUser.email
        }
      ),
      /* @__PURE__ */ t.jsxs("div", { className: "grid gap-2", children: [
        /* @__PURE__ */ t.jsx(
          _i,
          {
            date: new Date(e.created),
            includeTime: !0,
            className: "text-sm font-medium leading-none select-none cursor-default"
          }
        ),
        /* @__PURE__ */ t.jsxs("p", { className: "flex gap-1 text-xs text-muted-foreground", children: [
          f("Version"),
          " #",
          r
        ] })
      ] }),
      /* @__PURE__ */ t.jsx("div", { className: "grow" }),
      /* @__PURE__ */ t.jsxs("div", { className: "flex font-medium gap-2 justify-center items-center", children: [
        n && /* @__PURE__ */ t.jsxs(te, { children: [
          /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx("div", { className: "size-10 flex justify-center items-center", children: /* @__PURE__ */ t.jsx(Rs, { className: "w-5 h-5 " }) }) }),
          /* @__PURE__ */ t.jsx(Q, { children: f("Viewing") })
        ] }),
        /* @__PURE__ */ t.jsx(
          Ei,
          {
            state: e.state,
            versionId: e.id,
            publishedVersionId: s
          }
        ),
        /* @__PURE__ */ t.jsxs(
          Yn,
          {
            onOpenChange: (y) => u(y),
            open: c,
            children: [
              /* @__PURE__ */ t.jsx(Xn, { asChild: !0, children: /* @__PURE__ */ t.jsx(O, { variant: "ghost", disabled: h, size: "icon", children: /* @__PURE__ */ t.jsx(_h, {}) }) }),
              /* @__PURE__ */ t.jsxs(Jn, { className: "w-40", children: [
                /* @__PURE__ */ t.jsxs(
                  me,
                  {
                    onClick: () => d(e),
                    className: "w-full",
                    children: [
                      /* @__PURE__ */ t.jsx(Rs, { className: "mr-2 h-4 w-4" }),
                      /* @__PURE__ */ t.jsx("span", { children: f("View") })
                    ]
                  }
                ),
                e.state !== it.DRAFT && /* @__PURE__ */ t.jsx(
                  Vc,
                  {
                    versionNumber: r.toString(),
                    versionId: e.id,
                    onConfirm: () => {
                      u(!1);
                    },
                    children: /* @__PURE__ */ t.jsxs(
                      me,
                      {
                        className: "w-full",
                        onSelect: (y) => {
                          y.preventDefault();
                        },
                        disabled: !o,
                        children: [
                          /* @__PURE__ */ t.jsx(zt, { className: "mr-2 h-4 w-4" }),
                          /* @__PURE__ */ t.jsx("span", { children: f("Use as Draft") })
                        ]
                      }
                    )
                  }
                )
              ] })
            ]
          }
        )
      ] })
    ] });
  }
);
Uc.displayName = "FlowVersionDetailsCard";
const Wc = () => {
  const [e, n, s] = F(
    (i) => [i.flow, i.setRightSidebar, i.flowVersion]
  ), {
    data: r,
    isLoading: a,
    isError: o
  } = Qe.useListFlowVersions(e.id);
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsx(Na, { onClose: () => n(ye.NONE), children: f("Version History") }),
    /* @__PURE__ */ t.jsxs(Lh, { children: [
      a && /* @__PURE__ */ t.jsx(Li, { numberOfCards: 10 }),
      o && /* @__PURE__ */ t.jsx("div", { children: f("Error, please try again.") }),
      r && r.data && /* @__PURE__ */ t.jsx(Ze, { className: "w-full h-full", children: r.data.map((i, l) => /* @__PURE__ */ t.jsx(
        Uc,
        {
          selected: i.id === (s == null ? void 0 : s.id),
          publishedVersionId: e.publishedVersionId,
          flowVersion: i,
          flowVersionNumber: r.data.length - l
        },
        i.id
      )) })
    ] })
  ] });
};
Wc.displayName = "FlowVersionsList";
const Hc = 70, Gc = k.memo(
  ({ run: e, viewedRunId: n, refetchRuns: s }) => {
    const { Icon: r, variant: a } = jn.getStatusIcon(e.status), o = Ve().checkAccess(
      Ie.WRITE_RUN
    ), i = oe.getProjectId(), l = Xr(), [c, u] = p.useState(!1), { mutate: d, isPending: h } = Fh.useRetryRun({
      onSuccess: ({ run: m }) => {
        s(), l(`/runs/${m.id}`);
      }
    });
    return /* @__PURE__ */ t.jsxs(
      Mi,
      {
        className: $("px-3 group", {
          "bg-accent text-accent-foreground": e.id === n
        }),
        style: { height: `${Hc}px` },
        onClick: () => {
          l(`/runs/${e.id}`);
        },
        children: [
          /* @__PURE__ */ t.jsx("div", { children: /* @__PURE__ */ t.jsx("span", { children: e.status === Ne.CANCELED ? /* @__PURE__ */ t.jsxs(te, { children: [
            /* @__PURE__ */ t.jsx(ne, { children: /* @__PURE__ */ t.jsx(
              r,
              {
                className: $("w-5 h-5", {
                  "text-success": a === "success",
                  "text-destructive": a === "error"
                })
              }
            ) }),
            /* @__PURE__ */ t.jsx(Q, { children: f("Canceled") })
          ] }) : /* @__PURE__ */ t.jsx(
            r,
            {
              className: $("w-5 h-5", {
                "text-success": a === "success",
                "text-destructive": a === "error"
              })
            }
          ) }) }),
          /* @__PURE__ */ t.jsxs("div", { className: "grid gap-2", children: [
            /* @__PURE__ */ t.jsxs("div", { className: "text-sm font-medium leading-none flex gap-2 items-center", children: [
              /* @__PURE__ */ t.jsx(
                _i,
                {
                  date: new Date(e.created ?? /* @__PURE__ */ new Date()),
                  includeTime: !0,
                  className: "text-sm font-medium leading-none select-none cursor-default"
                }
              ),
              e.id === n && /* @__PURE__ */ t.jsx(Rs, { className: "w-3.5 h-3.5" })
            ] }),
            rs({
              status: e.status,
              ignoreInternalError: !1
            }) && /* @__PURE__ */ t.jsxs("p", { className: "flex gap-1 text-xs text-muted-foreground", children: [
              /* @__PURE__ */ t.jsx(zh, { className: "h-3.5 w-3.5" }),
              f("Took"),
              " ",
              qn.formatDuration(
                e.startTime && e.finishTime ? new Date(e.finishTime).getTime() - new Date(e.startTime).getTime() : void 0,
                !1
              )
            ] }),
            e.status === Ne.RUNNING && /* @__PURE__ */ t.jsxs("p", { className: "flex gap-1 text-xs text-muted-foreground", children: [
              f("Running"),
              "..."
            ] }),
            e.status === Ne.QUEUED && /* @__PURE__ */ t.jsxs("p", { className: "flex gap-1 text-xs text-muted-foreground", children: [
              f("Queued"),
              "..."
            ] })
          ] }),
          /* @__PURE__ */ t.jsxs("div", { className: "ml-auto font-medium", children: [
            h && /* @__PURE__ */ t.jsx(Gn, { className: "size-4" }),
            !h && /* @__PURE__ */ t.jsx(
              Fe,
              {
                hasPermission: o,
                children: /* @__PURE__ */ t.jsxs(
                  Yn,
                  {
                    modal: !1,
                    open: c,
                    onOpenChange: u,
                    children: [
                      /* @__PURE__ */ t.jsxs(te, { children: [
                        /* @__PURE__ */ t.jsx(ne, { children: /* @__PURE__ */ t.jsx(Xn, { children: /* @__PURE__ */ t.jsx(
                          O,
                          {
                            variant: "ghost",
                            size: "icon",
                            className: $(
                              "group-hover:opacity-100 opacity-0 rounded-full bg-accent drop-shadow-md",
                              {
                                "opacity-100": c
                              }
                            ),
                            onClick: (m) => {
                              m.preventDefault(), m.stopPropagation();
                            },
                            children: /* @__PURE__ */ t.jsx(Rm, { className: "w-4 h-4" })
                          }
                        ) }) }),
                        /* @__PURE__ */ t.jsx(Q, { children: f("Retry run") })
                      ] }),
                      /* @__PURE__ */ t.jsxs(Jn, { children: [
                        /* @__PURE__ */ t.jsx(
                          me,
                          {
                            disabled: !o,
                            onClick: (m) => {
                              m.preventDefault(), m.stopPropagation(), d({
                                runId: e.id,
                                flowId: e.flowId,
                                projectId: i,
                                retryStrategy: qa.ON_LATEST_VERSION
                              });
                            },
                            className: "cursor-pointer",
                            children: /* @__PURE__ */ t.jsx("div", { className: "flex flex-row gap-2 items-center", children: /* @__PURE__ */ t.jsx("span", { children: f("On latest version") }) })
                          }
                        ),
                        $h(e.status) && /* @__PURE__ */ t.jsx(
                          me,
                          {
                            onClick: (m) => {
                              m.preventDefault(), m.stopPropagation(), h || d({
                                runId: e.id,
                                flowId: e.flowId,
                                projectId: i,
                                retryStrategy: qa.FROM_FAILED_STEP
                              });
                            },
                            className: "cursor-pointer",
                            children: /* @__PURE__ */ t.jsx("div", { className: "flex flex-row gap-2 items-center", children: /* @__PURE__ */ t.jsx("span", { children: f("From failed step") }) })
                          }
                        )
                      ] })
                    ]
                  }
                )
              }
            )
          ] })
        ]
      },
      e.id
    );
  }
);
Gc.displayName = "FlowRunCard";
const qc = k.memo(() => {
  const [e, n, s] = F((m) => [
    m.flow,
    m.setRightSidebar,
    m.run
  ]), {
    data: r,
    isLoading: a,
    isError: o,
    refetch: i,
    isRefetching: l,
    fetchNextPage: c,
    hasNextPage: u,
    isFetchingNextPage: d
  } = em({
    queryKey: ["flow-runs", e.id],
    getNextPageParam: (m) => m.next,
    initialPageParam: void 0,
    queryFn: ({ pageParam: m }) => Fi.list({
      flowId: [e.id],
      projectId: oe.getProjectId(),
      limit: 15,
      cursor: m
    }),
    refetchOnMount: !0,
    staleTime: 0,
    refetchInterval: (m) => {
      var g;
      const y = (g = m.state.data) == null ? void 0 : g.pages.flatMap((j) => j.data), v = y == null ? void 0 : y.filter(
        (j) => !rs({
          status: j.status,
          ignoreInternalError: !1
        })
      );
      return v != null && v.length ? 15 * 1e3 : !1;
    }
  }), h = p.useMemo(() => {
    const m = ((r == null ? void 0 : r.pages.flatMap((y) => y.data)) ?? []).map(
      (y) => ({ type: "flowRun", run: y })
    );
    return u ? [
      ...m,
      { type: "loadMoreButton", id: "loadMoreButton" }
    ] : m;
  }, [r, u]);
  return /* @__PURE__ */ t.jsxs("div", { className: "h-full w-full flex flex-col", children: [
    /* @__PURE__ */ t.jsx(Na, { onClose: () => n(ye.NONE), children: f("Recent Runs") }),
    a && /* @__PURE__ */ t.jsx(Li, { numberOfCards: 10 }),
    o && /* @__PURE__ */ t.jsx("div", { children: f("Error, please try again.") }),
    r && r.pages.flatMap((m) => m.data).length === 0 && !a && !l && /* @__PURE__ */ t.jsx(Vh, { message: f("No runs found") }),
    r && r.pages.flatMap((m) => m.data).length > 0 && /* @__PURE__ */ t.jsx(
      Bh,
      {
        className: "w-full grow max-w-[calc(100%-6px)]",
        items: h,
        estimateSize: () => Hc,
        getItemKey: (m) => m,
        renderItem: (m) => m.type === "flowRun" ? /* @__PURE__ */ t.jsx(
          Gc,
          {
            refetchRuns: () => {
              i();
            },
            run: m.run,
            viewedRunId: s == null ? void 0 : s.id
          },
          m.run.id + m.run.status
        ) : /* @__PURE__ */ t.jsx("div", { className: "mx-5 h-full flex items-center ", children: /* @__PURE__ */ t.jsx(
          O,
          {
            className: "w-full",
            variant: "accent",
            onClick: () => c(),
            loading: d,
            children: f("More...")
          }
        ) })
      }
    )
  ] });
});
qc.displayName = "RunsList";
const Kc = k.memo(
  ({
    hideContinueOnFailure: e,
    hideRetryOnFailure: n,
    disabled: s
  }) => {
    const r = Pe();
    return /* @__PURE__ */ t.jsxs("div", { className: $("grid", zi), children: [
      e !== !0 && /* @__PURE__ */ t.jsx(
        pe,
        {
          name: "settings.errorHandlingOptions.continueOnFailure.value",
          control: r.control,
          render: ({ field: a }) => /* @__PURE__ */ t.jsxs(we, { children: [
            /* @__PURE__ */ t.jsxs(
              bt,
              {
                htmlFor: "continueOnFailure",
                className: "flex items-center gap-1 h-7.5 max-h-7.5",
                children: [
                  /* @__PURE__ */ t.jsx(Ka, { children: /* @__PURE__ */ t.jsx(
                    gr,
                    {
                      disabled: s,
                      id: "continueOnFailure",
                      checked: a.value,
                      onCheckedChange: a.onChange
                    }
                  ) }),
                  /* @__PURE__ */ t.jsx("span", { className: "ml-2", children: f("Continue on Failure") })
                ]
              }
            ),
            /* @__PURE__ */ t.jsx(
              Ya,
              {
                text: f(
                  "Enable this option to skip this step and continue the flow normally if it fails."
                )
              }
            )
          ] })
        }
      ),
      n !== !0 && /* @__PURE__ */ t.jsx(
        pe,
        {
          name: "settings.errorHandlingOptions.retryOnFailure.value",
          control: r.control,
          render: ({ field: a }) => /* @__PURE__ */ t.jsxs(we, { children: [
            /* @__PURE__ */ t.jsxs(
              bt,
              {
                htmlFor: "retryOnFailure",
                className: "flex items-center gap-1 h-7.5 max-h-7.5",
                children: [
                  /* @__PURE__ */ t.jsx(Ka, { children: /* @__PURE__ */ t.jsx(
                    gr,
                    {
                      disabled: s,
                      id: "retryOnFailure",
                      checked: a.value,
                      onCheckedChange: a.onChange
                    }
                  ) }),
                  /* @__PURE__ */ t.jsx("span", { className: "ml-2", children: f("Retry on Failure") })
                ]
              }
            ),
            /* @__PURE__ */ t.jsx(
              Ya,
              {
                text: f(
                  "Automatically retry up to four attempts when failed."
                )
              }
            )
          ] })
        }
      )
    ] });
  }
);
Kc.displayName = "ActionErrorHandlingForm";
const kr = ({ className: e }) => /* @__PURE__ */ t.jsx("div", { className: $("flex  w-full  h-full  px-4", e), children: /* @__PURE__ */ t.jsxs("div", { className: "space-y-2 grow", children: [
  /* @__PURE__ */ t.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ t.jsx(ce, { className: "w-40 h-4" }) }),
  /* @__PURE__ */ t.jsx(ce, { className: "w-full h-40" })
] }) });
kr.displayName = "StepOutputSkeleton";
const Sn = ({
  status: e,
  lastTestDate: n,
  viewMode: s = "edit"
}) => e === "idle" ? null : /* @__PURE__ */ t.jsxs(
  "div",
  {
    className: $(
      "flex items-center justify-between px-3 py-2 shrink-0 gap-2",
      e === "success" && "bg-success-100",
      e === "failed" && "bg-destructive/10",
      e === "testing" && "bg-primary/10"
    ),
    children: [
      /* @__PURE__ */ t.jsx(rj, { status: e, viewMode: s }),
      n && e !== "testing" && /* @__PURE__ */ t.jsx(
        "span",
        {
          className: $(
            "text-xs truncate",
            e === "success" && "text-success-700/80",
            e === "failed" && "text-destructive/80"
          ),
          children: qn.formatDateWithTime(new Date(n), !1)
        }
      )
    ]
  }
), rj = ({
  status: e,
  viewMode: n
}) => e === "failed" ? /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1.5 text-sm", children: [
  /* @__PURE__ */ t.jsx(Xa, { status: fn.FAILED, size: "4.5" }),
  /* @__PURE__ */ t.jsx("span", { className: "text-destructive-700 dark:text-destructive-200 font-medium", children: n === "run" ? f("Failed") : f("Test Failed") })
] }) : e === "testing" ? /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1.5 text-sm text-primary", children: [
  /* @__PURE__ */ t.jsx($i, { className: "size-4 animate-spin" }),
  /* @__PURE__ */ t.jsx("span", { className: "font-medium", children: f("Testing...") })
] }) : /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1.5 text-sm", children: [
  /* @__PURE__ */ t.jsx(Xa, { status: fn.SUCCEEDED, size: "4.5" }),
  /* @__PURE__ */ t.jsx("span", { className: "text-success-700 font-medium", children: n === "run" ? f("Success") : f("Tested Successfully") })
] });
Sn.displayName = "TestPanelHeader";
const Gt = ({
  disabled: e = !1,
  className: n
}) => {
  const [s, r] = F((l) => [
    l.testPanelView,
    l.setTestPanelView
  ]), a = s === "split", o = a ? km : lm, i = a ? f("Collapse") : f("Split View");
  return /* @__PURE__ */ t.jsxs(
    O,
    {
      type: "button",
      variant: "ghost",
      size: "sm",
      onClick: () => r(a ? "drawer" : "split"),
      disabled: e,
      className: $("text-sm shrink-0", n),
      "aria-label": i,
      children: [
        /* @__PURE__ */ t.jsx(o, { className: "size-4" }),
        /* @__PURE__ */ t.jsx("span", { children: i })
      ]
    }
  );
};
Gt.displayName = "TestPanelViewToggle";
const aj = () => {
  const [e, n, s, r] = F(
    (x) => [
      x.run,
      x.loopsIndexes,
      x.flowVersion,
      x.selectedStep ? q.getStepOrThrow(
        x.selectedStep,
        x.flowVersion.trigger
      ) : null
    ]
  ), a = xr(r), [o, i] = p.useState(
    a ? "timeline" : "output"
  ), l = o === "timeline" && !a ? "output" : o, c = p.useMemo(() => e && r && e.steps ? jn.extractStepOutput(
    r.name,
    n,
    e.steps
  ) : null, [e, r == null ? void 0 : r.name, n, s.trigger]), u = (c == null ? void 0 : c.status) === fn.RUNNING, d = (c == null ? void 0 : c.outputType) === Uh.SLICE, h = d ? c == null ? void 0 : c.output : void 0, m = d ? void 0 : (c == null ? void 0 : c.errorMessage) ?? (c == null ? void 0 : c.output) ?? "No output";
  if (!e)
    return /* @__PURE__ */ t.jsx(t.Fragment, {});
  const y = rs({
    status: e.status,
    ignoreInternalError: !0
  }), { data: v } = Me.useFlag(
    ze.EXECUTION_DATA_RETENTION_DAYS
  );
  if (!y && e.status !== Ne.PAUSED && M(c))
    return /* @__PURE__ */ t.jsx(kr, { className: "p-4" });
  const g = ij(e, v);
  if (g)
    return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col justify-center items-center gap-4 w-full pt-8  px-5", children: [
      /* @__PURE__ */ t.jsx($t, { size: 36, className: "text-muted-foreground" }),
      /* @__PURE__ */ t.jsx("h4", { className: "px-6 text-sm text-center text-muted-foreground ", children: g })
    ] });
  if (!c || !r)
    return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col h-full w-full", children: [
      /* @__PURE__ */ t.jsx("div", { className: "flex justify-end px-3 py-2 shrink-0", children: /* @__PURE__ */ t.jsx(Gt, {}) }),
      /* @__PURE__ */ t.jsxs("div", { className: "grow flex flex-col items-center justify-center w-full px-6 py-10 gap-4 text-center", children: [
        /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-center size-12 rounded-full bg-muted text-muted-foreground", children: /* @__PURE__ */ t.jsx($t, { className: "size-6" }) }),
        /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-1.5 max-w-[280px]", children: [
          /* @__PURE__ */ t.jsx("span", { className: "text-sm font-medium text-foreground", children: f("This step didn't run") }),
          /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground leading-relaxed", children: f(
            "This step was skipped during this run, no input or output was captured."
          ) })
        ] })
      ] })
    ] });
  const j = c.status === fn.FAILED ? "failed" : c.status === fn.RUNNING ? "testing" : "success";
  return /* @__PURE__ */ t.jsxs("div", { className: "h-full flex flex-col", children: [
    /* @__PURE__ */ t.jsx(
      Sn,
      {
        status: j,
        lastTestDate: e.created,
        viewMode: "run"
      }
    ),
    /* @__PURE__ */ t.jsx(Ze, { className: "flex-1 p-3", children: /* @__PURE__ */ t.jsxs(
      qr,
      {
        value: l,
        onValueChange: (x) => i(x),
        className: "w-full",
        children: [
          /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between gap-2 shrink-0 mb-2", children: [
            /* @__PURE__ */ t.jsxs(Kr, { className: "h-9", children: [
              /* @__PURE__ */ t.jsx(wt, { value: "input", children: f("Input") }),
              a && /* @__PURE__ */ t.jsx(wt, { value: "timeline", children: f("Timeline") }),
              /* @__PURE__ */ t.jsx(wt, { value: "output", children: f("Output") })
            ] }),
            /* @__PURE__ */ t.jsx(Gt, {})
          ] }),
          /* @__PURE__ */ t.jsx(Nt, { value: "input", children: /* @__PURE__ */ t.jsx(
            Os,
            {
              data: c.input,
              title: f("Input"),
              copyableData: c.input,
              downloadFileName: `${r.name}-input`
            }
          ) }),
          a && /* @__PURE__ */ t.jsx(Nt, { value: "timeline", children: /* @__PURE__ */ t.jsx(
            Wh,
            {
              agentResult: c.output
            }
          ) }),
          /* @__PURE__ */ t.jsx(Nt, { value: "output", children: u ? /* @__PURE__ */ t.jsx(kr, { className: "p-4" }) : h ? /* @__PURE__ */ t.jsx(oj, { slicedOutputRef: h }) : /* @__PURE__ */ t.jsx(
            Os,
            {
              data: m,
              title: f("Output"),
              copyableData: m,
              downloadFileName: `${r.name}-output`
            }
          ) })
        ]
      }
    ) })
  ] });
}, oj = ({
  slicedOutputRef: e
}) => /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-3 p-4 bg-muted rounded-md", children: [
  /* @__PURE__ */ t.jsxs("div", { className: "flex items-start gap-2 text-sm", children: [
    /* @__PURE__ */ t.jsx($t, { className: "w-4 h-4 mt-0.5 text-muted-foreground shrink-0" }),
    /* @__PURE__ */ t.jsx("span", { children: f(
      "Output is too large to display inline ({size}). Download to inspect.",
      { size: qn.formatStorageSize(e.size) }
    ) })
  ] }),
  /* @__PURE__ */ t.jsx(O, { asChild: !0, variant: "outline", size: "sm", className: "w-fit gap-2", children: /* @__PURE__ */ t.jsxs(
    "a",
    {
      href: e.url,
      target: "_blank",
      rel: "noopener noreferrer",
      download: !0,
      children: [
        /* @__PURE__ */ t.jsx(Ci, { className: "w-4 h-4" }),
        f("Download output")
      ]
    }
  ) })
] });
function ij(e, n) {
  return M(e) || !rs({ status: e.status, ignoreInternalError: !0 }) ? null : [Ne.INTERNAL_ERROR].includes(e.status) ? f(
    "There are no logs captured for this run, because of an internal error, please contact support."
  ) : M(e.logsFileId) ? f(
    "Logs are kept for {days} days after execution and then deleted.",
    { days: n }
  ) : null;
}
function lj(e) {
  const n = e.split("Error:");
  if (n.length < 2)
    return e;
  const s = n.map((a) => a.trim().replace(/^\n+|\n+$/g, "")).filter((a) => a !== ""), r = "  ";
  return s.reduce((a, o, i) => {
    const l = r.repeat(i), c = s.length === 1 ? "Error" : `Error ${i + 1}`;
    return `${a}${l}${c}: ${o}
`;
  }, "");
}
const Jo = {
  formatErrorMessage: lj
}, Wn = {
  useSimulateTrigger: ({
    setErrorMessage: e,
    onSuccess: n
  }) => {
    const { form: s, builderState: r } = Ss(), a = r.flow.id, o = r.flowVersionId, i = s.getValues().name;
    return Re({
      mutationFn: async (l) => {
        e == null || e(void 0);
        const c = (await an.list({
          projectId: oe.getProjectId(),
          flowId: a,
          cursor: void 0,
          limit: 5
        })).data.map((d) => d.id);
        await an.test({
          projectId: oe.getProjectId(),
          flowId: a,
          flowVersionId: o,
          testStrategy: Is.SIMULATION
        });
        let u = 0;
        for (; u < 1e3; ) {
          if (l.aborted)
            return [];
          const d = await an.list({
            projectId: oe.getProjectId(),
            flowId: a,
            cursor: void 0,
            limit: 5
          }), h = d.data.map((m) => m.id);
          if (!ea(c, h))
            return d.data.length > 0 && r.updateSampleData({
              stepName: i,
              output: d.data[0].payload
            }), d.data;
          await qh(2e3), u++;
        }
        return [];
      },
      onSuccess: async (l) => {
        l.length > 0 && n();
      },
      onError: async (l) => {
        console.error(l), e == null || e(
          Jo.formatErrorMessage(
            f("There is no sample data available found for this trigger.")
          )
        );
      }
    });
  },
  useSaveMockData: ({ onSuccess: e }) => {
    const { form: n, builderState: s } = Ss(), r = s.flow.id, a = n.getValues().name;
    return Re({
      mutationFn: async (o) => {
        const i = await an.saveTriggerMockdata({
          projectId: oe.getProjectId(),
          flowId: r,
          mockData: o
        });
        return s.updateSampleData({
          stepName: a,
          output: i.payload
        }), i;
      },
      onSuccess: e
    });
  },
  usePollTrigger: ({
    setErrorMessage: e,
    onSuccess: n
  }) => {
    const { form: s, builderState: r } = Ss(), a = r.flow.id, o = r.flowVersionId, i = s.getValues().name;
    return Re({
      mutationFn: async () => {
        e(void 0);
        const { data: l } = await an.test({
          projectId: oe.getProjectId(),
          flowId: a,
          flowVersionId: o,
          testStrategy: Is.TEST_FUNCTION
        });
        return l.length > 0 && r.updateSampleData({
          stepName: i,
          output: l[0].payload
        }), l;
      },
      onSuccess: async (l) => {
        l.length > 0 && n();
      },
      onError: (l) => {
        var c;
        if (dn.isError(l)) {
          const u = (c = l.response) == null ? void 0 : c.data;
          let d = "Failed to run test step, please ensure settings are correct.";
          u.code === Hh.TEST_TRIGGER_FAILED && (d = JSON.stringify(
            {
              message: "Failed to run test step, please ensure settings are correct.",
              error: Gh(u.params.message)
            },
            null,
            2
          )), e(d);
        } else
          e(
            Jo.formatErrorMessage(
              f("Internal error, please try again later.")
            )
          );
      }
    });
  },
  /**To reset the loading state of the mutation use a new mutation key, but to make sure sucess never gets called, use the abortSignal */
  useTestAction: ({ currentStep: e }) => {
    const { flowVersionId: n, addActionTestListener: s } = Ss().builderState;
    return Re({
      mutationFn: async () => await Fi.testStep({
        request: {
          projectId: oe.getProjectId(),
          flowVersionId: n,
          stepName: e.name
        }
      }),
      onSuccess: (r) => {
        s({
          runId: r.runId,
          stepName: e.name
        });
      },
      onError: () => {
        Vi();
      }
    });
  }
}, Ss = () => {
  const e = Pe(), n = F((s) => ({
    flow: s.flow,
    flowVersion: s.flowVersion,
    flowVersionId: s.flowVersion.id,
    addActionTestListener: s.addActionTestListener,
    updateSampleData: s.updateSampleData
  }));
  return { form: e, builderState: n };
};
function cj(e) {
  switch (e) {
    case at.NUMBER:
      return It.NUMBER;
    case at.BOOLEAN:
      return It.CHECKBOX;
    case at.OBJECT:
      return It.OBJECT;
    case at.DATE:
      return It.DATE_TIME;
    case at.ARRAY:
      return It.ARRAY;
    case at.TEXT:
    default:
      return It.SHORT_TEXT;
  }
}
function dj({
  open: e,
  onOpenChange: n,
  onTestingSuccess: s
}) {
  const o = Pe().getValues().settings.input.inputSchema, { mutate: i, isPending: l } = Wn.useSaveMockData({
    onSuccess: () => {
      s(), n(!1);
    }
  }), c = Pn({
    shouldFocusError: !0,
    defaultValues: o.filter((h) => h.name.trim() !== "").reduce((h, m) => (h[m.name] = m.type === at.BOOLEAN ? !1 : "", h), {}),
    resolver: (h) => {
      const m = o.reduce((y, v) => (v.required && v.type !== at.BOOLEAN && !h[v.name] && (y[v.name] = {
        type: "required",
        message: f("{field} is required", { field: v.name })
      }), y), {});
      return Object.keys(m).length === 0 ? { values: h, errors: {} } : {
        values: {},
        errors: m
      };
    },
    mode: "onChange"
  });
  function u(h) {
    return h.replace(/[\s/@-]+/g, "_");
  }
  const d = o.reduce((h, m) => {
    const y = {
      displayName: m.name,
      description: m.description || "",
      required: m.required,
      type: cj(m.type),
      defaultValue: m.defaultValue
    };
    return h[m.name] = y, h;
  }, {});
  return /* @__PURE__ */ t.jsx(ut, { open: e, onOpenChange: n, children: /* @__PURE__ */ t.jsxs(ht, { className: "w-full max-w-xl flex flex-col max-h-[90vh]", children: [
    /* @__PURE__ */ t.jsxs(ft, { children: [
      /* @__PURE__ */ t.jsx(mt, { className: "px-0.5", children: f("Set Sample Data") }),
      /* @__PURE__ */ t.jsx(Zr, { className: "px-0.5", children: f("Provide sample values for testing this tool trigger.") })
    ] }),
    /* @__PURE__ */ t.jsx(Dn, { ...c, children: /* @__PURE__ */ t.jsxs(
      "form",
      {
        className: "grid space-y-4",
        onSubmit: c.handleSubmit((h) => {
          const m = Object.fromEntries(
            Object.entries(h).filter(([y, v]) => y.trim() !== "").map(([y, v]) => [u(y), v])
          );
          i(m);
        }),
        children: [
          /* @__PURE__ */ t.jsx(Ze, { className: "flex-1 max-h-[50vh]", children: /* @__PURE__ */ t.jsx("div", { className: "py-4", children: Object.keys(d).length > 0 ? /* @__PURE__ */ t.jsx("div", { className: "space-y-4", children: Object.entries(d).map(
            ([h, m]) => {
              var v;
              const y = c.formState.errors[h];
              return /* @__PURE__ */ t.jsxs(
                "div",
                {
                  className: "grid space-y-2 px-0.5",
                  children: [
                    /* @__PURE__ */ t.jsx(
                      vr,
                      {
                        props: { [h]: m },
                        propertySettings: null,
                        dynamicPropsInfo: null,
                        prefixValue: "",
                        useMentionTextInput: !1,
                        disabled: !1
                      }
                    ),
                    y && /* @__PURE__ */ t.jsx("p", { className: "text-xs text-destructive font-medium", children: (v = y.message) == null ? void 0 : v.toString() })
                  ]
                },
                h
              );
            }
          ) }) : /* @__PURE__ */ t.jsx("div", { className: "p-4 rounded-lg text-center", children: /* @__PURE__ */ t.jsx("p", { className: "text-sm text-muted-foreground", children: f("No input fields defined in the schema") }) }) }) }),
          /* @__PURE__ */ t.jsxs(pt, { children: [
            /* @__PURE__ */ t.jsx(
              O,
              {
                type: "button",
                variant: "outline",
                onClick: () => n(!1),
                disabled: l,
                children: f("Cancel")
              }
            ),
            /* @__PURE__ */ t.jsx(O, { type: "submit", loading: l, children: f("Use Sample Data") })
          ] })
        ]
      }
    ) })
  ] }) });
}
var Yc = /* @__PURE__ */ ((e) => (e.JSON = "json", e.TEXT = "text", e.FORM_DATA = "form-data", e))(Yc || {}), ba = /* @__PURE__ */ ((e) => (e.GET = "GET", e.POST = "POST", e.PATCH = "PATCH", e.PUT = "PUT", e.DELETE = "DELETE", e.HEAD = "HEAD", e))(ba || {});
const uj = ({
  bodyType: e,
  field: n
}) => {
  switch (e) {
    case "json":
      return /* @__PURE__ */ t.jsx(Kh, { field: n, readonly: !1 });
    case "text":
      return /* @__PURE__ */ t.jsx(Et, { ...n });
    case "form-data":
      return /* @__PURE__ */ t.jsx(
        As,
        {
          values: n.value,
          onChange: n.onChange,
          disabled: !1
        }
      );
  }
};
Je({
  bodyType: Ja(Yc),
  body: Yh([Je({}), Te()]),
  headers: Qa(Te(), Te()),
  queryParams: Qa(Te(), Te()),
  method: Ja(ba)
});
const hj = ({
  open: e,
  onOpenChange: n
}) => {
  const { data: s } = Me.useFlag(
    ze.WEBHOOK_URL_PREFIX
  ), r = F((l) => l.flow.id), [a, o] = p.useState(!1), { mutate: i } = Re({
    mutationFn: async (l) => {
      o(!0), await dn.any(`${s}/${r}/test`, {
        method: l.method,
        data: l.body,
        headers: l.headers,
        params: l.queryParams
      });
    }
  });
  return /* @__PURE__ */ t.jsx(
    ut,
    {
      open: e,
      onOpenChange: (l) => {
        n(l);
      },
      children: /* @__PURE__ */ t.jsxs(ht, { children: [
        /* @__PURE__ */ t.jsx(ft, { children: /* @__PURE__ */ t.jsx(mt, { children: f("Send Sample Data to Webhook") }) }),
        /* @__PURE__ */ t.jsx(
          Sa,
          {
            showMethodDropdown: !0,
            onSubmit: i,
            isLoading: a
          }
        )
      ] })
    }
  );
}, fj = ({
  currentStep: e,
  onOpenChange: n,
  open: s
}) => {
  const [r] = F((a) => [
    a.updateSampleData
  ]);
  return /* @__PURE__ */ t.jsx(ut, { open: s, onOpenChange: n, children: /* @__PURE__ */ t.jsxs(ht, { children: [
    /* @__PURE__ */ t.jsx(ft, { children: /* @__PURE__ */ t.jsx(mt, { children: f("Send Sample Data to Webhook") }) }),
    /* @__PURE__ */ t.jsx(
      Sa,
      {
        showMethodDropdown: !1,
        isLoading: !1,
        onSubmit: (a) => {
          r({
            stepName: e.name,
            output: {
              body: a.body,
              headers: a.headers,
              queryParams: a.queryParams
            }
          });
        }
      }
    )
  ] }) });
}, Sa = (e) => {
  const { showMethodDropdown: n, onSubmit: s, isLoading: r } = e, a = Pn({
    defaultValues: {
      bodyType: "json",
      body: {},
      headers: {},
      queryParams: {},
      method: "GET"
      /* GET */
    }
  });
  return /* @__PURE__ */ t.jsx(Dn, { ...a, children: /* @__PURE__ */ t.jsxs("form", { className: "space-y-4", onSubmit: a.handleSubmit(s), children: [
    n && /* @__PURE__ */ t.jsx(
      pe,
      {
        control: a.control,
        name: "method",
        render: ({ field: o }) => /* @__PURE__ */ t.jsxs(we, { children: [
          /* @__PURE__ */ t.jsx(bt, { children: f("Method") }),
          /* @__PURE__ */ t.jsx(
            Ft,
            {
              options: Object.values(ba).map((i) => ({
                value: i,
                label: i
              })),
              onChange: (i) => {
                o.onChange(i);
              },
              value: o.value,
              disabled: !1,
              placeholder: f("Select an option")
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ t.jsxs(qr, { defaultValue: "queryParams", children: [
      /* @__PURE__ */ t.jsxs(Kr, { className: "grid w-full grid-cols-3", children: [
        /* @__PURE__ */ t.jsx(wt, { value: "queryParams", children: f("Query Params") }),
        /* @__PURE__ */ t.jsx(wt, { value: "headers", children: f("Headers") }),
        /* @__PURE__ */ t.jsx(wt, { value: "body", children: f("Body") })
      ] }),
      /* @__PURE__ */ t.jsx(Nt, { value: "queryParams", children: /* @__PURE__ */ t.jsx(
        pe,
        {
          control: a.control,
          name: "queryParams",
          render: ({ field: o }) => /* @__PURE__ */ t.jsx(we, { children: /* @__PURE__ */ t.jsx(
            As,
            {
              values: o.value,
              onChange: (i) => o.onChange({ target: { value: i } }),
              disabled: !1
            }
          ) })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Nt, { value: "headers", children: /* @__PURE__ */ t.jsx(
        pe,
        {
          control: a.control,
          name: "headers",
          render: ({ field: o }) => /* @__PURE__ */ t.jsx(we, { children: /* @__PURE__ */ t.jsx(
            As,
            {
              values: o.value,
              onChange: (i) => o.onChange({ target: { value: i } }),
              disabled: !1
            }
          ) })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Nt, { value: "body", children: /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
        /* @__PURE__ */ t.jsx(
          pe,
          {
            name: "bodyType",
            render: ({ field: o }) => /* @__PURE__ */ t.jsxs(we, { children: [
              /* @__PURE__ */ t.jsx(bt, { children: f("Type") }),
              /* @__PURE__ */ t.jsx(
                Ft,
                {
                  options: [
                    {
                      value: "json",
                      label: f("JSON")
                    },
                    {
                      value: "text",
                      label: f("Text")
                    },
                    {
                      value: "form-data",
                      label: f("Form Data")
                    }
                  ],
                  onChange: (i) => {
                    switch (o.onChange(i), i) {
                      case "json":
                      case "form-data":
                        a.setValue("body", {});
                        break;
                      case "text":
                        a.setValue("body", "");
                        break;
                    }
                  },
                  value: o.value,
                  disabled: !1,
                  placeholder: f("Select an option"),
                  showDeselect: !0
                }
              )
            ] })
          }
        ),
        /* @__PURE__ */ t.jsx(
          pe,
          {
            control: a.control,
            name: "body",
            render: ({ field: o }) => /* @__PURE__ */ t.jsxs(we, { className: "mt-4", children: [
              /* @__PURE__ */ t.jsx(bt, { children: f("Body") }),
              /* @__PURE__ */ t.jsx(
                uj,
                {
                  bodyType: a.getValues("bodyType"),
                  field: o
                }
              )
            ] })
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ t.jsxs(pt, { children: [
      /* @__PURE__ */ t.jsx(yn, { asChild: !0, children: /* @__PURE__ */ t.jsx(O, { type: "button", variant: "outline", children: f("Cancel") }) }),
      /* @__PURE__ */ t.jsx(O, { type: "submit", loading: r, children: f("Send") })
    ] })
  ] }) });
};
Sa.displayName = "TestWebhookFunctionalityDialog";
const Ca = (e) => {
  const { testingMode: n, currentStep: s, open: r, onOpenChange: a } = e;
  if (n === "returnResponseAndWaitForNextWebhook")
    return /* @__PURE__ */ t.jsx(
      fj,
      {
        currentStep: s,
        open: r,
        onOpenChange: a,
        testingMode: n
      }
    );
  if (n === "trigger")
    return /* @__PURE__ */ t.jsx(
      hj,
      {
        currentStep: s,
        open: r,
        onOpenChange: a,
        testingMode: n
      }
    );
};
Ca.displayName = "TestWebhookDialog";
const mj = {
  getTestType: ({
    triggerName: e,
    pieceName: n,
    trigger: s
  }) => {
    if (lt.isMcpToolTrigger(n, e))
      return "mcp-tool";
    if (lt.isChatTrigger(n, e))
      return "chat-trigger";
    if (n === "@activepieces/piece-webhook" && e === "catch_webhook")
      return "webhook";
    if (s.type === Za.APP_WEBHOOK || s.type === Za.WEBHOOK)
      switch (s.testStrategy) {
        case Is.TEST_FUNCTION:
          return "polling";
        case Is.SIMULATION:
          return "simulation";
      }
    return "polling";
  }
}, Xc = p.createContext(null), pj = (e) => e.type === Y.PIECE && e.settings.pieceName === "@activepieces/piece-webhook" && e.settings.actionName === "return_response_and_wait_for_next_webhook", Jc = ({
  step: e,
  children: n
}) => {
  const { mutate: s, isPending: r } = Wn.useTestAction({ currentStep: e }), a = F(
    (h) => h.isStepBeingTested
  ), { isLoadingDynamicProperties: o } = p.useContext(qt), [i, l] = p.useState(!1), c = r || a(e.name) || i, u = e.valid !== !1 && !c && !o, d = p.useCallback(() => {
    u && (pj(e) ? l(!0) : s(void 0));
  }, [u, e, s]);
  return /* @__PURE__ */ t.jsxs(
    Xc.Provider,
    {
      value: { fireTest: d, isTesting: c, canFireTest: u },
      children: [
        n,
        i && /* @__PURE__ */ t.jsx(
          Ca,
          {
            testingMode: "returnResponseAndWaitForNextWebhook",
            open: !0,
            onOpenChange: (h) => !h && l(!1),
            currentStep: e
          }
        )
      ]
    }
  );
}, Qc = () => p.useContext(Xc);
Jc.displayName = "ActionTestRunnerProvider";
const Zc = p.createContext(null), ed = ({
  step: e,
  children: n
}) => {
  var X;
  const [s, r] = p.useState(
    void 0
  ), [a, o] = p.useState(!1), i = p.useRef(new AbortController()), [l, c] = F(
    (ue) => [ue.setChatDrawerOpenSource, ue.flowVersion.id]
  ), { isLoadingDynamicProperties: u } = p.useContext(qt), d = Qn(), h = e.type === ee.PIECE, m = h ? e.settings.pieceName : "", y = h ? e.settings.pieceVersion : void 0, v = h ? e.settings.triggerName : void 0, { pieceModel: g, isLoading: j } = Rn.usePiece({
    name: m,
    version: y,
    enabled: h && !!m
  }), x = v ? (X = g == null ? void 0 : g.triggers) == null ? void 0 : X[v] : void 0, N = x == null ? void 0 : x.sampleData, w = x && v && m ? mj.getTestType({ triggerName: v, pieceName: m, trigger: x }) : null, b = m && v ? lt.isManualTrigger({ pieceName: m, triggerName: v }) : !1, E = p.useCallback(async () => {
    await d.invalidateQueries({
      queryKey: ["triggerEvents", c]
    });
  }, [d, c]), { mutate: R, isPending: S } = Wn.useSaveMockData({
    onSuccess: E
  }), {
    mutate: C,
    isPending: T,
    reset: I
  } = Wn.useSimulateTrigger({
    setErrorMessage: r,
    onSuccess: async () => {
      await E(), o(!1);
    }
  }), { mutate: P, isPending: D } = Wn.usePollTrigger({
    setErrorMessage: r,
    onSuccess: E
  }), A = T || D || S || a, _ = e.valid !== !1, L = _ && !A && !u && !j && !b && w !== null, H = p.useCallback(() => {
    if (!(!L || !w))
      switch (w) {
        case "chat-trigger":
          l(Yr.TEST_STEP), C(i.current.signal);
          break;
        case "simulation":
        case "webhook":
          C(i.current.signal);
          break;
        case "polling":
          P();
          break;
        case "mcp-tool":
          o(!0);
          break;
      }
  }, [
    L,
    w,
    C,
    P,
    l
  ]);
  return /* @__PURE__ */ t.jsxs(
    Zc.Provider,
    {
      value: {
        step: e,
        pieceModel: g,
        isPieceLoading: j,
        testType: w,
        mockData: N,
        isValid: _,
        canFireTest: L,
        isTesting: A,
        isSimulating: T,
        isSavingMockdata: S,
        isPollingTesting: D,
        errorMessage: s,
        setErrorMessage: r,
        isTestingDialogOpen: a,
        setIsTestingDialogOpen: o,
        abortControllerRef: i,
        simulateTrigger: C,
        pollTrigger: P,
        saveMockAsSampleData: R,
        resetSimulation: I,
        fireTest: H,
        onTestSuccess: E
      },
      children: [
        n,
        w === "mcp-tool" && /* @__PURE__ */ t.jsx(
          dj,
          {
            open: a,
            onOpenChange: o,
            onTestingSuccess: E
          }
        )
      ]
    }
  );
}, td = () => p.useContext(Zc);
ed.displayName = "TriggerTestRunnerProvider";
const $e = ({
  children: e,
  invalid: n,
  saving: s
}) => {
  const { isLoadingDynamicProperties: r } = p.useContext(qt);
  return /* @__PURE__ */ t.jsx(ks, { children: /* @__PURE__ */ t.jsxs(te, { children: [
    /* @__PURE__ */ t.jsx(ne, { asChild: !0, className: "disabled:pointer-events-auto", children: e }),
    (n || r || s) && /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: n ? f("Fill in the required fields first") : r ? f("Please wait until all inputs are loaded") : f("Saving...") })
  ] }) });
};
$e.displayName = "TestButtonTooltip";
const gj = (e) => M(e) ? !1 : e !== "", Ea = k.memo(
  (e) => {
    const {
      isValid: n,
      isTesting: s,
      sampleData: r,
      errorMessage: a,
      lastTestDate: o,
      currentStep: i,
      children: l,
      isSaving: c,
      onRetest: u,
      onCancelTesting: d,
      hideCancel: h,
      sampleDataInput: m,
      consoleLogs: y
    } = e, [v, g] = p.useState("Output"), j = !M(m), x = gj(y), N = v === "Input" && !j || v === "Logs" && !x ? "Output" : v, w = !M(a) || xr(i) && (r == null ? void 0 : r.status) === Xh.FAILED, b = s ? "testing" : w ? "failed" : "success", R = N === "Input" ? m : N === "Logs" ? y : a ?? r, S = xr(i) && !a;
    return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col h-full w-full min-h-0", children: [
      /* @__PURE__ */ t.jsx(Sn, { status: b, lastTestDate: o }),
      !s && l,
      /* @__PURE__ */ t.jsxs("div", { className: "flex-1 flex flex-col w-full text-start min-h-0", children: [
        a && !s && /* @__PURE__ */ t.jsx("div", { className: "px-3 pt-2 text-xs text-muted-foreground shrink-0", children: f("Errors are not saved on refresh") }),
        !S && /* @__PURE__ */ t.jsx(
          xj,
          {
            activeTab: N,
            setActiveTab: g,
            hasInput: j,
            hasLogs: x,
            disabled: s
          }
        ),
        /* @__PURE__ */ t.jsx("div", { className: "flex-1 min-h-0 px-3 pb-3 overflow-auto", children: s && !S ? /* @__PURE__ */ t.jsx(wj, { data: R }) : S ? /* @__PURE__ */ t.jsx(
          Jh,
          {
            agentResult: bj(r),
            errorMessage: a
          }
        ) : /* @__PURE__ */ t.jsx(
          Os,
          {
            data: R,
            title: f(N),
            copyableData: R,
            downloadFileName: `${(i == null ? void 0 : i.name) ?? "output"}-${N.toLowerCase()}`
          }
        ) })
      ] }),
      s ? /* @__PURE__ */ t.jsx(
        jj,
        {
          onCancel: h ? void 0 : d
        }
      ) : /* @__PURE__ */ t.jsx(
        yj,
        {
          onRetest: u,
          disabled: !n || c,
          isValid: n,
          isSaving: c
        }
      )
    ] });
  }
), xj = ({
  activeTab: e,
  setActiveTab: n,
  hasInput: s,
  hasLogs: r,
  disabled: a = !1
}) => /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between px-3 py-2 gap-2 shrink-0", children: [
  /* @__PURE__ */ t.jsx(
    vj,
    {
      activeTab: e,
      setActiveTab: n,
      hasInput: s,
      hasLogs: r,
      disabled: a
    }
  ),
  /* @__PURE__ */ t.jsx(Gt, { disabled: a })
] }), vj = ({
  activeTab: e,
  setActiveTab: n,
  hasInput: s,
  hasLogs: r,
  disabled: a
}) => /* @__PURE__ */ t.jsxs(
  "div",
  {
    className: $(
      "inline-flex items-center rounded-md bg-muted p-0.5 gap-0.5",
      a && "opacity-50"
    ),
    children: [
      /* @__PURE__ */ t.jsx(
        hr,
        {
          label: f("Output"),
          active: e === "Output",
          onClick: () => n("Output"),
          disabled: a
        }
      ),
      s && /* @__PURE__ */ t.jsx(
        hr,
        {
          label: f("Input"),
          active: e === "Input",
          onClick: () => n("Input"),
          disabled: a
        }
      ),
      r && /* @__PURE__ */ t.jsx(
        hr,
        {
          label: f("Logs"),
          active: e === "Logs",
          onClick: () => n("Logs"),
          disabled: a
        }
      )
    ]
  }
), hr = ({
  label: e,
  active: n,
  onClick: s,
  disabled: r
}) => /* @__PURE__ */ t.jsx(
  "button",
  {
    type: "button",
    onClick: s,
    disabled: r,
    className: $(
      "px-3 py-1 text-xs font-medium rounded-sm transition-colors disabled:cursor-not-allowed",
      n ? "bg-background text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
    ),
    children: e
  }
), yj = ({
  onRetest: e,
  disabled: n,
  isValid: s,
  isSaving: r
}) => /* @__PURE__ */ t.jsxs(
  "div",
  {
    "data-test-panel-trigger": !0,
    className: "relative px-3 py-3 bg-background z-10 shrink-0",
    children: [
      /* @__PURE__ */ t.jsx(
        "div",
        {
          "aria-hidden": !0,
          className: "pointer-events-none absolute -top-6 left-0 right-0 h-6 bg-gradient-to-t from-background to-transparent"
        }
      ),
      /* @__PURE__ */ t.jsx($e, { saving: r, invalid: !s, children: /* @__PURE__ */ t.jsxs(
        O,
        {
          variant: "outline",
          onClick: e,
          disabled: n,
          keyboardShortcut: "G",
          onKeyboardShortcut: e,
          className: "w-full justify-center bg-primary/5 enabled:hover:bg-primary/15 enabled:hover:text-primary text-primary border-primary/20",
          size: "sm",
          children: [
            /* @__PURE__ */ t.jsx(wn, { className: "size-4 fill-current" }),
            f("Retest Step")
          ]
        }
      ) })
    ]
  }
), jj = ({ onCancel: e }) => /* @__PURE__ */ t.jsxs(
  "div",
  {
    "data-test-panel-trigger": !0,
    className: "relative px-3 py-3 bg-background z-10 shrink-0",
    children: [
      /* @__PURE__ */ t.jsx(
        "div",
        {
          "aria-hidden": !0,
          className: "pointer-events-none absolute -top-6 left-0 right-0 h-6 bg-gradient-to-t from-background to-transparent"
        }
      ),
      /* @__PURE__ */ t.jsxs(
        O,
        {
          onClick: e,
          disabled: !e,
          variant: "outline",
          className: "w-full justify-center bg-primary/5 hover:bg-primary/10 text-primary border-primary/20",
          size: "sm",
          children: [
            /* @__PURE__ */ t.jsx($i, { className: "size-4 animate-spin" }),
            f("Cancel Testing")
          ]
        }
      )
    ]
  }
), wj = ({ data: e }) => M(e) ? /* @__PURE__ */ t.jsx(Nj, {}) : /* @__PURE__ */ t.jsx("div", { className: "opacity-40 animate-pulse pointer-events-none select-none", children: /* @__PURE__ */ t.jsx(Os, { data: e, title: f("Output") }) }), Nj = () => /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-3 py-3 animate-pulse", children: [
  /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-24" }),
  /* @__PURE__ */ t.jsxs("div", { className: "pl-4 flex flex-col gap-2.5", children: [
    /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-32" }),
    /* @__PURE__ */ t.jsxs("div", { className: "pl-4 flex flex-col gap-2.5", children: [
      /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-48" }),
      /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-40" }),
      /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-44" })
    ] }),
    /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-28" }),
    /* @__PURE__ */ t.jsxs("div", { className: "pl-4 flex flex-col gap-2.5", children: [
      /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-36" }),
      /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-52" })
    ] }),
    /* @__PURE__ */ t.jsx(ce, { className: "h-3 w-32" })
  ] })
] });
Ea.displayName = "TestSampleDataViewer";
function bj(e) {
  if (!M(e) && !(typeof e != "object" || e === null) && "status" in e && "steps" in e && "prompt" in e)
    return e;
}
const nd = k.memo(
  ({
    isSaving: e,
    currentStep: n
  }) => {
    var g;
    const [
      s,
      r,
      a,
      o,
      i,
      l,
      c
    ] = F((j) => [
      j.outputSampleData[n.name],
      j.inputSampleData[n.name],
      j.errorLogs[n.name],
      n.type === Y.CODE ? j.consoleLogs[n.name] : null,
      j.isStepBeingTested,
      j.removeStepTestListener,
      j.revertSampleDataLocallyCallbacks[n.name]
    ]), u = Qc(), d = () => u == null ? void 0 : u.fireTest(), h = (g = n.settings.sampleData) == null ? void 0 : g.lastTestDate, m = !M(h) || !M(a) || i(n.name), y = (u == null ? void 0 : u.isTesting) ?? !1, { isLoadingDynamicProperties: v } = p.useContext(qt);
    return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      !m && !y && /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col h-full", children: [
        /* @__PURE__ */ t.jsx(Sn, { status: "idle" }),
        /* @__PURE__ */ t.jsx("div", { className: "flex justify-end px-3 py-2 shrink-0", children: /* @__PURE__ */ t.jsx(Gt, {}) }),
        /* @__PURE__ */ t.jsxs("div", { className: "grow flex flex-col items-center justify-center w-full px-6 py-10 gap-4 text-center", children: [
          /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-center size-12 rounded-full bg-primary/10 text-primary", children: /* @__PURE__ */ t.jsx(hm, { className: "size-6" }) }),
          /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-1.5 max-w-[280px]", children: [
            /* @__PURE__ */ t.jsx("span", { className: "text-sm font-medium text-foreground", children: f("No sample data yet") }),
            /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground leading-relaxed", children: f(
              "Run this step to capture sample data. You can then use the result in following steps."
            ) })
          ] }),
          /* @__PURE__ */ t.jsx($e, { saving: e, invalid: !n.valid, children: /* @__PURE__ */ t.jsxs(
            O,
            {
              size: "sm",
              onClick: d,
              loading: y || e,
              disabled: !n.valid || v,
              className: "bg-primary text-primary-foreground hover:bg-primary/90",
              children: [
                /* @__PURE__ */ t.jsx(wn, { className: "size-3.5 fill-current" }),
                f("Test Step")
              ]
            }
          ) })
        ] })
      ] }),
      (m || y) && /* @__PURE__ */ t.jsx(
        Ea,
        {
          isValid: n.valid && !v,
          currentStep: n,
          isTesting: y,
          sampleData: s,
          sampleDataInput: r ?? null,
          lastTestDate: h,
          isSaving: e,
          onRetest: d,
          errorMessage: a,
          consoleLogs: o,
          onCancelTesting: () => {
            l(n.name), c == null || c();
          }
        }
      )
    ] });
  }
), Sj = (e) => q.isAction(e.type), sd = k.memo((e) => {
  const n = F(
    (s) => s.selectedStep ? q.getStep(s.selectedStep, s.flowVersion.trigger) : null
  );
  return M(n) || !Sj(n) ? null : /* @__PURE__ */ t.jsx(nd, { ...e, currentStep: n });
});
nd.displayName = "TestStepSectionImplementation";
sd.displayName = "TestActionSection";
const Cj = ({
  isValid: e,
  testType: n,
  mockData: s,
  isSaving: r,
  isTesting: a,
  onSimulateTrigger: o,
  onPollTrigger: i,
  onMcpToolTesting: l,
  onSaveMockAsSampleData: c
}) => {
  const { isLoadingDynamicProperties: u } = p.useContext(qt);
  return n === "simulation" || n === "webhook" || n === "chat-trigger" ? /* @__PURE__ */ t.jsxs("div", { className: "flex justify-center flex-col gap-2 items-center", children: [
    /* @__PURE__ */ t.jsx($e, { saving: r, invalid: !e, children: /* @__PURE__ */ t.jsxs(
      O,
      {
        variant: "outline",
        size: "sm",
        onClick: o,
        keyboardShortcut: "G",
        onKeyboardShortcut: o,
        disabled: !e || u,
        loading: r,
        children: [
          /* @__PURE__ */ t.jsx(Qs, { animation: !0, variant: "primary" }),
          f("Test Trigger")
        ]
      }
    ) }),
    !M(s) && JSON.stringify(s) !== "{}" && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      f("Or"),
      /* @__PURE__ */ t.jsx(
        O,
        {
          variant: "outline",
          size: "sm",
          onClick: () => c(s),
          loading: r,
          children: f("Use Mock Data")
        }
      )
    ] })
  ] }) : n === "mcp-tool" ? /* @__PURE__ */ t.jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ t.jsx($e, { saving: r, invalid: !e, children: /* @__PURE__ */ t.jsxs(
    O,
    {
      variant: "outline",
      size: "sm",
      onClick: l,
      keyboardShortcut: "G",
      onKeyboardShortcut: l,
      loading: a,
      disabled: !e || u,
      children: [
        /* @__PURE__ */ t.jsx(Qs, { animation: !0, variant: "primary" }),
        f("Test Tool")
      ]
    }
  ) }) }) : /* @__PURE__ */ t.jsx("div", { className: "flex justify-center", children: /* @__PURE__ */ t.jsx($e, { saving: r, invalid: !e, children: /* @__PURE__ */ t.jsxs(
    O,
    {
      variant: "outline",
      size: "sm",
      onClick: i,
      keyboardShortcut: "G",
      onKeyboardShortcut: i,
      loading: a,
      disabled: !e || u,
      children: [
        /* @__PURE__ */ t.jsx(Qs, { animation: !0, variant: "primary" }),
        f("Load Sample Data")
      ]
    }
  ) }) });
}, Ej = ({
  isWebhookTestingDialogOpen: e,
  setIsWebhookTestingDialogOpen: n
}) => {
  const [s, r] = p.useState(0), a = Pe().getValues();
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsx(
      O,
      {
        variant: "default",
        size: "sm",
        className: "flex items-center gap-2",
        onClick: () => {
          n(!0);
        },
        children: f("Generate Sample Data")
      }
    ),
    /* @__PURE__ */ t.jsx(
      Ca,
      {
        open: e,
        onOpenChange: (o) => {
          o || setTimeout(() => {
            r(s + 1);
          }, 200), n(o);
        },
        testingMode: "trigger",
        currentStep: a
      },
      `test-webhook-dialog-${s}`
    )
  ] });
}, Tj = ({
  note: e,
  resetSimulation: n,
  abortControllerRef: s
}) => /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-4 w-full px-3 pt-3", children: [
  /* @__PURE__ */ t.jsxs("div", { className: "flex gap-2 items-center justify-center w-full", children: [
    /* @__PURE__ */ t.jsx(Gn, { className: "size-4" }),
    /* @__PURE__ */ t.jsx("div", { children: f("Testing Trigger") }),
    /* @__PURE__ */ t.jsx("div", { className: "grow" }),
    /* @__PURE__ */ t.jsx(
      O,
      {
        variant: "outline",
        size: "sm",
        onClick: () => {
          n(), s.current.abort(), s.current = new AbortController();
        },
        children: f("Cancel")
      }
    )
  ] }),
  e && /* @__PURE__ */ t.jsxs(as, { children: [
    /* @__PURE__ */ t.jsx(Qh, { className: "h-4 w-4 text-warning" }),
    /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-1", children: [
      /* @__PURE__ */ t.jsxs(Bi, { children: [
        f("Action Required"),
        ":"
      ] }),
      /* @__PURE__ */ t.jsx(os, { children: /* @__PURE__ */ t.jsx("div", { className: "break-wrods", children: e }) })
    ] })
  ] })
] }), rd = k.memo(
  ({ pollResults: e, sampleData: n }) => {
    const s = Pj(n, (e == null ? void 0 : e.data) ?? []), a = Pe().getValues(), o = F(
      (i) => i.updateSampleData
    );
    return /* @__PURE__ */ t.jsxs("div", { className: "mb-3 px-3 pt-3", children: [
      /* @__PURE__ */ t.jsxs(
        Zn,
        {
          value: s,
          onValueChange: (i) => {
            const l = e == null ? void 0 : e.data.find(
              (c) => c.id === i
            );
            l && o({
              stepName: a.name,
              output: l.payload
            });
          },
          children: [
            /* @__PURE__ */ t.jsx(
              es,
              {
                className: "w-full",
                disabled: e && e.data.length === 0,
                children: e && e.data.length > 0 ? /* @__PURE__ */ t.jsx(
                  ts,
                  {
                    placeholder: f("No sample data available")
                  }
                ) : f("Old results were removed, retest for new sample data")
              }
            ),
            /* @__PURE__ */ t.jsx(ns, { children: e && e.data.map((i, l) => /* @__PURE__ */ t.jsx(Xe, { value: i.id, children: f("Result #") + (l + 1) }, i.id)) })
          ]
        }
      ),
      /* @__PURE__ */ t.jsx("span", { className: "text-sm mt-2 text-muted-foreground", children: f("The sample data can be used in the next steps.") })
    ] });
  }
);
rd.displayName = "TriggerEventSelect";
function Pj(e, n) {
  var s;
  if (e !== void 0)
    return (s = n.find((r) => ea(e, r.payload))) == null ? void 0 : s.id;
}
const ad = k.memo(
  ({ isSaving: e, flowVersionId: n, flowId: s }) => {
    const r = td(), a = F(
      (L) => L.selectedStep ? q.getStep(
        L.selectedStep,
        L.flowVersion.trigger
      ) : null
    ), o = a == null ? void 0 : a.name, { sampleData: i, sampleDataInput: l, lastTestDate: c } = F((L) => ({
      sampleData: o ? L.outputSampleData[o] : void 0,
      sampleDataInput: o ? L.inputSampleData[o] : void 0,
      lastTestDate: o && L.selectedStep ? Dj(L.flowVersion.trigger, o) : void 0
    })), { pollResults: u } = xp.usePollResults(
      n,
      s
    );
    if (!r || !a || a.type !== ee.PIECE)
      return null;
    const {
      pieceModel: d,
      isPieceLoading: h,
      testType: m,
      mockData: y,
      isValid: v,
      isSimulating: g,
      isSavingMockdata: j,
      isPollingTesting: x,
      errorMessage: N,
      isTestingDialogOpen: w,
      setIsTestingDialogOpen: b,
      abortControllerRef: E,
      saveMockAsSampleData: R,
      resetSimulation: S,
      fireTest: C
    } = r, T = !M(c) || !M(N), P = !!M(c) && !g;
    if (h || M(m))
      return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col h-full", children: [
        /* @__PURE__ */ t.jsx(Sn, { status: "idle" }),
        /* @__PURE__ */ t.jsx("div", { className: "flex justify-end px-3 py-2 shrink-0", children: /* @__PURE__ */ t.jsx(Gt, {}) })
      ] });
    const D = T && !g && !j, A = a.settings.triggerName, _ = () => {
      var L;
      switch (m) {
        case "simulation":
          return f("testPieceWebhookTriggerNote", {
            pieceName: d == null ? void 0 : d.displayName,
            triggerName: A ? (L = d == null ? void 0 : d.triggers[A]) == null ? void 0 : L.displayName : void 0
          });
        case "webhook":
          return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-2", children: [
            /* @__PURE__ */ t.jsx("p", { children: f(
              "Send Data to the webhook URL to generate sample data to use in the next steps"
            ) }),
            /* @__PURE__ */ t.jsx(
              Ej,
              {
                isWebhookTestingDialogOpen: w,
                setIsWebhookTestingDialogOpen: (H) => {
                  b(H), H || (E.current.abort(), E.current = new AbortController());
                }
              }
            )
          ] });
        default:
          return null;
      }
    };
    return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col h-full", children: [
      P && !N && /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col h-full", children: [
        /* @__PURE__ */ t.jsx(Sn, { status: "idle" }),
        /* @__PURE__ */ t.jsx("div", { className: "flex justify-end px-3 py-2 shrink-0", children: /* @__PURE__ */ t.jsx(Gt, {}) }),
        /* @__PURE__ */ t.jsxs("div", { className: "grow flex flex-col items-center justify-center w-full px-6 py-10 gap-4 text-center", children: [
          /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-center size-12 rounded-full bg-primary/10 text-primary", children: /* @__PURE__ */ t.jsx(Zh, { className: "size-6" }) }),
          /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-1.5 max-w-[280px]", children: [
            /* @__PURE__ */ t.jsx("span", { className: "text-sm font-medium text-foreground", children: f("No sample data yet") }),
            /* @__PURE__ */ t.jsx("span", { className: "text-xs text-muted-foreground leading-relaxed", children: f(
              "Test the trigger to capture sample data. You can then use the result in the following steps."
            ) })
          ] }),
          /* @__PURE__ */ t.jsx(
            Cj,
            {
              isValid: v,
              testType: m,
              isTesting: x || g || w,
              mockData: y,
              isSaving: e || j,
              onSimulateTrigger: C,
              onPollTrigger: C,
              onMcpToolTesting: C,
              onSaveMockAsSampleData: R
            }
          )
        ] })
      ] }),
      (!P || N) && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
        D && /* @__PURE__ */ t.jsx(
          Ea,
          {
            onRetest: C,
            hideCancel: !0,
            isValid: v,
            consoleLogs: null,
            isTesting: x,
            sampleData: i,
            sampleDataInput: l ?? null,
            errorMessage: N ?? null,
            lastTestDate: c,
            isSaving: e,
            children: (u == null ? void 0 : u.data) && !N && /* @__PURE__ */ t.jsx(
              rd,
              {
                pollResults: u,
                sampleData: i
              }
            )
          }
        ),
        g && /* @__PURE__ */ t.jsx(
          Tj,
          {
            note: _(),
            resetSimulation: S,
            abortControllerRef: E
          }
        )
      ] })
    ] });
  }
);
ad.displayName = "TestTriggerSection";
const Dj = (e, n) => {
  var r, a;
  const s = q.getStep(n, e);
  return (a = (r = s == null ? void 0 : s.settings) == null ? void 0 : r.sampleData) == null ? void 0 : a.lastTestDate;
}, od = k.memo(
  ({
    flowVersionId: e,
    isSaving: n,
    type: s,
    flowId: r,
    projectId: a
  }) => /* @__PURE__ */ t.jsx("div", { className: "flex flex-col h-full", children: s === ee.PIECE ? /* @__PURE__ */ t.jsx(
    ad,
    {
      flowId: r,
      isSaving: n,
      flowVersionId: e,
      projectId: a
    }
  ) : /* @__PURE__ */ t.jsx(
    sd,
    {
      flowVersionId: e,
      isSaving: n,
      projectId: a
    }
  ) })
);
od.displayName = "TestStepContainer";
const Rj = [
  "[data-test-panel-trigger]",
  "[data-radix-popper-content-wrapper]",
  '[role="dialog"]',
  '[data-slot="resizable-handle"]',
  "[data-panel-resize-handle-id]"
].join(","), id = ({
  mode: e,
  flowId: n,
  flowVersionId: s,
  projectId: r,
  stepType: a,
  showGenerateSampleData: o,
  showStepInputOutFromRun: i,
  saving: l
}) => {
  const [c, u] = F(
    (h) => [h.setTestPanelOpen, h.isTestPanelOpen]
  ), d = p.useRef(null);
  return p.useEffect(() => {
    if (e !== "drawer" || !u) return;
    const h = (m) => {
      var v;
      const y = m.target;
      y instanceof Element && ((v = d.current) != null && v.contains(y) || y.closest(Rj) || c(!1));
    };
    return document.addEventListener("pointerdown", h), () => document.removeEventListener("pointerdown", h);
  }, [e, u, c]), /* @__PURE__ */ t.jsxs(
    "div",
    {
      ref: d,
      className: $(
        "h-full w-full bg-background flex flex-col overflow-hidden border border-border",
        e === "drawer" && "rounded-t-xl shadow-lg border-b-0 border-x-0",
        e === "split" && "rounded-t-xl border-b-0"
      ),
      role: e === "drawer" ? "dialog" : void 0,
      children: [
        o && r && /* @__PURE__ */ t.jsx(
          od,
          {
            type: a,
            flowId: n,
            flowVersionId: s,
            projectId: r,
            isSaving: l
          }
        ),
        i && /* @__PURE__ */ t.jsx(aj, {})
      ]
    }
  );
};
id.displayName = "TestPanelHost";
const gn = "w-full justify-center bg-primary/5 enabled:hover:bg-primary/15 enabled:hover:text-primary text-primary border-primary/20", ld = () => {
  var d, h;
  const [
    e,
    n,
    s,
    r,
    a,
    o
  ] = F((m) => [
    m.selectedStep,
    m.flowVersion,
    m.isStepBeingTested,
    m.setTestPanelOpen,
    m.run,
    m.saving
  ]), i = e ? q.getStep(e, n.trigger) : null;
  if (!i)
    return null;
  const l = !M(
    (h = (d = i.settings) == null ? void 0 : d.sampleData) == null ? void 0 : h.lastTestDate
  ), c = s(i.name), u = () => r(!0);
  return Oj(i) ? /* @__PURE__ */ t.jsx(
    Aj,
    {
      currentStep: i,
      sampleDataExists: l,
      onOpenPanel: u,
      saving: o,
      hasRun: !M(a)
    }
  ) : Ij(i) ? lt.isManualTrigger({
    pieceName: i.settings.pieceName,
    triggerName: i.settings.triggerName ?? ""
  }) ? null : /* @__PURE__ */ t.jsx(
    kj,
    {
      sampleDataExists: l,
      stepIsRunning: c,
      stepIsValid: i.valid !== !1,
      onOpenPanel: u,
      saving: o,
      hasRun: !M(a)
    }
  ) : null;
}, Oj = (e) => q.isAction(e.type), Ij = (e) => e.type === ee.PIECE, Aj = ({
  currentStep: e,
  sampleDataExists: n,
  onOpenPanel: s,
  saving: r,
  hasRun: a
}) => {
  const o = e.valid !== !1, { isLoadingDynamicProperties: i } = p.useContext(qt), l = Qc();
  cd(o);
  const c = () => {
    s(), l == null || l.fireTest();
  };
  if (a)
    return /* @__PURE__ */ t.jsx(xn, { children: /* @__PURE__ */ t.jsx($e, { saving: r, invalid: !1, children: /* @__PURE__ */ t.jsx(
      O,
      {
        variant: "outline",
        onClick: s,
        disabled: r,
        className: gn,
        size: "sm",
        children: f("Show Output")
      }
    ) }) });
  if (n) {
    const d = r || !o || i;
    return /* @__PURE__ */ t.jsxs(xn, { children: [
      /* @__PURE__ */ t.jsx(
        O,
        {
          variant: "outline",
          onClick: s,
          disabled: r,
          className: "w-full justify-center",
          size: "sm",
          children: f("Show Sample Data")
        }
      ),
      /* @__PURE__ */ t.jsx($e, { saving: r, invalid: !o, children: /* @__PURE__ */ t.jsxs(
        O,
        {
          variant: "outline",
          onClick: c,
          disabled: d,
          keyboardShortcut: "G",
          onKeyboardShortcut: c,
          className: gn,
          size: "sm",
          children: [
            /* @__PURE__ */ t.jsx(wn, { className: "size-4 fill-current" }),
            f("Retest Step")
          ]
        }
      ) })
    ] });
  }
  const u = !o || r || i;
  return /* @__PURE__ */ t.jsx(xn, { children: /* @__PURE__ */ t.jsx($e, { saving: r, invalid: !o, children: /* @__PURE__ */ t.jsxs(
    O,
    {
      variant: "outline",
      onClick: c,
      disabled: u,
      keyboardShortcut: "G",
      onKeyboardShortcut: c,
      className: gn,
      size: "sm",
      children: [
        /* @__PURE__ */ t.jsx(wn, { className: "size-4 fill-current" }),
        f("Test Step")
      ]
    }
  ) }) });
}, kj = ({
  sampleDataExists: e,
  stepIsRunning: n,
  stepIsValid: s,
  onOpenPanel: r,
  saving: a,
  hasRun: o
}) => {
  const { isLoadingDynamicProperties: i } = p.useContext(qt), l = td();
  cd(s);
  const c = () => {
    r(), l == null || l.fireTest();
  }, u = (l == null ? void 0 : l.isTesting) ?? !1, d = (l == null ? void 0 : l.canFireTest) ?? !1, h = !s || a || i || n || u || !d;
  return o ? /* @__PURE__ */ t.jsx(xn, { children: /* @__PURE__ */ t.jsx(
    O,
    {
      variant: "outline",
      onClick: r,
      disabled: a,
      className: gn,
      size: "sm",
      children: f("Show Output")
    }
  ) }) : e ? /* @__PURE__ */ t.jsxs(xn, { children: [
    /* @__PURE__ */ t.jsx(
      O,
      {
        variant: "outline",
        onClick: r,
        disabled: a,
        className: "w-full justify-center",
        size: "sm",
        children: f("Show Sample Data")
      }
    ),
    /* @__PURE__ */ t.jsx($e, { saving: a, invalid: !s, children: /* @__PURE__ */ t.jsxs(
      O,
      {
        variant: "outline",
        onClick: c,
        disabled: h,
        keyboardShortcut: "G",
        onKeyboardShortcut: c,
        className: gn,
        size: "sm",
        children: [
          /* @__PURE__ */ t.jsx(wn, { className: "size-4 fill-current" }),
          f("Retest Trigger")
        ]
      }
    ) })
  ] }) : /* @__PURE__ */ t.jsx(xn, { children: /* @__PURE__ */ t.jsx($e, { saving: a, invalid: !s, children: /* @__PURE__ */ t.jsxs(
    O,
    {
      variant: "outline",
      onClick: c,
      disabled: h,
      keyboardShortcut: "G",
      onKeyboardShortcut: c,
      className: gn,
      size: "sm",
      "data-testid": "test-trigger-button",
      children: [
        /* @__PURE__ */ t.jsx(wn, { className: "size-4 fill-current" }),
        f("Test Trigger")
      ]
    }
  ) }) });
}, cd = (e) => {
  p.useEffect(() => {
    if (e) return;
    const n = /(Mac)/i.test(navigator.userAgent), s = (r) => {
      r.key.toLowerCase() === "g" && (n ? r.metaKey : r.ctrlKey) && je.error(f("Configure step first"));
    };
    return document.addEventListener("keydown", s), () => document.removeEventListener("keydown", s);
  }, [e]);
}, xn = ({ children: e }) => /* @__PURE__ */ t.jsxs(
  "div",
  {
    "data-test-panel-trigger": !0,
    className: "relative px-3 py-3 bg-background z-10 flex flex-col gap-2 shrink-0",
    children: [
      /* @__PURE__ */ t.jsx(
        "div",
        {
          "aria-hidden": !0,
          className: "pointer-events-none absolute -top-6 left-0 right-0 h-6 bg-gradient-to-t from-background to-transparent"
        }
      ),
      e
    ]
  }
);
ld.displayName = "TestStepCTAButton";
const Mj = (e) => e ? Je({
  auth: Te().min(1)
}).passthrough() : Je({}).passthrough(), _j = () => {
  const {
    predefinedInputs: e,
    setPredefinedInputs: n,
    selectedAction: s,
    selectedPiece: r
  } = Lt(), { pieces: a } = Rn.usePieces({}), o = a == null ? void 0 : a.find((g) => g.name === (r == null ? void 0 : r.pieceName)), i = (s == null ? void 0 : s.requireAuth) ?? !0, l = p.useMemo(
    () => Mj(i),
    [i]
  ), c = p.useMemo(
    () => s ? Object.fromEntries(
      Object.entries(s.props).map(([g, j]) => [
        g,
        j
      ])
    ) : {},
    [s]
  ), u = p.useMemo(() => {
    const g = {};
    return i && (e != null && e.auth) && (g.auth = e.auth), e != null && e.fields && Object.entries(e.fields).forEach(([j, x]) => {
      x.mode === st.CHOOSE_YOURSELF && !M(x.value) && (g[j] = x.value);
    }), g;
  }, [e, i]), d = Pn({
    resolver: Hs(l),
    defaultValues: u,
    mode: "onChange",
    reValidateMode: "onChange"
  });
  p.useEffect(() => {
    const g = d.watch((j, { name: x }) => {
      var E;
      if (!x || x === "auth") return;
      const N = Lt.getState().predefinedInputs, b = { ...(N == null ? void 0 : N.fields) ?? {} };
      ((E = b[x]) == null ? void 0 : E.mode) === st.CHOOSE_YOURSELF && (b[x] = {
        ...b[x],
        value: j[x]
      }), n({
        ...N,
        fields: b
      });
    });
    return () => g.unsubscribe();
  }, [d, n]);
  const h = (g) => {
    const j = M(g) ? void 0 : g;
    n({
      auth: j,
      fields: (e == null ? void 0 : e.fields) || {}
    }), d.setValue("auth", g ?? "");
  }, m = (g) => {
    var j, x;
    return ((x = (j = e == null ? void 0 : e.fields) == null ? void 0 : j[g]) == null ? void 0 : x.mode) ?? st.AGENT_DECIDE;
  }, y = (g, j) => {
    const x = (e == null ? void 0 : e.fields) ?? {}, N = x[g], w = {
      mode: j,
      value: j === st.CHOOSE_YOURSELF ? (N == null ? void 0 : N.value) ?? d.getValues(g) : void 0
    };
    n({
      ...e,
      fields: {
        ...x,
        [g]: w
      }
    }), j === st.CHOOSE_YOURSELF ? d.setValue(g, w.value ?? "") : d.setValue(g, void 0, { shouldDirty: !1 });
  }, v = i && (o == null ? void 0 : o.auth);
  return /* @__PURE__ */ t.jsx(Dn, { ...d, children: /* @__PURE__ */ t.jsxs(Ze, { className: "h-full", children: [
    /* @__PURE__ */ t.jsxs("div", { className: "flex items-start border-b gap-3 p-4", children: [
      /* @__PURE__ */ t.jsx("div", { className: "flex size-11 shrink-0 items-center justify-center rounded-sm border bg-background", children: /* @__PURE__ */ t.jsx(
        "img",
        {
          className: "size-8 object-contain",
          src: o == null ? void 0 : o.logoUrl,
          alt: o == null ? void 0 : o.displayName
        }
      ) }),
      /* @__PURE__ */ t.jsxs("div", { className: "min-w-0 flex-1", children: [
        /* @__PURE__ */ t.jsx("div", { className: "text-sm font-medium", children: s == null ? void 0 : s.displayName }),
        (s == null ? void 0 : s.description) && /* @__PURE__ */ t.jsx("p", { className: "mt-0.5 text-xs text-muted-foreground line-clamp-2", children: s.description })
      ] })
    ] }),
    /* @__PURE__ */ t.jsxs("div", { className: "space-y-6 p-4", children: [
      v && !M(o) && /* @__PURE__ */ t.jsx(
        ef,
        {
          piece: o,
          value: d.watch("auth"),
          onChange: h,
          placeholder: f("Connect your account")
        }
      ),
      Object.keys(c).length > 0 && /* @__PURE__ */ t.jsx("div", { className: "space-y-5", children: Object.entries(c).map(([g, j]) => {
        if (j.type === It.MARKDOWN)
          return /* @__PURE__ */ t.jsx(
            Ms,
            {
              markdown: j.description,
              variables: {},
              variant: j.variant
            },
            g
          );
        const N = m(g), w = N === st.CHOOSE_YOURSELF;
        return /* @__PURE__ */ t.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ t.jsxs("h3", { className: "text-sm font-medium", children: [
              j.displayName,
              " ",
              j.required && "*"
            ] }),
            /* @__PURE__ */ t.jsxs(
              Zn,
              {
                value: N,
                onValueChange: (b) => y(g, b),
                children: [
                  /* @__PURE__ */ t.jsx(es, { className: "w-80", children: /* @__PURE__ */ t.jsx(ts, {}) }),
                  /* @__PURE__ */ t.jsxs(ns, { children: [
                    /* @__PURE__ */ t.jsx(Xe, { value: st.AGENT_DECIDE, children: f("Let agent decide") }),
                    /* @__PURE__ */ t.jsx(Xe, { value: st.CHOOSE_YOURSELF, children: f("Set value myself") }),
                    !j.required && /* @__PURE__ */ t.jsx(Xe, { value: st.LEAVE_EMPTY, children: f("Leave empty") })
                  ] })
                ]
              }
            )
          ] }),
          w && /* @__PURE__ */ t.jsx(
            pe,
            {
              name: g,
              control: d.control,
              render: ({ field: b }) => Ui({
                field: b,
                hideLabel: !0,
                propertyName: g,
                inputName: g,
                property: j,
                allowDynamicValues: !1,
                markdownVariables: {},
                useMentionTextInput: !0,
                disabled: !1,
                dynamicInputModeToggled: !1,
                form: d,
                dynamicPropsInfo: {
                  pieceName: (o == null ? void 0 : o.name) ?? "",
                  pieceVersion: (o == null ? void 0 : o.version) ?? "",
                  actionOrTriggerName: (s == null ? void 0 : s.name) ?? "",
                  placedInside: "predefinedAgentInputs",
                  updateFormSchema: null,
                  updatePropertySettingsSchema: null
                },
                propertySettings: null
              })
            }
          )
        ] }, g);
      }) })
    ] })
  ] }) });
}, Lj = [
  "@activepieces/piece-ai",
  "@activepieces/piece-mcp",
  "@activepieces/piece-openai",
  "@activepieces/piece-claude",
  "@activepieces/piece-google-gemini",
  "@activepieces/piece-grok-xai"
];
function Fj({
  tools: e,
  onToolsUpdate: n
}) {
  const {
    showAddPieceDialog: s,
    selectedPage: r,
    searchQuery: a,
    selectedAction: o,
    isPieceAuthSet: i,
    selectedPiece: l,
    editingPieceTool: c,
    createNewPieceTool: u,
    goBackToActionsList: d,
    handlePieceSelect: h,
    handleActionSelect: m,
    goBackToPiecesList: y,
    closePieceDialog: v
  } = Lt(), [g] = Ws(a, 300), { metadata: j, isLoading: x } = En.useAllStepsMetadata({
    searchQuery: g,
    type: "action"
  }), N = p.useMemo(() => (j == null ? void 0 : j.filter(
    (C) => "suggestedActions" in C && "suggestedTriggers" in C
  ).filter((C) => !Lj.includes(C.pieceName))) ?? [], [j]);
  p.useEffect(() => {
    var C;
    if (s && !M(c) && N.length > 0) {
      const T = N.find(
        (I) => I.pieceName === c.pieceMetadata.pieceName
      );
      if (T) {
        h(T);
        const I = (C = T.suggestedActions) == null ? void 0 : C.find((P) => Us.createPieceToolName(T.pieceName, P.name) === c.toolName);
        I && m(I);
      }
    }
  }, [s, c, N]);
  const w = i(), b = () => {
    const C = u();
    if (!M(C)) {
      if (M(c))
        n([...e, C]), je("Piece tool added");
      else {
        const T = e.map(
          (I) => I.toolName === c.toolName ? C : I
        );
        n(T), je("Piece tool updated");
      }
      v();
    }
  }, E = (C) => {
    C || v();
  }, R = () => {
    switch (r) {
      case "pieces-list":
        return /* @__PURE__ */ t.jsx(
          yg,
          {
            isPiecesLoading: x,
            pieceMetadata: N
          }
        );
      case "actions-list":
        return /* @__PURE__ */ t.jsx(vg, { tools: e });
      case "action-inputs":
        return /* @__PURE__ */ t.jsx(_j, {});
    }
  }, S = () => {
    switch (r) {
      case "pieces-list":
        return f("Connect apps with the agent");
      case "actions-list":
        return l && /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-start gap-2", children: [
          /* @__PURE__ */ t.jsxs(te, { children: [
            /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
              O,
              {
                variant: "ghost",
                size: "icon",
                onClick: y,
                children: /* @__PURE__ */ t.jsx(Ds, { className: "size-4" })
              }
            ) }),
            /* @__PURE__ */ t.jsx(Q, { children: f("Back") })
          ] }),
          f(l.displayName)
        ] });
      case "action-inputs":
        return o && /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-start gap-2", children: [
          /* @__PURE__ */ t.jsxs(te, { children: [
            /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
              O,
              {
                variant: "ghost",
                size: "icon",
                onClick: d,
                children: /* @__PURE__ */ t.jsx(Ds, { className: "size-4" })
              }
            ) }),
            /* @__PURE__ */ t.jsx(Q, { children: f("Back") })
          ] }),
          o.displayName
        ] });
    }
  };
  return /* @__PURE__ */ t.jsx(ut, { open: s, onOpenChange: E, children: /* @__PURE__ */ t.jsxs(ht, { className: "w-[90vw] max-w-[750px] h-[80vh] max-h-[800px] flex flex-col overflow-hidden p-0", children: [
    /* @__PURE__ */ t.jsx(ft, { className: "min-h-16 flex px-4 items-start justify-center mb-0 border-b", children: /* @__PURE__ */ t.jsx(mt, { children: S() }) }),
    R(),
    r === "action-inputs" && /* @__PURE__ */ t.jsxs(pt, { className: "border-t p-4 mt-auto", children: [
      /* @__PURE__ */ t.jsx(yn, { asChild: !0, children: /* @__PURE__ */ t.jsx(O, { type: "button", variant: "outline", children: f("Close") }) }),
      /* @__PURE__ */ t.jsx(
        O,
        {
          loading: !1,
          disabled: !w,
          type: "button",
          onClick: b,
          children: c ? f("Update Tool") : f("Add Tool")
        }
      )
    ] })
  ] }) });
}
const zj = [
  "/ap-cdn/pieces/youtube.png",
  "/ap-cdn/pieces/slack.png",
  "/ap-cdn/pieces/github.png",
  "/ap-cdn/pieces/notion.png"
], $j = ({
  disabled: e,
  toolsField: n,
  selectedProvider: s
}) => {
  const r = Array.isArray(n.value) ? n.value : [], a = (d) => n.onChange(d), o = (d) => {
    a(r.filter((h) => d !== h.toolName));
  }, i = r.filter((d) => d.type === ot.FLOW), l = r.filter((d) => d.type === ot.MCP), c = r.filter(
    (d) => d.type === ot.KNOWLEDGE_BASE
  ), u = r.filter((d) => d.type === ot.PIECE).reduce((d, h) => {
    var y;
    const m = (y = h.pieceMetadata) == null ? void 0 : y.pieceName;
    return m && (d[m] ?? (d[m] = [])).push(h), d;
  }, {});
  return /* @__PURE__ */ t.jsxs("div", { children: [
    /* @__PURE__ */ t.jsx("h2", { className: "text-sm font-medium", children: f("Agent Tools") }),
    /* @__PURE__ */ t.jsx("div", { className: "mt-2", children: i.length + l.length + Object.keys(u).length > 0 ? /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      /* @__PURE__ */ t.jsxs(
        tf,
        {
          type: "single",
          collapsible: !0,
          className: "border rounded-md overflow-hidden shadow-none",
          children: [
            Object.entries(u).map(([d, h]) => /* @__PURE__ */ t.jsx(
              Pp,
              {
                disabled: e,
                tools: h,
                removeTool: o
              },
              d
            )),
            i.length > 0 && /* @__PURE__ */ t.jsx(
              vp,
              {
                disabled: e,
                tools: i,
                removeTool: o
              }
            ),
            l.length > 0 && /* @__PURE__ */ t.jsx(
              yp,
              {
                disabled: e,
                tools: l,
                removeTool: o
              }
            )
          ]
        }
      ),
      /* @__PURE__ */ t.jsx(io, { disabled: e, align: "start", children: /* @__PURE__ */ t.jsxs(O, { variant: "outline", className: "mt-2", children: [
        /* @__PURE__ */ t.jsx(_e, { className: "size-4 mr-2" }),
        f("Add")
      ] }) })
    ] }) : /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col items-center justify-center gap-4 rounded-xl border bg-card px-4 py-8 text-center", children: [
      /* @__PURE__ */ t.jsxs("div", { className: "flex items-center", children: [
        zj.slice(0, 4).map((d, h) => /* @__PURE__ */ t.jsx(
          "div",
          {
            className: "relative flex size-9 items-center justify-center rounded-full border bg-background",
            style: { marginLeft: h === 0 ? 0 : -10 },
            children: /* @__PURE__ */ t.jsx(
              "img",
              {
                src: d,
                alt: d,
                className: "size-4 object-contain"
              }
            )
          },
          d
        )),
        /* @__PURE__ */ t.jsx(
          "div",
          {
            className: "relative flex size-9 items-center justify-center rounded-full border text-[10px] bg-background text-foreground font-medium",
            style: { marginLeft: -10 },
            children: /* @__PURE__ */ t.jsx("span", { children: "+500" })
          }
        )
      ] }),
      /* @__PURE__ */ t.jsx("p", { className: "text-sm font-medium text-muted-foreground", children: f("Connect apps, flows, MCPs and more.") }),
      /* @__PURE__ */ t.jsx(io, { disabled: e, align: "center", children: /* @__PURE__ */ t.jsxs(O, { variant: "outline", className: "gap-2", children: [
        /* @__PURE__ */ t.jsx(_e, { className: "size-4" }),
        f("Add")
      ] }) })
    ] }) }),
    /* @__PURE__ */ t.jsx(
      Tp,
      {
        disabled: e,
        tools: c,
        allTools: r,
        removeTool: o,
        onToolsUpdate: a,
        selectedProvider: s
      }
    ),
    /* @__PURE__ */ t.jsx(Ip, { onToolsUpdate: a, tools: r }),
    /* @__PURE__ */ t.jsx(Fj, { tools: r, onToolsUpdate: a }),
    /* @__PURE__ */ t.jsx(nf, { tools: r, onToolsUpdate: a })
  ] });
}, Vj = (e) => {
  const { pieceModel: n, updateFormSchema: s, updatePropertySettingsSchema: r } = ia(), a = Pe();
  if (M(n))
    return /* @__PURE__ */ t.jsx("div", { className: "space-y-3", children: Array.from({ length: 5 }).map((c, u) => /* @__PURE__ */ t.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ t.jsxs("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ t.jsx(ce, { className: "w-40 h-4" }),
        /* @__PURE__ */ t.jsx(ce, { className: "size-8" })
      ] }),
      /* @__PURE__ */ t.jsx(ce, { className: "w-full h-12" })
    ] }, u)) });
  const o = e.step.settings.actionName, i = n.actions[o], l = (({ auth: c, ...u }) => u)(i.props);
  return /* @__PURE__ */ t.jsx("div", { className: "w-full", children: /* @__PURE__ */ t.jsx("div", { className: "flex flex-col gap-4 w-full", children: Object.keys(l).map((c) => /* @__PURE__ */ t.jsx(
    pe,
    {
      name: `settings.input.${c}`,
      control: a.control,
      render: ({ field: u }) => Bj({
        field: u,
        allowDynamicValues: !1,
        dynamicInputModeToggled: !1,
        markdownVariables: {},
        propertyName: c,
        inputName: `settings.input.${c}`,
        property: l[c],
        useMentionTextInput: !0,
        disabled: e.readonly,
        form: a,
        dynamicPropsInfo: {
          pieceName: e.step.settings.pieceName,
          pieceVersion: e.step.settings.pieceVersion,
          actionOrTriggerName: o,
          placedInside: "stepSettings",
          updateFormSchema: s,
          updatePropertySettingsSchema: r
        },
        propertySettings: null
      })
    },
    c
  )) }) });
}, Bj = (e) => {
  var a, o;
  const { propertyName: n, disabled: s, field: r } = e;
  switch (n) {
    case us.AGENT_TOOLS: {
      const i = (o = (a = e.form) == null ? void 0 : a.watch) == null ? void 0 : o.call(
        a,
        "settings.input.aiProviderModel"
      );
      return /* @__PURE__ */ t.jsx(
        $j,
        {
          disabled: s,
          toolsField: r,
          selectedProvider: i == null ? void 0 : i.provider
        }
      );
    }
    case us.STRUCTURED_OUTPUT:
      return /* @__PURE__ */ t.jsx(
        wg,
        {
          disabled: s,
          structuredOutputField: r
        }
      );
    case us.AI_PROVIDER_MODEL: {
      const i = r.value.provider, l = r.value.model;
      return /* @__PURE__ */ t.jsx(
        sf,
        {
          defaultModel: l,
          defaultProvider: i,
          onChange: r.onChange,
          disabled: s
        }
      );
    }
    default:
      return Ui({
        ...e,
        enableMarkdownForInputWithMention: n === us.PROMPT
      });
  }
}, Uj = Je({
  packageName: Te().min(1, f("The package name is required"))
}), dd = ({ children: e, onAdd: n }) => {
  var l, c, u;
  const [s, r] = p.useState(!1), a = Pn({
    defaultValues: {},
    resolver: Hs(Uj)
  }), { mutate: o, isPending: i } = Re({
    mutationFn: async () => {
      const { packageName: d } = a.getValues(), h = await dn.get(
        `https://registry.npmjs.org/${d}`
      );
      return {
        packageName: d,
        packageVersion: h["dist-tags"].latest
      };
    },
    onSuccess: (d) => {
      n(d), r(!1), je.success(f("Package added successfully"), {
        duration: 3e3
      });
    },
    onError: () => {
      a.setError("root.serverError", {
        message: f("Could not fetch package version")
      });
    }
  });
  return /* @__PURE__ */ t.jsxs(ut, { open: s, onOpenChange: (d) => r(d), children: [
    /* @__PURE__ */ t.jsx(ki, { asChild: !0, children: e }),
    /* @__PURE__ */ t.jsxs(ht, { className: "sm:max-w-[425px]", children: [
      /* @__PURE__ */ t.jsxs(ft, { children: [
        /* @__PURE__ */ t.jsx(mt, { children: f("Add NPM Package") }),
        /* @__PURE__ */ t.jsx(Zr, { children: f("Type the name of the npm package you want to add.") })
      ] }),
      /* @__PURE__ */ t.jsx(Dn, { ...a, children: /* @__PURE__ */ t.jsxs(
        "form",
        {
          onSubmit: (d) => a.handleSubmit(() => o())(d),
          className: "flex flex-col gap-4",
          children: [
            /* @__PURE__ */ t.jsx(
              pe,
              {
                control: a.control,
                name: "packageName",
                render: ({ field: d }) => /* @__PURE__ */ t.jsxs(we, { children: [
                  /* @__PURE__ */ t.jsx(vn, { htmlFor: "packageName", children: f("Package Name") }),
                  /* @__PURE__ */ t.jsx(
                    Et,
                    {
                      ...d,
                      id: "packageName",
                      type: "text",
                      placeholder: "hello-world",
                      className: "rounded-sm"
                    }
                  ),
                  /* @__PURE__ */ t.jsx(Nn, {})
                ] })
              }
            ),
            /* @__PURE__ */ t.jsx(rf, { children: f("The latest version will be fetched and added") }),
            ((u = (c = (l = a == null ? void 0 : a.formState) == null ? void 0 : l.errors) == null ? void 0 : c.root) == null ? void 0 : u.serverError) && /* @__PURE__ */ t.jsx(Nn, { children: a.formState.errors.root.serverError.message })
          ]
        }
      ) }),
      /* @__PURE__ */ t.jsxs(pt, { children: [
        /* @__PURE__ */ t.jsx(yn, { asChild: !0, children: /* @__PURE__ */ t.jsx(O, { type: "button", variant: "outline", children: f("Cancel") }) }),
        /* @__PURE__ */ t.jsx(O, { type: "submit", loading: i, onClick: () => o(), children: f("Add") })
      ] })
    ] })
  ] });
};
dd.displayName = "AddNpmDialog";
const Wj = yr.baseTheme({
  "&.cm-editor.cm-focused": {
    outline: "none"
  }
}), Hj = ({
  sourceCode: e,
  readonly: n,
  onChange: s,
  applyCodeToCurrentStep: r,
  minHeight: a
}) => {
  const { code: o, packageJson: i } = e, [l, c] = p.useState("code"), [u, d] = p.useState("typescript"), h = typeof r == "function", { theme: m } = Ai(), y = p.useRef(null), v = m === "dark" ? df : uf, { data: g } = Me.useFlag(
    ze.ALLOW_NPM_PACKAGES_IN_CODE_STEP
  ), j = [
    Wj,
    af.readOnly.of(n),
    yr.editable.of(!n),
    u === "json" ? of() : zf({ jsx: !1, typescript: !0 })
  ];
  function x() {
    c("packageJson"), d("json");
  }
  function N() {
    c("code"), d("typescript");
  }
  function w({
    packageName: b,
    packageVersion: E
  }) {
    try {
      const R = hf(JSON.parse(i), {
        dependencies: {
          [b]: E
        }
      });
      c("packageJson"), s({ code: o, packageJson: JSON.stringify(R, null, 2) });
    } catch (R) {
      console.error(R), Vi();
    }
  }
  return /* @__PURE__ */ t.jsxs(
    "div",
    {
      className: "flex flex-col gap-2 border rounded py-2 px-2 transition-all",
      ref: y,
      children: [
        /* @__PURE__ */ t.jsxs("div", { className: "flex flex-row justify-center items-center h-full", children: [
          /* @__PURE__ */ t.jsxs("div", { className: "flex justify-start gap-4 items-center", children: [
            /* @__PURE__ */ t.jsx(
              "div",
              {
                className: $("text-sm cursor-pointer", {
                  "font-bold": l === "code"
                }),
                onClick: () => N(),
                children: f("Code")
              }
            ),
            g && /* @__PURE__ */ t.jsx(
              "div",
              {
                className: $("text-sm cursor-pointer", {
                  "font-bold": l === "packageJson"
                }),
                onClick: () => x(),
                children: f("Dependencies")
              }
            )
          ] }),
          /* @__PURE__ */ t.jsx("div", { className: "flex grow" }),
          h ? /* @__PURE__ */ t.jsxs(
            O,
            {
              variant: "outline",
              className: "flex gap-2",
              size: "sm",
              onClick: r,
              children: [
                /* @__PURE__ */ t.jsx($f, { className: "w-3 h-3" }),
                f("Use code")
              ]
            }
          ) : g && /* @__PURE__ */ t.jsx(dd, { onAdd: w, children: /* @__PURE__ */ t.jsxs(
            O,
            {
              variant: "outline",
              className: "flex gap-2",
              size: "sm",
              onClick: () => {
              },
              children: [
                /* @__PURE__ */ t.jsx(lf, { className: "w-4 h-4" }),
                f("Add package")
              ]
            }
          ) })
        ] }),
        /* @__PURE__ */ t.jsx(
          cf,
          {
            value: l === "code" ? o : i,
            className: "border-none",
            minHeight: a ?? "200px",
            width: "100%",
            height: "100%",
            maxWidth: "100%",
            basicSetup: {
              foldGutter: !0,
              lineNumbers: !0,
              searchKeymap: !1,
              lintKeymap: !0,
              autocompletion: !0,
              foldKeymap: !0
            },
            lang: "typescript",
            onChange: (b) => {
              s(
                l === "code" ? { code: b, packageJson: i } : { code: o, packageJson: b }
              );
            },
            theme: v,
            readOnly: n,
            extensions: [...j, yr.lineWrapping]
          }
        )
      ]
    }
  );
}, Gj = "\nTo use data from previous steps in your code, include them as pairs of keys and values below. \n\nYou can access these inputs in your code using `inputs.key`, where `key` is the name you assigned below.  \n", qj = `
**const code** is the entry to the code. If it is removed or renamed, your step will fail.
`, ud = k.memo(({ readonly: e }) => {
  const n = Pe();
  return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-4", children: [
    /* @__PURE__ */ t.jsx(
      pe,
      {
        control: n.control,
        name: "settings.input",
        render: ({ field: s }) => /* @__PURE__ */ t.jsxs(we, { children: [
          /* @__PURE__ */ t.jsx("div", { className: "pb-4", children: /* @__PURE__ */ t.jsx(Ms, { markdown: Gj, variant: eo.INFO }) }),
          /* @__PURE__ */ t.jsx("div", { className: "flex items-center justify-between mb-2!", children: /* @__PURE__ */ t.jsx(bt, { children: f("Inputs") }) }),
          /* @__PURE__ */ t.jsx(
            As,
            {
              disabled: e,
              values: s.value,
              onChange: s.onChange,
              keyInputClassName: "h-[38px]",
              renderValueInput: ({ value: r, onChange: a, disabled: o }) => /* @__PURE__ */ t.jsx(
                _s,
                {
                  initialValue: r,
                  disabled: o,
                  onChange: a
                }
              )
            }
          ),
          /* @__PURE__ */ t.jsx(Nn, {})
        ] })
      }
    ),
    /* @__PURE__ */ t.jsx("div", { children: /* @__PURE__ */ t.jsx(
      Ms,
      {
        markdown: qj,
        variant: eo.WARNING
      }
    ) }),
    /* @__PURE__ */ t.jsx(
      pe,
      {
        control: n.control,
        name: "settings.sourceCode",
        render: ({ field: s }) => /* @__PURE__ */ t.jsxs(we, { children: [
          /* @__PURE__ */ t.jsx(
            Hj,
            {
              sourceCode: s.value,
              onChange: s.onChange,
              readonly: e
            }
          ),
          /* @__PURE__ */ t.jsx(Nn, {})
        ] })
      }
    )
  ] });
});
ud.displayName = "CodeSettings";
const Kj = ({
  selectedBranchIndex: e,
  displayName: n,
  branchName: s,
  setDisplayName: r,
  setBranchName: a,
  readonly: o,
  isEditingStepOrBranchName: i,
  setIsEditingStepOrBranchName: l,
  setSelectedBranchIndex: c,
  tooltipTitle: u,
  tooltipDescription: d,
  pieceVersion: h,
  stepIndex: m
}) => {
  const y = !M(e), v = !y && !i && (!!u || !!d || !!h), g = () => {
    o || l(!0);
  };
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    y ? /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      /* @__PURE__ */ t.jsx(
        "div",
        {
          className: "truncate cursor-pointer hover:underline",
          onClick: (j) => {
            j.stopPropagation(), c(null);
          },
          children: n
        }
      ),
      "/",
      /* @__PURE__ */ t.jsx(
        Jr,
        {
          onValueChange: (j) => {
            j && a(j);
          },
          readonly: o,
          value: s,
          tooltipContent: o ? "" : f("Edit Branch Name"),
          isEditing: i,
          setIsEditing: l
        },
        s
      )
    ] }) : i ? /* @__PURE__ */ t.jsx(
      Yj,
      {
        value: n,
        onValueChange: r,
        onCommit: () => l(!1)
      }
    ) : /* @__PURE__ */ t.jsx(ks, { children: /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsxs(
        "div",
        {
          role: o ? void 0 : "button",
          tabIndex: o ? void 0 : 0,
          onClick: o ? void 0 : g,
          onKeyDown: o ? void 0 : (j) => {
            (j.key === "Enter" || j.key === " ") && (j.preventDefault(), g());
          },
          "aria-label": o ? void 0 : f("Edit Step Name"),
          className: $(
            "flex items-center gap-1.5 min-w-0",
            !o && "cursor-text rounded-sm hover:text-foreground/80 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          ),
          children: [
            /* @__PURE__ */ t.jsxs("span", { className: "truncate text-foreground", children: [
              typeof m == "number" && `${m}. `,
              n
            ] }),
            !o && /* @__PURE__ */ t.jsx(zt, { className: "size-3.5 shrink-0 text-muted-foreground" })
          ]
        }
      ) }),
      v && /* @__PURE__ */ t.jsx(Q, { side: "bottom", className: "max-w-xs", children: /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-1", children: [
        u && /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ t.jsx("span", { className: "font-medium text-sm", children: u }),
          h && /* @__PURE__ */ t.jsxs("span", { className: "text-[11px] font-mono text-background/90", children: [
            "(v",
            h,
            ")"
          ] })
        ] }),
        !u && h && /* @__PURE__ */ t.jsxs("span", { className: "text-[11px] font-mono text-background/90", children: [
          "(v",
          h,
          ")"
        ] }),
        d && /* @__PURE__ */ t.jsx("div", { className: "text-xs text-background/90", children: d })
      ] }) })
    ] }) }),
    y && !i && !o && /* @__PURE__ */ t.jsx(ks, { children: /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
        O,
        {
          variant: "ghost",
          size: "icon",
          className: "size-6 shrink-0 text-muted-foreground hover:text-foreground",
          onClick: g,
          "aria-label": f("Edit Branch Name"),
          children: /* @__PURE__ */ t.jsx(zt, { className: "size-3.5" })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Edit Branch Name") })
    ] }) })
  ] });
}, Yj = ({
  value: e,
  onValueChange: n,
  onCommit: s
}) => {
  const r = p.useRef(null), a = p.useCallback((i) => {
    r.current = i, i && requestAnimationFrame(() => {
      i.focus();
      const l = document.createRange(), c = window.getSelection();
      l.selectNodeContents(i), c == null || c.removeAllRanges(), c == null || c.addRange(l);
    });
  }, []), o = () => {
    var l;
    const i = (((l = r.current) == null ? void 0 : l.textContent) ?? "").trim();
    i.length > 0 && i !== e && n(i), s();
  };
  return /* @__PURE__ */ t.jsx(
    "div",
    {
      ref: a,
      contentEditable: !0,
      suppressContentEditableWarning: !0,
      className: "truncate focus:outline-hidden break-all",
      onBlur: o,
      onKeyDown: (i) => {
        i.key === "Escape" ? (i.preventDefault(), r.current && (r.current.textContent = e), s()) : i.key === "Enter" && (i.preventDefault(), o());
      },
      children: e
    }
  );
}, Xj = f(
  `Select the items to iterate over from the previous step by clicking on the **Items** input, which should be a **list** of items.

The loop will iterate over each item in the list and execute the next step for every item.`
), hd = k.memo(({ readonly: e }) => {
  const n = Pe();
  return /* @__PURE__ */ t.jsx(
    pe,
    {
      control: n.control,
      name: "settings.items",
      render: ({ field: s }) => /* @__PURE__ */ t.jsxs(we, { className: "flex flex-col gap-2", children: [
        /* @__PURE__ */ t.jsx(Ms, { markdown: Xj }),
        /* @__PURE__ */ t.jsx(bt, { showRequiredIndicator: !0, children: f("Items") }),
        /* @__PURE__ */ t.jsx(
          _s,
          {
            disabled: e,
            onChange: s.onChange,
            initialValue: s.value,
            placeholder: f("Select an array of items")
          }
        )
      ] })
    }
  );
});
hd.displayName = "LoopsSettings";
function fd(e) {
  var N, w;
  const [n, s] = p.useState(!1), [r, a] = p.useState(!1), [o, i] = p.useState(null), { pieceModel: l, isLoading: c } = Rn.usePiece({
    name: e.piece.name,
    version: (o == null ? void 0 : o.pieceVersion) ?? e.piece.version
  }), u = Pe(), d = Ve().checkAccess(
    Ie.WRITE_APP_CONNECTION
  ), {
    data: h,
    isLoading: m,
    refetch: y
  } = ff.useAppConnections({
    request: {
      pieceName: e.piece.name,
      projectId: oe.getProjectId(),
      limit: 1e3
    },
    pieceAuth: e.piece.auth,
    extraKeys: [e.piece.name, oe.getProjectId()],
    staleTime: 0
  }), v = (N = h == null ? void 0 : h.data) == null ? void 0 : N.find(
    (b) => b.externalId === $n(u.getValues().settings.input.auth ?? "")
  ), g = (v == null ? void 0 : v.scope) === hs.PLATFORM, j = ((w = u.getValues().settings.propertySettings.auth) == null ? void 0 : w.type) === pi.DYNAMIC, x = mf();
  return /* @__PURE__ */ t.jsx(
    pe,
    {
      control: u.control,
      name: "settings.input.auth",
      render: ({ field: b }) => {
        var E, R, S, C, T, I, P;
        return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
          (m || !l) && /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-2", children: [
            /* @__PURE__ */ t.jsx(bt, { showRequiredIndicator: !0, children: f("Connection") }),
            /* @__PURE__ */ t.jsx(
              Ft,
              {
                options: [],
                disabled: !0,
                loading: m,
                placeholder: f("Select a connection"),
                value: b.value,
                onChange: (D) => b.onChange(D),
                showDeselect: !1,
                onRefresh: () => {
                },
                showRefresh: !1
              }
            )
          ] }),
          !m && l && e.piece.auth && /* @__PURE__ */ t.jsxs(
            pf,
            {
              property: e.piece.auth,
              propertyName: "auth",
              field: b,
              disabled: e.disabled,
              inputName: "settings.input.auth",
              allowDynamicValues: !e.isTrigger,
              dynamicInputModeToggled: j,
              isForConnectionSelect: !0,
              children: [
                /* @__PURE__ */ t.jsx(
                  gf,
                  {
                    reconnectConnection: o,
                    isGlobalConnection: g,
                    piece: l,
                    open: n,
                    setOpen: (D, A) => {
                      s(D), A && (y(), b.onChange(Qo(A.externalId)));
                    }
                  },
                  `CreateOrEditConnectionDialog-open-${n}`
                ),
                /* @__PURE__ */ t.jsxs(
                  Zn,
                  {
                    open: r,
                    onOpenChange: a,
                    defaultValue: b.value,
                    onValueChange: b.onChange,
                    disabled: e.disabled,
                    children: [
                      /* @__PURE__ */ t.jsxs("div", { className: "relative", children: [
                        b.value && !b.disabled && v && (!g || x) && /* @__PURE__ */ t.jsx("div", { className: "z-50 absolute right-8 top-1 ", children: /* @__PURE__ */ t.jsx(
                          Fe,
                          {
                            hasPermission: d,
                            children: /* @__PURE__ */ t.jsx(
                              O,
                              {
                                variant: "ghost",
                                size: "xs",
                                loading: c,
                                onClick: (D) => {
                                  D.stopPropagation(), i(v), a(!1), s(!0);
                                },
                                disabled: !d,
                                children: f("Reconnect")
                              }
                            )
                          }
                        ) }),
                        /* @__PURE__ */ t.jsxs(es, { className: "flex gap-2 items-center", children: [
                          /* @__PURE__ */ t.jsx(
                            ts,
                            {
                              className: "truncate grow shrink",
                              placeholder: f("Select a connection"),
                              "data-testid": "select-connection-value",
                              children: !M(b.value) && !M(
                                (E = h == null ? void 0 : h.data) == null ? void 0 : E.find(
                                  (D) => D.externalId === $n(b.value)
                                )
                              ) ? /* @__PURE__ */ t.jsxs("div", { className: "truncate grow shrink flex items-center gap-2", children: [
                                ((S = (R = h == null ? void 0 : h.data) == null ? void 0 : R.find(
                                  (D) => D.externalId === $n(b.value)
                                )) == null ? void 0 : S.scope) === hs.PLATFORM && /* @__PURE__ */ t.jsx(to, { size: 16, className: "shrink-0" }),
                                (T = (C = h == null ? void 0 : h.data) == null ? void 0 : C.find(
                                  (D) => D.externalId === $n(b.value)
                                )) == null ? void 0 : T.displayName
                              ] }) : null
                            }
                          ),
                          /* @__PURE__ */ t.jsx("div", { className: "grow" }),
                          b.value && ((I = h == null ? void 0 : h.data) == null ? void 0 : I.find(
                            (D) => D.externalId === $n(b.value) && D.scope !== hs.PLATFORM
                          )) && /* @__PURE__ */ t.jsx(
                            "span",
                            {
                              role: "button",
                              className: "z-50 opacity-0 pointer-events-none",
                              children: f("Reconnect")
                            }
                          )
                        ] })
                      ] }),
                      /* @__PURE__ */ t.jsxs(ns, { children: [
                        /* @__PURE__ */ t.jsx(
                          Fe,
                          {
                            hasPermission: d,
                            children: /* @__PURE__ */ t.jsx(
                              xf,
                              {
                                onClick: () => {
                                  a(!1), i(null), s(!0);
                                },
                                disabled: !d,
                                children: /* @__PURE__ */ t.jsxs(
                                  "span",
                                  {
                                    className: $(
                                      "flex items-center gap-1 text-primary w-full",
                                      {
                                        "text-muted-foreground cursor-not-allowed": !d
                                      }
                                    ),
                                    children: [
                                      /* @__PURE__ */ t.jsx(_e, { size: 16 }),
                                      f("Create Connection")
                                    ]
                                  }
                                )
                              }
                            )
                          }
                        ),
                        h && h.data && ((P = h.data) == null ? void 0 : P.map((D) => /* @__PURE__ */ t.jsx(
                          Xe,
                          {
                            value: Qo(D.externalId),
                            children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
                              D.usingSecretManager && /* @__PURE__ */ t.jsx(Jf, { size: 16, className: "shrink-0" }),
                              D.scope === hs.PLATFORM && /* @__PURE__ */ t.jsx(to, { size: 16, className: "shrink-0" }),
                              D.displayName
                            ] })
                          },
                          D.externalId
                        )))
                      ] })
                    ]
                  }
                )
              ]
            }
          )
        ] });
      }
    },
    u.getValues().settings.input.auth
  );
}
fd.displayName = "ConnectionSelect";
function Qo(e) {
  return `{{connections['${e}']}}`;
}
function $n(e) {
  if (!M(e))
    return e.replace(
      /\{\{connections\['(.*?)'\]\}\}/g,
      (n, s) => s
    );
}
const Zo = (e) => {
  const { auth: n, ...s } = e;
  return s;
}, Mr = k.memo((e) => {
  const {
    pieceModel: n,
    selectedStep: s,
    updateFormSchema: r,
    updatePropertySettingsSchema: a
  } = ia(), o = e.step.settings.actionName, i = o ? n == null ? void 0 : n.actions[o] : void 0, l = e.step.settings.triggerName, c = l ? n == null ? void 0 : n.triggers[l] : void 0, u = Zo(
    (i == null ? void 0 : i.props) ?? {}
  ), d = Zo(
    (c == null ? void 0 : c.props) ?? {}
  ), { data: h } = Me.useFlag(
    ze.WEBHOOK_URL_PREFIX
  ), { data: m } = Me.useFlag(
    ze.PAUSED_FLOW_TIMEOUT_DAYS
  ), { data: y } = Me.useFlag(
    ze.WEBHOOK_TIMEOUT_SECONDS
  ), { data: v } = Me.useFlag(ze.PUBLIC_URL), g = {
    webhookUrl: `${h}/${e.flowId}`,
    formUrl: `${v}forms/${e.flowId}`,
    chatUrl: `${v}chats/${e.flowId}`,
    pausedFlowTimeoutDays: (m == null ? void 0 : m.toString()) ?? "",
    webhookTimeoutSeconds: (y == null ? void 0 : y.toString()) ?? ""
  }, j = !M(i) && (i.requireAuth ?? !0), x = !M(c) && (c.requireAuth ?? !0);
  return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-4 w-full", children: [
    !n && /* @__PURE__ */ t.jsx("div", { className: "space-y-3", children: Array.from({ length: 5 }).map((N, w) => /* @__PURE__ */ t.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ t.jsxs("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ t.jsx(ce, { className: "w-40 h-4" }),
        /* @__PURE__ */ t.jsx(ce, { className: "size-8" })
      ] }),
      /* @__PURE__ */ t.jsx(ce, { className: "w-full h-12" })
    ] }, w)) }),
    n && /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
      n.auth && (j || x) && /* @__PURE__ */ t.jsx(
        fd,
        {
          isTrigger: !M(c),
          piece: n,
          disabled: e.readonly
        }
      ),
      i && /* @__PURE__ */ t.jsx(
        vr,
        {
          prefixValue: "settings.input",
          props: u,
          propertySettings: s.settings.propertySettings,
          disabled: e.readonly,
          useMentionTextInput: !0,
          markdownVariables: g,
          dynamicPropsInfo: {
            pieceName: n.name,
            pieceVersion: n.version,
            actionOrTriggerName: i.name,
            placedInside: "stepSettings",
            updateFormSchema: r,
            updatePropertySettingsSchema: a
          }
        },
        i.name
      ),
      c && /* @__PURE__ */ t.jsx(
        vr,
        {
          dynamicPropsInfo: {
            pieceName: n.name,
            pieceVersion: n.version,
            actionOrTriggerName: c.name,
            placedInside: "stepSettings",
            updateFormSchema: r,
            updatePropertySettingsSchema: a
          },
          prefixValue: "settings.input",
          props: d,
          useMentionTextInput: !1,
          propertySettings: s.settings.propertySettings,
          disabled: e.readonly,
          markdownVariables: g
        },
        c.name
      )
    ] })
  ] });
});
Mr.displayName = "PieceSettings";
const _r = (e) => /* @__PURE__ */ t.jsxs("div", { className: "flex gap-2 text-center justify-end", children: [
  e.showAnd && /* @__PURE__ */ t.jsx(
    O,
    {
      variant: "basic",
      size: "sm",
      onClick: e.onAnd,
      disabled: e.readonly,
      children: f("+ And")
    }
  ),
  e.showOr && /* @__PURE__ */ t.jsx(
    O,
    {
      variant: "basic",
      size: "sm",
      onClick: e.onOr,
      disabled: e.readonly,
      children: f("+ Or")
    }
  )
] });
_r.displayName = "BranchConditionToolbar";
const ei = {
  [ie.TEXT_CONTAINS]: f("(Text) Contains"),
  [ie.TEXT_DOES_NOT_CONTAIN]: f("(Text) Does not contain"),
  [ie.TEXT_EXACTLY_MATCHES]: f("(Text) Exactly matches"),
  [ie.TEXT_DOES_NOT_EXACTLY_MATCH]: f(
    "(Text) Does not exactly match"
  ),
  [ie.TEXT_STARTS_WITH]: f("(Text) Starts with"),
  [ie.TEXT_DOES_NOT_START_WITH]: f("(Text) Does not start with"),
  [ie.TEXT_ENDS_WITH]: f("(Text) Ends with"),
  [ie.TEXT_DOES_NOT_END_WITH]: f("(Text) Does not end with"),
  [ie.LIST_CONTAINS]: f("(List) Contains"),
  [ie.LIST_DOES_NOT_CONTAIN]: f("(List) Does not contain"),
  [ie.NUMBER_IS_GREATER_THAN]: f("(Number) Is greater than"),
  [ie.NUMBER_IS_LESS_THAN]: f("(Number) Is less than"),
  [ie.NUMBER_IS_EQUAL_TO]: f("(Number) Is equal to"),
  [ie.DATE_IS_AFTER]: f("(Date/time) After"),
  [ie.DATE_IS_BEFORE]: f("(Date/time) Before"),
  [ie.DATE_IS_EQUAL]: f("(Date/time) Equals"),
  [ie.BOOLEAN_IS_TRUE]: f("(Boolean) Is true"),
  [ie.BOOLEAN_IS_FALSE]: f("(Boolean) Is false"),
  [ie.LIST_IS_EMPTY]: f("(List) Is empty"),
  [ie.LIST_IS_NOT_EMPTY]: f("(List) Is not empty"),
  [ie.EXISTS]: f("Exists"),
  [ie.DOES_NOT_EXIST]: f("Does not exist")
}, Jj = Object.keys(ei).map((e) => ({
  label: ei[e],
  value: e
})), md = ({
  deleteClick: e,
  groupIndex: n,
  conditionIndex: s,
  showDelete: r,
  readonly: a,
  branchIndex: o
}) => {
  var h;
  const i = Pe(), l = i.getValues(
    `settings.branches.${o}.conditions.${n}.${s}`
  ), c = l.operator && vf.includes(l == null ? void 0 : l.operator), u = l.operator && no.includes(l == null ? void 0 : l.operator), d = u ? l.firstValue.length === 0 : l.firstValue.length === 0 || "secondValue" in l && ((h = l.secondValue) == null ? void 0 : h.length) === 0;
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2", children: [
      d && /* @__PURE__ */ t.jsxs(te, { children: [
        /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx("div", { children: /* @__PURE__ */ t.jsx(Wi, { className: "h-4 w-4 shrink-0" }) }) }),
        /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Incomplete condition") })
      ] }),
      /* @__PURE__ */ t.jsxs(
        "div",
        {
          className: $("grid gap-2 grow", {
            "grid-cols-2": u,
            "grid-cols-3": !u
          }),
          children: [
            /* @__PURE__ */ t.jsx(
              pe,
              {
                name: `settings.branches.${o}.conditions.${n}.${s}.firstValue`,
                control: i.control,
                render: ({ field: m }) => /* @__PURE__ */ t.jsx(we, { children: /* @__PURE__ */ t.jsx(
                  _s,
                  {
                    disabled: a,
                    placeholder: f("First value"),
                    onChange: (y) => {
                      m.onChange(y), i.trigger();
                    },
                    initialValue: m.value
                  }
                ) })
              }
            ),
            /* @__PURE__ */ t.jsx(
              pe,
              {
                name: `settings.branches.${o}.conditions.${n}.${s}.operator`,
                control: i.control,
                render: ({ field: m }) => /* @__PURE__ */ t.jsx(we, { children: /* @__PURE__ */ t.jsx(
                  Ft,
                  {
                    disabled: a,
                    value: m.value,
                    options: Jj,
                    placeholder: "",
                    onChange: (y) => {
                      u && y !== null && !no.includes(y) && i.setValue(
                        `settings.branches.${o}.conditions.${n}.${s}.secondValue`,
                        ""
                      ), m.onChange(y), i.trigger();
                    }
                  }
                ) })
              }
            ),
            !u && /* @__PURE__ */ t.jsx(
              pe,
              {
                name: `settings.branches.${o}.conditions.${n}.${s}.secondValue`,
                control: i.control,
                render: ({ field: m }) => /* @__PURE__ */ t.jsx(we, { children: /* @__PURE__ */ t.jsx(
                  _s,
                  {
                    placeholder: f("Second value"),
                    disabled: a,
                    initialValue: m.value || "",
                    onChange: (y) => {
                      m.onChange(y), i.trigger();
                    }
                  }
                ) })
              }
            )
          ]
        }
      )
    ] }),
    /* @__PURE__ */ t.jsxs("div", { className: "flex justify-start items-center gap-2 mt-2", children: [
      c && /* @__PURE__ */ t.jsx(
        pe,
        {
          name: `settings.branches.${o}.conditions.${n}.${s}.caseSensitive`,
          control: i.control,
          render: ({ field: m }) => /* @__PURE__ */ t.jsxs(we, { children: [
            /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-2 p-1", children: [
              /* @__PURE__ */ t.jsx(
                gr,
                {
                  disabled: a,
                  id: "case-sensitive",
                  checked: m.value,
                  onCheckedChange: (y) => m.onChange(y)
                }
              ),
              /* @__PURE__ */ t.jsx(vn, { htmlFor: "case-sensitive", children: f("Case sensitive") })
            ] }),
            /* @__PURE__ */ t.jsx(Nn, {})
          ] })
        }
      ),
      /* @__PURE__ */ t.jsx("div", { className: "grow" }),
      /* @__PURE__ */ t.jsx("div", { children: r && /* @__PURE__ */ t.jsxs(
        O,
        {
          variant: "basic",
          className: "text-destructive gap-2 items-center",
          size: "sm",
          onClick: e,
          children: [
            /* @__PURE__ */ t.jsx(Qr, { className: "w-4 h-4" }),
            " ",
            f("Remove")
          ]
        }
      ) })
    ] })
  ] });
};
md.displayName = "BranchSingleCondition";
const pd = k.memo(
  ({
    readonly: e,
    groupIndex: n,
    onAnd: s,
    onOr: r,
    handleDelete: a,
    numberOfGroups: o,
    branchIndex: i
  }) => {
    const l = Pe(), { fields: c } = ta({
      control: l.control,
      name: `settings.branches.${i}.conditions.${n}`
    });
    return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-4", children: [
      n > 0 && /* @__PURE__ */ t.jsx(yf, { className: "my-2", children: f("OR") }),
      c.length === 0 && /* @__PURE__ */ t.jsx(
        _r,
        {
          readonly: e,
          onAnd: s,
          onOr: r,
          showOr: !0,
          showAnd: !0
        },
        `toolbar-${n}`
      ),
      c.map((u, d) => /* @__PURE__ */ t.jsxs(k.Fragment, { children: [
        d > 0 && /* @__PURE__ */ t.jsx("div", { children: f("And If") }),
        /* @__PURE__ */ t.jsx(
          md,
          {
            groupIndex: n,
            readonly: e,
            conditionIndex: d,
            deleteClick: () => a(d),
            showDelete: o !== 1 || c.length !== 1,
            branchIndex: i
          }
        )
      ] }, u.id)),
      /* @__PURE__ */ t.jsx(
        _r,
        {
          onAnd: s,
          onOr: r,
          readonly: e,
          showOr: !0,
          showAnd: !0
        }
      )
    ] });
  }
);
pd.displayName = "ConditionGroup";
const gd = k.memo(
  ({ readonly: e, branchIndex: n }) => {
    const s = Pe(), { fields: r, append: a, remove: o, update: i } = ta({
      control: s.control,
      name: `settings.branches.${n}.conditions`
    }), l = (d, h) => {
      const m = s.getValues(
        `settings.branches.${n}.conditions`
      ), y = [...m[d]], v = m.length === 1, g = y.length === 1;
      v && g ? i(d, [Zs]) : g ? o(d) : (y.splice(h, 1), i(d, y));
    }, c = (d) => {
      const h = s.getValues(
        `settings.branches.${n}.conditions`
      );
      h[d] = [...h[d], Zs], i(d, h[d]);
    }, u = () => {
      a([[Zs]]);
    };
    return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-4", onSubmit: (d) => d.preventDefault(), children: [
      /* @__PURE__ */ t.jsx("div", { className: "text-md ", children: f("Execute If") }),
      r.map((d, h) => /* @__PURE__ */ t.jsx(
        pd,
        {
          readonly: e,
          branchIndex: n,
          numberOfGroups: r.length,
          groupIndex: h,
          onAnd: () => c(h),
          onOr: u,
          handleDelete: (m) => l(h, m)
        },
        d.id
      ))
    ] });
  }
);
gd.displayName = "BranchSettings";
const Qj = ({
  step: e,
  setSelectedBranchIndex: n,
  errors: s,
  duplicateBranch: r,
  deleteBranch: a,
  readonly: o,
  branchNameChanged: i,
  moveBranch: l
}) => {
  const [c, u] = p.useState(null), d = Pe();
  return /* @__PURE__ */ t.jsx(
    jf,
    {
      value: e.settings.branches.map((h, m) => ({
        id: m + 1,
        branch: h
      })),
      onMove: ({ activeIndex: h, overIndex: m }) => {
        l({ sourceIndex: h, targetIndex: m });
      },
      children: e.settings.branches.map(
        (h, m) => h.branchType === wf.FALLBACK ? /* @__PURE__ */ t.jsx(k.Fragment, {}, m) : /* @__PURE__ */ t.jsx(Nf, { value: m + 1, asChild: !0, children: /* @__PURE__ */ t.jsxs("div", { children: [
          /* @__PURE__ */ t.jsx(
            Zj,
            {
              branch: h,
              branchIndex: m,
              readonly: o,
              onClick: () => {
                n(m);
              },
              errors: s,
              duplicateBranch: () => {
                r(m), d.trigger();
              },
              deleteBranch: () => {
                a(m), d.trigger();
              },
              isEditingBranchName: c === m,
              setIsEditingBranchName: (y) => u(y ? m : null),
              branchNameChanged: (y) => {
                i(m, y);
              },
              showDeleteButton: e.settings.branches.length > 2
            }
          ),
          m === e.settings.branches.length - 2 ? null : /* @__PURE__ */ t.jsx(mi, {})
        ] }) }, m)
      )
    }
  );
}, Zj = ({
  branch: e,
  branchIndex: n,
  readonly: s,
  onClick: r,
  errors: a,
  duplicateBranch: o,
  deleteBranch: i,
  isEditingBranchName: l,
  setIsEditingBranchName: c,
  branchNameChanged: u,
  showDeleteButton: d
}) => /* @__PURE__ */ t.jsxs(
  "div",
  {
    className: "flex items-center gap-2 hover:transition-colors   has-[div.button-group:hover]:bg-background  text-sm hover:bg-gray-100 dark:hover:bg-accent px-2 cursor-pointer",
    onClick: () => {
      r();
    },
    children: [
      /* @__PURE__ */ t.jsx(
        Jr,
        {
          readonly: s,
          value: e.branchName,
          onValueChange: (h) => {
            h && u(h);
          },
          isEditing: l,
          setIsEditing: c,
          disallowEditingOnClick: !0
        },
        e.branchName + n
      ),
      !M(a[n]) && /* @__PURE__ */ t.jsx("div", { className: "min-w-[16px]", children: /* @__PURE__ */ t.jsxs(te, { children: [
        /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(Wi, { className: "h-4 w-4 shrink-0" }) }),
        /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Incomplete settings") })
      ] }) }),
      /* @__PURE__ */ t.jsx("div", { className: "grow" }),
      /* @__PURE__ */ t.jsxs(
        "div",
        {
          className: $("flex gap-2 py-1 items-center button-group", {
            "pointer-events-none": s,
            "opacity-0": s
          }),
          children: [
            d && /* @__PURE__ */ t.jsxs(te, { children: [
              /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
                O,
                {
                  variant: "ghost",
                  size: "icon",
                  onClick: (h) => {
                    h.stopPropagation(), i();
                  },
                  children: /* @__PURE__ */ t.jsx(Qr, { className: "w-4 h-4 stroke-destructive" })
                }
              ) }),
              /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Delete") })
            ] }),
            /* @__PURE__ */ t.jsxs(te, { children: [
              /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
                O,
                {
                  variant: "ghost",
                  size: "icon",
                  onClick: (h) => {
                    h.stopPropagation(), c(!0);
                  },
                  children: /* @__PURE__ */ t.jsx(zt, { className: "h-4 w-4" })
                }
              ) }),
              /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Rename") })
            ] }),
            /* @__PURE__ */ t.jsxs(te, { children: [
              /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
                O,
                {
                  variant: "ghost",
                  size: "icon",
                  onClick: (h) => {
                    h.stopPropagation(), o();
                  },
                  children: /* @__PURE__ */ t.jsx(Ri, { className: "h-4 w-4" })
                }
              ) }),
              /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Duplicate") })
            ] }),
            /* @__PURE__ */ t.jsxs(te, { children: [
              /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
                bf,
                {
                  variant: "ghost",
                  size: "icon",
                  disabled: s,
                  className: "shrink-0 size-7",
                  children: /* @__PURE__ */ t.jsx(ji, { className: "size-4", "aria-hidden": "true" })
                }
              ) }),
              /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Move") })
            ] })
          ]
        }
      )
    ]
  }
), ew = ({
  addButtonClicked: e
}) => /* @__PURE__ */ t.jsx("div", { className: "flex items-center gap-2 justify-end mb-2", children: /* @__PURE__ */ t.jsxs(
  O,
  {
    variant: "basic",
    className: "gap-1 items-center",
    onClick: e,
    children: [
      /* @__PURE__ */ t.jsx(_e, { className: "w-4 h-4" }),
      f("Add Branch")
    ]
  }
) }), xd = p.memo(({ readonly: e }) => {
  var j;
  const [
    n,
    s,
    r,
    a,
    o,
    i
  ] = F((x) => [
    q.getActionOrThrow(
      x.selectedStep,
      x.flowVersion.trigger
    ),
    x.applyOperation,
    x.setSelectedBranchIndex,
    x.selectedBranchIndex,
    x.addOperationListener,
    x.removeOperationListener
  ]), { fitView: l } = Tn(), { control: c, setValue: u, formState: d } = Pe(), { insert: h, remove: m, move: y } = ta({
    control: c,
    name: "settings.branches"
  }), v = Pe(), g = (x) => {
    s({
      type: ae.DELETE_BRANCH,
      request: {
        stepName: n.name,
        branchIndex: x
      }
    }), r(null), l(_t.createFocusStepInGraphParams(n.name));
  };
  return p.useEffect(() => {
    const x = (N, w) => {
      switch (w.type) {
        case ae.DELETE_BRANCH: {
          if (w.request.stepName !== n.name)
            return;
          m(w.request.branchIndex);
          break;
        }
        case ae.DUPLICATE_BRANCH:
        case ae.ADD_BRANCH: {
          if (w.request.stepName !== n.name) return;
          const b = q.getActionOrThrow(
            w.request.stepName,
            N.trigger
          );
          if (b.type !== Y.ROUTER) {
            console.error(
              `Trying to duplicate a branch on a none router step! ${w.request.stepName}`
            );
            return;
          }
          const E = b.settings.branches[w.request.branchIndex];
          w.type === ae.DUPLICATE_BRANCH ? h(w.request.branchIndex + 1, {
            ...E,
            branchName: `${E.branchName} Copy`
          }) : h(
            b.settings.branches.length - 1,
            q.createBranch(
              `Branch ${b.settings.branches.length}`,
              void 0
            )
          ), v.trigger();
          break;
        }
        case ae.MOVE_BRANCH: {
          if (w.request.stepName !== n.name) return;
          y(
            w.request.sourceBranchIndex,
            w.request.targetBranchIndex
          );
          break;
        }
      }
    };
    return o(x), () => i(x);
  }, []), /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    M(a) && /* @__PURE__ */ t.jsx(
      pe,
      {
        control: c,
        name: "settings.executionType",
        render: ({ field: x }) => /* @__PURE__ */ t.jsxs(we, { children: [
          /* @__PURE__ */ t.jsx(vn, { children: f("Execute") }),
          /* @__PURE__ */ t.jsxs(
            Zn,
            {
              disabled: x.disabled,
              onValueChange: x.onChange,
              value: x.value,
              children: [
                /* @__PURE__ */ t.jsx(es, { children: /* @__PURE__ */ t.jsx(ts, { placeholder: f("Execute") }) }),
                /* @__PURE__ */ t.jsxs(ns, { children: [
                  /* @__PURE__ */ t.jsx(
                    Xe,
                    {
                      value: `${so.EXECUTE_FIRST_MATCH}`,
                      children: f("Only the first (left) matching branch")
                    }
                  ),
                  /* @__PURE__ */ t.jsx(
                    Xe,
                    {
                      value: `${so.EXECUTE_ALL_MATCH}`,
                      children: f("All matching paths from left to right")
                    }
                  )
                ] })
              ]
            }
          )
        ] })
      }
    ),
    M(a) && /* @__PURE__ */ t.jsxs("div", { children: [
      /* @__PURE__ */ t.jsxs("div", { className: "flex gap-2 mb-2 items-center", children: [
        /* @__PURE__ */ t.jsx(_m, { className: "w-4 h-4 rotate-180" }),
        /* @__PURE__ */ t.jsx(vn, { children: f("Branches") })
      ] }),
      /* @__PURE__ */ t.jsx(
        Qj,
        {
          errors: ((j = d.errors.settings) == null ? void 0 : j.branches) ?? [],
          readonly: e,
          step: n,
          branchNameChanged: (x, N) => {
            u(`settings.branches.${x}.branchName`, N, {
              shouldValidate: !0
            });
          },
          deleteBranch: g,
          moveBranch: ({ sourceIndex: x, targetIndex: N }) => {
            s({
              type: ae.MOVE_BRANCH,
              request: {
                stepName: n.name,
                sourceBranchIndex: x,
                targetBranchIndex: N
              }
            });
          },
          duplicateBranch: (x) => {
            s({
              type: ae.DUPLICATE_BRANCH,
              request: {
                stepName: n.name,
                branchIndex: x
              }
            }), r(x + 1);
          },
          setSelectedBranchIndex: (x) => {
            r(x), n.children[x] ? l(
              _t.createFocusStepInGraphParams(
                n.children[x].name
              )
            ) : l(
              _t.createFocusStepInGraphParams(
                `${n.name}-big-add-button-${n.name}-branch-${x}-start-edge`
              )
            );
          }
        }
      ),
      !e && /* @__PURE__ */ t.jsx("div", { className: "mt-2", children: /* @__PURE__ */ t.jsx(
        ew,
        {
          addButtonClicked: () => {
            s({
              type: ae.ADD_BRANCH,
              request: {
                stepName: n.name,
                branchIndex: n.settings.branches.length - 1,
                branchName: `Branch ${n.settings.branches.length}`
              }
            }), r(n.settings.branches.length - 1);
          }
        }
      ) })
    ] }),
    !M(a) && /* @__PURE__ */ t.jsx(
      gd,
      {
        readonly: e,
        branchIndex: a
      },
      `settings.branches[${a}].conditions`
    )
  ] });
});
xd.displayName = "RouterSettings";
const vd = () => {
  const [e, n, s] = F(
    (u) => [u.selectedStep, u.flowVersion, u.selectStepByName]
  ), r = p.useMemo(
    () => q.getAllSteps(n.trigger),
    [n.trigger]
  ), a = p.useMemo(() => M(e) ? -1 : r.findIndex((u) => u.name === e), [e, r]);
  if (a === -1)
    return null;
  const o = a > 0 ? r[a - 1] : null, i = a < r.length - 1 ? r[a + 1] : null, l = M(o) || ti(o.type), c = M(i) || ti(i.type);
  return /* @__PURE__ */ t.jsx(ks, { children: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center", children: [
    /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
        O,
        {
          variant: "ghost",
          size: "sm",
          disabled: l,
          onClick: () => !l && o && s(o.name),
          "aria-label": f("Previous step"),
          children: /* @__PURE__ */ t.jsx(Ds, { className: "size-4" })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Previous step") })
    ] }),
    /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
        O,
        {
          variant: "ghost",
          size: "sm",
          disabled: c,
          onClick: () => !c && i && s(i.name),
          "aria-label": f("Next step"),
          children: /* @__PURE__ */ t.jsx(Hr, { className: "size-4" })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: f("Next step") })
    ] })
  ] }) });
}, ti = (e) => e === ee.EMPTY;
vd.displayName = "StepNavigationButtons";
function Ta({
  currentVersion: e,
  selectedVersion: n
}) {
  if (e === n)
    return "PATCH_UPGRADE";
  const s = Bn.parse(e), r = Bn.parse(n);
  return !s || !r || s.major !== r.major || s.minor !== r.minor ? "MINOR_OR_MAJOR" : Bn.lt(n, e) ? "PATCH_DOWNGRADE" : "PATCH_UPGRADE";
}
function tw({
  currentVersion: e,
  versions: n
}) {
  var a;
  const s = (a = n[0]) == null ? void 0 : a.version;
  if (!s) return;
  if (Ta({
    currentVersion: e,
    selectedVersion: s
  }) === "MINOR_OR_MAJOR" && Bn.gt(s, e))
    return s;
}
function yd({
  versionChangeType: e,
  props: n,
  currentInput: s
}) {
  return e === "MINOR_OR_MAJOR" ? Hn.getDefaultValueForProperties({
    props: { ...n },
    existingInput: {}
  }) : e === "PATCH_DOWNGRADE" ? Hn.getDefaultValueForProperties({
    props: { ...n },
    existingInput: s
  }) : s;
}
function nw({
  currentVersion: e,
  versions: n
}) {
  var r;
  const s = (r = n[0]) == null ? void 0 : r.version;
  if (!(!s || !Bn.gt(s, e)))
    return s;
}
function sw({
  isLatestMinorOrMajor: e
}) {
  return /* @__PURE__ */ t.jsxs(as, { variant: e ? "warning" : "default", children: [
    e ? /* @__PURE__ */ t.jsx(Hi, { className: "size-4" }) : /* @__PURE__ */ t.jsx(Gi, { className: "size-4" }),
    /* @__PURE__ */ t.jsx(Bi, { children: e ? f("Significant update available") : f("Newer version available") }),
    /* @__PURE__ */ t.jsx(os, { children: e ? f("MajorUpgradeNote") : f(
      "Settings will carry over. Retest the step as the output may have changed."
    ) })
  ] });
}
function rw() {
  return /* @__PURE__ */ t.jsxs(as, { variant: "warning", children: [
    /* @__PURE__ */ t.jsx(Hi, { className: "size-4" }),
    /* @__PURE__ */ t.jsx(os, { children: f("MajorUpgradeNote") })
  ] });
}
function aw() {
  return /* @__PURE__ */ t.jsxs(as, { children: [
    /* @__PURE__ */ t.jsx($t, { className: "size-4" }),
    /* @__PURE__ */ t.jsx(os, { children: f("Settings will carry over. Retest as the output may have changed.") })
  ] });
}
function ow() {
  return /* @__PURE__ */ t.jsxs(as, { children: [
    /* @__PURE__ */ t.jsx($t, { className: "size-4" }),
    /* @__PURE__ */ t.jsx(os, { children: f(
      "You're switching to an older patch. Your settings will be kept where possible."
    ) })
  ] });
}
async function iw({
  step: e,
  targetVersion: n,
  currentVersion: s,
  applyOperation: r
}) {
  const a = e.settings.pieceName, o = e.type === ee.PIECE ? e.settings.triggerName ?? "" : e.settings.actionName ?? "", i = await Sf.get({
    name: a,
    version: n
  }), l = Ta({
    currentVersion: s,
    selectedVersion: n
  }), c = e.type === ee.PIECE ? i.triggers[o] : i.actions[o];
  if (M(c))
    throw new Error(
      f(
        "The selected version does not include the current action or trigger. Please choose a different version."
      )
    );
  const u = yd({
    versionChangeType: l,
    props: c.props,
    currentInput: e.settings.input
  }), d = lt.isPieceStepInputValid({
    props: c.props,
    auth: i.auth,
    input: u,
    requireAuth: c.requireAuth
  });
  e.type === ee.PIECE ? r({
    type: ae.UPDATE_TRIGGER,
    request: {
      ...e,
      type: ee.PIECE,
      valid: d,
      settings: {
        ...e.settings,
        pieceVersion: n,
        input: u
      }
    }
  }) : r({
    type: ae.UPDATE_ACTION,
    request: {
      ...e,
      type: Y.PIECE,
      valid: d,
      settings: {
        ...e.settings,
        pieceVersion: n,
        input: u
      }
    }
  }), l === "MINOR_OR_MAJOR" && r({
    type: ae.UPDATE_SAMPLE_DATA_INFO,
    request: {
      stepName: e.name,
      sampleDataSettings: void 0
    }
  });
}
const Mt = {
  getVersionChangeType: Ta,
  getInputAfterVersionChange: yd,
  getLatestMinorOrMajorUpgrade: tw,
  getLatestVersion: nw,
  applyPieceVersionChange: iw
};
var cn = /* @__PURE__ */ ((e) => (e.MINOR_OR_MAJOR = "MINOR_OR_MAJOR", e.PATCH_DOWNGRADE = "PATCH_DOWNGRADE", e.PATCH_UPGRADE = "PATCH_UPGRADE", e))(cn || {});
const lw = ({
  step: e,
  currentVersion: n,
  latestVersion: s,
  isLatestMinorOrMajor: r,
  onClose: a,
  onOpenAdvanced: o
}) => {
  const [i, l] = p.useState(void 0), c = F(
    (h) => h.applyOperation
  ), { mutate: u, isPending: d } = Re({
    mutationFn: async () => {
      await Mt.applyPieceVersionChange({
        step: e,
        targetVersion: s,
        currentVersion: n,
        applyOperation: c
      });
    },
    onSuccess: () => {
      a();
    },
    onError: (h) => {
      l(h.message);
    }
  });
  return /* @__PURE__ */ t.jsxs("div", { className: "flex flex-col gap-4", children: [
    /* @__PURE__ */ t.jsx(
      sw,
      {
        isLatestMinorOrMajor: r
      }
    ),
    i && /* @__PURE__ */ t.jsx("p", { className: "text-sm font-medium text-destructive", children: i }),
    /* @__PURE__ */ t.jsxs(pt, { children: [
      /* @__PURE__ */ t.jsx(
        O,
        {
          type: "button",
          variant: "outline",
          className: "mr-auto",
          onClick: o,
          children: f("Advanced")
        }
      ),
      /* @__PURE__ */ t.jsx(O, { type: "button", variant: "outline", onClick: a, children: f("Cancel") }),
      /* @__PURE__ */ t.jsx(
        O,
        {
          type: "button",
          loading: d,
          onClick: () => u(),
          children: r ? f("Upgrade to v{version}", { version: s }) : f("Update to v{version}", { version: s })
        }
      )
    ] })
  ] });
}, cw = ({
  step: e,
  currentVersion: n
}) => {
  const [s, r] = p.useState(null), a = e.settings.pieceName, { pieceVersions: o, isLoading: i } = Rn.usePieceVersions(a), l = Mt.getLatestVersion({
    currentVersion: n,
    versions: o ?? []
  }), c = l !== void 0, u = l !== void 0 && Mt.getVersionChangeType({
    currentVersion: n,
    selectedVersion: l
  }) === cn.MINOR_OR_MAJOR, d = () => {
    r(c ? "upgrade" : "advanced");
  };
  return /* @__PURE__ */ t.jsxs(t.Fragment, { children: [
    /* @__PURE__ */ t.jsxs(te, { children: [
      /* @__PURE__ */ t.jsx(ne, { asChild: !0, children: /* @__PURE__ */ t.jsx(
        O,
        {
          type: "button",
          variant: "ghost",
          size: "icon",
          className: "size-6",
          onClick: d,
          loading: i,
          children: c ? /* @__PURE__ */ t.jsx(Gi, { className: "size-3.5 text-green-500" }) : /* @__PURE__ */ t.jsx(Cf, { className: "size-3.5" })
        }
      ) }),
      /* @__PURE__ */ t.jsx(Q, { side: "bottom", children: c ? f("New version available") : f("Switch version") })
    ] }),
    /* @__PURE__ */ t.jsx(
      ut,
      {
        open: s !== null,
        onOpenChange: (h) => !h && r(null),
        children: /* @__PURE__ */ t.jsxs(ht, { children: [
          /* @__PURE__ */ t.jsx(ft, { className: "mb-0", children: /* @__PURE__ */ t.jsx(mt, { children: s === "upgrade" ? f("New Version Available") : f("Update Piece Version") }) }),
          s === "upgrade" && l && /* @__PURE__ */ t.jsx(
            lw,
            {
              step: e,
              currentVersion: n,
              latestVersion: l,
              isLatestMinorOrMajor: u,
              onClose: () => r(null),
              onOpenAdvanced: () => r("advanced")
            },
            "upgrade"
          ),
          s === "advanced" && /* @__PURE__ */ t.jsx(
            dw,
            {
              step: e,
              currentVersion: n,
              onClose: () => r(null),
              onBack: c ? () => r("upgrade") : void 0
            },
            "advanced"
          )
        ] })
      }
    )
  ] });
}, dw = ({
  step: e,
  currentVersion: n,
  onClose: s,
  onBack: r
}) => {
  var T, I;
  const a = e.settings.pieceName, { pieceVersions: o, isLoading: i } = Rn.usePieceVersions(a), l = F(
    (P) => P.applyOperation
  ), [c, u] = p.useState(!1), [d, h] = p.useState(!1), m = (o ?? []).filter((P) => Mt.getVersionChangeType({
    currentVersion: n,
    selectedVersion: P.version
  }) !== cn.MINOR_OR_MAJOR), y = c ? o ?? [] : m, v = Mt.getLatestVersion({
    currentVersion: n,
    versions: o ?? []
  }), g = (T = m[0]) == null ? void 0 : T.version, j = y.map((P) => {
    const D = P.version === n, A = v !== void 0 && P.version === v && !D, _ = g !== void 0 && P.version === g && P.version !== n && !A;
    return {
      value: P.version,
      label: `${P.version} ${D ? `(${f("Current")})` : A ? `(${f("Latest")})` : _ ? `(${f("Latest patch")})` : ""}`
    };
  }), x = Pn({
    resolver: Hs(uw),
    defaultValues: { version: n },
    mode: "onChange"
  }), N = x.watch("version"), w = Mt.getVersionChangeType({
    currentVersion: n,
    selectedVersion: N
  }), b = w === cn.MINOR_OR_MAJOR, E = w === cn.PATCH_DOWNGRADE, R = w === cn.PATCH_UPGRADE && N !== n, { mutate: S, isPending: C } = Re(
    {
      mutationFn: async ({ version: P }) => {
        await Mt.applyPieceVersionChange({
          step: e,
          targetVersion: P,
          currentVersion: n,
          applyOperation: l
        });
      },
      onSuccess: () => {
        s();
      },
      onError: (P) => {
        x.setError("root.serverError", {
          type: "manual",
          message: P.message
        });
      }
    }
  );
  return /* @__PURE__ */ t.jsx(Dn, { ...x, children: /* @__PURE__ */ t.jsxs(
    "form",
    {
      className: "flex flex-col gap-4",
      onSubmit: x.handleSubmit((P) => S(P)),
      children: [
        /* @__PURE__ */ t.jsx(
          pe,
          {
            control: x.control,
            name: "version",
            render: ({ field: P }) => /* @__PURE__ */ t.jsxs(we, { className: "flex flex-col gap-2", children: [
              /* @__PURE__ */ t.jsxs("div", { className: "flex items-center justify-between", children: [
                /* @__PURE__ */ t.jsx("span", { className: "text-sm font-medium", children: f("Version") }),
                /* @__PURE__ */ t.jsx(
                  O,
                  {
                    type: "button",
                    variant: "link",
                    size: "sm",
                    className: "h-auto p-0 text-xs",
                    onClick: () => {
                      u((D) => !D), h(!0);
                    },
                    children: c ? f("Patch versions only") : f("Show all versions")
                  }
                )
              ] }),
              /* @__PURE__ */ t.jsx(
                Ft,
                {
                  options: j,
                  value: P.value,
                  loading: i,
                  openState: {
                    open: d,
                    setOpen: h
                  },
                  onChange: (D) => {
                    D && P.onChange(D);
                  },
                  placeholder: f("Search versions...")
                }
              ),
              /* @__PURE__ */ t.jsx(Nn, {})
            ] })
          }
        ),
        b && /* @__PURE__ */ t.jsx(rw, {}),
        R && /* @__PURE__ */ t.jsx(aw, {}),
        E && /* @__PURE__ */ t.jsx(ow, {}),
        ((I = x.formState.errors.root) == null ? void 0 : I.serverError) && /* @__PURE__ */ t.jsx("p", { className: "text-sm font-medium text-destructive", children: x.formState.errors.root.serverError.message }),
        /* @__PURE__ */ t.jsxs(pt, { children: [
          r && /* @__PURE__ */ t.jsx(
            O,
            {
              type: "button",
              variant: "outline",
              className: "mr-auto",
              onClick: r,
              children: f("Back")
            }
          ),
          /* @__PURE__ */ t.jsx(O, { type: "button", variant: "outline", onClick: s, children: f("Cancel") }),
          /* @__PURE__ */ t.jsx(
            O,
            {
              type: "submit",
              loading: C,
              disabled: N === n,
              children: f("Apply")
            }
          )
        ] })
      ]
    }
  ) });
}, uw = Je({
  version: Te().min(1, Ef.required)
}), jd = () => {
  var _, L, H, X, ue, Se;
  const { selectedStep: e, pieceModel: n, formSchema: s } = ia(), { project: r } = Ti.useCurrentProject(), [
    a,
    o,
    i,
    l,
    c,
    u,
    d,
    h,
    m,
    y
  ] = F((G) => [
    G.readonly,
    G.exitStepSettings,
    G.applyOperation,
    G.saving,
    G.flowVersion,
    G.selectedBranchIndex,
    G.setSelectedBranchIndex,
    G.run,
    G.testPanelView,
    G.isTestPanelOpen
  ]), { stepMetadata: v } = En.useStepMetadata({
    step: e
  }), g = p.useRef(e);
  g.current = e;
  const j = p.useRef(e), x = Pn({
    mode: "all",
    disabled: a,
    reValidateMode: "onChange",
    defaultValues: e,
    resetOptions: {
      keepDefaultValues: !1,
      keepDirtyValues: !0
    },
    resolver: async (G, Ue, et) => {
      const ve = await Hs(s)(G, Ue, et), ge = Hn.removeUndefinedFromInput(G), tt = Hn.removeUndefinedFromInput(
        j.current
      ), he = Object.keys(ve.errors).length === 0;
      return ge.valid = he, ge.type === ee.EMPTY || M(n) && (ge.type === Y.PIECE || ge.type === ee.PIECE) || ea(
        ni(ge),
        ni(tt)
      ) || (j.current = JSON.parse(JSON.stringify(ge)), ge.type === ee.PIECE ? i({
        type: ae.UPDATE_TRIGGER,
        request: {
          ...ge,
          valid: he
        }
      }) : i({
        type: ae.UPDATE_ACTION,
        request: {
          ...ge,
          valid: he
        }
      })), ve;
    }
  }), N = p.useRef(null), w = x.getValues(), b = w.type === ee.PIECE && lt.isManualTrigger({
    pieceName: w.settings.pieceName,
    triggerName: w.settings.triggerName ?? ""
  }), E = w.type === ee.EMPTY, R = !a && !b && !E, S = !M(h) && !b && !E, [C, T] = p.useState(!1), I = [Y.CODE, Y.PIECE].includes(
    w.type
  ) && !M(v), P = w.settings.pieceName === "@activepieces/piece-ai" && w.settings.actionName === "run_agent";
  p.useEffect(() => {
    x.trigger();
  }, []);
  const D = R || S, A = /* @__PURE__ */ t.jsx(Ze, { className: "h-full", children: /* @__PURE__ */ t.jsxs(
    "div",
    {
      className: $(
        "flex flex-col px-4 pb-6 pt-3",
        zi
      ),
      children: [
        w.type === Y.LOOP_ON_ITEMS && /* @__PURE__ */ t.jsx(hd, { readonly: a }),
        w.type === Y.CODE && /* @__PURE__ */ t.jsx(ud, { readonly: a }),
        w.type === Y.PIECE && P && w && /* @__PURE__ */ t.jsx(
          Vj,
          {
            step: w,
            flowId: c.flowId,
            readonly: a
          }
        ),
        w.type === Y.PIECE && !P && w && /* @__PURE__ */ t.jsx(
          Mr,
          {
            step: w,
            flowId: c.flowId,
            readonly: a
          }
        ),
        w.type === Y.ROUTER && w && /* @__PURE__ */ t.jsx(xd, { readonly: a }),
        w.type === ee.PIECE && w && /* @__PURE__ */ t.jsx(
          Mr,
          {
            step: w,
            flowId: c.flowId,
            readonly: a
          }
        ),
        I && /* @__PURE__ */ t.jsx(
          Kc,
          {
            hideContinueOnFailure: v.type === Y.PIECE ? (L = (_ = v.errorHandlingOptions) == null ? void 0 : _.continueOnFailure) == null ? void 0 : L.hide : !1,
            disabled: a,
            hideRetryOnFailure: v.type === Y.PIECE ? (X = (H = v.errorHandlingOptions) == null ? void 0 : H.retryOnFailure) == null ? void 0 : X.hide : !1
          }
        )
      ]
    }
  ) });
  return /* @__PURE__ */ t.jsx(Dn, { ...x, children: /* @__PURE__ */ t.jsxs(
    "form",
    {
      onSubmit: (G) => G.preventDefault(),
      onChange: (G) => G.preventDefault(),
      className: "w-full h-full flex flex-col",
      children: [
        /* @__PURE__ */ t.jsxs(
          "div",
          {
            ref: N,
            className: "relative z-10 bg-background",
            children: [
              /* @__PURE__ */ t.jsx(
                Na,
                {
                  onClose: () => o(),
                  leadingIcon: v ? /* @__PURE__ */ t.jsx(
                    ci,
                    {
                      logoUrl: v.logoUrl,
                      displayName: v.displayName,
                      showTooltip: !1,
                      border: !1,
                      size: "md"
                    }
                  ) : null,
                  actions: /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1", children: [
                    si(v) && v.pieceVersion && (w.type === Y.PIECE || w.type === ee.PIECE) && /* @__PURE__ */ t.jsx(
                      fw,
                      {
                        step: w,
                        pieceVersion: v.pieceVersion,
                        readonly: a
                      }
                    ),
                    /* @__PURE__ */ t.jsx(vd, {})
                  ] }),
                  children: /* @__PURE__ */ t.jsx(
                    Kj,
                    {
                      selectedBranchIndex: u,
                      stepIndex: q.getStepNumber(
                        c.trigger,
                        e.name
                      ),
                      setDisplayName: (G) => {
                        x.setValue("displayName", G, {
                          shouldValidate: !0
                        });
                      },
                      readonly: a,
                      displayName: w.displayName,
                      branchName: M(u) || (Se = (ue = w.settings.branches) == null ? void 0 : ue[u]) == null ? void 0 : Se.branchName,
                      setBranchName: (G) => {
                        M(u) || x.setValue(
                          `settings.branches[${u}].branchName`,
                          G,
                          {
                            shouldValidate: !0
                          }
                        );
                      },
                      setSelectedBranchIndex: d,
                      isEditingStepOrBranchName: C,
                      setIsEditingStepOrBranchName: T,
                      tooltipTitle: (v == null ? void 0 : v.actionOrTriggerOrAgentDisplayName) || (v == null ? void 0 : v.displayName),
                      tooltipDescription: (v == null ? void 0 : v.actionOrTriggerOrAgentDescription) || (v == null ? void 0 : v.description),
                      pieceVersion: si(v) ? v.pieceVersion : void 0
                    }
                  )
                }
              ),
              /* @__PURE__ */ t.jsx(
                "div",
                {
                  "aria-hidden": !0,
                  className: "pointer-events-none absolute -bottom-3 left-0 right-0 h-3 bg-gradient-to-b from-background to-transparent"
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ t.jsx(
          Tf,
          {
            children: /* @__PURE__ */ t.jsx(pw, { step: e, children: /* @__PURE__ */ t.jsx(
              hw,
              {
                isSplit: D && y && m === "split",
                showTestPanel: D,
                isTestPanelOpen: y,
                settingsForm: A,
                testPanelHost: D ? /* @__PURE__ */ t.jsx(
                  id,
                  {
                    mode: m === "split" ? "split" : "drawer",
                    flowId: c.flowId,
                    flowVersionId: c.id,
                    projectId: r == null ? void 0 : r.id,
                    stepType: w.type,
                    showGenerateSampleData: R,
                    showStepInputOutFromRun: S,
                    saving: l
                  }
                ) : null
              }
            ) })
          },
          `${e.name}-${e.type}`
        )
      ]
    }
  ) });
};
jd.displayName = "StepSettingsContainer";
const hw = ({
  isSplit: e,
  showTestPanel: n,
  isTestPanelOpen: s,
  settingsForm: r,
  testPanelHost: a
}) => e ? /* @__PURE__ */ t.jsxs("div", { className: "relative flex-1 min-h-0 flex flex-row", children: [
  /* @__PURE__ */ t.jsx("div", { className: "w-1/2 min-w-0 min-h-0 h-full", children: r }),
  a && /* @__PURE__ */ t.jsx("div", { className: "w-1/2 min-w-0 min-h-0 h-full pt-2 pl-1", children: a })
] }) : /* @__PURE__ */ t.jsxs("div", { className: "relative flex-1 min-h-0 flex flex-col w-full", children: [
  /* @__PURE__ */ t.jsx("div", { className: "flex-1 min-h-0", children: r }),
  n && !s && /* @__PURE__ */ t.jsx("div", { className: "shrink-0", children: /* @__PURE__ */ t.jsx(ld, {}) }),
  a && s && /* @__PURE__ */ t.jsx("div", { className: "absolute bottom-0 left-0 right-0 h-[60%] z-50", children: a })
] }), fw = ({
  step: e,
  pieceVersion: n,
  readonly: s
}) => {
  const r = Pf.getExactVersion(n), a = !s && (e.type === Y.PIECE || e.type === ee.PIECE);
  return /* @__PURE__ */ t.jsxs("div", { className: "flex items-center gap-1 shrink-0", children: [
    /* @__PURE__ */ t.jsxs("span", { className: "text-xs text-muted-foreground", children: [
      "v",
      r
    ] }),
    a && /* @__PURE__ */ t.jsx(cw, { step: e, currentVersion: r })
  ] });
}, mw = (e) => q.isAction(e.type), pw = ({
  step: e,
  children: n
}) => mw(e) ? /* @__PURE__ */ t.jsx(Jc, { step: e, children: n }, e.name) : /* @__PURE__ */ t.jsx(ed, { step: e, children: n }, e.name), ni = (e) => {
  const { sampleData: n, ...s } = e.settings, { lastUpdatedDate: r, ...a } = e;
  return { ...a, settings: s };
}, si = (e) => (e == null ? void 0 : e.type) === Y.PIECE || (e == null ? void 0 : e.type) === ee.PIECE, gw = "transition-all ", xw = 1e3, vw = 850, yw = "25%", jw = "400px", ww = 700, Nw = () => {
  var S, C;
  const { platform: e } = wi.useCurrentPlatform(), [
    n,
    s,
    r,
    a,
    o,
    i,
    l,
    c,
    u
  ] = F((T) => [
    T.flowVersion,
    T.rightSidebar,
    T.selectedStep,
    T.removeAllStepTestsListeners,
    q.getStep(
      T.selectedStep ?? "",
      T.flowVersion.trigger
    ),
    T.testPanelView,
    T.isTestPanelOpen,
    T.setTestPanelView,
    T.setTestPanelOpen
  ]);
  p.useEffect(() => () => {
    a();
  }, [a]), hn.useShowBuilderIsSavingWarningBeforeLeaving();
  const d = p.useRef(null), h = Vf(d), [m, y] = p.useState(!1);
  p.useEffect(() => {
    const T = () => y(!1);
    return window.addEventListener("pointerup", T), () => window.removeEventListener("pointerup", T);
  }, []);
  const v = s === ye.PIECE_SETTINGS && i === "split" && l, g = s === ye.PIECE_SETTINGS && i === "split", j = p.useRef(null), x = p.useRef(null), N = Df(s);
  p.useLayoutEffect(() => {
    const T = j.current;
    if (!T) return;
    if (s === ye.NONE) {
      T.resize("0%");
      return;
    }
    const I = N === ye.NONE, P = g ? I ? xw : vw : yw;
    T.resize(P);
    const D = window.requestAnimationFrame(() => T.resize(P));
    return () => window.cancelAnimationFrame(D);
  }, [g, N, s]), p.useEffect(() => {
    if (!v || !m) return;
    const T = x.current;
    if (!T) return;
    const I = new ResizeObserver((P) => {
      var A;
      const D = ((A = P[0]) == null ? void 0 : A.contentRect.width) ?? 0;
      D > 0 && D < ww && (c("drawer"), u(!1));
    });
    return I.observe(T), () => I.disconnect();
  }, [v, m, c, u]);
  const { pieceModel: w, refetch: b } = Rn.usePieceModelForStepSettings({
    name: o == null ? void 0 : o.settings.pieceName,
    version: o == null ? void 0 : o.settings.pieceVersion,
    enabled: (o == null ? void 0 : o.type) === Y.PIECE || (o == null ? void 0 : o.type) === ee.PIECE
  });
  hn.useSetSocketListener(b), hn.useListenToExistingRun();
  const [E, R] = p.useState(!1);
  return /* @__PURE__ */ t.jsxs("div", { className: "flex h-full w-full flex-col relative max-h-[100vh]", children: [
    /* @__PURE__ */ t.jsx("div", { className: "z-40", children: /* @__PURE__ */ t.jsx(vy, {}) }),
    /* @__PURE__ */ t.jsxs(my, { orientation: "horizontal", children: [
      /* @__PURE__ */ t.jsx(qo, { defaultSize: "100%", id: "flow-canvas", children: /* @__PURE__ */ t.jsxs("div", { ref: d, className: "relative h-full w-full", children: [
        /* @__PURE__ */ t.jsx(Ny, { children: /* @__PURE__ */ t.jsx(
          Lc,
          {
            setHasCanvasBeenInitialised: R
          }
        ) }),
        /* @__PURE__ */ t.jsx(Bc, {}),
        d.current && d.current.clientWidth > 0 && /* @__PURE__ */ t.jsx(
          $g,
          {
            canvasHeight: ((S = d.current) == null ? void 0 : S.clientHeight) ?? 0,
            canvasWidth: ((C = d.current) == null ? void 0 : C.clientWidth) ?? 0,
            hasCanvasBeenInitialised: E,
            selectedStep: r
          }
        ),
        /* @__PURE__ */ t.jsx(
          Bf,
          {
            position: "absolute",
            show: e == null ? void 0 : e.plan.showPoweredBy
          }
        ),
        /* @__PURE__ */ t.jsx(
          Nl,
          {
            parentHeight: h.height,
            parentWidth: h.width
          }
        )
      ] }) }),
      /* @__PURE__ */ t.jsx(
        py,
        {
          disabled: s === ye.NONE,
          withHandle: s !== ye.NONE,
          onPointerDown: () => y(!0),
          onPointerUp: () => y(!1),
          onPointerCancel: () => y(!1),
          className: s === ye.NONE ? "bg-transparent" : ""
        }
      ),
      /* @__PURE__ */ t.jsx(
        qo,
        {
          panelRef: j,
          id: "right-sidebar",
          collapsedSize: "0%",
          defaultSize: "0%",
          minSize: s === ye.NONE ? "0%" : jw,
          maxSize: s === ye.NONE ? "0%" : g ? "95%" : "60%",
          className: $("min-w-0 bg-background z-30", {
            [gw]: !m
          }),
          style: {
            transitionDuration: `${m ? 0 : W.SIDEBAR_ANIMATION_DURATION}ms`
          },
          children: /* @__PURE__ */ t.jsxs("div", { ref: x, className: "h-full w-full", children: [
            s === ye.PIECE_SETTINGS && o && /* @__PURE__ */ t.jsx(
              Wg,
              {
                pieceModel: w,
                selectedStep: o,
                children: /* @__PURE__ */ t.jsx(jd, {})
              },
              bw({
                flowVersionId: n.id,
                step: o,
                hasPieceModelLoaded: !!w
              })
            ),
            s === ye.RUNS && /* @__PURE__ */ t.jsx(qc, {}),
            s === ye.VERSIONS && /* @__PURE__ */ t.jsx(Wc, {})
          ] })
        }
      )
    ] }),
    /* @__PURE__ */ t.jsx(kv, {})
  ] });
};
Nw.displayName = "BuilderPage";
function bw({
  flowVersionId: e,
  step: n,
  hasPieceModelLoaded: s
}) {
  const r = n == null ? void 0 : n.name, a = (n == null ? void 0 : n.type) === ee.PIECE ? n == null ? void 0 : n.settings.triggerName : n == null ? void 0 : n.settings.actionName, o = (n == null ? void 0 : n.type) === ee.PIECE || (n == null ? void 0 : n.type) === Y.PIECE ? n == null ? void 0 : n.settings.pieceName : void 0, i = (n == null ? void 0 : n.type) === ee.PIECE || (n == null ? void 0 : n.type) === Y.PIECE ? n == null ? void 0 : n.settings.pieceVersion : void 0, l = (n == null ? void 0 : n.type) != ee.EMPTY && (n == null ? void 0 : n.type) != ee.PIECE && (n == null ? void 0 : n.skip);
  return `${e}-${r ?? ""}-${a ?? ""}-${o ?? ""}-${i ?? ""}-${"skipped-" + !!l}-${s ? "loaded" : "not-loaded"}`;
}
function _w({
  children: e,
  outputSampleData: n,
  inputSampleData: s,
  ...r
}) {
  const a = p.useRef(void 0), { checkAccess: o } = Ve(), i = !o(Ie.WRITE_FLOW) || r.readonly;
  Rf.useReloadPageIfProjectIdChanged(r.flow.projectId);
  const l = vi(), c = Qn();
  return a.current || (a.current = Of({
    ...r,
    readonly: i,
    outputSampleData: n,
    inputSampleData: s,
    socket: l,
    queryClient: c
  })), /* @__PURE__ */ t.jsx(If.Provider, { value: a.current, children: e });
}
export {
  _w as B,
  Nw as a
};
