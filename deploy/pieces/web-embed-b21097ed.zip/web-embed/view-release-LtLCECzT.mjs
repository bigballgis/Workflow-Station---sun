import { fA as N, fB as C, fC as B, fD as T, fE as X, fF as M, fG as A, fH as y, fI as D, fJ as L, b8 as P, a_ as k, j as s, fK as v, bi as z, i as b, a6 as l, aS as _, a3 as w, a4 as R, ao as G, a5 as I, b1 as S, a2 as E, eB as F } from "./mount-builder-CqIEWsZv.mjs";
import { a as U, A as Y, P as j, F as H } from "./apply-plan-CZiZRBzx.mjs";
import { R as K } from "./rotate-ccw-ClYM7DvH.mjs";
function g(n, r) {
  const e = +N(n) - +N(r);
  return e < 0 ? -1 : e > 0 ? 1 : e;
}
function J(n) {
  return (r) => {
    const c = (n ? Math[n] : Math.trunc)(r);
    return c === 0 ? 0 : c;
  };
}
function q(n, r) {
  return +N(n) - +N(r);
}
function Q(n, r) {
  const e = N(n, r == null ? void 0 : r.in);
  return +C(e, r) == +B(e, r);
}
function V(n, r, e) {
  const [c, t, d] = T(
    e == null ? void 0 : e.in,
    n,
    n,
    r
  ), f = g(t, d), a = Math.abs(
    X(t, d)
  );
  if (a < 1) return 0;
  t.getMonth() === 1 && t.getDate() > 27 && t.setDate(30), t.setMonth(t.getMonth() - f * a);
  let o = g(t, d) === -f;
  Q(c) && a === 1 && g(c, d) === 1 && (o = !1);
  const m = f * (a - +o);
  return m === 0 ? 0 : m;
}
function W(n, r, e) {
  const c = q(n, r) / 1e3;
  return J(e == null ? void 0 : e.roundingMethod)(c);
}
function Z(n, r, e) {
  const c = L(), t = (e == null ? void 0 : e.locale) ?? c.locale ?? A, d = 2520, f = g(n, r);
  if (isNaN(f)) throw new RangeError("Invalid time value");
  const a = Object.assign({}, e, {
    addSuffix: e == null ? void 0 : e.addSuffix,
    comparison: f
  }), [o, m] = T(
    e == null ? void 0 : e.in,
    ...f > 0 ? [r, n] : [n, r]
  ), h = W(m, o), O = (M(m) - M(o)) / 1e3, i = Math.round((h - O) / 60);
  let x;
  if (i < 2)
    return e != null && e.includeSeconds ? h < 5 ? t.formatDistance("lessThanXSeconds", 5, a) : h < 10 ? t.formatDistance("lessThanXSeconds", 10, a) : h < 20 ? t.formatDistance("lessThanXSeconds", 20, a) : h < 40 ? t.formatDistance("halfAMinute", 0, a) : h < 60 ? t.formatDistance("lessThanXMinutes", 1, a) : t.formatDistance("xMinutes", 1, a) : i === 0 ? t.formatDistance("lessThanXMinutes", 1, a) : t.formatDistance("xMinutes", i, a);
  if (i < 45)
    return t.formatDistance("xMinutes", i, a);
  if (i < 90)
    return t.formatDistance("aboutXHours", 1, a);
  if (i < y) {
    const u = Math.round(i / 60);
    return t.formatDistance("aboutXHours", u, a);
  } else {
    if (i < d)
      return t.formatDistance("xDays", 1, a);
    if (i < D) {
      const u = Math.round(i / y);
      return t.formatDistance("xDays", u, a);
    } else if (i < D * 2)
      return x = Math.round(i / D), t.formatDistance("aboutXMonths", x, a);
  }
  if (x = V(m, o), x < 12) {
    const u = Math.round(i / D);
    return t.formatDistance("xMonths", u, a);
  } else {
    const u = x % 12, p = Math.trunc(x / 12);
    return u < 3 ? t.formatDistance("aboutXYears", p, a) : u < 9 ? t.formatDistance("overXYears", p, a) : t.formatDistance("almostXYears", p + 1, a);
  }
}
const $ = (n) => {
  switch (n) {
    case j.GIT:
      return /* @__PURE__ */ s.jsxs("span", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ s.jsx(F, { className: "size-4" }),
        " ",
        l("Git")
      ] });
    case j.PROJECT:
      return /* @__PURE__ */ s.jsxs("span", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ s.jsx(H, { className: "size-4" }),
        " ",
        l("Project")
      ] });
    case j.ROLLBACK:
      return /* @__PURE__ */ s.jsxs("span", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ s.jsx(K, { className: "size-4" }),
        " ",
        l("Rollback")
      ] });
  }
}, ae = () => {
  var f, a, o;
  const { releaseId: n } = P(), r = k(), { data: e, isLoading: c } = U.useProjectRelease(
    n || "",
    !!n
  );
  if (!n)
    return /* @__PURE__ */ s.jsx(v, { to: "/releases", replace: !0 });
  if (!c && z(e))
    return /* @__PURE__ */ s.jsx(v, { to: "/404", replace: !0 });
  const t = new Date((e == null ? void 0 : e.created) ?? 0), d = Z(t, /* @__PURE__ */ new Date(), { addSuffix: !0 });
  return /* @__PURE__ */ s.jsxs("div", { className: "space-y-6 w-full", children: [
    /* @__PURE__ */ s.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ s.jsxs("div", { className: "flex items-center gap-2 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ s.jsx(
          b,
          {
            variant: "link",
            className: "p-0 h-auto text-sm text-muted-foreground hover:text-primary",
            onClick: () => r("/releases"),
            children: l("Releases")
          }
        ),
        /* @__PURE__ */ s.jsx(_, { className: "h-4 w-4" }),
        /* @__PURE__ */ s.jsx("span", { children: e == null ? void 0 : e.name })
      ] }),
      /* @__PURE__ */ s.jsx("div", { className: "flex justify-between items-center w-full", children: /* @__PURE__ */ s.jsxs("div", { className: "flex flex-col items-start gap-2 w-full", children: [
        /* @__PURE__ */ s.jsxs("div", { className: "flex items-center gap-2 text-md justify-between w-full", children: [
          /* @__PURE__ */ s.jsx("h1", { className: "text-3xl font-bold", children: e == null ? void 0 : e.name }),
          /* @__PURE__ */ s.jsxs(w, { children: [
            /* @__PURE__ */ s.jsx(R, { asChild: !0, children: /* @__PURE__ */ s.jsx(
              Y,
              {
                onSuccess: () => {
                  r("/releases");
                },
                variant: "ghost",
                className: " p-0",
                request: {
                  projectId: G.getProjectId(),
                  type: j.ROLLBACK,
                  projectReleaseId: (e == null ? void 0 : e.id) || ""
                },
                defaultName: e == null ? void 0 : e.name,
                children: /* @__PURE__ */ s.jsx(b, { disabled: c, children: l("Rollback") })
              }
            ) }),
            /* @__PURE__ */ s.jsx(I, { side: "bottom", children: l("Rollback") })
          ] })
        ] }),
        /* @__PURE__ */ s.jsxs("p", { className: "text-sm text-muted-foreground", children: [
          l("Created"),
          ": ",
          d
        ] })
      ] }) })
    ] }),
    /* @__PURE__ */ s.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ s.jsx("span", { className: "text-md font-semibold", children: l("Summary") }),
      c ? /* @__PURE__ */ s.jsx(S, { className: "h-24 w-full" }) : /* @__PURE__ */ s.jsx("div", { className: "flex flex-col items-start gap-2", children: e != null && e.importedBy ? /* @__PURE__ */ s.jsx(E, { children: /* @__PURE__ */ s.jsxs(w, { children: [
        /* @__PURE__ */ s.jsx(R, { asChild: !0, children: /* @__PURE__ */ s.jsxs("span", { className: "flex items-center flex-row gap-1", children: [
          l("Imported by"),
          /* @__PURE__ */ s.jsxs("span", { className: "font-semibold text-md", children: [
            (f = e == null ? void 0 : e.importedByUser) == null ? void 0 : f.firstName,
            " ",
            (a = e == null ? void 0 : e.importedByUser) == null ? void 0 : a.lastName
          ] }),
          l("from"),
          " ",
          $(
            (e == null ? void 0 : e.type) ?? j.GIT
          )
        ] }) }),
        /* @__PURE__ */ s.jsx(I, { children: /* @__PURE__ */ s.jsx("p", { children: (o = e == null ? void 0 : e.importedByUser) == null ? void 0 : o.email }) })
      ] }) }) : null })
    ] }),
    /* @__PURE__ */ s.jsxs("div", { className: "space-y-2", children: [
      /* @__PURE__ */ s.jsx("span", { className: "text-md font-semibold", children: l("Description") }),
      c ? /* @__PURE__ */ s.jsx(S, { className: "h-24 w-full" }) : /* @__PURE__ */ s.jsx("div", { className: "flex flex-col items-start gap-2", children: /* @__PURE__ */ s.jsx("pre", { className: "whitespace-pre-wrap", children: (e == null ? void 0 : e.description) || l("No description provided") }) })
    ] })
  ] });
};
export {
  ae as default
};
