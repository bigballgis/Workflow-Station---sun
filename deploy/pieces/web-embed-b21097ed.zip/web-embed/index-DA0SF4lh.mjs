import { c as H, ae as L, j as s, H as P, e as U, a3 as C, a4 as R, h as o, a5 as b, a6 as m, co as I, cl as N, cp as n, cq as k, cr as F, aa as E, cs as v, L as K, ct as T, ac as M } from "./mount-builder-CqIEWsZv.mjs";
import { D as W } from "./dashboard-page-header-BfLKPs1b.mjs";
import { P as G } from "./piece-icon-from-name-CkNp4shA.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const O = [
  ["path", { d: "M3 3v16a2 2 0 0 0 2 2h16", key: "c24i48" }],
  ["path", { d: "M18 17V9", key: "2bz60n" }],
  ["path", { d: "M13 17V5", key: "1frdt8" }],
  ["path", { d: "M8 17v-3", key: "17ska0" }]
], q = H("chart-column", O), X = ({ pieceName: r, fallback: i }) => {
  const { summary: t } = L.usePieceSummary({ name: r });
  return /* @__PURE__ */ s.jsx("span", { children: (t == null ? void 0 : t.displayName) || i || r });
}, Y = {
  getStatusReport: async () => U.get("/v1/trigger-runs/status")
}, _ = {
  useStatusReport: () => P({
    queryKey: ["trigger-status-report"],
    queryFn: Y.getStatusReport,
    meta: { showErrorDialog: !0, loadSubsetOptions: {} }
  })
};
function B({ days: r, className: i }) {
  return /* @__PURE__ */ s.jsx("div", { className: o("flex gap-1", i), children: [...r].reverse().map((t, l) => {
    const u = t.success + t.failure;
    return /* @__PURE__ */ s.jsxs(C, { children: [
      /* @__PURE__ */ s.jsx(R, { asChild: !0, children: /* @__PURE__ */ s.jsx(
        "div",
        {
          className: o(
            "w-3 h-6 rounded-sm cursor-pointer transition-colors",
            "hover:scale-110 hover:shadow-xs",
            {
              "bg-success hover:bg-success-600": t.status === "success",
              "bg-destructive hover:bg-destructive/80": t.status === "fault",
              "bg-amber-400 hover:bg-amber-500": t.status === "warning"
            }
          )
        }
      ) }),
      /* @__PURE__ */ s.jsx(b, { side: "top", align: "center", className: "text-xs", children: /* @__PURE__ */ s.jsxs("div", { children: [
        "On ",
        t.date,
        ", there were ",
        u,
        " total runs: ",
        t.success,
        " ",
        "succeeded and ",
        t.failure,
        " failed."
      ] }) })
    ] }, l);
  }) });
}
const c = {
  SUCCESS: "success",
  FAULT: "fault",
  WARNING: "warning"
}, V = {
  [c.SUCCESS]: "All trigger runs were successful in the selected period.",
  [c.WARNING]: "Some trigger runs failed. Please review for potential issues.",
  [c.FAULT]: "All trigger runs failed. Immediate attention required."
}, S = (r, i) => {
  const t = A(r), l = t.reduce(
    (d, e) => {
      var a;
      return d + (((a = i.dailyStats[e]) == null ? void 0 : a.success) ?? 0);
    },
    0
  ), u = t.reduce(
    (d, e) => {
      var a;
      return d + (((a = i.dailyStats[e]) == null ? void 0 : a.failure) ?? 0);
    },
    0
  ), g = l > 0 ? l / (l + u) * 100 : 100;
  return Number(g.toFixed(1));
}, A = (r) => Array.from(
  { length: r },
  (i, t) => K().subtract(t, "day").format("YYYY-MM-DD")
);
function $() {
  const { data: r, isLoading: i } = _.useStatusReport(), t = i ? [] : Object.entries((r == null ? void 0 : r.pieces) ?? {}).map(([e, a]) => {
    const D = S(7, a), h = S(14, a), z = S(1, a);
    return {
      id: e,
      status: {
        type: h === 100 ? c.SUCCESS : h > 0 ? c.WARNING : c.FAULT
      },
      last24Hours: z,
      last7Days: D,
      last14Days: h,
      lastResults: A(14).map((x) => {
        var j, y;
        const p = ((j = a.dailyStats[x]) == null ? void 0 : j.success) ?? 0, f = ((y = a.dailyStats[x]) == null ? void 0 : y.failure) ?? 0, w = p + f;
        return {
          date: x,
          success: p,
          failure: f,
          status: f > 0 ? p > 0 ? "warning" : "fault" : "success",
          totalRuns: w
        };
      }),
      runs: a.totalRuns
    };
  }), l = (e) => {
    switch (e) {
      case c.SUCCESS:
        return /* @__PURE__ */ s.jsx(N, { size: 16, className: "text-success-700" });
      case c.WARNING:
        return /* @__PURE__ */ s.jsx(T, { size: 16, className: "text-amber-700" });
      case c.FAULT:
        return /* @__PURE__ */ s.jsx(M, { size: 16, className: "text-destructive" });
      default:
        return /* @__PURE__ */ s.jsx(T, { size: 16, className: "text-gray-500" });
    }
  }, u = (e) => {
    switch (e) {
      case c.SUCCESS:
        return "text-success-700";
      case c.WARNING:
        return "text-amber-700";
      case c.FAULT:
        return "text-destructive";
      default:
        return "text-gray-600";
    }
  }, g = (e) => V[e] || "Unknown status", d = [
    {
      accessorKey: "pieceDisplayName",
      size: 220,
      header: ({ column: e }) => /* @__PURE__ */ s.jsx(n, { column: e, title: "Piece", icon: k }),
      cell: ({ row: e }) => {
        const a = e.original.status;
        return /* @__PURE__ */ s.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ s.jsx(
            G,
            {
              pieceName: e.original.id,
              showTooltip: !1,
              size: "md"
            }
          ),
          /* @__PURE__ */ s.jsx("div", { className: "flex flex-col", children: /* @__PURE__ */ s.jsxs("div", { className: "font-medium flex items-center gap-2", children: [
            /* @__PURE__ */ s.jsx(X, { pieceName: e.original.id }),
            /* @__PURE__ */ s.jsxs(C, { children: [
              /* @__PURE__ */ s.jsx(R, { asChild: !0, children: /* @__PURE__ */ s.jsx(
                "span",
                {
                  className: o(
                    "flex items-center ml-2",
                    u(a.type)
                  ),
                  tabIndex: 0,
                  "aria-label": g(a.type),
                  style: { cursor: "pointer" },
                  children: l(a.type)
                }
              ) }),
              /* @__PURE__ */ s.jsx(b, { children: g(a.type) })
            ] })
          ] }) })
        ] });
      }
    },
    {
      accessorKey: "runs",
      size: 160,
      header: ({ column: e }) => /* @__PURE__ */ s.jsx(
        n,
        {
          column: e,
          title: "Total Runs (14D)",
          icon: F
        }
      ),
      cell: ({ row: e }) => /* @__PURE__ */ s.jsx("div", { className: "font-medium", children: e.original.runs.toLocaleString() })
    },
    {
      accessorKey: "lastResults",
      size: 190,
      header: ({ column: e }) => /* @__PURE__ */ s.jsx(
        n,
        {
          column: e,
          title: "Last Results",
          icon: q
        }
      ),
      cell: ({ row: e }) => /* @__PURE__ */ s.jsx(B, { days: e.original.lastResults })
    },
    {
      accessorKey: "last24Hours",
      size: 70,
      header: ({ column: e }) => /* @__PURE__ */ s.jsx(n, { column: e, title: "24H", icon: E }),
      cell: ({ row: e }) => /* @__PURE__ */ s.jsxs("div", { className: o("font-medium"), children: [
        e.original.last24Hours,
        "%"
      ] })
    },
    {
      accessorKey: "last7Days",
      size: 65,
      header: ({ column: e }) => /* @__PURE__ */ s.jsx(n, { column: e, title: "7D", icon: v }),
      cell: ({ row: e }) => /* @__PURE__ */ s.jsxs("div", { className: o("font-medium"), children: [
        e.original.last7Days,
        "%"
      ] })
    },
    {
      accessorKey: "last14Days",
      size: 65,
      header: ({ column: e }) => /* @__PURE__ */ s.jsx(n, { column: e, title: "14D", icon: v }),
      cell: ({ row: e }) => /* @__PURE__ */ s.jsxs("div", { className: o("font-medium"), children: [
        e.original.last14Days,
        "%"
      ] })
    }
  ];
  return /* @__PURE__ */ s.jsxs("div", { className: "flex flex-col w-full gap-4", children: [
    /* @__PURE__ */ s.jsx(
      W,
      {
        title: m("Trigger Health Status"),
        description: m("Monitor the health and performance of your triggers")
      }
    ),
    /* @__PURE__ */ s.jsx(
      I,
      {
        emptyStateTextTitle: m("No trigger data available"),
        emptyStateTextDescription: m(
          "Trigger health information will appear here"
        ),
        emptyStateIcon: /* @__PURE__ */ s.jsx(N, { className: "size-14" }),
        hidePagination: !0,
        columns: d,
        page: { data: t, previous: "", next: "" },
        isLoading: i
      }
    )
  ] });
}
export {
  $ as default
};
