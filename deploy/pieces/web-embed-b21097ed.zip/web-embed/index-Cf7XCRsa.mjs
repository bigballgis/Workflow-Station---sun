import { c as K, bd as W, be as A, bf as v, bg as F, bh as X, bi as b, a6 as s, j as e, bj as L, bk as k, ah as _, bl as I, bm as U, a2 as Z, a3 as J, a4 as ee, bn as se, a5 as te, bo as ie, bp as E, bq as P, i as m, aj as R, g as j, br as y, bs as $, bt as z, bu as V, bv as q, bw as Q, aQ as M, bx as N, by as G, ab as H, bz as g, b0 as ae, a$ as O, bA as ne, bB as le, L as C, bC as re, I as oe, bD as ce, bE as de, bF as xe, bG as ue } from "./mount-builder-CqIEWsZv.mjs";
import { C as me } from "./centered-page-C5JGBrkC.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const he = [
  ["path", { d: "M8 2v4", key: "1cmpym" }],
  ["path", { d: "M16 2v4", key: "4m81vk" }],
  ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2", key: "1hopcy" }],
  ["path", { d: "M3 10h18", key: "8toen8" }],
  ["path", { d: "M8 14h.01", key: "6423bh" }],
  ["path", { d: "M12 14h.01", key: "1etili" }],
  ["path", { d: "M16 14h.01", key: "1gbofw" }],
  ["path", { d: "M8 18h.01", key: "lrp35t" }],
  ["path", { d: "M12 18h.01", key: "mhygvu" }],
  ["path", { d: "M16 18h.01", key: "kzsmim" }]
], Y = K("calendar-days", he);
function pe({
  platformSubscription: t
}) {
  const { openDialog: i } = W(), { plan: a, usage: c } = t, o = c.activeFlows || 0, { data: d } = A.useFlag(v.EDITION), r = d !== F.COMMUNITY && a.plan === X.STANDARD, n = a.activeFlowsLimit, x = !b(n) && n > 0 && o / n > 0.8, l = b(n) ? s("Unlimited") : n.toLocaleString();
  return /* @__PURE__ */ e.jsxs(L, { variant: "outline", children: [
    /* @__PURE__ */ e.jsx(k, { variant: "icon", children: /* @__PURE__ */ e.jsx(_, {}) }),
    /* @__PURE__ */ e.jsxs(I, { children: [
      /* @__PURE__ */ e.jsxs(U, { children: [
        s("Active Flows"),
        /* @__PURE__ */ e.jsx(Z, { children: /* @__PURE__ */ e.jsxs(J, { children: [
          /* @__PURE__ */ e.jsx(ee, { asChild: !0, children: /* @__PURE__ */ e.jsx(se, { className: "size-4 text-muted-foreground" }) }),
          /* @__PURE__ */ e.jsx(te, { side: "bottom", children: s(
            `Count of active flows, $${ie} for extra 5 active flows`
          ) })
        ] }) })
      ] }),
      /* @__PURE__ */ e.jsxs(E, { children: [
        /* @__PURE__ */ e.jsxs("span", { className: "font-medium text-foreground", children: [
          o.toLocaleString(),
          " / ",
          l
        ] }),
        " ",
        s("flows used"),
        x && /* @__PURE__ */ e.jsx("span", { className: "ml-2 text-destructive font-medium", children: s("Approaching limit") })
      ] })
    ] }),
    r && /* @__PURE__ */ e.jsx(P, { children: /* @__PURE__ */ e.jsx(m, { variant: "outline", size: "sm", onClick: () => i(), children: s("Manage") }) })
  ] });
}
function je({
  isOpen: t,
  onOpenChange: i,
  currentThreshold: a,
  currentCreditsToAdd: c,
  currentMaxMonthlyLimit: o,
  isEditing: d = !1
}) {
  const r = R(), [n, x] = j.useState(a ?? 1e3), [l, T] = j.useState(
    c ?? 1e4
  ), [h, S] = j.useState(
    o ?? null
  ), { mutate: w, isPending: f } = y.useUpdateAutoTopUp(r), p = f, D = () => {
    const u = {
      minThreshold: n,
      creditsToAdd: l,
      maxMonthlyLimit: h,
      state: g.ENABLED
    };
    w(u, { onSuccess: () => {
      i(!1);
    } });
  };
  return /* @__PURE__ */ e.jsx($, { open: t, onOpenChange: i, children: /* @__PURE__ */ e.jsxs(z, { className: "max-w-[480px]", children: [
    /* @__PURE__ */ e.jsxs(V, { children: [
      /* @__PURE__ */ e.jsx(q, { children: d ? s("Edit Auto Top-up Configuration") : s("Enable Auto Top-up") }),
      /* @__PURE__ */ e.jsx(Q, { children: s("Automatically purchase credits when your balance runs low.") })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { className: "space-y-6 py-4", children: [
      /* @__PURE__ */ e.jsxs("div", { className: "space-y-6", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ e.jsx(M, { children: s("When credits fall below") }),
            /* @__PURE__ */ e.jsx("span", { className: "text-sm font-medium text-primary", children: s("{threshold} credits", {
              threshold: n.toLocaleString()
            }) })
          ] }),
          /* @__PURE__ */ e.jsx(
            N,
            {
              value: [n],
              onValueChange: (u) => x(u[0]),
              min: 0,
              max: 1e5,
              step: 1e3
            }
          ),
          /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between text-xs text-muted-foreground", children: [
            /* @__PURE__ */ e.jsx("span", { children: s("0") }),
            /* @__PURE__ */ e.jsx("span", { children: s("100,000") })
          ] })
        ] }),
        /* @__PURE__ */ e.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ e.jsx(M, { children: s("Add this many credits") }),
            /* @__PURE__ */ e.jsx("span", { className: "text-sm font-medium text-primary", children: s("{creditsToAdd} credits", {
              creditsToAdd: l.toLocaleString()
            }) })
          ] }),
          /* @__PURE__ */ e.jsx(
            N,
            {
              value: [l],
              onValueChange: (u) => T(u[0]),
              min: 1e3,
              max: 5e5,
              step: 1e3
            }
          ),
          /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between text-xs text-muted-foreground", children: [
            /* @__PURE__ */ e.jsx("span", { children: s("1,000") }),
            /* @__PURE__ */ e.jsx("span", { children: s("500,000") })
          ] })
        ] }),
        /* @__PURE__ */ e.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between items-center", children: [
            /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-0.5", children: [
              /* @__PURE__ */ e.jsx(M, { children: s("Monthly spending limit") }),
              /* @__PURE__ */ e.jsx("span", { className: "text-xs text-muted-foreground whitespace-nowrap", children: s("Maximum credits to add per month") })
            ] }),
            /* @__PURE__ */ e.jsx("span", { className: "text-sm font-medium text-primary", children: h ? s("{maxMonthlyLimit} credits (${usd})", {
              maxMonthlyLimit: h.toLocaleString(),
              usd: (h / 1e3 * 1).toFixed(2)
            }) : s("No limit") })
          ] }),
          /* @__PURE__ */ e.jsx(
            N,
            {
              value: [h ?? 0],
              onValueChange: (u) => S(u[0] === 0 ? null : u[0]),
              min: 0,
              max: 2e6,
              step: 1e4
            }
          ),
          /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between text-xs text-muted-foreground", children: [
            /* @__PURE__ */ e.jsx("span", { children: s("No limit") }),
            /* @__PURE__ */ e.jsx("span", { children: s("2,000,000") })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ e.jsx("div", { className: "rounded-lg border p-4 bg-primary/5 border-primary/30", children: /* @__PURE__ */ e.jsxs("div", { className: "space-y-3 animate-in fade-in duration-300", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between items-baseline", children: [
          /* @__PURE__ */ e.jsx("span", { className: "text-sm font-semibold", children: s("Payment per top-up") }),
          /* @__PURE__ */ e.jsx("span", { className: "text-2xl font-bold text-primary", children: s("${totalCost}", {
            totalCost: (l / 1e3 * 1).toFixed(2)
          }) })
        ] }),
        /* @__PURE__ */ e.jsx("div", { className: "text-xs text-muted-foreground text-right", children: s("$1 per 1000 credits") })
      ] }) })
    ] }),
    /* @__PURE__ */ e.jsxs(G, { children: [
      /* @__PURE__ */ e.jsx(
        m,
        {
          variant: "outline",
          onClick: () => i(!1),
          disabled: p,
          children: s("Cancel")
        }
      ),
      /* @__PURE__ */ e.jsxs(m, { onClick: D, disabled: p, children: [
        p && /* @__PURE__ */ e.jsx(H, { className: "w-4 h-4 animate-spin mr-2" }),
        s("Save Configuration")
      ] })
    ] })
  ] }) });
}
function ge({
  isOpen: t,
  onOpenChange: i
}) {
  const [a, c] = j.useState(1e3), o = 1, { mutate: d, isPending: r } = y.useCreateAICreditCheckoutSession(
    () => i(!1)
  ), n = a / 1e3 * o, x = () => {
    d({ aiCredits: a });
  };
  return /* @__PURE__ */ e.jsx($, { open: t, onOpenChange: i, children: /* @__PURE__ */ e.jsxs(z, { className: "max-w-[480px]", children: [
    /* @__PURE__ */ e.jsxs(V, { children: [
      /* @__PURE__ */ e.jsx(q, { className: "flex items-center gap-2 text-lg", children: s("Purchase AI Credits") }),
      /* @__PURE__ */ e.jsx(Q, { children: s("Add more credits to your wallet for AI tasks") })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ e.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between text-sm font-medium", children: [
          /* @__PURE__ */ e.jsx("span", { children: s("Credits to add") }),
          /* @__PURE__ */ e.jsx("span", { className: "text-primary font-semibold", children: s("{creditsToAdd} credits", {
            creditsToAdd: a.toLocaleString()
          }) })
        ] }),
        /* @__PURE__ */ e.jsx(
          N,
          {
            value: [a],
            onValueChange: (l) => c(l[0]),
            min: 1e3,
            max: 5e5,
            step: 1e3
          }
        ),
        /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between text-xs text-muted-foreground", children: [
          /* @__PURE__ */ e.jsx("span", { children: s("1,000") }),
          /* @__PURE__ */ e.jsx("span", { children: s("500,000") })
        ] })
      ] }),
      /* @__PURE__ */ e.jsx("div", { className: "rounded-lg border p-4 bg-primary/5 border-primary/30", children: /* @__PURE__ */ e.jsxs("div", { className: "space-y-3 animate-in fade-in duration-300", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex justify-between items-baseline", children: [
          /* @__PURE__ */ e.jsx("span", { className: "text-sm font-semibold", children: s("Total Cost") }),
          /* @__PURE__ */ e.jsx("span", { className: "text-2xl font-bold text-primary", children: s("${totalCost}", {
            totalCost: n.toFixed(2)
          }) })
        ] }),
        /* @__PURE__ */ e.jsx("div", { className: "text-xs text-muted-foreground text-right", children: s("${cost} per 1000 credits", { cost: o }) })
      ] }) })
    ] }),
    /* @__PURE__ */ e.jsxs(G, { children: [
      /* @__PURE__ */ e.jsx(
        m,
        {
          variant: "outline",
          onClick: () => i(!1),
          disabled: r,
          children: s("Cancel")
        }
      ),
      /* @__PURE__ */ e.jsxs(
        m,
        {
          onClick: x,
          className: "gap-2",
          disabled: r || a < 1e3,
          children: [
            r ? /* @__PURE__ */ e.jsx(H, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ e.jsx(_, { className: "w-4 h-4" }),
            r ? s("Processing...") : s("Purchase Credits")
          ]
        }
      )
    ] })
  ] }) });
}
function be({ platformSubscription: t }) {
  const i = R(), { plan: a, usage: c } = t, [o, d] = j.useState(!1), [r, n] = j.useState(!1), [x, l] = j.useState(!1), T = c.totalAiCreditsUsed, h = c.aiCreditsRemaining, S = window.location.hostname.includes("cloud.activepieces.com"), w = a.aiCreditsAutoTopUpState ?? g.DISABLED, f = A.useFlag(
    v.CAN_BUY_AI_CREDITS
  ), p = w === g.ENABLED, { mutate: D, isPending: u } = y.useUpdateAutoTopUp(i);
  return S ? /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-4", children: [
    /* @__PURE__ */ e.jsxs(L, { variant: "outline", children: [
      /* @__PURE__ */ e.jsx(k, { variant: "icon", children: /* @__PURE__ */ e.jsx(ae, {}) }),
      /* @__PURE__ */ e.jsxs(I, { children: [
        /* @__PURE__ */ e.jsx(U, { children: s("AI Credits") }),
        /* @__PURE__ */ e.jsxs(E, { children: [
          Math.round(h).toLocaleString(),
          " ",
          s("credits available"),
          /* @__PURE__ */ e.jsxs("span", { className: "ml-2 text-xs", children: [
            "(",
            s("Total used"),
            ":",
            " ",
            Math.round(T).toLocaleString(),
            ")"
          ] })
        ] })
      ] }),
      f && /* @__PURE__ */ e.jsx(P, { children: /* @__PURE__ */ e.jsx(
        m,
        {
          variant: "basic",
          size: "sm",
          onClick: () => d(!0),
          children: s("Purchase Credits")
        }
      ) })
    ] }),
    f && /* @__PURE__ */ e.jsxs(L, { variant: "outline", children: [
      /* @__PURE__ */ e.jsx(k, { variant: "icon", children: /* @__PURE__ */ e.jsx(O, {}) }),
      /* @__PURE__ */ e.jsxs(I, { children: [
        /* @__PURE__ */ e.jsx(U, { children: s("Auto Top-up") }),
        /* @__PURE__ */ e.jsx(E, { children: p ? fe(a) : s("Automatically purchase credits when balance is low.") })
      ] }),
      /* @__PURE__ */ e.jsxs(P, { children: [
        p && /* @__PURE__ */ e.jsx(
          m,
          {
            variant: "ghost",
            size: "icon",
            className: "h-8 w-8",
            onClick: () => {
              l(!0), n(!0);
            },
            children: /* @__PURE__ */ e.jsx(O, { className: "size-4" })
          }
        ),
        /* @__PURE__ */ e.jsx(
          ne,
          {
            checked: p,
            onCheckedChange: (B) => {
              B ? (l(!1), n(!0)) : D({ state: g.DISABLED });
            },
            disabled: u
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ e.jsx(
      ge,
      {
        isOpen: o,
        onOpenChange: d
      }
    ),
    /* @__PURE__ */ e.jsx(
      je,
      {
        isOpen: r,
        onOpenChange: n,
        isEditing: x,
        currentThreshold: a.aiCreditsAutoTopUpThreshold,
        currentCreditsToAdd: a.aiCreditsAutoTopUpCreditsToAdd,
        currentMaxMonthlyLimit: a.maxAutoTopUpCreditsMonthly
      }
    )
  ] }) : null;
}
function fe(t) {
  return t.aiCreditsAutoTopUpThreshold && t.aiCreditsAutoTopUpCreditsToAdd ? s("Adds {credits} credits when below {threshold}", {
    credits: t.aiCreditsAutoTopUpCreditsToAdd.toLocaleString(),
    threshold: t.aiCreditsAutoTopUpThreshold.toLocaleString()
  }) : s("Enabled");
}
const Ce = ({ info: t }) => /* @__PURE__ */ e.jsxs("div", { className: "space-y-4", children: [
  /* @__PURE__ */ e.jsx(le, { variant: "accent", className: "rounded-sm text-sm", children: b(t.plan.plan) ? s("Free") : (t == null ? void 0 : t.plan.plan.charAt(0).toUpperCase()) + (t == null ? void 0 : t.plan.plan.slice(1)) }),
  /* @__PURE__ */ e.jsxs("div", { className: "flex items-baseline gap-2", children: [
    /* @__PURE__ */ e.jsxs("div", { className: "text-5xl font-semibold", children: [
      "$",
      t.nextBillingAmount || 0 .toFixed(2)
    ] }),
    /* @__PURE__ */ e.jsx("div", { className: "text-xl text-muted-foreground", children: s("/month") })
  ] }),
  (t == null ? void 0 : t.nextBillingDate) && b(t.cancelAt) && /* @__PURE__ */ e.jsxs("div", { className: "text-sm text-muted-foreground flex items-center gap-2", children: [
    /* @__PURE__ */ e.jsx(Y, { className: "w-4 h-4" }),
    /* @__PURE__ */ e.jsxs("span", { children: [
      s("Next billing date "),
      /* @__PURE__ */ e.jsx("span", { className: "font-semibold", children: C(C.unix(t.nextBillingDate).toISOString()).format(
        "MMM D, YYYY"
      ) })
    ] })
  ] }),
  (t == null ? void 0 : t.cancelAt) && /* @__PURE__ */ e.jsxs("div", { className: "text-sm text-muted-foreground flex items-center gap-2", children: [
    /* @__PURE__ */ e.jsx(Y, { className: "w-4 h-4" }),
    /* @__PURE__ */ e.jsxs("span", { children: [
      s("Subscription will end"),
      " ",
      /* @__PURE__ */ e.jsx("span", { className: "font-semibold", children: C(C.unix(t.cancelAt).toISOString()).format(
        "MMM D, YYYY"
      ) })
    ] })
  ] })
] });
function ye() {
  const { data: t } = A.useFlag(v.EDITION);
  return /* @__PURE__ */ e.jsx(
    re,
    {
      featureKey: "BILLING",
      locked: t === F.COMMUNITY,
      lockTitle: s("Unlock Billing Page"),
      lockDescription: s(
        "Switch to the Enterprise edition to access billing and usage management."
      ),
      lockDocumentationUrl: "https://www.activepieces.com/docs/install/configuration/overview#enterprise-edition-optional",
      showContactSales: !1,
      children: /* @__PURE__ */ e.jsx(Ne, {})
    }
  );
}
function Ne() {
  var l;
  const { platform: t } = oe.useCurrentPlatform(), {
    data: i,
    isLoading: a,
    isError: c
  } = ce.usePlatformSubscription(t.id), { data: o } = A.useFlag(v.EDITION), d = o === F.COMMUNITY, { mutate: r } = y.usePortalLink(), n = (l = i == null ? void 0 : i.plan) == null ? void 0 : l.stripeSubscriptionStatus, x = de.ACTIVE === n;
  return a || b(i) ? /* @__PURE__ */ e.jsx("article", { className: "h-full flex items-center justify-center w-full", children: /* @__PURE__ */ e.jsx(xe, {}) }) : c ? /* @__PURE__ */ e.jsx("article", { className: "h-full flex items-center justify-center w-full", children: s("Failed to load billing information") }) : /* @__PURE__ */ e.jsx(
    me,
    {
      title: s("Billing"),
      description: s(
        "For questions about billing contact us at support@activepieces.com"
      ),
      children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-6", children: [
        x && /* @__PURE__ */ e.jsx(Ce, { info: i }),
        (x || (i == null ? void 0 : i.plan.aiCreditsAutoTopUpState) === g.ENABLED) && /* @__PURE__ */ e.jsx(
          m,
          {
            variant: "outline",
            size: "sm",
            className: "w-fit",
            onClick: () => r(),
            children: s("Access Billing Portal")
          }
        ),
        !d && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
          /* @__PURE__ */ e.jsx(pe, { platformSubscription: i }),
          /* @__PURE__ */ e.jsx(be, { platformSubscription: i })
        ] }),
        /* @__PURE__ */ e.jsx(ue, { platform: t })
      ] })
    }
  );
}
export {
  ye as default
};
