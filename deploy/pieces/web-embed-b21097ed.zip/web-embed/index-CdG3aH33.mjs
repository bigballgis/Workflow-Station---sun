import { c as K, a1 as V, I as q, fs as Q, ao as P, c0 as E, ft as S, c1 as F, fu as Y, b6 as w, aJ as I, a6 as a, fv as W, fw as $, fx as X, j as e, bs as O, b_ as Z, bt as k, c2 as z, bu as G, bv as M, c3 as B, c4 as A, c5 as ee, a3 as H, a4 as _, eQ as se, a5 as L, c9 as ae, aI as te, by as U, i as j, as as N, g as C, aQ as le, fy as re, c8 as ce, o as ne, s as ie, a_ as oe, cO as de, cQ as me, co as he, fz as ue, b9 as je, ba as xe, C as pe, bb as ge, bc as v, eB as R, cn as fe, cp as g, c$ as ye, cY as Pe, aa as Ce, c_ as Ne } from "./mount-builder-CqIEWsZv.mjs";
import { p as be, C as Se, P as m, a as ve, A as T, F as D } from "./apply-plan-CZiZRBzx.mjs";
import { R as Re } from "./rotate-ccw-ClYM7DvH.mjs";
import { D as Te } from "./database-DZzKBFIH.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const De = [
  ["path", { d: "M9 14 4 9l5-5", key: "102s5s" }],
  ["path", { d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11", key: "f3b9sd" }]
], Ee = K("undo-2", De), J = (i) => {
  const [h, r] = V.useState(!1), { platform: u } = q.useCurrentPlatform(), { gitSync: c } = Q.useGitSync(
    P.getProjectId(),
    u.plan.environmentsEnabled
  ), l = E({
    defaultValues: {
      type: S.PUSH_EVERYTHING,
      commitMessage: ""
    },
    resolver: F(Y)
  }), { mutate: n, isPending: x } = w({
    mutationFn: async (s) => {
      W(c, "gitSync"), await $.push(c.id, {
        type: S.PUSH_EVERYTHING,
        commitMessage: s.commitMessage
      });
    },
    onSuccess: () => {
      I.success(a("Everything is pushed successfully"), {
        duration: 3e3
      }), r(!1);
    }
  });
  return !c || c.branchType !== X.DEVELOPMENT ? null : /* @__PURE__ */ e.jsxs(O, { open: h, onOpenChange: r, children: [
    /* @__PURE__ */ e.jsx(Z, { asChild: !0, children: i.children }),
    /* @__PURE__ */ e.jsx(k, { children: /* @__PURE__ */ e.jsx(z, { ...l, children: /* @__PURE__ */ e.jsxs("form", { onSubmit: l.handleSubmit((s) => n(s)), children: [
      /* @__PURE__ */ e.jsx(G, { children: /* @__PURE__ */ e.jsx(M, { children: a("Push Everything to Git") }) }),
      /* @__PURE__ */ e.jsx(
        B,
        {
          control: l.control,
          name: "commitMessage",
          render: ({ field: s }) => /* @__PURE__ */ e.jsxs(A, { className: "gap-2 flex flex-col", children: [
            /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ e.jsx(ee, { children: a("Commit Message") }),
              /* @__PURE__ */ e.jsxs(H, { children: [
                /* @__PURE__ */ e.jsx(_, { asChild: !0, children: /* @__PURE__ */ e.jsx(se, { className: "w-4 h-4 text-muted-foreground cursor-help" }) }),
                /* @__PURE__ */ e.jsx(L, { className: "max-w-xs", children: a(
                  "Push all published flows, connections, and tables to the Git repository."
                ) })
              ] })
            ] }),
            /* @__PURE__ */ e.jsx(ae, { children: /* @__PURE__ */ e.jsx(te, { ...s }) }),
            /* @__PURE__ */ e.jsx("div", { className: "text-sm text-gray-500", children: a(
              "Enter a commit message to describe the changes you want to push."
            ) })
          ] })
        }
      ),
      /* @__PURE__ */ e.jsxs(U, { children: [
        /* @__PURE__ */ e.jsx(
          j,
          {
            type: "button",
            variant: "outline",
            onClick: () => {
              r(!1), l.reset();
            },
            children: a("Cancel")
          }
        ),
        /* @__PURE__ */ e.jsx(
          j,
          {
            type: "submit",
            loading: x,
            onClick: l.handleSubmit((s) => n(s)),
            children: a("Push")
          }
        )
      ] })
    ] }) }) })
  ] });
};
J.displayName = "PushEverythingDialog";
const Fe = ne({
  selectedProject: ie({ message: a("Please select project") })
});
function we({
  projectId: i,
  open: h,
  setOpen: r,
  onSuccess: u
}) {
  var b;
  const { data: c } = N.useAll(), [l, n] = C.useState(!1), [x, s] = C.useState(null), { mutate: d, isPending: p } = w({
    mutationFn: (t) => be.diff(t),
    onSuccess: (t) => {
      if ((!t.flows || t.flows.length === 0) && (!t.tables || t.tables.length === 0)) {
        I(a("No Changes Found"), {
          description: a("There are no differences to apply")
        });
        return;
      }
      s(t), r(!1), n(!0);
    }
  }), o = E({
    resolver: F(Fe),
    defaultValues: {
      selectedProject: (b = c == null ? void 0 : c.find((t) => t.id !== i)) == null ? void 0 : b.id
    }
  }), f = (t) => {
    if (!t.selectedProject) {
      o.setError("selectedProject", {
        type: "required",
        message: a("Please select a project")
      });
      return;
    }
    d({
      projectId: i,
      type: m.PROJECT,
      targetProjectId: t.selectedProject
    });
  };
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(
      O,
      {
        open: h,
        onOpenChange: (t) => {
          r(t), t && o.reset();
        },
        children: /* @__PURE__ */ e.jsxs(k, { className: "sm:max-w-[425px]", children: [
          /* @__PURE__ */ e.jsx(G, { children: /* @__PURE__ */ e.jsx(M, { children: a("Create Release") }) }),
          /* @__PURE__ */ e.jsx(z, { ...o, children: /* @__PURE__ */ e.jsxs(
            "form",
            {
              onSubmit: o.handleSubmit(f),
              className: "flex flex-col gap-4",
              children: [
                /* @__PURE__ */ e.jsx(
                  B,
                  {
                    control: o.control,
                    name: "selectedProject",
                    render: ({ field: t }) => /* @__PURE__ */ e.jsxs(A, { className: "grid gap-2", children: [
                      /* @__PURE__ */ e.jsx(le, { children: a("Project") }),
                      /* @__PURE__ */ e.jsx(
                        re,
                        {
                          onChange: t.onChange,
                          value: t.value,
                          placeholder: a("Search projects..."),
                          options: (c ?? []).filter((y) => y.id !== i).map((y) => ({
                            label: y.displayName,
                            value: y.id
                          }))
                        }
                      ),
                      /* @__PURE__ */ e.jsx(ce, {})
                    ] })
                  }
                ),
                /* @__PURE__ */ e.jsxs(U, { children: [
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      variant: "outline",
                      type: "button",
                      onClick: () => r(!1),
                      children: a("Cancel")
                    }
                  ),
                  /* @__PURE__ */ e.jsx(
                    j,
                    {
                      type: "submit",
                      onClick: () => o.handleSubmit(f),
                      loading: p,
                      children: a("Review Changes")
                    }
                  )
                ] })
              ]
            }
          ) })
        ] })
      }
    ),
    l && /* @__PURE__ */ e.jsx(
      Se,
      {
        loading: p,
        open: l,
        setOpen: n,
        refetch: u,
        diffRequest: {
          projectId: i,
          targetProjectId: o.getValues("selectedProject"),
          type: m.PROJECT
        },
        plan: x
      }
    )
  ] });
}
function Ie({
  ReleaseType: i,
  children: h,
  onSuccess: r,
  ...u
}) {
  const { project: c } = N.useCurrentProject(), [l, n] = C.useState(!1);
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(
      j,
      {
        ...u,
        onClick: () => {
          n(!0);
        },
        children: h
      }
    ),
    i === m.PROJECT && /* @__PURE__ */ e.jsx(
      we,
      {
        open: l,
        setOpen: n,
        projectId: c.id,
        onSuccess: r
      }
    )
  ] });
}
const Oe = () => {
  const i = oe(), { checkAccess: h } = de(), r = h(
    me.WRITE_PROJECT_RELEASE
  ), { data: u, isLoading: c, refetch: l } = ve.useProjectReleases(), { data: n } = N.useAll(), x = [
    {
      accessorKey: "name",
      size: 200,
      accessorFn: (s) => s.name,
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(g, { column: s, title: a("Name"), icon: ye }),
      cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: s.original.name })
    },
    {
      accessorKey: "type",
      size: 150,
      accessorFn: (s) => s.type,
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(
        g,
        {
          column: s,
          title: a("Source"),
          icon: Te
        }
      ),
      cell: ({ row: s }) => {
        var o;
        const d = s.original.type === m.GIT, p = s.original.type === m.PROJECT;
        return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
          d ? /* @__PURE__ */ e.jsx(R, { className: "size-4" }) : p ? /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ e.jsx(D, { className: "size-4" }),
            ((o = n == null ? void 0 : n.find(
              (f) => f.id === s.original.projectId
            )) == null ? void 0 : o.displayName) ?? a("Project")
          ] }) : /* @__PURE__ */ e.jsx(Re, { className: "size-4" }),
          d ? "Git" : p ? "" : a("Rollback")
        ] });
      }
    },
    {
      accessorKey: "created",
      size: 150,
      accessorFn: (s) => s.created,
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(
        g,
        {
          column: s,
          title: a("Imported At"),
          icon: Ce
        }
      ),
      cell: ({ row: s }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(Pe, { date: new Date(s.original.created) }) })
    },
    {
      accessorKey: "importedBy",
      size: 180,
      accessorFn: (s) => s.importedBy,
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(
        g,
        {
          column: s,
          title: a("Imported By"),
          icon: Ne
        }
      ),
      cell: ({ row: s }) => {
        var d;
        return /* @__PURE__ */ e.jsx("div", { className: "text-left", children: (d = s.original.importedByUser) == null ? void 0 : d.email });
      }
    },
    {
      accessorKey: "actions",
      id: "select",
      header: ({ column: s }) => /* @__PURE__ */ e.jsx(g, { column: s, title: "" }),
      cell: ({ row: s }) => /* @__PURE__ */ e.jsx(
        "div",
        {
          className: "flex items-center justify-center z-10",
          onClick: (d) => d.stopPropagation(),
          children: /* @__PURE__ */ e.jsxs(H, { children: [
            /* @__PURE__ */ e.jsx(_, { asChild: !0, children: /* @__PURE__ */ e.jsx(
              T,
              {
                onSuccess: l,
                variant: "ghost",
                className: "size-8 p-0",
                request: {
                  projectId: P.getProjectId(),
                  type: m.ROLLBACK,
                  projectReleaseId: s.original.id
                },
                defaultName: s.original.name,
                children: /* @__PURE__ */ e.jsx(Ee, { className: "size-4" })
              }
            ) }),
            /* @__PURE__ */ e.jsx(L, { side: "bottom", children: a("Rollback") })
          ] })
        }
      )
    }
  ];
  return /* @__PURE__ */ e.jsx("div", { className: "flex-col w-full gap-4", children: /* @__PURE__ */ e.jsx(
    he,
    {
      emptyStateTextTitle: a("No project releases found"),
      emptyStateTextDescription: a("Create a project release to get started"),
      emptyStateIcon: /* @__PURE__ */ e.jsx(fe, { className: "size-14" }),
      columns: x,
      toolbarButtons: [
        /* @__PURE__ */ e.jsx(J, { children: /* @__PURE__ */ e.jsx(
          j,
          {
            variant: "outline",
            disabled: !r,
            children: a("Push Everything")
          }
        ) }, "push"),
        /* @__PURE__ */ e.jsx(
          ue,
          {
            hasPermission: r,
            children: /* @__PURE__ */ e.jsxs(je, { modal: !1, children: [
              /* @__PURE__ */ e.jsx(xe, { asChild: !0, children: /* @__PURE__ */ e.jsxs(
                j,
                {
                  className: "w-full",
                  disabled: !r,
                  children: [
                    a("Create Release"),
                    /* @__PURE__ */ e.jsx(pe, { className: "h-3 w-4 ml-2" })
                  ]
                }
              ) }),
              /* @__PURE__ */ e.jsxs(ge, { children: [
                /* @__PURE__ */ e.jsx(v, { className: "cursor-pointer", asChild: !0, children: /* @__PURE__ */ e.jsx(
                  T,
                  {
                    variant: "ghost",
                    onSuccess: l,
                    className: "w-full justify-start",
                    request: {
                      type: m.GIT,
                      projectId: P.getProjectId()
                    },
                    children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row gap-2 items-center", children: [
                      /* @__PURE__ */ e.jsx(R, { className: "size-4" }),
                      /* @__PURE__ */ e.jsx("span", { children: a("From Git") })
                    ] })
                  }
                ) }),
                /* @__PURE__ */ e.jsx(v, { className: "cursor-pointer", asChild: !0, children: /* @__PURE__ */ e.jsx(
                  Ie,
                  {
                    variant: "ghost",
                    onSuccess: l,
                    className: "w-full justify-start",
                    ReleaseType: m.PROJECT,
                    children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row gap-2 items-center", children: [
                      /* @__PURE__ */ e.jsx(D, { className: "size-4" }),
                      /* @__PURE__ */ e.jsx("span", { children: a("From Project") })
                    ] })
                  }
                ) })
              ] })
            ] })
          },
          "create-release"
        )
      ],
      page: u,
      isLoading: c,
      onRowClick: (s) => {
        i(`/releases/${s.id}`);
      }
    }
  ) });
};
Oe.displayName = "ProjectReleasesPage";
export {
  Oe as ProjectReleasesPage
};
