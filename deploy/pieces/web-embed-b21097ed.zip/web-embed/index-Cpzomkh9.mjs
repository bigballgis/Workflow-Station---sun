import { dw as m, dx as d, g as q, j as e, bs as J, a3 as P, a4 as R, b_ as U, a5 as D, a6 as s, bt as Y, bu as $, bv as X, c0 as Q, c1 as Z, dy as ee, dz as E, dA as j, c2 as se, c6 as ae, c3 as S, c4 as f, aQ as v, dB as T, dC as b, dD as w, dE as F, dF as y, c8 as x, aX as O, dG as re, by as ne, i as p, e as te, G as ce, I as oe, bC as ie, cj as le, ck as de, co as ue, dH as z, af as me, cp as I, bB as A, Y as ge, dI as H, dJ as K, ar as he, aW as xe, cb as je, cc as pe, dK as Ce } from "./mount-builder-CqIEWsZv.mjs";
import { D as Se } from "./dashboard-page-header-BfLKPs1b.mjs";
const k = {
  getEmptySecretManagerConfig: fe,
  getDefaultValues: ve
};
function fe(a) {
  switch (a) {
    case d.HASHICORP:
      return { url: "", roleId: "", secretId: "" };
    case d.AWS:
      return { accessKeyId: "", secretAccessKey: "", region: "" };
    case d.CYBERARK:
      return { organizationAccountName: "", loginId: "", url: "", apiKey: "" };
    case d.ONEPASSWORD:
      return { serviceAccountToken: "" };
  }
}
function ve(a) {
  const n = a ? {
    name: a.name,
    scope: a.scope,
    projectIds: a.scope === m.PROJECT ? a.projectIds ?? [] : []
  } : {
    name: "",
    scope: m.PLATFORM,
    projectIds: []
  };
  switch ((a == null ? void 0 : a.providerId) ?? d.HASHICORP) {
    case d.HASHICORP:
      return {
        ...n,
        providerId: d.HASHICORP,
        config: { url: "", roleId: "", secretId: "" }
      };
    case d.AWS:
      return {
        ...n,
        providerId: d.AWS,
        config: { accessKeyId: "", secretAccessKey: "", region: "" }
      };
    case d.CYBERARK:
      return {
        ...n,
        providerId: d.CYBERARK,
        config: {
          organizationAccountName: "",
          loginId: "",
          url: "",
          apiKey: ""
        }
      };
    case d.ONEPASSWORD:
      return {
        ...n,
        providerId: d.ONEPASSWORD,
        config: { serviceAccountToken: "" }
      };
  }
}
const L = ({
  children: a,
  connection: n
}) => {
  const [i, t] = q.useState(!1);
  return /* @__PURE__ */ e.jsxs(J, { open: i, onOpenChange: t, children: [
    /* @__PURE__ */ e.jsxs(P, { children: [
      /* @__PURE__ */ e.jsx(R, { asChild: !0, children: /* @__PURE__ */ e.jsx(U, { asChild: !0, children: a }) }),
      /* @__PURE__ */ e.jsx(D, { children: s("Edit") })
    ] }),
    /* @__PURE__ */ e.jsxs(Y, { className: "max-w-2xl max-h-[90vh] overflow-y-auto", children: [
      /* @__PURE__ */ e.jsx($, { children: /* @__PURE__ */ e.jsx(X, { children: n ? `${s("Edit")} ${n.name}` : s("New Secret Manager Connection") }) }),
      /* @__PURE__ */ e.jsx(
        Ee,
        {
          connection: n,
          setOpen: t
        },
        i ? "open" : "closed"
      )
    ] })
  ] });
}, Ee = ({
  connection: a,
  setOpen: n
}) => {
  var M;
  const i = !!a, t = Q({
    resolver: Z(ee),
    mode: "onChange",
    defaultValues: k.getDefaultValues(a)
  }), u = t.watch("providerId"), N = t.watch("scope"), C = E.find((r) => r.id === u), { mutate: c, isPending: o } = j.useCreateSecretManagerConnection({
    onSuccess: () => n(!1),
    onError: (r) => B(r, t)
  }), { mutate: g, isPending: V } = j.useUpdateSecretManagerConnection({
    onSuccess: () => n(!1),
    onError: (r) => B(r, t)
  }), W = o || V, _ = (r) => {
    t.clearErrors("root.serverError"), i && a ? g({ id: a.id, config: r }) : c(r);
  };
  return /* @__PURE__ */ e.jsx(se, { ...t, children: /* @__PURE__ */ e.jsxs(
    "form",
    {
      className: "grid space-y-4",
      onSubmit: t.handleSubmit(_),
      children: [
        /* @__PURE__ */ e.jsx(ae, { className: "max-h-[500px]", children: /* @__PURE__ */ e.jsxs("div", { className: "grid space-y-3", children: [
          !i && /* @__PURE__ */ e.jsx(
            S,
            {
              name: "providerId",
              render: ({ field: r }) => /* @__PURE__ */ e.jsxs(f, { className: "space-y-2", children: [
                /* @__PURE__ */ e.jsx(v, { htmlFor: "provider-select", showRequiredIndicator: !0, children: s("Provider") }),
                /* @__PURE__ */ e.jsxs(
                  T,
                  {
                    value: r.value ?? "",
                    onValueChange: (l) => {
                      const h = E.find(
                        (G) => G.id === l
                      );
                      r.onChange(l), h && t.setValue(
                        "config",
                        k.getEmptySecretManagerConfig(
                          h.id
                        )
                      );
                    },
                    children: [
                      /* @__PURE__ */ e.jsx(b, { id: "provider-select", children: /* @__PURE__ */ e.jsx(w, { placeholder: s("Select a provider") }) }),
                      /* @__PURE__ */ e.jsx(F, { children: E.map((l) => /* @__PURE__ */ e.jsx(y, { value: l.id, children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                        /* @__PURE__ */ e.jsx(
                          "img",
                          {
                            src: l.logo,
                            alt: l.name,
                            className: "w-4 h-4 object-contain"
                          }
                        ),
                        /* @__PURE__ */ e.jsx("span", { children: l.name })
                      ] }) }, l.id)) })
                    ]
                  }
                ),
                /* @__PURE__ */ e.jsx(x, {})
              ] })
            }
          ),
          /* @__PURE__ */ e.jsx(
            S,
            {
              name: "name",
              render: ({ field: r }) => /* @__PURE__ */ e.jsxs(f, { className: "space-y-2", children: [
                /* @__PURE__ */ e.jsx(v, { htmlFor: "connection-name", showRequiredIndicator: !0, children: s("Name") }),
                /* @__PURE__ */ e.jsx(
                  O,
                  {
                    ...r,
                    id: "connection-name",
                    placeholder: s("e.g. Production HashiCorp"),
                    className: "rounded-sm"
                  }
                ),
                /* @__PURE__ */ e.jsx(x, {})
              ] })
            }
          ),
          /* @__PURE__ */ e.jsx(
            S,
            {
              name: "scope",
              render: ({ field: r }) => /* @__PURE__ */ e.jsxs(f, { className: "space-y-2", children: [
                /* @__PURE__ */ e.jsx(v, { htmlFor: "connection-scope", showRequiredIndicator: !0, children: s("Scope") }),
                /* @__PURE__ */ e.jsxs(T, { value: r.value, onValueChange: r.onChange, children: [
                  /* @__PURE__ */ e.jsx(b, { id: "connection-scope", children: /* @__PURE__ */ e.jsx(w, { placeholder: s("Select scope") }) }),
                  /* @__PURE__ */ e.jsxs(F, { children: [
                    /* @__PURE__ */ e.jsx(y, { value: m.PLATFORM, children: s("Platform") }),
                    /* @__PURE__ */ e.jsx(y, { value: m.PROJECT, children: s("Project") })
                  ] })
                ] }),
                /* @__PURE__ */ e.jsx(x, {})
              ] })
            }
          ),
          N === m.PROJECT && /* @__PURE__ */ e.jsx(re, { control: t.control, name: "projectIds" }),
          C && Object.entries(C.fields).map(
            ([r, l]) => /* @__PURE__ */ e.jsx(
              S,
              {
                name: `config.${r}`,
                render: ({ field: h }) => /* @__PURE__ */ e.jsxs(f, { className: "space-y-2", children: [
                  /* @__PURE__ */ e.jsx(
                    v,
                    {
                      htmlFor: r,
                      showRequiredIndicator: !l.optional,
                      children: l.displayName
                    }
                  ),
                  /* @__PURE__ */ e.jsx("div", { className: "flex gap-2 items-center justify-center", children: /* @__PURE__ */ e.jsx(
                    O,
                    {
                      ...h,
                      id: r,
                      placeholder: l.placeholder,
                      className: "rounded-sm",
                      type: l.type,
                      value: h.value
                    }
                  ) }),
                  /* @__PURE__ */ e.jsx(x, {})
                ] })
              },
              r
            )
          )
        ] }) }),
        ((M = t.formState.errors.root) == null ? void 0 : M.serverError) && /* @__PURE__ */ e.jsx(x, { children: t.formState.errors.root.serverError.message }),
        /* @__PURE__ */ e.jsxs(ne, { className: "mt-1", children: [
          /* @__PURE__ */ e.jsx(
            p,
            {
              variant: "outline",
              type: "button",
              onClick: (r) => {
                r.stopPropagation(), r.preventDefault(), n(!1);
              },
              children: s("Cancel")
            }
          ),
          /* @__PURE__ */ e.jsx(p, { loading: W, type: "submit", children: s("Save") })
        ] })
      ]
    }
  ) });
};
function B(a, n) {
  var i, t;
  if (te.isError(a)) {
    const u = (i = a.response) == null ? void 0 : i.data;
    (u == null ? void 0 : u.code) === ce.SECRET_MANAGER_CONNECTION_FAILED && n.setError("root.serverError", {
      type: "manual",
      message: s('Failed to connect to secret manager with error: "{msg}"', {
        msg: (t = u.params) == null ? void 0 : t.message
      })
    });
  } else
    n.setError("root.serverError", {
      type: "manual",
      message: s("Failed to connect to secret manager, please check console")
    });
}
const Ae = () => {
  const { platform: a } = oe.useCurrentPlatform(), { data: n, isLoading: i } = j.useListSecretManagerConnections({
    listForPlatform: !0,
    showErrorDialog: !0
  }), { mutate: t } = j.useDeleteSecretManagerConnection(), u = i, N = n ? { data: n, next: null, previous: null } : void 0, C = [
    {
      accessorKey: "name",
      size: 240,
      header: ({ column: c }) => /* @__PURE__ */ e.jsx(
        I,
        {
          column: c,
          title: s("Name"),
          icon: z
        }
      ),
      cell: ({ row: c }) => {
        const o = E.find(
          (g) => g.id === c.original.providerId
        );
        return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 w-fit", children: [
          /* @__PURE__ */ e.jsx(
            me,
            {
              size: "md",
              border: !0,
              displayName: o == null ? void 0 : o.name,
              logoUrl: o == null ? void 0 : o.logo,
              showTooltip: !0
            }
          ),
          /* @__PURE__ */ e.jsx("span", { children: c.original.name })
        ] });
      }
    },
    {
      accessorKey: "scope",
      size: 100,
      header: ({ column: c }) => /* @__PURE__ */ e.jsx(
        I,
        {
          column: c,
          title: s("Scope"),
          icon: ge
        }
      ),
      cell: ({ row: c }) => c.original.scope === m.PLATFORM ? /* @__PURE__ */ e.jsx(A, { variant: "outline", className: "text-xs", children: s("Platform") }) : /* @__PURE__ */ e.jsx(A, { variant: "outline", className: "text-xs", children: s("Project") })
    },
    {
      accessorKey: "connection",
      size: 100,
      header: ({ column: c }) => /* @__PURE__ */ e.jsx(
        I,
        {
          column: c,
          title: s("Status"),
          icon: K
        }
      ),
      cell: ({ row: c }) => {
        const { configured: o, connected: g } = c.original.connection;
        return o ? g ? /* @__PURE__ */ e.jsx(
          H,
          {
            icon: K,
            text: s("Connected"),
            variant: "success"
          }
        ) : /* @__PURE__ */ e.jsx(
          H,
          {
            icon: he,
            text: s("Disconnected"),
            variant: "error"
          }
        ) : /* @__PURE__ */ e.jsx(A, { variant: "outline", className: "text-xs text-muted-foreground", children: s("Not configured") });
      }
    },
    {
      id: "actions",
      cell: ({ row: c }) => {
        const o = c.original;
        return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1 justify-end", children: [
          /* @__PURE__ */ e.jsx(L, { connection: o, children: /* @__PURE__ */ e.jsx(p, { variant: "ghost", size: "sm", children: /* @__PURE__ */ e.jsx(xe, { className: "size-4" }) }) }),
          /* @__PURE__ */ e.jsx(Ne, { connection: o }),
          /* @__PURE__ */ e.jsx(
            je,
            {
              title: s("Delete Connection"),
              message: s(
                "Are you sure you want to delete this secret manager connection?"
              ),
              warning: s(
                "Deleting this secret manager connection will break all flows/app connections using it."
              ),
              entityName: o.name,
              mutationFn: async () => t(o.id),
              children: /* @__PURE__ */ e.jsx("div", { children: /* @__PURE__ */ e.jsxs(P, { children: [
                /* @__PURE__ */ e.jsx(R, { asChild: !0, children: /* @__PURE__ */ e.jsx(p, { variant: "ghost", size: "sm", children: /* @__PURE__ */ e.jsx(pe, { className: "size-4 text-destructive" }) }) }),
                /* @__PURE__ */ e.jsx(D, { children: s("Delete") })
              ] }) })
            }
          )
        ] });
      }
    }
  ];
  return /* @__PURE__ */ e.jsx(
    ie,
    {
      featureKey: "SECRET_MANAGERS",
      locked: !a.plan.secretManagersEnabled,
      lockTitle: s("Enable Secret Managers"),
      lockDescription: s("Manage your secrets from a single and secure place"),
      children: /* @__PURE__ */ e.jsxs("div", { className: "flex-col w-full", children: [
        /* @__PURE__ */ e.jsx(
          Se,
          {
            title: s("Secret Managers"),
            description: s("Manage Secret Manager connections"),
            children: /* @__PURE__ */ e.jsx(L, { children: /* @__PURE__ */ e.jsx(le, { icon: de, iconSize: 16, size: "sm", children: s("New Connection") }) })
          }
        ),
        /* @__PURE__ */ e.jsx(
          ue,
          {
            emptyStateTextTitle: s("No connections found"),
            emptyStateTextDescription: s(
              "Add a secret manager connection to manage your secrets"
            ),
            emptyStateIcon: /* @__PURE__ */ e.jsx(z, { className: "size-14" }),
            columns: C,
            page: N,
            isLoading: u,
            hidePagination: !0
          }
        )
      ] })
    }
  );
}, Ne = ({
  connection: a
}) => {
  const { mutate: n, isPending: i } = j.useClearCache();
  return /* @__PURE__ */ e.jsxs(P, { children: [
    /* @__PURE__ */ e.jsx(R, { asChild: !0, children: /* @__PURE__ */ e.jsx(
      p,
      {
        variant: "ghost",
        size: "sm",
        loading: i,
        onClick: () => n(a.id),
        children: /* @__PURE__ */ e.jsx(Ce, { className: "size-4" })
      }
    ) }),
    /* @__PURE__ */ e.jsx(D, { children: s("Clear Cache") })
  ] });
};
export {
  Ae as default
};
