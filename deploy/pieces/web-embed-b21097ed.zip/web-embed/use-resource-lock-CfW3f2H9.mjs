import { c as R, E as x, ao as p, g as i, W as m, jx as u, j as s, fa as v, a3 as g, a4 as S, a5 as U, a6 as k, h as E, jy as O, aS as N } from "./mount-builder-CqIEWsZv.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const j = [
  ["path", { d: "M12 13v8", key: "1l5pq0" }],
  ["path", { d: "M4 14.899A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 2.5 8.242", key: "1pljnt" }],
  ["path", { d: "m8 17 4-4 4 4", key: "1quai1" }]
], y = R("cloud-upload", j);
function _({ resourceId: t }) {
  const e = x(), r = p.getCurrentUserId(), [a, l] = i.useState([]);
  return i.useEffect(() => {
    const o = (d) => {
      d.resourceId === t && l(d.users.filter((n) => n.userId !== r));
    };
    return e.on(m.PRESENCE_UPDATED, o), () => {
      e.off(m.PRESENCE_UPDATED, o);
    };
  }, [t, e, r]), i.useEffect(() => {
    e.emit(
      u.JOIN_PRESENCE,
      { resourceId: t },
      (d) => {
        l(
          d.users.filter((n) => n.userId !== r)
        );
      }
    );
    const o = setInterval(() => {
      e.emit(u.JOIN_PRESENCE, { resourceId: t });
    }, 3e4);
    return () => {
      clearInterval(o), e.emit(u.LEAVE_PRESENCE, { resourceId: t });
    };
  }, [t, e, r]), a;
}
const h = 5, b = 28, C = [
  "hsl(var(--destructive-500))",
  "hsl(var(--chart-1))",
  "hsl(var(--warning-500))",
  "hsl(var(--success-500))",
  "hsl(var(--chart-2))",
  "hsl(var(--primary))",
  "hsl(var(--chart-5))",
  "hsl(var(--chart-4))"
];
function A(t) {
  let e = 0;
  for (let r = 0; r < t.length; r++)
    e = e * 31 + t.charCodeAt(r) | 0;
  return C[Math.abs(e) % C.length];
}
function B({ resourceId: t }) {
  const e = _({ resourceId: t });
  if (e.length === 0)
    return null;
  const r = e.slice(0, h), a = e.length - h;
  return /* @__PURE__ */ s.jsxs("div", { className: "flex items-center gap-1", children: [
    r.map((l) => /* @__PURE__ */ s.jsx(
      "div",
      {
        className: "rounded-full border-2",
        style: { borderColor: A(l.userId) },
        children: /* @__PURE__ */ s.jsx(v, { id: l.userId, size: "small" })
      },
      l.userId
    )),
    a > 0 && /* @__PURE__ */ s.jsxs(g, { children: [
      /* @__PURE__ */ s.jsx(S, { asChild: !0, children: /* @__PURE__ */ s.jsxs(
        "div",
        {
          className: "flex items-center justify-center rounded-full bg-muted text-xs font-medium text-muted-foreground border",
          style: { width: `${b}px`, height: `${b}px` },
          children: [
            "+",
            a
          ]
        }
      ) }),
      /* @__PURE__ */ s.jsx(U, { side: "bottom", children: k("+{count} more", { count: a }) })
    ] })
  ] });
}
function I({ ...t }) {
  return /* @__PURE__ */ s.jsx("nav", { "aria-label": "breadcrumb", "data-slot": "breadcrumb", ...t });
}
function D({ className: t, ...e }) {
  return /* @__PURE__ */ s.jsx(
    "ol",
    {
      "data-slot": "breadcrumb-list",
      className: E(
        "flex flex-wrap items-center gap-1.5 text-sm break-words text-muted-foreground sm:gap-2.5",
        t
      ),
      ...e
    }
  );
}
function P({ className: t, ...e }) {
  return /* @__PURE__ */ s.jsx(
    "li",
    {
      "data-slot": "breadcrumb-item",
      className: E("inline-flex items-center gap-1.5", t),
      ...e
    }
  );
}
function w({
  asChild: t,
  className: e,
  ...r
}) {
  const a = t ? O : "a";
  return /* @__PURE__ */ s.jsx(
    a,
    {
      "data-slot": "breadcrumb-link",
      className: E("transition-colors hover:text-foreground", e),
      ...r
    }
  );
}
function K({ className: t, ...e }) {
  return /* @__PURE__ */ s.jsx(
    "span",
    {
      "data-slot": "breadcrumb-page",
      role: "link",
      "aria-disabled": "true",
      "aria-current": "page",
      className: E("font-normal text-foreground", t),
      ...e
    }
  );
}
function T({
  children: t,
  className: e,
  ...r
}) {
  return /* @__PURE__ */ s.jsx(
    "li",
    {
      "data-slot": "breadcrumb-separator",
      role: "presentation",
      "aria-hidden": "true",
      className: E("[&>svg]:size-3.5", e),
      ...r,
      children: t ?? /* @__PURE__ */ s.jsx(N, {})
    }
  );
}
function q({ resourceId: t }) {
  const e = x(), r = p.getCurrentUserId(), a = i.useRef(!1), [l, o] = i.useState(null);
  i.useEffect(() => {
    const n = (f) => {
      f.resourceId === t && f.userId !== r && o({
        userId: f.userId,
        userDisplayName: f.userDisplayName
      });
    }, c = (f) => {
      f.resourceId === t && o(null);
    };
    return e.on(m.RESOURCE_LOCKED, n), e.on(m.RESOURCE_UNLOCKED, c), () => {
      e.off(m.RESOURCE_LOCKED, n), e.off(m.RESOURCE_UNLOCKED, c);
    };
  }, [t, e, r]), i.useEffect(() => {
    e.emit(
      u.LOCK_RESOURCE,
      { resourceId: t },
      (c) => {
        c.acquired ? a.current = !0 : c.lock && o(c.lock);
      }
    );
    const n = setInterval(() => {
      a.current && e.emit(
        u.LOCK_RESOURCE,
        { resourceId: t },
        (c) => {
          !c.acquired && c.lock && (a.current = !1, o(c.lock));
        }
      );
    }, 3e4);
    return () => {
      clearInterval(n), a.current && (e.emit(u.UNLOCK_RESOURCE, { resourceId: t }), a.current = !1);
    };
  }, [t, e]);
  const d = i.useCallback(() => {
    e.emit(
      u.LOCK_RESOURCE,
      { resourceId: t, force: !0 },
      (n) => {
        n.acquired && (a.current = !1, window.location.reload());
      }
    );
  }, [t, e]);
  return { lockedBy: l, takeOver: d };
}
export {
  B as A,
  I as B,
  y as C,
  D as a,
  P as b,
  w as c,
  T as d,
  K as e,
  q as u
};
