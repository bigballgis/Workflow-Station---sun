import { c as B, j as e, c7 as de, b9 as ve, ba as Ne, i as T, C as Se, bb as Re, bc as O, a6 as t, bi as D, cp as E, cd as Be, fQ as L, dI as Le, D as A, dJ as Ve, cY as Ke, aa as Qe, a3 as Z, a4 as ee, a5 as se, fR as He, b3 as We, fS as we, be as Ye, bf as qe, bs as te, bt as ae, bu as ye, bv as be, c6 as Je, h as Ge, G as Xe, cf as Ze, ao as b, a_ as ne, bK as Te, fT as ue, bw as es, fU as ss, b1 as Ae, by as ts, aY as as, fV as is, af as ns, d1 as Ie, eQ as rs, d6 as U, fW as ls, g as j, ax as os, ay as cs, aA as ds, bn as us, fX as ms, fY as me, H as gs, cO as fs, cQ as hs, a9 as q, ai as xs, fZ as M, f_ as J, aJ as ps, fz as G, f$ as ge, ar as fe, g0 as he, g1 as xe, co as js, da as vs, g2 as Ns, d5 as Ss, g3 as Rs } from "./mount-builder-CqIEWsZv.mjs";
import { T as ws } from "./truncated-column-text-value-Bg-cyJFo.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ys = [
  ["rect", { width: "20", height: "5", x: "2", y: "3", rx: "1", key: "1wp1u1" }],
  ["path", { d: "M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8", key: "1s80jp" }],
  ["path", { d: "M10 12h4", key: "a56b0p" }]
], ke = B("archive", ys);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const bs = [
  ["path", { d: "M5 22h14", key: "ehvnwv" }],
  ["path", { d: "M5 2h14", key: "pdyrp9" }],
  [
    "path",
    {
      d: "M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22",
      key: "1d314k"
    }
  ],
  [
    "path",
    { d: "M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2", key: "1vvvr6" }
  ]
], Ts = B("hourglass", bs);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const As = [
  ["path", { d: "M21 7v6h-6", key: "3ptur4" }],
  ["path", { d: "M3 17a9 9 0 0 1 9-9 9 9 0 0 1 6 2.3l3 2.7", key: "1kgawr" }]
], Is = B("redo", As);
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ks = [
  ["path", { d: "M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8", key: "1p45f6" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }]
], pe = B("rotate-cw", ks), Cs = ({
  setSelectedRows: s,
  selectedRows: o,
  selectedAll: i,
  setSelectedAll: g,
  excludedRows: n,
  setExcludedRows: d,
  data: r,
  onViewError: v,
  onViewRun: c
}) => [
  {
    id: "select",
    accessorKey: "select",
    size: 40,
    minSize: 40,
    maxSize: 40,
    header: ({ table: a }) => /* @__PURE__ */ e.jsxs("div", { className: "flex items-center h-full relative", children: [
      /* @__PURE__ */ e.jsx(
        de,
        {
          checked: i || a.getIsAllPageRowsSelected(),
          onCheckedChange: (u) => {
            const m = !!u;
            if (a.toggleAllPageRowsSelected(m), m) {
              const N = a.getRowModel().rows.map((S) => ({
                id: S.original.id,
                status: S.original.status
              }));
              s((S) => {
                const R = new Map([
                  ...S.map((w) => [w.id, w]),
                  ...N.map(
                    (w) => [w.id, w]
                  )
                ]);
                return Array.from(R.values());
              });
            } else
              g(!1), s([]), d(/* @__PURE__ */ new Set());
          }
        }
      ),
      o.length > 0 && /* @__PURE__ */ e.jsx("div", { className: "absolute left-5", children: /* @__PURE__ */ e.jsxs(ve, { children: [
        /* @__PURE__ */ e.jsx(Ne, { asChild: !0, children: /* @__PURE__ */ e.jsx(T, { variant: "ghost", size: "xs", children: /* @__PURE__ */ e.jsx(Se, { className: "h-4 w-4" }) }) }),
        /* @__PURE__ */ e.jsxs(Re, { className: "z-50", children: [
          /* @__PURE__ */ e.jsx(
            O,
            {
              className: "cursor-pointer",
              onClick: () => {
                const u = a.getRowModel().rows.map((m) => ({
                  id: m.original.id,
                  status: m.original.status
                }));
                s(u), g(!1), d(/* @__PURE__ */ new Set()), a.toggleAllPageRowsSelected(!0);
              },
              children: t("Select shown")
            }
          ),
          /* @__PURE__ */ e.jsx(
            O,
            {
              className: "cursor-pointer",
              onClick: () => {
                if (r != null && r.data) {
                  const u = r.data.map((m) => ({
                    id: m.id,
                    status: m.status
                  }));
                  s(u), g(!0), d(/* @__PURE__ */ new Set()), a.toggleAllPageRowsSelected(!0);
                }
              },
              children: t("Select all")
            }
          )
        ] })
      ] }) })
    ] }),
    cell: ({ row: a }) => {
      const u = n.has(a.original.id), m = i ? !u : o.some(
        (N) => N.id === a.original.id
      );
      return /* @__PURE__ */ e.jsx("div", { className: "flex items-center h-full", children: /* @__PURE__ */ e.jsx(
        de,
        {
          checked: m,
          onCheckedChange: (N) => {
            const S = !!N;
            if (i)
              if (S) {
                const R = new Set(n);
                R.delete(a.original.id), d(R);
              } else
                d(/* @__PURE__ */ new Set([...n, a.original.id]));
            else
              s(S ? (R) => [
                ...R,
                {
                  id: a.original.id,
                  status: a.original.status
                }
              ] : (R) => R.filter(
                (w) => w.id !== a.original.id
              ));
            a.toggleSelected(S);
          }
        }
      ) });
    }
  },
  {
    accessorKey: "flowId",
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      E,
      {
        column: a,
        title: t("Flow"),
        icon: Be
      }
    ),
    cell: ({ row: a }) => {
      const { archivedAt: u, flowVersion: m } = a.original, N = (m == null ? void 0 : m.displayName) ?? "—";
      return /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 text-left", children: [
        !D(u) && /* @__PURE__ */ e.jsx(ke, { className: "size-4 text-muted-foreground" }),
        /* @__PURE__ */ e.jsx(ws, { value: N })
      ] });
    }
  },
  {
    accessorKey: "status",
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      E,
      {
        column: a,
        title: t("Status"),
        icon: Ve
      }
    ),
    cell: ({ row: a }) => {
      const u = a.original.status, { variant: m, Icon: N } = L.getStatusIcon(u);
      return /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(
        Le,
        {
          icon: N,
          text: A.convertEnumToReadable(u),
          variant: m
        }
      ) });
    }
  },
  {
    accessorKey: "created",
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      E,
      {
        column: a,
        title: t("Started At"),
        icon: Qe
      }
    ),
    cell: ({ row: a }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(
      Ke,
      {
        date: new Date(a.original.created ?? /* @__PURE__ */ new Date()),
        className: "text-left",
        includeTime: !0
      }
    ) })
  },
  {
    accessorKey: "duration",
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      E,
      {
        column: a,
        title: t("Duration"),
        icon: He
      }
    ),
    cell: ({ row: a }) => {
      const u = a.original.startTime && a.original.finishTime ? new Date(a.original.finishTime).getTime() - new Date(a.original.startTime).getTime() : void 0, m = a.original.startTime && a.original.created ? new Date(a.original.startTime).getTime() - new Date(a.original.created).getTime() : void 0;
      return /* @__PURE__ */ e.jsxs(Z, { children: [
        /* @__PURE__ */ e.jsx(ee, { children: /* @__PURE__ */ e.jsx("div", { className: "text-left flex items-center gap-2", children: a.original.finishTime && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
          /* @__PURE__ */ e.jsx(Ts, { className: "h-4 w-4 text-muted-foreground" }),
          A.formatDuration(u)
        ] }) }) }),
        /* @__PURE__ */ e.jsx(se, { side: "bottom", children: t(
          `Time waited before first execution attempt: ${A.formatDuration(
            m
          )}`
        ) })
      ] });
    }
  },
  {
    accessorKey: "failedStep",
    header: ({ column: a }) => /* @__PURE__ */ e.jsx(
      E,
      {
        column: a,
        title: t("Failure"),
        icon: We
      }
    ),
    cell: ({ row: a }) => {
      const { failedStep: u } = a.original;
      return D(u) ? /* @__PURE__ */ e.jsx("div", { className: "text-left", children: "-" }) : /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsxs(Z, { children: [
        /* @__PURE__ */ e.jsx(ee, { asChild: !0, children: /* @__PURE__ */ e.jsx(
          T,
          {
            variant: "ghost",
            size: "sm",
            onClick: (m) => {
              m.stopPropagation(), u.message ? v(a.original) : c(a.original);
            },
            children: t("View error")
          }
        ) }),
        /* @__PURE__ */ e.jsx(se, { side: "bottom", children: t("Failed on ({stepName})", {
          stepName: u.displayName
        }) })
      ] }) });
    }
  }
], Ds = ({
  open: s,
  onOpenChange: o,
  failedRuns: i
}) => {
  const g = we(), { data: n } = Ye.useFlag(
    qe.EXECUTION_DATA_RETENTION_DAYS
  );
  return /* @__PURE__ */ e.jsx(te, { open: s, onOpenChange: o, children: /* @__PURE__ */ e.jsxs(ae, { className: "max-w-lg", children: [
    /* @__PURE__ */ e.jsx(ye, { children: /* @__PURE__ */ e.jsx(be, { children: t("Failed Retries") }) }),
    /* @__PURE__ */ e.jsx(Je, { className: "max-h-[400px]", children: /* @__PURE__ */ e.jsx("ul", { className: "flex flex-col gap-3 pr-3", children: i.map((d) => {
      var c;
      const { Icon: r, variant: v } = L.getStatusIcon(d.status);
      return /* @__PURE__ */ e.jsxs(
        "li",
        {
          className: "flex items-start justify-between gap-3 rounded-md border p-3",
          children: [
            /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-1 min-w-0", children: [
              /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1.5 text-sm font-medium", children: [
                /* @__PURE__ */ e.jsx(
                  r,
                  {
                    className: Ge("size-4 shrink-0", {
                      "text-destructive": v === "error",
                      "text-success": v === "success",
                      "text-muted-foreground": v === "default"
                    })
                  }
                ),
                /* @__PURE__ */ e.jsxs("span", { className: "truncate", children: [
                  t("Previous status"),
                  ":",
                  " ",
                  A.convertEnumToHumanReadable(d.status)
                ] })
              ] }),
              /* @__PURE__ */ e.jsx("p", { className: "text-xs text-muted-foreground", children: ((c = d.error) == null ? void 0 : c.errorCode) === Xe.FLOW_RUN_RETRY_OUTSIDE_RETENTION ? t(
                "Retry is only available for {failedJobRetentionDays} after a run fails.",
                {
                  failedJobRetentionDays: n
                }
              ) : d.error.errorMessage ?? t("Internal server error") })
            ] }),
            /* @__PURE__ */ e.jsxs(
              T,
              {
                variant: "ghost",
                size: "sm",
                className: "shrink-0",
                onClick: () => g(
                  b.appendProjectRoutePrefix(
                    `/runs/${d.id}`
                  )
                ),
                children: [
                  /* @__PURE__ */ e.jsx(Ze, { className: "size-4" }),
                  /* @__PURE__ */ e.jsx("span", { className: "sr-only", children: t("Open run") })
                ]
              }
            )
          ]
        },
        d.id
      );
    }) }) })
  ] }) });
}, Ps = ({
  run: s,
  open: o,
  onOpenChange: i
}) => {
  var N;
  const g = ne(), n = s == null ? void 0 : s.failedStep, { data: d } = Te.useGetFlow({
    flowId: (s == null ? void 0 : s.flowId) ?? "",
    versionId: s == null ? void 0 : s.flowVersionId,
    enabled: o && !D(s) && !D(n)
  });
  if (D(s) || D(n))
    return /* @__PURE__ */ e.jsx(te, { open: o, onOpenChange: i, children: /* @__PURE__ */ e.jsx(ae, { className: "max-w-lg" }) });
  const r = d == null ? void 0 : d.version, v = r ? ue.getStep(n.name, r.trigger) : void 0, c = r ? ue.getStepNumber(r.trigger, n.name) : null, a = ((N = s.flowVersion) == null ? void 0 : N.displayName) ?? (r == null ? void 0 : r.displayName) ?? "", u = s.finishTime ?? s.startTime ?? s.created, { Icon: m } = L.getStatusIcon(s.status);
  return /* @__PURE__ */ e.jsx(te, { open: o, onOpenChange: i, children: /* @__PURE__ */ e.jsxs(ae, { className: "max-w-lg", onClick: (S) => S.stopPropagation(), children: [
    /* @__PURE__ */ e.jsxs(ye, { children: [
      /* @__PURE__ */ e.jsxs(be, { className: "flex items-center gap-2 text-base", children: [
        /* @__PURE__ */ e.jsx(m, { className: "size-4 shrink-0 text-destructive-800 dark:text-destructive-200" }),
        /* @__PURE__ */ e.jsx("span", { className: "truncate", children: a || t("Run Failed") })
      ] }),
      /* @__PURE__ */ e.jsx(es, { className: "text-xs", children: u ? A.formatDateWithTime(new Date(u), !0) : null })
    ] }),
    n.message ? /* @__PURE__ */ e.jsx(
      ss,
      {
        json: n.message,
        title: /* @__PURE__ */ e.jsxs("span", { className: "flex items-center gap-2 min-w-0", children: [
          v ? /* @__PURE__ */ e.jsx(Es, { step: v }) : /* @__PURE__ */ e.jsx(Ae, { className: "size-[25px] rounded-md shrink-0" }),
          /* @__PURE__ */ e.jsx("span", { className: "truncate", children: c ? `${c}. ${n.displayName}` : n.displayName })
        ] }),
        className: "max-h-[400px] overflow-auto",
        hideDownload: !0
      }
    ) : /* @__PURE__ */ e.jsx("div", { className: "text-sm italic text-muted-foreground", children: t("No error message available") }),
    /* @__PURE__ */ e.jsx(ts, { children: /* @__PURE__ */ e.jsxs(
      T,
      {
        onClick: () => g(
          b.appendProjectRoutePrefix(
            `/runs/${s.id}`
          )
        ),
        children: [
          /* @__PURE__ */ e.jsx(as, { className: "size-4" }),
          t("Go to run")
        ]
      }
    ) })
  ] }) });
}, Es = ({ step: s }) => {
  const { stepMetadata: o, isLoading: i } = is.useStepMetadata({ step: s });
  return i || !o ? /* @__PURE__ */ e.jsx(Ae, { className: "size-[25px] rounded-md shrink-0" }) : /* @__PURE__ */ e.jsx(
    ns,
    {
      logoUrl: o.logoUrl,
      displayName: o.displayName,
      size: "xs",
      border: !1,
      showTooltip: !1
    }
  );
}, _ = "flowRunIds", Ms = ({
  retriedRunsIds: s,
  clearRetriedRuns: o
}) => {
  const [, i] = Ie(), g = ne();
  return s.length === 0 ? null : /* @__PURE__ */ e.jsx("div", { className: "fixed bottom-5 p-4 left-1/2 transform -translate-x-1/2  w-[480px]  animate-slide-in-from-bottom  bg-background shadow-lg border rounded-lg z-9999", children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center justify-between animate-fade", children: [
    /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ e.jsx(rs, { className: "size-5" }),
      t("runsRetriedNote", {
        runsCount: s.length
      })
    ] }),
    /* @__PURE__ */ e.jsx(
      T,
      {
        variant: "outline",
        size: "sm",
        onClick: () => {
          g(b.appendProjectRoutePrefix("/runs")), i({
            [_]: s,
            [U]: s.length.toString()
          }), o();
        },
        children: t("View")
      }
    )
  ] }) });
}, F = 20, ie = 6, je = 2.5, X = 2 * Math.PI * ie, C = F / 2;
function _s({
  categories: s,
  total: o
}) {
  let i = 0;
  return /* @__PURE__ */ e.jsx(
    "svg",
    {
      width: F,
      height: F,
      viewBox: `0 0 ${F} ${F}`,
      children: o === 0 ? /* @__PURE__ */ e.jsx(
        "circle",
        {
          cx: C,
          cy: C,
          r: ie,
          fill: "none",
          stroke: "var(--muted-foreground)",
          strokeWidth: je,
          opacity: 0.4
        }
      ) : s.map((g) => {
        const n = g.count / o * X, d = X - i;
        return i += n, /* @__PURE__ */ e.jsx(
          "circle",
          {
            cx: C,
            cy: C,
            r: ie,
            fill: "none",
            stroke: g.color,
            strokeWidth: je,
            strokeDasharray: `${n} ${X - n}`,
            strokeDashoffset: d,
            transform: `rotate(-90 ${C} ${C})`
          },
          g.label
        );
      })
    }
  );
}
function Fs() {
  const { categories: s, total: o, refetch: i } = ls.useRunStats(), [g, n] = j.useState(!1), [d, r] = j.useState(!1), v = j.useCallback(
    (c) => {
      n(c), c ? i() : r(!1);
    },
    [i]
  );
  return j.useEffect(() => {
    g && requestAnimationFrame(() => r(!0));
  }, [g]), /* @__PURE__ */ e.jsxs(os, { open: g, onOpenChange: v, children: [
    /* @__PURE__ */ e.jsx(cs, { asChild: !0, children: /* @__PURE__ */ e.jsxs("button", { className: "flex items-center gap-2 px-3 py-1.5 border border-dashed rounded-md hover:bg-accent transition-colors text-sm text-muted-foreground", children: [
      /* @__PURE__ */ e.jsx(_s, { categories: s, total: o }),
      t("Queue Status")
    ] }) }),
    /* @__PURE__ */ e.jsx(ds, { align: "end", className: "w-80 p-4", children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-col gap-3", children: [
      /* @__PURE__ */ e.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-1.5", children: [
          /* @__PURE__ */ e.jsx("p", { className: "text-sm font-medium", children: t("Current Queue Status") }),
          /* @__PURE__ */ e.jsxs(Z, { children: [
            /* @__PURE__ */ e.jsx(ee, { asChild: !0, children: /* @__PURE__ */ e.jsx(us, { className: "size-3.5 text-muted-foreground" }) }),
            /* @__PURE__ */ e.jsx(se, { side: "top", children: t("Showing results from the last 7 days") })
          ] })
        ] }),
        /* @__PURE__ */ e.jsxs("p", { className: "text-xs text-muted-foreground", children: [
          t("Total Runs"),
          ": ",
          A.formatNumberCompact(o)
        ] })
      ] }),
      o === 0 ? /* @__PURE__ */ e.jsx("p", { className: "text-sm text-muted-foreground", children: t("There are no runs") }) : /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
        /* @__PURE__ */ e.jsx("div", { className: "flex h-3 w-full overflow-hidden rounded-full bg-muted", children: s.map((c) => /* @__PURE__ */ e.jsx(
          "div",
          {
            style: {
              width: d ? `${c.count / o * 100}%` : "0%",
              backgroundColor: c.color,
              transition: "width 600ms ease-out"
            }
          },
          c.label
        )) }),
        /* @__PURE__ */ e.jsx("div", { className: "flex flex-col gap-1.5", children: s.map((c) => /* @__PURE__ */ e.jsxs(
          "div",
          {
            className: "flex items-center justify-between text-xs",
            children: [
              /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ e.jsx(
                  "div",
                  {
                    className: "size-2.5 rounded-full",
                    style: { backgroundColor: c.color }
                  }
                ),
                /* @__PURE__ */ e.jsx("span", { children: A.convertEnumToHumanReadable(c.label) })
              ] }),
              /* @__PURE__ */ e.jsx("span", { className: "font-medium tabular-nums", children: A.formatNumberCompact(c.count) })
            ]
          },
          c.label
        )) })
      ] })
    ] }) })
  ] });
}
const zs = () => {
  const [s, o] = Ie(), [i, g] = j.useState([]), [n, d] = j.useState(!1), [r, v] = j.useState(/* @__PURE__ */ new Set()), c = b.getProjectId(), [a, u] = j.useState([]), [m, N] = j.useState([]), [S, R] = j.useState(!1), [w, re] = j.useState(null), [V, Ce] = j.useState(
    () => s.has("createdAfter")
  );
  j.useEffect(() => {
    if (V) return;
    const l = ms(me);
    o(
      (f) => {
        const x = new URLSearchParams(f);
        return x.has("createdAfter") || (x.set("createdAfter", l.from.toISOString()), x.set("createdBefore", l.to.toISOString())), x;
      },
      { replace: !0 }
    ), Ce(!0);
  }, [V, o]);
  const { data: le, isLoading: De, refetch: K } = gs({
    queryKey: ["flow-run-table", s.toString(), c],
    enabled: V,
    staleTime: 0,
    gcTime: 0,
    meta: { showErrorDialog: !0, loadSubsetOptions: {} },
    queryFn: () => {
      const l = s.getAll("status"), f = s.getAll("flowId"), x = s.get(Ss), p = s.getAll(_), h = s.get("failedStepName") || void 0, I = s.get("failedStepMessage") || void 0, k = s.get(U) ? parseInt(s.get(U)) : 10, $e = s.get("createdAfter"), Ue = s.get("createdBefore"), Oe = s.get("archivedAt");
      return Rs.list({
        status: l ?? void 0,
        projectId: c,
        flowId: f,
        cursor: x ?? void 0,
        limit: k,
        includeArchived: Oe === "true",
        createdAfter: $e ?? void 0,
        createdBefore: Ue ?? void 0,
        failedStepName: h,
        failedStepMessage: I,
        flowRunIds: p
      });
    },
    refetchInterval: (l) => {
      var p;
      const f = (p = l.state.data) == null ? void 0 : p.data, x = f == null ? void 0 : f.filter(
        (h) => !Ns({
          status: h.status,
          ignoreInternalError: !1
        })
      );
      return x != null && x.length ? 15 * 1e3 : !1;
    }
  }), P = ne(), Pe = Cs({
    data: le,
    selectedRows: i,
    setSelectedRows: g,
    selectedAll: n,
    setSelectedAll: d,
    excludedRows: r,
    setExcludedRows: v,
    onViewError: re,
    onViewRun: (l) => P(
      b.appendProjectRoutePrefix(`/runs/${l.id}`)
    )
  }), { data: Q, isFetching: Ee } = Te.useFlows({
    limit: 1e3,
    cursor: void 0
  }), oe = we(), z = Q == null ? void 0 : Q.data, { checkAccess: Me } = fs(), y = Me(hs.WRITE_RUN), _e = j.useMemo(
    () => [
      {
        type: "select",
        title: t("Flow name"),
        accessorKey: "flowId",
        options: (z == null ? void 0 : z.map((l) => ({
          label: l.version.displayName,
          value: l.id
        }))) || [],
        icon: q
      },
      {
        type: "select",
        title: t("Status"),
        accessorKey: "status",
        options: Object.values(M).map((l) => ({
          label: A.convertEnumToHumanReadable(l),
          value: l,
          icon: L.getStatusIcon(l).Icon
        })),
        icon: q
      },
      {
        type: "input",
        title: t("Error message"),
        accessorKey: "failedStepMessage",
        icon: xs
      },
      {
        type: "date",
        title: t("Created"),
        accessorKey: "created",
        icon: q,
        defaultPresetName: me
      },
      {
        type: "checkbox",
        title: t("Show archived"),
        accessorKey: "archivedAt"
      }
    ],
    [z]
  ), $ = J.useBulkRetryRuns({
    onSuccess: (l) => {
      const f = l.map((p) => p.id);
      u(f);
      const x = s.get(_);
      K(), x && (P(b.appendProjectRoutePrefix("/runs")), o({
        [_]: f,
        [U]: f.length.toString()
      }));
    },
    onPartialFailure: (l) => {
      N(l), ps.error(
        t("{count} run(s) failed to retry", { count: l.length }),
        {
          action: {
            label: t("More"),
            onClick: () => R(!0)
          },
          duration: 15e3,
          closeButton: !0,
          dismissible: !0
        }
      );
    }
  }), H = J.useBulkCancelRuns({
    onSuccess: () => {
      K(), g([]), d(!1), v(/* @__PURE__ */ new Set());
    }
  }), W = J.useBulkArchiveRuns({
    onSuccess: () => {
      K();
    }
  }), Fe = j.useMemo(
    () => [
      {
        render: (l, f) => {
          const x = i.length === 0 || !y;
          return /* @__PURE__ */ e.jsx("div", { onClick: (p) => p.stopPropagation(), children: /* @__PURE__ */ e.jsxs(
            T,
            {
              disabled: x,
              variant: "ghost",
              size: "sm",
              loading: W.isPending,
              onClick: () => {
                const p = i.map((h) => h.id);
                W.mutate({
                  projectId: c,
                  flowRunIds: n ? void 0 : p,
                  excludeFlowRunIds: n ? Array.from(r) : void 0,
                  status: s.getAll("status").length > 0 ? s.getAll("status") : void 0,
                  flowId: s.getAll("flowId"),
                  createdAfter: s.get("createdAfter") || void 0,
                  createdBefore: s.get("createdBefore") || void 0,
                  failedStepName: s.get("failedStepName") || void 0,
                  failedStepMessage: s.get("failedStepMessage") || void 0
                }), f(), g([]);
              },
              children: [
                /* @__PURE__ */ e.jsx(ke, { className: "size-4 mr-1" }),
                i.length > 0 ? `${t("Archive")} ${x ? "" : n ? r.size > 0 ? `${t("all except")} ${r.size}` : t("all") : `(${i.length})`}` : t("Archive")
              ]
            }
          ) });
        }
      },
      {
        render: (l, f) => {
          const x = i.every(
            (h) => h.status === M.PAUSED || h.status === M.QUEUED
          ), p = i.length === 0 || !y || !x;
          return /* @__PURE__ */ e.jsx("div", { onClick: (h) => h.stopPropagation(), children: /* @__PURE__ */ e.jsx(
            G,
            {
              hasPermission: y,
              children: /* @__PURE__ */ e.jsx(
                ge,
                {
                  message: t("Only paused or queued runs can be cancelled"),
                  isDisabled: x,
                  children: /* @__PURE__ */ e.jsxs(
                    T,
                    {
                      disabled: p,
                      variant: "ghost",
                      size: "sm",
                      loading: H.isPending,
                      onClick: () => {
                        const h = i.map((k) => k.id), I = s.getAll(
                          "status"
                        );
                        H.mutate({
                          projectId: c,
                          flowRunIds: n ? void 0 : h,
                          excludeFlowRunIds: n ? Array.from(r) : void 0,
                          status: I.length > 0 ? I.filter(
                            (k) => k === M.PAUSED || k === M.QUEUED
                          ) : void 0,
                          flowId: s.getAll("flowId"),
                          createdAfter: s.get("createdAfter") || void 0,
                          createdBefore: s.get("createdBefore") || void 0
                        }), f();
                      },
                      children: [
                        /* @__PURE__ */ e.jsx(fe, { className: "h-3 w-4 mr-1" }),
                        i.length > 0 ? `${t("Cancel")} ${n ? r.size > 0 ? `${t("all except")} ${r.size}` : t("all") : `(${i.length})`}` : t("Cancel")
                      ]
                    }
                  )
                }
              )
            }
          ) });
        }
      },
      {
        render: (l, f) => {
          const x = i.every(
            (h) => he(h.status)
          ), p = i.length === 0 || !y;
          return /* @__PURE__ */ e.jsx("div", { onClick: (h) => h.stopPropagation(), children: /* @__PURE__ */ e.jsx(
            G,
            {
              hasPermission: y,
              children: /* @__PURE__ */ e.jsxs(ve, { modal: !1, children: [
                /* @__PURE__ */ e.jsx(Ne, { asChild: !0, disabled: p, children: /* @__PURE__ */ e.jsxs(
                  T,
                  {
                    disabled: p,
                    variant: "ghost",
                    size: "sm",
                    loading: $.isPending,
                    children: [
                      /* @__PURE__ */ e.jsx(pe, { className: "size-4 mr-1" }),
                      i.length > 0 ? `${t("Retry")} ${p ? "" : n ? r.size > 0 ? `${t("all except")} ${r.size}` : t("all") : `(${i.length})`}` : t("Retry"),
                      /* @__PURE__ */ e.jsx(Se, { className: "h-3 w-4 ml-1" })
                    ]
                  }
                ) }),
                /* @__PURE__ */ e.jsxs(Re, { children: [
                  /* @__PURE__ */ e.jsx(
                    G,
                    {
                      hasPermission: y,
                      children: /* @__PURE__ */ e.jsx(
                        O,
                        {
                          disabled: !y,
                          onClick: () => {
                            const h = i.map((I) => I.id);
                            $.mutate({
                              projectId: c,
                              flowRunIds: n ? void 0 : h,
                              strategy: xe.ON_LATEST_VERSION,
                              excludeFlowRunIds: n ? Array.from(r) : void 0,
                              status: s.getAll(
                                "status"
                              ),
                              flowId: s.getAll("flowId"),
                              createdAfter: s.get("createdAfter") || void 0,
                              createdBefore: s.get("createdBefore") || void 0,
                              failedStepName: s.get("failedStepName") || void 0,
                              failedStepMessage: s.get("failedStepMessage") || void 0
                            }), f(), g([]);
                          },
                          className: "cursor-pointer",
                          children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row gap-2 items-center", children: [
                            /* @__PURE__ */ e.jsx(pe, { className: "h-4 w-4" }),
                            /* @__PURE__ */ e.jsx("span", { children: t("on latest version") })
                          ] })
                        }
                      )
                    }
                  ),
                  i.some((h) => he(h.status)) && /* @__PURE__ */ e.jsx(
                    ge,
                    {
                      message: t(
                        "Only failed runs can be retried from failed step"
                      ),
                      isDisabled: !x,
                      children: /* @__PURE__ */ e.jsx(
                        O,
                        {
                          disabled: !y || !x,
                          onClick: () => {
                            const h = i.map((I) => I.id);
                            $.mutate({
                              projectId: c,
                              flowRunIds: n ? void 0 : h,
                              strategy: xe.FROM_FAILED_STEP,
                              excludeFlowRunIds: n ? Array.from(r) : void 0,
                              status: s.getAll(
                                "status"
                              ),
                              flowId: s.getAll("flowId"),
                              createdAfter: s.get("createdAfter") || void 0,
                              createdBefore: s.get("createdBefore") || void 0,
                              failedStepName: s.get("failedStepName") || void 0,
                              failedStepMessage: s.get("failedStepMessage") || void 0
                            }), f(), g([]), d(!1), v(/* @__PURE__ */ new Set());
                          },
                          className: "cursor-pointer",
                          children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row gap-2 items-center", children: [
                            /* @__PURE__ */ e.jsx(Is, { className: "h-4 w-4" }),
                            /* @__PURE__ */ e.jsx("span", { children: t("from failed step") })
                          ] })
                        }
                      )
                    }
                  )
                ] })
              ] })
            }
          ) });
        }
      }
    ],
    [
      $,
      W,
      y,
      i,
      n,
      r,
      H
    ]
  ), ze = j.useCallback(
    (l, f) => {
      f ? oe(
        b.appendProjectRoutePrefix(`/runs/${l.id}`)
      ) : P(
        b.appendProjectRoutePrefix(`/runs/${l.id}`)
      );
    },
    [P, oe]
  ), Y = s.getAll(_), ce = Y.length > 0 ? [
    /* @__PURE__ */ e.jsx(
      T,
      {
        variant: "outline",
        onClick: () => {
          o({}), P(b.appendProjectRoutePrefix("/runs"));
        },
        children: /* @__PURE__ */ e.jsxs("div", { className: "flex flex-row gap-2 items-center", children: [
          t("Viewing retried runs"),
          " (",
          Y.length,
          ")",
          " ",
          /* @__PURE__ */ e.jsx(fe, { className: "size-4" })
        ] })
      },
      "retried-runs-filter"
    )
  ] : [];
  return /* @__PURE__ */ e.jsxs("div", { className: "relative", children: [
    /* @__PURE__ */ e.jsx(
      js,
      {
        emptyStateTextTitle: t("No flow runs found"),
        emptyStateTextDescription: t(
          "Come back later when your automations start running"
        ),
        emptyStateIcon: /* @__PURE__ */ e.jsx(vs, { className: "size-14" }),
        columns: Pe,
        page: le,
        isLoading: De || Ee,
        filters: ce.length > 0 ? [] : _e,
        bulkActions: Fe,
        onRowClick: (l, f) => ze(l, f),
        customFilters: ce,
        toolbarButtons: [/* @__PURE__ */ e.jsx(Fs, {}, "status-chart")],
        hidePagination: Y.length > 0
      }
    ),
    /* @__PURE__ */ e.jsx(
      Ms,
      {
        retriedRunsIds: a,
        clearRetriedRuns: () => u([])
      }
    ),
    /* @__PURE__ */ e.jsx(
      Ds,
      {
        open: S,
        onOpenChange: R,
        failedRuns: m
      }
    ),
    /* @__PURE__ */ e.jsx(
      Ps,
      {
        run: w,
        open: w !== null,
        onOpenChange: (l) => {
          l || re(null);
        }
      }
    )
  ] });
}, Os = () => /* @__PURE__ */ e.jsx(zs, {});
export {
  Os as RunsPage
};
