import { ae as t, j as c, af as r } from "./mount-builder-CqIEWsZv.mjs";
const l = ({
  pieceName: o,
  size: s = "md",
  border: a = !0,
  showTooltip: i = !0
}) => {
  const { summary: e } = t.usePieceSummary({ name: o });
  return /* @__PURE__ */ c.jsx(
    r,
    {
      size: s,
      border: a,
      displayName: e == null ? void 0 : e.displayName,
      logoUrl: e == null ? void 0 : e.logoUrl,
      showTooltip: i
    }
  );
};
export {
  l as P
};
