import { o as y, B as D, N as h, jd as M, di as O, s as l, j as e, bs as P, bt as R, ao as k, g as j, c0 as B, c1 as T, b6 as _, e as L, G as q, cP as z, aJ as G, a6 as a, je as x, c2 as H, bu as X, bv as $, bw as J, c3 as b, c4 as v, c5 as f, c9 as g, aX as w, c8 as E, i as d, ey as U, d9 as W, by as Z, gO as K, f as N } from "./mount-builder-CqIEWsZv.mjs";
const Q = /^[a-zA-Z0-9_]+$/;
y({
  ...D,
  name: l(),
  projectId: l(),
  platformId: l(),
  ownerId: h(l()),
  owner: h(O),
  metadata: h(M)
}).describe("A project-scoped encrypted variable that flows can reference via {{variables['NAME']}}.");
const Y = y({
  name: l().min(1, N.required).regex(Q, "invalidVariableName"),
  value: l().optional()
});
function se(u) {
  const { open: t, onOpenChange: i, existing: o, onSaved: r } = u;
  return /* @__PURE__ */ e.jsx(P, { open: t, onOpenChange: i, children: /* @__PURE__ */ e.jsx(R, { className: "max-w-md", children: /* @__PURE__ */ e.jsx(
    ee,
    {
      existing: o,
      onOpenChange: i,
      onSaved: r
    },
    t ? `${(o == null ? void 0 : o.id) ?? "new"}-open` : "closed"
  ) }) });
}
function ee(u) {
  const { existing: t, onOpenChange: i, onSaved: o } = u, r = !!t, p = k.getProjectId(), [m, V] = j.useState(!1), [c, C] = j.useState(!r), n = B({
    resolver: T(Y),
    mode: "onChange",
    defaultValues: {
      name: (t == null ? void 0 : t.name) ?? "",
      value: ""
    }
  }), { mutate: F, isPending: S } = _({
    mutationFn: async (s) => {
      if (!p)
        throw new Error("No project");
      return t ? x.update(t.id, { value: s.value }) : x.create({
        projectId: p,
        name: s.name,
        value: s.value ?? ""
      });
    },
    onSuccess: (s) => {
      G.success(r ? a("Variable updated") : a("Variable created")), o == null || o(s), i(!1);
    },
    onError: (s) => {
      if (L.isApError(s, q.VALIDATION)) {
        n.setError("name", {
          type: "manual",
          message: "Variable name already used"
        });
        return;
      }
      z();
    }
  }), I = (s) => {
    if (!s.value) {
      n.setError("value", { type: "manual", message: N.required });
      return;
    }
    F(s);
  };
  return /* @__PURE__ */ e.jsx(H, { ...n, children: /* @__PURE__ */ e.jsxs(
    "form",
    {
      className: "flex flex-col gap-4",
      onSubmit: n.handleSubmit(I),
      children: [
        /* @__PURE__ */ e.jsxs(X, { children: [
          /* @__PURE__ */ e.jsx($, { children: r ? a("Edit variable") : a("New variable") }),
          /* @__PURE__ */ e.jsx(J, { children: a(
            "Store an API key, token, or other value you can reuse across flow steps without exposing it."
          ) })
        ] }),
        /* @__PURE__ */ e.jsx(
          b,
          {
            control: n.control,
            name: "name",
            render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { children: [
              /* @__PURE__ */ e.jsx(f, { children: a("Name") }),
              /* @__PURE__ */ e.jsx(g, { children: /* @__PURE__ */ e.jsx(w, { ...s, disabled: r, placeholder: "STRIPE_PROD" }) }),
              /* @__PURE__ */ e.jsx(E, {})
            ] })
          }
        ),
        (!r || c) && /* @__PURE__ */ e.jsx(
          b,
          {
            control: n.control,
            name: "value",
            render: ({ field: s }) => /* @__PURE__ */ e.jsxs(v, { children: [
              /* @__PURE__ */ e.jsx(f, { children: a("Value") }),
              /* @__PURE__ */ e.jsx(g, { children: /* @__PURE__ */ e.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ e.jsx(
                  w,
                  {
                    ...s,
                    type: m ? "text" : "password",
                    autoComplete: "new-password",
                    className: "pr-10",
                    placeholder: r ? a("Enter new value") : a("Enter the value")
                  }
                ),
                /* @__PURE__ */ e.jsx(
                  d,
                  {
                    type: "button",
                    variant: "ghost",
                    size: "sm",
                    className: "absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 p-0",
                    onClick: () => V((A) => !A),
                    "aria-label": m ? a("Hide value") : a("Show value"),
                    children: m ? /* @__PURE__ */ e.jsx(U, { className: "h-4 w-4" }) : /* @__PURE__ */ e.jsx(W, { className: "h-4 w-4" })
                  }
                )
              ] }) }),
              /* @__PURE__ */ e.jsx(E, {})
            ] })
          }
        ),
        r && !c && /* @__PURE__ */ e.jsx(
          d,
          {
            type: "button",
            variant: "outline",
            className: "w-full",
            onClick: () => C(!0),
            children: a("Rotate value")
          }
        ),
        /* @__PURE__ */ e.jsxs(Z, { children: [
          /* @__PURE__ */ e.jsx(K, { asChild: !0, children: /* @__PURE__ */ e.jsx(d, { type: "button", variant: "outline", children: r && !c ? a("Close") : a("Cancel") }) }),
          (!r || c) && /* @__PURE__ */ e.jsx(d, { type: "submit", loading: S, children: r ? a("Save new value") : a("Create") })
        ] })
      ]
    }
  ) });
}
export {
  se as V
};
