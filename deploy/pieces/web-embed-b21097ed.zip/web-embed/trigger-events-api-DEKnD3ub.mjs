import { e } from "./mount-builder-CqIEWsZv.mjs";
const s = {
  test(t) {
    return e.post(
      "/v1/test-trigger",
      t
    );
  },
  list(t) {
    return e.get(
      "/v1/trigger-events",
      t
    );
  },
  saveTriggerMockdata(t) {
    return e.post("/v1/trigger-events", t);
  }
};
export {
  s as t
};
