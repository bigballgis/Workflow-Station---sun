import { c as I, g as r, cO as v, eq as A, I as R, cN as E, d6 as g, d5 as k, cQ as w, er as G, j as e, cb as z, i as _, cc as L, a6 as s, es as M, cj as O, ck as U, bC as H, co as K, ai as F, a9 as B, Y as Q, ak as W, D as x, cp as d, cq as Y, et as q, dI as V, dJ as $, cY as J, aa as X, eu as Z, ev as ee } from "./mount-builder-CqIEWsZv.mjs";
import { D as te } from "./dashboard-page-header-BfLKPs1b.mjs";
import { N as se, R as oe } from "./reconnect-button-dialog-J6RLSNjF.mjs";
import { C as ae } from "./copy-text-tooltip-CjpUgg8T.mjs";
import { P as ne } from "./piece-icon-from-name-CkNp4shA.mjs";
/**
 * @license lucide-react v0.576.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const ce = [
  [
    "path",
    {
      d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
      key: "usdka0"
    }
  ]
], ie = I("folder-open", ce), h = "status", le = [
  {
    type: "input",
    title: s("Search"),
    accessorKey: "displayName",
    icon: F
  },
  {
    type: "select",
    title: s("Status"),
    accessorKey: h,
    options: Object.values(W).map((a) => ({
      label: x.convertEnumToReadable(a),
      value: a
    })),
    icon: B
  }
], ge = () => {
  const [a, C] = r.useState(0), [c, m] = r.useState([]), { checkAccess: j } = v(), u = A(), { platform: b } = R.useCurrentPlatform(), N = [
    {
      accessorKey: "displayName",
      size: 260,
      header: ({ column: t }) => /* @__PURE__ */ e.jsx(
        d,
        {
          column: t,
          title: s("Name"),
          icon: Y
        }
      ),
      cell: ({ row: t }) => /* @__PURE__ */ e.jsx(
        ae,
        {
          title: s("External ID"),
          text: t.original.externalId || "",
          children: /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 w-fit", children: [
            /* @__PURE__ */ e.jsx(
              ne,
              {
                pieceName: t.original.pieceName,
                showTooltip: !1,
                size: "sm"
              }
            ),
            /* @__PURE__ */ e.jsx("span", { children: t.original.displayName })
          ] })
        }
      )
    },
    {
      accessorKey: "status",
      size: 120,
      header: ({ column: t }) => /* @__PURE__ */ e.jsx(
        d,
        {
          column: t,
          title: s("Status"),
          icon: $
        }
      ),
      cell: ({ row: t }) => {
        const l = t.original.status, { variant: o, icon: S } = q.getStatusIcon(l);
        return /* @__PURE__ */ e.jsx("div", { className: "text-left", children: /* @__PURE__ */ e.jsx(
          V,
          {
            icon: S,
            text: x.convertEnumToReadable(l),
            variant: o
          }
        ) });
      }
    },
    {
      accessorKey: "updated",
      size: 150,
      header: ({ column: t }) => /* @__PURE__ */ e.jsx(
        d,
        {
          column: t,
          title: s("Connected At"),
          icon: X
        }
      ),
      cell: ({ row: t }) => /* @__PURE__ */ e.jsx(
        J,
        {
          date: new Date(t.original.updated),
          className: "text-left"
        }
      )
    },
    {
      accessorKey: "projectsCount",
      size: 100,
      header: ({ column: t }) => /* @__PURE__ */ e.jsx(
        d,
        {
          column: t,
          title: s("Projects"),
          icon: ie
        }
      ),
      cell: ({ row: t }) => /* @__PURE__ */ e.jsx("div", { className: "text-left", children: t.original.projectIds.length })
    },
    {
      id: "actions",
      cell: ({ row: t }) => /* @__PURE__ */ e.jsxs("div", { className: "flex items-center gap-2 justify-end", children: [
        t.original.preSelectForNewProjects && /* @__PURE__ */ e.jsx(Z, {}),
        /* @__PURE__ */ e.jsx(
          ee,
          {
            connectionId: t.original.id,
            currentName: t.original.displayName,
            projectIds: t.original.projectIds,
            preSelectForNewProjects: t.original.preSelectForNewProjects ?? !1,
            userHasPermissionToEdit: !0,
            onEdit: () => {
              i();
            }
          }
        ),
        /* @__PURE__ */ e.jsx(
          oe,
          {
            connection: t.original,
            onConnectionCreated: () => {
              i();
            },
            hasPermission: !0
          }
        )
      ] })
    }
  ], n = new URLSearchParams(u.search), {
    data: f,
    isLoading: y,
    refetch: i
  } = E.useGlobalConnections({
    request: {
      displayName: n.get("displayName") ?? void 0,
      cursor: n.get(k) ?? void 0,
      limit: n.get(g) ? parseInt(n.get(g)) : 10,
      status: n.getAll(h) ?? []
    },
    extraKeys: [u.search],
    staleTime: 0,
    gcTime: 0,
    showErrorDialog: !0
  }), T = j(
    w.WRITE_APP_CONNECTION
  ), p = G.useBulkDeleteGlobalConnections(
    i
  ), D = r.useMemo(
    () => [
      {
        render: (t, l) => /* @__PURE__ */ e.jsx("div", { onClick: (o) => o.stopPropagation(), children: /* @__PURE__ */ e.jsx(
          z,
          {
            title: s("Delete Connections"),
            message: s(
              "The selected connections will be permanently deleted."
            ),
            warning: /* @__PURE__ */ e.jsx(M, {}),
            entityName: "connections",
            buttonText: s("Delete"),
            mutationFn: async () => {
              try {
                await p.mutateAsync(
                  c.map((o) => o.id)
                ), l(), m([]);
              } catch (o) {
                console.error("Error deleting connections:", o);
              }
            },
            children: c.length > 0 && /* @__PURE__ */ e.jsxs(
              _,
              {
                variant: "ghost",
                size: "sm",
                className: "text-destructive hover:text-destructive",
                disabled: !T,
                children: [
                  /* @__PURE__ */ e.jsx(L, { className: "mr-1 w-4" }),
                  `${s("Delete")} (${c.length})`
                ]
              }
            )
          }
        ) })
      }
    ],
    [p, c]
  ), P = r.useMemo(
    () => [
      /* @__PURE__ */ e.jsx(
        se,
        {
          isGlobalConnection: !0,
          onConnectionCreated: () => {
            C(a + 1), i();
          },
          children: /* @__PURE__ */ e.jsx(O, { icon: U, iconSize: 16, size: "sm", children: s("New Connection") })
        },
        "new-connection"
      )
    ],
    [a]
  );
  return /* @__PURE__ */ e.jsx("div", { className: "flex-col w-full", children: /* @__PURE__ */ e.jsxs(
    H,
    {
      featureKey: "GLOBAL_CONNECTIONS",
      locked: !b.plan.globalConnectionsEnabled,
      lockTitle: s("Enable Global Connections"),
      lockDescription: s(
        "Manage platform-wide connections to external systems."
      ),
      lockVideoUrl: "/ap-cdn/videos/showcase/global-connections.mp4",
      children: [
        /* @__PURE__ */ e.jsx(
          te,
          {
            description: s(
              "Manage platform-wide connections to external systems."
            ),
            title: s("Global Connections")
          }
        ),
        /* @__PURE__ */ e.jsx(
          K,
          {
            emptyStateTextTitle: s("No global connections found"),
            emptyStateTextDescription: s(
              "Create a global connection that can be shared to multiple projects"
            ),
            emptyStateIcon: /* @__PURE__ */ e.jsx(Q, { className: "size-14" }),
            columns: N,
            page: f,
            isLoading: y,
            filters: le,
            selectColumn: !0,
            onSelectedRowsChange: m,
            bulkActions: D,
            toolbarButtons: P
          }
        )
      ]
    }
  ) });
};
export {
  ge as GlobalConnectionsTable
};
