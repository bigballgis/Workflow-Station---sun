import { TriggerStrategy } from '@activepieces/pieces-framework';
declare enum AuthType {
    NONE = "none",
    BASIC = "basic",
    HEADER = "header"
}
export declare const catchWebhook: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    liveMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    syncMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    testMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    authType: import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, true>;
    authFields: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    liveMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    syncMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    testMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    authType: import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, true>;
    authFields: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    liveMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    syncMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    testMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    authType: import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, true>;
    authFields: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    liveMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    syncMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    testMarkdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    authType: import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, true>;
    authFields: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}>;
export {};
