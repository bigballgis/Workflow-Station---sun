declare enum ResponseType {
    JSON = "json",
    RAW = "raw",
    REDIRECT = "redirect"
}
export declare const returnResponseAndWaitForNextWebhook: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    markdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    responseType: import("@activepieces/pieces-framework").StaticDropdownProperty<ResponseType, false>;
    fields: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
}>;
export {};
