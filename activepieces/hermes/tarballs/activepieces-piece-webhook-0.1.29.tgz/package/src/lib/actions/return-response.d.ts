declare enum ResponseType {
    JSON = "json",
    RAW = "raw",
    REDIRECT = "redirect"
}
declare enum FlowExecution {
    STOP = "stop",
    RESPOND = "respond"
}
export declare const returnResponse: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    responseType: import("@activepieces/pieces-framework").StaticDropdownProperty<ResponseType, false>;
    fields: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
    respond: import("@activepieces/pieces-framework").StaticDropdownProperty<FlowExecution, false>;
}>;
export {};
