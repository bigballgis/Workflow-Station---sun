export declare const webhook: import("@activepieces/pieces-framework").Piece<undefined>;
