"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.webhook = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const catch_hook_1 = require("./lib/triggers/catch-hook");
const shared_1 = require("@activepieces/shared");
const return_response_1 = require("./lib/actions/return-response");
const return_response_and_wait_for_next_webhook_1 = require("./lib/actions/return-response-and-wait-for-next-webhook");
exports.webhook = (0, pieces_framework_1.createPiece)({
    displayName: 'Webhook',
    description: 'Receive HTTP requests and trigger flows using unique URLs.',
    auth: pieces_framework_1.PieceAuth.None(),
    categories: [shared_1.PieceCategory.CORE],
    minimumSupportedRelease: '0.52.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/webhooks.svg',
    authors: ['abuaboud', 'pfernandez98', 'kishanprmr', 'AbdulTheActivePiecer'],
    actions: [return_response_1.returnResponse, return_response_and_wait_for_next_webhook_1.returnResponseAndWaitForNextWebhook],
    triggers: [catch_hook_1.catchWebhook],
});
//# sourceMappingURL=index.js.map