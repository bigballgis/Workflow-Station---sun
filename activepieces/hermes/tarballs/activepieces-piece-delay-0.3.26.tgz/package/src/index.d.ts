export declare const delay: import("@activepieces/pieces-framework").Piece<undefined>;
