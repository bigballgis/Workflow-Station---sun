declare enum TimeUnit {
    SECONDS = "seconds",
    MINUTES = "minutes",
    HOURS = "hours",
    DAYS = "days"
}
export declare const delayForAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    markdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    unit: import("@activepieces/pieces-framework").StaticDropdownProperty<TimeUnit, true>;
    delayFor: import("@activepieces/pieces-framework").NumberProperty<true>;
}>;
export {};
