export declare const delayUntilAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    markdown: import("dist/packages/pieces/community/framework/src/lib/property/input/markdown-property").MarkDownProperty;
    delayUntilTimestamp: import("@activepieces/pieces-framework").DateTimeProperty<true>;
}>;
