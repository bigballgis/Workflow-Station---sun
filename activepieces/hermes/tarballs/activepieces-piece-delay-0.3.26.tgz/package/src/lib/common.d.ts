export declare const markdownDescription = "\n**Note:** The maximum duration per step is {{pausedFlowTimeoutDays}} days.\n";
