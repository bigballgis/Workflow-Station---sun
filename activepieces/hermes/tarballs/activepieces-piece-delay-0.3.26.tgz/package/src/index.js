"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.delay = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const delay_for_action_1 = require("./lib/actions/delay-for-action");
const delay_until_action_1 = require("./lib/actions/delay-until-action");
exports.delay = (0, pieces_framework_1.createPiece)({
    displayName: 'Delay',
    description: 'Use it to delay the execution of the next action',
    minimumSupportedRelease: '0.36.1',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/delay.svg',
    authors: ["Nilesh", "kishanprmr", "MoShizzle", "AbdulTheActivePiecer", "khaledmashaly", "abuaboud"],
    categories: [shared_1.PieceCategory.CORE, shared_1.PieceCategory.FLOW_CONTROL],
    auth: pieces_framework_1.PieceAuth.None(),
    actions: [
        delay_for_action_1.delayForAction, // Delay for a fixed duration
        delay_until_action_1.delayUntilAction, // Takes a timestamp parameter instead of duration
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map