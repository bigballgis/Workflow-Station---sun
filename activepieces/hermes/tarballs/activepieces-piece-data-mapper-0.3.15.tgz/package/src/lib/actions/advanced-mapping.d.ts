export declare const advancedMapping: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    mapping: import("@activepieces/pieces-framework").JsonProperty<true>;
}>;
