"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dataMapper = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const advanced_mapping_1 = require("./lib/actions/advanced-mapping");
exports.dataMapper = (0, pieces_framework_1.createPiece)({
    displayName: 'Data Mapper',
    description: 'tools to manipulate data structure',
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/data-mapper.svg',
    auth: pieces_framework_1.PieceAuth.None(),
    categories: [shared_1.PieceCategory.CORE],
    authors: ["kishanprmr", "MoShizzle", "AbdulTheActivePiecer", "khaledmashaly", "abuaboud"],
    actions: [advanced_mapping_1.advancedMapping],
    triggers: [],
});
//# sourceMappingURL=index.js.map