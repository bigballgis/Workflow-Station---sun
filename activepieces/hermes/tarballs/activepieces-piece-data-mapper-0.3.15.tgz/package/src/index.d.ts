export declare const dataMapper: import("@activepieces/pieces-framework").Piece<undefined>;
