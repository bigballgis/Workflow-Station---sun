export declare const textHelper: import("@activepieces/pieces-framework").Piece<undefined>;
//# sourceMappingURL=index.d.ts.map