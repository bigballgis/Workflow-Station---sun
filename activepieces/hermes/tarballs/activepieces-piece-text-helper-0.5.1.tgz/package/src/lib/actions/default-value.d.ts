export declare const defaultValue: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    value: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    defaultString: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=default-value.d.ts.map