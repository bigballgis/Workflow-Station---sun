export declare const slugifyAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    text: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=slugify.d.ts.map