export declare const htmlToMarkdown: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    html: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=html-to-markdown.d.ts.map