export declare const stripHtmlContent: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    html: import("@activepieces/pieces-framework").LongTextProperty<true>;
}>;
//# sourceMappingURL=strip-html.d.ts.map