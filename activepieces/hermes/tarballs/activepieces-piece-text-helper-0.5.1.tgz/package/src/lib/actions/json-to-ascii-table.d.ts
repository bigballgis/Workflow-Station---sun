export declare const jsonToAsciiTable: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    data: import("@activepieces/pieces-framework").JsonProperty<true>;
}>;
//# sourceMappingURL=json-to-ascii-table.d.ts.map