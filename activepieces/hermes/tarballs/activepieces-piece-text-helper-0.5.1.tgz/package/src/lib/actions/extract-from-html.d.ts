export declare const extractFromHtml: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    html: import("@activepieces/pieces-framework").LongTextProperty<true>;
    target: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    selector: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    extractionType: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    attributeName: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    returnMultiple: import("@activepieces/pieces-framework").CheckboxProperty<true>;
}>;
//# sourceMappingURL=extract-from-html.d.ts.map