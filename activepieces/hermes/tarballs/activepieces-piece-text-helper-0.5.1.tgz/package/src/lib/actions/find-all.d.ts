export declare const findAll: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    text: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    expression: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    ignoreCase: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
//# sourceMappingURL=find-all.d.ts.map