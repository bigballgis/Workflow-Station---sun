"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.textHelper = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const concat_1 = require("./lib/actions/concat");
const find_1 = require("./lib/actions/find");
const find_all_1 = require("./lib/actions/find-all");
const html_to_markdown_1 = require("./lib/actions/html-to-markdown");
const markdown_to_html_1 = require("./lib/actions/markdown-to-html");
const replace_1 = require("./lib/actions/replace");
const split_1 = require("./lib/actions/split");
const strip_html_1 = require("./lib/actions/strip-html");
const slugify_1 = require("./lib/actions/slugify");
const default_value_1 = require("./lib/actions/default-value");
const json_to_ascii_table_1 = require("./lib/actions/json-to-ascii-table");
const extract_from_html_1 = require("./lib/actions/extract-from-html");
exports.textHelper = (0, pieces_framework_1.createPiece)({
    displayName: 'Text Helper',
    description: 'Tools for text processing',
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.36.1',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/text-helper.svg',
    authors: [
        'joeworkman',
        'kishanprmr',
        'MoShizzle',
        'AbdulTheActivePiecer',
        'abuaboud',
        'AdamSelene',
        'Anmol-Gup',
        'geekyme',
        'bertrandong',
        'onyedikachi-david',
    ],
    categories: [shared_1.PieceCategory.CORE],
    actions: [
        concat_1.concat,
        replace_1.replace,
        split_1.split,
        find_1.find,
        find_all_1.findAll,
        markdown_to_html_1.markdownToHTML,
        html_to_markdown_1.htmlToMarkdown,
        strip_html_1.stripHtmlContent,
        slugify_1.slugifyAction,
        default_value_1.defaultValue,
        json_to_ascii_table_1.jsonToAsciiTable,
        extract_from_html_1.extractFromHtml,
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map