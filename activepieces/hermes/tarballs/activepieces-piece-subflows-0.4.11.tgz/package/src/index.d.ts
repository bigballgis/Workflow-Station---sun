export declare const flows: import("@activepieces/pieces-framework").Piece<undefined>;
