"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.flows = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const call_flow_1 = require("./lib/actions/call-flow");
const callable_flow_1 = require("./lib/triggers/callable-flow");
const respond_1 = require("./lib/actions/respond");
const shared_1 = require("@activepieces/shared");
exports.flows = (0, pieces_framework_1.createPiece)({
    displayName: 'Sub Flows',
    description: 'Trigger and call another sub flow.',
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.67.1',
    categories: [shared_1.PieceCategory.CORE, shared_1.PieceCategory.FLOW_CONTROL],
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/subflows.svg',
    authors: ['hazemadelkhalel'],
    actions: [call_flow_1.callFlow, respond_1.response],
    triggers: [callable_flow_1.callableFlow],
});
//# sourceMappingURL=index.js.map