import { FlowStatus, FlowTriggerType, PopulatedFlow } from "@activepieces/shared";
import { FlowsContext, ListFlowsContextParams } from "@activepieces/pieces-framework";
export declare const callableFlowKey: (runId: string) => string;
export type CallableFlowRequest = {
    data: unknown;
    callbackUrl: string;
};
export type CallableFlowResponse = {
    status: 'success' | 'error';
    data: unknown;
};
export declare const MOCK_CALLBACK_IN_TEST_FLOW_URL = "MOCK";
export declare function listEnabledFlowsWithSubflowTrigger({ flowsContext, params, }: ListParams): Promise<{
    metadata?: {
        [x: string]: unknown;
    } | null | undefined;
    ownerId?: string | null | undefined;
    folderId?: string | null | undefined;
    publishedVersionId?: string | null | undefined;
    timeSavedPerRun?: number | null | undefined;
    templateId?: string | null | undefined;
    triggerSource?: {
        schedule?: {
            type: import("@activepieces/shared").TriggerSourceScheduleType.CRON_EXPRESSION;
            cronExpression: string;
            timezone: string;
        } | null | undefined;
    } | undefined;
    externalId: string;
    id: string;
    created: string;
    updated: string;
    projectId: string;
    status: FlowStatus;
    operationStatus: import("@activepieces/shared").FlowOperationStatus;
    version: {
        updatedBy?: string | null | undefined;
        schemaVersion?: string | null | undefined;
        backupFiles?: {
            [x: string]: string;
        } | null | undefined;
        id: string;
        created: string;
        updated: string;
        flowId: string;
        displayName: string;
        trigger: {
            nextAction?: any;
            displayName: string;
            valid: boolean;
            type: FlowTriggerType.PIECE;
            settings: {
                sampleData?: {
                    sampleDataFileId?: string | undefined;
                    sampleDataInputFileId?: string | undefined;
                    lastTestDate?: string | undefined;
                } | undefined;
                customLogoUrl?: string | undefined;
                triggerName?: string | undefined;
                propertySettings: {
                    [x: string]: {
                        schema?: any;
                        type: import("@activepieces/shared").PropertyExecutionType;
                    };
                };
                pieceName: string;
                pieceVersion: string;
                input: {
                    [x: string]: any;
                };
            };
            name: string;
        } | {
            nextAction?: any;
            displayName: string;
            valid: boolean;
            type: FlowTriggerType.EMPTY;
            settings: any;
            name: string;
        };
        valid: boolean;
        agentIds: string[];
        state: import("@activepieces/shared").FlowVersionState;
        connectionIds: string[];
        notes: {
            ownerId?: string | null | undefined;
            id: string;
            content: string;
            color: import("@activepieces/shared").NoteColorVariant;
            position: {
                x: number;
                y: number;
            };
            size: {
                width: number;
                height: number;
            };
            createdAt: string;
            updatedAt: string;
        }[];
    };
}[]>;
export declare function findFlowByExternalIdOrThrow({ flowsContext, externalId, }: {
    flowsContext: FlowsContext;
    externalId: string | undefined;
}): Promise<PopulatedFlow>;
type ListParams = {
    flowsContext: FlowsContext;
    params?: ListFlowsContextParams;
};
export {};
