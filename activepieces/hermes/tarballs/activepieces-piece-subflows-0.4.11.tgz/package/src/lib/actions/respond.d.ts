export declare const response: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    mode: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    response: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
}>;
