type FlowValue = {
    externalId: string;
    exampleData: unknown;
};
export declare const callFlow: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    flow: import("@activepieces/pieces-framework").DropdownProperty<FlowValue, false, undefined> | import("@activepieces/pieces-framework").DropdownProperty<FlowValue, true, undefined>;
    mode: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    flowProps: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
    waitForResponse: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
export {};
