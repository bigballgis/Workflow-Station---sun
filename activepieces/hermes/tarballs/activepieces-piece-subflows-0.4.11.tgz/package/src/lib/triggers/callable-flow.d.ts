import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const callableFlow: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    mode: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    exampleData: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    mode: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    exampleData: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    mode: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    exampleData: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").PieceAuthProperty | undefined, {
    mode: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    exampleData: import("@activepieces/pieces-framework").DynamicProperties<true, undefined>;
}>;
