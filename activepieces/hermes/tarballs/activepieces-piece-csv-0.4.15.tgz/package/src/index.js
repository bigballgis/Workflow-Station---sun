"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.csv = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const convert_csv_to_json_1 = require("./lib/actions/convert-csv-to-json");
const convert_json_to_csv_1 = require("./lib/actions/convert-json-to-csv");
const convert_excel_to_csv_1 = require("./lib/actions/convert-excel-to-csv");
exports.csv = (0, pieces_framework_1.createPiece)({
    displayName: 'CSV',
    description: 'Manipulate CSV text',
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/csv.svg',
    auth: pieces_framework_1.PieceAuth.None(),
    categories: [shared_1.PieceCategory.CORE],
    actions: [convert_csv_to_json_1.csvToJsonAction, convert_json_to_csv_1.jsonToCsvAction, convert_excel_to_csv_1.excelToCsvAction],
    authors: ["kishanprmr", "MoShizzle", "khaledmashaly", "abuaboud", 'sanket-a11y'],
    triggers: [],
});
//# sourceMappingURL=index.js.map