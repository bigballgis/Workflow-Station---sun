export declare const csvToJsonAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    csv_text: import("@activepieces/pieces-framework").LongTextProperty<true>;
    has_headers: import("@activepieces/pieces-framework").CheckboxProperty<true>;
    delimiter_type: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=convert-csv-to-json.d.ts.map