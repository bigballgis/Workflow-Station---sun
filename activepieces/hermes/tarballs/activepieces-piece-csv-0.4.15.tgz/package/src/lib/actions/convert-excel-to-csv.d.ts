export declare const excelToCsvAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    sheet_name: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    delimiter_type: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=convert-excel-to-csv.d.ts.map