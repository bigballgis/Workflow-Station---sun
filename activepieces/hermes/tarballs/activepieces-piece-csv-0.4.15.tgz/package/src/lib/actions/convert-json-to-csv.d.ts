export declare const jsonToCsvAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    markdown: import("@activepieces/pieces-framework/dist/src/lib/property/input/markdown-property").MarkDownProperty;
    json_array: import("@activepieces/pieces-framework").JsonProperty<true>;
    delimiter_type: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=convert-json-to-csv.d.ts.map