"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.http = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const send_http_request_action_1 = require("./lib/actions/send-http-request-action");
const parse_url_1 = require("./lib/actions/parse-url");
exports.http = (0, pieces_framework_1.createPiece)({
    displayName: 'HTTP',
    description: 'Sends HTTP requests and return responses',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/http.svg',
    categories: [shared_1.PieceCategory.CORE],
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.20.3',
    actions: [send_http_request_action_1.httpSendRequestAction, parse_url_1.parseUrl],
    authors: [
        'bibhuty-did-this',
        'landonmoir',
        'JanHolger',
        'Salem-Alaa',
        'kishanprmr',
        'AbdulTheActivePiecer',
        'khaledmashaly',
        'abuaboud',
        'pfernandez98',
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map