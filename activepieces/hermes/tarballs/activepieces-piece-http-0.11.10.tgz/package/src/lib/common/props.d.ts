import { HttpMethod } from '@activepieces/pieces-common';
export declare const httpMethodDropdown: import("@activepieces/pieces-framework").StaticDropdownProperty<HttpMethod, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<HttpMethod, true>;
//# sourceMappingURL=props.d.ts.map