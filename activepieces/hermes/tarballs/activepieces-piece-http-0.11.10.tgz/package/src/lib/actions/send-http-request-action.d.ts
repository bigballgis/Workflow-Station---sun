declare enum AuthType {
    NONE = "NONE",
    BASIC = "BASIC",
    BEARER_TOKEN = "BEARER_TOKEN"
}
export declare const httpSendRequestAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    method: import("@activepieces/pieces-framework").StaticDropdownProperty<import("@activepieces/pieces-common").HttpMethod, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<import("@activepieces/pieces-common").HttpMethod, true>;
    url: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    headers: import("@activepieces/pieces-framework").ObjectProperty<true>;
    queryParams: import("@activepieces/pieces-framework").ObjectProperty<true>;
    authType: import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, false> | import("@activepieces/pieces-framework").StaticDropdownProperty<AuthType, true>;
    authFields: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
    body_type: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
    body: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
    response_is_binary: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    use_proxy: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    proxy_settings: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
    timeout: import("@activepieces/pieces-framework").NumberProperty<false>;
    followRedirects: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    failureMode: import("@activepieces/pieces-framework").StaticDropdownProperty<string, false>;
}>;
export {};
//# sourceMappingURL=send-http-request-action.d.ts.map