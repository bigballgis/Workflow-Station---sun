export declare const parseUrl: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    url: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    returnArrays: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
//# sourceMappingURL=parse-url.d.ts.map