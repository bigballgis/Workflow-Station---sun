export declare const unzipFile: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    maxResults: import("@activepieces/pieces-framework").NumberProperty<false>;
    usePassword: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    passwordOptions: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}>;
//# sourceMappingURL=unzip-file.d.ts.map