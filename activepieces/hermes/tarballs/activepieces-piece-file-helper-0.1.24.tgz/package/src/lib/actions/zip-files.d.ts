export declare const zipFiles: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    files: import("@activepieces/pieces-framework").ArrayProperty<true> | import("@activepieces/pieces-framework").ArrayProperty<false>;
    outputFileName: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    usePassword: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    passwordOptions: import("@activepieces/pieces-framework").DynamicProperties<false, undefined>;
}>;
//# sourceMappingURL=zip-files.d.ts.map