export declare const createFile: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    content: import("@activepieces/pieces-framework").LongTextProperty<true>;
    fileName: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    encoding: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=create-file.d.ts.map