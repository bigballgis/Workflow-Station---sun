export declare const filesOutput: {
    Text: string;
    Base64: string;
};
export declare const readFileAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    readOptions: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=read-file.d.ts.map