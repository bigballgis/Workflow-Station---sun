export declare const checkFileType: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
    mimeTypes: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=check-file-type.d.ts.map