export declare const changeFileEncoding: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    inputFile: import("@activepieces/pieces-framework").FileProperty<true>;
    inputEncoding: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    outputFileName: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    outputEncoding: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
}>;
//# sourceMappingURL=change-file-encoding.d.ts.map