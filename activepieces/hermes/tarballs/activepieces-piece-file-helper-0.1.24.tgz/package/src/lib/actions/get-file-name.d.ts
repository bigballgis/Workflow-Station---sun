export declare const getFileName: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    file: import("@activepieces/pieces-framework").FileProperty<true>;
}>;
//# sourceMappingURL=get-file-name.d.ts.map