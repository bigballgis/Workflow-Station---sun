export declare const predefinedMimeTypes: {
    label: string;
    value: string;
}[];
//# sourceMappingURL=mimeTypes.d.ts.map