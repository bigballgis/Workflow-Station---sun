export declare const encodings: {
    value: string;
    label: string;
}[];
//# sourceMappingURL=encodings.d.ts.map