"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.filesHelper = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const read_file_1 = require("./lib/actions/read-file");
const create_file_1 = require("./lib/actions/create-file");
const change_file_encoding_1 = require("./lib/actions/change-file-encoding");
const check_file_type_1 = require("./lib/actions/check-file-type");
const zip_files_1 = require("./lib/actions/zip-files");
const unzip_file_1 = require("./lib/actions/unzip-file");
const get_file_name_1 = require("./lib/actions/get-file-name");
exports.filesHelper = (0, pieces_framework_1.createPiece)({
    displayName: 'Files Helper',
    description: 'Read file content and return it in different formats.',
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/new-core/file-helper.svg',
    categories: [shared_1.PieceCategory.CORE],
    authors: ['kishanprmr', 'MoShizzle', 'abuaboud', 'Seb-C', 'danielpoonwj'],
    actions: [
        read_file_1.readFileAction,
        create_file_1.createFile,
        change_file_encoding_1.changeFileEncoding,
        check_file_type_1.checkFileType,
        zip_files_1.zipFiles,
        unzip_file_1.unzipFile,
        get_file_name_1.getFileName,
    ],
    triggers: [],
});
//# sourceMappingURL=index.js.map