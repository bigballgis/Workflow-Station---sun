export declare const filesHelper: import("@activepieces/pieces-framework").Piece<undefined>;
//# sourceMappingURL=index.d.ts.map