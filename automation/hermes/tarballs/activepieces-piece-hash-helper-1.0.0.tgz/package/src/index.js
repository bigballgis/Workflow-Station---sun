"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __commonJS = (cb, mod) => function __require() {
  try {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  } catch (e) {
    throw mod = 0, e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/core.js
// @__NO_SIDE_EFFECTS__
function $constructor(name, initializer2, params) {
  function init(inst, def) {
    if (!inst._zod) {
      Object.defineProperty(inst, "_zod", {
        value: {
          def,
          constr: _,
          traits: /* @__PURE__ */ new Set()
        },
        enumerable: false
      });
    }
    if (inst._zod.traits.has(name)) {
      return;
    }
    inst._zod.traits.add(name);
    initializer2(inst, def);
    const proto = _.prototype;
    const keys = Object.keys(proto);
    for (let i = 0; i < keys.length; i++) {
      const k = keys[i];
      if (!(k in inst)) {
        inst[k] = proto[k].bind(inst);
      }
    }
  }
  const Parent = params?.Parent ?? Object;
  class Definition extends Parent {
  }
  Object.defineProperty(Definition, "name", { value: name });
  function _(def) {
    var _a2;
    const inst = params?.Parent ? new Definition() : this;
    init(inst, def);
    (_a2 = inst._zod).deferred ?? (_a2.deferred = []);
    for (const fn of inst._zod.deferred) {
      fn();
    }
    return inst;
  }
  Object.defineProperty(_, "init", { value: init });
  Object.defineProperty(_, Symbol.hasInstance, {
    value: (inst) => {
      if (params?.Parent && inst instanceof params.Parent)
        return true;
      return inst?._zod?.traits?.has(name);
    }
  });
  Object.defineProperty(_, "name", { value: name });
  return _;
}
function config(newConfig) {
  if (newConfig)
    Object.assign(globalConfig, newConfig);
  return globalConfig;
}
var NEVER, $ZodAsyncError, $ZodEncodeError, globalConfig;
var init_core = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/core.js"() {
    NEVER = Object.freeze({
      status: "aborted"
    });
    $ZodAsyncError = class extends Error {
      constructor() {
        super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
      }
    };
    $ZodEncodeError = class extends Error {
      constructor(name) {
        super(`Encountered unidirectional transform during encode: ${name}`);
        this.name = "ZodEncodeError";
      }
    };
    globalConfig = {};
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/util.js
function getEnumValues(entries) {
  const numericValues = Object.values(entries).filter((v) => typeof v === "number");
  const values = Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
  return values;
}
function jsonStringifyReplacer(_, value) {
  if (typeof value === "bigint")
    return value.toString();
  return value;
}
function cached(getter) {
  const set = false;
  return {
    get value() {
      if (!set) {
        const value = getter();
        Object.defineProperty(this, "value", { value });
        return value;
      }
      throw new Error("cached value already set");
    }
  };
}
function nullish(input) {
  return input === null || input === void 0;
}
function cleanRegex(source) {
  const start = source.startsWith("^") ? 1 : 0;
  const end = source.endsWith("$") ? source.length - 1 : source.length;
  return source.slice(start, end);
}
function defineLazy(object2, key, getter) {
  let value = void 0;
  Object.defineProperty(object2, key, {
    get() {
      if (value === EVALUATING) {
        return void 0;
      }
      if (value === void 0) {
        value = EVALUATING;
        value = getter();
      }
      return value;
    },
    set(v) {
      Object.defineProperty(object2, key, {
        value: v
        // configurable: true,
      });
    },
    configurable: true
  });
}
function isObject(data) {
  return typeof data === "object" && data !== null && !Array.isArray(data);
}
function isPlainObject(o) {
  if (isObject(o) === false)
    return false;
  const ctor = o.constructor;
  if (ctor === void 0)
    return true;
  if (typeof ctor !== "function")
    return true;
  const prot = ctor.prototype;
  if (isObject(prot) === false)
    return false;
  if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) {
    return false;
  }
  return true;
}
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone(inst, def, params) {
  const cl = new inst._zod.constr(def ?? inst._zod.def);
  if (!def || params?.parent)
    cl._zod.parent = inst;
  return cl;
}
function normalizeParams(_params) {
  const params = _params;
  if (!params)
    return {};
  if (typeof params === "string")
    return { error: () => params };
  if (params?.message !== void 0) {
    if (params?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    params.error = params.message;
  }
  delete params.message;
  if (typeof params.error === "string")
    return { ...params, error: () => params.error };
  return params;
}
function optionalKeys(shape) {
  return Object.keys(shape).filter((k) => {
    return shape[k]._zod.optin === "optional" && shape[k]._zod.optout === "optional";
  });
}
function aborted(x, startIndex = 0) {
  if (x.aborted === true)
    return true;
  for (let i = startIndex; i < x.issues.length; i++) {
    if (x.issues[i]?.continue !== true) {
      return true;
    }
  }
  return false;
}
function prefixIssues(path, issues) {
  return issues.map((iss) => {
    var _a2;
    (_a2 = iss).path ?? (_a2.path = []);
    iss.path.unshift(path);
    return iss;
  });
}
function unwrapMessage(message) {
  return typeof message === "string" ? message : message?.message;
}
function finalizeIssue(iss, ctx, config2) {
  const full = { ...iss, path: iss.path ?? [] };
  if (!iss.message) {
    const message = unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config2.customError?.(iss)) ?? unwrapMessage(config2.localeError?.(iss)) ?? "Invalid input";
    full.message = message;
  }
  delete full.inst;
  delete full.continue;
  if (!ctx?.reportInput) {
    delete full.input;
  }
  return full;
}
function getLengthableOrigin(input) {
  if (Array.isArray(input))
    return "array";
  if (typeof input === "string")
    return "string";
  return "unknown";
}
function issue(...args) {
  const [iss, input, inst] = args;
  if (typeof iss === "string") {
    return {
      message: iss,
      code: "custom",
      input,
      inst
    };
  }
  return { ...iss };
}
var EVALUATING, captureStackTrace, allowsEval, propertyKeyTypes, NUMBER_FORMAT_RANGES;
var init_util = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/util.js"() {
    EVALUATING = /* @__PURE__ */ Symbol("evaluating");
    captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {
    };
    allowsEval = cached(() => {
      if (typeof navigator !== "undefined" && navigator?.userAgent?.includes("Cloudflare")) {
        return false;
      }
      try {
        const F = Function;
        new F("");
        return true;
      } catch (_) {
        return false;
      }
    });
    propertyKeyTypes = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
    NUMBER_FORMAT_RANGES = {
      safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
      int32: [-2147483648, 2147483647],
      uint32: [0, 4294967295],
      float32: [-34028234663852886e22, 34028234663852886e22],
      float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
    };
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/errors.js
var initializer, $ZodError, $ZodRealError;
var init_errors = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/errors.js"() {
    init_core();
    init_util();
    initializer = (inst, def) => {
      inst.name = "$ZodError";
      Object.defineProperty(inst, "_zod", {
        value: inst._zod,
        enumerable: false
      });
      Object.defineProperty(inst, "issues", {
        value: def,
        enumerable: false
      });
      inst.message = JSON.stringify(def, jsonStringifyReplacer, 2);
      Object.defineProperty(inst, "toString", {
        value: () => inst.message,
        enumerable: false
      });
    };
    $ZodError = $constructor("$ZodError", initializer);
    $ZodRealError = $constructor("$ZodError", initializer, { Parent: Error });
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/parse.js
var _parse, parse, _parseAsync, parseAsync, _safeParse, safeParse, _safeParseAsync, safeParseAsync;
var init_parse = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/parse.js"() {
    init_core();
    init_errors();
    init_util();
    _parse = (_Err) => (schema, value, _ctx, _params) => {
      const ctx = _ctx ? Object.assign(_ctx, { async: false }) : { async: false };
      const result = schema._zod.run({ value, issues: [] }, ctx);
      if (result instanceof Promise) {
        throw new $ZodAsyncError();
      }
      if (result.issues.length) {
        const e = new (_params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
        captureStackTrace(e, _params?.callee);
        throw e;
      }
      return result.value;
    };
    parse = /* @__PURE__ */ _parse($ZodRealError);
    _parseAsync = (_Err) => async (schema, value, _ctx, params) => {
      const ctx = _ctx ? Object.assign(_ctx, { async: true }) : { async: true };
      let result = schema._zod.run({ value, issues: [] }, ctx);
      if (result instanceof Promise)
        result = await result;
      if (result.issues.length) {
        const e = new (params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
        captureStackTrace(e, params?.callee);
        throw e;
      }
      return result.value;
    };
    parseAsync = /* @__PURE__ */ _parseAsync($ZodRealError);
    _safeParse = (_Err) => (schema, value, _ctx) => {
      const ctx = _ctx ? { ..._ctx, async: false } : { async: false };
      const result = schema._zod.run({ value, issues: [] }, ctx);
      if (result instanceof Promise) {
        throw new $ZodAsyncError();
      }
      return result.issues.length ? {
        success: false,
        error: new (_Err ?? $ZodError)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
      } : { success: true, data: result.value };
    };
    safeParse = /* @__PURE__ */ _safeParse($ZodRealError);
    _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
      const ctx = _ctx ? Object.assign(_ctx, { async: true }) : { async: true };
      let result = schema._zod.run({ value, issues: [] }, ctx);
      if (result instanceof Promise)
        result = await result;
      return result.issues.length ? {
        success: false,
        error: new _Err(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
      } : { success: true, data: result.value };
    };
    safeParseAsync = /* @__PURE__ */ _safeParseAsync($ZodRealError);
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/regexes.js
var dateSource, date, string, bigint, integer, number, boolean;
var init_regexes = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/regexes.js"() {
    init_util();
    dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
    date = /* @__PURE__ */ new RegExp(`^${dateSource}$`);
    string = (params) => {
      const regex = params ? `[\\s\\S]{${params?.minimum ?? 0},${params?.maximum ?? ""}}` : `[\\s\\S]*`;
      return new RegExp(`^${regex}$`);
    };
    bigint = /^-?\d+n?$/;
    integer = /^-?\d+$/;
    number = /^-?\d+(?:\.\d+)?$/;
    boolean = /^(?:true|false)$/i;
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/checks.js
var $ZodCheck, numericOriginMap, $ZodCheckGreaterThan, $ZodCheckNumberFormat, $ZodCheckMinLength, $ZodCheckStringFormat, $ZodCheckRegex;
var init_checks = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/checks.js"() {
    init_core();
    init_regexes();
    init_util();
    $ZodCheck = /* @__PURE__ */ $constructor("$ZodCheck", (inst, def) => {
      var _a2;
      inst._zod ?? (inst._zod = {});
      inst._zod.def = def;
      (_a2 = inst._zod).onattach ?? (_a2.onattach = []);
    });
    numericOriginMap = {
      number: "number",
      bigint: "bigint",
      object: "date"
    };
    $ZodCheckGreaterThan = /* @__PURE__ */ $constructor("$ZodCheckGreaterThan", (inst, def) => {
      $ZodCheck.init(inst, def);
      const origin = numericOriginMap[typeof def.value];
      inst._zod.onattach.push((inst2) => {
        const bag = inst2._zod.bag;
        const curr = (def.inclusive ? bag.minimum : bag.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
        if (def.value > curr) {
          if (def.inclusive)
            bag.minimum = def.value;
          else
            bag.exclusiveMinimum = def.value;
        }
      });
      inst._zod.check = (payload) => {
        if (def.inclusive ? payload.value >= def.value : payload.value > def.value) {
          return;
        }
        payload.issues.push({
          origin,
          code: "too_small",
          minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
          input: payload.value,
          inclusive: def.inclusive,
          inst,
          continue: !def.abort
        });
      };
    });
    $ZodCheckNumberFormat = /* @__PURE__ */ $constructor("$ZodCheckNumberFormat", (inst, def) => {
      $ZodCheck.init(inst, def);
      def.format = def.format || "float64";
      const isInt = def.format?.includes("int");
      const origin = isInt ? "int" : "number";
      const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
      inst._zod.onattach.push((inst2) => {
        const bag = inst2._zod.bag;
        bag.format = def.format;
        bag.minimum = minimum;
        bag.maximum = maximum;
        if (isInt)
          bag.pattern = integer;
      });
      inst._zod.check = (payload) => {
        const input = payload.value;
        if (isInt) {
          if (!Number.isInteger(input)) {
            payload.issues.push({
              expected: origin,
              format: def.format,
              code: "invalid_type",
              continue: false,
              input,
              inst
            });
            return;
          }
          if (!Number.isSafeInteger(input)) {
            if (input > 0) {
              payload.issues.push({
                input,
                code: "too_big",
                maximum: Number.MAX_SAFE_INTEGER,
                note: "Integers must be within the safe integer range.",
                inst,
                origin,
                inclusive: true,
                continue: !def.abort
              });
            } else {
              payload.issues.push({
                input,
                code: "too_small",
                minimum: Number.MIN_SAFE_INTEGER,
                note: "Integers must be within the safe integer range.",
                inst,
                origin,
                inclusive: true,
                continue: !def.abort
              });
            }
            return;
          }
        }
        if (input < minimum) {
          payload.issues.push({
            origin: "number",
            input,
            code: "too_small",
            minimum,
            inclusive: true,
            inst,
            continue: !def.abort
          });
        }
        if (input > maximum) {
          payload.issues.push({
            origin: "number",
            input,
            code: "too_big",
            maximum,
            inclusive: true,
            inst,
            continue: !def.abort
          });
        }
      };
    });
    $ZodCheckMinLength = /* @__PURE__ */ $constructor("$ZodCheckMinLength", (inst, def) => {
      var _a2;
      $ZodCheck.init(inst, def);
      (_a2 = inst._zod.def).when ?? (_a2.when = (payload) => {
        const val = payload.value;
        return !nullish(val) && val.length !== void 0;
      });
      inst._zod.onattach.push((inst2) => {
        const curr = inst2._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
        if (def.minimum > curr)
          inst2._zod.bag.minimum = def.minimum;
      });
      inst._zod.check = (payload) => {
        const input = payload.value;
        const length = input.length;
        if (length >= def.minimum)
          return;
        const origin = getLengthableOrigin(input);
        payload.issues.push({
          origin,
          code: "too_small",
          minimum: def.minimum,
          inclusive: true,
          input,
          inst,
          continue: !def.abort
        });
      };
    });
    $ZodCheckStringFormat = /* @__PURE__ */ $constructor("$ZodCheckStringFormat", (inst, def) => {
      var _a2, _b;
      $ZodCheck.init(inst, def);
      inst._zod.onattach.push((inst2) => {
        const bag = inst2._zod.bag;
        bag.format = def.format;
        if (def.pattern) {
          bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
          bag.patterns.add(def.pattern);
        }
      });
      if (def.pattern)
        (_a2 = inst._zod).check ?? (_a2.check = (payload) => {
          def.pattern.lastIndex = 0;
          if (def.pattern.test(payload.value))
            return;
          payload.issues.push({
            origin: "string",
            code: "invalid_format",
            format: def.format,
            input: payload.value,
            ...def.pattern ? { pattern: def.pattern.toString() } : {},
            inst,
            continue: !def.abort
          });
        });
      else
        (_b = inst._zod).check ?? (_b.check = () => {
        });
    });
    $ZodCheckRegex = /* @__PURE__ */ $constructor("$ZodCheckRegex", (inst, def) => {
      $ZodCheckStringFormat.init(inst, def);
      inst._zod.check = (payload) => {
        def.pattern.lastIndex = 0;
        if (def.pattern.test(payload.value))
          return;
        payload.issues.push({
          origin: "string",
          code: "invalid_format",
          format: "regex",
          input: payload.value,
          pattern: def.pattern.toString(),
          inst,
          continue: !def.abort
        });
      };
    });
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/doc.js
var init_doc = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/doc.js"() {
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/versions.js
var version;
var init_versions = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/versions.js"() {
    version = {
      major: 4,
      minor: 3,
      patch: 6
    };
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/schemas.js
function handleArrayResult(result, final, index) {
  if (result.issues.length) {
    final.issues.push(...prefixIssues(index, result.issues));
  }
  final.value[index] = result.value;
}
function handlePropertyResult(result, final, key, input, isOptionalOut) {
  if (result.issues.length) {
    if (isOptionalOut && !(key in input)) {
      return;
    }
    final.issues.push(...prefixIssues(key, result.issues));
  }
  if (result.value === void 0) {
    if (key in input) {
      final.value[key] = void 0;
    }
  } else {
    final.value[key] = result.value;
  }
}
function normalizeDef(def) {
  const keys = Object.keys(def.shape);
  for (const k of keys) {
    if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) {
      throw new Error(`Invalid element at key "${k}": expected a Zod schema`);
    }
  }
  const okeys = optionalKeys(def.shape);
  return {
    ...def,
    keys,
    keySet: new Set(keys),
    numKeys: keys.length,
    optionalKeys: new Set(okeys)
  };
}
function handleCatchall(proms, input, payload, ctx, def, inst) {
  const unrecognized = [];
  const keySet = def.keySet;
  const _catchall = def.catchall._zod;
  const t = _catchall.def.type;
  const isOptionalOut = _catchall.optout === "optional";
  for (const key in input) {
    if (keySet.has(key))
      continue;
    if (t === "never") {
      unrecognized.push(key);
      continue;
    }
    const r = _catchall.run({ value: input[key], issues: [] }, ctx);
    if (r instanceof Promise) {
      proms.push(r.then((r2) => handlePropertyResult(r2, payload, key, input, isOptionalOut)));
    } else {
      handlePropertyResult(r, payload, key, input, isOptionalOut);
    }
  }
  if (unrecognized.length) {
    payload.issues.push({
      code: "unrecognized_keys",
      keys: unrecognized,
      input,
      inst
    });
  }
  if (!proms.length)
    return payload;
  return Promise.all(proms).then(() => {
    return payload;
  });
}
function handleUnionResults(results, final, inst, ctx) {
  for (const result of results) {
    if (result.issues.length === 0) {
      final.value = result.value;
      return final;
    }
  }
  const nonaborted = results.filter((r) => !aborted(r));
  if (nonaborted.length === 1) {
    final.value = nonaborted[0].value;
    return nonaborted[0];
  }
  final.issues.push({
    code: "invalid_union",
    input: final.value,
    inst,
    errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
  });
  return final;
}
function handleOptionalResult(result, input) {
  if (result.issues.length && input === void 0) {
    return { issues: [], value: void 0 };
  }
  return result;
}
function handlePipeResult(left, next, ctx) {
  if (left.issues.length) {
    left.aborted = true;
    return left;
  }
  return next._zod.run({ value: left.value, issues: left.issues }, ctx);
}
function handleRefineResult(result, payload, input, inst) {
  if (!result) {
    const _iss = {
      code: "custom",
      input,
      inst,
      // incorporates params.error into issue reporting
      path: [...inst._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !inst._zod.def.abort
      // params: inst._zod.def.params,
    };
    if (inst._zod.def.params)
      _iss.params = inst._zod.def.params;
    payload.issues.push(issue(_iss));
  }
}
var $ZodType, $ZodString, $ZodStringFormat, $ZodURL, $ZodNumber, $ZodNumberFormat, $ZodBoolean, $ZodBigInt, $ZodAny, $ZodUnknown, $ZodVoid, $ZodDate, $ZodArray, $ZodObject, $ZodUnion, $ZodDiscriminatedUnion, $ZodRecord, $ZodEnum, $ZodLiteral, $ZodTransform, $ZodOptional, $ZodNullable, $ZodPipe, $ZodCustom;
var init_schemas = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/schemas.js"() {
    init_checks();
    init_core();
    init_doc();
    init_parse();
    init_regexes();
    init_util();
    init_versions();
    init_util();
    $ZodType = /* @__PURE__ */ $constructor("$ZodType", (inst, def) => {
      var _a2;
      inst ?? (inst = {});
      inst._zod.def = def;
      inst._zod.bag = inst._zod.bag || {};
      inst._zod.version = version;
      const checks = [...inst._zod.def.checks ?? []];
      if (inst._zod.traits.has("$ZodCheck")) {
        checks.unshift(inst);
      }
      for (const ch of checks) {
        for (const fn of ch._zod.onattach) {
          fn(inst);
        }
      }
      if (checks.length === 0) {
        (_a2 = inst._zod).deferred ?? (_a2.deferred = []);
        inst._zod.deferred?.push(() => {
          inst._zod.run = inst._zod.parse;
        });
      } else {
        const runChecks = (payload, checks2, ctx) => {
          let isAborted = aborted(payload);
          let asyncResult;
          for (const ch of checks2) {
            if (ch._zod.def.when) {
              const shouldRun = ch._zod.def.when(payload);
              if (!shouldRun)
                continue;
            } else if (isAborted) {
              continue;
            }
            const currLen = payload.issues.length;
            const _ = ch._zod.check(payload);
            if (_ instanceof Promise && ctx?.async === false) {
              throw new $ZodAsyncError();
            }
            if (asyncResult || _ instanceof Promise) {
              asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
                await _;
                const nextLen = payload.issues.length;
                if (nextLen === currLen)
                  return;
                if (!isAborted)
                  isAborted = aborted(payload, currLen);
              });
            } else {
              const nextLen = payload.issues.length;
              if (nextLen === currLen)
                continue;
              if (!isAborted)
                isAborted = aborted(payload, currLen);
            }
          }
          if (asyncResult) {
            return asyncResult.then(() => {
              return payload;
            });
          }
          return payload;
        };
        const handleCanaryResult = (canary, payload, ctx) => {
          if (aborted(canary)) {
            canary.aborted = true;
            return canary;
          }
          const checkResult = runChecks(payload, checks, ctx);
          if (checkResult instanceof Promise) {
            if (ctx.async === false)
              throw new $ZodAsyncError();
            return checkResult.then((checkResult2) => inst._zod.parse(checkResult2, ctx));
          }
          return inst._zod.parse(checkResult, ctx);
        };
        inst._zod.run = (payload, ctx) => {
          if (ctx.skipChecks) {
            return inst._zod.parse(payload, ctx);
          }
          if (ctx.direction === "backward") {
            const canary = inst._zod.parse({ value: payload.value, issues: [] }, { ...ctx, skipChecks: true });
            if (canary instanceof Promise) {
              return canary.then((canary2) => {
                return handleCanaryResult(canary2, payload, ctx);
              });
            }
            return handleCanaryResult(canary, payload, ctx);
          }
          const result = inst._zod.parse(payload, ctx);
          if (result instanceof Promise) {
            if (ctx.async === false)
              throw new $ZodAsyncError();
            return result.then((result2) => runChecks(result2, checks, ctx));
          }
          return runChecks(result, checks, ctx);
        };
      }
      defineLazy(inst, "~standard", () => ({
        validate: (value) => {
          try {
            const r = safeParse(inst, value);
            return r.success ? { value: r.data } : { issues: r.error?.issues };
          } catch (_) {
            return safeParseAsync(inst, value).then((r) => r.success ? { value: r.data } : { issues: r.error?.issues });
          }
        },
        vendor: "zod",
        version: 1
      }));
    });
    $ZodString = /* @__PURE__ */ $constructor("$ZodString", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.pattern = [...inst?._zod.bag?.patterns ?? []].pop() ?? string(inst._zod.bag);
      inst._zod.parse = (payload, _) => {
        if (def.coerce)
          try {
            payload.value = String(payload.value);
          } catch (_2) {
          }
        if (typeof payload.value === "string")
          return payload;
        payload.issues.push({
          expected: "string",
          code: "invalid_type",
          input: payload.value,
          inst
        });
        return payload;
      };
    });
    $ZodStringFormat = /* @__PURE__ */ $constructor("$ZodStringFormat", (inst, def) => {
      $ZodCheckStringFormat.init(inst, def);
      $ZodString.init(inst, def);
    });
    $ZodURL = /* @__PURE__ */ $constructor("$ZodURL", (inst, def) => {
      $ZodStringFormat.init(inst, def);
      inst._zod.check = (payload) => {
        try {
          const trimmed = payload.value.trim();
          const url2 = new URL(trimmed);
          if (def.hostname) {
            def.hostname.lastIndex = 0;
            if (!def.hostname.test(url2.hostname)) {
              payload.issues.push({
                code: "invalid_format",
                format: "url",
                note: "Invalid hostname",
                pattern: def.hostname.source,
                input: payload.value,
                inst,
                continue: !def.abort
              });
            }
          }
          if (def.protocol) {
            def.protocol.lastIndex = 0;
            if (!def.protocol.test(url2.protocol.endsWith(":") ? url2.protocol.slice(0, -1) : url2.protocol)) {
              payload.issues.push({
                code: "invalid_format",
                format: "url",
                note: "Invalid protocol",
                pattern: def.protocol.source,
                input: payload.value,
                inst,
                continue: !def.abort
              });
            }
          }
          if (def.normalize) {
            payload.value = url2.href;
          } else {
            payload.value = trimmed;
          }
          return;
        } catch (_) {
          payload.issues.push({
            code: "invalid_format",
            format: "url",
            input: payload.value,
            inst,
            continue: !def.abort
          });
        }
      };
    });
    $ZodNumber = /* @__PURE__ */ $constructor("$ZodNumber", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.pattern = inst._zod.bag.pattern ?? number;
      inst._zod.parse = (payload, _ctx) => {
        if (def.coerce)
          try {
            payload.value = Number(payload.value);
          } catch (_) {
          }
        const input = payload.value;
        if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) {
          return payload;
        }
        const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? "Infinity" : void 0 : void 0;
        payload.issues.push({
          expected: "number",
          code: "invalid_type",
          input,
          inst,
          ...received ? { received } : {}
        });
        return payload;
      };
    });
    $ZodNumberFormat = /* @__PURE__ */ $constructor("$ZodNumberFormat", (inst, def) => {
      $ZodCheckNumberFormat.init(inst, def);
      $ZodNumber.init(inst, def);
    });
    $ZodBoolean = /* @__PURE__ */ $constructor("$ZodBoolean", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.pattern = boolean;
      inst._zod.parse = (payload, _ctx) => {
        if (def.coerce)
          try {
            payload.value = Boolean(payload.value);
          } catch (_) {
          }
        const input = payload.value;
        if (typeof input === "boolean")
          return payload;
        payload.issues.push({
          expected: "boolean",
          code: "invalid_type",
          input,
          inst
        });
        return payload;
      };
    });
    $ZodBigInt = /* @__PURE__ */ $constructor("$ZodBigInt", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.pattern = bigint;
      inst._zod.parse = (payload, _ctx) => {
        if (def.coerce)
          try {
            payload.value = BigInt(payload.value);
          } catch (_) {
          }
        if (typeof payload.value === "bigint")
          return payload;
        payload.issues.push({
          expected: "bigint",
          code: "invalid_type",
          input: payload.value,
          inst
        });
        return payload;
      };
    });
    $ZodAny = /* @__PURE__ */ $constructor("$ZodAny", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.parse = (payload) => payload;
    });
    $ZodUnknown = /* @__PURE__ */ $constructor("$ZodUnknown", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.parse = (payload) => payload;
    });
    $ZodVoid = /* @__PURE__ */ $constructor("$ZodVoid", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.parse = (payload, _ctx) => {
        const input = payload.value;
        if (typeof input === "undefined")
          return payload;
        payload.issues.push({
          expected: "void",
          code: "invalid_type",
          input,
          inst
        });
        return payload;
      };
    });
    $ZodDate = /* @__PURE__ */ $constructor("$ZodDate", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.parse = (payload, _ctx) => {
        if (def.coerce) {
          try {
            payload.value = new Date(payload.value);
          } catch (_err) {
          }
        }
        const input = payload.value;
        const isDate = input instanceof Date;
        const isValidDate = isDate && !Number.isNaN(input.getTime());
        if (isValidDate)
          return payload;
        payload.issues.push({
          expected: "date",
          code: "invalid_type",
          input,
          ...isDate ? { received: "Invalid Date" } : {},
          inst
        });
        return payload;
      };
    });
    $ZodArray = /* @__PURE__ */ $constructor("$ZodArray", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.parse = (payload, ctx) => {
        const input = payload.value;
        if (!Array.isArray(input)) {
          payload.issues.push({
            expected: "array",
            code: "invalid_type",
            input,
            inst
          });
          return payload;
        }
        payload.value = Array(input.length);
        const proms = [];
        for (let i = 0; i < input.length; i++) {
          const item = input[i];
          const result = def.element._zod.run({
            value: item,
            issues: []
          }, ctx);
          if (result instanceof Promise) {
            proms.push(result.then((result2) => handleArrayResult(result2, payload, i)));
          } else {
            handleArrayResult(result, payload, i);
          }
        }
        if (proms.length) {
          return Promise.all(proms).then(() => payload);
        }
        return payload;
      };
    });
    $ZodObject = /* @__PURE__ */ $constructor("$ZodObject", (inst, def) => {
      $ZodType.init(inst, def);
      const desc = Object.getOwnPropertyDescriptor(def, "shape");
      if (!desc?.get) {
        const sh = def.shape;
        Object.defineProperty(def, "shape", {
          get: () => {
            const newSh = { ...sh };
            Object.defineProperty(def, "shape", {
              value: newSh
            });
            return newSh;
          }
        });
      }
      const _normalized = cached(() => normalizeDef(def));
      defineLazy(inst._zod, "propValues", () => {
        const shape = def.shape;
        const propValues = {};
        for (const key in shape) {
          const field = shape[key]._zod;
          if (field.values) {
            propValues[key] ?? (propValues[key] = /* @__PURE__ */ new Set());
            for (const v of field.values)
              propValues[key].add(v);
          }
        }
        return propValues;
      });
      const isObject2 = isObject;
      const catchall = def.catchall;
      let value;
      inst._zod.parse = (payload, ctx) => {
        value ?? (value = _normalized.value);
        const input = payload.value;
        if (!isObject2(input)) {
          payload.issues.push({
            expected: "object",
            code: "invalid_type",
            input,
            inst
          });
          return payload;
        }
        payload.value = {};
        const proms = [];
        const shape = value.shape;
        for (const key of value.keys) {
          const el = shape[key];
          const isOptionalOut = el._zod.optout === "optional";
          const r = el._zod.run({ value: input[key], issues: [] }, ctx);
          if (r instanceof Promise) {
            proms.push(r.then((r2) => handlePropertyResult(r2, payload, key, input, isOptionalOut)));
          } else {
            handlePropertyResult(r, payload, key, input, isOptionalOut);
          }
        }
        if (!catchall) {
          return proms.length ? Promise.all(proms).then(() => payload) : payload;
        }
        return handleCatchall(proms, input, payload, ctx, _normalized.value, inst);
      };
    });
    $ZodUnion = /* @__PURE__ */ $constructor("$ZodUnion", (inst, def) => {
      $ZodType.init(inst, def);
      defineLazy(inst._zod, "optin", () => def.options.some((o) => o._zod.optin === "optional") ? "optional" : void 0);
      defineLazy(inst._zod, "optout", () => def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
      defineLazy(inst._zod, "values", () => {
        if (def.options.every((o) => o._zod.values)) {
          return new Set(def.options.flatMap((option) => Array.from(option._zod.values)));
        }
        return void 0;
      });
      defineLazy(inst._zod, "pattern", () => {
        if (def.options.every((o) => o._zod.pattern)) {
          const patterns = def.options.map((o) => o._zod.pattern);
          return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
        }
        return void 0;
      });
      const single = def.options.length === 1;
      const first = def.options[0]._zod.run;
      inst._zod.parse = (payload, ctx) => {
        if (single) {
          return first(payload, ctx);
        }
        let async = false;
        const results = [];
        for (const option of def.options) {
          const result = option._zod.run({
            value: payload.value,
            issues: []
          }, ctx);
          if (result instanceof Promise) {
            results.push(result);
            async = true;
          } else {
            if (result.issues.length === 0)
              return result;
            results.push(result);
          }
        }
        if (!async)
          return handleUnionResults(results, payload, inst, ctx);
        return Promise.all(results).then((results2) => {
          return handleUnionResults(results2, payload, inst, ctx);
        });
      };
    });
    $ZodDiscriminatedUnion = /* @__PURE__ */ $constructor("$ZodDiscriminatedUnion", (inst, def) => {
      def.inclusive = false;
      $ZodUnion.init(inst, def);
      const _super = inst._zod.parse;
      defineLazy(inst._zod, "propValues", () => {
        const propValues = {};
        for (const option of def.options) {
          const pv = option._zod.propValues;
          if (!pv || Object.keys(pv).length === 0)
            throw new Error(`Invalid discriminated union option at index "${def.options.indexOf(option)}"`);
          for (const [k, v] of Object.entries(pv)) {
            if (!propValues[k])
              propValues[k] = /* @__PURE__ */ new Set();
            for (const val of v) {
              propValues[k].add(val);
            }
          }
        }
        return propValues;
      });
      const disc = cached(() => {
        const opts = def.options;
        const map = /* @__PURE__ */ new Map();
        for (const o of opts) {
          const values = o._zod.propValues?.[def.discriminator];
          if (!values || values.size === 0)
            throw new Error(`Invalid discriminated union option at index "${def.options.indexOf(o)}"`);
          for (const v of values) {
            if (map.has(v)) {
              throw new Error(`Duplicate discriminator value "${String(v)}"`);
            }
            map.set(v, o);
          }
        }
        return map;
      });
      inst._zod.parse = (payload, ctx) => {
        const input = payload.value;
        if (!isObject(input)) {
          payload.issues.push({
            code: "invalid_type",
            expected: "object",
            input,
            inst
          });
          return payload;
        }
        const opt = disc.value.get(input?.[def.discriminator]);
        if (opt) {
          return opt._zod.run(payload, ctx);
        }
        if (def.unionFallback) {
          return _super(payload, ctx);
        }
        payload.issues.push({
          code: "invalid_union",
          errors: [],
          note: "No matching discriminator",
          discriminator: def.discriminator,
          input,
          path: [def.discriminator],
          inst
        });
        return payload;
      };
    });
    $ZodRecord = /* @__PURE__ */ $constructor("$ZodRecord", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.parse = (payload, ctx) => {
        const input = payload.value;
        if (!isPlainObject(input)) {
          payload.issues.push({
            expected: "record",
            code: "invalid_type",
            input,
            inst
          });
          return payload;
        }
        const proms = [];
        const values = def.keyType._zod.values;
        if (values) {
          payload.value = {};
          const recordKeys = /* @__PURE__ */ new Set();
          for (const key of values) {
            if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
              recordKeys.add(typeof key === "number" ? key.toString() : key);
              const result = def.valueType._zod.run({ value: input[key], issues: [] }, ctx);
              if (result instanceof Promise) {
                proms.push(result.then((result2) => {
                  if (result2.issues.length) {
                    payload.issues.push(...prefixIssues(key, result2.issues));
                  }
                  payload.value[key] = result2.value;
                }));
              } else {
                if (result.issues.length) {
                  payload.issues.push(...prefixIssues(key, result.issues));
                }
                payload.value[key] = result.value;
              }
            }
          }
          let unrecognized;
          for (const key in input) {
            if (!recordKeys.has(key)) {
              unrecognized = unrecognized ?? [];
              unrecognized.push(key);
            }
          }
          if (unrecognized && unrecognized.length > 0) {
            payload.issues.push({
              code: "unrecognized_keys",
              input,
              inst,
              keys: unrecognized
            });
          }
        } else {
          payload.value = {};
          for (const key of Reflect.ownKeys(input)) {
            if (key === "__proto__")
              continue;
            let keyResult = def.keyType._zod.run({ value: key, issues: [] }, ctx);
            if (keyResult instanceof Promise) {
              throw new Error("Async schemas not supported in object keys currently");
            }
            const checkNumericKey = typeof key === "string" && number.test(key) && keyResult.issues.length;
            if (checkNumericKey) {
              const retryResult = def.keyType._zod.run({ value: Number(key), issues: [] }, ctx);
              if (retryResult instanceof Promise) {
                throw new Error("Async schemas not supported in object keys currently");
              }
              if (retryResult.issues.length === 0) {
                keyResult = retryResult;
              }
            }
            if (keyResult.issues.length) {
              if (def.mode === "loose") {
                payload.value[key] = input[key];
              } else {
                payload.issues.push({
                  code: "invalid_key",
                  origin: "record",
                  issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
                  input: key,
                  path: [key],
                  inst
                });
              }
              continue;
            }
            const result = def.valueType._zod.run({ value: input[key], issues: [] }, ctx);
            if (result instanceof Promise) {
              proms.push(result.then((result2) => {
                if (result2.issues.length) {
                  payload.issues.push(...prefixIssues(key, result2.issues));
                }
                payload.value[keyResult.value] = result2.value;
              }));
            } else {
              if (result.issues.length) {
                payload.issues.push(...prefixIssues(key, result.issues));
              }
              payload.value[keyResult.value] = result.value;
            }
          }
        }
        if (proms.length) {
          return Promise.all(proms).then(() => payload);
        }
        return payload;
      };
    });
    $ZodEnum = /* @__PURE__ */ $constructor("$ZodEnum", (inst, def) => {
      $ZodType.init(inst, def);
      const values = getEnumValues(def.entries);
      const valuesSet = new Set(values);
      inst._zod.values = valuesSet;
      inst._zod.pattern = new RegExp(`^(${values.filter((k) => propertyKeyTypes.has(typeof k)).map((o) => typeof o === "string" ? escapeRegex(o) : o.toString()).join("|")})$`);
      inst._zod.parse = (payload, _ctx) => {
        const input = payload.value;
        if (valuesSet.has(input)) {
          return payload;
        }
        payload.issues.push({
          code: "invalid_value",
          values,
          input,
          inst
        });
        return payload;
      };
    });
    $ZodLiteral = /* @__PURE__ */ $constructor("$ZodLiteral", (inst, def) => {
      $ZodType.init(inst, def);
      if (def.values.length === 0) {
        throw new Error("Cannot create literal schema with no valid values");
      }
      const values = new Set(def.values);
      inst._zod.values = values;
      inst._zod.pattern = new RegExp(`^(${def.values.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$`);
      inst._zod.parse = (payload, _ctx) => {
        const input = payload.value;
        if (values.has(input)) {
          return payload;
        }
        payload.issues.push({
          code: "invalid_value",
          values: def.values,
          input,
          inst
        });
        return payload;
      };
    });
    $ZodTransform = /* @__PURE__ */ $constructor("$ZodTransform", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.parse = (payload, ctx) => {
        if (ctx.direction === "backward") {
          throw new $ZodEncodeError(inst.constructor.name);
        }
        const _out = def.transform(payload.value, payload);
        if (ctx.async) {
          const output = _out instanceof Promise ? _out : Promise.resolve(_out);
          return output.then((output2) => {
            payload.value = output2;
            return payload;
          });
        }
        if (_out instanceof Promise) {
          throw new $ZodAsyncError();
        }
        payload.value = _out;
        return payload;
      };
    });
    $ZodOptional = /* @__PURE__ */ $constructor("$ZodOptional", (inst, def) => {
      $ZodType.init(inst, def);
      inst._zod.optin = "optional";
      inst._zod.optout = "optional";
      defineLazy(inst._zod, "values", () => {
        return def.innerType._zod.values ? /* @__PURE__ */ new Set([...def.innerType._zod.values, void 0]) : void 0;
      });
      defineLazy(inst._zod, "pattern", () => {
        const pattern = def.innerType._zod.pattern;
        return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
      });
      inst._zod.parse = (payload, ctx) => {
        if (def.innerType._zod.optin === "optional") {
          const result = def.innerType._zod.run(payload, ctx);
          if (result instanceof Promise)
            return result.then((r) => handleOptionalResult(r, payload.value));
          return handleOptionalResult(result, payload.value);
        }
        if (payload.value === void 0) {
          return payload;
        }
        return def.innerType._zod.run(payload, ctx);
      };
    });
    $ZodNullable = /* @__PURE__ */ $constructor("$ZodNullable", (inst, def) => {
      $ZodType.init(inst, def);
      defineLazy(inst._zod, "optin", () => def.innerType._zod.optin);
      defineLazy(inst._zod, "optout", () => def.innerType._zod.optout);
      defineLazy(inst._zod, "pattern", () => {
        const pattern = def.innerType._zod.pattern;
        return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
      });
      defineLazy(inst._zod, "values", () => {
        return def.innerType._zod.values ? /* @__PURE__ */ new Set([...def.innerType._zod.values, null]) : void 0;
      });
      inst._zod.parse = (payload, ctx) => {
        if (payload.value === null)
          return payload;
        return def.innerType._zod.run(payload, ctx);
      };
    });
    $ZodPipe = /* @__PURE__ */ $constructor("$ZodPipe", (inst, def) => {
      $ZodType.init(inst, def);
      defineLazy(inst._zod, "values", () => def.in._zod.values);
      defineLazy(inst._zod, "optin", () => def.in._zod.optin);
      defineLazy(inst._zod, "optout", () => def.out._zod.optout);
      defineLazy(inst._zod, "propValues", () => def.in._zod.propValues);
      inst._zod.parse = (payload, ctx) => {
        if (ctx.direction === "backward") {
          const right = def.out._zod.run(payload, ctx);
          if (right instanceof Promise) {
            return right.then((right2) => handlePipeResult(right2, def.in, ctx));
          }
          return handlePipeResult(right, def.in, ctx);
        }
        const left = def.in._zod.run(payload, ctx);
        if (left instanceof Promise) {
          return left.then((left2) => handlePipeResult(left2, def.out, ctx));
        }
        return handlePipeResult(left, def.out, ctx);
      };
    });
    $ZodCustom = /* @__PURE__ */ $constructor("$ZodCustom", (inst, def) => {
      $ZodCheck.init(inst, def);
      $ZodType.init(inst, def);
      inst._zod.parse = (payload, _) => {
        return payload;
      };
      inst._zod.check = (payload) => {
        const input = payload.value;
        const r = def.fn(input);
        if (r instanceof Promise) {
          return r.then((r2) => handleRefineResult(r2, payload, input, inst));
        }
        handleRefineResult(r, payload, input, inst);
        return;
      };
    });
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ar.js
var init_ar = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ar.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/az.js
var init_az = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/az.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/be.js
var init_be = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/be.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/bg.js
var init_bg = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/bg.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ca.js
var init_ca = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ca.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/cs.js
var init_cs = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/cs.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/da.js
var init_da = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/da.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/de.js
var init_de = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/de.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/en.js
var init_en = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/en.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/eo.js
var init_eo = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/eo.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/es.js
var init_es = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/es.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fa.js
var init_fa = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fa.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fi.js
var init_fi = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fi.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fr.js
var init_fr = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fr.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fr-CA.js
var init_fr_CA = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/fr-CA.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/he.js
var init_he = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/he.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/hu.js
var init_hu = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/hu.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/hy.js
var init_hy = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/hy.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/id.js
var init_id = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/id.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/is.js
var init_is = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/is.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/it.js
var init_it = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/it.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ja.js
var init_ja = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ja.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ka.js
var init_ka = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ka.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/km.js
var init_km = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/km.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/kh.js
var init_kh = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/kh.js"() {
    init_km();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ko.js
var init_ko = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ko.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/lt.js
var init_lt = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/lt.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/mk.js
var init_mk = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/mk.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ms.js
var init_ms = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ms.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/nl.js
var init_nl = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/nl.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/no.js
var init_no = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/no.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ota.js
var init_ota = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ota.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ps.js
var init_ps = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ps.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/pl.js
var init_pl = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/pl.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/pt.js
var init_pt = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/pt.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ru.js
var init_ru = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ru.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/sl.js
var init_sl = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/sl.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/sv.js
var init_sv = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/sv.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ta.js
var init_ta = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ta.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/th.js
var init_th = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/th.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/tr.js
var init_tr = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/tr.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/uk.js
var init_uk = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/uk.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ua.js
var init_ua = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ua.js"() {
    init_uk();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ur.js
var init_ur = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/ur.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/uz.js
var init_uz = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/uz.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/vi.js
var init_vi = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/vi.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/zh-CN.js
var init_zh_CN = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/zh-CN.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/zh-TW.js
var init_zh_TW = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/zh-TW.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/yo.js
var init_yo = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/yo.js"() {
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/index.js
var init_locales = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/locales/index.js"() {
    init_ar();
    init_az();
    init_be();
    init_bg();
    init_ca();
    init_cs();
    init_da();
    init_de();
    init_en();
    init_eo();
    init_es();
    init_fa();
    init_fi();
    init_fr();
    init_fr_CA();
    init_he();
    init_hu();
    init_hy();
    init_id();
    init_is();
    init_it();
    init_ja();
    init_ka();
    init_kh();
    init_km();
    init_ko();
    init_lt();
    init_mk();
    init_ms();
    init_nl();
    init_no();
    init_ota();
    init_ps();
    init_pl();
    init_pt();
    init_ru();
    init_sl();
    init_sv();
    init_ta();
    init_th();
    init_tr();
    init_ua();
    init_uk();
    init_ur();
    init_uz();
    init_vi();
    init_zh_CN();
    init_zh_TW();
    init_yo();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/registries.js
function registry() {
  return new $ZodRegistry();
}
var _a, $ZodRegistry, globalRegistry;
var init_registries = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/registries.js"() {
    $ZodRegistry = class {
      constructor() {
        this._map = /* @__PURE__ */ new WeakMap();
        this._idmap = /* @__PURE__ */ new Map();
      }
      add(schema, ..._meta) {
        const meta2 = _meta[0];
        this._map.set(schema, meta2);
        if (meta2 && typeof meta2 === "object" && "id" in meta2) {
          this._idmap.set(meta2.id, schema);
        }
        return this;
      }
      clear() {
        this._map = /* @__PURE__ */ new WeakMap();
        this._idmap = /* @__PURE__ */ new Map();
        return this;
      }
      remove(schema) {
        const meta2 = this._map.get(schema);
        if (meta2 && typeof meta2 === "object" && "id" in meta2) {
          this._idmap.delete(meta2.id);
        }
        this._map.delete(schema);
        return this;
      }
      get(schema) {
        const p = schema._zod.parent;
        if (p) {
          const pm = { ...this.get(p) ?? {} };
          delete pm.id;
          const f = { ...pm, ...this._map.get(schema) };
          return Object.keys(f).length ? f : void 0;
        }
        return this._map.get(schema);
      }
      has(schema) {
        return this._map.has(schema);
      }
    };
    (_a = globalThis).__zod_globalRegistry ?? (_a.__zod_globalRegistry = registry());
    globalRegistry = globalThis.__zod_globalRegistry;
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function _string(Class, params) {
  return new Class({
    type: "string",
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _coercedString(Class, params) {
  return new Class({
    type: "string",
    coerce: true,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _url(Class, params) {
  return new Class({
    type: "string",
    format: "url",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _number(Class, params) {
  return new Class({
    type: "number",
    checks: [],
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _coercedNumber(Class, params) {
  return new Class({
    type: "number",
    coerce: true,
    checks: [],
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _int(Class, params) {
  return new Class({
    type: "number",
    check: "number_format",
    abort: false,
    format: "safeint",
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _boolean(Class, params) {
  return new Class({
    type: "boolean",
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _coercedBoolean(Class, params) {
  return new Class({
    type: "boolean",
    coerce: true,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _coercedBigint(Class, params) {
  return new Class({
    type: "bigint",
    coerce: true,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _any(Class) {
  return new Class({
    type: "any"
  });
}
// @__NO_SIDE_EFFECTS__
function _unknown(Class) {
  return new Class({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function _void(Class, params) {
  return new Class({
    type: "void",
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _coercedDate(Class, params) {
  return new Class({
    type: "date",
    coerce: true,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _gte(value, params) {
  return new $ZodCheckGreaterThan({
    check: "greater_than",
    ...normalizeParams(params),
    value,
    inclusive: true
  });
}
// @__NO_SIDE_EFFECTS__
function _minLength(minimum, params) {
  return new $ZodCheckMinLength({
    check: "min_length",
    ...normalizeParams(params),
    minimum
  });
}
// @__NO_SIDE_EFFECTS__
function _regex(pattern, params) {
  return new $ZodCheckRegex({
    check: "string_format",
    format: "regex",
    ...normalizeParams(params),
    pattern
  });
}
// @__NO_SIDE_EFFECTS__
function _custom(Class, fn, _params) {
  const norm = normalizeParams(_params);
  norm.abort ?? (norm.abort = true);
  const schema = new Class({
    type: "custom",
    check: "custom",
    fn,
    ...norm
  });
  return schema;
}
var init_api = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/api.js"() {
    init_checks();
    init_registries();
    init_schemas();
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/to-json-schema.js
var init_to_json_schema = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/to-json-schema.js"() {
    init_registries();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/json-schema-processors.js
var init_json_schema_processors = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/json-schema-processors.js"() {
    init_to_json_schema();
    init_util();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/json-schema-generator.js
var init_json_schema_generator = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/json-schema-generator.js"() {
    init_json_schema_processors();
    init_to_json_schema();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/json-schema.js
var init_json_schema = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/json-schema.js"() {
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/index.js
var init_core2 = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/core/index.js"() {
    init_core();
    init_parse();
    init_errors();
    init_schemas();
    init_checks();
    init_versions();
    init_util();
    init_regexes();
    init_locales();
    init_registries();
    init_doc();
    init_api();
    init_to_json_schema();
    init_json_schema_processors();
    init_json_schema_generator();
    init_json_schema();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/parse.js
var init_parse2 = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/parse.js"() {
    init_core2();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/schemas.js
// @__NO_SIDE_EFFECTS__
function string2(params) {
  return _string(ZodMiniString, params);
}
// @__NO_SIDE_EFFECTS__
function url(params) {
  return _url(ZodMiniURL, params);
}
// @__NO_SIDE_EFFECTS__
function number2(params) {
  return _number(ZodMiniNumber, params);
}
// @__NO_SIDE_EFFECTS__
function int(params) {
  return _int(ZodMiniNumberFormat, params);
}
// @__NO_SIDE_EFFECTS__
function boolean2(params) {
  return _boolean(ZodMiniBoolean, params);
}
// @__NO_SIDE_EFFECTS__
function any() {
  return _any(ZodMiniAny);
}
// @__NO_SIDE_EFFECTS__
function unknown() {
  return _unknown(ZodMiniUnknown);
}
// @__NO_SIDE_EFFECTS__
function _void2(params) {
  return _void(ZodMiniVoid, params);
}
// @__NO_SIDE_EFFECTS__
function array(element, params) {
  return new ZodMiniArray({
    type: "array",
    element,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function object(shape, params) {
  const def = {
    type: "object",
    shape: shape ?? {},
    ...normalizeParams(params)
  };
  return new ZodMiniObject(def);
}
// @__NO_SIDE_EFFECTS__
function union(options, params) {
  return new ZodMiniUnion({
    type: "union",
    options,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function discriminatedUnion(discriminator, options, params) {
  return new ZodMiniDiscriminatedUnion({
    type: "union",
    options,
    discriminator,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function record(keyType, valueType, params) {
  return new ZodMiniRecord({
    type: "record",
    keyType,
    valueType,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function _enum(values, params) {
  const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
  return new ZodMiniEnum({
    type: "enum",
    entries,
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function literal(value, params) {
  return new ZodMiniLiteral({
    type: "literal",
    values: Array.isArray(value) ? value : [value],
    ...normalizeParams(params)
  });
}
// @__NO_SIDE_EFFECTS__
function transform(fn) {
  return new ZodMiniTransform({
    type: "transform",
    transform: fn
  });
}
// @__NO_SIDE_EFFECTS__
function optional(innerType) {
  return new ZodMiniOptional({
    type: "optional",
    innerType
  });
}
// @__NO_SIDE_EFFECTS__
function nullable(innerType) {
  return new ZodMiniNullable({
    type: "nullable",
    innerType
  });
}
// @__NO_SIDE_EFFECTS__
function pipe(in_, out) {
  return new ZodMiniPipe({
    type: "pipe",
    in: in_,
    out
  });
}
// @__NO_SIDE_EFFECTS__
function custom(fn, _params) {
  return _custom(ZodMiniCustom, fn ?? (() => true), _params);
}
var ZodMiniType, ZodMiniString, ZodMiniStringFormat, ZodMiniURL, ZodMiniNumber, ZodMiniNumberFormat, ZodMiniBoolean, ZodMiniBigInt, ZodMiniAny, ZodMiniUnknown, ZodMiniVoid, ZodMiniDate, ZodMiniArray, ZodMiniObject, ZodMiniUnion, ZodMiniDiscriminatedUnion, ZodMiniRecord, ZodMiniEnum, ZodMiniLiteral, ZodMiniTransform, ZodMiniOptional, ZodMiniNullable, ZodMiniPipe, ZodMiniCustom;
var init_schemas2 = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/schemas.js"() {
    init_core2();
    init_util();
    init_parse2();
    ZodMiniType = /* @__PURE__ */ $constructor("ZodMiniType", (inst, def) => {
      if (!inst._zod)
        throw new Error("Uninitialized schema in ZodMiniType.");
      $ZodType.init(inst, def);
      inst.def = def;
      inst.type = def.type;
      inst.parse = (data, params) => parse(inst, data, params, { callee: inst.parse });
      inst.safeParse = (data, params) => safeParse(inst, data, params);
      inst.parseAsync = async (data, params) => parseAsync(inst, data, params, { callee: inst.parseAsync });
      inst.safeParseAsync = async (data, params) => safeParseAsync(inst, data, params);
      inst.check = (...checks) => {
        return inst.clone({
          ...def,
          checks: [
            ...def.checks ?? [],
            ...checks.map((ch) => typeof ch === "function" ? { _zod: { check: ch, def: { check: "custom" }, onattach: [] } } : ch)
          ]
        }, { parent: true });
      };
      inst.with = inst.check;
      inst.clone = (_def, params) => clone(inst, _def, params);
      inst.brand = () => inst;
      inst.register = ((reg, meta2) => {
        reg.add(inst, meta2);
        return inst;
      });
      inst.apply = (fn) => fn(inst);
    });
    ZodMiniString = /* @__PURE__ */ $constructor("ZodMiniString", (inst, def) => {
      $ZodString.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniStringFormat = /* @__PURE__ */ $constructor("ZodMiniStringFormat", (inst, def) => {
      $ZodStringFormat.init(inst, def);
      ZodMiniString.init(inst, def);
    });
    ZodMiniURL = /* @__PURE__ */ $constructor("ZodMiniURL", (inst, def) => {
      $ZodURL.init(inst, def);
      ZodMiniStringFormat.init(inst, def);
    });
    ZodMiniNumber = /* @__PURE__ */ $constructor("ZodMiniNumber", (inst, def) => {
      $ZodNumber.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniNumberFormat = /* @__PURE__ */ $constructor("ZodMiniNumberFormat", (inst, def) => {
      $ZodNumberFormat.init(inst, def);
      ZodMiniNumber.init(inst, def);
    });
    ZodMiniBoolean = /* @__PURE__ */ $constructor("ZodMiniBoolean", (inst, def) => {
      $ZodBoolean.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniBigInt = /* @__PURE__ */ $constructor("ZodMiniBigInt", (inst, def) => {
      $ZodBigInt.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniAny = /* @__PURE__ */ $constructor("ZodMiniAny", (inst, def) => {
      $ZodAny.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniUnknown = /* @__PURE__ */ $constructor("ZodMiniUnknown", (inst, def) => {
      $ZodUnknown.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniVoid = /* @__PURE__ */ $constructor("ZodMiniVoid", (inst, def) => {
      $ZodVoid.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniDate = /* @__PURE__ */ $constructor("ZodMiniDate", (inst, def) => {
      $ZodDate.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniArray = /* @__PURE__ */ $constructor("ZodMiniArray", (inst, def) => {
      $ZodArray.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniObject = /* @__PURE__ */ $constructor("ZodMiniObject", (inst, def) => {
      $ZodObject.init(inst, def);
      ZodMiniType.init(inst, def);
      defineLazy(inst, "shape", () => def.shape);
    });
    ZodMiniUnion = /* @__PURE__ */ $constructor("ZodMiniUnion", (inst, def) => {
      $ZodUnion.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniDiscriminatedUnion = /* @__PURE__ */ $constructor("ZodMiniDiscriminatedUnion", (inst, def) => {
      $ZodDiscriminatedUnion.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniRecord = /* @__PURE__ */ $constructor("ZodMiniRecord", (inst, def) => {
      $ZodRecord.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniEnum = /* @__PURE__ */ $constructor("ZodMiniEnum", (inst, def) => {
      $ZodEnum.init(inst, def);
      ZodMiniType.init(inst, def);
      inst.options = Object.values(def.entries);
    });
    ZodMiniLiteral = /* @__PURE__ */ $constructor("ZodMiniLiteral", (inst, def) => {
      $ZodLiteral.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniTransform = /* @__PURE__ */ $constructor("ZodMiniTransform", (inst, def) => {
      $ZodTransform.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniOptional = /* @__PURE__ */ $constructor("ZodMiniOptional", (inst, def) => {
      $ZodOptional.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniNullable = /* @__PURE__ */ $constructor("ZodMiniNullable", (inst, def) => {
      $ZodNullable.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniPipe = /* @__PURE__ */ $constructor("ZodMiniPipe", (inst, def) => {
      $ZodPipe.init(inst, def);
      ZodMiniType.init(inst, def);
    });
    ZodMiniCustom = /* @__PURE__ */ $constructor("ZodMiniCustom", (inst, def) => {
      $ZodCustom.init(inst, def);
      ZodMiniType.init(inst, def);
    });
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/checks.js
var init_checks2 = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/checks.js"() {
    init_core2();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/iso.js
var init_iso = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/iso.js"() {
    init_core2();
    init_schemas2();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/coerce.js
var coerce_exports = {};
__export(coerce_exports, {
  bigint: () => bigint2,
  boolean: () => boolean3,
  date: () => date2,
  number: () => number3,
  string: () => string3
});
// @__NO_SIDE_EFFECTS__
function string3(params) {
  return _coercedString(ZodMiniString, params);
}
// @__NO_SIDE_EFFECTS__
function number3(params) {
  return _coercedNumber(ZodMiniNumber, params);
}
// @__NO_SIDE_EFFECTS__
function boolean3(params) {
  return _coercedBoolean(ZodMiniBoolean, params);
}
// @__NO_SIDE_EFFECTS__
function bigint2(params) {
  return _coercedBigint(ZodMiniBigInt, params);
}
// @__NO_SIDE_EFFECTS__
function date2(params) {
  return _coercedDate(ZodMiniDate, params);
}
var init_coerce = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/coerce.js"() {
    init_core2();
    init_schemas2();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/external.js
var init_external = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/v4/mini/external.js"() {
    init_core2();
    init_parse2();
    init_schemas2();
    init_checks2();
    init_core2();
    init_json_schema_processors();
    init_locales();
    init_iso();
    init_iso();
    init_coerce();
  }
});

// node_modules/.pnpm/zod@4.3.6/node_modules/zod/mini/index.js
var init_mini = __esm({
  "node_modules/.pnpm/zod@4.3.6/node_modules/zod/mini/index.js"() {
    init_external();
    init_external();
  }
});

// packages/core/utils/src/lib/utils.ts
var init_utils = __esm({
  "packages/core/utils/src/lib/utils.ts"() {
    "use strict";
  }
});

// packages/core/utils/src/lib/object-utils.ts
var init_object_utils = __esm({
  "packages/core/utils/src/lib/object-utils.ts"() {
    "use strict";
    init_utils();
  }
});

// packages/core/utils/src/lib/assertions.ts
var init_assertions = __esm({
  "packages/core/utils/src/lib/assertions.ts"() {
    "use strict";
  }
});

// packages/core/utils/src/lib/try-catch.ts
var init_try_catch = __esm({
  "packages/core/utils/src/lib/try-catch.ts"() {
    "use strict";
  }
});

// node_modules/.pnpm/nanoid@3.3.17/node_modules/nanoid/url-alphabet/index.js
var init_url_alphabet = __esm({
  "node_modules/.pnpm/nanoid@3.3.17/node_modules/nanoid/url-alphabet/index.js"() {
  }
});

// node_modules/.pnpm/nanoid@3.3.17/node_modules/nanoid/index.js
var import_crypto, POOL_SIZE_MULTIPLIER, pool, poolOffset, fillPool, random, customRandom, customAlphabet;
var init_nanoid = __esm({
  "node_modules/.pnpm/nanoid@3.3.17/node_modules/nanoid/index.js"() {
    import_crypto = __toESM(require("crypto"), 1);
    init_url_alphabet();
    POOL_SIZE_MULTIPLIER = 128;
    fillPool = (bytes) => {
      if (bytes < 0) throw new RangeError("Wrong ID size");
      try {
        if (!pool || pool.length < bytes) {
          pool = Buffer.allocUnsafe(bytes * POOL_SIZE_MULTIPLIER);
          import_crypto.default.randomFillSync(pool);
          poolOffset = 0;
        } else if (poolOffset + bytes > pool.length) {
          import_crypto.default.randomFillSync(pool);
          poolOffset = 0;
        }
      } catch (e) {
        pool = void 0;
        throw e;
      }
      poolOffset += bytes;
    };
    random = (bytes) => {
      fillPool(bytes |= 0);
      return pool.subarray(poolOffset - bytes, poolOffset);
    };
    customRandom = (alphabet, defaultSize, getRandom) => {
      let mask = (2 << 31 - Math.clz32(alphabet.length - 1 | 1)) - 1;
      let step = Math.ceil(1.6 * mask * defaultSize / alphabet.length);
      return (size = defaultSize) => {
        if (size <= 0) return "";
        let id = "";
        while (true) {
          let bytes = getRandom(step);
          let i = step;
          while (i--) {
            id += alphabet[bytes[i] & mask] || "";
            if (id.length === size) return id;
          }
        }
      };
    };
    customAlphabet = (alphabet, size = 21) => customRandom(alphabet, size, random);
  }
});

// packages/core/utils/src/lib/id-generator.ts
var ALPHABET, ID_LENGTH, ApId, apId;
var init_id_generator = __esm({
  "packages/core/utils/src/lib/id-generator.ts"() {
    "use strict";
    init_nanoid();
    init_mini();
    ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    ID_LENGTH = 21;
    ApId = string2().check(_regex(new RegExp(`^[0-9a-zA-Z]{${ID_LENGTH}}$`)));
    apId = customAlphabet(ALPHABET, ID_LENGTH);
  }
});

// packages/core/utils/src/lib/base-model.ts
function NullableEnum(enumObj) {
  return optional(nullable(_enum(enumObj)));
}
var DateOrString, BaseModelSchema, Nullable, OptionalBooleanFromQuery, OptionalArrayFromQuery;
var init_base_model = __esm({
  "packages/core/utils/src/lib/base-model.ts"() {
    "use strict";
    init_mini();
    DateOrString = pipe(
      transform((val) => val instanceof Date ? val.toISOString() : val),
      string2()
    );
    BaseModelSchema = {
      id: string2(),
      created: DateOrString,
      updated: DateOrString
    };
    Nullable = (schema) => optional(nullable(schema));
    OptionalBooleanFromQuery = pipe(
      transform((val) => val === "true" || val === true ? true : val === "false" || val === false ? false : void 0),
      optional(boolean2())
    );
    OptionalArrayFromQuery = (schema) => pipe(
      transform((val) => Array.isArray(val) ? val : val !== void 0 ? [val] : void 0),
      optional(array(schema))
    );
  }
});

// packages/core/utils/src/lib/metadata.ts
var Metadata;
var init_metadata = __esm({
  "packages/core/utils/src/lib/metadata.ts"() {
    "use strict";
    init_mini();
    Metadata = record(string2(), unknown());
  }
});

// packages/core/utils/src/lib/seek-page.ts
var init_seek_page = __esm({
  "packages/core/utils/src/lib/seek-page.ts"() {
    "use strict";
    init_mini();
    init_base_model();
  }
});

// packages/core/utils/src/lib/locale.ts
var init_locale = __esm({
  "packages/core/utils/src/lib/locale.ts"() {
    "use strict";
  }
});

// packages/core/utils/src/lib/permission.ts
var AIProviderName;
var init_permission = __esm({
  "packages/core/utils/src/lib/permission.ts"() {
    "use strict";
    AIProviderName = /* @__PURE__ */ ((AIProviderName3) => {
      AIProviderName3["OPENAI"] = "openai";
      AIProviderName3["OPENROUTER"] = "openrouter";
      AIProviderName3["ANTHROPIC"] = "anthropic";
      AIProviderName3["AZURE"] = "azure";
      AIProviderName3["GOOGLE"] = "google";
      AIProviderName3["ACTIVEPIECES"] = "activepieces";
      AIProviderName3["CLOUDFLARE_GATEWAY"] = "cloudflare-gateway";
      AIProviderName3["CUSTOM"] = "custom";
      AIProviderName3["BEDROCK"] = "bedrock";
      AIProviderName3["MISTRAL"] = "mistral";
      return AIProviderName3;
    })(AIProviderName || {});
  }
});

// packages/core/utils/src/lib/mustache-utils.ts
var init_mustache_utils = __esm({
  "packages/core/utils/src/lib/mustache-utils.ts"() {
    "use strict";
  }
});

// packages/core/utils/src/lib/friendly-piece-error.ts
var init_friendly_piece_error = __esm({
  "packages/core/utils/src/lib/friendly-piece-error.ts"() {
    "use strict";
    init_utils();
  }
});

// packages/core/utils/src/lib/color.ts
var ColorHex;
var init_color = __esm({
  "packages/core/utils/src/lib/color.ts"() {
    "use strict";
    init_mini();
    ColorHex = string2().check(_regex(/^#[0-9A-Fa-f]{6}$/));
  }
});

// packages/core/utils/src/lib/multipart-file.ts
var ApMultipartFile;
var init_multipart_file = __esm({
  "packages/core/utils/src/lib/multipart-file.ts"() {
    "use strict";
    init_mini();
    ApMultipartFile = object({
      filename: string2(),
      data: unknown(),
      type: literal("file"),
      mimetype: optional(string2())
    });
  }
});

// node_modules/.pnpm/ipaddr.js@2.3.0/node_modules/ipaddr.js/lib/ipaddr.js
var require_ipaddr = __commonJS({
  "node_modules/.pnpm/ipaddr.js@2.3.0/node_modules/ipaddr.js/lib/ipaddr.js"(exports2, module2) {
    (function(root) {
      "use strict";
      const ipv4Part = "(0?\\d+|0x[a-f0-9]+)";
      const ipv4Regexes = {
        fourOctet: new RegExp(`^${ipv4Part}\\.${ipv4Part}\\.${ipv4Part}\\.${ipv4Part}$`, "i"),
        threeOctet: new RegExp(`^${ipv4Part}\\.${ipv4Part}\\.${ipv4Part}$`, "i"),
        twoOctet: new RegExp(`^${ipv4Part}\\.${ipv4Part}$`, "i"),
        longValue: new RegExp(`^${ipv4Part}$`, "i")
      };
      const octalRegex = new RegExp(`^0[0-7]+$`, "i");
      const hexRegex = new RegExp(`^0x[a-f0-9]+$`, "i");
      const zoneIndex = "%[0-9a-z]{1,}";
      const ipv6Part = "(?:[0-9a-f]+::?)+";
      const ipv6Regexes = {
        zoneIndex: new RegExp(zoneIndex, "i"),
        "native": new RegExp(`^(::)?(${ipv6Part})?([0-9a-f]+)?(::)?(${zoneIndex})?$`, "i"),
        deprecatedTransitional: new RegExp(`^(?:::)(${ipv4Part}\\.${ipv4Part}\\.${ipv4Part}\\.${ipv4Part}(${zoneIndex})?)$`, "i"),
        transitional: new RegExp(`^((?:${ipv6Part})|(?:::)(?:${ipv6Part})?)${ipv4Part}\\.${ipv4Part}\\.${ipv4Part}\\.${ipv4Part}(${zoneIndex})?$`, "i")
      };
      function expandIPv6(string4, parts) {
        if (string4.indexOf("::") !== string4.lastIndexOf("::")) {
          return null;
        }
        let colonCount = 0;
        let lastColon = -1;
        let zoneId = (string4.match(ipv6Regexes.zoneIndex) || [])[0];
        let replacement, replacementCount;
        if (zoneId) {
          zoneId = zoneId.substring(1);
          string4 = string4.replace(/%.+$/, "");
        }
        while ((lastColon = string4.indexOf(":", lastColon + 1)) >= 0) {
          colonCount++;
        }
        if (string4.substr(0, 2) === "::") {
          colonCount--;
        }
        if (string4.substr(-2, 2) === "::") {
          colonCount--;
        }
        if (colonCount > parts) {
          return null;
        }
        replacementCount = parts - colonCount;
        replacement = ":";
        while (replacementCount--) {
          replacement += "0:";
        }
        string4 = string4.replace("::", replacement);
        if (string4[0] === ":") {
          string4 = string4.slice(1);
        }
        if (string4[string4.length - 1] === ":") {
          string4 = string4.slice(0, -1);
        }
        parts = (function() {
          const ref = string4.split(":");
          const results = [];
          for (let i = 0; i < ref.length; i++) {
            results.push(parseInt(ref[i], 16));
          }
          return results;
        })();
        return {
          parts,
          zoneId
        };
      }
      function matchCIDR(first, second, partSize, cidrBits) {
        if (first.length !== second.length) {
          throw new Error("ipaddr: cannot match CIDR for objects with different lengths");
        }
        let part = 0;
        let shift;
        while (cidrBits > 0) {
          shift = partSize - cidrBits;
          if (shift < 0) {
            shift = 0;
          }
          if (first[part] >> shift !== second[part] >> shift) {
            return false;
          }
          cidrBits -= partSize;
          part += 1;
        }
        return true;
      }
      function parseIntAuto(string4) {
        if (hexRegex.test(string4)) {
          return parseInt(string4, 16);
        }
        if (string4[0] === "0" && !isNaN(parseInt(string4[1], 10))) {
          if (octalRegex.test(string4)) {
            return parseInt(string4, 8);
          }
          throw new Error(`ipaddr: cannot parse ${string4} as octal`);
        }
        return parseInt(string4, 10);
      }
      function padPart(part, length) {
        while (part.length < length) {
          part = `0${part}`;
        }
        return part;
      }
      const ipaddr2 = {};
      ipaddr2.IPv4 = (function() {
        function IPv4(octets) {
          if (octets.length !== 4) {
            throw new Error("ipaddr: ipv4 octet count should be 4");
          }
          let i, octet;
          for (i = 0; i < octets.length; i++) {
            octet = octets[i];
            if (!(0 <= octet && octet <= 255)) {
              throw new Error("ipaddr: ipv4 octet should fit in 8 bits");
            }
          }
          this.octets = octets;
        }
        IPv4.prototype.SpecialRanges = {
          unspecified: [[new IPv4([0, 0, 0, 0]), 8]],
          broadcast: [[new IPv4([255, 255, 255, 255]), 32]],
          // RFC3171
          multicast: [[new IPv4([224, 0, 0, 0]), 4]],
          // RFC3927
          linkLocal: [[new IPv4([169, 254, 0, 0]), 16]],
          // RFC5735
          loopback: [[new IPv4([127, 0, 0, 0]), 8]],
          // RFC6598
          carrierGradeNat: [[new IPv4([100, 64, 0, 0]), 10]],
          // RFC1918
          "private": [
            [new IPv4([10, 0, 0, 0]), 8],
            [new IPv4([172, 16, 0, 0]), 12],
            [new IPv4([192, 168, 0, 0]), 16]
          ],
          // Reserved and testing-only ranges; RFCs 5735, 5737, 2544, 1700
          reserved: [
            [new IPv4([192, 0, 0, 0]), 24],
            [new IPv4([192, 0, 2, 0]), 24],
            [new IPv4([192, 88, 99, 0]), 24],
            [new IPv4([198, 18, 0, 0]), 15],
            [new IPv4([198, 51, 100, 0]), 24],
            [new IPv4([203, 0, 113, 0]), 24],
            [new IPv4([240, 0, 0, 0]), 4]
          ],
          // RFC7534, RFC7535
          as112: [
            [new IPv4([192, 175, 48, 0]), 24],
            [new IPv4([192, 31, 196, 0]), 24]
          ],
          // RFC7450
          amt: [
            [new IPv4([192, 52, 193, 0]), 24]
          ]
        };
        IPv4.prototype.kind = function() {
          return "ipv4";
        };
        IPv4.prototype.match = function(other, cidrRange) {
          let ref;
          if (cidrRange === void 0) {
            ref = other;
            other = ref[0];
            cidrRange = ref[1];
          }
          if (other.kind() !== "ipv4") {
            throw new Error("ipaddr: cannot match ipv4 address with non-ipv4 one");
          }
          return matchCIDR(this.octets, other.octets, 8, cidrRange);
        };
        IPv4.prototype.prefixLengthFromSubnetMask = function() {
          let cidr = 0;
          let stop = false;
          const zerotable = {
            0: 8,
            128: 7,
            192: 6,
            224: 5,
            240: 4,
            248: 3,
            252: 2,
            254: 1,
            255: 0
          };
          let i, octet, zeros;
          for (i = 3; i >= 0; i -= 1) {
            octet = this.octets[i];
            if (octet in zerotable) {
              zeros = zerotable[octet];
              if (stop && zeros !== 0) {
                return null;
              }
              if (zeros !== 8) {
                stop = true;
              }
              cidr += zeros;
            } else {
              return null;
            }
          }
          return 32 - cidr;
        };
        IPv4.prototype.range = function() {
          return ipaddr2.subnetMatch(this, this.SpecialRanges);
        };
        IPv4.prototype.toByteArray = function() {
          return this.octets.slice(0);
        };
        IPv4.prototype.toIPv4MappedAddress = function() {
          return ipaddr2.IPv6.parse(`::ffff:${this.toString()}`);
        };
        IPv4.prototype.toNormalizedString = function() {
          return this.toString();
        };
        IPv4.prototype.toString = function() {
          return this.octets.join(".");
        };
        return IPv4;
      })();
      ipaddr2.IPv4.broadcastAddressFromCIDR = function(string4) {
        try {
          const cidr = this.parseCIDR(string4);
          const ipInterfaceOctets = cidr[0].toByteArray();
          const subnetMaskOctets = this.subnetMaskFromPrefixLength(cidr[1]).toByteArray();
          const octets = [];
          let i = 0;
          while (i < 4) {
            octets.push(parseInt(ipInterfaceOctets[i], 10) | parseInt(subnetMaskOctets[i], 10) ^ 255);
            i++;
          }
          return new this(octets);
        } catch (e) {
          throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
      };
      ipaddr2.IPv4.isIPv4 = function(string4) {
        return this.parser(string4) !== null;
      };
      ipaddr2.IPv4.isValid = function(string4) {
        try {
          new this(this.parser(string4));
          return true;
        } catch (e) {
          return false;
        }
      };
      ipaddr2.IPv4.isValidCIDR = function(string4) {
        try {
          this.parseCIDR(string4);
          return true;
        } catch (e) {
          return false;
        }
      };
      ipaddr2.IPv4.isValidFourPartDecimal = function(string4) {
        if (ipaddr2.IPv4.isValid(string4) && string4.match(/^(0|[1-9]\d*)(\.(0|[1-9]\d*)){3}$/)) {
          return true;
        } else {
          return false;
        }
      };
      ipaddr2.IPv4.isValidCIDRFourPartDecimal = function(string4) {
        const match = string4.match(/^(.+)\/(\d+)$/);
        if (!ipaddr2.IPv4.isValidCIDR(string4) || !match) {
          return false;
        }
        return ipaddr2.IPv4.isValidFourPartDecimal(match[1]);
      };
      ipaddr2.IPv4.networkAddressFromCIDR = function(string4) {
        let cidr, i, ipInterfaceOctets, octets, subnetMaskOctets;
        try {
          cidr = this.parseCIDR(string4);
          ipInterfaceOctets = cidr[0].toByteArray();
          subnetMaskOctets = this.subnetMaskFromPrefixLength(cidr[1]).toByteArray();
          octets = [];
          i = 0;
          while (i < 4) {
            octets.push(parseInt(ipInterfaceOctets[i], 10) & parseInt(subnetMaskOctets[i], 10));
            i++;
          }
          return new this(octets);
        } catch (e) {
          throw new Error("ipaddr: the address does not have IPv4 CIDR format");
        }
      };
      ipaddr2.IPv4.parse = function(string4) {
        const parts = this.parser(string4);
        if (parts === null) {
          throw new Error("ipaddr: string is not formatted like an IPv4 Address");
        }
        return new this(parts);
      };
      ipaddr2.IPv4.parseCIDR = function(string4) {
        let match;
        if (match = string4.match(/^(.+)\/(\d+)$/)) {
          const maskLength = parseInt(match[2]);
          if (maskLength >= 0 && maskLength <= 32) {
            const parsed = [this.parse(match[1]), maskLength];
            Object.defineProperty(parsed, "toString", {
              value: function() {
                return this.join("/");
              }
            });
            return parsed;
          }
        }
        throw new Error("ipaddr: string is not formatted like an IPv4 CIDR range");
      };
      ipaddr2.IPv4.parser = function(string4) {
        let match, part, value;
        if (match = string4.match(ipv4Regexes.fourOctet)) {
          return (function() {
            const ref = match.slice(1, 6);
            const results = [];
            for (let i = 0; i < ref.length; i++) {
              part = ref[i];
              results.push(parseIntAuto(part));
            }
            return results;
          })();
        } else if (match = string4.match(ipv4Regexes.longValue)) {
          value = parseIntAuto(match[1]);
          if (value > 4294967295 || value < 0) {
            throw new Error("ipaddr: address outside defined range");
          }
          return (function() {
            const results = [];
            let shift;
            for (shift = 0; shift <= 24; shift += 8) {
              results.push(value >> shift & 255);
            }
            return results;
          })().reverse();
        } else if (match = string4.match(ipv4Regexes.twoOctet)) {
          return (function() {
            const ref = match.slice(1, 4);
            const results = [];
            value = parseIntAuto(ref[1]);
            if (value > 16777215 || value < 0) {
              throw new Error("ipaddr: address outside defined range");
            }
            results.push(parseIntAuto(ref[0]));
            results.push(value >> 16 & 255);
            results.push(value >> 8 & 255);
            results.push(value & 255);
            return results;
          })();
        } else if (match = string4.match(ipv4Regexes.threeOctet)) {
          return (function() {
            const ref = match.slice(1, 5);
            const results = [];
            value = parseIntAuto(ref[2]);
            if (value > 65535 || value < 0) {
              throw new Error("ipaddr: address outside defined range");
            }
            results.push(parseIntAuto(ref[0]));
            results.push(parseIntAuto(ref[1]));
            results.push(value >> 8 & 255);
            results.push(value & 255);
            return results;
          })();
        } else {
          return null;
        }
      };
      ipaddr2.IPv4.subnetMaskFromPrefixLength = function(prefix) {
        prefix = parseInt(prefix);
        if (prefix < 0 || prefix > 32) {
          throw new Error("ipaddr: invalid IPv4 prefix length");
        }
        const octets = [0, 0, 0, 0];
        let j = 0;
        const filledOctetCount = Math.floor(prefix / 8);
        while (j < filledOctetCount) {
          octets[j] = 255;
          j++;
        }
        if (filledOctetCount < 4) {
          octets[filledOctetCount] = Math.pow(2, prefix % 8) - 1 << 8 - prefix % 8;
        }
        return new this(octets);
      };
      ipaddr2.IPv6 = (function() {
        function IPv6(parts, zoneId) {
          let i, part;
          if (parts.length === 16) {
            this.parts = [];
            for (i = 0; i <= 14; i += 2) {
              this.parts.push(parts[i] << 8 | parts[i + 1]);
            }
          } else if (parts.length === 8) {
            this.parts = parts;
          } else {
            throw new Error("ipaddr: ipv6 part count should be 8 or 16");
          }
          for (i = 0; i < this.parts.length; i++) {
            part = this.parts[i];
            if (!(0 <= part && part <= 65535)) {
              throw new Error("ipaddr: ipv6 part should fit in 16 bits");
            }
          }
          if (zoneId) {
            this.zoneId = zoneId;
          }
        }
        IPv6.prototype.SpecialRanges = {
          // RFC4291, here and after
          unspecified: [new IPv6([0, 0, 0, 0, 0, 0, 0, 0]), 128],
          linkLocal: [new IPv6([65152, 0, 0, 0, 0, 0, 0, 0]), 10],
          multicast: [new IPv6([65280, 0, 0, 0, 0, 0, 0, 0]), 8],
          loopback: [new IPv6([0, 0, 0, 0, 0, 0, 0, 1]), 128],
          uniqueLocal: [new IPv6([64512, 0, 0, 0, 0, 0, 0, 0]), 7],
          ipv4Mapped: [new IPv6([0, 0, 0, 0, 0, 65535, 0, 0]), 96],
          // RFC6666
          discard: [new IPv6([256, 0, 0, 0, 0, 0, 0, 0]), 64],
          // RFC6145
          rfc6145: [new IPv6([0, 0, 0, 0, 65535, 0, 0, 0]), 96],
          // RFC6052
          rfc6052: [new IPv6([100, 65435, 0, 0, 0, 0, 0, 0]), 96],
          // RFC3056
          "6to4": [new IPv6([8194, 0, 0, 0, 0, 0, 0, 0]), 16],
          // RFC6052, RFC6146
          teredo: [new IPv6([8193, 0, 0, 0, 0, 0, 0, 0]), 32],
          // RFC5180
          benchmarking: [new IPv6([8193, 2, 0, 0, 0, 0, 0, 0]), 48],
          // RFC7450
          amt: [new IPv6([8193, 3, 0, 0, 0, 0, 0, 0]), 32],
          as112v6: [
            [new IPv6([8193, 4, 274, 0, 0, 0, 0, 0]), 48],
            [new IPv6([9760, 79, 32768, 0, 0, 0, 0, 0]), 48]
          ],
          deprecated: [new IPv6([8193, 16, 0, 0, 0, 0, 0, 0]), 28],
          orchid2: [new IPv6([8193, 32, 0, 0, 0, 0, 0, 0]), 28],
          droneRemoteIdProtocolEntityTags: [new IPv6([8193, 48, 0, 0, 0, 0, 0, 0]), 28],
          reserved: [
            // RFC3849
            [new IPv6([8193, 0, 0, 0, 0, 0, 0, 0]), 23],
            // RFC2928
            [new IPv6([8193, 3512, 0, 0, 0, 0, 0, 0]), 32]
          ]
        };
        IPv6.prototype.isIPv4MappedAddress = function() {
          return this.range() === "ipv4Mapped";
        };
        IPv6.prototype.kind = function() {
          return "ipv6";
        };
        IPv6.prototype.match = function(other, cidrRange) {
          let ref;
          if (cidrRange === void 0) {
            ref = other;
            other = ref[0];
            cidrRange = ref[1];
          }
          if (other.kind() !== "ipv6") {
            throw new Error("ipaddr: cannot match ipv6 address with non-ipv6 one");
          }
          return matchCIDR(this.parts, other.parts, 16, cidrRange);
        };
        IPv6.prototype.prefixLengthFromSubnetMask = function() {
          let cidr = 0;
          let stop = false;
          const zerotable = {
            0: 16,
            32768: 15,
            49152: 14,
            57344: 13,
            61440: 12,
            63488: 11,
            64512: 10,
            65024: 9,
            65280: 8,
            65408: 7,
            65472: 6,
            65504: 5,
            65520: 4,
            65528: 3,
            65532: 2,
            65534: 1,
            65535: 0
          };
          let part, zeros;
          for (let i = 7; i >= 0; i -= 1) {
            part = this.parts[i];
            if (part in zerotable) {
              zeros = zerotable[part];
              if (stop && zeros !== 0) {
                return null;
              }
              if (zeros !== 16) {
                stop = true;
              }
              cidr += zeros;
            } else {
              return null;
            }
          }
          return 128 - cidr;
        };
        IPv6.prototype.range = function() {
          return ipaddr2.subnetMatch(this, this.SpecialRanges);
        };
        IPv6.prototype.toByteArray = function() {
          let part;
          const bytes = [];
          const ref = this.parts;
          for (let i = 0; i < ref.length; i++) {
            part = ref[i];
            bytes.push(part >> 8);
            bytes.push(part & 255);
          }
          return bytes;
        };
        IPv6.prototype.toFixedLengthString = function() {
          const addr = (function() {
            const results = [];
            for (let i = 0; i < this.parts.length; i++) {
              results.push(padPart(this.parts[i].toString(16), 4));
            }
            return results;
          }).call(this).join(":");
          let suffix = "";
          if (this.zoneId) {
            suffix = `%${this.zoneId}`;
          }
          return addr + suffix;
        };
        IPv6.prototype.toIPv4Address = function() {
          if (!this.isIPv4MappedAddress()) {
            throw new Error("ipaddr: trying to convert a generic ipv6 address to ipv4");
          }
          const ref = this.parts.slice(-2);
          const high = ref[0];
          const low = ref[1];
          return new ipaddr2.IPv4([high >> 8, high & 255, low >> 8, low & 255]);
        };
        IPv6.prototype.toNormalizedString = function() {
          const addr = (function() {
            const results = [];
            for (let i = 0; i < this.parts.length; i++) {
              results.push(this.parts[i].toString(16));
            }
            return results;
          }).call(this).join(":");
          let suffix = "";
          if (this.zoneId) {
            suffix = `%${this.zoneId}`;
          }
          return addr + suffix;
        };
        IPv6.prototype.toRFC5952String = function() {
          const regex = /((^|:)(0(:|$)){2,})/g;
          const string4 = this.toNormalizedString();
          let bestMatchIndex = 0;
          let bestMatchLength = -1;
          let match;
          while (match = regex.exec(string4)) {
            if (match[0].length > bestMatchLength) {
              bestMatchIndex = match.index;
              bestMatchLength = match[0].length;
            }
          }
          if (bestMatchLength < 0) {
            return string4;
          }
          return `${string4.substring(0, bestMatchIndex)}::${string4.substring(bestMatchIndex + bestMatchLength)}`;
        };
        IPv6.prototype.toString = function() {
          return this.toRFC5952String();
        };
        return IPv6;
      })();
      ipaddr2.IPv6.broadcastAddressFromCIDR = function(string4) {
        try {
          const cidr = this.parseCIDR(string4);
          const ipInterfaceOctets = cidr[0].toByteArray();
          const subnetMaskOctets = this.subnetMaskFromPrefixLength(cidr[1]).toByteArray();
          const octets = [];
          let i = 0;
          while (i < 16) {
            octets.push(parseInt(ipInterfaceOctets[i], 10) | parseInt(subnetMaskOctets[i], 10) ^ 255);
            i++;
          }
          return new this(octets);
        } catch (e) {
          throw new Error(`ipaddr: the address does not have IPv6 CIDR format (${e})`);
        }
      };
      ipaddr2.IPv6.isIPv6 = function(string4) {
        return this.parser(string4) !== null;
      };
      ipaddr2.IPv6.isValid = function(string4) {
        if (typeof string4 === "string" && string4.indexOf(":") === -1) {
          return false;
        }
        try {
          const addr = this.parser(string4);
          new this(addr.parts, addr.zoneId);
          return true;
        } catch (e) {
          return false;
        }
      };
      ipaddr2.IPv6.isValidCIDR = function(string4) {
        if (typeof string4 === "string" && string4.indexOf(":") === -1) {
          return false;
        }
        try {
          this.parseCIDR(string4);
          return true;
        } catch (e) {
          return false;
        }
      };
      ipaddr2.IPv6.networkAddressFromCIDR = function(string4) {
        let cidr, i, ipInterfaceOctets, octets, subnetMaskOctets;
        try {
          cidr = this.parseCIDR(string4);
          ipInterfaceOctets = cidr[0].toByteArray();
          subnetMaskOctets = this.subnetMaskFromPrefixLength(cidr[1]).toByteArray();
          octets = [];
          i = 0;
          while (i < 16) {
            octets.push(parseInt(ipInterfaceOctets[i], 10) & parseInt(subnetMaskOctets[i], 10));
            i++;
          }
          return new this(octets);
        } catch (e) {
          throw new Error(`ipaddr: the address does not have IPv6 CIDR format (${e})`);
        }
      };
      ipaddr2.IPv6.parse = function(string4) {
        const addr = this.parser(string4);
        if (addr.parts === null) {
          throw new Error("ipaddr: string is not formatted like an IPv6 Address");
        }
        return new this(addr.parts, addr.zoneId);
      };
      ipaddr2.IPv6.parseCIDR = function(string4) {
        let maskLength, match, parsed;
        if (match = string4.match(/^(.+)\/(\d+)$/)) {
          maskLength = parseInt(match[2]);
          if (maskLength >= 0 && maskLength <= 128) {
            parsed = [this.parse(match[1]), maskLength];
            Object.defineProperty(parsed, "toString", {
              value: function() {
                return this.join("/");
              }
            });
            return parsed;
          }
        }
        throw new Error("ipaddr: string is not formatted like an IPv6 CIDR range");
      };
      ipaddr2.IPv6.parser = function(string4) {
        let addr, i, match, octet, octets, zoneId;
        if (match = string4.match(ipv6Regexes.deprecatedTransitional)) {
          return this.parser(`::ffff:${match[1]}`);
        }
        if (ipv6Regexes.native.test(string4)) {
          return expandIPv6(string4, 8);
        }
        if (match = string4.match(ipv6Regexes.transitional)) {
          zoneId = match[6] || "";
          addr = match[1];
          if (!match[1].endsWith("::")) {
            addr = addr.slice(0, -1);
          }
          addr = expandIPv6(addr + zoneId, 6);
          if (addr.parts) {
            octets = [
              parseInt(match[2]),
              parseInt(match[3]),
              parseInt(match[4]),
              parseInt(match[5])
            ];
            for (i = 0; i < octets.length; i++) {
              octet = octets[i];
              if (!(0 <= octet && octet <= 255)) {
                return null;
              }
            }
            addr.parts.push(octets[0] << 8 | octets[1]);
            addr.parts.push(octets[2] << 8 | octets[3]);
            return {
              parts: addr.parts,
              zoneId: addr.zoneId
            };
          }
        }
        return null;
      };
      ipaddr2.IPv6.subnetMaskFromPrefixLength = function(prefix) {
        prefix = parseInt(prefix);
        if (prefix < 0 || prefix > 128) {
          throw new Error("ipaddr: invalid IPv6 prefix length");
        }
        const octets = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
        let j = 0;
        const filledOctetCount = Math.floor(prefix / 8);
        while (j < filledOctetCount) {
          octets[j] = 255;
          j++;
        }
        if (filledOctetCount < 16) {
          octets[filledOctetCount] = Math.pow(2, prefix % 8) - 1 << 8 - prefix % 8;
        }
        return new this(octets);
      };
      ipaddr2.fromByteArray = function(bytes) {
        const length = bytes.length;
        if (length === 4) {
          return new ipaddr2.IPv4(bytes);
        } else if (length === 16) {
          return new ipaddr2.IPv6(bytes);
        } else {
          throw new Error("ipaddr: the binary input is neither an IPv6 nor IPv4 address");
        }
      };
      ipaddr2.isValid = function(string4) {
        return ipaddr2.IPv6.isValid(string4) || ipaddr2.IPv4.isValid(string4);
      };
      ipaddr2.isValidCIDR = function(string4) {
        return ipaddr2.IPv6.isValidCIDR(string4) || ipaddr2.IPv4.isValidCIDR(string4);
      };
      ipaddr2.parse = function(string4) {
        if (ipaddr2.IPv6.isValid(string4)) {
          return ipaddr2.IPv6.parse(string4);
        } else if (ipaddr2.IPv4.isValid(string4)) {
          return ipaddr2.IPv4.parse(string4);
        } else {
          throw new Error("ipaddr: the address has neither IPv6 nor IPv4 format");
        }
      };
      ipaddr2.parseCIDR = function(string4) {
        try {
          return ipaddr2.IPv6.parseCIDR(string4);
        } catch (e) {
          try {
            return ipaddr2.IPv4.parseCIDR(string4);
          } catch (e2) {
            throw new Error("ipaddr: the address has neither IPv6 nor IPv4 CIDR format");
          }
        }
      };
      ipaddr2.process = function(string4) {
        const addr = this.parse(string4);
        if (addr.kind() === "ipv6" && addr.isIPv4MappedAddress()) {
          return addr.toIPv4Address();
        } else {
          return addr;
        }
      };
      ipaddr2.subnetMatch = function(address, rangeList, defaultName) {
        let i, rangeName, rangeSubnets, subnet;
        if (defaultName === void 0 || defaultName === null) {
          defaultName = "unicast";
        }
        for (rangeName in rangeList) {
          if (Object.prototype.hasOwnProperty.call(rangeList, rangeName)) {
            rangeSubnets = rangeList[rangeName];
            if (rangeSubnets[0] && !(rangeSubnets[0] instanceof Array)) {
              rangeSubnets = [rangeSubnets];
            }
            for (i = 0; i < rangeSubnets.length; i++) {
              subnet = rangeSubnets[i];
              if (address.kind() === subnet[0].kind() && address.match.apply(address, subnet)) {
                return rangeName;
              }
            }
          }
        }
        return defaultName;
      };
      if (typeof module2 !== "undefined" && module2.exports) {
        module2.exports = ipaddr2;
      } else {
        root.ipaddr = ipaddr2;
      }
    })(exports2);
  }
});

// packages/core/utils/src/lib/ssrf-ip-classifier.ts
var import_ipaddr;
var init_ssrf_ip_classifier = __esm({
  "packages/core/utils/src/lib/ssrf-ip-classifier.ts"() {
    "use strict";
    import_ipaddr = __toESM(require_ipaddr());
  }
});

// packages/core/utils/src/lib/project-role.ts
var ProjectRole;
var init_project_role = __esm({
  "packages/core/utils/src/lib/project-role.ts"() {
    "use strict";
    init_mini();
    init_base_model();
    ProjectRole = object({
      ...BaseModelSchema,
      name: string2(),
      permissions: array(string2()),
      platformId: Nullable(string2()),
      type: string2(),
      userCount: optional(number2())
    });
  }
});

// packages/core/utils/src/lib/activepieces-error.ts
var init_activepieces_error = __esm({
  "packages/core/utils/src/lib/activepieces-error.ts"() {
    "use strict";
  }
});

// packages/core/utils/src/lib/form-errors.ts
var init_form_errors = __esm({
  "packages/core/utils/src/lib/form-errors.ts"() {
    "use strict";
  }
});

// packages/core/utils/src/lib/byte-lru-cache.ts
var init_byte_lru_cache = __esm({
  "packages/core/utils/src/lib/byte-lru-cache.ts"() {
    "use strict";
    init_utils();
  }
});

// packages/core/utils/src/index.ts
var init_src = __esm({
  "packages/core/utils/src/index.ts"() {
    "use strict";
    init_utils();
    init_object_utils();
    init_assertions();
    init_try_catch();
    init_id_generator();
    init_base_model();
    init_metadata();
    init_seek_page();
    init_locale();
    init_permission();
    init_mustache_utils();
    init_friendly_piece_error();
    init_color();
    init_multipart_file();
    init_ssrf_ip_classifier();
    init_project_role();
    init_activepieces_error();
    init_form_errors();
    init_byte_lru_cache();
  }
});

// packages/pieces/community/hash-helper/src/index.ts
var index_exports = {};
__export(index_exports, {
  hashHelper: () => hashHelper
});
module.exports = __toCommonJS(index_exports);

// packages/pieces/framework/src/lib/action/action.ts
init_mini();
var ErrorHandlingOptionsParam = object({
  retryOnFailure: object({
    defaultValue: optional(boolean2()),
    hide: optional(boolean2())
  }),
  continueOnFailure: object({
    defaultValue: optional(boolean2()),
    hide: optional(boolean2())
  })
});
var IAction = class {
  constructor(name, displayName, description, props, run, test, requireAuth, errorHandlingOptions, outputSchema, audience, aiMetadata) {
    this.name = name;
    this.displayName = displayName;
    this.description = description;
    this.props = props;
    this.run = run;
    this.test = test;
    this.requireAuth = requireAuth;
    this.errorHandlingOptions = errorHandlingOptions;
    this.outputSchema = outputSchema;
    this.audience = audience;
    this.aiMetadata = aiMetadata;
  }
};
var createAction = (params) => {
  return new IAction(
    params.name,
    params.displayName,
    params.description,
    params.props,
    params.run,
    params.test ?? params.run,
    params.requireAuth ?? true,
    params.errorHandlingOptions ?? {
      continueOnFailure: {
        defaultValue: false
      },
      retryOnFailure: {
        defaultValue: false
      }
    },
    params.outputSchema,
    params.audience,
    params.aiMetadata
  );
};

// packages/pieces/framework/src/lib/property/input/index.ts
init_mini();

// packages/pieces/framework/src/lib/property/input/array-property.ts
init_mini();

// packages/pieces/framework/src/lib/property/input/common.ts
init_mini();
var BasePropertySchema = object({
  displayName: string2(),
  description: optional(string2())
});
var TPropertyValue = (_T, propertyType) => object({
  type: literal(propertyType),
  required: boolean2(),
  defaultValue: optional(any())
});

// packages/pieces/framework/src/lib/property/input/text-property.ts
init_mini();
var ShortTextProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(string2(), "SHORT_TEXT" /* SHORT_TEXT */).shape
});
var LongTextProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(string2(), "LONG_TEXT" /* LONG_TEXT */).shape
});

// packages/pieces/framework/src/lib/property/input/dropdown/static-dropdown.ts
init_mini();

// packages/pieces/framework/src/lib/property/input/dropdown/common.ts
init_mini();
var DropdownOption = object({
  label: string2(),
  value: unknown()
});
var DropdownState = object({
  disabled: optional(boolean2()),
  placeholder: optional(string2()),
  options: array(DropdownOption)
});

// packages/pieces/framework/src/lib/property/input/dropdown/static-dropdown.ts
var StaticDropdownProperty = object({
  ...BasePropertySchema.shape,
  options: DropdownState,
  ...TPropertyValue(unknown(), "STATIC_DROPDOWN" /* STATIC_DROPDOWN */).shape
});
var StaticMultiSelectDropdownProperty = object({
  ...BasePropertySchema.shape,
  options: DropdownState,
  ...TPropertyValue(array(unknown()), "STATIC_MULTI_SELECT_DROPDOWN" /* STATIC_MULTI_SELECT_DROPDOWN */).shape
});

// packages/pieces/framework/src/lib/property/input/dropdown/dropdown-prop.ts
init_mini();
var DropdownProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(unknown(), "DROPDOWN" /* DROPDOWN */).shape,
  refreshers: array(string2())
});
var MultiSelectDropdownProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(array(unknown()), "MULTI_SELECT_DROPDOWN" /* MULTI_SELECT_DROPDOWN */).shape,
  refreshers: array(string2())
});

// packages/pieces/framework/src/lib/property/input/checkbox-property.ts
init_mini();
var CheckboxProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(boolean2(), "CHECKBOX" /* CHECKBOX */).shape
});

// packages/pieces/framework/src/lib/property/input/number-property.ts
init_mini();
var NumberProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(number2(), "NUMBER" /* NUMBER */).shape
});

// packages/pieces/framework/src/lib/property/input/file-property.ts
init_mini();
var FileProperty = object({
  ...BasePropertySchema.shape,
  streaming: optional(boolean2()),
  ...TPropertyValue(unknown(), "FILE" /* FILE */).shape
});

// packages/pieces/framework/src/lib/property/input/date-time-property.ts
init_mini();
var DateTimeProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(string2(), "DATE_TIME" /* DATE_TIME */).shape
});

// packages/pieces/framework/src/lib/property/input/array-property.ts
var ArraySubProps = record(string2(), union([
  ShortTextProperty,
  LongTextProperty,
  StaticDropdownProperty,
  MultiSelectDropdownProperty,
  StaticMultiSelectDropdownProperty,
  CheckboxProperty,
  NumberProperty,
  FileProperty,
  DateTimeProperty
]));
var ArrayProperty = object({
  ...BasePropertySchema.shape,
  properties: ArraySubProps,
  ...TPropertyValue(array(unknown()), "ARRAY" /* ARRAY */).shape
});

// packages/pieces/framework/src/lib/property/input/dynamic-prop.ts
init_mini();

// packages/pieces/framework/src/lib/property/input/json-property.ts
init_mini();
var JsonProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(
    union([record(string2(), unknown())]),
    "JSON" /* JSON */
  ).shape
});

// packages/pieces/framework/src/lib/property/input/dynamic-prop.ts
var DynamicProp = union([
  ShortTextProperty,
  StaticDropdownProperty,
  JsonProperty,
  ArrayProperty,
  StaticMultiSelectDropdownProperty
]);
var DynamicPropsValue = record(string2(), DynamicProp);
var DynamicProperties = object({
  refreshers: array(string2()),
  ...BasePropertySchema.shape,
  ...TPropertyValue(unknown(), "DYNAMIC" /* DYNAMIC */).shape
});

// packages/pieces/framework/src/lib/property/input/markdown-property.ts
init_mini();
var MarkDownProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(_void2(), "MARKDOWN" /* MARKDOWN */).shape
});

// packages/core/piece-types/src/lib/piece.ts
var PackageType = /* @__PURE__ */ ((PackageType2) => {
  PackageType2["ARCHIVE"] = "ARCHIVE";
  PackageType2["REGISTRY"] = "REGISTRY";
  return PackageType2;
})(PackageType || {});
var PieceType = /* @__PURE__ */ ((PieceType2) => {
  PieceType2["CUSTOM"] = "CUSTOM";
  PieceType2["OFFICIAL"] = "OFFICIAL";
  return PieceType2;
})(PieceType || {});
var PieceCategory = /* @__PURE__ */ ((PieceCategory2) => {
  PieceCategory2["ARTIFICIAL_INTELLIGENCE"] = "ARTIFICIAL_INTELLIGENCE";
  PieceCategory2["COMMUNICATION"] = "COMMUNICATION";
  PieceCategory2["COMMERCE"] = "COMMERCE";
  PieceCategory2["CORE"] = "CORE";
  PieceCategory2["UNIVERSAL_AI"] = "UNIVERSAL_AI";
  PieceCategory2["FLOW_CONTROL"] = "FLOW_CONTROL";
  PieceCategory2["BUSINESS_INTELLIGENCE"] = "BUSINESS_INTELLIGENCE";
  PieceCategory2["ACCOUNTING"] = "ACCOUNTING";
  PieceCategory2["PRODUCTIVITY"] = "PRODUCTIVITY";
  PieceCategory2["CONTENT_AND_FILES"] = "CONTENT_AND_FILES";
  PieceCategory2["DEVELOPER_TOOLS"] = "DEVELOPER_TOOLS";
  PieceCategory2["CUSTOMER_SUPPORT"] = "CUSTOMER_SUPPORT";
  PieceCategory2["FORMS_AND_SURVEYS"] = "FORMS_AND_SURVEYS";
  PieceCategory2["HUMAN_RESOURCES"] = "HUMAN_RESOURCES";
  PieceCategory2["PAYMENT_PROCESSING"] = "PAYMENT_PROCESSING";
  PieceCategory2["MARKETING"] = "MARKETING";
  PieceCategory2["SALES_AND_CRM"] = "SALES_AND_CRM";
  return PieceCategory2;
})(PieceCategory || {});

// packages/core/piece-types/src/lib/app-connection.ts
var OAuth2GrantType = /* @__PURE__ */ ((OAuth2GrantType2) => {
  OAuth2GrantType2["AUTHORIZATION_CODE"] = "authorization_code";
  OAuth2GrantType2["CLIENT_CREDENTIALS"] = "client_credentials";
  return OAuth2GrantType2;
})(OAuth2GrantType || {});
var BOTH_CLIENT_CREDENTIALS_AND_AUTHORIZATION_CODE = "both_client_credentials_and_authorization_code";

// packages/core/piece-types/src/lib/trigger.ts
init_mini();
var TriggerStrategy = /* @__PURE__ */ ((TriggerStrategy3) => {
  TriggerStrategy3["POLLING"] = "POLLING";
  TriggerStrategy3["WEBHOOK"] = "WEBHOOK";
  TriggerStrategy3["APP_WEBHOOK"] = "APP_WEBHOOK";
  TriggerStrategy3["MANUAL"] = "MANUAL";
  return TriggerStrategy3;
})(TriggerStrategy || {});
var WebhookHandshakeStrategy = /* @__PURE__ */ ((WebhookHandshakeStrategy2) => {
  WebhookHandshakeStrategy2["NONE"] = "NONE";
  WebhookHandshakeStrategy2["HEADER_PRESENT"] = "HEADER_PRESENT";
  WebhookHandshakeStrategy2["QUERY_PRESENT"] = "QUERY_PRESENT";
  WebhookHandshakeStrategy2["BODY_PARAM_PRESENT"] = "BODY_PARAM_PRESENT";
  WebhookHandshakeStrategy2["HEAD_REQUEST"] = "HEAD_REQUEST";
  return WebhookHandshakeStrategy2;
})(WebhookHandshakeStrategy || {});
var WebhookHandshakeConfiguration = object({
  strategy: _enum(WebhookHandshakeStrategy),
  paramName: optional(string2())
});
var TriggerTestStrategy = /* @__PURE__ */ ((TriggerTestStrategy2) => {
  TriggerTestStrategy2["SIMULATION"] = "SIMULATION";
  TriggerTestStrategy2["TEST_FUNCTION"] = "TEST_FUNCTION";
  return TriggerTestStrategy2;
})(TriggerTestStrategy || {});

// packages/core/piece-types/src/lib/execution.ts
init_mini();
var StreamStepProgress = /* @__PURE__ */ ((StreamStepProgress2) => {
  StreamStepProgress2["WEBSOCKET"] = "WEBSOCKET";
  StreamStepProgress2["NONE"] = "NONE";
  return StreamStepProgress2;
})(StreamStepProgress || {});
var RespondResponse = object({
  status: optional(number2()),
  body: optional(unknown()),
  headers: optional(record(string2(), string2()))
});
var DelayPauseMetadata = object({
  type: literal("DELAY" /* DELAY */),
  resumeDateTime: string2(),
  requestIdToReply: optional(string2()),
  handlerId: optional(string2()),
  streamStepProgress: optional(_enum(StreamStepProgress))
});
var WebhookPauseMetadata = object({
  type: literal("WEBHOOK" /* WEBHOOK */),
  requestId: string2(),
  requestIdToReply: optional(string2()),
  response: RespondResponse,
  handlerId: optional(string2()),
  streamStepProgress: optional(_enum(StreamStepProgress))
});
var PauseMetadata = union([DelayPauseMetadata, WebhookPauseMetadata]);

// packages/core/piece-types/src/lib/engine.ts
init_mini();
var TriggerPayload = object({
  body: unknown(),
  rawBody: optional(unknown()),
  headers: record(string2(), string2()),
  queryParams: record(string2(), string2())
});

// packages/core/piece-types/src/lib/agents.ts
init_src();
init_mini();
var FieldControlMode = /* @__PURE__ */ ((FieldControlMode2) => {
  FieldControlMode2["AGENT_DECIDE"] = "agent-decide";
  FieldControlMode2["CHOOSE_YOURSELF"] = "choose-yourself";
  FieldControlMode2["LEAVE_EMPTY"] = "leave-empty";
  return FieldControlMode2;
})(FieldControlMode || {});
var KnowledgeBaseSourceType = /* @__PURE__ */ ((KnowledgeBaseSourceType2) => {
  KnowledgeBaseSourceType2["FILE"] = "FILE";
  KnowledgeBaseSourceType2["TABLE"] = "TABLE";
  return KnowledgeBaseSourceType2;
})(KnowledgeBaseSourceType || {});
var McpProtocol = /* @__PURE__ */ ((McpProtocol2) => {
  McpProtocol2["SSE"] = "sse";
  McpProtocol2["STREAMABLE_HTTP"] = "streamable-http";
  McpProtocol2["SIMPLE_HTTP"] = "http";
  return McpProtocol2;
})(McpProtocol || {});
var AgentOutputFieldType = /* @__PURE__ */ ((AgentOutputFieldType2) => {
  AgentOutputFieldType2["TEXT"] = "text";
  AgentOutputFieldType2["NUMBER"] = "number";
  AgentOutputFieldType2["BOOLEAN"] = "boolean";
  return AgentOutputFieldType2;
})(AgentOutputFieldType || {});
var ToolCallStatus = /* @__PURE__ */ ((ToolCallStatus2) => {
  ToolCallStatus2["IN_PROGRESS"] = "in-progress";
  ToolCallStatus2["COMPLETED"] = "completed";
  return ToolCallStatus2;
})(ToolCallStatus || {});
var PredefinedInputField = object({
  mode: _enum(FieldControlMode),
  value: unknown()
});
var PredefinedInputsStructure = object({
  auth: optional(string2()),
  fields: record(string2(), PredefinedInputField)
});
var AgentPieceToolMetadata = object({
  pieceName: string2(),
  pieceVersion: string2(),
  actionName: string2(),
  predefinedInput: optional(PredefinedInputsStructure)
});
var AgentPieceTool = object({
  type: literal("PIECE" /* PIECE */),
  toolName: string2().check(_minLength(1)),
  pieceMetadata: AgentPieceToolMetadata
});
var McpAuthNone = object({
  type: literal("none" /* NONE */)
});
var McpAuthAccessToken = object({
  type: literal("access_token" /* ACCESS_TOKEN */),
  accessToken: string2()
});
var McpAuthApiKey = object({
  type: literal("api_key" /* API_KEY */),
  apiKey: string2(),
  apiKeyHeader: string2()
});
var McpAuthHeaders = object({
  type: literal("headers" /* HEADERS */),
  headers: record(string2(), string2())
});
var McpAuthConfig = discriminatedUnion("type", [
  McpAuthNone,
  McpAuthAccessToken,
  McpAuthApiKey,
  McpAuthHeaders
]);
var AgentFlowTool = object({
  type: literal("FLOW" /* FLOW */),
  toolName: string2().check(_minLength(1)),
  externalFlowId: string2(),
  flowDisplayName: optional(string2())
});
var AgentMcpTool = object({
  type: literal("MCP" /* MCP */),
  toolName: string2().check(_minLength(1)),
  serverUrl: url(),
  protocol: _enum(McpProtocol),
  auth: McpAuthConfig
});
var AgentKnowledgeBaseTool = object({
  type: literal("KNOWLEDGE_BASE" /* KNOWLEDGE_BASE */),
  toolName: string2().check(_minLength(1)),
  sourceType: _enum(KnowledgeBaseSourceType),
  sourceId: string2(),
  sourceName: string2()
});
var AgentTool = discriminatedUnion("type", [
  AgentPieceTool,
  AgentFlowTool,
  AgentMcpTool,
  AgentKnowledgeBaseTool
]);
var AgentOutputField = object({
  displayName: string2(),
  description: optional(string2()),
  type: _enum(AgentOutputFieldType)
});
var MarkdownContentBlock = object({
  type: literal("MARKDOWN" /* MARKDOWN */),
  markdown: string2()
});
var toolCallBaseShape = {
  type: literal("TOOL_CALL" /* TOOL_CALL */),
  input: Nullable(record(string2(), unknown())),
  output: optional(unknown()),
  toolName: string2(),
  status: _enum(ToolCallStatus),
  toolCallId: string2(),
  startTime: string2(),
  endTime: optional(string2())
};
var toolCallBaseSchema = object(toolCallBaseShape);
var ToolCallContentBlock = discriminatedUnion("toolCallType", [
  object({
    ...toolCallBaseShape,
    toolCallType: literal("PIECE" /* PIECE */),
    pieceName: string2(),
    pieceVersion: string2(),
    actionName: string2()
  }),
  object({
    ...toolCallBaseShape,
    toolCallType: literal("FLOW" /* FLOW */),
    displayName: string2(),
    externalFlowId: string2()
  }),
  object({
    ...toolCallBaseShape,
    toolCallType: literal("MCP" /* MCP */),
    displayName: string2(),
    serverUrl: string2()
  }),
  object({
    ...toolCallBaseShape,
    toolCallType: literal("KNOWLEDGE_BASE" /* KNOWLEDGE_BASE */),
    displayName: string2(),
    sourceType: string2()
  }),
  object({
    ...toolCallBaseShape,
    toolCallType: literal("UNKNOWN" /* UNKNOWN */),
    displayName: string2()
  })
]);
var AgentStepBlock = union([MarkdownContentBlock, ToolCallContentBlock]);

// packages/core/piece-types/src/lib/ai-providers.ts
init_src();
init_mini();
var AIProviderModelType = /* @__PURE__ */ ((AIProviderModelType2) => {
  AIProviderModelType2["IMAGE"] = "image";
  AIProviderModelType2["TEXT"] = "text";
  return AIProviderModelType2;
})(AIProviderModelType || {});
var BaseAIProviderAuthConfig = object({
  apiKey: string2()
});
var AnthropicProviderAuthConfig = BaseAIProviderAuthConfig;
var ActivePiecesProviderAuthConfig = object({
  apiKey: string2(),
  apiKeyHash: string2()
});
var OpenAICompatibleProviderAuthConfig = BaseAIProviderAuthConfig;
var CloudflareGatewayProviderAuthConfig = BaseAIProviderAuthConfig;
var AzureProviderAuthConfig = BaseAIProviderAuthConfig;
var GoogleProviderAuthConfig = BaseAIProviderAuthConfig;
var OpenAIProviderAuthConfig = BaseAIProviderAuthConfig;
var OpenRouterProviderAuthConfig = BaseAIProviderAuthConfig;
var MistralProviderAuthConfig = BaseAIProviderAuthConfig;
var BedrockProviderAuthConfig = object({
  accessKeyId: string2().check(_minLength(1)),
  secretAccessKey: string2().check(_minLength(1))
});
var AnthropicProviderConfig = object({});
var ActivePiecesProviderConfig = object({});
var GoogleProviderConfig = object({});
var OpenAIProviderConfig = object({});
var OpenRouterProviderConfig = object({});
var MistralProviderConfig = object({});
var ProviderModelConfig = object({
  modelId: string2(),
  modelName: string2(),
  modelType: _enum(AIProviderModelType)
});
var OpenAICompatibleProviderConfig = object({
  apiKeyHeader: string2(),
  baseUrl: string2(),
  models: array(ProviderModelConfig),
  defaultHeaders: optional(record(string2(), string2()))
});
var CloudflareGatewayProviderConfig = object({
  accountId: string2(),
  gatewayId: string2(),
  models: array(ProviderModelConfig),
  vertexProject: optional(string2()),
  vertexRegion: optional(string2())
});
var AzureProviderConfig = object({
  resourceName: string2(),
  apiVersion: pipe(
    transform((v) => typeof v === "string" && v.trim().length === 0 ? void 0 : v),
    optional(string2())
  )
});
var BedrockProviderConfig = object({
  region: string2().check(_minLength(1))
});
var AIProviderAuthConfig = union([
  AnthropicProviderAuthConfig,
  AzureProviderAuthConfig,
  GoogleProviderAuthConfig,
  OpenAIProviderAuthConfig,
  OpenRouterProviderAuthConfig,
  CloudflareGatewayProviderAuthConfig,
  OpenAICompatibleProviderAuthConfig,
  ActivePiecesProviderAuthConfig,
  BedrockProviderAuthConfig,
  MistralProviderAuthConfig
]);
var AIProviderConfig = union([
  OpenAICompatibleProviderConfig,
  CloudflareGatewayProviderConfig,
  AzureProviderConfig,
  BedrockProviderConfig,
  AnthropicProviderConfig,
  GoogleProviderConfig,
  OpenAIProviderConfig,
  OpenRouterProviderConfig,
  ActivePiecesProviderConfig,
  MistralProviderConfig
]);
var AIProviderModel = object({
  id: string2(),
  name: string2(),
  type: _enum(AIProviderModelType)
});
var AIProviderWithoutSensitiveData = object({
  id: string2(),
  name: string2(),
  provider: _enum(AIProviderName),
  config: AIProviderConfig,
  enabledForChat: boolean2()
});
var GetProviderConfigResponse = object({
  provider: _enum(AIProviderName),
  config: AIProviderConfig,
  auth: AIProviderAuthConfig,
  platformId: string2()
});
var CF_GATEWAY_SUBMODEL_TO_PROVIDER = {
  openai: "openai" /* OPENAI */,
  anthropic: "anthropic" /* ANTHROPIC */,
  "google-ai-studio": "google" /* GOOGLE */,
  "google-vertex-ai": "google" /* GOOGLE */
};
var OPENAI_CHAT_MODELS = ["gpt-5.5", "gpt-5.4-mini", "gpt-5.4-nano", "gpt-4.1", "gpt-4.1-mini"];
var ANTHROPIC_CHAT_MODELS = ["claude-sonnet-4-6", "claude-opus-4-7", "claude-haiku-4-5"];
var ANTHROPIC_OPENROUTER_CHAT_MODELS = ["claude-sonnet-4.6", "claude-opus-4.7", "claude-haiku-4.5"];
var GOOGLE_CHAT_MODELS = ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-3.1-pro-preview", "gemini-3-flash-preview"];
var X_AI_OPENROUTER_CHAT_MODELS = ["grok-4.20", "grok-4.1-fast"];
var ALLOWED_CHAT_MODELS_BY_PROVIDER = {
  ["openai" /* OPENAI */]: OPENAI_CHAT_MODELS,
  ["anthropic" /* ANTHROPIC */]: ANTHROPIC_CHAT_MODELS,
  ["google" /* GOOGLE */]: GOOGLE_CHAT_MODELS,
  ["activepieces" /* ACTIVEPIECES */]: [
    ...ANTHROPIC_OPENROUTER_CHAT_MODELS.map((m) => `${"anthropic" /* ANTHROPIC */}/${m}`),
    ...OPENAI_CHAT_MODELS.map((m) => `${"openai" /* OPENAI */}/${m}`),
    ...GOOGLE_CHAT_MODELS.map((m) => `${"google" /* GOOGLE */}/${m}`),
    ...X_AI_OPENROUTER_CHAT_MODELS.map((m) => `x-ai/${m}`)
  ]
};
var DEFAULT_MAX_CONTEXT_TOKENS = 128e3;
var PROVIDER_MAX_CONTEXT_TOKENS = {
  ["openai" /* OPENAI */]: 128e3,
  ["anthropic" /* ANTHROPIC */]: 2e5,
  ["google" /* GOOGLE */]: 1048576,
  ["bedrock" /* BEDROCK */]: 2e5,
  ["azure" /* AZURE */]: 128e3,
  ["openrouter" /* OPENROUTER */]: 128e3,
  ["activepieces" /* ACTIVEPIECES */]: 2e5,
  ["mistral" /* MISTRAL */]: 128e3
};
function getMaxContextTokens({ provider }) {
  if (!provider) return DEFAULT_MAX_CONTEXT_TOKENS;
  return PROVIDER_MAX_CONTEXT_TOKENS[provider] ?? DEFAULT_MAX_CONTEXT_TOKENS;
}
var DEFAULT_EMBEDDING_MODELS = {
  ["openai" /* OPENAI */]: "text-embedding-3-small",
  ["google" /* GOOGLE */]: "text-embedding-004",
  ["azure" /* AZURE */]: "text-embedding-3-small",
  ["activepieces" /* ACTIVEPIECES */]: "text-embedding-3-small",
  ["openrouter" /* OPENROUTER */]: "openai/text-embedding-3-small"
};
var WEB_SEARCH_MODE_BY_PROVIDER = {
  ["anthropic" /* ANTHROPIC */]: "native",
  ["google" /* GOOGLE */]: "native",
  ["openrouter" /* OPENROUTER */]: "plugin",
  ["activepieces" /* ACTIVEPIECES */]: "plugin"
};
var NO_IMAGE_GENERATION_PROVIDERS = /* @__PURE__ */ new Set([
  "anthropic" /* ANTHROPIC */,
  "mistral" /* MISTRAL */
]);
function buildProviderCapabilities(provider) {
  return {
    chatModels: ALLOWED_CHAT_MODELS_BY_PROVIDER[provider],
    maxContextTokens: getMaxContextTokens({ provider }),
    defaultEmbeddingModel: DEFAULT_EMBEDDING_MODELS[provider],
    supportsEmbedding: DEFAULT_EMBEDDING_MODELS[provider] !== void 0,
    supportsImageGeneration: !NO_IMAGE_GENERATION_PROVIDERS.has(provider),
    webSearch: WEB_SEARCH_MODE_BY_PROVIDER[provider]
  };
}
var AI_PROVIDER_CAPABILITIES = {
  ["openai" /* OPENAI */]: buildProviderCapabilities("openai" /* OPENAI */),
  ["anthropic" /* ANTHROPIC */]: buildProviderCapabilities("anthropic" /* ANTHROPIC */),
  ["openrouter" /* OPENROUTER */]: buildProviderCapabilities("openrouter" /* OPENROUTER */),
  ["azure" /* AZURE */]: buildProviderCapabilities("azure" /* AZURE */),
  ["google" /* GOOGLE */]: buildProviderCapabilities("google" /* GOOGLE */),
  ["cloudflare-gateway" /* CLOUDFLARE_GATEWAY */]: buildProviderCapabilities("cloudflare-gateway" /* CLOUDFLARE_GATEWAY */),
  ["custom" /* CUSTOM */]: buildProviderCapabilities("custom" /* CUSTOM */),
  ["bedrock" /* BEDROCK */]: buildProviderCapabilities("bedrock" /* BEDROCK */),
  ["mistral" /* MISTRAL */]: buildProviderCapabilities("mistral" /* MISTRAL */),
  ["activepieces" /* ACTIVEPIECES */]: buildProviderCapabilities("activepieces" /* ACTIVEPIECES */)
};

// packages/core/piece-types/src/lib/forms.ts
init_mini();
var FileResponseInterfaceV1 = object({
  base64Url: string2(),
  fileName: string2(),
  extension: optional(string2())
});
var FileResponseInterfaceV2 = object({
  mimeType: string2(),
  url: string2(),
  fileName: optional(string2())
});
var FileResponseInterface = union([FileResponseInterfaceV1, FileResponseInterfaceV2]);
var HumanInputFormResult = union([
  object({
    type: literal("file" /* FILE */),
    value: FileResponseInterface
  }),
  object({
    type: literal("markdown" /* MARKDOWN */),
    value: string2(),
    files: optional(array(FileResponseInterface))
  })
]);
var ChatFormResponse = object({
  sessionId: string2(),
  message: string2(),
  files: optional(array(string2()))
});

// packages/core/piece-types/src/lib/tables.ts
init_src();
init_mini();
var TableAutomationTrigger = /* @__PURE__ */ ((TableAutomationTrigger2) => {
  TableAutomationTrigger2["ON_NEW_RECORD"] = "ON_NEW_RECORD";
  TableAutomationTrigger2["ON_UPDATE_RECORD"] = "ON_UPDATE_RECORD";
  return TableAutomationTrigger2;
})(TableAutomationTrigger || {});
var TableAutomationStatus = /* @__PURE__ */ ((TableAutomationStatus2) => {
  TableAutomationStatus2["ENABLED"] = "ENABLED";
  TableAutomationStatus2["DISABLED"] = "DISABLED";
  return TableAutomationStatus2;
})(TableAutomationStatus || {});
var TableWebhookEventType = /* @__PURE__ */ ((TableWebhookEventType2) => {
  TableWebhookEventType2["RECORD_CREATED"] = "RECORD_CREATED";
  TableWebhookEventType2["RECORD_UPDATED"] = "RECORD_UPDATED";
  TableWebhookEventType2["RECORD_DELETED"] = "RECORD_DELETED";
  return TableWebhookEventType2;
})(TableWebhookEventType || {});
var Field = union([object({
  ...BaseModelSchema,
  name: string2(),
  externalId: string2(),
  type: literal("STATIC_DROPDOWN" /* STATIC_DROPDOWN */),
  tableId: string2(),
  projectId: string2(),
  data: object({
    options: array(object({
      value: string2()
    }))
  })
}), object({
  ...BaseModelSchema,
  name: string2(),
  externalId: string2(),
  type: union([literal("TEXT" /* TEXT */), literal("NUMBER" /* NUMBER */), literal("DATE" /* DATE */)]),
  tableId: string2(),
  projectId: string2()
})]);
var Table = object({
  ...BaseModelSchema,
  name: string2(),
  folderId: Nullable(string2()),
  projectId: string2(),
  externalId: string2(),
  status: NullableEnum(TableAutomationStatus),
  trigger: NullableEnum(TableAutomationTrigger)
});
var PopulatedRecord = object({
  ...BaseModelSchema,
  tableId: string2(),
  projectId: string2(),
  cells: record(string2(), object({
    updated: string2(),
    created: string2(),
    value: unknown(),
    fieldName: string2()
  }))
});
var CreateTableWebhookRequest = object({
  events: array(_enum(TableWebhookEventType)),
  webhookUrl: string2(),
  flowId: string2()
});
var ExportTableResponse = object({
  fields: array(object({ id: string2(), name: string2() })),
  rows: array(record(string2(), string2())),
  name: string2()
});
var ListTablesRequest = object({
  projectId: string2(),
  limit: optional(coerce_exports.number()),
  cursor: optional(string2()),
  name: optional(string2()),
  externalIds: OptionalArrayFromQuery(string2()),
  folderId: optional(string2()),
  folderIds: OptionalArrayFromQuery(string2())
});
var CreateRecordsRequest = object({
  records: array(array(object({
    fieldId: string2(),
    value: coerceToString()
  }))),
  tableId: string2()
});
var UpdateRecordRequest = object({
  cells: optional(array(object({
    fieldId: string2(),
    value: coerceToString()
  }))),
  tableId: string2(),
  agentUpdate: optional(boolean2())
});
var Filter = discriminatedUnion("operator", [
  valueFilter("eq" /* EQ */),
  valueFilter("neq" /* NEQ */),
  valueFilter("gt" /* GT */),
  valueFilter("gte" /* GTE */),
  valueFilter("lt" /* LT */),
  valueFilter("lte" /* LTE */),
  valueFilter("co" /* CO */),
  existenceFilter("exists" /* EXISTS */),
  existenceFilter("not_exists" /* NOT_EXISTS */)
]);
var ListRecordsRequest = object({
  tableId: string2(),
  limit: optional(coerce_exports.number()),
  cursor: optional(string2()),
  filters: OptionalArrayFromQuery(Filter)
});
function coerceToString() {
  return pipe(
    transform((v) => v === null || v === void 0 ? v : String(v)),
    nullable(string2())
  );
}
function valueFilter(op) {
  return object({
    fieldId: string2(),
    operator: literal(op),
    value: string2()
  });
}
function existenceFilter(op) {
  return object({
    fieldId: string2(),
    operator: literal(op)
  });
}

// packages/core/piece-types/src/lib/flow-contracts.ts
init_src();
init_mini();
var StopResponse = object({
  status: optional(number2()),
  body: optional(unknown()),
  headers: optional(record(string2(), string2()))
});
var Project = object({
  ...BaseModelSchema,
  deleted: Nullable(DateOrString),
  ownerId: string2(),
  displayName: string2(),
  platformId: string2(),
  externalId: Nullable(string2())
});

// packages/core/piece-types/src/lib/mcp-piece.ts
init_mini();
var McpProperty = object({
  name: string2(),
  description: optional(string2()),
  type: string2(),
  required: boolean2()
});
var McpTrigger = object({
  pieceName: string2(),
  triggerName: string2(),
  input: object({
    toolName: string2(),
    toolDescription: string2(),
    inputSchema: array(McpProperty),
    returnsResponse: boolean2()
  })
});

// packages/core/piece-types/src/lib/execution-contracts.ts
init_src();
init_mini();
var EXACT_VERSION_PATTERN = "^[0-9]+\\.[0-9]+\\.[0-9]+$";
var EXACT_VERSION_REGEX = new RegExp(EXACT_VERSION_PATTERN);
var VERSION_PATTERN = "^([~^])?[0-9]+\\.[0-9]+\\.[0-9]+$";
var ExactVersionType = string2().check(_regex(new RegExp(EXACT_VERSION_PATTERN)));
var VersionType = string2().check(_regex(new RegExp(VERSION_PATTERN)));
var PrivatePiecePackage = object({
  packageType: literal("ARCHIVE" /* ARCHIVE */),
  pieceType: _enum(PieceType),
  pieceName: string2(),
  pieceVersion: string2(),
  archiveId: string2(),
  platformId: string2()
});
var OfficialPiecePackage = object({
  packageType: literal("REGISTRY" /* REGISTRY */),
  pieceType: literal("OFFICIAL" /* OFFICIAL */),
  pieceName: string2(),
  pieceVersion: string2()
});
var CustomNpmPiecePackage = object({
  packageType: literal("REGISTRY" /* REGISTRY */),
  pieceType: literal("CUSTOM" /* CUSTOM */),
  pieceName: string2(),
  pieceVersion: string2(),
  platformId: string2()
});
var PublicPiecePackage = union([OfficialPiecePackage, CustomNpmPiecePackage]);
var PiecePackage = union([PrivatePiecePackage, OfficialPiecePackage, CustomNpmPiecePackage]);
var ScheduleOptions = discriminatedUnion("type", [
  object({
    type: literal("CRON_EXPRESSION" /* CRON_EXPRESSION */),
    cronExpression: string2(),
    timezone: string2()
  }),
  object({
    type: literal("INTERVAL" /* INTERVAL */),
    intervalMs: int().check(_gte(6e4))
  })
]);
var TriggerSource = object({
  ...BaseModelSchema,
  type: _enum(TriggerStrategy),
  projectId: string2(),
  flowId: string2(),
  triggerName: string2(),
  schedule: Nullable(ScheduleOptions),
  flowVersionId: string2(),
  pieceName: string2(),
  pieceVersion: string2(),
  deleted: Nullable(string2()),
  simulate: boolean2()
});
var FileType = /* @__PURE__ */ ((FileType2) => {
  FileType2["UNKNOWN"] = "UNKNOWN";
  FileType2["FLOW_RUN_LOG"] = "FLOW_RUN_LOG";
  FileType2["FLOW_RUN_LOG_SLICE"] = "FLOW_RUN_LOG_SLICE";
  FileType2["PACKAGE_ARCHIVE"] = "PACKAGE_ARCHIVE";
  FileType2["FLOW_STEP_FILE"] = "FLOW_STEP_FILE";
  FileType2["SAMPLE_DATA"] = "SAMPLE_DATA";
  FileType2["TRIGGER_PAYLOAD"] = "TRIGGER_PAYLOAD";
  FileType2["SAMPLE_DATA_INPUT"] = "SAMPLE_DATA_INPUT";
  FileType2["TRIGGER_EVENT_FILE"] = "TRIGGER_EVENT_FILE";
  FileType2["PROJECT_RELEASE"] = "PROJECT_RELEASE";
  FileType2["FLOW_VERSION_BACKUP"] = "FLOW_VERSION_BACKUP";
  FileType2["PLATFORM_ASSET"] = "PLATFORM_ASSET";
  FileType2["USER_PROFILE_PICTURE"] = "USER_PROFILE_PICTURE";
  FileType2["WEBHOOK_PAYLOAD"] = "WEBHOOK_PAYLOAD";
  FileType2["KNOWLEDGE_BASE"] = "KNOWLEDGE_BASE";
  FileType2["FLOW_BUNDLE"] = "FLOW_BUNDLE";
  return FileType2;
})(FileType || {});
var FileCompression = /* @__PURE__ */ ((FileCompression2) => {
  FileCompression2["NONE"] = "NONE";
  FileCompression2["ZSTD"] = "ZSTD";
  return FileCompression2;
})(FileCompression || {});
var FileLocation = /* @__PURE__ */ ((FileLocation2) => {
  FileLocation2["S3"] = "S3";
  FileLocation2["DB"] = "DB";
  return FileLocation2;
})(FileLocation || {});
var File2 = object({
  ...BaseModelSchema,
  projectId: Nullable(string2()),
  platformId: Nullable(string2()),
  type: _enum(FileType),
  compression: _enum(FileCompression),
  data: optional(unknown()),
  location: _enum(FileLocation),
  size: Nullable(number2()),
  fileName: Nullable(string2()),
  s3Key: Nullable(string2()),
  metadata: Nullable(record(string2(), string2()))
});
var PlatformRole = /* @__PURE__ */ ((PlatformRole2) => {
  PlatformRole2["ADMIN"] = "ADMIN";
  PlatformRole2["MEMBER"] = "MEMBER";
  PlatformRole2["OPERATOR"] = "OPERATOR";
  return PlatformRole2;
})(PlatformRole || {});
var UserStatus = /* @__PURE__ */ ((UserStatus2) => {
  UserStatus2["ACTIVE"] = "ACTIVE";
  UserStatus2["INACTIVE"] = "INACTIVE";
  return UserStatus2;
})(UserStatus || {});
var UserWithMetaInformation = object({
  id: string2(),
  email: string2(),
  firstName: string2(),
  status: _enum(UserStatus),
  externalId: Nullable(string2()),
  platformId: Nullable(string2()),
  platformRole: _enum(PlatformRole),
  lastName: string2(),
  created: DateOrString,
  updated: DateOrString,
  lastActiveDate: Nullable(DateOrString),
  imageUrl: Nullable(string2())
});

// packages/pieces/framework/src/lib/property/input/object-property.ts
init_mini();
var ObjectProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(
    record(string2(), unknown()),
    "OBJECT" /* OBJECT */
  ).shape
});

// packages/pieces/framework/src/lib/property/input/color-property.ts
init_mini();
var ColorProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(string2(), "COLOR" /* COLOR */).shape
});

// packages/pieces/framework/src/lib/property/input/index.ts
var InputProperty = union([
  ShortTextProperty,
  LongTextProperty,
  MarkDownProperty,
  CheckboxProperty,
  StaticDropdownProperty,
  StaticMultiSelectDropdownProperty,
  DropdownProperty,
  MultiSelectDropdownProperty,
  DynamicProperties,
  NumberProperty,
  ArrayProperty,
  ObjectProperty,
  JsonProperty,
  DateTimeProperty,
  FileProperty,
  ColorProperty
]);
var Property = {
  ShortText(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "SHORT_TEXT" /* SHORT_TEXT */
    };
  },
  Checkbox(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "CHECKBOX" /* CHECKBOX */
    };
  },
  LongText(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "LONG_TEXT" /* LONG_TEXT */
    };
  },
  MarkDown(request) {
    return {
      displayName: "Markdown",
      required: false,
      description: request.value,
      type: "MARKDOWN" /* MARKDOWN */,
      valueSchema: void 0,
      variant: request.variant ?? "INFO" /* INFO */
    };
  },
  Number(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "NUMBER" /* NUMBER */
    };
  },
  Json(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "JSON" /* JSON */
    };
  },
  Array(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "ARRAY" /* ARRAY */
    };
  },
  Object(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "OBJECT" /* OBJECT */
    };
  },
  Dropdown(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "DROPDOWN" /* DROPDOWN */
    };
  },
  StaticDropdown(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "STATIC_DROPDOWN" /* STATIC_DROPDOWN */
    };
  },
  MultiSelectDropdown(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "MULTI_SELECT_DROPDOWN" /* MULTI_SELECT_DROPDOWN */
    };
  },
  DynamicProperties(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "DYNAMIC" /* DYNAMIC */
    };
  },
  StaticMultiSelectDropdown(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "STATIC_MULTI_SELECT_DROPDOWN" /* STATIC_MULTI_SELECT_DROPDOWN */
    };
  },
  DateTime(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "DATE_TIME" /* DATE_TIME */
    };
  },
  File(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "FILE" /* FILE */
    };
  },
  Custom(request) {
    const code = request.code.toString();
    return {
      ...request,
      code,
      valueSchema: void 0,
      type: "CUSTOM" /* CUSTOM */
    };
  },
  Color(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "COLOR" /* COLOR */
    };
  }
};

// packages/pieces/framework/src/lib/property/authentication/index.ts
init_mini();

// packages/pieces/framework/src/lib/property/authentication/basic-auth-prop.ts
init_mini();

// packages/pieces/framework/src/lib/property/authentication/common.ts
init_mini();
var BasePieceAuthSchema = object({
  displayName: string2(),
  description: optional(string2()),
  hasConnectionIdentifier: optional(boolean2())
});

// packages/pieces/framework/src/lib/property/authentication/basic-auth-prop.ts
var BasicAuthPropertyValue = object({
  username: string2(),
  password: string2()
});
var BasicAuthProperty = object({
  ...BasePieceAuthSchema.shape,
  username: object({
    displayName: string2(),
    description: optional(string2())
  }),
  password: object({
    displayName: string2(),
    description: optional(string2())
  }),
  ...TPropertyValue(BasicAuthPropertyValue, "BASIC_AUTH" /* BASIC_AUTH */).shape
});

// packages/pieces/framework/src/lib/property/authentication/custom-auth-prop.ts
init_mini();
var CustomAuthProps = record(string2(), union([
  ShortTextProperty,
  LongTextProperty,
  NumberProperty,
  CheckboxProperty,
  StaticDropdownProperty
]));
var CustomAuthProperty = object({
  ...BasePieceAuthSchema.shape,
  props: CustomAuthProps,
  ...TPropertyValue(unknown(), "CUSTOM_AUTH" /* CUSTOM_AUTH */).shape
});

// packages/pieces/framework/src/lib/property/authentication/oidc-prop.ts
init_mini();

// packages/pieces/framework/src/lib/property/authentication/secret-text-property.ts
init_mini();
var SecretTextProperty = object({
  ...BasePieceAuthSchema.shape,
  ...TPropertyValue(object({
    auth: string2()
  }), "SECRET_TEXT" /* SECRET_TEXT */).shape
});

// packages/pieces/framework/src/lib/property/authentication/oidc-prop.ts
var OIDCAuthProps = record(string2(), union([
  ShortTextProperty,
  LongTextProperty,
  SecretTextProperty,
  NumberProperty,
  CheckboxProperty,
  StaticDropdownProperty,
  StaticMultiSelectDropdownProperty,
  MarkDownProperty
]));
var OIDCProperty = object({
  ...BasePieceAuthSchema.shape,
  props: OIDCAuthProps,
  ...TPropertyValue(unknown(), "OIDC" /* OIDC */).shape
});

// packages/pieces/framework/src/lib/property/authentication/oauth2-prop.ts
init_mini();
var OAuth2AuthorizationMethod = /* @__PURE__ */ ((OAuth2AuthorizationMethod2) => {
  OAuth2AuthorizationMethod2["HEADER"] = "HEADER";
  OAuth2AuthorizationMethod2["BODY"] = "BODY";
  return OAuth2AuthorizationMethod2;
})(OAuth2AuthorizationMethod || {});
var OAuthProp = union([
  ShortTextProperty,
  SecretTextProperty,
  StaticDropdownProperty
]);
var OAuth2Props = record(string2(), OAuthProp);
var OAuth2ExtraProps = object({
  props: optional(record(string2(), OAuthProp)),
  authUrl: string2(),
  tokenUrl: string2(),
  scope: array(string2()),
  prompt: optional(union([literal("none"), literal("consent"), literal("login"), literal("omit")])),
  pkce: optional(boolean2()),
  pkceMethod: optional(union([literal("plain"), literal("S256")])),
  authorizationMethod: optional(_enum(OAuth2AuthorizationMethod)),
  grantType: optional(union([_enum(OAuth2GrantType), literal(BOTH_CLIENT_CREDENTIALS_AND_AUTHORIZATION_CODE)])),
  extra: optional(record(string2(), string2()))
});
var OAuth2PropertyValue = object({
  access_token: string2(),
  props: optional(OAuth2Props),
  data: record(string2(), any())
});
var OAuth2Property = object({
  ...BasePieceAuthSchema.shape,
  ...OAuth2ExtraProps.shape,
  ...TPropertyValue(OAuth2PropertyValue, "OAUTH2" /* OAUTH2 */).shape
});

// packages/pieces/framework/src/lib/property/authentication/index.ts
init_src();
var PieceAuthProperty = union([
  BasicAuthProperty,
  CustomAuthProperty,
  OIDCProperty,
  OAuth2Property,
  SecretTextProperty
]);
var DEFAULT_CONNECTION_DISPLAY_NAME = "Connection";
var PieceAuth = {
  SecretText(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "SECRET_TEXT" /* SECRET_TEXT */
    };
  },
  OAuth2(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "OAUTH2" /* OAUTH2 */,
      displayName: request.displayName || DEFAULT_CONNECTION_DISPLAY_NAME
    };
  },
  BasicAuth(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "BASIC_AUTH" /* BASIC_AUTH */,
      displayName: request.displayName || DEFAULT_CONNECTION_DISPLAY_NAME,
      required: true
    };
  },
  CustomAuth(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "CUSTOM_AUTH" /* CUSTOM_AUTH */,
      displayName: request.displayName || DEFAULT_CONNECTION_DISPLAY_NAME
    };
  },
  OIDC(request) {
    return {
      ...request,
      valueSchema: void 0,
      type: "OIDC" /* OIDC */,
      displayName: request.displayName || DEFAULT_CONNECTION_DISPLAY_NAME
    };
  },
  None() {
    return void 0;
  }
};
var authConnectionTypeToPropertyType = {
  ["OAUTH2" /* OAUTH2 */]: "OAUTH2" /* OAUTH2 */,
  ["CLOUD_OAUTH2" /* CLOUD_OAUTH2 */]: "OAUTH2" /* OAUTH2 */,
  ["PLATFORM_OAUTH2" /* PLATFORM_OAUTH2 */]: "OAUTH2" /* OAUTH2 */,
  ["BASIC_AUTH" /* BASIC_AUTH */]: "BASIC_AUTH" /* BASIC_AUTH */,
  ["CUSTOM_AUTH" /* CUSTOM_AUTH */]: "CUSTOM_AUTH" /* CUSTOM_AUTH */,
  ["OIDC" /* OIDC */]: "OIDC" /* OIDC */,
  ["SECRET_TEXT" /* SECRET_TEXT */]: "SECRET_TEXT" /* SECRET_TEXT */,
  ["NO_AUTH" /* NO_AUTH */]: void 0
};

// packages/pieces/framework/src/lib/property/index.ts
init_mini();

// packages/pieces/framework/src/lib/property/input/custom-property.ts
init_mini();
var CustomProperty = object({
  ...BasePropertySchema.shape,
  ...TPropertyValue(unknown(), "CUSTOM" /* CUSTOM */).shape,
  code: string2()
});

// packages/pieces/framework/src/lib/property/util.ts
init_mini();
init_src();

// packages/pieces/framework/src/lib/property/index.ts
var PieceProperty = union([InputProperty, PieceAuthProperty]);
var PiecePropertyMap = record(string2(), PieceProperty);
var InputPropertyMap = record(string2(), InputProperty);

// packages/pieces/framework/src/lib/trigger/trigger.ts
init_mini();
init_src();
var WebhookRenewConfiguration = union([
  object({
    strategy: literal("CRON" /* CRON */),
    cronExpression: string2()
  }),
  object({
    strategy: literal("NONE" /* NONE */)
  })
]);

// packages/pieces/framework/src/lib/context/versioning.ts
var LATEST_CONTEXT_VERSION = "2" /* V2 */;
var MINIMUM_SUPPORTED_RELEASE_AFTER_LATEST_CONTEXT_VERSION = "0.82.0";

// packages/pieces/framework/src/lib/piece.ts
var Piece = class {
  constructor(displayName, logoUrl, authors, events, actions, triggers, categories, auth, minimumSupportedRelease = MINIMUM_SUPPORTED_RELEASE_AFTER_LATEST_CONTEXT_VERSION, maximumSupportedRelease, description = "", deprecated) {
    this.displayName = displayName;
    this.logoUrl = logoUrl;
    this.authors = authors;
    this.events = events;
    this.categories = categories;
    this.auth = auth;
    this.minimumSupportedRelease = minimumSupportedRelease;
    this.maximumSupportedRelease = maximumSupportedRelease;
    this.description = description;
    this.deprecated = deprecated;
    this._actions = {};
    this._triggers = {};
    // this method didn't exist in older version
    this.getContextInfo = () => ({ version: LATEST_CONTEXT_VERSION });
    if (!isValidSimpleSemver(minimumSupportedRelease) || isSemverLessThan(minimumSupportedRelease, MINIMUM_SUPPORTED_RELEASE_AFTER_LATEST_CONTEXT_VERSION)) {
      this.minimumSupportedRelease = MINIMUM_SUPPORTED_RELEASE_AFTER_LATEST_CONTEXT_VERSION;
    }
    actions.forEach((action) => this._actions[action.name] = action);
    triggers.forEach((trigger) => this._triggers[trigger.name] = trigger);
  }
  metadata() {
    return {
      displayName: this.displayName,
      logoUrl: this.logoUrl,
      actions: this._actions,
      triggers: this._triggers,
      categories: this.categories,
      description: this.description,
      authors: this.authors,
      auth: withConnectionIdentifierFlag(this.auth),
      minimumSupportedRelease: this.minimumSupportedRelease,
      maximumSupportedRelease: this.maximumSupportedRelease,
      deprecated: this.deprecated,
      contextInfo: this.getContextInfo?.()
    };
  }
  getAction(actionName) {
    return this._actions[actionName];
  }
  getTrigger(triggerName) {
    return this._triggers[triggerName];
  }
  actions() {
    return this._actions;
  }
  triggers() {
    return this._triggers;
  }
};
var createPiece = (params) => {
  if (params.auth && Array.isArray(params.auth)) {
    const isUnique = params.auth.every(
      (auth, index, self) => index === self.findIndex((t) => t.type === auth.type)
    );
    if (!isUnique) {
      throw new Error("Auth properties must be unique by type");
    }
  }
  return new Piece(
    params.displayName,
    params.logoUrl,
    params.authors ?? [],
    params.events,
    params.actions,
    params.triggers,
    params.categories ?? [],
    params.auth,
    params.minimumSupportedRelease,
    params.maximumSupportedRelease,
    params.description,
    params.deprecated
  );
};
function withConnectionIdentifierFlag(auth) {
  if (auth === void 0) {
    return void 0;
  }
  return Array.isArray(auth) ? auth.map(flagConnectionIdentifier) : flagConnectionIdentifier(auth);
}
function flagConnectionIdentifier(auth) {
  return { ...auth, hasConnectionIdentifier: auth.getConnectionIdentifier !== void 0 };
}
function isValidSimpleSemver(version2) {
  return /^\d+\.\d+\.\d+$/.test(version2);
}
function isSemverLessThan(a, b) {
  const [a1, a2, a3] = a.split(".").map(Number);
  const [b1, b2, b3] = b.split(".").map(Number);
  if (a1 !== b1) return a1 < b1;
  if (a2 !== b2) return a2 < b2;
  return a3 < b3;
}

// packages/pieces/framework/src/lib/piece-metadata.ts
init_mini();
var I18nForPiece = optional(record(string2(), record(string2(), string2())));
var PieceBase = object({
  id: optional(string2()),
  name: string2(),
  displayName: string2(),
  logoUrl: string2(),
  description: string2(),
  authors: array(string2()),
  platformId: optional(string2()),
  directoryPath: optional(string2()),
  auth: optional(union([PieceAuthProperty, array(PieceAuthProperty)])),
  version: string2(),
  categories: optional(array(_enum(PieceCategory))),
  minimumSupportedRelease: optional(string2()),
  maximumSupportedRelease: optional(string2()),
  deprecated: optional(boolean2()),
  i18n: I18nForPiece
});
var Audience = _enum(["human", "ai", "both"]);
var AiMetadata = object({
  description: optional(string2()),
  idempotent: optional(boolean2())
});
var ActionBase = object({
  name: string2(),
  displayName: string2(),
  description: string2(),
  props: PiecePropertyMap,
  requireAuth: boolean2(),
  errorHandlingOptions: optional(ErrorHandlingOptionsParam),
  outputSchema: optional(custom()),
  audience: optional(Audience),
  aiMetadata: optional(AiMetadata)
});
var TriggerBase = object({
  name: string2(),
  displayName: string2(),
  description: string2(),
  props: PiecePropertyMap,
  errorHandlingOptions: optional(ErrorHandlingOptionsParam),
  type: _enum(TriggerStrategy),
  sampleData: unknown(),
  handshakeConfiguration: optional(custom()),
  renewConfiguration: optional(WebhookRenewConfiguration),
  testStrategy: _enum(TriggerTestStrategy),
  outputSchema: optional(custom()),
  aiMetadata: optional(AiMetadata)
});
var PieceMetadata = object({
  ...PieceBase.shape,
  actions: record(string2(), ActionBase),
  triggers: record(string2(), TriggerBase)
});
var PieceMetadataSummary = object({
  ...PieceBase.shape,
  actions: number2(),
  triggers: number2(),
  suggestedActions: optional(array(ActionBase)),
  suggestedTriggers: optional(array(TriggerBase))
});
var PiecePackageMetadata = object({
  projectUsage: number2(),
  pieceType: _enum(PieceType),
  packageType: _enum(PackageType),
  platformId: optional(string2()),
  archiveId: optional(string2())
});
var PieceMetadataModel = object({
  ...PieceMetadata.shape,
  ...PiecePackageMetadata.shape
});
var PieceMetadataModelSummary = object({
  ...PieceMetadataSummary.shape,
  ...PiecePackageMetadata.shape
});
var PiecePackageInformation = object({
  name: string2(),
  version: string2()
});

// packages/pieces/framework/src/lib/i18n.ts
init_src();

// packages/pieces/framework/src/index.ts
init_src();

// packages/pieces/community/hash-helper/src/lib/common/hashing.ts
var import_crypto2 = require("crypto");
function hashText(text, algorithm, encoding = "hex") {
  return (0, import_crypto2.createHash)(algorithm).update(text, "utf8").digest(encoding);
}
function base64Encode(text) {
  return Buffer.from(text, "utf8").toString("base64");
}
function base64Decode(encoded) {
  const normalized = encoded.replace(/\s+/g, "");
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized) || normalized.length % 4 !== 0) {
    throw new Error(`\u4E0D\u662F\u5408\u6CD5\u7684 Base64 \u8F93\u5165:${encoded.slice(0, 40)}`);
  }
  return Buffer.from(normalized, "base64").toString("utf8");
}

// packages/pieces/community/hash-helper/src/lib/actions/base64-decode.ts
var base64DecodeAction = createAction({
  name: "base64_decode",
  displayName: "Base64 Decode",
  description: "\u628A Base64 \u89E3\u7801\u4E3A UTF-8 \u6587\u672C;\u975E\u6CD5\u8F93\u5165\u629B\u9519\u4E2D\u65AD\u3002",
  props: {
    encoded: Property.LongText({ displayName: "Base64 Text", required: true })
  },
  run: async (ctx) => {
    return { text: base64Decode(ctx.propsValue.encoded) };
  }
});

// packages/pieces/community/hash-helper/src/lib/actions/base64-encode.ts
var base64EncodeAction = createAction({
  name: "base64_encode",
  displayName: "Base64 Encode",
  description: "\u628A UTF-8 \u6587\u672C\u7F16\u7801\u4E3A Base64\u3002",
  props: {
    text: Property.LongText({ displayName: "Text", required: true })
  },
  run: async (ctx) => {
    return { encoded: base64Encode(ctx.propsValue.text) };
  }
});

// packages/pieces/community/hash-helper/src/lib/actions/hash-text.ts
var hashTextAction = createAction({
  name: "hash_text",
  // 稳定机器名,进 flow JSON,改名=breaking
  displayName: "Hash Text",
  description: "\u8BA1\u7B97\u6587\u672C\u6458\u8981(SHA-256/SHA-512/SHA-1/MD5),\u7EAF\u672C\u5730\u3002",
  props: {
    text: Property.LongText({
      displayName: "Text",
      description: "\u8981\u8BA1\u7B97\u6458\u8981\u7684\u6587\u672C\u3002",
      required: true
    }),
    algorithm: Property.StaticDropdown({
      displayName: "Algorithm",
      required: true,
      defaultValue: "sha256",
      options: {
        options: [
          { label: "SHA-256", value: "sha256" },
          { label: "SHA-512", value: "sha512" },
          { label: "SHA-1", value: "sha1" },
          { label: "MD5", value: "md5" }
        ]
      }
    }),
    encoding: Property.StaticDropdown({
      displayName: "Output Encoding",
      required: false,
      defaultValue: "hex",
      options: {
        options: [
          { label: "Hex", value: "hex" },
          { label: "Base64", value: "base64" }
        ]
      }
    })
  },
  run: async (ctx) => {
    const { text, algorithm, encoding } = ctx.propsValue;
    const digest = hashText(
      text,
      algorithm,
      encoding ?? "hex"
    );
    return { digest, algorithm, encoding: encoding ?? "hex" };
  }
});

// packages/pieces/community/hash-helper/src/index.ts
var hashHelper = createPiece({
  displayName: "Hash Helper",
  description: "\u6587\u672C\u6458\u8981\u4E0E Base64 \u7F16\u89E3\u7801(\u7EAF\u672C\u5730,\u65E0\u5916\u7F51)\u3002",
  auth: PieceAuth.None(),
  // 纯计算件无需鉴权
  // 0.88 的 context V2 下限（framework 的 MINIMUM_SUPPORTED_RELEASE_AFTER_LATEST_CONTEXT_VERSION）。
  // 写低于它的值不会报错，只会被 Piece 构造器静默抬到这个数——写实值免得日后误判兼容范围。
  minimumSupportedRelease: "0.82.0",
  logoUrl: "/ap-cdn/pieces/hermes/hash-helper.svg",
  // HERMES: 气隙自托管图标(X-3)
  authors: ["workflow-station"],
  categories: ["CORE" /* CORE */],
  actions: [hashTextAction, base64EncodeAction, base64DecodeAction],
  triggers: []
});
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  hashHelper
});
